package org.apache.commons.lang3.text.translate;

import java.io.IOException;
import java.io.Writer;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class NumericEntityUnescaper_A30_Test {

@Test public void testTranslate() throws Exception { assertEquals(0, escaper.translate("&", 0, writer)); assertEquals(1, escaper.translate("&", 1, writer)); assertEquals(2, escaper.translate("&", 2, writer)); assertEquals(3, escaper.translate("&", 3, writer)); assertEquals(4, escaper.translate("&", 4, writer)); assertEquals(5, escaper.translate("&", 5, writer)); assertEquals(6, escaper.translate("&", 6, writer)); assertEquals(7, escaper.translate("&", 7, writer)); assertEquals(8, escaper.translate("&", 8, writer)); assertEquals(9, escaper.translate("&", 9, writer)); assertEquals(12, escaper.translate("&", 10, writer)); assertEquals(20, escaper.translate("&", 20, writer)); assertEquals(25, escaper.translate("&", 20, writer)); assertEquals(25, escaper.translate("&", 21, writer)); assertEquals(25, escaper.translate("&", 22, writer)); assertEquals(25, escaper.translate("&", 26, writer)); assertEquals(25, escaper.translate("&", 27, writer)); assertEquals(25, escaper.translate("&", 28, writer)); assertEquals(27, escaper.translate("&", 28, writer)); }
}
