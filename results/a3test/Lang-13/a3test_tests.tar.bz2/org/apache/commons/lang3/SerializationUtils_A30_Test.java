package org.apache.commons.lang3;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class SerializationUtils_A30_Test {

@Test public void testClassLoaderAwareObjectInputStream() throws IOException { ClassLoaderAwareObjectInputStream classLoaderAwareObjectInputStream = new ClassLoaderAwareObjectInputStream(getClass().getResourceAsStream("/test.class"), getClass().getClassLoader()); assertEquals(classLoaderAwareObjectInputStream.getClass(), classLoaderAwareObjectInputStream.getClass()); }
}
