package org.apache.commons.lang3;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class SerializationUtils_A31_Test {

@Test public void testresolveClass() throws Exception { try (InputStream stream = SerializationUtilsTest.class.getResourceAsStream("/test.txt")) { Class<?> c = SerializationUtils.resolveClass(new ObjectStreamClass(stream)); assertThat(c).isEqualTo(String.class); } }
}
