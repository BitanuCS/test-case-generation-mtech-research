package org.apache.commons.lang3.text.translate;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class LookupTranslator_A31_Test {

@Test public void testLonger() throws Exception { final LookupTranslator translator = new LookupTranslator(new CharSequence[] { "a", "b", "c" }); assertThat(translator.translate("a", 0, new StringWriter()), is(1)); assertThat(translator.translate("b", 2, new StringWriter()), is(2)); assertThat(translator.translate("b", 3, new StringWriter()), is(3)); assertThat(translator.translate("b", 4, new StringWriter()), is(4)); assertThat(translator.translate("b", 5, new StringWriter()), is(5)); assertThat(translator.translate("b", 6, new StringWriter()), is(6)); assertThat(translator.translate("b", 7, new StringWriter()), is(7)); assertThat(translator.translate("b", 8, new StringWriter()), is(8)); assertThat(translator.translate("b", 9, new StringWriter()), is(9)); assertThat(translator.translate("b", 10, new StringWriter()), is(9)); assertThat(translator.translate("b", 11, new StringWriter()), is(11)); assertThat(translator.translate("b", 12, new StringWriter()), is(12)); assertThat(translator.translate("b", 13, new StringWriter()), is(12)); }
}
