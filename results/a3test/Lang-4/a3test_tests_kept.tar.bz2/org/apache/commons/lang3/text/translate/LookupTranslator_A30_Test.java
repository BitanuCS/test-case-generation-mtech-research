package org.apache.commons.lang3.text.translate;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class LookupTranslator_A30_Test {

@Test public void testLookupTranslator() throws Exception { final LookupTranslator translator = new LookupTranslator(new CharSequence[] { "a", "b", "c" }, new CharSequence[] { "a", "b", "c" }); Assert.assertEquals(lookup("a", "b", "c"), translator.translate("a", 2, new StringWriter())); Assert.assertEquals(lookup("a", "b", "c"), translator.translate("a", 2, new StringWriter())); Assert.assertEquals(lookup("a", "b", "c"), translator.translate("a", 2, new StringWriter())); Assert.assertEquals(lookup("a", "b", "c"), translator.translate("a", 2, new StringWriter())); Assert.assertEquals(lookup("a", "b", "c"), translator.translate("a", 2, new StringWriter())); Assert.assertEquals(lookup("a", "b", "c"), translator.translate("a", 2, new StringWriter())); Assert.assertEquals(lookup("a", "b", "c"), translator.translate("a", 2, new StringWriter())); Assert.assertEquals(lookup("a", "b", "c"), translator.translate("a", 2, new StringWriter())); }
}
