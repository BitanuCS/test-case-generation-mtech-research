package org.jfree.chart.imagemap;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class StandardToolTipTagFragmentGenerator_A30_Test {

@Test public void testGenerateToolTipFragment() throws Exception { assertEquals("title=\"\" alt=\"\"", new StandardToolTipTagFragmentGenerator().generateToolTipFragment("")); }
}
