package org.apache.commons.lang3.text;

import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.Validate;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class ExtendedMessageFormat_A31_Test {

@Test public void testHashCode() throws Exception { ExtendedMessageFormat first = new ExtendedMessageFormat("a"); ExtendedMessageFormat second = new ExtendedMessageFormat("b"); assertEquals(first.hashCode(), second.hashCode()); }
}
