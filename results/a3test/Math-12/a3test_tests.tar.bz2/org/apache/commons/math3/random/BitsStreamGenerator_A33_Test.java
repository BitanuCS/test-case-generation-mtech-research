package org.apache.commons.math3.random;

import java.io.Serializable;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.util.FastMath;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class BitsStreamGenerator_A33_Test {

@Test public void testRandom() throws Exception { for (int i = 0; i < 1000; i++) { BitsStream random = new BitsStreamGenerator(); random.setSeed(i); } }
}
