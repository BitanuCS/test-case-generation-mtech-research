package org.jfree.chart.block;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test2001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2001");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(249.0d, (double) 0, (double) 1L, 101.0d);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D7 = blockContainer6.getBounds();
        blockContainer6.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockContainer6.getMargin();
        blockContainer6.setHeight(35.0d);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer13.getBounds();
        blockContainer13.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockContainer13.getMargin();
        org.jfree.chart.block.AbstractBlock abstractBlock18 = new org.jfree.chart.block.AbstractBlock();
        double double20 = abstractBlock18.calculateTotalWidth((double) (-1));
        java.lang.String str21 = abstractBlock18.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock18.setPadding(rectangleInsets22);
        abstractBlock18.setHeight((double) 10);
        org.jfree.chart.block.BlockBorder blockBorder26 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = blockBorder26.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D29 = blockContainer28.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets27.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType30, lengthAdjustmentType31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean35 = rectangleEdge33.equals((java.lang.Object) 10L);
        java.lang.String str36 = rectangleEdge33.toString();
        double double37 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D29, rectangleEdge33);
        java.awt.geom.Rectangle2D rectangle2D38 = abstractBlock18.trimPadding(rectangle2D29);
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets17.createOutsetRectangle(rectangle2D38);
        blockContainer6.setBounds(rectangle2D39);
        // The following exception was thrown during execution in test generation
        try {
            blockBorder4.draw(graphics2D5, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(blockBorder26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "RectangleEdge.RIGHT" + "'", str36, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test2002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2002");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) 0, (double) 'a', (double) 100);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint6 = blockBorder5.getPaint();
        org.jfree.chart.block.BorderArrangement borderArrangement8 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 1.0f);
        double double13 = range12.getLength();
        double double14 = range12.getCentralValue();
        org.jfree.data.Range range15 = null;
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range15, (double) 1.0f);
        double double18 = range17.getLength();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = borderArrangement8.arrangeRR(blockContainer9, range12, range17, graphics2D19);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range23 = null;
        org.jfree.data.Range range25 = org.jfree.data.Range.expandToInclude(range23, (double) 1.0f);
        boolean boolean28 = range25.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(0.0d, range12, lengthConstraintType21, (double) 100L, range25, lengthConstraintType29);
        boolean boolean31 = blockBorder5.equals((java.lang.Object) lengthConstraintType29);
        java.awt.Paint paint32 = blockBorder5.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = blockBorder33.getInsets();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType35 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D37 = blockContainer36.getBounds();
        blockContainer36.clear();
        blockContainer36.clear();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = blockContainer36.getMargin();
        java.lang.String str41 = blockContainer36.getID();
        blockContainer36.setPadding((double) 100.0f, (-1.0d), (double) (-1.0f), (double) 100);
        boolean boolean47 = lengthConstraintType35.equals((java.lang.Object) (-1.0d));
        boolean boolean48 = rectangleInsets34.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double52 = rectangleInsets50.calculateLeftOutset((double) '4');
        org.jfree.chart.block.BlockContainer blockContainer53 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D54 = blockContainer53.getBounds();
        blockContainer53.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.block.BlockContainer blockContainer57 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D58 = blockContainer57.getBounds();
        java.awt.geom.Rectangle2D rectangle2D59 = blockContainer53.trimBorder(rectangle2D58);
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets50.createInsetRectangle(rectangle2D58);
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets49.createInsetRectangle(rectangle2D60, false, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType64 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets34.createAdjustedRectangle(rectangle2D60, lengthAdjustmentType64, lengthAdjustmentType65);
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(lengthConstraintType35);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D66);
    }

    @Test
    public void test2003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2003");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double6 = rectangleConstraint5.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = blockContainer0.toContentConstraint(rectangleConstraint5);
        blockContainer0.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.block.AbstractBlock abstractBlock10 = new org.jfree.chart.block.AbstractBlock();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = abstractBlock10.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = abstractBlock10.getPadding();
        blockContainer0.setPadding(rectangleInsets12);
        double double14 = rectangleInsets12.getBottom();
        double double16 = rectangleInsets12.trimHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test2004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2004");
        org.jfree.chart.block.AbstractBlock abstractBlock0 = new org.jfree.chart.block.AbstractBlock();
        double double2 = abstractBlock0.calculateTotalWidth((double) (-1));
        java.lang.String str3 = abstractBlock0.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock0.setPadding(rectangleInsets4);
        double double7 = rectangleInsets4.extendWidth((double) (short) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement9 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = null;
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude(range11, (double) 1.0f);
        double double14 = range13.getLength();
        double double15 = range13.getCentralValue();
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (double) 1.0f);
        double double19 = range18.getLength();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = borderArrangement9.arrangeRR(blockContainer10, range13, range18, graphics2D20);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range24 = null;
        org.jfree.data.Range range26 = org.jfree.data.Range.expandToInclude(range24, (double) 1.0f);
        boolean boolean29 = range26.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(0.0d, range13, lengthConstraintType22, (double) 100L, range26, lengthConstraintType30);
        org.jfree.data.Range range33 = org.jfree.data.Range.expandToInclude(range26, 0.0d);
        boolean boolean34 = rectangleInsets4.equals((java.lang.Object) range26);
        java.lang.String str35 = range26.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "Range[1.0,1.0]" + "'", str35, "Range[1.0,1.0]");
    }

    @Test
    public void test2005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2005");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (short) 100);
        double double3 = range2.getLowerBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.calculateRightInset((double) 1.0f);
        double double8 = rectangleInsets4.trimWidth((double) 100);
        double double10 = rectangleInsets4.calculateBottomOutset((double) 100L);
        double double12 = rectangleInsets4.calculateRightOutset((double) 'a');
        boolean boolean13 = range2.equals((java.lang.Object) rectangleInsets4);
        org.jfree.chart.block.BlockBorder blockBorder14 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint15 = blockBorder14.getPaint();
        org.jfree.chart.block.BorderArrangement borderArrangement17 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer18 = null;
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (double) 1.0f);
        double double22 = range21.getLength();
        double double23 = range21.getCentralValue();
        org.jfree.data.Range range24 = null;
        org.jfree.data.Range range26 = org.jfree.data.Range.expandToInclude(range24, (double) 1.0f);
        double double27 = range26.getLength();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = borderArrangement17.arrangeRR(blockContainer18, range21, range26, graphics2D28);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range32 = null;
        org.jfree.data.Range range34 = org.jfree.data.Range.expandToInclude(range32, (double) 1.0f);
        boolean boolean37 = range34.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType38 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint(0.0d, range21, lengthConstraintType30, (double) 100L, range34, lengthConstraintType38);
        boolean boolean40 = blockBorder14.equals((java.lang.Object) lengthConstraintType38);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = blockBorder14.getInsets();
        double double43 = rectangleInsets41.calculateBottomInset((double) 10);
        double double45 = rectangleInsets41.calculateTopInset((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double48 = rectangleInsets46.calculateRightInset((double) 1.0f);
        double double50 = rectangleInsets46.trimWidth((double) 100);
        double double52 = rectangleInsets46.calculateBottomOutset((double) 100L);
        double double54 = rectangleInsets46.calculateRightOutset((double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer55 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D56 = blockContainer55.getBounds();
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets46.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets41.createAdjustedRectangle(rectangle2D56, lengthAdjustmentType58, lengthAdjustmentType59);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets4.createAdjustedRectangle(rectangle2D56, lengthAdjustmentType61, lengthAdjustmentType62);
        double double65 = rectangleInsets4.calculateBottomOutset(0.0d);
        double double67 = rectangleInsets4.extendHeight((double) 0.0f);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(blockBorder14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.0d + "'", double50 == 100.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test2006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2006");
        org.jfree.chart.block.AbstractBlock abstractBlock0 = new org.jfree.chart.block.AbstractBlock();
        double double2 = abstractBlock0.calculateTotalWidth((double) (-1));
        java.lang.String str3 = abstractBlock0.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock0.setPadding(rectangleInsets4);
        double double7 = rectangleInsets4.calculateRightOutset((double) (-1L));
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets4.getUnitType();
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D();
        boolean boolean10 = unitType8.equals((java.lang.Object) size2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType8, 99.0d, (double) (byte) 1, 32.0d, 197.0d);
        java.lang.String str16 = unitType8.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType8, 150.0d, (-153.0d), (-1.0d), 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "UnitType.ABSOLUTE" + "'", str16, "UnitType.ABSOLUTE");
    }

    @Test
    public void test2007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2007");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0.0f, 0.0d, (double) 10, (double) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, 32.0d, (double) '4', (double) (short) 0);
        double double11 = rectangleInsets9.calculateRightOutset((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.Object obj13 = new java.lang.Object();
        boolean boolean14 = unitType12.equals(obj13);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType12, 35.0d, (double) 100, 100.0d, (double) 10.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double22 = rectangleInsets20.calculateLeftOutset((double) '4');
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D24 = blockContainer23.getBounds();
        blockContainer23.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D28 = blockContainer27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D29 = blockContainer23.trimBorder(rectangle2D28);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets20.createInsetRectangle(rectangle2D28);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets19.createInsetRectangle(rectangle2D28);
        rectangleInsets9.trim(rectangle2D31);
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets4.createOutsetRectangle(rectangle2D31, false, false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test2008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2008");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 1.0f);
        double double5 = range4.getLength();
        double double6 = range4.getCentralValue();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1.0f);
        double double10 = range9.getLength();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = borderArrangement0.arrangeRR(blockContainer1, range4, range9, graphics2D11);
        java.lang.String str13 = size2D12.toString();
        double double14 = size2D12.getWidth();
        java.lang.String str15 = size2D12.toString();
        size2D12.height = 20.0d;
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str13, "Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str15, "Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test2009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2009");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 1.0f);
        double double4 = rectangleInsets0.trimWidth((double) 100);
        double double6 = rectangleInsets0.calculateBottomOutset((double) 100L);
        double double8 = rectangleInsets0.extendHeight((double) 1L);
        double double10 = rectangleInsets0.calculateRightOutset(7350.0d);
        double double11 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test2010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2010");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 1.0f);
        double double5 = range4.getLength();
        double double6 = range4.getCentralValue();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1.0f);
        double double10 = range9.getLength();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = borderArrangement0.arrangeRR(blockContainer1, range4, range9, graphics2D11);
        borderArrangement0.clear();
        borderArrangement0.clear();
        borderArrangement0.clear();
        borderArrangement0.clear();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test2011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2011");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 1.0f);
        double double5 = range4.getLength();
        double double6 = range4.getCentralValue();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1.0f);
        double double10 = range9.getLength();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = borderArrangement0.arrangeRR(blockContainer1, range4, range9, graphics2D11);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range4, (double) (short) 0);
        boolean boolean17 = range14.intersects(0.0d, (double) 10L);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D19 = blockContainer18.getBounds();
        blockContainer18.setWidth((double) (-1L));
        boolean boolean22 = range14.equals((java.lang.Object) (-1L));
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range14, 139.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test2012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2012");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(9.0d, 210.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight(299.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test2013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2013");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        java.awt.geom.Rectangle2D rectangle2D5 = blockContainer0.getBounds();
        boolean boolean6 = blockContainer0.isEmpty();
        blockContainer0.clear();
        double double9 = blockContainer0.trimToContentHeight(197.0d);
        blockContainer0.setID("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 197.0d + "'", double9 == 197.0d);
    }

    @Test
    public void test2014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2014");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer0.getMargin();
        double double6 = rectangleInsets4.calculateLeftInset(0.0d);
        double double8 = rectangleInsets4.extendHeight((double) (byte) 10);
        org.jfree.chart.block.BorderArrangement borderArrangement9 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj10 = null;
        boolean boolean11 = borderArrangement9.equals(obj10);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = borderArrangement9.arrangeNN(blockContainer12, graphics2D13);
        borderArrangement9.clear();
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D17 = blockContainer16.getBounds();
        blockContainer16.clear();
        blockContainer16.clear();
        blockContainer16.clear();
        java.lang.Object obj21 = null;
        borderArrangement9.add((org.jfree.chart.block.Block) blockContainer16, obj21);
        blockContainer16.setID("");
        java.awt.geom.Rectangle2D rectangle2D25 = blockContainer16.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double28 = rectangleInsets26.calculateRightInset((double) 1.0f);
        double double30 = rectangleInsets26.calculateRightOutset((double) 100L);
        double double32 = rectangleInsets26.trimHeight((double) 0);
        org.jfree.chart.block.EmptyBlock emptyBlock35 = new org.jfree.chart.block.EmptyBlock((double) 100L, (double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D36 = emptyBlock35.getBounds();
        rectangleInsets26.trim(rectangle2D36);
        java.awt.geom.Rectangle2D rectangle2D38 = blockContainer16.trimBorder(rectangle2D36);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets4.createInsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.util.UnitType unitType42 = rectangleInsets4.getUnitType();
        java.lang.String str43 = unitType42.toString();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "UnitType.ABSOLUTE" + "'", str43, "UnitType.ABSOLUTE");
    }

    @Test
    public void test2015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2015");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.jfree.data.Range range3 = rectangleConstraint0.getWidthRange();
        java.lang.String str4 = rectangleConstraint0.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2, "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str4, "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
    }

    @Test
    public void test2016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2016");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D8, rectangleConstraint9);
        double double11 = size2D10.width;
        org.jfree.chart.block.BlockBorder blockBorder16 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint17 = blockBorder16.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (-1.0d), 0.0d, (double) 0, paint17);
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(paint17);
        boolean boolean20 = size2D10.equals((java.lang.Object) blockBorder19);
        java.awt.Paint paint21 = blockBorder19.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder19.getInsets();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertNotNull(blockBorder16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test2017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2017");
        org.jfree.chart.block.AbstractBlock abstractBlock0 = new org.jfree.chart.block.AbstractBlock();
        double double2 = abstractBlock0.calculateTotalWidth((double) (-1));
        java.lang.String str3 = abstractBlock0.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock0.setPadding(rectangleInsets4);
        double double7 = rectangleInsets4.extendWidth((double) (short) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement9 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = null;
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude(range11, (double) 1.0f);
        double double14 = range13.getLength();
        double double15 = range13.getCentralValue();
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (double) 1.0f);
        double double19 = range18.getLength();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = borderArrangement9.arrangeRR(blockContainer10, range13, range18, graphics2D20);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range24 = null;
        org.jfree.data.Range range26 = org.jfree.data.Range.expandToInclude(range24, (double) 1.0f);
        boolean boolean29 = range26.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(0.0d, range13, lengthConstraintType22, (double) 100L, range26, lengthConstraintType30);
        org.jfree.data.Range range33 = org.jfree.data.Range.expandToInclude(range26, 0.0d);
        boolean boolean34 = rectangleInsets4.equals((java.lang.Object) range26);
        double double36 = rectangleInsets4.extendWidth(204.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 204.0d + "'", double36 == 204.0d);
    }

    @Test
    public void test2018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2018");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = borderArrangement0.equals(obj1);
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = borderArrangement0.arrangeNN(blockContainer3, graphics2D4);
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D8 = blockContainer7.getBounds();
        blockContainer7.clear();
        blockContainer7.clear();
        blockContainer7.clear();
        java.lang.Object obj12 = null;
        borderArrangement0.add((org.jfree.chart.block.Block) blockContainer7, obj12);
        borderArrangement0.clear();
        org.jfree.chart.block.BorderArrangement borderArrangement15 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement15.clear();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer17.getBounds();
        blockContainer17.clear();
        blockContainer17.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D27 = blockContainer17.arrange(graphics2D25, rectangleConstraint26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = blockContainer17.getMargin();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D31 = borderArrangement15.arrangeFN(blockContainer17, graphics2D29, (double) 1.0f);
        blockContainer17.setWidth(197.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = blockContainer17.getMargin();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement36 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer37 = null;
        org.jfree.data.Range range38 = null;
        org.jfree.data.Range range40 = org.jfree.data.Range.expandToInclude(range38, (double) 1.0f);
        double double41 = range40.getLength();
        double double42 = range40.getCentralValue();
        org.jfree.data.Range range43 = null;
        org.jfree.data.Range range45 = org.jfree.data.Range.expandToInclude(range43, (double) 1.0f);
        double double46 = range45.getLength();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.util.Size2D size2D48 = borderArrangement36.arrangeRR(blockContainer37, range40, range45, graphics2D47);
        org.jfree.data.Range range50 = org.jfree.data.Range.shift(range40, (double) (short) 0);
        double double51 = range50.getCentralValue();
        double double53 = range50.constrain(0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(range50, 65.0d);
        java.lang.String str56 = rectangleConstraint55.toString();
        double double57 = rectangleConstraint55.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = rectangleConstraint55.toUnconstrainedWidth();
        // The following exception was thrown during execution in test generation
        try {
            org.jfree.chart.util.Size2D size2D59 = borderArrangement0.arrangeFR(blockContainer17, graphics2D35, rectangleConstraint55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(size2D31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(size2D48);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertEquals("'" + str56 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=65.0]" + "'", str56, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=65.0]");
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 65.0d + "'", double57 == 65.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint58);
    }

    @Test
    public void test2019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2019");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 1.0f);
        double double5 = range4.getLength();
        double double6 = range4.getCentralValue();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1.0f);
        double double10 = range9.getLength();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = borderArrangement0.arrangeRR(blockContainer1, range4, range9, graphics2D11);
        borderArrangement0.clear();
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer15.getBounds();
        blockContainer15.clear();
        blockContainer15.clear();
        blockContainer15.clear();
        double double20 = blockContainer15.getContentYOffset();
        double double21 = blockContainer15.getContentXOffset();
        double double23 = blockContainer15.calculateTotalWidth((double) 10L);
        blockContainer15.clear();
        blockContainer15.clear();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D28 = borderArrangement0.arrangeFN(blockContainer15, graphics2D26, (double) 1L);
        java.awt.geom.Rectangle2D rectangle2D29 = blockContainer15.getBounds();
        java.lang.Object obj30 = blockContainer15.clone();
        blockContainer15.setPadding(0.5d, 0.0d, (double) 100, 110.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test2020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2020");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = borderArrangement0.equals(obj1);
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = borderArrangement0.arrangeNN(blockContainer3, graphics2D4);
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        java.awt.geom.Rectangle2D rectangle2D8 = blockContainer7.getBounds();
        double double9 = blockContainer7.getContentXOffset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test2021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2021");
        org.jfree.chart.block.BorderArrangement borderArrangement1 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range3, (double) 1.0f);
        double double6 = range5.getLength();
        double double7 = range5.getCentralValue();
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) 1.0f);
        double double11 = range10.getLength();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = borderArrangement1.arrangeRR(blockContainer2, range5, range10, graphics2D12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (double) 1.0f);
        boolean boolean21 = range18.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(0.0d, range5, lengthConstraintType14, (double) 100L, range18, lengthConstraintType22);
        java.lang.String str24 = lengthConstraintType14.toString();
        java.lang.String str25 = lengthConstraintType14.toString();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "LengthConstraintType.FIXED" + "'", str24, "LengthConstraintType.FIXED");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "LengthConstraintType.FIXED" + "'", str25, "LengthConstraintType.FIXED");
    }

    @Test
    public void test2022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2022");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 1.0f);
        double double4 = rectangleInsets0.calculateRightOutset((double) 100L);
        java.lang.String str5 = rectangleInsets0.toString();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets0.getUnitType();
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint8 = blockBorder7.getPaint();
        org.jfree.chart.block.BorderArrangement borderArrangement10 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer11 = null;
        org.jfree.data.Range range12 = null;
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range12, (double) 1.0f);
        double double15 = range14.getLength();
        double double16 = range14.getCentralValue();
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 1.0f);
        double double20 = range19.getLength();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = borderArrangement10.arrangeRR(blockContainer11, range14, range19, graphics2D21);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range25 = null;
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) 1.0f);
        boolean boolean30 = range27.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(0.0d, range14, lengthConstraintType23, (double) 100L, range27, lengthConstraintType31);
        boolean boolean33 = blockBorder7.equals((java.lang.Object) lengthConstraintType31);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = blockBorder7.getInsets();
        double double36 = rectangleInsets34.calculateBottomInset((double) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets37.calculateRightInset((double) 1.0f);
        double double41 = rectangleInsets37.calculateRightOutset((double) 100L);
        java.lang.String str42 = rectangleInsets37.toString();
        org.jfree.chart.block.BlockBorder blockBorder43 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = blockBorder43.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D46 = blockContainer45.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets44.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType47, lengthAdjustmentType48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean52 = rectangleEdge50.equals((java.lang.Object) 10L);
        java.lang.String str53 = rectangleEdge50.toString();
        double double54 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D46, rectangleEdge50);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets37.createOutsetRectangle(rectangle2D46, false, false);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets34.createInsetRectangle(rectangle2D46);
        double double60 = rectangleInsets34.calculateRightInset(0.0d);
        java.lang.Object obj61 = null;
        boolean boolean62 = rectangleInsets34.equals(obj61);
        org.jfree.chart.util.UnitType unitType63 = rectangleInsets34.getUnitType();
        java.lang.String str64 = unitType63.toString();
        java.lang.String str65 = unitType63.toString();
        boolean boolean66 = unitType6.equals((java.lang.Object) unitType63);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str5, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str42, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(blockBorder43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertEquals("'" + str53 + "' != '" + "RectangleEdge.RIGHT" + "'", str53, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(unitType63);
        org.junit.Assert.assertEquals("'" + str64 + "' != '" + "UnitType.ABSOLUTE" + "'", str64, "UnitType.ABSOLUTE");
        org.junit.Assert.assertEquals("'" + str65 + "' != '" + "UnitType.ABSOLUTE" + "'", str65, "UnitType.ABSOLUTE");
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test2023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2023");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(99.0d, 209.0d, 110.0d, 197.0d);
    }

    @Test
    public void test2024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2024");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D3 = blockContainer2.getBounds();
        blockContainer2.clear();
        blockContainer2.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D12 = blockContainer2.arrange(graphics2D10, rectangleConstraint11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockContainer2.getMargin();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D16 = borderArrangement0.arrangeFN(blockContainer2, graphics2D14, (double) 1.0f);
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D19 = blockContainer18.getBounds();
        blockContainer18.setID("RectangleConstraintType.RANGE");
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint23.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D25 = blockContainer18.arrange(graphics2D22, rectangleConstraint24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double28 = rectangleInsets26.calculateRightInset((double) 1.0f);
        double double30 = rectangleInsets26.trimWidth((double) 100);
        double double32 = rectangleInsets26.calculateBottomOutset((double) 100L);
        boolean boolean33 = blockContainer18.equals((java.lang.Object) rectangleInsets26);
        java.awt.geom.Rectangle2D rectangle2D34 = blockContainer18.getBounds();
        java.lang.String str35 = blockContainer18.getID();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double38 = rectangleConstraint37.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint37.toUnconstrainedHeight();
        java.lang.String str40 = rectangleConstraint39.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint39.toUnconstrainedHeight();
        double double42 = rectangleConstraint39.getHeight();
        // The following exception was thrown during execution in test generation
        try {
            org.jfree.chart.util.Size2D size2D43 = borderArrangement0.arrangeFR(blockContainer18, graphics2D36, rectangleConstraint39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "RectangleConstraintType.RANGE" + "'", str35, "RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(rectangleConstraint37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str40, "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(rectangleConstraint41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test2025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2025");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) 0, (double) 'a', (double) 100);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint6 = blockBorder5.getPaint();
        org.jfree.chart.block.BorderArrangement borderArrangement8 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 1.0f);
        double double13 = range12.getLength();
        double double14 = range12.getCentralValue();
        org.jfree.data.Range range15 = null;
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range15, (double) 1.0f);
        double double18 = range17.getLength();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = borderArrangement8.arrangeRR(blockContainer9, range12, range17, graphics2D19);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range23 = null;
        org.jfree.data.Range range25 = org.jfree.data.Range.expandToInclude(range23, (double) 1.0f);
        boolean boolean28 = range25.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(0.0d, range12, lengthConstraintType21, (double) 100L, range25, lengthConstraintType29);
        boolean boolean31 = blockBorder5.equals((java.lang.Object) lengthConstraintType29);
        java.awt.Paint paint32 = blockBorder5.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint32);
        double double35 = rectangleInsets4.calculateBottomInset(35.0d);
        double double37 = rectangleInsets4.extendHeight(55.0d);
        double double38 = rectangleInsets4.getBottom();
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 97.0d + "'", double35 == 97.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 204.0d + "'", double37 == 204.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 97.0d + "'", double38 == 97.0d);
    }

    @Test
    public void test2026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2026");
        org.jfree.chart.block.BlockBorder blockBorder4 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) (short) 0, (double) 'a', (double) (byte) 10, (double) 1, paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        java.awt.Paint paint8 = blockBorder6.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder6.getInsets();
        org.jfree.chart.block.AbstractBlock abstractBlock10 = new org.jfree.chart.block.AbstractBlock();
        double double12 = abstractBlock10.calculateTotalWidth((double) (-1));
        java.lang.String str13 = abstractBlock10.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock10.setPadding(rectangleInsets14);
        abstractBlock10.setHeight((double) 10);
        double double19 = abstractBlock10.trimToContentWidth(97.0d);
        abstractBlock10.setMargin((double) (short) 10, (double) (short) 100, 32.0d, 32.0d);
        org.jfree.chart.block.BlockBorder blockBorder25 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint26 = blockBorder25.getPaint();
        org.jfree.chart.block.BorderArrangement borderArrangement28 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer29 = null;
        org.jfree.data.Range range30 = null;
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range30, (double) 1.0f);
        double double33 = range32.getLength();
        double double34 = range32.getCentralValue();
        org.jfree.data.Range range35 = null;
        org.jfree.data.Range range37 = org.jfree.data.Range.expandToInclude(range35, (double) 1.0f);
        double double38 = range37.getLength();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.Size2D size2D40 = borderArrangement28.arrangeRR(blockContainer29, range32, range37, graphics2D39);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType41 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range43 = null;
        org.jfree.data.Range range45 = org.jfree.data.Range.expandToInclude(range43, (double) 1.0f);
        boolean boolean48 = range45.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType49 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(0.0d, range32, lengthConstraintType41, (double) 100L, range45, lengthConstraintType49);
        boolean boolean51 = blockBorder25.equals((java.lang.Object) lengthConstraintType49);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = blockBorder25.getInsets();
        double double54 = rectangleInsets52.calculateBottomInset((double) 10);
        double double56 = rectangleInsets52.calculateTopInset((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double59 = rectangleInsets57.calculateRightInset((double) 1.0f);
        double double61 = rectangleInsets57.trimWidth((double) 100);
        double double63 = rectangleInsets57.calculateBottomOutset((double) 100L);
        double double65 = rectangleInsets57.calculateRightOutset((double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer66 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D67 = blockContainer66.getBounds();
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets57.createOutsetRectangle(rectangle2D67);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType69 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = null;
        java.awt.geom.Rectangle2D rectangle2D71 = rectangleInsets52.createAdjustedRectangle(rectangle2D67, lengthAdjustmentType69, lengthAdjustmentType70);
        abstractBlock10.setBounds(rectangle2D67);
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets9.createInsetRectangle(rectangle2D67, true, false);
        double double76 = rectangleInsets9.getBottom();
        double double78 = rectangleInsets9.calculateBottomOutset((double) (byte) 100);
        org.junit.Assert.assertNotNull(blockBorder4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 97.0d + "'", double19 == 97.0d);
        org.junit.Assert.assertNotNull(blockBorder25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertNotNull(lengthConstraintType41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.0d + "'", double61 == 100.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 10.0d + "'", double76 == 10.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 10.0d + "'", double78 == 10.0d);
    }

    @Test
    public void test2027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2027");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockBorder blockBorder1 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(paint2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        boolean boolean5 = borderArrangement0.equals((java.lang.Object) blockBorder3);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BorderArrangement borderArrangement7 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) 1.0f);
        double double12 = range11.getLength();
        double double13 = range11.getCentralValue();
        org.jfree.data.Range range14 = null;
        org.jfree.data.Range range16 = org.jfree.data.Range.expandToInclude(range14, (double) 1.0f);
        double double17 = range16.getLength();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.Size2D size2D19 = borderArrangement7.arrangeRR(blockContainer8, range11, range16, graphics2D18);
        blockContainer6.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement7);
        java.lang.String str21 = blockContainer6.getID();
        java.awt.geom.Rectangle2D rectangle2D22 = blockContainer6.getBounds();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double24 = rectangleConstraint23.getWidth();
        org.jfree.data.Range range25 = rectangleConstraint23.getWidthRange();
        org.jfree.data.Range range26 = rectangleConstraint23.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint23.toUnconstrainedHeight();
        boolean boolean28 = blockContainer6.equals((java.lang.Object) rectangleConstraint23);
        java.lang.Object obj29 = null;
        borderArrangement0.add((org.jfree.chart.block.Block) blockContainer6, obj29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean33 = rectangleEdge31.equals((java.lang.Object) 10L);
        java.lang.String str34 = rectangleEdge31.toString();
        org.jfree.chart.block.BorderArrangement borderArrangement35 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj36 = null;
        boolean boolean37 = borderArrangement35.equals(obj36);
        org.jfree.chart.block.BlockContainer blockContainer38 = null;
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.Size2D size2D40 = borderArrangement35.arrangeNN(blockContainer38, graphics2D39);
        borderArrangement35.clear();
        boolean boolean42 = rectangleEdge31.equals((java.lang.Object) borderArrangement35);
        org.jfree.chart.block.BlockContainer blockContainer43 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D44 = blockContainer43.getBounds();
        blockContainer43.clear();
        java.lang.Object obj46 = null;
        borderArrangement35.add((org.jfree.chart.block.Block) blockContainer43, obj46);
        org.jfree.chart.block.BlockContainer blockContainer48 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement35);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean51 = rectangleEdge49.equals((java.lang.Object) 10L);
        boolean boolean52 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge49);
        boolean boolean53 = blockContainer48.equals((java.lang.Object) boolean52);
        double double54 = blockContainer48.getWidth();
        double double56 = blockContainer48.calculateTotalHeight((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = blockContainer48.getPadding();
        java.awt.Graphics2D graphics2D58 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.jfree.chart.util.Size2D size2D60 = borderArrangement0.arrangeFN(blockContainer48, graphics2D58, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(blockBorder1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "RectangleEdge.RIGHT" + "'", str34, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
    }

    @Test
    public void test2028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2028");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean2 = rectangleEdge0.equals((java.lang.Object) 10L);
        java.lang.String str3 = rectangleEdge0.toString();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj5 = null;
        boolean boolean6 = borderArrangement4.equals(obj5);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = borderArrangement4.arrangeNN(blockContainer7, graphics2D8);
        double double10 = size2D9.getWidth();
        boolean boolean11 = rectangleEdge0.equals((java.lang.Object) size2D9);
        size2D9.width = 108.0d;
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "RectangleEdge.RIGHT" + "'", str3, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test2029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2029");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 1.0f);
        double double5 = range4.getLength();
        double double6 = range4.getCentralValue();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1.0f);
        double double10 = range9.getLength();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = borderArrangement0.arrangeRR(blockContainer1, range4, range9, graphics2D11);
        java.lang.String str13 = size2D12.toString();
        double double14 = size2D12.height;
        double double15 = size2D12.getHeight();
        java.lang.String str16 = size2D12.toString();
        double double17 = size2D12.height;
        size2D12.setWidth(150.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str13, "Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str16, "Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test2030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2030");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 1.0f);
        double double5 = range4.getLength();
        double double6 = range4.getCentralValue();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1.0f);
        double double10 = range9.getLength();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = borderArrangement0.arrangeRR(blockContainer1, range4, range9, graphics2D11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range4, (double) (byte) -1);
        org.jfree.data.Range range17 = new org.jfree.data.Range(0.0d, 110.0d);
        org.jfree.data.Range range20 = org.jfree.data.Range.shift(range17, (double) (short) 1, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range4, range20);
        org.jfree.data.Range range23 = org.jfree.data.Range.shift(range20, 0.5d);
        double double24 = range23.getLength();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 110.0d + "'", double24 == 110.0d);
    }

    @Test
    public void test2031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2031");
        org.jfree.chart.block.EmptyBlock emptyBlock2 = new org.jfree.chart.block.EmptyBlock((double) (short) 100, (double) (short) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = emptyBlock2.getMargin();
        double double5 = rectangleInsets3.calculateLeftOutset(55.0d);
        double double7 = rectangleInsets3.calculateBottomOutset((double) 0L);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test2032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2032");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double6 = rectangleConstraint5.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = blockContainer0.toContentConstraint(rectangleConstraint5);
        java.lang.String str8 = blockContainer0.getID();
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) 1.0f);
        double double12 = range11.getLength();
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range11, (double) 1, (double) 10);
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (double) 1.0f);
        double double19 = range18.getLength();
        double double20 = range18.getLength();
        double double22 = range18.constrain(0.0d);
        boolean boolean24 = range18.contains((double) (short) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(range15, range18);
        boolean boolean26 = blockContainer0.equals((java.lang.Object) range18);
        org.jfree.data.Range range29 = org.jfree.data.Range.shift(range18, 98.0d, true);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test2033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2033");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer0.getMargin();
        java.lang.String str5 = blockContainer0.getID();
        blockContainer0.setPadding((double) 100.0f, (-1.0d), (double) (-1.0f), (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double13 = rectangleConstraint12.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint12.toUnconstrainedHeight();
        org.jfree.chart.block.BorderArrangement borderArrangement16 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer17 = null;
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude(range18, (double) 1.0f);
        double double21 = range20.getLength();
        double double22 = range20.getCentralValue();
        org.jfree.data.Range range23 = null;
        org.jfree.data.Range range25 = org.jfree.data.Range.expandToInclude(range23, (double) 1.0f);
        double double26 = range25.getLength();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = borderArrangement16.arrangeRR(blockContainer17, range20, range25, graphics2D27);
        org.jfree.data.Range range30 = org.jfree.data.Range.shift(range20, (double) (short) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = rectangleConstraint12.toRangeHeight(range20);
        org.jfree.data.Range range33 = org.jfree.data.Range.shift(range20, (double) (byte) -1);
        org.jfree.data.Range range36 = org.jfree.data.Range.expand(range20, (double) (short) -1, (double) (byte) 10);
        org.jfree.data.Range range38 = org.jfree.data.Range.expandToInclude(range36, (double) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint(0.0d, range38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = blockContainer0.toContentConstraint(rectangleConstraint39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = blockContainer0.arrange(graphics2D41);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertNotNull(size2D42);
    }

    @Test
    public void test2034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2034");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getWidth();
        org.jfree.data.Range range2 = rectangleConstraint0.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight(110.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedWidth();
        java.lang.String str6 = rectangleConstraint5.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint5.toFixedHeight((double) (-1));
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=110.0]" + "'", str6, "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=110.0]");
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test2035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2035");
        org.jfree.chart.block.AbstractBlock abstractBlock0 = new org.jfree.chart.block.AbstractBlock();
        double double2 = abstractBlock0.calculateTotalWidth((double) (-1));
        java.lang.String str3 = abstractBlock0.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock0.setPadding(rectangleInsets4);
        double double7 = rectangleInsets4.calculateRightOutset((double) (-1L));
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets4.getUnitType();
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D();
        boolean boolean10 = unitType8.equals((java.lang.Object) size2D9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 0L, (double) (-1.0f), (double) 0, 0.0d);
        java.lang.String str16 = rectangleInsets15.toString();
        double double18 = rectangleInsets15.trimHeight(0.0d);
        double double20 = rectangleInsets15.calculateTopInset((double) 1L);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D22 = blockContainer21.getBounds();
        blockContainer21.clear();
        blockContainer21.clear();
        blockContainer21.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double27 = rectangleConstraint26.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = blockContainer21.toContentConstraint(rectangleConstraint26);
        blockContainer21.clear();
        blockContainer21.setPadding((double) 1, 100.0d, (double) (byte) 1, (double) (-1L));
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint36.toFixedWidth((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint38.toFixedWidth((double) 10.0f);
        org.jfree.chart.util.Size2D size2D41 = blockContainer21.arrange(graphics2D35, rectangleConstraint40);
        org.jfree.chart.block.BlockFrame blockFrame42 = blockContainer21.getFrame();
        java.awt.geom.Rectangle2D rectangle2D43 = blockContainer21.getBounds();
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets15.createInsetRectangle(rectangle2D43, true, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean49 = rectangleEdge47.equals((java.lang.Object) 10L);
        java.lang.String str50 = rectangleEdge47.toString();
        org.jfree.chart.block.EmptyBlock emptyBlock53 = new org.jfree.chart.block.EmptyBlock((double) 100L, (double) (short) 10);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double56 = rectangleConstraint55.getWidth();
        org.jfree.data.Range range57 = rectangleConstraint55.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = rectangleConstraint55.toFixedHeight(110.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = rectangleConstraint55.toFixedWidth((double) 100.0f);
        org.jfree.data.Range range62 = rectangleConstraint61.getHeightRange();
        org.jfree.chart.util.Size2D size2D63 = emptyBlock53.arrange(graphics2D54, rectangleConstraint61);
        double double64 = size2D63.getWidth();
        boolean boolean65 = rectangleEdge47.equals((java.lang.Object) double64);
        double double66 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D43, rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "RectangleInsets[t=0.0,l=-1.0,b=0.0,r=0.0]" + "'", str16, "RectangleInsets[t=0.0,l=-1.0,b=0.0,r=0.0]");
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertNotNull(size2D41);
        org.junit.Assert.assertNotNull(blockFrame42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "RectangleEdge.RIGHT" + "'", str50, "RectangleEdge.RIGHT");
        org.junit.Assert.assertNotNull(rectangleConstraint55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNotNull(rectangleConstraint59);
        org.junit.Assert.assertNotNull(rectangleConstraint61);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertNotNull(size2D63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 100.0d + "'", double64 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test2036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2036");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.setID("RectangleConstraintType.RANGE");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D4, rectangleConstraint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets8.calculateRightInset((double) 1.0f);
        double double12 = rectangleInsets8.calculateRightOutset((double) 100L);
        java.lang.String str13 = rectangleInsets8.toString();
        org.jfree.chart.block.BlockBorder blockBorder14 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockBorder14.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D17 = blockContainer16.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets15.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType18, lengthAdjustmentType19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean23 = rectangleEdge21.equals((java.lang.Object) 10L);
        java.lang.String str24 = rectangleEdge21.toString();
        double double25 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D17, rectangleEdge21);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets8.createOutsetRectangle(rectangle2D17, false, false);
        blockContainer0.setBounds(rectangle2D17);
        java.lang.Object obj30 = blockContainer0.clone();
        blockContainer0.setID("hi!");
        java.util.List list33 = blockContainer0.getBlocks();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str13, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(blockBorder14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "RectangleEdge.RIGHT" + "'", str24, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test2037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2037");
        org.jfree.chart.block.AbstractBlock abstractBlock0 = new org.jfree.chart.block.AbstractBlock();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = abstractBlock0.getMargin();
        double double3 = rectangleInsets1.calculateRightOutset((double) (byte) 0);
        double double5 = rectangleInsets1.calculateLeftInset((double) 10L);
        double double6 = rectangleInsets1.getBottom();
        double double8 = rectangleInsets1.trimWidth((double) '#');
        double double10 = rectangleInsets1.calculateTopOutset((double) '#');
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets1.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType11, 2.1346153846153846d, 10.0d, 12.0d, (double) (byte) -1);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(unitType11);
    }

    @Test
    public void test2038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2038");
        org.jfree.chart.block.BorderArrangement borderArrangement1 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range3, (double) 1.0f);
        double double6 = range5.getLength();
        double double7 = range5.getCentralValue();
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) 1.0f);
        double double11 = range10.getLength();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = borderArrangement1.arrangeRR(blockContainer2, range5, range10, graphics2D12);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range5, (double) (short) 0);
        boolean boolean18 = range15.intersects((double) (-1L), (double) 10L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(0.0d, range15);
        java.lang.String str20 = range15.toString();
        org.jfree.data.Range range22 = org.jfree.data.Range.shift(range15, 299.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "Range[1.0,1.0]" + "'", str20, "Range[1.0,1.0]");
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test2039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2039");
        org.jfree.chart.block.EmptyBlock emptyBlock2 = new org.jfree.chart.block.EmptyBlock(0.03125d, 99.0d);
    }

    @Test
    public void test2040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2040");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        java.lang.String str5 = blockContainer0.getID();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D6);
        double double9 = blockContainer0.calculateTotalWidth((double) (byte) 0);
        double double10 = blockContainer0.getHeight();
        double double12 = blockContainer0.calculateTotalHeight(5.5d);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 5.5d + "'", double12 == 5.5d);
    }

    @Test
    public void test2041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2041");
        org.jfree.chart.block.AbstractBlock abstractBlock0 = new org.jfree.chart.block.AbstractBlock();
        double double2 = abstractBlock0.calculateTotalWidth((double) (-1));
        java.lang.String str3 = abstractBlock0.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock0.setPadding(rectangleInsets4);
        abstractBlock0.setHeight((double) 10);
        org.jfree.chart.block.BorderArrangement borderArrangement8 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 1.0f);
        double double13 = range12.getLength();
        double double14 = range12.getCentralValue();
        org.jfree.data.Range range15 = null;
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range15, (double) 1.0f);
        double double18 = range17.getLength();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = borderArrangement8.arrangeRR(blockContainer9, range12, range17, graphics2D19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range12, (double) (byte) -1);
        org.jfree.data.Range range25 = new org.jfree.data.Range(0.0d, 110.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.shift(range25, (double) (short) 1, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range12, range28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = abstractBlock0.toContentConstraint(rectangleConstraint29);
        abstractBlock0.setMargin((double) 10L, 0.0d, (double) 1.0f, (double) (byte) 0);
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 0L, 1.0d);
        abstractBlock0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder40);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
    }

    @Test
    public void test2042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2042");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 100, (double) 1L, (double) (short) 100, 0.0d);
        double double5 = rectangleInsets4.getTop();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D7 = blockContainer6.getBounds();
        blockContainer6.clear();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) 0, (double) 'a', (double) 100);
        org.jfree.chart.block.BlockBorder blockBorder14 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint15 = blockBorder14.getPaint();
        org.jfree.chart.block.BorderArrangement borderArrangement17 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer18 = null;
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (double) 1.0f);
        double double22 = range21.getLength();
        double double23 = range21.getCentralValue();
        org.jfree.data.Range range24 = null;
        org.jfree.data.Range range26 = org.jfree.data.Range.expandToInclude(range24, (double) 1.0f);
        double double27 = range26.getLength();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = borderArrangement17.arrangeRR(blockContainer18, range21, range26, graphics2D28);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range32 = null;
        org.jfree.data.Range range34 = org.jfree.data.Range.expandToInclude(range32, (double) 1.0f);
        boolean boolean37 = range34.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType38 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint(0.0d, range21, lengthConstraintType30, (double) 100L, range34, lengthConstraintType38);
        boolean boolean40 = blockBorder14.equals((java.lang.Object) lengthConstraintType38);
        java.awt.Paint paint41 = blockBorder14.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder(rectangleInsets13, paint41);
        blockContainer6.setMargin(rectangleInsets13);
        double double44 = rectangleInsets13.getTop();
        org.jfree.chart.util.UnitType unitType45 = rectangleInsets13.getUnitType();
        org.jfree.chart.block.AbstractBlock abstractBlock46 = new org.jfree.chart.block.AbstractBlock();
        double double48 = abstractBlock46.calculateTotalWidth((double) (-1));
        java.lang.String str49 = abstractBlock46.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock46.setPadding(rectangleInsets50);
        double double52 = rectangleInsets50.getTop();
        double double53 = rectangleInsets50.getRight();
        org.jfree.chart.util.UnitType unitType54 = rectangleInsets50.getUnitType();
        org.jfree.chart.block.EmptyBlock emptyBlock57 = new org.jfree.chart.block.EmptyBlock(9.0d, (double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D58 = emptyBlock57.getBounds();
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets50.createInsetRectangle(rectangle2D58);
        rectangleInsets13.trim(rectangle2D59);
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets4.createOutsetRectangle(rectangle2D59);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(blockBorder14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 52.0d + "'", double44 == 52.0d);
        org.junit.Assert.assertNotNull(unitType45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-1.0d) + "'", double48 == (-1.0d));
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(unitType54);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test2043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2043");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        java.util.List list9 = blockContainer8.getBlocks();
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer8);
        blockContainer8.setID("Size2D[width=-1.0, height=110.0]");
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test2044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2044");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean2 = rectangleEdge0.equals((java.lang.Object) 10L);
        java.lang.String str3 = rectangleEdge0.toString();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj5 = null;
        boolean boolean6 = borderArrangement4.equals(obj5);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = borderArrangement4.arrangeNN(blockContainer7, graphics2D8);
        borderArrangement4.clear();
        boolean boolean11 = rectangleEdge0.equals((java.lang.Object) borderArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D13 = blockContainer12.getBounds();
        blockContainer12.clear();
        java.lang.Object obj15 = null;
        borderArrangement4.add((org.jfree.chart.block.Block) blockContainer12, obj15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = blockContainer12.arrange(graphics2D17);
        size2D18.width = (byte) 100;
        size2D18.height = 100.0f;
        size2D18.width = 3.0d;
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "RectangleEdge.RIGHT" + "'", str3, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(size2D18);
    }

    @Test
    public void test2045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2045");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.setID("RectangleConstraintType.RANGE");
        java.lang.String str4 = blockContainer0.getID();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "RectangleConstraintType.RANGE" + "'", str4, "RectangleConstraintType.RANGE");
    }

    @Test
    public void test2046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2046");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        java.lang.String str5 = blockContainer0.getID();
        java.lang.String str6 = blockContainer0.getID();
        double double7 = blockContainer0.getWidth();
        double double9 = blockContainer0.trimToContentWidth((double) 1.0f);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Object obj12 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = blockContainer0.draw(graphics2D10, rectangle2D11, obj12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test2047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2047");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        java.lang.String str5 = blockContainer0.getID();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D6);
        double double8 = blockContainer0.getContentXOffset();
        java.util.List list9 = blockContainer0.getBlocks();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test2048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2048");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        double double4 = blockContainer0.trimToContentHeight(150.0d);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 150.0d + "'", double4 == 150.0d);
    }

    @Test
    public void test2049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2049");
        org.jfree.chart.block.AbstractBlock abstractBlock0 = new org.jfree.chart.block.AbstractBlock();
        double double2 = abstractBlock0.calculateTotalWidth((double) (-1));
        java.lang.String str3 = abstractBlock0.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock0.setPadding(rectangleInsets4);
        abstractBlock0.setHeight((double) 10);
        org.jfree.chart.block.BorderArrangement borderArrangement8 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 1.0f);
        double double13 = range12.getLength();
        double double14 = range12.getCentralValue();
        org.jfree.data.Range range15 = null;
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range15, (double) 1.0f);
        double double18 = range17.getLength();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = borderArrangement8.arrangeRR(blockContainer9, range12, range17, graphics2D19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range12, (double) (byte) -1);
        org.jfree.data.Range range25 = new org.jfree.data.Range(0.0d, 110.0d);
        org.jfree.data.Range range28 = org.jfree.data.Range.shift(range25, (double) (short) 1, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range12, range28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = abstractBlock0.toContentConstraint(rectangleConstraint29);
        org.jfree.data.Range range31 = rectangleConstraint30.getWidthRange();
        double double32 = rectangleConstraint30.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = rectangleConstraint30.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint30.toFixedWidth((double) 1.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = rectangleConstraint30.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
    }

    @Test
    public void test2050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2050");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 0, (double) (short) 0, (double) 'a', (-90.0d));
    }

    @Test
    public void test2051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2051");
        org.jfree.chart.block.EmptyBlock emptyBlock2 = new org.jfree.chart.block.EmptyBlock((double) (short) 100, (double) (short) 1);
        java.lang.String str3 = emptyBlock2.getID();
        double double5 = emptyBlock2.calculateTotalHeight(35.0d);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D7 = blockContainer6.getBounds();
        blockContainer6.clear();
        blockContainer6.clear();
        blockContainer6.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double12 = rectangleConstraint11.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = blockContainer6.toContentConstraint(rectangleConstraint11);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint11.getWidthConstraintType();
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 1.0f);
        double double20 = range19.getLength();
        double double21 = range19.getLength();
        org.jfree.chart.block.BorderArrangement borderArrangement23 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer24 = null;
        org.jfree.data.Range range25 = null;
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) 1.0f);
        double double28 = range27.getLength();
        double double29 = range27.getCentralValue();
        org.jfree.data.Range range30 = null;
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range30, (double) 1.0f);
        double double33 = range32.getLength();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D35 = borderArrangement23.arrangeRR(blockContainer24, range27, range32, graphics2D34);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range38 = null;
        org.jfree.data.Range range40 = org.jfree.data.Range.expandToInclude(range38, (double) 1.0f);
        boolean boolean43 = range40.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType44 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint(0.0d, range27, lengthConstraintType36, (double) 100L, range40, lengthConstraintType44);
        java.lang.String str46 = lengthConstraintType44.toString();
        org.jfree.data.Range range48 = null;
        org.jfree.data.Range range50 = org.jfree.data.Range.expandToInclude(range48, (double) 1.0f);
        double double51 = range50.getLength();
        org.jfree.data.Range range54 = org.jfree.data.Range.expand(range50, (double) 1, (double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = rectangleConstraint55.toFixedWidth((double) 10.0f);
        double double58 = rectangleConstraint55.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = rectangleConstraint55.toFixedWidth(0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType61 = rectangleConstraint60.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = new org.jfree.chart.block.RectangleConstraint(0.0d, range19, lengthConstraintType44, 110.0d, range50, lengthConstraintType61);
        org.jfree.data.Range range64 = org.jfree.data.Range.expandToInclude(range50, 0.0d);
        org.jfree.data.Range range65 = null;
        org.jfree.data.Range range67 = org.jfree.data.Range.expandToInclude(range65, (double) (short) 100);
        double double68 = range67.getLowerBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double71 = rectangleInsets69.calculateRightInset((double) 1.0f);
        double double73 = rectangleInsets69.trimWidth((double) 100);
        double double75 = rectangleInsets69.calculateBottomOutset((double) 100L);
        double double77 = rectangleInsets69.calculateRightOutset((double) 'a');
        boolean boolean78 = range67.equals((java.lang.Object) rectangleInsets69);
        org.jfree.data.Range range79 = org.jfree.data.Range.combine(range50, range67);
        org.jfree.data.Range range81 = org.jfree.data.Range.shift(range67, 97.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint82 = new org.jfree.chart.block.RectangleConstraint((double) 1, range81);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint83 = rectangleConstraint11.toRangeHeight(range81);
        boolean boolean84 = emptyBlock2.equals((java.lang.Object) rectangleConstraint11);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType44);
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "RectangleConstraintType.RANGE" + "'", str46, "RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(rectangleConstraint55);
        org.junit.Assert.assertNotNull(rectangleConstraint57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint60);
        org.junit.Assert.assertNotNull(lengthConstraintType61);
        org.junit.Assert.assertNotNull(range64);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.0d + "'", double68 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 100.0d + "'", double73 == 100.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertNotNull(range81);
        org.junit.Assert.assertNotNull(rectangleConstraint83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test2052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2052");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double6 = rectangleConstraint5.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = blockContainer0.toContentConstraint(rectangleConstraint5);
        blockContainer0.clear();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = blockContainer9.arrange(graphics2D10);
        blockContainer9.setID("Range[1.0,1.0]");
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer9);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BorderArrangement borderArrangement17 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer18 = null;
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (double) 1.0f);
        double double22 = range21.getLength();
        double double23 = range21.getCentralValue();
        org.jfree.data.Range range24 = null;
        org.jfree.data.Range range26 = org.jfree.data.Range.expandToInclude(range24, (double) 1.0f);
        double double27 = range26.getLength();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = borderArrangement17.arrangeRR(blockContainer18, range21, range26, graphics2D28);
        blockContainer16.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement17);
        java.lang.String str31 = blockContainer16.getID();
        java.lang.Object obj32 = blockContainer16.clone();
        blockContainer16.setHeight((double) (byte) 1);
        double double35 = blockContainer16.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D37 = blockContainer36.getBounds();
        blockContainer36.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = blockContainer36.getMargin();
        blockContainer36.setHeight(35.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = blockContainer36.getPadding();
        org.jfree.chart.block.EmptyBlock emptyBlock46 = new org.jfree.chart.block.EmptyBlock((double) 100L, (double) (short) 10);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double49 = rectangleConstraint48.getWidth();
        org.jfree.data.Range range50 = rectangleConstraint48.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = rectangleConstraint48.toFixedHeight(110.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = rectangleConstraint48.toFixedWidth((double) 100.0f);
        org.jfree.data.Range range55 = rectangleConstraint54.getHeightRange();
        org.jfree.chart.util.Size2D size2D56 = emptyBlock46.arrange(graphics2D47, rectangleConstraint54);
        java.awt.geom.Rectangle2D rectangle2D57 = emptyBlock46.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets43.createAdjustedRectangle(rectangle2D57, lengthAdjustmentType58, lengthAdjustmentType59);
        java.awt.geom.Rectangle2D rectangle2D61 = blockContainer16.trimMargin(rectangle2D57);
        // The following exception was thrown during execution in test generation
        try {
            blockContainer0.draw(graphics2D15, rectangle2D61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(rectangleConstraint52);
        org.junit.Assert.assertNotNull(rectangleConstraint54);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test2053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2053");
        org.jfree.chart.block.AbstractBlock abstractBlock0 = new org.jfree.chart.block.AbstractBlock();
        double double2 = abstractBlock0.calculateTotalWidth((double) (-1));
        java.lang.String str3 = abstractBlock0.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock0.setPadding(rectangleInsets4);
        double double6 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.getRight();
        double double9 = rectangleInsets4.calculateLeftOutset(0.0d);
        double double11 = rectangleInsets4.calculateBottomOutset(35.0d);
        double double13 = rectangleInsets4.calculateRightOutset((double) (byte) -1);
        double double14 = rectangleInsets4.getBottom();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) 0, (double) 'a', (double) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement20 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj21 = null;
        boolean boolean22 = borderArrangement20.equals(obj21);
        org.jfree.chart.block.BlockContainer blockContainer23 = null;
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = borderArrangement20.arrangeNN(blockContainer23, graphics2D24);
        borderArrangement20.clear();
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D28 = blockContainer27.getBounds();
        blockContainer27.clear();
        blockContainer27.clear();
        blockContainer27.clear();
        java.lang.Object obj32 = null;
        borderArrangement20.add((org.jfree.chart.block.Block) blockContainer27, obj32);
        blockContainer27.setID("");
        java.awt.geom.Rectangle2D rectangle2D36 = blockContainer27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets19.createOutsetRectangle(rectangle2D36);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets4.createAdjustedRectangle(rectangle2D36, lengthAdjustmentType38, lengthAdjustmentType39);
        double double42 = rectangleInsets4.calculateLeftOutset(0.0d);
        double double44 = rectangleInsets4.calculateBottomOutset(137.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test2054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2054");
        org.jfree.chart.block.EmptyBlock emptyBlock2 = new org.jfree.chart.block.EmptyBlock((-32.0d), (-100.0d));
        java.lang.Object obj3 = emptyBlock2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test2055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2055");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 1.0f);
        double double9 = range8.getLength();
        double double10 = range8.getCentralValue();
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude(range11, (double) 1.0f);
        double double14 = range13.getLength();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.Size2D size2D16 = borderArrangement4.arrangeRR(blockContainer5, range8, range13, graphics2D15);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement4);
        org.jfree.chart.block.Arrangement arrangement18 = blockContainer0.getArrangement();
        arrangement18.clear();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(arrangement18);
    }

    @Test
    public void test2056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2056");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean2 = rectangleEdge0.equals((java.lang.Object) 10L);
        java.lang.String str3 = rectangleEdge0.toString();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj5 = null;
        boolean boolean6 = borderArrangement4.equals(obj5);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = borderArrangement4.arrangeNN(blockContainer7, graphics2D8);
        borderArrangement4.clear();
        boolean boolean11 = rectangleEdge0.equals((java.lang.Object) borderArrangement4);
        boolean boolean12 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "RectangleEdge.RIGHT" + "'", str3, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test2057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2057");
        org.jfree.data.Range range3 = new org.jfree.data.Range((double) (byte) 1, 10.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedWidth((double) 10.0f);
        double double7 = rectangleConstraint4.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint4.toFixedWidth(0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = rectangleConstraint9.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint12.toUnconstrainedWidth();
        org.jfree.chart.block.BorderArrangement borderArrangement14 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer15 = null;
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (double) 1.0f);
        double double19 = range18.getLength();
        double double20 = range18.getCentralValue();
        org.jfree.data.Range range21 = null;
        org.jfree.data.Range range23 = org.jfree.data.Range.expandToInclude(range21, (double) 1.0f);
        double double24 = range23.getLength();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.util.Size2D size2D26 = borderArrangement14.arrangeRR(blockContainer15, range18, range23, graphics2D25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint(range18, (double) (byte) -1);
        double double29 = range18.getLength();
        double double30 = range18.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = rectangleConstraint12.toRangeWidth(range18);
        double double33 = range18.constrain((-1.0d));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint(0.0d, range3, lengthConstraintType10, (double) (byte) 100, range18, lengthConstraintType34);
        java.lang.String str36 = range3.toString();
        org.jfree.data.Range range38 = org.jfree.data.Range.expandToInclude(range3, 90.0d);
        double double39 = range3.getCentralValue();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "Range[1.0,10.0]" + "'", str36, "Range[1.0,10.0]");
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 5.5d + "'", double39 == 5.5d);
    }

    @Test
    public void test2058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2058");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        double double5 = blockContainer0.getContentYOffset();
        double double6 = blockContainer0.getContentXOffset();
        double double7 = blockContainer0.getHeight();
        double double8 = blockContainer0.getContentYOffset();
        org.jfree.chart.block.BlockFrame blockFrame9 = blockContainer0.getFrame();
        blockContainer0.clear();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame9);
    }

    @Test
    public void test2059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2059");
        org.jfree.chart.block.EmptyBlock emptyBlock2 = new org.jfree.chart.block.EmptyBlock((double) (byte) 0, (double) (short) -1);
        emptyBlock2.setPadding(108.0d, 32.0d, 100.0d, 0.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.UnitType unitType9 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) (byte) 1, 0.0d, (double) ' ', (double) '#');
        double double16 = rectangleInsets14.calculateTopOutset((-1.0d));
        double double17 = rectangleInsets14.getBottom();
        double double19 = rectangleInsets14.calculateTopInset((double) (short) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement20 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj21 = null;
        boolean boolean22 = borderArrangement20.equals(obj21);
        org.jfree.chart.block.BlockContainer blockContainer23 = null;
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = borderArrangement20.arrangeNN(blockContainer23, graphics2D24);
        borderArrangement20.clear();
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D28 = blockContainer27.getBounds();
        blockContainer27.clear();
        blockContainer27.clear();
        blockContainer27.clear();
        java.lang.Object obj32 = null;
        borderArrangement20.add((org.jfree.chart.block.Block) blockContainer27, obj32);
        blockContainer27.setID("");
        java.awt.geom.Rectangle2D rectangle2D36 = blockContainer27.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets37.calculateRightInset((double) 1.0f);
        double double41 = rectangleInsets37.calculateRightOutset((double) 100L);
        double double43 = rectangleInsets37.trimHeight((double) 0);
        org.jfree.chart.block.EmptyBlock emptyBlock46 = new org.jfree.chart.block.EmptyBlock((double) 100L, (double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D47 = emptyBlock46.getBounds();
        rectangleInsets37.trim(rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D49 = blockContainer27.trimBorder(rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets14.createOutsetRectangle(rectangle2D47);
        // The following exception was thrown during execution in test generation
        try {
            emptyBlock2.draw(graphics2D8, rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.03125d + "'", double16 == 0.03125d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 32.0d + "'", double17 == 32.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test2060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2060");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (short) 100);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 1.0f);
        double double9 = range8.getLength();
        double double10 = range8.getCentralValue();
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude(range11, (double) 1.0f);
        double double14 = range13.getLength();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.Size2D size2D16 = borderArrangement4.arrangeRR(blockContainer5, range8, range13, graphics2D15);
        blockContainer3.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement4);
        org.jfree.chart.block.BlockBorder blockBorder18 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint19 = blockBorder18.getPaint();
        java.lang.Object obj20 = null;
        boolean boolean21 = blockBorder18.equals(obj20);
        java.awt.Paint paint22 = blockBorder18.getPaint();
        boolean boolean23 = borderArrangement4.equals((java.lang.Object) blockBorder18);
        boolean boolean24 = range2.equals((java.lang.Object) boolean23);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(blockBorder18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test2061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2061");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.jfree.chart.block.BorderArrangement borderArrangement3 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) 1.0f);
        double double8 = range7.getLength();
        double double9 = range7.getCentralValue();
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 1.0f);
        double double13 = range12.getLength();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = borderArrangement3.arrangeRR(blockContainer4, range7, range12, graphics2D14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude(range18, (double) 1.0f);
        boolean boolean23 = range20.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(0.0d, range7, lengthConstraintType16, (double) 100L, range20, lengthConstraintType24);
        boolean boolean26 = blockBorder0.equals((java.lang.Object) lengthConstraintType24);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = blockBorder0.getInsets();
        double double29 = rectangleInsets27.calculateBottomOutset((double) 1L);
        double double31 = rectangleInsets27.trimHeight(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double34 = rectangleInsets32.calculateRightInset((double) 1.0f);
        double double36 = rectangleInsets32.calculateBottomOutset((double) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets37.calculateRightInset((double) 1.0f);
        double double41 = rectangleInsets37.calculateRightOutset((double) 100L);
        java.lang.String str42 = rectangleInsets37.toString();
        org.jfree.chart.block.BlockBorder blockBorder43 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = blockBorder43.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D46 = blockContainer45.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets44.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType47, lengthAdjustmentType48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean52 = rectangleEdge50.equals((java.lang.Object) 10L);
        java.lang.String str53 = rectangleEdge50.toString();
        double double54 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D46, rectangleEdge50);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets37.createOutsetRectangle(rectangle2D46, false, false);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets32.createInsetRectangle(rectangle2D57);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets27.createAdjustedRectangle(rectangle2D57, lengthAdjustmentType59, lengthAdjustmentType60);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str42, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertNotNull(blockBorder43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertEquals("'" + str53 + "' != '" + "RectangleEdge.RIGHT" + "'", str53, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test2062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2062");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.BorderArrangement borderArrangement2 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) 1.0f);
        double double7 = range6.getLength();
        double double8 = range6.getCentralValue();
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) 1.0f);
        double double12 = range11.getLength();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = borderArrangement2.arrangeRR(blockContainer3, range6, range11, graphics2D13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range6, (double) (byte) -1);
        double double17 = range6.getLength();
        double double18 = range6.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint0.toRangeWidth(range6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint19.toUnconstrainedHeight();
        double double21 = rectangleConstraint20.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test2063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2063");
        org.jfree.chart.block.EmptyBlock emptyBlock2 = new org.jfree.chart.block.EmptyBlock((double) (short) 100, (double) (short) 1);
        double double3 = emptyBlock2.getWidth();
        java.awt.geom.Rectangle2D rectangle2D4 = emptyBlock2.getBounds();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D7 = blockContainer6.getBounds();
        blockContainer6.clear();
        blockContainer6.clear();
        blockContainer6.clear();
        double double11 = blockContainer6.getContentYOffset();
        double double12 = blockContainer6.getContentXOffset();
        double double14 = blockContainer6.calculateTotalWidth((double) 10L);
        blockContainer6.clear();
        java.lang.String str16 = blockContainer6.getID();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth((double) 10.0f);
        double double21 = rectangleConstraint18.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint18.toFixedWidth(0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = rectangleConstraint23.getWidthConstraintType();
        org.jfree.chart.util.Size2D size2D25 = blockContainer6.arrange(graphics2D17, rectangleConstraint23);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType26 = rectangleConstraint23.getWidthConstraintType();
        org.jfree.data.Range range27 = rectangleConstraint23.getWidthRange();
        org.jfree.chart.util.Size2D size2D28 = emptyBlock2.arrange(graphics2D5, rectangleConstraint23);
        double double29 = emptyBlock2.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(lengthConstraintType26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test2064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2064");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.setID("RectangleConstraintType.RANGE");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D4, rectangleConstraint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets8.calculateRightInset((double) 1.0f);
        double double12 = rectangleInsets8.trimWidth((double) 100);
        double double14 = rectangleInsets8.calculateBottomOutset((double) 100L);
        boolean boolean15 = blockContainer0.equals((java.lang.Object) rectangleInsets8);
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer0.getBounds();
        java.lang.String str17 = blockContainer0.getID();
        java.lang.String str18 = blockContainer0.getID();
        java.awt.geom.Rectangle2D rectangle2D19 = blockContainer0.getBounds();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "RectangleConstraintType.RANGE" + "'", str17, "RectangleConstraintType.RANGE");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "RectangleConstraintType.RANGE" + "'", str18, "RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test2065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2065");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) '4');
        java.lang.String str3 = rectangleInsets0.toString();
        double double4 = rectangleInsets0.getLeft();
        double double6 = rectangleInsets0.calculateLeftOutset((double) 10L);
        double double8 = rectangleInsets0.extendWidth((double) ' ');
        double double10 = rectangleInsets0.calculateRightOutset((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test2066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2066");
        org.jfree.chart.block.EmptyBlock emptyBlock2 = new org.jfree.chart.block.EmptyBlock((double) (byte) 0, (double) (short) 10);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = emptyBlock2.arrange(graphics2D3);
        java.lang.String str5 = emptyBlock2.getID();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D8 = blockContainer7.getBounds();
        blockContainer7.clear();
        blockContainer7.clear();
        blockContainer7.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double13 = rectangleConstraint12.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = blockContainer7.toContentConstraint(rectangleConstraint12);
        blockContainer7.clear();
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = blockContainer16.arrange(graphics2D17);
        blockContainer16.setID("Range[1.0,1.0]");
        blockContainer7.add((org.jfree.chart.block.Block) blockContainer16);
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D23 = blockContainer22.getBounds();
        blockContainer22.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockContainer22.getMargin();
        org.jfree.chart.block.AbstractBlock abstractBlock27 = new org.jfree.chart.block.AbstractBlock();
        double double29 = abstractBlock27.calculateTotalWidth((double) (-1));
        java.lang.String str30 = abstractBlock27.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock27.setPadding(rectangleInsets31);
        abstractBlock27.setHeight((double) 10);
        org.jfree.chart.block.BlockBorder blockBorder35 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = blockBorder35.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D38 = blockContainer37.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets36.createAdjustedRectangle(rectangle2D38, lengthAdjustmentType39, lengthAdjustmentType40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean44 = rectangleEdge42.equals((java.lang.Object) 10L);
        java.lang.String str45 = rectangleEdge42.toString();
        double double46 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D38, rectangleEdge42);
        java.awt.geom.Rectangle2D rectangle2D47 = abstractBlock27.trimPadding(rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets26.createOutsetRectangle(rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D49 = blockContainer7.trimBorder(rectangle2D48);
        // The following exception was thrown during execution in test generation
        try {
            emptyBlock2.draw(graphics2D6, rectangle2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-1.0d) + "'", double29 == (-1.0d));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(blockBorder35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "RectangleEdge.RIGHT" + "'", str45, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D49);
    }

    @Test
    public void test2067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2067");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.setID("RectangleConstraintType.RANGE");
        double double4 = blockContainer0.getWidth();
        blockContainer0.clear();
        double double6 = blockContainer0.getContentYOffset();
        org.jfree.chart.block.Arrangement arrangement7 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(arrangement7);
    }

    @Test
    public void test2068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2068");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockContainer0.getMargin();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = blockContainer0.arrange(graphics2D5);
        double double7 = size2D6.width;
        java.lang.Object obj8 = null;
        boolean boolean9 = size2D6.equals(obj8);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test2069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2069");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double6 = rectangleConstraint5.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = blockContainer0.toContentConstraint(rectangleConstraint5);
        org.jfree.chart.block.BlockFrame blockFrame8 = blockContainer0.getFrame();
        java.lang.Object obj9 = blockContainer0.clone();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(blockFrame8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test2070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2070");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double6 = rectangleConstraint5.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = blockContainer0.toContentConstraint(rectangleConstraint5);
        blockContainer0.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.block.Arrangement arrangement10 = blockContainer0.getArrangement();
        blockContainer0.setWidth((double) (byte) 1);
        org.jfree.chart.block.AbstractBlock abstractBlock13 = new org.jfree.chart.block.AbstractBlock();
        double double15 = abstractBlock13.calculateTotalWidth((double) (-1));
        double double17 = abstractBlock13.calculateTotalHeight((double) (-1L));
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = abstractBlock13.getMargin();
        abstractBlock13.setPadding(100.0d, (double) 0L, (double) (byte) 1, 33.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = abstractBlock13.getMargin();
        abstractBlock13.setID("Size2D[width=-1.0, height=10.0]");
        java.awt.geom.Rectangle2D rectangle2D27 = abstractBlock13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D28 = blockContainer0.trimPadding(rectangle2D27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockContainer0.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = blockContainer0.getPadding();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.awt.geom.Rectangle2D rectangle2D32 = blockContainer0.trimBorder(rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(arrangement10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
    }

    @Test
    public void test2071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2071");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 1.0f);
        double double5 = range4.getLength();
        double double6 = range4.getCentralValue();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1.0f);
        double double10 = range9.getLength();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = borderArrangement0.arrangeRR(blockContainer1, range4, range9, graphics2D11);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range4, (double) (short) 0);
        org.jfree.data.Range range16 = org.jfree.data.Range.expandToInclude(range14, (double) 1);
        java.lang.String str17 = range14.toString();
        double double18 = range14.getLength();
        double double19 = range14.getLowerBound();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "Range[1.0,1.0]" + "'", str17, "Range[1.0,1.0]");
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test2072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2072");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, 1.0d);
        double double4 = range3.getCentralValue();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range3, (double) (short) -1, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range3, (double) 100L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(5.5d, range3);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test2073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2073");
        org.jfree.chart.block.BorderArrangement borderArrangement1 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range3, (double) 1.0f);
        double double6 = range5.getLength();
        double double7 = range5.getCentralValue();
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) 1.0f);
        double double11 = range10.getLength();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = borderArrangement1.arrangeRR(blockContainer2, range5, range10, graphics2D12);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range5, (double) (short) 0);
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range15, (double) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double19 = rectangleConstraint18.getWidth();
        org.jfree.data.Range range20 = rectangleConstraint18.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint18.toFixedHeight(110.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint18.toFixedWidth((double) 100.0f);
        org.jfree.data.Range range25 = rectangleConstraint18.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType26 = rectangleConstraint18.getHeightConstraintType();
        java.lang.String str27 = lengthConstraintType26.toString();
        org.jfree.data.Range range29 = null;
        org.jfree.chart.block.AbstractBlock abstractBlock30 = new org.jfree.chart.block.AbstractBlock();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double32 = rectangleConstraint31.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = abstractBlock30.toContentConstraint(rectangleConstraint31);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = rectangleConstraint31.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 1, range15, lengthConstraintType26, (double) 10, range29, lengthConstraintType34);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockBorder36.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double40 = rectangleInsets38.calculateRightInset((double) 1.0f);
        double double42 = rectangleInsets38.trimWidth((double) 100);
        org.jfree.chart.util.UnitType unitType43 = rectangleInsets38.getUnitType();
        org.jfree.chart.block.BlockContainer blockContainer44 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D45 = blockContainer44.getBounds();
        blockContainer44.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = blockContainer44.getMargin();
        boolean boolean49 = unitType43.equals((java.lang.Object) rectangleInsets48);
        double double51 = rectangleInsets48.trimWidth(90.0d);
        org.jfree.chart.block.AbstractBlock abstractBlock52 = new org.jfree.chart.block.AbstractBlock();
        double double54 = abstractBlock52.calculateTotalWidth((double) (-1));
        double double56 = abstractBlock52.calculateTotalHeight((double) (-1L));
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = abstractBlock52.getMargin();
        abstractBlock52.setPadding(100.0d, (double) 0L, (double) (byte) 1, 33.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = abstractBlock52.getMargin();
        abstractBlock52.setID("Size2D[width=-1.0, height=10.0]");
        java.awt.geom.Rectangle2D rectangle2D66 = abstractBlock52.getBounds();
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets48.createOutsetRectangle(rectangle2D66);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets37.createOutsetRectangle(rectangle2D66, true, true);
        boolean boolean71 = lengthConstraintType34.equals((java.lang.Object) rectangleInsets37);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(lengthConstraintType26);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "LengthConstraintType.NONE" + "'", str27, "LengthConstraintType.NONE");
        org.junit.Assert.assertNotNull(rectangleConstraint31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertNotNull(unitType43);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 90.0d + "'", double51 == 90.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + (-1.0d) + "'", double54 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + (-1.0d) + "'", double56 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test2074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2074");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.setID("RectangleConstraintType.RANGE");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D4, rectangleConstraint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets8.calculateRightInset((double) 1.0f);
        double double12 = rectangleInsets8.trimWidth((double) 100);
        double double14 = rectangleInsets8.calculateBottomOutset((double) 100L);
        boolean boolean15 = blockContainer0.equals((java.lang.Object) rectangleInsets8);
        double double16 = blockContainer0.getContentXOffset();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer17.getBounds();
        blockContainer17.clear();
        blockContainer17.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D27 = blockContainer17.arrange(graphics2D25, rectangleConstraint26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = blockContainer17.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D30 = blockContainer29.getBounds();
        blockContainer29.clear();
        blockContainer29.clear();
        blockContainer29.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double35 = rectangleConstraint34.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = blockContainer29.toContentConstraint(rectangleConstraint34);
        org.jfree.data.Range range37 = rectangleConstraint34.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = blockContainer17.toContentConstraint(rectangleConstraint34);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double41 = rectangleConstraint40.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint40.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = rectangleConstraint40.toUnconstrainedHeight();
        org.jfree.data.Range range44 = rectangleConstraint40.getHeightRange();
        org.jfree.data.Range range45 = rectangleConstraint40.getHeightRange();
        boolean boolean46 = blockContainer0.equals((java.lang.Object) rectangleConstraint40);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = rectangleConstraint40.toFixedWidth(100.0d);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(rectangleConstraint43);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
    }

    @Test
    public void test2075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2075");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean2 = rectangleEdge0.equals((java.lang.Object) 10L);
        java.lang.String str3 = rectangleEdge0.toString();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj5 = null;
        boolean boolean6 = borderArrangement4.equals(obj5);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = borderArrangement4.arrangeNN(blockContainer7, graphics2D8);
        borderArrangement4.clear();
        boolean boolean11 = rectangleEdge0.equals((java.lang.Object) borderArrangement4);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) 100L, (double) 1.0f, (double) 10.0f);
        boolean boolean17 = borderArrangement4.equals((java.lang.Object) 100L);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D19 = blockContainer18.getBounds();
        blockContainer18.clear();
        blockContainer18.clear();
        blockContainer18.clear();
        java.lang.String str23 = blockContainer18.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = blockContainer18.getPadding();
        org.jfree.data.Range range25 = null;
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) 1.0f);
        boolean boolean30 = range27.intersects((double) 0, (double) 0.0f);
        org.jfree.data.Range range31 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(range27, range31);
        java.lang.String str33 = rectangleConstraint32.toString();
        org.jfree.data.Range range34 = null;
        org.jfree.data.Range range36 = org.jfree.data.Range.expandToInclude(range34, (double) 1.0f);
        boolean boolean39 = range36.intersects((double) 0, (double) 0.0f);
        org.jfree.data.Range range40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint(range36, range40);
        boolean boolean43 = range36.contains((double) 100L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint(range36, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = rectangleConstraint32.toRangeHeight(range36);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = rectangleConstraint46.toUnconstrainedWidth();
        // The following exception was thrown during execution in test generation
        try {
            borderArrangement4.add((org.jfree.chart.block.Block) blockContainer18, (java.lang.Object) rectangleConstraint46);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: class org.jfree.chart.block.RectangleConstraint cannot be cast to class org.jfree.chart.util.RectangleEdge (org.jfree.chart.block.RectangleConstraint and org.jfree.chart.util.RectangleEdge are in unnamed module of loader 'app')");
        } catch (java.lang.ClassCastException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "RectangleEdge.RIGHT" + "'", str3, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str33, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint46);
        org.junit.Assert.assertNotNull(rectangleConstraint47);
    }

    @Test
    public void test2076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2076");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D2 = blockContainer1.getBounds();
        blockContainer1.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D6 = blockContainer5.getBounds();
        java.awt.geom.Rectangle2D rectangle2D7 = blockContainer1.trimBorder(rectangle2D6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedWidth((double) 10.0f);
        double double12 = rectangleConstraint9.getHeight();
        org.jfree.chart.util.Size2D size2D13 = borderArrangement0.arrange(blockContainer1, graphics2D8, rectangleConstraint9);
        org.jfree.chart.block.BlockFrame blockFrame14 = blockContainer1.getFrame();
        double double16 = blockContainer1.calculateTotalHeight((double) (-1L));
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockFrame14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
    }

    @Test
    public void test2077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2077");
        // The following exception was thrown during execution in test generation
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }

    @Test
    public void test2078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2078");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) 1.0f);
        double double12 = range11.getLength();
        double double13 = range11.getLength();
        org.jfree.chart.block.BorderArrangement borderArrangement15 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer16 = null;
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 1.0f);
        double double20 = range19.getLength();
        double double21 = range19.getCentralValue();
        org.jfree.data.Range range22 = null;
        org.jfree.data.Range range24 = org.jfree.data.Range.expandToInclude(range22, (double) 1.0f);
        double double25 = range24.getLength();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = borderArrangement15.arrangeRR(blockContainer16, range19, range24, graphics2D26);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range30 = null;
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range30, (double) 1.0f);
        boolean boolean35 = range32.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint(0.0d, range19, lengthConstraintType28, (double) 100L, range32, lengthConstraintType36);
        java.lang.String str38 = lengthConstraintType36.toString();
        org.jfree.data.Range range40 = null;
        org.jfree.data.Range range42 = org.jfree.data.Range.expandToInclude(range40, (double) 1.0f);
        double double43 = range42.getLength();
        org.jfree.data.Range range46 = org.jfree.data.Range.expand(range42, (double) 1, (double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint47.toFixedWidth((double) 10.0f);
        double double50 = rectangleConstraint47.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = rectangleConstraint47.toFixedWidth(0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType53 = rectangleConstraint52.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = new org.jfree.chart.block.RectangleConstraint(0.0d, range11, lengthConstraintType36, 110.0d, range42, lengthConstraintType53);
        boolean boolean55 = blockContainer0.equals((java.lang.Object) rectangleConstraint54);
        double double56 = blockContainer0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = null;
        // The following exception was thrown during execution in test generation
        try {
            blockContainer0.setPadding(rectangleInsets57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "RectangleConstraintType.RANGE" + "'", str38, "RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(rectangleConstraint47);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint52);
        org.junit.Assert.assertNotNull(lengthConstraintType53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 10.0d + "'", double56 == 10.0d);
    }

    @Test
    public void test2079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2079");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D3 = blockContainer2.getBounds();
        blockContainer2.clear();
        blockContainer2.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D12 = blockContainer2.arrange(graphics2D10, rectangleConstraint11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockContainer2.getMargin();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D16 = borderArrangement0.arrangeFN(blockContainer2, graphics2D14, (double) 1.0f);
        blockContainer2.setWidth(197.0d);
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer19.getBounds();
        blockContainer19.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockContainer19.getMargin();
        blockContainer19.setHeight(35.0d);
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D27 = blockContainer26.getBounds();
        blockContainer26.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = blockContainer26.getMargin();
        org.jfree.chart.block.AbstractBlock abstractBlock31 = new org.jfree.chart.block.AbstractBlock();
        double double33 = abstractBlock31.calculateTotalWidth((double) (-1));
        java.lang.String str34 = abstractBlock31.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock31.setPadding(rectangleInsets35);
        abstractBlock31.setHeight((double) 10);
        org.jfree.chart.block.BlockBorder blockBorder39 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = blockBorder39.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer41 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D42 = blockContainer41.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets40.createAdjustedRectangle(rectangle2D42, lengthAdjustmentType43, lengthAdjustmentType44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean48 = rectangleEdge46.equals((java.lang.Object) 10L);
        java.lang.String str49 = rectangleEdge46.toString();
        double double50 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D42, rectangleEdge46);
        java.awt.geom.Rectangle2D rectangle2D51 = abstractBlock31.trimPadding(rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets30.createOutsetRectangle(rectangle2D51);
        blockContainer19.setBounds(rectangle2D52);
        java.awt.geom.Rectangle2D rectangle2D54 = blockContainer2.trimMargin(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(blockBorder39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "RectangleEdge.RIGHT" + "'", str49, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D54);
    }

    @Test
    public void test2080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2080");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        double double5 = blockContainer0.getContentYOffset();
        double double6 = blockContainer0.getContentXOffset();
        double double8 = blockContainer0.calculateTotalWidth((double) 10L);
        blockContainer0.clear();
        java.lang.String str10 = blockContainer0.getID();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double13 = rectangleConstraint12.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toUnconstrainedHeight();
        org.jfree.chart.util.Size2D size2D15 = blockContainer0.arrange(graphics2D11, rectangleConstraint12);
        size2D15.width = 20.0d;
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(size2D15);
    }

    @Test
    public void test2081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2081");
        org.jfree.chart.block.EmptyBlock emptyBlock2 = new org.jfree.chart.block.EmptyBlock((double) (byte) 0, (double) (short) 10);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = emptyBlock2.arrange(graphics2D3);
        emptyBlock2.setID("RectangleConstraintType.RANGE");
        double double7 = emptyBlock2.getHeight();
        org.jfree.chart.block.AbstractBlock abstractBlock8 = new org.jfree.chart.block.AbstractBlock();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = abstractBlock8.getMargin();
        double double11 = rectangleInsets9.calculateRightOutset((double) (byte) 0);
        double double13 = rectangleInsets9.calculateTopInset(0.0d);
        double double15 = rectangleInsets9.calculateRightInset((double) 100L);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) 0, (double) 'a', (double) 100);
        org.jfree.chart.block.BorderArrangement borderArrangement21 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj22 = null;
        boolean boolean23 = borderArrangement21.equals(obj22);
        org.jfree.chart.block.BlockContainer blockContainer24 = null;
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.util.Size2D size2D26 = borderArrangement21.arrangeNN(blockContainer24, graphics2D25);
        borderArrangement21.clear();
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D29 = blockContainer28.getBounds();
        blockContainer28.clear();
        blockContainer28.clear();
        blockContainer28.clear();
        java.lang.Object obj33 = null;
        borderArrangement21.add((org.jfree.chart.block.Block) blockContainer28, obj33);
        blockContainer28.setID("");
        java.awt.geom.Rectangle2D rectangle2D37 = blockContainer28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets20.createOutsetRectangle(rectangle2D37);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets9.createAdjustedRectangle(rectangle2D38, lengthAdjustmentType39, lengthAdjustmentType40);
        emptyBlock2.setBounds(rectangle2D41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.block.AbstractBlock abstractBlock44 = new org.jfree.chart.block.AbstractBlock();
        double double46 = abstractBlock44.calculateTotalWidth((double) (-1));
        java.lang.String str47 = abstractBlock44.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock44.setPadding(rectangleInsets48);
        double double51 = rectangleInsets48.calculateRightOutset((double) (-1L));
        org.jfree.chart.util.UnitType unitType52 = rectangleInsets48.getUnitType();
        org.jfree.chart.util.Size2D size2D53 = new org.jfree.chart.util.Size2D();
        boolean boolean54 = unitType52.equals((java.lang.Object) size2D53);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = new org.jfree.chart.util.RectangleInsets(unitType52, (double) 0L, (double) (-1.0f), (double) 0, 0.0d);
        org.jfree.chart.block.EmptyBlock emptyBlock62 = new org.jfree.chart.block.EmptyBlock((double) (short) 100, (double) (short) 1);
        double double63 = emptyBlock62.getWidth();
        java.awt.geom.Rectangle2D rectangle2D64 = emptyBlock62.getBounds();
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets59.createOutsetRectangle(rectangle2D64, true, false);
        // The following exception was thrown during execution in test generation
        try {
            emptyBlock2.drawBorder(graphics2D43, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-1.0d) + "'", double46 == (-1.0d));
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(unitType52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 100.0d + "'", double63 == 100.0d);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }

    @Test
    public void test2082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2082");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str1 = lengthConstraintType0.toString();
        java.lang.String str2 = lengthConstraintType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets3.calculateRightInset((double) 1.0f);
        double double7 = rectangleInsets3.trimWidth((double) 100);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets3.getUnitType();
        double double10 = rectangleInsets3.trimWidth((double) 0L);
        double double12 = rectangleInsets3.calculateTopInset((double) (-1L));
        boolean boolean13 = lengthConstraintType0.equals((java.lang.Object) double12);
        org.jfree.chart.block.AbstractBlock abstractBlock14 = new org.jfree.chart.block.AbstractBlock();
        double double16 = abstractBlock14.calculateTotalWidth((double) (-1));
        java.lang.String str17 = abstractBlock14.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock14.setPadding(rectangleInsets18);
        abstractBlock14.setHeight((double) 10);
        double double23 = abstractBlock14.trimToContentWidth(97.0d);
        double double24 = abstractBlock14.getContentYOffset();
        org.jfree.chart.block.BlockFrame blockFrame25 = abstractBlock14.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockFrame25.getInsets();
        boolean boolean27 = lengthConstraintType0.equals((java.lang.Object) rectangleInsets26);
        double double29 = rectangleInsets26.calculateLeftInset((double) 0L);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "RectangleConstraintType.RANGE" + "'", str1, "RectangleConstraintType.RANGE");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "RectangleConstraintType.RANGE" + "'", str2, "RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 97.0d + "'", double23 == 97.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test2083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2083");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) 0, (double) 'a', (double) 100);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint6 = blockBorder5.getPaint();
        org.jfree.chart.block.BorderArrangement borderArrangement8 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 1.0f);
        double double13 = range12.getLength();
        double double14 = range12.getCentralValue();
        org.jfree.data.Range range15 = null;
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range15, (double) 1.0f);
        double double18 = range17.getLength();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = borderArrangement8.arrangeRR(blockContainer9, range12, range17, graphics2D19);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range23 = null;
        org.jfree.data.Range range25 = org.jfree.data.Range.expandToInclude(range23, (double) 1.0f);
        boolean boolean28 = range25.intersects((double) 0, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(0.0d, range12, lengthConstraintType21, (double) 100L, range25, lengthConstraintType29);
        boolean boolean31 = blockBorder5.equals((java.lang.Object) lengthConstraintType29);
        java.awt.Paint paint32 = blockBorder5.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, paint32);
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(paint32);
        java.awt.Paint paint35 = blockBorder34.getPaint();
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test2084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2084");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = borderArrangement0.equals(obj1);
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = borderArrangement0.arrangeNN(blockContainer3, graphics2D4);
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        org.jfree.chart.block.BlockFrame blockFrame8 = blockContainer7.getFrame();
        blockContainer7.setID("RectangleInsets[t=0.0,l=0.0,b=10.0,r=1.0]");
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D12 = blockContainer11.getBounds();
        blockContainer11.setID("RectangleConstraintType.RANGE");
        java.lang.Object obj15 = blockContainer11.clone();
        org.jfree.chart.block.BlockBorder blockBorder16 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint17 = blockBorder16.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder(paint17);
        blockContainer11.setFrame((org.jfree.chart.block.BlockFrame) blockBorder18);
        org.jfree.chart.block.BlockBorder blockBorder20 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D23 = blockContainer22.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets21.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType24, lengthAdjustmentType25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean29 = rectangleEdge27.equals((java.lang.Object) 10L);
        java.lang.String str30 = rectangleEdge27.toString();
        double double31 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D23, rectangleEdge27);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge27);
        boolean boolean34 = blockBorder18.equals((java.lang.Object) rectangleEdge27);
        blockContainer7.setFrame((org.jfree.chart.block.BlockFrame) blockBorder18);
        java.awt.Paint paint36 = blockBorder18.getPaint();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets(32.0d, 0.0d, 33.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets((double) 0.0f, 0.0d, (double) 10, (double) 1L);
        org.jfree.chart.block.BorderArrangement borderArrangement48 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer49 = null;
        org.jfree.data.Range range50 = null;
        org.jfree.data.Range range52 = org.jfree.data.Range.expandToInclude(range50, (double) 1.0f);
        double double53 = range52.getLength();
        double double54 = range52.getCentralValue();
        org.jfree.data.Range range55 = null;
        org.jfree.data.Range range57 = org.jfree.data.Range.expandToInclude(range55, (double) 1.0f);
        double double58 = range57.getLength();
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.util.Size2D size2D60 = borderArrangement48.arrangeRR(blockContainer49, range52, range57, graphics2D59);
        borderArrangement48.clear();
        borderArrangement48.clear();
        org.jfree.chart.block.BlockContainer blockContainer63 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D64 = blockContainer63.getBounds();
        blockContainer63.clear();
        blockContainer63.clear();
        blockContainer63.clear();
        double double68 = blockContainer63.getContentYOffset();
        double double69 = blockContainer63.getContentXOffset();
        double double71 = blockContainer63.calculateTotalWidth((double) 10L);
        blockContainer63.clear();
        blockContainer63.clear();
        java.awt.Graphics2D graphics2D74 = null;
        org.jfree.chart.util.Size2D size2D76 = borderArrangement48.arrangeFN(blockContainer63, graphics2D74, (double) 1L);
        java.awt.geom.Rectangle2D rectangle2D77 = blockContainer63.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = rectangleInsets47.createAdjustedRectangle(rectangle2D77, lengthAdjustmentType78, lengthAdjustmentType79);
        java.awt.geom.Rectangle2D rectangle2D81 = rectangleInsets42.createInsetRectangle(rectangle2D80);
        // The following exception was thrown during execution in test generation
        try {
            blockBorder18.draw(graphics2D37, rectangle2D80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertNotNull(blockFrame8);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(blockBorder16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(blockBorder20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "RectangleEdge.RIGHT" + "'", str30, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(size2D60);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 10.0d + "'", double71 == 10.0d);
        org.junit.Assert.assertNotNull(size2D76);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(rectangle2D81);
    }

    @Test
    public void test2085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2085");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (double) 10L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint3.getHeightConstraintType();
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D6 = blockContainer5.getBounds();
        blockContainer5.clear();
        blockContainer5.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D15 = blockContainer5.arrange(graphics2D13, rectangleConstraint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockContainer5.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D18 = blockContainer17.getBounds();
        blockContainer17.clear();
        blockContainer17.clear();
        blockContainer17.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double23 = rectangleConstraint22.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = blockContainer17.toContentConstraint(rectangleConstraint22);
        org.jfree.data.Range range25 = rectangleConstraint22.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = blockContainer5.toContentConstraint(rectangleConstraint22);
        org.jfree.chart.block.BorderArrangement borderArrangement27 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer28 = null;
        org.jfree.data.Range range29 = null;
        org.jfree.data.Range range31 = org.jfree.data.Range.expandToInclude(range29, (double) 1.0f);
        double double32 = range31.getLength();
        double double33 = range31.getCentralValue();
        org.jfree.data.Range range34 = null;
        org.jfree.data.Range range36 = org.jfree.data.Range.expandToInclude(range34, (double) 1.0f);
        double double37 = range36.getLength();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.Size2D size2D39 = borderArrangement27.arrangeRR(blockContainer28, range31, range36, graphics2D38);
        org.jfree.data.Range range41 = org.jfree.data.Range.shift(range31, (double) (short) 0);
        org.jfree.data.Range range43 = org.jfree.data.Range.shift(range41, (double) 100.0f);
        org.jfree.data.Range range46 = org.jfree.data.Range.expand(range43, 33.0d, (double) (-1L));
        boolean boolean48 = range43.contains((-1.0d));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint26.toRangeWidth(range43);
        java.lang.String str50 = rectangleConstraint49.toString();
        boolean boolean51 = lengthConstraintType4.equals((java.lang.Object) rectangleConstraint49);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=101.0, height=0.0]" + "'", str50, "RectangleConstraint[RectangleConstraintType.RANGE: width=101.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test2086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2086");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', 5.5d, 98.0d, 0.03125d);
    }

    @Test
    public void test2087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2087");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean2 = rectangleEdge0.equals((java.lang.Object) 10L);
        java.lang.String str3 = rectangleEdge0.toString();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj5 = null;
        boolean boolean6 = borderArrangement4.equals(obj5);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = borderArrangement4.arrangeNN(blockContainer7, graphics2D8);
        borderArrangement4.clear();
        boolean boolean11 = rectangleEdge0.equals((java.lang.Object) borderArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D13 = blockContainer12.getBounds();
        blockContainer12.clear();
        java.lang.Object obj15 = null;
        borderArrangement4.add((org.jfree.chart.block.Block) blockContainer12, obj15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = blockContainer12.arrange(graphics2D17);
        size2D18.width = (byte) 100;
        size2D18.height = 100.0f;
        size2D18.width = 10;
        size2D18.setWidth((double) (byte) 1);
        size2D18.setHeight((double) ' ');
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "RectangleEdge.RIGHT" + "'", str3, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(size2D18);
    }

    @Test
    public void test2088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2088");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 1.0f, (double) (short) 1);
    }

    @Test
    public void test2089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2089");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D8, rectangleConstraint9);
        org.jfree.chart.block.Arrangement arrangement11 = blockContainer0.getArrangement();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets13.calculateRightInset((double) 1.0f);
        double double17 = rectangleInsets13.trimWidth((double) 100);
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets13.getUnitType();
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer19.getBounds();
        blockContainer19.setID("RectangleConstraintType.RANGE");
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockContainer19.getMargin();
        boolean boolean24 = unitType18.equals((java.lang.Object) rectangleInsets23);
        org.jfree.chart.block.BlockContainer blockContainer25 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = blockContainer25.arrange(graphics2D26);
        blockContainer25.setID("Range[1.0,1.0]");
        java.util.List list30 = blockContainer25.getBlocks();
        boolean boolean31 = unitType18.equals((java.lang.Object) blockContainer25);
        double double33 = blockContainer25.calculateTotalWidth(0.0d);
        blockContainer25.setID("Size2D[width=-1.0, height=10.0]");
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D37 = blockContainer36.getBounds();
        blockContainer36.clear();
        blockContainer36.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D46 = blockContainer36.arrange(graphics2D44, rectangleConstraint45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = blockContainer36.getMargin();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double49 = rectangleConstraint48.getWidth();
        org.jfree.data.Range range50 = rectangleConstraint48.getWidthRange();
        double double51 = rectangleConstraint48.getWidth();
        double double52 = rectangleConstraint48.getWidth();
        boolean boolean53 = blockContainer36.equals((java.lang.Object) double52);
        java.awt.geom.Rectangle2D rectangle2D54 = blockContainer36.getBounds();
        java.awt.geom.Rectangle2D rectangle2D55 = blockContainer25.trimMargin(rectangle2D54);
        // The following exception was thrown during execution in test generation
        try {
            blockContainer0.draw(graphics2D12, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(arrangement11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test2090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2090");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean2 = rectangleEdge0.equals((java.lang.Object) 10L);
        java.lang.String str3 = rectangleEdge0.toString();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj5 = null;
        boolean boolean6 = borderArrangement4.equals(obj5);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = borderArrangement4.arrangeNN(blockContainer7, graphics2D8);
        double double10 = size2D9.getWidth();
        boolean boolean11 = rectangleEdge0.equals((java.lang.Object) size2D9);
        double double12 = size2D9.height;
        org.jfree.chart.block.EmptyBlock emptyBlock15 = new org.jfree.chart.block.EmptyBlock((double) 100L, (double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D16 = emptyBlock15.getBounds();
        boolean boolean17 = size2D9.equals((java.lang.Object) emptyBlock15);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (double) (byte) 0);
        org.jfree.chart.util.Size2D size2D22 = emptyBlock15.arrange(graphics2D18, rectangleConstraint21);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "RectangleEdge.RIGHT" + "'", str3, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(size2D22);
    }

    @Test
    public void test2091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2091");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getWidth();
        org.jfree.data.Range range2 = rectangleConstraint0.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight(110.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint5.toFixedHeight((-10.0d));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint7.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test2092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2092");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        org.jfree.data.Range range2 = null;
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 1.0f);
        double double5 = range4.getLength();
        double double6 = range4.getCentralValue();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 1.0f);
        double double10 = range9.getLength();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = borderArrangement0.arrangeRR(blockContainer1, range4, range9, graphics2D11);
        org.jfree.chart.block.BlockBorder blockBorder17 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint18 = blockBorder17.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (-1.0d), 0.0d, (double) 0, paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(paint18);
        boolean boolean21 = borderArrangement0.equals((java.lang.Object) blockBorder20);
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D24 = blockContainer23.getBounds();
        blockContainer23.clear();
        blockContainer23.clear();
        blockContainer23.clear();
        double double28 = blockContainer23.getContentYOffset();
        double double29 = blockContainer23.getContentXOffset();
        blockContainer23.setHeight(197.0d);
        org.jfree.chart.block.BlockFrame blockFrame32 = blockContainer23.getFrame();
        java.lang.Object obj33 = null;
        borderArrangement0.add((org.jfree.chart.block.Block) blockContainer23, obj33);
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D36 = blockContainer35.getBounds();
        blockContainer35.setWidth((double) (-1L));
        org.jfree.chart.block.Arrangement arrangement39 = blockContainer35.getArrangement();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.util.Size2D size2D41 = borderArrangement0.arrangeNN(blockContainer35, graphics2D40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.block.BlockBorder blockBorder43 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = blockBorder43.getInsets();
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D46 = blockContainer45.getBounds();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets44.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType47, lengthAdjustmentType48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean52 = rectangleEdge50.equals((java.lang.Object) 10L);
        java.lang.String str53 = rectangleEdge50.toString();
        org.jfree.chart.block.BorderArrangement borderArrangement54 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj55 = null;
        boolean boolean56 = borderArrangement54.equals(obj55);
        org.jfree.chart.block.BlockContainer blockContainer57 = null;
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.util.Size2D size2D59 = borderArrangement54.arrangeNN(blockContainer57, graphics2D58);
        borderArrangement54.clear();
        boolean boolean61 = rectangleEdge50.equals((java.lang.Object) borderArrangement54);
        org.jfree.chart.block.BlockContainer blockContainer62 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D63 = blockContainer62.getBounds();
        blockContainer62.clear();
        java.lang.Object obj65 = null;
        borderArrangement54.add((org.jfree.chart.block.Block) blockContainer62, obj65);
        java.lang.String str67 = blockContainer62.getID();
        java.awt.geom.Rectangle2D rectangle2D68 = blockContainer62.getBounds();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj69 = blockContainer35.draw(graphics2D42, rectangle2D46, (java.lang.Object) rectangle2D68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(blockBorder17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame32);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(arrangement39);
        org.junit.Assert.assertNotNull(size2D41);
        org.junit.Assert.assertNotNull(blockBorder43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertEquals("'" + str53 + "' != '" + "RectangleEdge.RIGHT" + "'", str53, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(size2D59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(rectangle2D68);
    }

    @Test
    public void test2093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2093");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.setID("RectangleConstraintType.RANGE");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D4, rectangleConstraint6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets8.calculateRightInset((double) 1.0f);
        double double12 = rectangleInsets8.trimWidth((double) 100);
        double double14 = rectangleInsets8.calculateBottomOutset((double) 100L);
        boolean boolean15 = blockContainer0.equals((java.lang.Object) rectangleInsets8);
        double double16 = blockContainer0.getWidth();
        blockContainer0.clear();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D20 = blockContainer19.getBounds();
        blockContainer19.clear();
        blockContainer19.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D29 = blockContainer19.arrange(graphics2D27, rectangleConstraint28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = blockContainer19.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D32 = blockContainer31.getBounds();
        blockContainer31.clear();
        blockContainer31.clear();
        blockContainer31.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double37 = rectangleConstraint36.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = blockContainer31.toContentConstraint(rectangleConstraint36);
        org.jfree.data.Range range39 = rectangleConstraint36.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = blockContainer19.toContentConstraint(rectangleConstraint36);
        double double41 = blockContainer19.getContentXOffset();
        org.jfree.chart.block.BlockBorder blockBorder46 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint47 = blockBorder46.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder48 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (-1.0d), 0.0d, (double) 0, paint47);
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder(paint47);
        java.awt.Paint paint50 = blockBorder49.getPaint();
        blockContainer19.setFrame((org.jfree.chart.block.BlockFrame) blockBorder49);
        java.awt.geom.Rectangle2D rectangle2D52 = blockContainer19.getBounds();
        org.jfree.chart.block.BlockContainer blockContainer53 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D54 = blockContainer53.getBounds();
        blockContainer53.clear();
        blockContainer53.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D63 = blockContainer53.arrange(graphics2D61, rectangleConstraint62);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = blockContainer53.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer65 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D66 = blockContainer65.getBounds();
        blockContainer65.clear();
        blockContainer65.clear();
        blockContainer65.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint70 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double71 = rectangleConstraint70.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint72 = blockContainer65.toContentConstraint(rectangleConstraint70);
        org.jfree.data.Range range73 = rectangleConstraint70.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint74 = blockContainer53.toContentConstraint(rectangleConstraint70);
        org.jfree.chart.block.AbstractBlock abstractBlock75 = new org.jfree.chart.block.AbstractBlock();
        double double77 = abstractBlock75.calculateTotalWidth((double) (-1));
        abstractBlock75.setMargin((double) 'a', 110.0d, (double) 0, 0.0d);
        boolean boolean83 = blockContainer53.equals((java.lang.Object) 0);
        java.lang.Object obj84 = blockContainer53.clone();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj85 = blockContainer0.draw(graphics2D18, rectangle2D52, (java.lang.Object) blockContainer53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 10.0d + "'", double41 == 10.0d);
        org.junit.Assert.assertNotNull(blockBorder46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleConstraint62);
        org.junit.Assert.assertNotNull(size2D63);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangleConstraint70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint72);
        org.junit.Assert.assertNull(range73);
        org.junit.Assert.assertNotNull(rectangleConstraint74);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + (-1.0d) + "'", double77 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(obj84);
    }

    @Test
    public void test2094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2094");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean2 = rectangleEdge0.equals((java.lang.Object) 10L);
        java.lang.String str3 = rectangleEdge0.toString();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj5 = null;
        boolean boolean6 = borderArrangement4.equals(obj5);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = borderArrangement4.arrangeNN(blockContainer7, graphics2D8);
        borderArrangement4.clear();
        boolean boolean11 = rectangleEdge0.equals((java.lang.Object) borderArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D13 = blockContainer12.getBounds();
        blockContainer12.clear();
        java.lang.Object obj15 = null;
        borderArrangement4.add((org.jfree.chart.block.Block) blockContainer12, obj15);
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D19 = blockContainer18.getBounds();
        blockContainer18.clear();
        blockContainer18.clear();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockContainer18.getMargin();
        java.lang.String str23 = blockContainer18.getID();
        blockContainer18.setPadding((double) 100.0f, (-1.0d), (double) (-1.0f), (double) 100);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double31 = rectangleConstraint30.getWidth();
        org.jfree.data.Range range32 = rectangleConstraint30.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = rectangleConstraint30.toFixedHeight(110.0d);
        double double35 = rectangleConstraint34.getHeight();
        org.jfree.chart.util.Size2D size2D36 = borderArrangement4.arrangeFF(blockContainer18, graphics2D29, rectangleConstraint34);
        org.jfree.chart.block.AbstractBlock abstractBlock37 = new org.jfree.chart.block.AbstractBlock();
        double double39 = abstractBlock37.calculateTotalWidth((double) (-1));
        abstractBlock37.setMargin((double) 'a', 110.0d, (double) 0, 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = abstractBlock37.getPadding();
        org.jfree.data.Range range46 = null;
        org.jfree.data.Range range48 = org.jfree.data.Range.expandToInclude(range46, (double) 1.0f);
        double double49 = range48.getLength();
        boolean boolean51 = range48.equals((java.lang.Object) 10L);
        boolean boolean54 = range48.intersects((double) (short) 100, (double) 0.0f);
        boolean boolean56 = range48.contains((double) 100.0f);
        boolean boolean57 = rectangleInsets45.equals((java.lang.Object) 100.0f);
        boolean boolean58 = blockContainer18.equals((java.lang.Object) rectangleInsets45);
        double double60 = rectangleInsets45.extendWidth(10.0d);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "RectangleEdge.RIGHT" + "'", str3, "RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(rectangleConstraint34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 110.0d + "'", double35 == 110.0d);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-1.0d) + "'", double39 == (-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10.0d + "'", double60 == 10.0d);
    }

    @Test
    public void test2095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2095");
        org.jfree.chart.block.AbstractBlock abstractBlock0 = new org.jfree.chart.block.AbstractBlock();
        double double2 = abstractBlock0.calculateTotalWidth((double) (-1));
        java.lang.String str3 = abstractBlock0.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        abstractBlock0.setPadding(rectangleInsets4);
        java.lang.String str6 = rectangleInsets4.toString();
        double double8 = rectangleInsets4.trimHeight(110.0d);
        double double10 = rectangleInsets4.trimHeight((double) (-1L));
        double double11 = rectangleInsets4.getBottom();
        double double13 = rectangleInsets4.calculateLeftInset((-152.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str6, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 110.0d + "'", double8 == 110.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test2096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2096");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.clear();
        blockContainer0.clear();
        java.lang.String str5 = blockContainer0.getID();
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (double) (-1L), (double) 10.0f, (double) (-1L));
        blockContainer0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder10);
        double double12 = blockContainer0.getHeight();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test2097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2097");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getWidth();
        org.jfree.data.Range range2 = rectangleConstraint0.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint0.toFixedHeight(110.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint0.toFixedWidth((double) 100.0f);
        org.jfree.data.Range range7 = rectangleConstraint0.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint0.getHeightConstraintType();
        java.lang.String str9 = lengthConstraintType8.toString();
        org.jfree.chart.block.EmptyBlock emptyBlock12 = new org.jfree.chart.block.EmptyBlock(0.0d, (double) 10);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.Range range14 = null;
        org.jfree.data.Range range16 = org.jfree.data.Range.expandToInclude(range14, (double) 1.0f);
        boolean boolean19 = range16.intersects((double) 0, (double) 0.0f);
        org.jfree.data.Range range20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range16, range20);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedHeight(0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint23.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint24.toFixedHeight((double) (short) -1);
        org.jfree.chart.util.Size2D size2D27 = emptyBlock12.arrange(graphics2D13, rectangleConstraint26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint26.toFixedWidth((double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint29.toUnconstrainedHeight();
        boolean boolean31 = lengthConstraintType8.equals((java.lang.Object) rectangleConstraint30);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType32 = rectangleConstraint30.getWidthConstraintType();
        org.jfree.data.Range range33 = rectangleConstraint30.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "LengthConstraintType.NONE" + "'", str9, "LengthConstraintType.NONE");
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType32);
        org.junit.Assert.assertNull(range33);
    }

    @Test
    public void test2098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2098");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1.0f);
        boolean boolean5 = range2.intersects((double) 0, (double) 0.0f);
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range2, range6);
        java.lang.String str8 = rectangleConstraint7.toString();
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) 1.0f);
        boolean boolean14 = range11.intersects((double) 0, (double) 0.0f);
        org.jfree.data.Range range15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range11, range15);
        boolean boolean18 = range11.contains((double) 100L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range11, (double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint7.toRangeHeight(range11);
        org.jfree.chart.block.BorderArrangement borderArrangement24 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        org.jfree.data.Range range26 = null;
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude(range26, (double) 1.0f);
        double double29 = range28.getLength();
        double double30 = range28.getCentralValue();
        org.jfree.data.Range range31 = null;
        org.jfree.data.Range range33 = org.jfree.data.Range.expandToInclude(range31, (double) 1.0f);
        double double34 = range33.getLength();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.util.Size2D size2D36 = borderArrangement24.arrangeRR(blockContainer25, range28, range33, graphics2D35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint(0.0d, range33);
        boolean boolean39 = range33.contains((double) 1L);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude(range33, (double) 0L);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range33, 0.0d, (double) (byte) -1);
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D46 = blockContainer45.getBounds();
        blockContainer45.clear();
        blockContainer45.clear();
        blockContainer45.clear();
        boolean boolean50 = range33.equals((java.lang.Object) blockContainer45);
        org.jfree.data.Range range52 = org.jfree.data.Range.expandToInclude(range33, (double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = new org.jfree.chart.block.RectangleConstraint(9.0d, range33);
        org.jfree.data.Range range54 = null;
        org.jfree.data.Range range56 = org.jfree.data.Range.expandToInclude(range54, (double) (short) 100);
        double double57 = range56.getLowerBound();
        org.jfree.data.Range range59 = org.jfree.data.Range.shift(range56, 0.03125d);
        org.jfree.data.Range range62 = org.jfree.data.Range.expand(range56, (double) (short) 0, (double) (byte) -1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = rectangleConstraint53.toRangeHeight(range56);
        org.jfree.data.Range range66 = new org.jfree.data.Range((-32.0d), (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = new org.jfree.chart.block.RectangleConstraint(range56, range66);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = rectangleConstraint7.toRangeHeight(range66);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str8, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 100.0d + "'", double57 == 100.0d);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(rectangleConstraint63);
        org.junit.Assert.assertNotNull(rectangleConstraint68);
    }

    @Test
    public void test2099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2099");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = blockContainer0.getBounds();
        blockContainer0.clear();
        blockContainer0.setMargin((double) (short) 100, (double) (short) 10, (double) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D10 = blockContainer0.arrange(graphics2D8, rectangleConstraint9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockContainer0.getMargin();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D13 = blockContainer12.getBounds();
        blockContainer12.clear();
        blockContainer12.clear();
        blockContainer12.clear();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double18 = rectangleConstraint17.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = blockContainer12.toContentConstraint(rectangleConstraint17);
        org.jfree.data.Range range20 = rectangleConstraint17.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = blockContainer0.toContentConstraint(rectangleConstraint17);
        double double22 = blockContainer0.getContentXOffset();
        org.jfree.chart.block.BlockBorder blockBorder27 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint28 = blockBorder27.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (-1.0d), 0.0d, (double) 0, paint28);
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder(paint28);
        java.awt.Paint paint31 = blockBorder30.getPaint();
        blockContainer0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder30);
        java.awt.geom.Rectangle2D rectangle2D33 = blockContainer0.getBounds();
        blockContainer0.setID("RectangleConstraint[RectangleConstraintType.RANGE: width=101.0, height=0.0]");
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertNotNull(blockBorder27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }
}

