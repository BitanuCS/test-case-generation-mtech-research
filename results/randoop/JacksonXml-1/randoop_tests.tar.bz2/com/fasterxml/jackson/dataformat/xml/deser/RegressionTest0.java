package com.fasterxml.jackson.dataformat.xml.deser;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test1");
        com.fasterxml.jackson.core.io.IOContext iOContext0 = null;
        javax.xml.stream.XMLInputFactory xMLInputFactory3 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory4 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper5 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(xMLInputFactory3, xMLOutputFactory4);
        java.lang.Class[] classArray7 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray8 = (java.lang.Class<?>[]) classArray7;
        xmlMapper5.registerSubtypes(wildcardClassArray8);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper11 = xmlMapper5.setDefaultUseWrapper(true);
        com.fasterxml.jackson.databind.cfg.HandlerInstantiator handlerInstantiator12 = null;
        java.lang.Object obj13 = xmlMapper5.setHandlerInstantiator(handlerInstantiator12);
        com.fasterxml.jackson.databind.PropertyNamingStrategy propertyNamingStrategy14 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper15 = xmlMapper5.setPropertyNamingStrategy(propertyNamingStrategy14);
        java.util.Locale locale16 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper17 = xmlMapper5.setLocale(locale16);
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver18 = xmlMapper5.getSubtypeResolver();
        com.fasterxml.jackson.core.Base64Variant base64Variant19 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper20 = xmlMapper5.setBase64Variant(base64Variant19);
        javax.xml.stream.XMLStreamReader xMLStreamReader21 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser fromXmlParser22 = new com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser(iOContext0, (int) (byte) 0, (int) (byte) 1, (com.fasterxml.jackson.core.ObjectCodec) xmlMapper5, xMLStreamReader21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(classArray7);
        org.junit.Assert.assertArrayEquals(classArray7, new java.lang.Class[] {});
        org.junit.Assert.assertNotNull(wildcardClassArray8);
        org.junit.Assert.assertArrayEquals(wildcardClassArray8, new java.lang.Class[] {});
        org.junit.Assert.assertNotNull(xmlMapper11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(objectMapper15);
        org.junit.Assert.assertNotNull(objectMapper17);
        org.junit.Assert.assertNotNull(subtypeResolver18);
        org.junit.Assert.assertNotNull(objectMapper20);
    }
}

