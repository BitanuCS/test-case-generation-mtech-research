package com.fasterxml.jackson.databind.deser.impl;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test1");
        com.fasterxml.jackson.databind.BeanDescription beanDescription0 = null;
        com.fasterxml.jackson.databind.deser.impl.CreatorCollector creatorCollector2 = new com.fasterxml.jackson.databind.deser.impl.CreatorCollector(beanDescription0, true);
        com.fasterxml.jackson.databind.introspect.AnnotatedWithParams annotatedWithParams3 = null;
        // The following exception was thrown during execution in test generation
        try {
            creatorCollector2.verifyNonDup(annotatedWithParams3, 12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 12 out of bounds for length 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test2");
        com.fasterxml.jackson.databind.BeanDescription beanDescription0 = null;
        com.fasterxml.jackson.databind.deser.impl.CreatorCollector creatorCollector2 = new com.fasterxml.jackson.databind.deser.impl.CreatorCollector(beanDescription0, true);
        creatorCollector2._hasNonDefaultCreator = true;
    }
}

