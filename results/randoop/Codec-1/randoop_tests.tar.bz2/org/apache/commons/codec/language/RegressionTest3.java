package org.apache.commons.codec.language;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1501");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str10 = metaphone0.metaphone("O621");
        metaphone0.setMaxCodeLen((int) '9');
        java.lang.String str14 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNH");
        java.lang.String str16 = metaphone0.metaphone("RKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ORKPKSKMNSKTKNKTRKSPKSN" + "'", str14, "ORKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "RKPKSKMNSKTKNKTRKSPKSNRKP" + "'", str16, "RKPKSKMNSKTKNKTRKSPKSNRKP");
    }

    @Test
    public void test1502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1502");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("K", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSKTSNKTRKSPKSNRKPR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1503");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        java.lang.String str9 = metaphone0.metaphone("A111111111");
        java.lang.String str11 = metaphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str13 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str16 = doubleMetaphone14.doubleMetaphone("H");
        java.lang.String str18 = doubleMetaphone14.doubleMetaphone("");
        java.lang.String str21 = doubleMetaphone14.doubleMetaphone("ORKP", true);
        java.lang.String str24 = doubleMetaphone14.doubleMetaphone("", false);
        java.lang.String str26 = doubleMetaphone14.doubleMetaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = metaphone0.encode((java.lang.Object) doubleMetaphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O" + "'", str11, "O");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ORKP" + "'", str13, "ORKP");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "ARKP" + "'", str26, "ARKP");
    }

    @Test
    public void test1504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1504");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        char char14 = doubleMetaphone0.charAt("", (int) 'c');
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone0.new DoubleMetaphoneResult((-1));
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
    }

    @Test
    public void test1505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1505");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.soundex("AR");
        soundex4.setMaxLength((int) ' ');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A600" + "'", str6, "A600");
    }

    @Test
    public void test1506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1506");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        int int16 = refinedSoundex0.difference("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK", "");
        java.lang.String str18 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderExc");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0940103030808306030830609053" + "'", str18, "O0940103030808306030830609053");
    }

    @Test
    public void test1507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1507");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.soundex("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone13.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult20.appendPrimary('#');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A093138363836931589313836383693158" + "'", str12, "A093138363836931589313836383693158");
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
    }

    @Test
    public void test1508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1508");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.encode("");
        java.lang.String str14 = caverphone0.encode("A621r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "1111111111" + "'", str12, "1111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AA11111111" + "'", str14, "AA11111111");
    }

    @Test
    public void test1509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1509");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        int int12 = refinedSoundex0.difference("org.apache.commons.codec.Encoder", "A093138363836931589313836383693158");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test1510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1510");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex11.setMaxLength(52);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str15 = soundex11.encode("A621HIo");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: H");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1511");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        int int9 = soundex0.getMaxLength();
        java.lang.String str11 = soundex0.encode("");
        int int14 = soundex0.difference("ORKP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test1512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1512");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A093153836383693");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test1513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1513");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O0931");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "A621");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = '\000';
        char char13 = doubleMetaphone8.charAt("", 0);
        boolean boolean17 = doubleMetaphone8.isDoubleMetaphoneEqual("A111111111", "A", false);
        java.lang.Object obj18 = caverphone0.encode((java.lang.Object) "A");
        java.lang.String str20 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTION");
        java.lang.String str22 = caverphone0.encode("R");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertEquals("'" + obj18 + "' != '" + "A111111111" + "'", obj18, "A111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A111111111" + "'", str22, "A111111111");
    }

    @Test
    public void test1514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1514");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test1515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1515");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("HI");
        int int10 = metaphone0.getMaxCodeLen();
        int int11 = metaphone0.getMaxCodeLen();
        java.lang.String str13 = metaphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H" + "'", str9, "H");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ORK" + "'", str13, "ORK");
    }

    @Test
    public void test1516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1516");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char3 = refinedSoundex1.getMappingCode('a');
        int int6 = refinedSoundex1.difference("", "hi!");
        char char8 = refinedSoundex1.getMappingCode('#');
        java.lang.String str10 = refinedSoundex1.soundex("01230120022455012623010202");
        java.lang.String str12 = refinedSoundex1.encode("A621");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) str12);
        java.lang.String str15 = caverphone0.caverphone("A621");
        java.lang.String str17 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertNotNull(refinedSoundex1);
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '0' + "'", char3 == '0');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0" + "'", str12, "A0");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "A111111111" + "'", obj13, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
    }

    @Test
    public void test1517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1517");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "A111111111O620");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1518");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.Encoder", "O062010202050520302052030602013050");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1519");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("A621");
        java.lang.String str13 = refinedSoundex0.encode("O000");
        char char15 = refinedSoundex0.getMappingCode('a');
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("O0931");
        boolean boolean23 = caverphone16.isCaverphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "A621");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone24 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone24.maxCodeLen = '\000';
        char char29 = doubleMetaphone24.charAt("", 0);
        boolean boolean33 = doubleMetaphone24.isDoubleMetaphoneEqual("A111111111", "A", false);
        java.lang.Object obj34 = caverphone16.encode((java.lang.Object) "A");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj35 = refinedSoundex0.encode((java.lang.Object) caverphone16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '0' + "'", char15 == '0');
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "A111111111" + "'", str20, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '\000' + "'", char29 == '\000');
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertEquals("'" + obj34 + "' != '" + "A111111111" + "'", obj34, "A111111111");
    }

    @Test
    public void test1520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1520");
        char[] charArray2 = new char[] { '1', 'a' };
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char7 = refinedSoundex5.getMappingCode('a');
        int int10 = refinedSoundex5.difference("", "hi!");
        int int13 = refinedSoundex5.difference("hi!", "");
        int int16 = refinedSoundex5.difference("hi!", "");
        char char18 = refinedSoundex5.getMappingCode('4');
        java.lang.String str20 = refinedSoundex5.soundex("");
        java.lang.Object obj21 = soundex4.encode((java.lang.Object) str20);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', 'a' });
        org.junit.Assert.assertNotNull(refinedSoundex5);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "" + "'", obj21, "");
    }

    @Test
    public void test1521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1521");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "01230120022455012623010202");
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A931", "O0");
        char char8 = refinedSoundex0.getMappingCode('9');
        java.lang.String str10 = refinedSoundex0.soundex("A621r");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A09" + "'", str10, "A09");
    }

    @Test
    public void test1522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1522");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O0940103030808306030830609053016080940103030808306030830609053016080931", "0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1523");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        java.lang.String str10 = soundex4.encode(" AKPK");
        java.lang.Class<?> wildcardClass11 = soundex4.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A212" + "'", str10, "A212");
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test1524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1524");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("ORKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
    }

    @Test
    public void test1525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1525");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("O093");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A313", "org.apache.commons.codec.EncoderException: ");
        metaphone0.setMaxCodeLen((int) '3');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test1526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1526");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('4');
        org.apache.commons.codec.language.Caverphone caverphone7 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str9 = caverphone7.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str11 = caverphone7.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str13 = caverphone7.encode("");
        java.lang.String str15 = caverphone7.encode("01230120022455012623010202");
        java.lang.String str17 = caverphone7.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str19 = caverphone7.caverphone("O941");
        java.lang.String str21 = caverphone7.caverphone("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = refinedSoundex4.encode((java.lang.Object) caverphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKPKKMNSKT" + "'", str9, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A111111111" + "'", str19, "A111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKKMNSKT" + "'", str21, "AKPKKMNSKT");
    }

    @Test
    public void test1527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1527");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.encode("");
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "#", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "1111111111" + "'", str12, "1111111111");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test1528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1528");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("A0931383");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "A000" + "'", str3, "A000");
    }

    @Test
    public void test1529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1529");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        metaphone0.setMaxCodeLen((int) (short) 0);
        java.lang.String str16 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
    }

    @Test
    public void test1530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1530");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        boolean boolean13 = metaphone0.isMetaphoneEqual("O000", "O620");
        int int14 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test1531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1531");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        int int1 = metaphone0.getMaxCodeLen();
        java.lang.String str3 = metaphone0.metaphone("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "H" + "'", str3, "H");
    }

    @Test
    public void test1532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1532");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        java.lang.String str13 = metaphone0.encode("hi!");
        boolean boolean16 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO", "O941");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test1533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1533");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.Object obj9 = doubleMetaphone0.encode((java.lang.Object) "ORKP");
        doubleMetaphone0.maxCodeLen = 0;
        boolean boolean15 = doubleMetaphone0.isDoubleMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", true);
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("A");
        char[] charArray23 = null;
        org.apache.commons.codec.language.Soundex soundex24 = new org.apache.commons.codec.language.Soundex(charArray23);
        java.lang.String str26 = soundex24.soundex("");
        java.lang.String str28 = soundex24.encode("");
        java.lang.Object obj29 = caverphone16.encode((java.lang.Object) "");
        boolean boolean32 = caverphone16.isCaverphoneEqual("O093", "AKP1111111");
        java.lang.Object obj33 = doubleMetaphone0.encode((java.lang.Object) "AKP1111111");
        doubleMetaphone0.setMaxCodeLen((int) '6');
        int int36 = doubleMetaphone0.maxCodeLen;
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A111111111" + "'", str22, "A111111111");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "1111111111" + "'", obj29, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "" + "'", obj33, "");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 54 + "'", int36 == 54);
    }

    @Test
    public void test1534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1534");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex8.setMaxLength((int) '1');
        int int13 = soundex8.difference("", "0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1535");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("AKPKMNSKT1");
        java.lang.String str12 = caverphone0.encode("H000");
        java.lang.String str14 = caverphone0.caverphone("#");
        java.lang.String str16 = caverphone0.encode("");
        boolean boolean19 = caverphone0.isCaverphoneEqual("A#", "A621HI");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKMNSKT1" + "'", str10, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "1111111111" + "'", str14, "1111111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "1111111111" + "'", str16, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test1536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1536");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("");
        boolean boolean16 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: org.ap", "org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str18 = caverphone0.encode("org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        boolean boolean21 = caverphone0.isCaverphoneEqual("A0931", "A111111111O620");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str24 = doubleMetaphone22.doubleMetaphone("H");
        doubleMetaphone22.setMaxCodeLen((int) (byte) 0);
        java.lang.String str28 = doubleMetaphone22.encode("H");
        boolean boolean31 = doubleMetaphone22.isDoubleMetaphoneEqual("hi!", "AKPKKMNSKT");
        int int32 = doubleMetaphone22.getMaxCodeLen();
        boolean boolean36 = doubleMetaphone22.isDoubleMetaphoneEqual("A0", "O0931", true);
        java.lang.String str38 = doubleMetaphone22.doubleMetaphone("A#");
        boolean boolean41 = doubleMetaphone22.isDoubleMetaphoneEqual("A111111111O620", "AA11111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj42 = caverphone0.encode((java.lang.Object) boolean41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test1537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1537");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        java.lang.String str12 = metaphone0.encode("A111111111O620");
        java.lang.String str14 = metaphone0.encode("AKPKMNSK11");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKP" + "'", str14, "AKP");
    }

    @Test
    public void test1538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1538");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        soundex0.setMaxLength((int) '1');
        char[] charArray3 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray3);
        soundex4.setMaxLength((int) (byte) 100);
        java.lang.String str8 = soundex4.soundex("A#");
        java.lang.Object obj9 = soundex0.encode((java.lang.Object) str8);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "A000" + "'", obj9, "A000");
    }

    @Test
    public void test1539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1539");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        java.lang.String str15 = caverphone0.encode("AK");
        java.lang.String str17 = caverphone0.encode("A0O");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
    }

    @Test
    public void test1540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1540");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean5 = metaphone0.isMetaphoneEqual("ARK", "A0931");
        boolean boolean8 = metaphone0.isMetaphoneEqual("hi!", "O093");
        metaphone0.setMaxCodeLen((int) '9');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test1541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1541");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("AKPKMNSKT1", "");
        java.lang.Object obj6 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = soundex2.encode(obj6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test1542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1542");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('a');
        int int10 = refinedSoundex0.difference("AK", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        int int13 = refinedSoundex0.difference("", "ARKPXKMNSKTKNKTRKSPXNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1543");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        metaphone0.setMaxCodeLen(105);
        java.lang.String str28 = metaphone0.encode("ARKPKKMNSKTKNKTRKSPXNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "ARKPKMNSKTKNKTRKSPKSNRKP" + "'", str28, "ARKPKMNSKTKNKTRKSPKSNRKP");
    }

    @Test
    public void test1544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1544");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        java.lang.String str21 = refinedSoundex0.encode("H0");
        char char23 = refinedSoundex0.getMappingCode(' ');
        java.lang.String str25 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderExc");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "H0" + "'", str21, "H0");
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "O0940103030808306030830609053" + "'", str25, "O0940103030808306030830609053");
    }

    @Test
    public void test1545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1545");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.metaphone("A0313");
        java.lang.String str6 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSK");
        metaphone0.setMaxCodeLen((int) '0');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "ORK" + "'", str6, "ORK");
    }

    @Test
    public void test1546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1546");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        char char5 = refinedSoundex3.getMappingCode('O');
        java.lang.String str7 = refinedSoundex3.soundex("A0931383");
        java.lang.String str9 = refinedSoundex3.encode(" AKPKMNSKTK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A0" + "'", str7, "A0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A02125232" + "'", str9, "A02125232");
    }

    @Test
    public void test1547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1547");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = refinedSoundex4.difference("O931", "org.apache.commons.codec.EncoderException: AKPK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test1548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1548");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORK", "AKPKSKMNSK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1549");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        java.lang.String str9 = metaphone0.metaphone("A111111111");
        java.lang.String str11 = metaphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str13 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str15 = metaphone0.encode("org.apache.commons.codec.EncoderException: A000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O" + "'", str11, "O");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ORKP" + "'", str13, "ORKP");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKP" + "'", str15, "ORKP");
    }

    @Test
    public void test1550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1550");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        int int19 = refinedSoundex0.difference("1111111111", "O621");
        char char21 = refinedSoundex0.getMappingCode('r');
        char char23 = refinedSoundex0.getMappingCode('0');
        char[] charArray27 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex28 = new org.apache.commons.codec.language.RefinedSoundex(charArray27);
        char char30 = refinedSoundex28.getMappingCode('4');
        org.apache.commons.codec.language.Metaphone metaphone31 = new org.apache.commons.codec.language.Metaphone();
        metaphone31.setMaxCodeLen(3);
        java.lang.String str35 = metaphone31.encode("");
        int int38 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone31, "hi!", "");
        metaphone31.setMaxCodeLen(0);
        java.lang.String str42 = metaphone31.encode("AK11111111");
        java.lang.String str44 = metaphone31.encode("A1");
        java.lang.String str46 = metaphone31.metaphone("A000");
        java.lang.String str48 = metaphone31.metaphone("ORKPXKMNSKTKNKTRKSSPXN");
        java.lang.Object obj49 = refinedSoundex28.encode((java.lang.Object) str48);
        java.lang.Object obj50 = refinedSoundex0.encode((java.lang.Object) str48);
        char char52 = refinedSoundex0.getMappingCode('A');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '9' + "'", char21 == '9');
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertArrayEquals(charArray27, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + '\000' + "'", char30 == '\000');
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "" + "'", str46, "");
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "" + "'", str48, "");
        org.junit.Assert.assertEquals("'" + obj49 + "' != '" + "" + "'", obj49, "");
        org.junit.Assert.assertEquals("'" + obj50 + "' != '" + "" + "'", obj50, "");
        org.junit.Assert.assertTrue("'" + char52 + "' != '" + '0' + "'", char52 == '0');
    }

    @Test
    public void test1551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1551");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        int int25 = metaphone0.getMaxCodeLen();
        boolean boolean28 = metaphone0.isMetaphoneEqual("8org.apache.commons.codec.EncoderException: A0931", "O09315383638369315893153836383693158931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 114 + "'", int25 == 114);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test1552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1552");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.encode("ORK");
        char char11 = refinedSoundex0.getMappingCode('a');
        java.lang.String str13 = refinedSoundex0.soundex("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKPor");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O093" + "'", str9, "O093");
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '0' + "'", char11 == '0');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0931538363836931589315383638369315893109" + "'", str13, "O0931538363836931589315383638369315893109");
    }

    @Test
    public void test1553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1553");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        java.lang.String str19 = caverphone0.caverphone("ARKPXKMNSK");
        java.lang.String str21 = caverphone0.caverphone("AKPKMNSKT");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone22.maxCodeLen = 0;
        char char27 = doubleMetaphone22.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult29 = doubleMetaphone22.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult29.appendAlternate('\000');
        doubleMetaphoneResult29.append('#');
        boolean boolean34 = doubleMetaphoneResult29.isComplete();
        java.lang.Class<?> wildcardClass35 = doubleMetaphoneResult29.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSK11" + "'", str19, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKMNSKT1" + "'", str21, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '\000' + "'", char27 == '\000');
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test1554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1554");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.soundex("A0313836");
        int int11 = soundex0.getMaxLength();
        int int14 = soundex0.difference("H0", "ARKPKSKMNSK");
        int int15 = soundex0.getMaxLength();
        int int16 = soundex0.getMaxLength();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test1555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1555");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = 0;
        char char19 = doubleMetaphone14.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean23 = doubleMetaphone14.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone14.maxCodeLen = 3;
        java.lang.String str27 = doubleMetaphone14.encode("A111111111");
        java.lang.Object obj28 = refinedSoundex0.encode((java.lang.Object) str27);
        int int31 = refinedSoundex0.difference("A0313836", "O620");
        java.lang.String str33 = refinedSoundex0.soundex("ORKPXKMNSK");
        java.lang.String str35 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODER");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A" + "'", str27, "A");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "A0" + "'", obj28, "A0");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "O09315383" + "'", str33, "O09315383");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "O0940103030808306030830609" + "'", str35, "O0940103030808306030830609");
    }

    @Test
    public void test1556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1556");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        java.lang.String str23 = metaphone0.encode("");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
    }

    @Test
    public void test1557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1557");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        int int9 = soundex0.getMaxLength();
        java.lang.String str11 = soundex0.encode("");
        java.lang.String str13 = soundex0.encode("O0931");
        java.lang.String str15 = soundex0.encode("");
        int int16 = soundex0.getMaxLength();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O000" + "'", str13, "O000");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test1558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1558");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.encode("A");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
    }

    @Test
    public void test1559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1559");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.String str32 = caverphone0.caverphone("01230120022455012623010202");
        java.lang.String str34 = caverphone0.encode("ORK");
        java.lang.String str36 = caverphone0.encode(" AKPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "1111111111" + "'", str32, "1111111111");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AK11111111" + "'", str34, "AK11111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "AKPK111111" + "'", str36, "AKPK111111");
    }

    @Test
    public void test1560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1560");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("");
        boolean boolean30 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: O620", "AKPKMNSKTS");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "1111111111" + "'", str27, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test1561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1561");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str10 = metaphone0.metaphone("O");
        java.lang.String str12 = metaphone0.encode("O093");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char15 = refinedSoundex13.getMappingCode('a');
        int int18 = refinedSoundex13.difference("", "hi!");
        char char20 = refinedSoundex13.getMappingCode('0');
        char char22 = refinedSoundex13.getMappingCode('a');
        java.lang.String str24 = refinedSoundex13.soundex("1111111111");
        char char26 = refinedSoundex13.getMappingCode('0');
        java.lang.String str28 = refinedSoundex13.encode("O");
        java.lang.Object obj30 = refinedSoundex13.encode((java.lang.Object) "A0");
        java.lang.String str32 = refinedSoundex13.soundex("A");
        java.lang.Object obj33 = metaphone0.encode((java.lang.Object) "A");
        boolean boolean36 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "ARKPXKMNSKTSNKTRKSPXN");
        metaphone0.setMaxCodeLen(0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNotNull(refinedSoundex13);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '0' + "'", char15 == '0');
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '0' + "'", char22 == '0');
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '\000' + "'", char26 == '\000');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "O0" + "'", str28, "O0");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "A0" + "'", obj30, "A0");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "A0" + "'", str32, "A0");
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "A" + "'", obj33, "A");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test1562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1562");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        java.lang.String str9 = soundex1.encode("01230120022455012623010202");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) '5');
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test1563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1563");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean5 = metaphone0.isMetaphoneEqual("ARK", "A0931");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        doubleMetaphone6.setMaxCodeLen((int) (byte) 0);
        java.lang.String str13 = doubleMetaphone6.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult15 = doubleMetaphone6.new DoubleMetaphoneResult(0);
        java.lang.String str16 = doubleMetaphoneResult15.getAlternate();
        doubleMetaphoneResult15.append('\000');
        doubleMetaphoneResult15.append('#', '#');
        java.lang.String str22 = doubleMetaphoneResult15.getPrimary();
        java.lang.String str23 = doubleMetaphoneResult15.getAlternate();
        doubleMetaphoneResult15.append("org.apache.commons.codec.EncoderException: hi!");
        doubleMetaphoneResult15.append("ORKP");
        doubleMetaphoneResult15.append("");
        doubleMetaphoneResult15.append('\000', 'a');
        java.lang.String str33 = doubleMetaphoneResult15.getAlternate();
        java.lang.Object obj34 = metaphone0.encode((java.lang.Object) str33);
        java.lang.String str36 = metaphone0.encode("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + obj34 + "' != '" + "" + "'", obj34, "");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "ORKP" + "'", str36, "ORKP");
    }

    @Test
    public void test1564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1564");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("AKPKMNSKT1");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        doubleMetaphone11.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone11.maxCodeLen = '0';
        java.lang.String str20 = doubleMetaphone11.doubleMetaphone("A", true);
        boolean boolean23 = doubleMetaphone11.isDoubleMetaphoneEqual("A0", "");
        boolean boolean26 = doubleMetaphone11.isDoubleMetaphoneEqual("A ", "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone11.setMaxCodeLen((int) 'A');
        int int31 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone11, "ARK", "A ");
        doubleMetaphone11.setMaxCodeLen((int) '#');
        boolean boolean36 = doubleMetaphone11.isDoubleMetaphoneEqual("O620", "");
        char[] charArray37 = null;
        org.apache.commons.codec.language.Soundex soundex38 = new org.apache.commons.codec.language.Soundex(charArray37);
        java.lang.String str40 = soundex38.soundex("");
        java.lang.Object obj41 = doubleMetaphone11.encode((java.lang.Object) "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj42 = caverphone0.encode((java.lang.Object) doubleMetaphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKMNSKT1" + "'", str10, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "A" + "'", str20, "A");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "" + "'", str40, "");
        org.junit.Assert.assertNull(obj41);
    }

    @Test
    public void test1565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1565");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        soundex4.setMaxLength((int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = '\000';
        doubleMetaphone7.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult13 = doubleMetaphone7.new DoubleMetaphoneResult((int) '1');
        doubleMetaphoneResult13.appendPrimary(' ');
        doubleMetaphoneResult13.appendAlternate("A621");
        doubleMetaphoneResult13.appendAlternate("org.apache.commons.codec.EncoderException: A0");
        doubleMetaphoneResult13.appendPrimary("org.apache.commons.codec.EncoderException: AA11111111");
        doubleMetaphoneResult13.appendPrimary('\000');
        doubleMetaphoneResult13.append("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "A0931383");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = soundex4.encode((java.lang.Object) "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
    }

    @Test
    public void test1566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1566");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone0.maxCodeLen = '0';
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A621HI", "ORGAPACHECOMMONSCODECENCODEREXCEPTION");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test1567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1567");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("AKPKMNSKT1");
        java.lang.String str12 = caverphone0.encode("H000");
        java.lang.String str14 = caverphone0.caverphone("#");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = caverphone0.encode((java.lang.Object) 8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKMNSKT1" + "'", str10, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "1111111111" + "'", str14, "1111111111");
    }

    @Test
    public void test1568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1568");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        int int8 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.Caverphone caverphone9 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str11 = caverphone9.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str13 = caverphone9.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone9.encode("A");
        java.lang.Object obj16 = doubleMetaphone0.encode((java.lang.Object) str15);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone0.new DoubleMetaphoneResult(79);
        java.lang.String str20 = doubleMetaphone0.doubleMetaphone("org.apache.commons.codec.EncoderException: AK11111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertEquals("'" + obj16 + "' != '" + "" + "'", obj16, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
    }

    @Test
    public void test1569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1569");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        int int17 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(0);
        boolean boolean22 = metaphone0.isMetaphoneEqual("K111111111", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        metaphone0.setMaxCodeLen(105);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test1570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1570");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AKP1111111", "org.apache.commons.codec.EncoderException: ARKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1571");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("A111111111O620");
        java.lang.String str12 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: ");
        metaphone0.setMaxCodeLen((int) '6');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ORKPXKMNSK" + "'", str12, "ORKPXKMNSK");
    }

    @Test
    public void test1572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1572");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.Object obj32 = caverphone0.encode((java.lang.Object) "AKPKMNSKT1");
        java.lang.String str34 = caverphone0.caverphone("O0940103030808306030830609053016080931");
        int int37 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str39 = caverphone0.caverphone("A0");
        java.lang.String str41 = caverphone0.encode("A ");
        java.lang.String[] strArray45 = new java.lang.String[] {};
        boolean boolean46 = org.apache.commons.codec.language.DoubleMetaphone.contains("01230120022455012623010202", (int) 'a', (int) (short) 0, strArray45);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj47 = caverphone0.encode((java.lang.Object) boolean46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "AKPKMNSKT1" + "'", obj32, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "A111111111" + "'", str39, "A111111111");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "A111111111" + "'", str41, "A111111111");
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertArrayEquals(strArray45, new java.lang.String[] {});
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test1573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1573");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.encode("H");
        boolean boolean16 = caverphone0.isCaverphoneEqual("A111111111O620", "hi!");
        java.lang.String str18 = caverphone0.caverphone("01");
        boolean boolean21 = caverphone0.isCaverphoneEqual("  ", "O093");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "1111111111" + "'", str18, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test1574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1574");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int6 = soundex2.getMaxLength();
        int int7 = soundex2.getMaxLength();
        int int10 = soundex2.difference("AKPKMNSK", "O941");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = 0;
        char char16 = doubleMetaphone11.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone11.new DoubleMetaphoneResult((int) (short) 0);
        java.lang.String str20 = doubleMetaphone11.doubleMetaphone("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj21 = soundex2.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        int int22 = soundex2.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "O941" + "'", obj21, "O941");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
    }

    @Test
    public void test1575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1575");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str15 = caverphone0.caverphone("ARKPKSKMNSK");
        java.lang.String str17 = caverphone0.caverphone("ORK");
        org.apache.commons.codec.language.Metaphone metaphone18 = new org.apache.commons.codec.language.Metaphone();
        metaphone18.setMaxCodeLen(3);
        java.lang.String str22 = metaphone18.encode("");
        java.lang.String str24 = metaphone18.encode("");
        metaphone18.setMaxCodeLen((int) (short) 10);
        int int27 = metaphone18.getMaxCodeLen();
        java.lang.String str29 = metaphone18.encode("ORKP");
        java.lang.String str31 = metaphone18.encode("hi!");
        int int32 = metaphone18.getMaxCodeLen();
        int int35 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone18, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "AKPKMNSKT");
        int int36 = metaphone18.getMaxCodeLen();
        java.lang.String str38 = metaphone18.encode("ARKPKKMNSK");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = caverphone0.encode((java.lang.Object) metaphone18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKT1" + "'", str13, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKSKMNSK" + "'", str15, "AKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AK11111111" + "'", str17, "AK11111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ORKP" + "'", str29, "ORKP");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "H" + "'", str31, "H");
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "ARKPKMNSK" + "'", str38, "ARKPKMNSK");
    }

    @Test
    public void test1576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1576");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = 100;
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        java.lang.String str22 = doubleMetaphone0.encode("");
        int int23 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.Caverphone caverphone24 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str26 = caverphone24.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str28 = caverphone24.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str30 = caverphone24.encode("");
        java.lang.String str32 = caverphone24.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone33 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone33.maxCodeLen = 0;
        char char38 = doubleMetaphone33.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult40 = doubleMetaphone33.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult40.appendAlternate('\000');
        java.lang.String str43 = doubleMetaphoneResult40.getAlternate();
        java.lang.String str44 = doubleMetaphoneResult40.getPrimary();
        java.lang.Object obj45 = caverphone24.encode((java.lang.Object) str44);
        java.lang.String str47 = caverphone24.caverphone("");
        int int50 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone24, "AKPKKMNSKT", "ORKP");
        boolean boolean53 = caverphone24.isCaverphoneEqual("", "HI");
        boolean boolean56 = caverphone24.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str58 = caverphone24.encode("A0");
        java.lang.String str60 = caverphone24.caverphone("");
        java.lang.String str62 = caverphone24.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean65 = caverphone24.isCaverphoneEqual("", " AKPK");
        java.lang.String str67 = caverphone24.encode("O093");
        boolean boolean70 = caverphone24.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#", "");
        java.lang.Object obj71 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "AKPKKMNSKT" + "'", str26, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AKPKKMNSKT" + "'", str28, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "1111111111" + "'", str32, "1111111111");
        org.junit.Assert.assertTrue("'" + char38 + "' != '" + '\000' + "'", char38 == '\000');
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "" + "'", str43, "");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
        org.junit.Assert.assertEquals("'" + obj45 + "' != '" + "1111111111" + "'", obj45, "1111111111");
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "1111111111" + "'", str47, "1111111111");
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "A111111111" + "'", str58, "A111111111");
        org.junit.Assert.assertEquals("'" + str60 + "' != '" + "1111111111" + "'", str60, "1111111111");
        org.junit.Assert.assertEquals("'" + str62 + "' != '" + "AKPKKMNSKT" + "'", str62, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertEquals("'" + str67 + "' != '" + "A111111111" + "'", str67, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertEquals("'" + obj71 + "' != '" + "ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK" + "'", obj71, "ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
    }

    @Test
    public void test1577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1577");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        soundex3.setMaxLength((int) (short) 100);
        soundex3.setMaxLength(48);
        soundex3.setMaxLength(19);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex3.encode("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1578");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: hi!");
        int int16 = refinedSoundex0.difference("AKPKKMNSKT", "O0940103030808306030830609053016080");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderExc", "ORKPXKMNSKTKNKTRKSSPXNH");
        java.lang.String str21 = refinedSoundex0.encode("A0931");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0940103030808306030830609053016080" + "'", str13, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A0" + "'", str21, "A0");
    }

    @Test
    public void test1579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1579");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.soundex("ORKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O0621" + "'", str7, "O0621");
    }

    @Test
    public void test1580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1580");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("H0", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1581");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.maxCodeLen = '0';
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult6 = doubleMetaphone0.new DoubleMetaphoneResult((int) '1');
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("ARKPXKMNSK", false);
        char[] charArray10 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray10);
        org.apache.commons.codec.language.Soundex soundex12 = new org.apache.commons.codec.language.Soundex(charArray10);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = new org.apache.commons.codec.language.RefinedSoundex(charArray10);
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray10);
        soundex14.setMaxLength(0);
        int int19 = soundex14.difference("AKP1111111", "AKPK");
        java.lang.Object obj20 = doubleMetaphone0.encode((java.lang.Object) "AKPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ARKPKSKMNSK" + "'", str9, "ARKPKSKMNSK");
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "AKPK" + "'", obj20, "AKPK");
    }

    @Test
    public void test1582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1582");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        boolean boolean17 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("AK11111111", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean24 = doubleMetaphone0.isDoubleMetaphoneEqual("O0", "", false);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "  ");
        doubleMetaphone0.maxCodeLen = 0;
        char char32 = doubleMetaphone0.charAt("9", (-1));
        int int33 = doubleMetaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + char32 + "' != '" + '\000' + "'", char32 == '\000');
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test1583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1583");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("AKPKMNSKT1");
        java.lang.String str12 = caverphone0.encode("H000");
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone13.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str19 = caverphone13.encode("A");
        java.lang.String str21 = caverphone13.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str23 = caverphone13.encode("hi!");
        java.lang.String str25 = caverphone13.encode("O0940103030808306030830609053016080931");
        java.lang.String str27 = caverphone13.encode("org.apache.commons.codec.EncoderException: O0");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = caverphone0.encode((java.lang.Object) caverphone13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKMNSKT1" + "'", str10, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A111111111" + "'", str19, "A111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKKMNSKT" + "'", str21, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "AA11111111" + "'", str23, "AA11111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A111111111" + "'", str25, "A111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "AKPKKMNSKT" + "'", str27, "AKPKKMNSKT");
    }

    @Test
    public void test1584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1584");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O0931");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "A621");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = '\000';
        char char13 = doubleMetaphone8.charAt("", 0);
        boolean boolean17 = doubleMetaphone8.isDoubleMetaphoneEqual("A111111111", "A", false);
        java.lang.Object obj18 = caverphone0.encode((java.lang.Object) "A");
        java.lang.String str20 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        java.lang.String str22 = caverphone0.encode("9");
        java.lang.String str24 = caverphone0.caverphone("A111111111");
        java.lang.Object obj26 = caverphone0.encode((java.lang.Object) "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertEquals("'" + obj18 + "' != '" + "A111111111" + "'", obj18, "A111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A111111111" + "'", str24, "A111111111");
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "AKPKMNSKTK" + "'", obj26, "AKPKMNSKTK");
    }

    @Test
    public void test1585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1585");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        int int19 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "O0931");
        char[] charArray21 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex22 = new org.apache.commons.codec.language.RefinedSoundex(charArray21);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex23 = new org.apache.commons.codec.language.RefinedSoundex(charArray21);
        org.apache.commons.codec.language.Soundex soundex24 = new org.apache.commons.codec.language.Soundex(charArray21);
        org.apache.commons.codec.language.Soundex soundex25 = new org.apache.commons.codec.language.Soundex(charArray21);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex26 = new org.apache.commons.codec.language.RefinedSoundex(charArray21);
        java.lang.String str28 = refinedSoundex26.encode("");
        java.lang.Object obj29 = metaphone0.encode((java.lang.Object) str28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertArrayEquals(charArray21, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "" + "'", obj29, "");
    }

    @Test
    public void test1586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1586");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        org.apache.commons.codec.language.Caverphone caverphone9 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str11 = caverphone9.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str13 = caverphone9.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone9.encode("");
        java.lang.String str17 = caverphone9.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone18.maxCodeLen = 0;
        char char23 = doubleMetaphone18.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult25 = doubleMetaphone18.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult25.appendAlternate('\000');
        java.lang.String str28 = doubleMetaphoneResult25.getAlternate();
        java.lang.String str29 = doubleMetaphoneResult25.getPrimary();
        java.lang.Object obj30 = caverphone9.encode((java.lang.Object) str29);
        java.lang.String str32 = caverphone9.caverphone("");
        java.lang.String str34 = caverphone9.encode("");
        boolean boolean37 = caverphone9.isCaverphoneEqual("", "A#");
        java.lang.Object obj38 = refinedSoundex0.encode((java.lang.Object) "A#");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone39 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str41 = doubleMetaphone39.doubleMetaphone("H");
        doubleMetaphone39.setMaxCodeLen((int) (byte) 0);
        java.lang.String str46 = doubleMetaphone39.doubleMetaphone("1111111111", false);
        java.lang.String str49 = doubleMetaphone39.doubleMetaphone("hi!", false);
        java.lang.String str52 = doubleMetaphone39.doubleMetaphone("", true);
        doubleMetaphone39.setMaxCodeLen((int) 'O');
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult56 = doubleMetaphone39.new DoubleMetaphoneResult((int) '0');
        int int57 = doubleMetaphone39.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj58 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "1111111111" + "'", obj30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "1111111111" + "'", str32, "1111111111");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "1111111111" + "'", str34, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertEquals("'" + obj38 + "' != '" + "A0" + "'", obj38, "A0");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "" + "'", str41, "");
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "" + "'", str46, "");
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "" + "'", str49, "");
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 79 + "'", int57 == 79);
    }

    @Test
    public void test1587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1587");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('a');
        int int10 = refinedSoundex0.difference("AK", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        java.lang.String str12 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        char char14 = refinedSoundex0.getMappingCode('i');
        java.lang.String str16 = refinedSoundex0.soundex("ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O0940103030808306030830609053016080" + "'", str12, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '0' + "'", char14 == '0');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O09315383" + "'", str16, "O09315383");
    }

    @Test
    public void test1588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1588");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex5, "", "A313");
        char char17 = refinedSoundex5.getMappingCode('A');
        // The following exception was thrown during execution in test generation
        try {
            char char19 = refinedSoundex5.getMappingCode('o');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + ' ' + "'", char17 == ' ');
    }

    @Test
    public void test1589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1589");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        int int15 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone16.maxCodeLen = '\000';
        char char21 = doubleMetaphone16.charAt("", 0);
        java.lang.String str23 = doubleMetaphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str25 = doubleMetaphone16.doubleMetaphone("");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult27 = doubleMetaphone16.new DoubleMetaphoneResult((int) (byte) 100);
        doubleMetaphoneResult27.appendPrimary('4');
        java.lang.String str30 = doubleMetaphoneResult27.getPrimary();
        java.lang.Object obj31 = doubleMetaphone0.encode((java.lang.Object) str30);
        doubleMetaphone0.setMaxCodeLen(2);
        int int36 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "AKPKKMNSKT", "O0940103030808306030830609");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "4" + "'", str30, "4");
        org.junit.Assert.assertEquals("'" + obj31 + "' != '" + "" + "'", obj31, "");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test1590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1590");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        soundex0.setMaxLength((int) '8');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str15 = doubleMetaphone13.doubleMetaphone("H");
        doubleMetaphone13.setMaxCodeLen((int) (byte) 0);
        java.lang.String str20 = doubleMetaphone13.doubleMetaphone("1111111111", false);
        java.lang.String str23 = doubleMetaphone13.doubleMetaphone("hi!", false);
        char char26 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = soundex0.encode((java.lang.Object) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + 'r' + "'", char26 == 'r');
    }

    @Test
    public void test1591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1591");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        char char12 = refinedSoundex0.getMappingCode('#');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean22 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char25 = doubleMetaphone13.charAt("01230120022455012623010202", (int) (short) 1);
        char char28 = doubleMetaphone13.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone13.maxCodeLen = 100;
        boolean boolean33 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        boolean boolean36 = doubleMetaphone13.isDoubleMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str38 = doubleMetaphone13.encode("AKPKKMNSKT");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '1' + "'", char25 == '1');
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + 'O' + "'", char28 == 'O');
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKMNSKT" + "'", str38, "AKPKMNSKT");
    }

    @Test
    public void test1592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1592");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) 'o');
        java.lang.String str4 = soundex0.soundex("0123012002245501262301020201230120022455012623010");
        java.lang.String str6 = soundex0.encode("O0940103030808306030830609053016080313836");
        int int7 = soundex0.getMaxLength();
        soundex0.setMaxLength((-1));
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O000" + "'", str6, "O000");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
    }

    @Test
    public void test1593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1593");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        java.lang.String str14 = caverphone0.encode("AKPKKMNSKT");
        java.lang.String str16 = caverphone0.encode("ORKPXKMNSKTKNKTRKSSPXNH");
        java.lang.String str18 = caverphone0.encode("ORKPXKMNSKTKNKTRKSSPXNH");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKT1" + "'", str14, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKMNSKTK" + "'", str16, "AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKMNSKTK" + "'", str18, "AKPKMNSKTK");
    }

    @Test
    public void test1594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1594");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        org.apache.commons.codec.language.Soundex soundex10 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = refinedSoundex0.encode((java.lang.Object) soundex10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertNotNull(soundex10);
    }

    @Test
    public void test1595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1595");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.encode("AKPKMNSK");
        java.lang.String str10 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKMNSK11" + "'", str8, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
    }

    @Test
    public void test1596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1596");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength((int) 'a');
        soundex1.setMaxLength(43);
        int int8 = soundex1.getMaxLength();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 43 + "'", int8 == 43);
    }

    @Test
    public void test1597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1597");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str7 = doubleMetaphone0.encode("A");
        java.lang.Object obj9 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone0.maxCodeLen = (byte) 1;
        char char14 = doubleMetaphone0.charAt("AKPKMNSKTS", 9);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex15 = new org.apache.commons.codec.language.RefinedSoundex();
        char char17 = refinedSoundex15.getMappingCode('0');
        int int20 = refinedSoundex15.difference("O0", "O0");
        char char22 = refinedSoundex15.getMappingCode(' ');
        char char24 = refinedSoundex15.getMappingCode('\000');
        int int27 = refinedSoundex15.difference("", "O0940103030808306030830609053016080");
        java.lang.String str29 = refinedSoundex15.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = doubleMetaphone0.encode((java.lang.Object) refinedSoundex15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + 'S' + "'", char14 == 'S');
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
    }

    @Test
    public void test1598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1598");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char31 = refinedSoundex29.getMappingCode('a');
        int int34 = refinedSoundex29.difference("", "hi!");
        char char36 = refinedSoundex29.getMappingCode('#');
        int int39 = refinedSoundex29.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj41 = refinedSoundex29.encode((java.lang.Object) "O941");
        java.lang.Object obj42 = caverphone0.encode(obj41);
        boolean boolean45 = caverphone0.isCaverphoneEqual("H000", "AA");
        java.lang.String str47 = caverphone0.caverphone("O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(refinedSoundex29);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0" + "'", obj41, "O0");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "A111111111" + "'", obj42, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "A111111111" + "'", str47, "A111111111");
    }

    @Test
    public void test1599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1599");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O09315383638369315893153836383693158931");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test1600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1600");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('a');
        int int10 = refinedSoundex0.difference("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN", "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test1601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1601");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: A111111111O620", "A#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1602");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex5.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
    }

    @Test
    public void test1603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1603");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        soundex0.setMaxLength(0);
        soundex0.setMaxLength((int) '#');
        soundex0.setMaxLength((int) 'i');
        org.apache.commons.codec.language.Soundex soundex12 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str14 = soundex12.encode("ARKP");
        java.lang.String str16 = soundex12.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj18 = soundex12.encode((java.lang.Object) "ORK");
        soundex12.setMaxLength(4);
        java.lang.String str22 = soundex12.soundex("A0313836");
        int int23 = soundex12.getMaxLength();
        int int26 = soundex12.difference("H0", "ARKPKSKMNSK");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = soundex0.encode((java.lang.Object) soundex12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A621" + "'", str14, "A621");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O621" + "'", str16, "O621");
        org.junit.Assert.assertEquals("'" + obj18 + "' != '" + "O620" + "'", obj18, "O620");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A000" + "'", str22, "A000");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test1604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1604");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int6 = soundex2.getMaxLength();
        java.lang.String str8 = soundex2.encode("A062125232523621256212523252362125");
        soundex2.setMaxLength((int) (byte) 1);
        java.lang.String str12 = soundex2.encode("O621");
        java.lang.String str14 = soundex2.encode("aORGAPACHECOMMONSCODECENCODEREXC");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O000" + "'", str12, "O000");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A941" + "'", str14, "A941");
    }

    @Test
    public void test1605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1605");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("r", "org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1606");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean19 = metaphone0.isMetaphoneEqual("A0931", "");
        metaphone0.setMaxCodeLen((int) ' ');
        java.lang.String str23 = metaphone0.encode("AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "AKPKMNSKT" + "'", str23, "AKPKMNSKT");
    }

    @Test
    public void test1607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1607");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        boolean boolean9 = caverphone0.isCaverphoneEqual("A0931", "A0931");
        boolean boolean12 = caverphone0.isCaverphoneEqual("A212", "ORKPXKMNSKTKNKTRKSSPXNH");
        java.lang.String str14 = caverphone0.caverphone("H000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A111111111" + "'", str14, "A111111111");
    }

    @Test
    public void test1608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1608");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = metaphone0.encode("");
        java.lang.String str19 = metaphone0.encode("AKPKMNSK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSK" + "'", str19, "AKPKMNSK");
    }

    @Test
    public void test1609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1609");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.encode("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        boolean boolean16 = caverphone0.isCaverphoneEqual("i4org.apache.commons.codec.EncoderException: A000", "AHIAM");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKTK" + "'", str13, "AKPKMNSKTK");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test1610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1610");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: hi!");
        int int16 = refinedSoundex0.difference("AKPKKMNSKT", "O0940103030808306030830609053016080");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderExc", "ORKPXKMNSKTKNKTRKSSPXNH");
        java.lang.String str21 = refinedSoundex0.soundex("AKPKMNSKTK");
        java.lang.String str23 = refinedSoundex0.encode("AK11111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0940103030808306030830609053016080" + "'", str13, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A03138363" + "'", str21, "A03138363");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A03" + "'", str23, "A03");
    }

    @Test
    public void test1611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1611");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        char char7 = doubleMetaphone0.charAt("hi!", 1);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A621", "H");
        doubleMetaphone0.maxCodeLen = '0';
        int int13 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str15 = doubleMetaphone0.encode("A");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult17 = doubleMetaphone0.new DoubleMetaphoneResult((int) '0');
        doubleMetaphoneResult17.append("", "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'i' + "'", char7 == 'i');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 48 + "'", int13 == 48);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A" + "'", str15, "A");
    }

    @Test
    public void test1612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1612");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AHM", "A000a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1613");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int3 = soundex0.difference("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "A931");
        java.lang.String str5 = soundex0.encode("");
        java.lang.String str7 = soundex0.soundex("A621HI0A093138363836931589313836383693158");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
    }

    @Test
    public void test1614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1614");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str8 = metaphone0.encode("");
        int int9 = metaphone0.getMaxCodeLen();
        int int10 = metaphone0.getMaxCodeLen();
        java.lang.String str12 = metaphone0.encode("O0621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
    }

    @Test
    public void test1615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1615");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str15 = refinedSoundex0.encode("ARKPKSKMNS");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A0931383" + "'", str15, "A0931383");
    }

    @Test
    public void test1616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1616");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        boolean boolean39 = caverphone0.isCaverphoneEqual("A031", "AKPKKMNSKT");
        boolean boolean42 = caverphone0.isCaverphoneEqual("O941", "A111111111O000");
        org.apache.commons.codec.EncoderException encoderException44 = new org.apache.commons.codec.EncoderException("A0931");
        java.lang.Throwable[] throwableArray45 = encoderException44.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException47 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray48 = encoderException47.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException50 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException47.addSuppressed((java.lang.Throwable) encoderException50);
        encoderException44.addSuppressed((java.lang.Throwable) encoderException47);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj53 = caverphone0.encode((java.lang.Object) encoderException47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertArrayEquals(throwableArray45, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertArrayEquals(throwableArray48, new java.lang.Throwable[] {});
    }

    @Test
    public void test1617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1617");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen(48);
        java.lang.String str6 = metaphone0.metaphone("AK11111111");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "AK" + "'", str6, "AK");
    }

    @Test
    public void test1618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1618");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        org.apache.commons.codec.language.Metaphone metaphone8 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str10 = metaphone8.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone8.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone13.caverphone("hi!");
        java.lang.Object obj18 = metaphone8.encode((java.lang.Object) "hi!");
        int int19 = metaphone8.getMaxCodeLen();
        int int20 = metaphone8.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = refinedSoundex0.encode((java.lang.Object) int20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "ORKP" + "'", str10, "ORKP");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj18 + "' != '" + "H" + "'", obj18, "H");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
    }

    @Test
    public void test1619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1619");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        int int13 = metaphone0.getMaxCodeLen();
        java.lang.String str15 = metaphone0.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        boolean boolean18 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA", "AKPKSKMNS");
        char[] charArray19 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex20 = new org.apache.commons.codec.language.Soundex(charArray19);
        java.lang.String str22 = soundex20.soundex("AA11111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = metaphone0.encode((java.lang.Object) soundex20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKPXKMNSKTSNKTRKSSPXN" + "'", str15, "ORKPXKMNSKTSNKTRKSSPXN");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A000" + "'", str22, "A000");
    }

    @Test
    public void test1620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1620");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        int int23 = metaphone0.getMaxCodeLen();
        java.lang.String str25 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ARKPKSKMNS" + "'", str22, "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "ARKPKSKMNS" + "'", str25, "ARKPKSKMNS");
    }

    @Test
    public void test1621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1621");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        metaphone0.setMaxCodeLen((int) '3');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test1622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1622");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str12 = metaphone10.encode("");
        java.lang.Object obj13 = metaphone0.encode((java.lang.Object) "");
        int int14 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(65);
        java.lang.String str18 = metaphone0.encode("AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "" + "'", obj13, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKMNSK" + "'", str18, "AKPKMNSK");
    }

    @Test
    public void test1623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1623");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        java.lang.String str13 = metaphone0.encode("hi!");
        int int14 = metaphone0.getMaxCodeLen();
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "AKPKMNSKT");
        int int18 = metaphone0.getMaxCodeLen();
        java.lang.String str20 = metaphone0.encode("ARKPKKMNSK");
        java.lang.String str22 = metaphone0.encode("A09313836383693158931");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "ARKPKMNSK" + "'", str20, "ARKPKMNSK");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A" + "'", str22, "A");
    }

    @Test
    public void test1624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1624");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(10);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = soundex1.difference("O941", "R");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test1625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1625");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char31 = refinedSoundex29.getMappingCode('a');
        int int34 = refinedSoundex29.difference("", "hi!");
        char char36 = refinedSoundex29.getMappingCode('#');
        int int39 = refinedSoundex29.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj41 = refinedSoundex29.encode((java.lang.Object) "O941");
        java.lang.Object obj42 = caverphone0.encode(obj41);
        boolean boolean45 = caverphone0.isCaverphoneEqual("H000", "AA");
        java.lang.String str47 = caverphone0.encode("AA");
        java.lang.String str49 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        boolean boolean52 = caverphone0.isCaverphoneEqual("aORGAPACHECOMMONSCODECENCODEREXC", "A0621252");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(refinedSoundex29);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0" + "'", obj41, "O0");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "A111111111" + "'", obj42, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "AA11111111" + "'", str47, "AA11111111");
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "AKPKKMNSKT" + "'", str49, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test1626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1626");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("org.apache.commons.codec.EncoderException: AKPKKMNSKT", "");
        int int8 = soundex2.difference("", "ARKPKSKMNS");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone9.maxCodeLen = '0';
        java.lang.String str18 = doubleMetaphone9.doubleMetaphone("A", true);
        java.lang.String str20 = doubleMetaphone9.doubleMetaphone("org.apache.commons.codec.EncoderException: ");
        java.lang.String str22 = doubleMetaphone9.encode("ARKPXKMNSKTKNKTRKSPXN");
        java.lang.Object obj23 = soundex2.encode((java.lang.Object) str22);
        int int26 = soundex2.difference("", "AHIAM");
        java.lang.String str28 = soundex2.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A" + "'", str18, "A");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "ARKPXKMNSKTKNKTRKSPXN" + "'", str20, "ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ARKPKSKMNSKTKNKTRKSPKSN" + "'", str22, "ARKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + obj23 + "' != '" + "A621" + "'", obj23, "A621");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
    }

    @Test
    public void test1627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1627");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (short) 1);
        int int6 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (short) 10);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char11 = refinedSoundex9.getMappingCode('a');
        int int14 = refinedSoundex9.difference("", "hi!");
        int int17 = refinedSoundex9.difference("hi!", "");
        int int20 = refinedSoundex9.difference("hi!", "");
        java.lang.String str22 = refinedSoundex9.encode("AKPKMNSKT");
        java.lang.String str24 = refinedSoundex9.soundex("O0940103030808306030830609053016080");
        char char26 = refinedSoundex9.getMappingCode('\000');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = soundex1.encode((java.lang.Object) char26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(refinedSoundex9);
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '0' + "'", char11 == '0');
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A0313836" + "'", str22, "A0313836");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O0" + "'", str24, "O0");
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '\000' + "'", char26 == '\000');
    }

    @Test
    public void test1628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1628");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        java.lang.String str13 = metaphone0.encode("hi!");
        int int14 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 1);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test1629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1629");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        int int10 = soundex1.difference("1111111111", "01230120022455012623010202");
        int int11 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test1630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1630");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        boolean boolean16 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080", "H000");
        boolean boolean19 = metaphone0.isMetaphoneEqual("K000", "AK11111111");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test1631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1631");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: hi!", "AKP");
        soundex1.setMaxLength((int) '#');
        int int10 = soundex1.difference(" ", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str12 = soundex1.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test1632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1632");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        char char16 = doubleMetaphone9.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone9.new DoubleMetaphoneResult((int) '4');
        java.lang.String str19 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) str19);
        java.lang.String str22 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        java.lang.String str24 = caverphone0.encode("ARKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + 'i' + "'", char16 == 'i');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "1111111111" + "'", obj20, "1111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKMNSK11" + "'", str24, "AKPKMNSK11");
    }

    @Test
    public void test1633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1633");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        java.lang.String str23 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        int int24 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone25 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str27 = doubleMetaphone25.doubleMetaphone("H");
        doubleMetaphone25.setMaxCodeLen((int) (byte) 0);
        java.lang.String str32 = doubleMetaphone25.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult34 = doubleMetaphone25.new DoubleMetaphoneResult(0);
        java.lang.String str35 = doubleMetaphoneResult34.getPrimary();
        doubleMetaphoneResult34.append('1', 'a');
        boolean boolean39 = doubleMetaphoneResult34.isComplete();
        doubleMetaphoneResult34.append('O', 'a');
        doubleMetaphoneResult34.appendAlternate(" AKPK");
        doubleMetaphoneResult34.append("AKPKMNSK");
        java.lang.Object obj47 = metaphone0.encode((java.lang.Object) "AKPKMNSK");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str23, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertEquals("'" + obj47 + "' != '" + "AKPKMNSK" + "'", obj47, "AKPKMNSK");
    }

    @Test
    public void test1634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1634");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        java.lang.String str14 = metaphone0.encode("org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ORKPXKMNSK" + "'", str14, "ORKPXKMNSK");
    }

    @Test
    public void test1635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1635");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("r");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "R" + "'", str1, "R");
    }

    @Test
    public void test1636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1636");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str30 = doubleMetaphone28.doubleMetaphone("H");
        java.lang.String str32 = doubleMetaphone28.doubleMetaphone("HI");
        java.lang.String str34 = doubleMetaphone28.doubleMetaphone("AKPKMNSKT1");
        java.lang.Object obj35 = metaphone0.encode((java.lang.Object) str34);
        boolean boolean38 = metaphone0.isMetaphoneEqual("I", "4");
        java.lang.String str40 = metaphone0.encode("O09401030308083060308306090530160809315383");
        metaphone0.setMaxCodeLen(56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPK" + "'", str34, "AKPK");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "AKPK" + "'", obj35, "AKPK");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "O" + "'", str40, "O");
    }

    @Test
    public void test1637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1637");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        java.lang.String str19 = caverphone0.caverphone("ARKPXKMNSK");
        java.lang.String str21 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str23 = caverphone0.encode("A621");
        java.lang.String str25 = caverphone0.encode("ARKPKSKMNS");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSK11" + "'", str19, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKMNSKT1" + "'", str21, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A111111111" + "'", str23, "A111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "AKPKSKMNS1" + "'", str25, "AKPKSKMNS1");
    }

    @Test
    public void test1638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1638");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str4 = soundex2.soundex("H");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = soundex2.encode((java.lang.Object) 'e');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "H000" + "'", str4, "H000");
    }

    @Test
    public void test1639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1639");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("");
        java.lang.String str17 = refinedSoundex0.soundex("O09315383");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0" + "'", str17, "O0");
    }

    @Test
    public void test1640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1640");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O0940103030808306030830609053", "H");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1641");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("AKPKMNSKT");
        org.apache.commons.codec.language.Caverphone caverphone14 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str16 = caverphone14.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str18 = caverphone14.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone14.encode("");
        java.lang.String str22 = caverphone14.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone23 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone23.maxCodeLen = 0;
        char char28 = doubleMetaphone23.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult30 = doubleMetaphone23.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult30.appendAlternate('\000');
        java.lang.String str33 = doubleMetaphoneResult30.getAlternate();
        java.lang.String str34 = doubleMetaphoneResult30.getPrimary();
        java.lang.Object obj35 = caverphone14.encode((java.lang.Object) str34);
        java.lang.String str37 = caverphone14.caverphone("");
        int int40 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone14, "AKPKKMNSKT", "ORKP");
        java.lang.String str42 = caverphone14.encode("O0940103030808306030830609053016080940103030808306030830609053016080931");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = caverphone0.encode((java.lang.Object) caverphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKT1" + "'", str13, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKKMNSKT" + "'", str16, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "1111111111" + "'", str20, "1111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '\000' + "'", char28 == '\000');
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "1111111111" + "'", obj35, "1111111111");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "1111111111" + "'", str37, "1111111111");
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "A111111111" + "'", str42, "A111111111");
    }

    @Test
    public void test1642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1642");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("AHIO");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AHIO" + "'", str1, "AHIO");
    }

    @Test
    public void test1643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1643");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex5.setMaxLength(0);
        soundex5.setMaxLength(1);
        int int12 = soundex5.difference(" ", "A111111111");
        soundex5.setMaxLength((int) 'O');
        char[] charArray19 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex20 = new org.apache.commons.codec.language.RefinedSoundex(charArray19);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex21 = new org.apache.commons.codec.language.RefinedSoundex(charArray19);
        org.apache.commons.codec.language.Soundex soundex22 = new org.apache.commons.codec.language.Soundex(charArray19);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex23 = new org.apache.commons.codec.language.RefinedSoundex(charArray19);
        org.apache.commons.codec.language.Soundex soundex24 = new org.apache.commons.codec.language.Soundex(charArray19);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = soundex5.encode((java.lang.Object) charArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertArrayEquals(charArray19, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1644");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        soundex1.setMaxLength(0);
        int int14 = soundex1.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ");
        java.lang.String str16 = soundex1.encode("A111111111O620");
        int int19 = soundex1.difference("A0313", "A621HIo");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A000" + "'", str16, "A000");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test1645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1645");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A1111111114r", "org.apache.commons.codec.EncoderException: org.ap");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1646");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str7 = soundex2.encode("AKPKKMNSKT");
        int int10 = soundex2.difference("hi!", "A0");
        int int13 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex2, "O0931538363836931589313836383693138", "org.apache.commons.codec.Encoder");
        java.lang.String str15 = soundex2.encode("AKPKMNSK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A313" + "'", str7, "A313");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A313" + "'", str15, "A313");
    }

    @Test
    public void test1647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1647");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        int int14 = metaphone0.getMaxCodeLen();
        int int15 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 0);
        java.lang.String str19 = metaphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
    }

    @Test
    public void test1648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1648");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: A000", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test1649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1649");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str9 = metaphone0.metaphone("4");
        java.lang.String str11 = metaphone0.encode("ARKPKKMNSK");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("ARKPXKMNSKTKNKTRKSPXN");
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("A0931");
        encoderException13.addSuppressed((java.lang.Throwable) encoderException15);
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray19 = encoderException18.getSuppressed();
        java.lang.Throwable[] throwableArray20 = encoderException18.getSuppressed();
        encoderException15.addSuppressed((java.lang.Throwable) encoderException18);
        java.lang.Throwable[] throwableArray22 = encoderException18.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = metaphone0.encode((java.lang.Object) throwableArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "4" + "'", str9, "4");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertArrayEquals(throwableArray19, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertArrayEquals(throwableArray20, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertArrayEquals(throwableArray22, new java.lang.Throwable[] {});
    }

    @Test
    public void test1650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1650");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            int int8 = soundex5.difference("ARKP", "A600");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test1651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1651");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode(' ');
        char char9 = refinedSoundex0.getMappingCode('a');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
    }

    @Test
    public void test1652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1652");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex9.setMaxLength((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex9.soundex("AK11111111");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1653");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj12 = refinedSoundex0.encode((java.lang.Object) "O941");
        char char14 = refinedSoundex0.getMappingCode('0');
        java.lang.String str16 = refinedSoundex0.encode("ARKPKKMNSKTKNKTRKSPXNRKP");
        java.lang.String str18 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "O0" + "'", obj12, "O0");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A09313836383693158931" + "'", str16, "A09313836383693158931");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0940103030808306030830609053016080940103030808306030830609053016080" + "'", str18, "O0940103030808306030830609053016080940103030808306030830609053016080");
    }

    @Test
    public void test1654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1654");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        boolean boolean14 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: org.ap", "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test1655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1655");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        org.apache.commons.codec.language.Caverphone caverphone2 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str4 = caverphone2.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone2.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str8 = caverphone2.encode("");
        java.lang.String str10 = caverphone2.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean13 = caverphone2.isCaverphoneEqual("ORKPXKMNSK", "A031");
        java.lang.String str15 = caverphone2.caverphone("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = soundex0.encode((java.lang.Object) caverphone2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "AKPKKMNSKT" + "'", str6, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKMNSKTK" + "'", str15, "AKPKMNSKTK");
    }

    @Test
    public void test1656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1656");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "A ");
        boolean boolean14 = metaphone0.isMetaphoneEqual("ORKPXKMNSKTSNKTRKSSPXN", "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test1657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1657");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("HI");
        java.lang.String str16 = metaphone0.encode("A212");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str19 = doubleMetaphone17.doubleMetaphone("H");
        doubleMetaphone17.setMaxCodeLen((int) (byte) 0);
        java.lang.String str24 = doubleMetaphone17.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult26 = doubleMetaphone17.new DoubleMetaphoneResult(0);
        int int27 = doubleMetaphone17.maxCodeLen;
        java.lang.String str29 = doubleMetaphone17.encode("org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        java.lang.Object obj30 = metaphone0.encode((java.lang.Object) str29);
        int int31 = metaphone0.getMaxCodeLen();
        java.lang.String str33 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "H" + "'", str14, "H");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "" + "'", obj30, "");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "ORK" + "'", str33, "ORK");
    }

    @Test
    public void test1658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1658");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean22 = caverphone0.isCaverphoneEqual("A#", "AKP1111111");
        java.lang.String str24 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        boolean boolean27 = caverphone0.isCaverphoneEqual("ORK", "");
        java.lang.String str29 = caverphone0.encode("A111111111");
        java.lang.String str31 = caverphone0.caverphone("A931");
        java.lang.String str33 = caverphone0.caverphone("O0940103030808306030830609053016080");
        java.lang.Object obj35 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "A111111111" + "'", str31, "A111111111");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "A111111111" + "'", str33, "A111111111");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "AKPKKMNSKT" + "'", obj35, "AKPKKMNSKT");
    }

    @Test
    public void test1659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1659");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean13 = caverphone0.isCaverphoneEqual("A1111111114r", "ORKP");
        org.apache.commons.codec.language.Metaphone metaphone14 = new org.apache.commons.codec.language.Metaphone();
        metaphone14.setMaxCodeLen(3);
        int int17 = metaphone14.getMaxCodeLen();
        metaphone14.setMaxCodeLen((int) (byte) 1);
        metaphone14.setMaxCodeLen((int) (byte) -1);
        boolean boolean24 = metaphone14.isMetaphoneEqual("O0940103030808306030830609053016080940103030808306030830609053016080", "01");
        java.lang.Object obj25 = caverphone0.encode((java.lang.Object) "01");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
    }

    @Test
    public void test1660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1660");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        java.lang.String str18 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A0");
        int int19 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORKPXKMNSK" + "'", str18, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test1661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1661");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        java.lang.String str23 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        metaphone0.setMaxCodeLen(0);
        java.lang.Class<?> wildcardClass26 = metaphone0.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str23, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test1662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1662");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str25 = caverphone0.caverphone("H0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A111111111" + "'", str25, "A111111111");
    }

    @Test
    public void test1663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1663");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.encode("H");
        java.lang.String str15 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
    }

    @Test
    public void test1664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1664");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex24 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char26 = refinedSoundex24.getMappingCode('a');
        int int29 = refinedSoundex24.difference("", "hi!");
        int int32 = refinedSoundex24.difference("", "A");
        java.lang.Object obj33 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str35 = caverphone0.caverphone("O0940103030808306030830609053016080940103030808306030830609053016080931");
        boolean boolean38 = caverphone0.isCaverphoneEqual("4", "O0931");
        char[] charArray40 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex41 = new org.apache.commons.codec.language.RefinedSoundex(charArray40);
        org.apache.commons.codec.language.Soundex soundex42 = new org.apache.commons.codec.language.Soundex(charArray40);
        org.apache.commons.codec.language.Soundex soundex43 = new org.apache.commons.codec.language.Soundex(charArray40);
        org.apache.commons.codec.language.Soundex soundex44 = new org.apache.commons.codec.language.Soundex(charArray40);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj45 = caverphone0.encode((java.lang.Object) charArray40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex24);
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "1111111111" + "'", obj33, "1111111111");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "A111111111" + "'", str35, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertArrayEquals(charArray40, new char[] { 'a' });
    }

    @Test
    public void test1665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1665");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        char char16 = doubleMetaphone9.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone9.new DoubleMetaphoneResult((int) '4');
        java.lang.String str19 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) str19);
        java.lang.String str22 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        java.lang.String str24 = caverphone0.caverphone("01230120022455012623010202");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + 'i' + "'", char16 == 'i');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "1111111111" + "'", obj20, "1111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
    }

    @Test
    public void test1666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1666");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str6 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "HI", "A");
        char char11 = refinedSoundex0.getMappingCode('O');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080" + "'", str4, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O0" + "'", str6, "O0");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '0' + "'", char11 == '0');
    }

    @Test
    public void test1667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1667");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        soundex3.setMaxLength(2);
        java.lang.String str16 = soundex3.soundex("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSKTSNKTRKSPKSNRKPR");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A621" + "'", str16, "A621");
    }

    @Test
    public void test1668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1668");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode(' ');
        char char9 = refinedSoundex0.getMappingCode('\000');
        org.apache.commons.codec.EncoderException encoderException11 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray12 = encoderException11.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = refinedSoundex0.encode((java.lang.Object) throwableArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertArrayEquals(throwableArray12, new java.lang.Throwable[] {});
    }

    @Test
    public void test1669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1669");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.soundex("A0931");
        java.lang.String str13 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A ");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0940103030808306030830609053016080" + "'", str13, "O0940103030808306030830609053016080");
    }

    @Test
    public void test1670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1670");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        java.lang.String str10 = caverphone0.caverphone("");
        java.lang.String str12 = caverphone0.encode("AKPKSKMNS1");
        boolean boolean15 = caverphone0.isCaverphoneEqual("A111111111O000", "org.apache.commons.codec.EncoderException: A0931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "1111111111" + "'", str10, "1111111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKSKMNS1" + "'", str12, "AKPKSKMNS1");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test1671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1671");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        int int17 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str21 = metaphone0.encode("A621");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
    }

    @Test
    public void test1672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1672");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        int int3 = soundex0.difference("H", "");
        int int4 = soundex0.getMaxLength();
        soundex0.setMaxLength((int) '8');
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test1673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1673");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("H", "A");
        char char13 = refinedSoundex0.getMappingCode('a');
        char[] charArray14 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex15 = new org.apache.commons.codec.language.Soundex(charArray14);
        soundex15.setMaxLength(1);
        int int18 = soundex15.getMaxLength();
        java.lang.String str20 = soundex15.encode("O0940103030808306030830609053016080931");
        java.lang.Object obj21 = refinedSoundex0.encode((java.lang.Object) "O0940103030808306030830609053016080931");
        int int24 = refinedSoundex0.difference("I000", "HI");
        int int27 = refinedSoundex0.difference("OA1111111114r", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        char char29 = refinedSoundex0.getMappingCode('A');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O000" + "'", str20, "O000");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "O0" + "'", obj21, "O0");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '0' + "'", char29 == '0');
    }

    @Test
    public void test1674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1674");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        soundex0.setMaxLength((int) '8');
        java.lang.String str14 = soundex0.encode("A093153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A000" + "'", str14, "A000");
    }

    @Test
    public void test1675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1675");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTSNKTRKSSPXN", "Aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1676");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int9 = soundex4.difference("AKP1111111", "AKPK");
        org.apache.commons.codec.EncoderException encoderException11 = new org.apache.commons.codec.EncoderException("A0931");
        java.lang.Throwable[] throwableArray12 = encoderException11.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException14 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray15 = encoderException14.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException17 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException14.addSuppressed((java.lang.Throwable) encoderException17);
        encoderException11.addSuppressed((java.lang.Throwable) encoderException14);
        java.lang.Throwable[] throwableArray20 = encoderException14.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException22 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray23 = encoderException22.getSuppressed();
        java.lang.Throwable[] throwableArray24 = encoderException22.getSuppressed();
        java.lang.Throwable[] throwableArray25 = encoderException22.getSuppressed();
        encoderException14.addSuppressed((java.lang.Throwable) encoderException22);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = soundex4.encode((java.lang.Object) encoderException22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertArrayEquals(throwableArray12, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertArrayEquals(throwableArray15, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertArrayEquals(throwableArray23, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertArrayEquals(throwableArray24, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertArrayEquals(throwableArray25, new java.lang.Throwable[] {});
    }

    @Test
    public void test1677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1677");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        metaphone0.setMaxCodeLen((int) (short) 0);
        metaphone0.setMaxCodeLen((int) 'H');
        metaphone0.setMaxCodeLen((int) 'r');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test1678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1678");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        java.lang.String str10 = soundex4.encode(" AKPK");
        int int11 = soundex4.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A212" + "'", str10, "A212");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test1679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1679");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        int int11 = soundex0.difference("H000", "HI");
        int int12 = soundex0.getMaxLength();
        int int15 = soundex0.difference("org.apache.commons.codec.EncoderException: AK11111111", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test1680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1680");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.soundex("HI");
        java.lang.String str9 = refinedSoundex0.encode("hi!");
        int int12 = refinedSoundex0.difference("A621", "");
        java.lang.String str14 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str16 = refinedSoundex0.soundex("A1111111114r");
        java.lang.String[] strArray20 = new java.lang.String[] {};
        boolean boolean21 = org.apache.commons.codec.language.DoubleMetaphone.contains("01230120022455012623010202", (int) 'a', (int) (short) 0, strArray20);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) boolean21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H0" + "'", str9, "H0");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O0940103030808306030830609053016080" + "'", str14, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A09" + "'", str16, "A09");
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertArrayEquals(strArray20, new java.lang.String[] {});
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test1681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1681");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: AA11111111");
        org.apache.commons.codec.EncoderException encoderException17 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        encoderException15.addSuppressed((java.lang.Throwable) encoderException17);
        java.lang.Throwable[] throwableArray19 = encoderException17.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = refinedSoundex0.encode((java.lang.Object) throwableArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertArrayEquals(throwableArray19, new java.lang.Throwable[] {});
    }

    @Test
    public void test1682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1682");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.encode("O09315383638369315893153836383693158");
        int int13 = soundex0.difference("org.apache.commons.codec.EncoderException: 01230120022455012623010202", "ORKPXKMNSKTSNKTRKSSPXNRKP");
        soundex0.setMaxLength((int) 'A');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test1683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1683");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int3 = soundex0.difference("A1", " ");
        int int6 = soundex0.difference("A0", "A");
        java.lang.String str8 = soundex0.soundex("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        int int11 = soundex0.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "org.apache.commons.codec.EncoderException: HI");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O621" + "'", str8, "O621");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test1684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1684");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.caverphone("01230120022455012623010202");
        boolean boolean28 = caverphone0.isCaverphoneEqual("", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test1685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1685");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        org.apache.commons.codec.language.Metaphone metaphone23 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str25 = metaphone23.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = refinedSoundex0.encode((java.lang.Object) metaphone23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
    }

    @Test
    public void test1686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1686");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        char char13 = refinedSoundex0.getMappingCode('4');
        java.lang.String str15 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0940103030808306030830609053016080940103030808306030830609053016080" + "'", str15, "O0940103030808306030830609053016080940103030808306030830609053016080");
    }

    @Test
    public void test1687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1687");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        soundex0.setMaxLength(0);
        int int13 = soundex0.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHIM", "A031");
        java.lang.String str15 = soundex0.encode("O0621");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O000" + "'", str15, "O000");
    }

    @Test
    public void test1688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1688");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.soundex("A0313836");
        int int13 = soundex0.difference("ARKP", "A0");
        java.lang.String str15 = soundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O621" + "'", str15, "O621");
    }

    @Test
    public void test1689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1689");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean12 = metaphone0.isMetaphoneEqual("A621", "");
        boolean boolean15 = metaphone0.isMetaphoneEqual("AKPKKMNSKT", "A111111111");
        java.lang.String str17 = metaphone0.metaphone("");
        java.lang.String str19 = metaphone0.encode("");
        java.lang.String str21 = metaphone0.encode("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone22.maxCodeLen = 0;
        boolean boolean28 = doubleMetaphone22.isDoubleMetaphoneEqual("O000", "A ", true);
        doubleMetaphone22.setMaxCodeLen((int) '4');
        boolean boolean34 = doubleMetaphone22.isDoubleMetaphoneEqual("ORKP", "H000", false);
        char char37 = doubleMetaphone22.charAt("", (int) '0');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj38 = metaphone0.encode((java.lang.Object) '0');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + char37 + "' != '" + '\000' + "'", char37 == '\000');
    }

    @Test
    public void test1690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1690");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int6 = refinedSoundex3.difference("O0931", "");
        java.lang.String str8 = refinedSoundex3.soundex("H0");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "H0" + "'", str8, "H0");
    }

    @Test
    public void test1691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1691");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        java.lang.String str12 = metaphone0.encode("A111111111O620");
        java.lang.String str14 = metaphone0.encode("A313");
        java.lang.String str16 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: org.ap");
        java.lang.String str18 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: O000");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A" + "'", str14, "A");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORK" + "'", str16, "ORK");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORK" + "'", str18, "ORK");
    }

    @Test
    public void test1692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1692");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.metaphone("O000");
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) "O000");
        java.lang.String str22 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        boolean boolean25 = caverphone0.isCaverphoneEqual("", "O094010303080830603083060905301608");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "A111111111" + "'", obj20, "A111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test1693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1693");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        doubleMetaphone0.setMaxCodeLen((int) (short) 0);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test1694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1694");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: ARK", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1695");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded(" AKPK", "org.apache.commons.codec.EncoderException: ARKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1696");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "ORKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1697");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("A031");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test1698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1698");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        boolean boolean12 = metaphone0.isMetaphoneEqual("K", "");
        java.lang.String str14 = metaphone0.encode("");
        java.lang.String str16 = metaphone0.encode("org.apache.commons.codec.EncoderException: A621HI");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORK" + "'", str16, "ORK");
    }

    @Test
    public void test1699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1699");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        java.lang.String str11 = soundex1.encode("org.apache.commons.codec.EncoderException: hi!");
        int int14 = soundex1.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "01230120022455012623010202");
        int int15 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O941" + "'", str11, "O941");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test1700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1700");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        char char9 = refinedSoundex7.getMappingCode('A');
        java.lang.String str11 = refinedSoundex7.encode("A09");
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + ' ' + "'", char9 == ' ');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A " + "'", str11, "A ");
    }

    @Test
    public void test1701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1701");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        int int8 = refinedSoundex0.difference("i0a", "org.apache.commons.codec.EncoderException: A0");
        java.lang.String str10 = refinedSoundex0.soundex("ARKPKKMNSKTKNKTRKSPXNRKP");
        java.lang.String str12 = refinedSoundex0.encode("KP");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A09313836383693158931" + "'", str10, "A09313836383693158931");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "K31" + "'", str12, "K31");
    }

    @Test
    public void test1702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1702");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (short) 1);
        int int6 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            int int11 = soundex1.difference("ORKPXKMNSKTSNKTRKSSPXNRKP", "org.apache.commons.codec.EncoderException: AK11111111");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test1703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1703");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = refinedSoundex5.soundex("org.apache.commons.codec.EncoderException: A0931383");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1704");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("K");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "K" + "'", str1, "K");
    }

    @Test
    public void test1705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1705");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORKPXKMNSK", "A031");
        boolean boolean14 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ", "AR");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test1706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1706");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("AKP1111111", "O000");
        java.lang.String[] strArray24 = new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" };
        boolean boolean25 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 1, (int) (short) 1, strArray24);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = refinedSoundex0.encode((java.lang.Object) boolean25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertArrayEquals(strArray24, new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" });
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test1707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1707");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        java.lang.String str10 = caverphone0.caverphone("");
        java.lang.String str12 = caverphone0.encode("org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "1111111111" + "'", str10, "1111111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
    }

    @Test
    public void test1708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1708");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.soundex("HI");
        java.lang.String str9 = refinedSoundex0.encode("hi!");
        int int12 = refinedSoundex0.difference("A621", "");
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj16 = refinedSoundex0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: HI");
        char char18 = refinedSoundex0.getMappingCode('a');
        java.lang.String str20 = refinedSoundex0.encode("r");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H0" + "'", str9, "H0");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + obj16 + "' != '" + "O0940103030808306030830609053016080" + "'", obj16, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '0' + "'", char18 == '0');
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "R9" + "'", str20, "R9");
    }

    @Test
    public void test1709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1709");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        int int10 = soundex1.difference("1111111111", "01230120022455012623010202");
        int int13 = soundex1.difference("K111111111", "ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str15 = soundex1.encode("O0940103030808306030830609");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O000" + "'", str15, "O000");
    }

    @Test
    public void test1710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1710");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("K120");
        java.lang.String str12 = caverphone0.encode("ORK");
        java.lang.String str14 = caverphone0.encode("O0931538363836931589313836383693138");
        boolean boolean17 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: AKPKKMNSKT", "H0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "K111111111" + "'", str10, "K111111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AK11111111" + "'", str12, "AK11111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A111111111" + "'", str14, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test1711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1711");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        java.lang.String str12 = metaphone0.encode("AA11111111");
        metaphone0.setMaxCodeLen(32);
        java.lang.String str16 = metaphone0.metaphone("ARKPKKMNSKTKNKTRKSPXNRKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKPKMNSKTKNKTRKSPKSNRKP" + "'", str16, "ARKPKMNSKTKNKTRKSPKSNRKP");
    }

    @Test
    public void test1712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1712");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        java.lang.String str26 = refinedSoundex0.encode("O093");
        char char28 = refinedSoundex0.getMappingCode('a');
        java.lang.String str30 = refinedSoundex0.soundex("A000a");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O0940103030808306030830609053016080" + "'", str24, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "O0" + "'", str26, "O0");
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '0' + "'", char28 == '0');
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "A0" + "'", str30, "A0");
    }

    @Test
    public void test1713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1713");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        int int11 = soundex0.difference("H000", "HI");
        int int12 = soundex0.getMaxLength();
        java.lang.String str14 = soundex0.encode("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O621" + "'", str14, "O621");
    }

    @Test
    public void test1714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1714");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("");
        boolean boolean30 = caverphone0.isCaverphoneEqual("ARKPKSKMNSK", "AA");
        java.lang.String str32 = caverphone0.caverphone("aORGAPACHECOMMONSCODECENCODEREXC");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "1111111111" + "'", str27, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKPKKMNSKT" + "'", str32, "AKPKKMNSKT");
    }

    @Test
    public void test1715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1715");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        java.lang.String str8 = soundex1.encode("O0940103030808306030830609053");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O000" + "'", str8, "O000");
    }

    @Test
    public void test1716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1716");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: A000");
        boolean boolean15 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: O620", "A0");
        boolean boolean18 = caverphone0.isCaverphoneEqual("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSNi", "A621HI0A093138363836931589313836383693158M");
        org.apache.commons.codec.EncoderException encoderException20 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException22 = new org.apache.commons.codec.EncoderException("HI");
        encoderException20.addSuppressed((java.lang.Throwable) encoderException22);
        java.lang.Throwable[] throwableArray24 = encoderException22.getSuppressed();
        java.lang.Throwable[] throwableArray25 = encoderException22.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException27 = new org.apache.commons.codec.EncoderException("ARKPXKMNSKTKNKTRKSPXN");
        org.apache.commons.codec.EncoderException encoderException29 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray30 = encoderException29.getSuppressed();
        java.lang.Throwable[] throwableArray31 = encoderException29.getSuppressed();
        encoderException27.addSuppressed((java.lang.Throwable) encoderException29);
        encoderException22.addSuppressed((java.lang.Throwable) encoderException27);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = caverphone0.encode((java.lang.Object) encoderException27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertArrayEquals(throwableArray24, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertArrayEquals(throwableArray25, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertArrayEquals(throwableArray30, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertArrayEquals(throwableArray31, new java.lang.Throwable[] {});
    }

    @Test
    public void test1717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1717");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        java.lang.String str5 = refinedSoundex3.soundex("A000");
        java.lang.String str7 = refinedSoundex3.encode("4");
        // The following exception was thrown during execution in test generation
        try {
            int int10 = refinedSoundex3.difference("", "K31");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A1" + "'", str5, "A1");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test1718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1718");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: AK11111111");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAK" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAK");
    }

    @Test
    public void test1719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1719");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPXKMNSKTKNKTRKSPXNKPK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPXKMNSKTKNKTRKSPXNKPK" + "'", str1, "ARKPXKMNSKTKNKTRKSPXNKPK");
    }

    @Test
    public void test1720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1720");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: i0a");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONIA" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONIA");
    }

    @Test
    public void test1721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1721");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        int int10 = soundex1.difference("1111111111", "01230120022455012623010202");
        int int13 = soundex1.difference("A093153836383693158", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        soundex1.setMaxLength(3);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1722");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex9.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex9.soundex("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSKTSNKTRKSPKSNRKPR");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1723");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: AK11111111", "A0313");
        soundex1.setMaxLength((int) (byte) -1);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test1724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1724");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        java.lang.String str13 = caverphone0.encode(" ");
        java.lang.String str15 = caverphone0.encode("ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKT");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKMNSKTK" + "'", str15, "AKPKMNSKTK");
    }

    @Test
    public void test1725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1725");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) (short) 0);
        int int8 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex();
        char char11 = refinedSoundex9.getMappingCode('0');
        int int14 = refinedSoundex9.difference("O0", "O0");
        java.lang.String str16 = refinedSoundex9.soundex("HI");
        java.lang.Object obj17 = doubleMetaphone0.encode((java.lang.Object) "HI");
        doubleMetaphone0.setMaxCodeLen(38);
        char char22 = doubleMetaphone0.charAt("AHIAM", (int) (short) 1);
        java.lang.String str24 = doubleMetaphone0.encode("ARK");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '\000' + "'", char11 == '\000');
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "H0" + "'", str16, "H0");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "" + "'", obj17, "");
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + 'H' + "'", char22 == 'H');
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ARK" + "'", str24, "ARK");
    }

    @Test
    public void test1726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1726");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str16 = doubleMetaphone14.doubleMetaphone("H");
        boolean boolean20 = doubleMetaphone14.isDoubleMetaphoneEqual("ORKP", "O0931", false);
        java.lang.String str23 = doubleMetaphone14.doubleMetaphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0", false);
        java.lang.Object obj24 = refinedSoundex0.encode((java.lang.Object) str23);
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ARKP" + "'", str23, "ARKP");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "A0931" + "'", obj24, "A0931");
    }

    @Test
    public void test1727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1727");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        int int19 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone20 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str22 = doubleMetaphone20.doubleMetaphone("H");
        doubleMetaphone20.setMaxCodeLen((int) (byte) 0);
        char char27 = doubleMetaphone20.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult29 = doubleMetaphone20.new DoubleMetaphoneResult((int) '4');
        java.lang.String str30 = doubleMetaphoneResult29.getAlternate();
        doubleMetaphoneResult29.appendPrimary("O0931");
        doubleMetaphoneResult29.append("org.apache.commons.codec.EncoderException: O000", "ORK");
        java.lang.Object obj36 = metaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O000");
        java.lang.String str38 = metaphone0.metaphone("AA11111111");
        metaphone0.setMaxCodeLen((int) 'o');
        metaphone0.setMaxCodeLen(79);
        boolean boolean45 = metaphone0.isMetaphoneEqual("0", "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + 'i' + "'", char27 == 'i');
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + obj36 + "' != '" + "ORKPXKMNSK" + "'", obj36, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "A" + "'", str38, "A");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test1728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1728");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.metaphone("O000");
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) "O000");
        org.apache.commons.codec.EncoderException encoderException22 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray23 = encoderException22.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException25 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException27 = new org.apache.commons.codec.EncoderException("");
        encoderException25.addSuppressed((java.lang.Throwable) encoderException27);
        encoderException22.addSuppressed((java.lang.Throwable) encoderException27);
        org.apache.commons.codec.EncoderException encoderException31 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        encoderException27.addSuppressed((java.lang.Throwable) encoderException31);
        org.apache.commons.codec.EncoderException encoderException34 = new org.apache.commons.codec.EncoderException("A0");
        encoderException27.addSuppressed((java.lang.Throwable) encoderException34);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = caverphone0.encode((java.lang.Object) encoderException27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "A111111111" + "'", obj20, "A111111111");
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertArrayEquals(throwableArray23, new java.lang.Throwable[] {});
    }

    @Test
    public void test1729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1729");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        int int16 = refinedSoundex0.difference("A000", "01230120022455012623010202");
        int int19 = refinedSoundex0.difference("AKPK", "AKP1111111");
        java.lang.String str21 = refinedSoundex0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone22.maxCodeLen = '\000';
        char char27 = doubleMetaphone22.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult29 = doubleMetaphone22.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult29.appendPrimary('#');
        boolean boolean32 = doubleMetaphoneResult29.isComplete();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "O09315383638369315893153836383693158" + "'", str21, "O09315383638369315893153836383693158");
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '\000' + "'", char27 == '\000');
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test1730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1730");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("");
        boolean boolean10 = metaphone0.isMetaphoneEqual("", "H");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str15 = doubleMetaphone13.doubleMetaphone("H");
        doubleMetaphone13.setMaxCodeLen((int) (byte) 0);
        java.lang.String str20 = doubleMetaphone13.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult22 = doubleMetaphone13.new DoubleMetaphoneResult(0);
        int int23 = doubleMetaphone13.maxCodeLen;
        java.lang.String str25 = doubleMetaphone13.encode("O941");
        int int26 = doubleMetaphone13.maxCodeLen;
        java.lang.String str28 = doubleMetaphone13.encode("org.apache.commons.codec.EncoderException: org.ap");
        java.lang.Object obj29 = metaphone0.encode((java.lang.Object) str28);
        java.lang.String str31 = metaphone0.metaphone("i0a");
        metaphone0.setMaxCodeLen((int) 'A');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "" + "'", obj29, "");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "I" + "'", str31, "I");
    }

    @Test
    public void test1731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1731");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("O093", "AKP1111111");
        java.lang.String str18 = caverphone0.encode("RKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "KPKMNSKTKN" + "'", str18, "KPKMNSKTKN");
    }

    @Test
    public void test1732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1732");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str17 = refinedSoundex0.soundex("O621");
        java.lang.String str19 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125");
        char[] charArray20 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex21 = new org.apache.commons.codec.language.Soundex(charArray20);
        org.apache.commons.codec.language.Soundex soundex22 = new org.apache.commons.codec.language.Soundex(charArray20);
        org.apache.commons.codec.language.Soundex soundex23 = new org.apache.commons.codec.language.Soundex(charArray20);
        org.apache.commons.codec.language.Soundex soundex24 = new org.apache.commons.codec.language.Soundex(charArray20);
        org.apache.commons.codec.language.Soundex soundex25 = new org.apache.commons.codec.language.Soundex(charArray20);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex26 = new org.apache.commons.codec.language.RefinedSoundex(charArray20);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = refinedSoundex0.encode((java.lang.Object) charArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0940103030808306030830609053016080931" + "'", str15, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0" + "'", str17, "O0");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0940103030808306030830609053016080" + "'", str19, "O0940103030808306030830609053016080");
        org.junit.Assert.assertNotNull(charArray20);
    }

    @Test
    public void test1733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1733");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        int int16 = metaphone13.getMaxCodeLen();
        boolean boolean19 = metaphone13.isMetaphoneEqual("", "");
        boolean boolean22 = metaphone13.isMetaphoneEqual("01230120022455012623010202", "");
        int int25 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone13, "01230120022455012623010202", "");
        java.lang.String str27 = metaphone13.encode("O093");
        boolean boolean30 = metaphone13.isMetaphoneEqual("A313", "org.apache.commons.codec.EncoderException: ");
        java.lang.String str32 = metaphone13.metaphone("O620");
        java.lang.Object obj33 = metaphone0.encode((java.lang.Object) str32);
        boolean boolean36 = metaphone0.isMetaphoneEqual("AKPKMNSK11", "");
        java.lang.String str38 = metaphone0.metaphone(" ");
        boolean boolean41 = metaphone0.isMetaphoneEqual("A0621252", "K120");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "O" + "'", str27, "O");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "O" + "'", str32, "O");
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "O" + "'", obj33, "O");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + " " + "'", str38, " ");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test1734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1734");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int6 = soundex2.getMaxLength();
        java.lang.String str8 = soundex2.encode("A062125232523621256212523252362125");
        soundex2.setMaxLength(3);
        java.lang.String str12 = soundex2.soundex("org.apache.commons.codec.EncoderException: O000");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O941" + "'", str12, "O941");
    }

    @Test
    public void test1735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1735");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.encode("A");
        java.lang.String str8 = refinedSoundex4.soundex("O093");
        int int11 = refinedSoundex4.difference("ARKPKMNSK", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A0" + "'", str6, "A0");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O0" + "'", str8, "O0");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
    }

    @Test
    public void test1736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1736");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        int int28 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "", "");
        boolean boolean31 = caverphone0.isCaverphoneEqual("", "ARKP");
        java.lang.String str33 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        java.lang.String str35 = caverphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "AKPKKMNSKT" + "'", str33, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "1111111111" + "'", str35, "1111111111");
    }

    @Test
    public void test1737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1737");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1738");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        soundex4.setMaxLength((int) 'O');
        java.lang.String str12 = soundex4.encode("");
        java.lang.String str14 = soundex4.encode("#");
        java.lang.String str16 = soundex4.encode("A09");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A000" + "'", str16, "A000");
    }

    @Test
    public void test1739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1739");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        java.lang.String str10 = soundex4.encode(" AKPK");
        java.lang.String str12 = soundex4.encode("Aa");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A212" + "'", str10, "A212");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A000" + "'", str12, "A000");
    }

    @Test
    public void test1740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1740");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.encode("O09315383638369315893153836383693158931");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone5 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str7 = doubleMetaphone5.doubleMetaphone("H");
        java.lang.String str9 = doubleMetaphone5.doubleMetaphone("");
        doubleMetaphone5.setMaxCodeLen((int) (byte) 100);
        java.lang.String str13 = doubleMetaphone5.doubleMetaphone("HI");
        doubleMetaphone5.maxCodeLen = (short) 10;
        doubleMetaphone5.setMaxCodeLen(65);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = metaphone0.encode((java.lang.Object) 65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
    }

    @Test
    public void test1741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1741");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSK" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSK");
    }

    @Test
    public void test1742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1742");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength(100);
        java.lang.String str11 = soundex1.soundex("1111111111");
        soundex1.setMaxLength((int) (short) 0);
        org.apache.commons.codec.language.Metaphone metaphone14 = new org.apache.commons.codec.language.Metaphone();
        metaphone14.setMaxCodeLen(3);
        int int17 = metaphone14.getMaxCodeLen();
        boolean boolean20 = metaphone14.isMetaphoneEqual("", "");
        boolean boolean23 = metaphone14.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean26 = metaphone14.isMetaphoneEqual("A621", "");
        boolean boolean29 = metaphone14.isMetaphoneEqual("AKPKKMNSKT", "A111111111");
        java.lang.String str31 = metaphone14.metaphone("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = soundex1.encode((java.lang.Object) metaphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
    }

    @Test
    public void test1743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1743");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.Object obj9 = doubleMetaphone0.encode((java.lang.Object) "ORKP");
        doubleMetaphone0.maxCodeLen = 0;
        boolean boolean14 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "ARKP");
        java.lang.String str17 = doubleMetaphone0.doubleMetaphone("org.apache.commons.codec.EncoderException: HI", true);
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("AKPKMNSK11", "1111111111");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex21 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char23 = refinedSoundex21.getMappingCode('a');
        int int26 = refinedSoundex21.difference("", "hi!");
        int int29 = refinedSoundex21.difference("", "A");
        int int32 = refinedSoundex21.difference("O", "AK11111111");
        java.lang.String str34 = refinedSoundex21.soundex("org.apache.commons.codec.EncoderException: O620");
        java.lang.Object obj35 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O620");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(refinedSoundex21);
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '0' + "'", char23 == '0');
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "O0940103030808306030830609053016080" + "'", str34, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "" + "'", obj35, "");
    }

    @Test
    public void test1744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1744");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str8 = metaphone0.encode("");
        int int9 = metaphone0.getMaxCodeLen();
        int int10 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(79);
        metaphone0.setMaxCodeLen(4);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test1745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1745");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("");
        java.lang.String str12 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "1111111111" + "'", str10, "1111111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
    }

    @Test
    public void test1746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1746");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str30 = doubleMetaphone28.doubleMetaphone("H");
        java.lang.String str32 = doubleMetaphone28.doubleMetaphone("HI");
        java.lang.String str34 = doubleMetaphone28.doubleMetaphone("AKPKMNSKT1");
        java.lang.Object obj35 = metaphone0.encode((java.lang.Object) str34);
        metaphone0.setMaxCodeLen((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPK" + "'", str34, "AKPK");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "AKPK" + "'", obj35, "AKPK");
    }

    @Test
    public void test1747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1747");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        char char6 = refinedSoundex0.getMappingCode('A');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = 0;
        char char12 = doubleMetaphone7.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean16 = doubleMetaphone7.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char19 = doubleMetaphone7.charAt("01230120022455012623010202", (int) (short) 1);
        char char22 = doubleMetaphone7.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone7.maxCodeLen = 100;
        boolean boolean27 = doubleMetaphone7.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        java.lang.String str29 = doubleMetaphone7.encode("");
        int int30 = doubleMetaphone7.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = refinedSoundex0.encode((java.lang.Object) int30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080" + "'", str4, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '0' + "'", char6 == '0');
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '1' + "'", char19 == '1');
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + 'O' + "'", char22 == 'O');
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
    }

    @Test
    public void test1748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1748");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.soundex("AR");
        java.lang.String str8 = soundex4.encode("A000");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A600" + "'", str6, "A600");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
    }

    @Test
    public void test1749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1749");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        int int23 = metaphone0.getMaxCodeLen();
        java.lang.String str25 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ARKPKSKMNS" + "'", str22, "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "ORKPKSKMNS" + "'", str25, "ORKPKSKMNS");
    }

    @Test
    public void test1750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1750");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        boolean boolean7 = metaphone0.isMetaphoneEqual(" ", "org.apache.commons.codec.EncoderException: O");
        metaphone0.setMaxCodeLen((int) '0');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test1751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1751");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "AA11111111", "AKPKMNSKTK");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test1752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1752");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        org.apache.commons.codec.EncoderException encoderException4 = new org.apache.commons.codec.EncoderException("A0");
        org.apache.commons.codec.EncoderException encoderException6 = new org.apache.commons.codec.EncoderException("O0");
        encoderException4.addSuppressed((java.lang.Throwable) encoderException6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = metaphone0.encode((java.lang.Object) encoderException4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
    }

    @Test
    public void test1753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1753");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("A0931383", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test1754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1754");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        java.lang.String str17 = metaphone0.metaphone("");
        java.lang.String str19 = metaphone0.encode("");
        java.lang.String str21 = metaphone0.metaphone("A111111111");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A" + "'", str21, "A");
    }

    @Test
    public void test1755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1755");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str17 = refinedSoundex0.soundex("O621");
        java.lang.String str19 = refinedSoundex0.encode("A#");
        java.lang.String str21 = refinedSoundex0.soundex("ARKP");
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("A0931");
        java.lang.Throwable[] throwableArray24 = encoderException23.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) throwableArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0940103030808306030830609053016080931" + "'", str15, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0" + "'", str17, "O0");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A0" + "'", str19, "A0");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A0931" + "'", str21, "A0931");
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertArrayEquals(throwableArray24, new java.lang.Throwable[] {});
    }

    @Test
    public void test1756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1756");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("");
        boolean boolean30 = caverphone0.isCaverphoneEqual("ARKPKSKMNSK", "AA");
        boolean boolean33 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: O", "A093153836383693158");
        boolean boolean36 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ARKP", "ARKPKMNSKTKNKTRKSPKSNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "1111111111" + "'", str27, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test1757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1757");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        soundex3.setMaxLength((int) (byte) -1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = soundex3.encode((java.lang.Object) "AO");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test1758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1758");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex6, "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0", "ARKPXKMNSKTSNKTRKSPXN");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1759");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.Object obj9 = doubleMetaphone0.encode((java.lang.Object) "ORKP");
        doubleMetaphone0.maxCodeLen = 0;
        boolean boolean14 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "ARKP");
        java.lang.String str16 = doubleMetaphone0.doubleMetaphone("ORKPXKMNSK");
        int int19 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ORKPKSKMNSKTKNKTRKSPKSN", "A931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test1760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1760");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        boolean boolean17 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("AK11111111", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean24 = doubleMetaphone0.isDoubleMetaphoneEqual("O0", "", false);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "  ");
        java.lang.String str29 = doubleMetaphone0.encode("ORKP");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult31 = doubleMetaphone0.new DoubleMetaphoneResult((int) (byte) 0);
        doubleMetaphoneResult31.append('e', ' ');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ARKP" + "'", str29, "ARKP");
    }

    @Test
    public void test1761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1761");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (short) -1);
        metaphone0.setMaxCodeLen((int) (byte) 100);
        java.lang.String str14 = metaphone0.metaphone("aORGAPACHECOMMONSCODECENCODEREXC");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ARKPXKMNSKTSNKTRKSK" + "'", str14, "ARKPXKMNSKTSNKTRKSK");
    }

    @Test
    public void test1762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1762");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.encode("A1");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = 0;
        char char15 = doubleMetaphone10.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean19 = doubleMetaphone10.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char22 = doubleMetaphone10.charAt("01230120022455012623010202", (int) (short) 1);
        char char25 = doubleMetaphone10.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone10.maxCodeLen = 100;
        boolean boolean30 = doubleMetaphone10.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        java.lang.String str32 = doubleMetaphone10.doubleMetaphone("AK11111111");
        java.lang.Object obj33 = caverphone0.encode((java.lang.Object) str32);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex34 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char36 = refinedSoundex34.getMappingCode('a');
        int int39 = refinedSoundex34.difference("", "hi!");
        int int42 = refinedSoundex34.difference("hi!", "");
        int int45 = refinedSoundex34.difference("hi!", "");
        java.lang.String str47 = refinedSoundex34.encode("AKPKMNSKT");
        int int50 = refinedSoundex34.difference("AA11111111", "01230120022455012623010202");
        java.lang.String str52 = refinedSoundex34.soundex("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        java.lang.Object obj53 = caverphone0.encode((java.lang.Object) str52);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone54 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str56 = doubleMetaphone54.doubleMetaphone("H");
        java.lang.String str58 = doubleMetaphone54.doubleMetaphone("");
        doubleMetaphone54.maxCodeLen = '\000';
        int int61 = doubleMetaphone54.maxCodeLen;
        doubleMetaphone54.maxCodeLen = 7;
        doubleMetaphone54.maxCodeLen = 49;
        int int66 = doubleMetaphone54.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj67 = caverphone0.encode((java.lang.Object) doubleMetaphone54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '1' + "'", char22 == '1');
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + 'O' + "'", char25 == 'O');
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AK" + "'", str32, "AK");
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "AK11111111" + "'", obj33, "AK11111111");
        org.junit.Assert.assertNotNull(refinedSoundex34);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '0' + "'", char36 == '0');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "A0313836" + "'", str47, "A0313836");
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertEquals("'" + str52 + "' != '" + "O09401030308083060308306090530160809315383638369315893153836383693158931" + "'", str52, "O09401030308083060308306090530160809315383638369315893153836383693158931");
        org.junit.Assert.assertEquals("'" + obj53 + "' != '" + "A111111111" + "'", obj53, "A111111111");
        org.junit.Assert.assertEquals("'" + str56 + "' != '" + "" + "'", str56, "");
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 49 + "'", int66 == 49);
    }

    @Test
    public void test1763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1763");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        char char5 = refinedSoundex0.getMappingCode(' ');
        java.lang.Object obj6 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = refinedSoundex0.encode(obj6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
    }

    @Test
    public void test1764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1764");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.metaphone("A0");
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str11 = caverphone5.encode("");
        java.lang.String str13 = caverphone5.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = 0;
        char char19 = doubleMetaphone14.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone14.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult21.appendAlternate('\000');
        java.lang.String str24 = doubleMetaphoneResult21.getAlternate();
        java.lang.String str25 = doubleMetaphoneResult21.getPrimary();
        java.lang.Object obj26 = caverphone5.encode((java.lang.Object) str25);
        java.lang.String str28 = caverphone5.caverphone("");
        int int31 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone5, "AKPKKMNSKT", "ORKP");
        java.lang.Object obj32 = metaphone0.encode((java.lang.Object) "AKPKKMNSKT");
        boolean boolean35 = metaphone0.isMetaphoneEqual("H", "org.apache.commons.codec.EncoderException: A093153836383693158");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKPKKMNSKT" + "'", str9, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "1111111111" + "'", obj26, "1111111111");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "1111111111" + "'", str28, "1111111111");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "" + "'", obj32, "");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test1765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1765");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("AA");
        int int8 = soundex0.getMaxLength();
        int int11 = soundex0.difference("Ar", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSKTSNKTRKSPKSNRKPR");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

    @Test
    public void test1766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1766");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int6 = soundex5.getMaxLength();
        int int9 = soundex5.difference("AKPKMNSKTK", "A621HI0A093138363836931589313836383693158M");
        int int10 = soundex5.getMaxLength();
        int int11 = soundex5.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test1767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1767");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A ");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) "A ");
        boolean boolean17 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: A0931383", "A03138363");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "A" + "'", obj14, "A");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test1768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1768");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str30 = caverphone0.encode("A0AiAKPKSKMNS1");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKSKMNS1" + "'", str30, "AKPKSKMNS1");
    }

    @Test
    public void test1769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1769");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        char[] charArray5 = null;
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray5);
        java.lang.String str8 = soundex6.soundex("");
        java.lang.String str10 = soundex6.encode("");
        java.lang.Object obj11 = caverphone0.encode((java.lang.Object) str10);
        boolean boolean14 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125", "AKPKSKMNS");
        java.lang.String str16 = caverphone0.encode(" 1");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + obj11 + "' != '" + "1111111111" + "'", obj11, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "1111111111" + "'", str16, "1111111111");
    }

    @Test
    public void test1770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1770");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) 'a');
        metaphone0.setMaxCodeLen(0);
        boolean boolean15 = metaphone0.isMetaphoneEqual("ARKPXKMNSKTKNKTRKSPXN", "A1111111114r");
        java.lang.String str17 = metaphone0.encode("O0");
        java.lang.Object obj19 = metaphone0.encode((java.lang.Object) "ORKP");
        metaphone0.setMaxCodeLen(8);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "" + "'", obj19, "");
    }

    @Test
    public void test1771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1771");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.Object obj32 = caverphone0.encode((java.lang.Object) "AKPKMNSKT1");
        boolean boolean35 = caverphone0.isCaverphoneEqual("", "AK11111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone36 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone36.maxCodeLen = 0;
        char char41 = doubleMetaphone36.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult43 = doubleMetaphone36.new DoubleMetaphoneResult((int) '#');
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult45 = doubleMetaphone36.new DoubleMetaphoneResult((-1));
        doubleMetaphone36.maxCodeLen = (-1);
        int int48 = doubleMetaphone36.getMaxCodeLen();
        int int49 = doubleMetaphone36.maxCodeLen;
        doubleMetaphone36.maxCodeLen = 1;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj52 = caverphone0.encode((java.lang.Object) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "AKPKMNSKT1" + "'", obj32, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + char41 + "' != '" + '\000' + "'", char41 == '\000');
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test1772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1772");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str8 = metaphone0.encode("");
        boolean boolean11 = metaphone0.isMetaphoneEqual("KP", "ORKPKSKMNS");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test1773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1773");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        soundex1.setMaxLength(0);
        int int12 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test1774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1774");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int6 = soundex2.getMaxLength();
        int int7 = soundex2.getMaxLength();
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex2, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN", "hi!");
        int int13 = soundex2.difference("org.apache.commons.codec.EncoderException: org.ap", "O0931");
        soundex2.setMaxLength(38);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test1775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1775");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str4 = refinedSoundex2.soundex("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone5 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str7 = doubleMetaphone5.doubleMetaphone("H");
        doubleMetaphone5.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = doubleMetaphone5.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone5.new DoubleMetaphoneResult(0);
        java.lang.String str15 = doubleMetaphoneResult14.getAlternate();
        doubleMetaphoneResult14.append('\000');
        doubleMetaphoneResult14.append('#', '#');
        java.lang.String str21 = doubleMetaphoneResult14.getPrimary();
        java.lang.String str22 = doubleMetaphoneResult14.getAlternate();
        doubleMetaphoneResult14.append("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str25 = doubleMetaphoneResult14.getAlternate();
        doubleMetaphoneResult14.append('1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = refinedSoundex2.encode((java.lang.Object) '1');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
    }

    @Test
    public void test1776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1776");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        int int3 = soundex0.difference("H", "");
        int int4 = soundex0.getMaxLength();
        soundex0.setMaxLength(0);
        int int9 = soundex0.difference("ORKPXKMNSKTSNKTRKSSPXNRKP", "R");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56 + "'", int4 == 56);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test1777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1777");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str16 = soundex1.soundex("O0931");
        java.lang.String str18 = soundex1.encode("org.apache.commons.codec.EncoderException: ARKP");
        int int19 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O000" + "'", str16, "O000");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O941" + "'", str18, "O941");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
    }

    @Test
    public void test1778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1778");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        int int17 = metaphone0.getMaxCodeLen();
        int int18 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
    }

    @Test
    public void test1779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1779");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.encode("hi!");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char10 = refinedSoundex8.getMappingCode('a');
        int int13 = refinedSoundex8.difference("", "hi!");
        char char15 = refinedSoundex8.getMappingCode('0');
        char char17 = refinedSoundex8.getMappingCode('a');
        java.lang.String str19 = refinedSoundex8.soundex("1111111111");
        int int22 = refinedSoundex8.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone23 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone23.maxCodeLen = '\000';
        doubleMetaphone23.setMaxCodeLen(4);
        java.lang.String str29 = doubleMetaphone23.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj30 = refinedSoundex8.encode((java.lang.Object) str29);
        java.lang.String str32 = refinedSoundex8.soundex("A0313836");
        int int35 = refinedSoundex8.difference("O0940103030808306030830609053016080", "A1111111114r");
        int int38 = refinedSoundex8.difference("", "A111111111");
        java.lang.Object obj39 = refinedSoundex0.encode((java.lang.Object) "A111111111");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertNotNull(refinedSoundex8);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '0' + "'", char10 == '0');
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '0' + "'", char17 == '0');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ARKP" + "'", str29, "ARKP");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "A0931" + "'", obj30, "A0931");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "A0" + "'", str32, "A0");
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertEquals("'" + obj39 + "' != '" + "A0" + "'", obj39, "A0");
    }

    @Test
    public void test1780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1780");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        int int5 = soundex4.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex4.soundex("O0940103030808306030830609053016080931");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test1781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1781");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str4 = refinedSoundex2.soundex("");
        java.lang.String str6 = refinedSoundex2.encode("A ");
        int int9 = refinedSoundex2.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP", "RKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A0" + "'", str6, "A0");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test1782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1782");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 100);
        doubleMetaphone0.setMaxCodeLen((int) 'O');
        int int9 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        metaphone10.setMaxCodeLen(3);
        int int13 = metaphone10.getMaxCodeLen();
        boolean boolean16 = metaphone10.isMetaphoneEqual("", "");
        boolean boolean19 = metaphone10.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone10.setMaxCodeLen(0);
        int int22 = metaphone10.getMaxCodeLen();
        metaphone10.setMaxCodeLen((int) (short) 100);
        int int25 = metaphone10.getMaxCodeLen();
        java.lang.String str27 = metaphone10.metaphone("");
        org.apache.commons.codec.language.Caverphone caverphone28 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str30 = caverphone28.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str32 = caverphone28.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str34 = caverphone28.encode("A");
        char[] charArray35 = null;
        org.apache.commons.codec.language.Soundex soundex36 = new org.apache.commons.codec.language.Soundex(charArray35);
        java.lang.String str38 = soundex36.soundex("");
        java.lang.String str40 = soundex36.encode("");
        java.lang.Object obj41 = caverphone28.encode((java.lang.Object) "");
        boolean boolean44 = caverphone28.isCaverphoneEqual("O093", "AKP1111111");
        java.lang.String str46 = caverphone28.caverphone("A0");
        java.lang.Object obj47 = metaphone10.encode((java.lang.Object) "A0");
        java.lang.Object obj48 = doubleMetaphone0.encode(obj47);
        doubleMetaphone0.setMaxCodeLen(4);
        java.lang.String str52 = doubleMetaphone0.doubleMetaphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 79 + "'", int9 == 79);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKKMNSKT" + "'", str30, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKPKKMNSKT" + "'", str32, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "" + "'", str40, "");
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "1111111111" + "'", obj41, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "A111111111" + "'", str46, "A111111111");
        org.junit.Assert.assertEquals("'" + obj47 + "' != '" + "A" + "'", obj47, "A");
        org.junit.Assert.assertEquals("'" + obj48 + "' != '" + "A" + "'", obj48, "A");
        org.junit.Assert.assertNull(str52);
    }

    @Test
    public void test1783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1783");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        java.lang.String str8 = metaphone0.metaphone("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = '\000';
        char char14 = doubleMetaphone9.charAt("", 0);
        java.lang.String str16 = doubleMetaphone9.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str18 = doubleMetaphone9.doubleMetaphone("");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) 100);
        doubleMetaphoneResult20.append("A", "O621");
        java.lang.String str24 = doubleMetaphoneResult20.getAlternate();
        java.lang.Object obj25 = metaphone0.encode((java.lang.Object) str24);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone26 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str28 = doubleMetaphone26.doubleMetaphone("H");
        doubleMetaphone26.setMaxCodeLen((int) (byte) 0);
        java.lang.String str33 = doubleMetaphone26.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult35 = doubleMetaphone26.new DoubleMetaphoneResult(0);
        java.lang.String str36 = doubleMetaphoneResult35.getAlternate();
        doubleMetaphoneResult35.append('\000');
        doubleMetaphoneResult35.append('#', '#');
        java.lang.String str42 = doubleMetaphoneResult35.getPrimary();
        doubleMetaphoneResult35.append("AA11111111", "org.apache.commons.codec.EncoderException: A0");
        doubleMetaphoneResult35.appendAlternate('1');
        doubleMetaphoneResult35.appendPrimary("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj50 = metaphone0.encode((java.lang.Object) doubleMetaphoneResult35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O621" + "'", str24, "O621");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "O" + "'", obj25, "O");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
    }

    @Test
    public void test1784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1784");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        java.lang.String str24 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        java.lang.String str26 = metaphone0.metaphone(" ");
        java.lang.String str28 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORKPXKMNSK" + "'", str24, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + " " + "'", str26, " ");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "ORKPKSKMNS" + "'", str28, "ORKPKSKMNS");
    }

    @Test
    public void test1785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1785");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        int int28 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "", "");
        java.lang.String str30 = caverphone0.caverphone("AK11111111");
        boolean boolean33 = caverphone0.isCaverphoneEqual("A0AiAKPKSKMNS1", "org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AK11111111" + "'", str30, "AK11111111");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test1786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1786");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) '#');
        int int8 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str10 = doubleMetaphone0.encode("ORK");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        int int12 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.encode("");
        int int20 = metaphone13.getMaxCodeLen();
        int int21 = metaphone13.getMaxCodeLen();
        metaphone13.setMaxCodeLen((int) 'a');
        metaphone13.setMaxCodeLen(0);
        boolean boolean28 = metaphone13.isMetaphoneEqual("ARKPXKMNSKTKNKTRKSPXN", "A1111111114r");
        java.lang.String str30 = metaphone13.metaphone("A000");
        java.lang.Object obj31 = doubleMetaphone0.encode((java.lang.Object) str30);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test1787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1787");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.Object obj32 = caverphone0.encode((java.lang.Object) "AKPKMNSKT1");
        java.lang.String str34 = caverphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "AKPKMNSKT1" + "'", obj32, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "1111111111" + "'", str34, "1111111111");
    }

    @Test
    public void test1788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1788");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str8 = soundex6.encode("O620#");
        java.lang.String str10 = soundex6.encode("A941");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O000" + "'", str8, "O000");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
    }

    @Test
    public void test1789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1789");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        char char16 = doubleMetaphone9.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone9.new DoubleMetaphoneResult((int) '4');
        java.lang.String str19 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) str19);
        java.lang.String str22 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        boolean boolean25 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderExc", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str27 = caverphone0.encode(" org.apache.commons.codec.EncoderException: ORGAP");
        java.lang.String str29 = caverphone0.encode("A09315383");
        boolean boolean32 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "A093153836383693");
        org.apache.commons.codec.EncoderException encoderException34 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException36 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray37 = encoderException36.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException39 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException36.addSuppressed((java.lang.Throwable) encoderException39);
        org.apache.commons.codec.EncoderException encoderException42 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray43 = encoderException42.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException45 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException47 = new org.apache.commons.codec.EncoderException("");
        encoderException45.addSuppressed((java.lang.Throwable) encoderException47);
        encoderException42.addSuppressed((java.lang.Throwable) encoderException47);
        org.apache.commons.codec.EncoderException encoderException51 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        encoderException47.addSuppressed((java.lang.Throwable) encoderException51);
        encoderException36.addSuppressed((java.lang.Throwable) encoderException51);
        java.lang.Throwable[] throwableArray54 = encoderException51.getSuppressed();
        encoderException34.addSuppressed((java.lang.Throwable) encoderException51);
        org.apache.commons.codec.EncoderException encoderException57 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Throwable[] throwableArray58 = encoderException57.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException60 = new org.apache.commons.codec.EncoderException("A111111111O620");
        encoderException57.addSuppressed((java.lang.Throwable) encoderException60);
        encoderException51.addSuppressed((java.lang.Throwable) encoderException57);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj63 = caverphone0.encode((java.lang.Object) encoderException51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + 'i' + "'", char16 == 'i');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "1111111111" + "'", obj20, "1111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "AKPKKMNSKT" + "'", str27, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertArrayEquals(throwableArray37, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertArrayEquals(throwableArray43, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertArrayEquals(throwableArray54, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertArrayEquals(throwableArray58, new java.lang.Throwable[] {});
    }

    @Test
    public void test1790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1790");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("");
        boolean boolean10 = metaphone0.isMetaphoneEqual("", "H");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int13 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test1791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1791");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: hi!", "AKP");
        soundex1.setMaxLength((int) '#');
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "A621", "AKPK");
        org.apache.commons.codec.language.Caverphone caverphone11 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str13 = caverphone11.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone11.caverphone("hi!");
        java.lang.String str17 = caverphone11.caverphone("");
        java.lang.String str19 = caverphone11.caverphone("HI");
        boolean boolean22 = caverphone11.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str24 = caverphone11.caverphone("");
        java.lang.Object obj25 = soundex1.encode((java.lang.Object) str24);
        java.lang.String str27 = soundex1.soundex("ORKPXKMNSKTKNKTRKSSPXNH");
        int int28 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AA11111111" + "'", str15, "AA11111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AA11111111" + "'", str19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "O621" + "'", str27, "O621");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 35 + "'", int28 == 35);
    }

    @Test
    public void test1792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1792");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str7 = metaphone0.metaphone("A#");
        java.lang.String str9 = metaphone0.encode("A");
        metaphone0.setMaxCodeLen(5);
        boolean boolean14 = metaphone0.isMetaphoneEqual("O620ORGAPACHECOMMONSCODECENCODER", "AHM");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A" + "'", str7, "A");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test1793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1793");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex24 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char26 = refinedSoundex24.getMappingCode('a');
        int int29 = refinedSoundex24.difference("", "hi!");
        int int32 = refinedSoundex24.difference("", "A");
        java.lang.Object obj33 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str35 = caverphone0.caverphone("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str37 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        boolean boolean40 = caverphone0.isCaverphoneEqual("O0940103030808306030830609053016080931", "ORKPXKMNSK");
        java.lang.String str42 = caverphone0.caverphone("ARK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex24);
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "1111111111" + "'", obj33, "1111111111");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "A111111111" + "'", str35, "A111111111");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "AKPKKMNSKT" + "'", str37, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "AK11111111" + "'", str42, "AK11111111");
    }

    @Test
    public void test1794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1794");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        java.lang.String str6 = metaphone0.encode("AKPKMNSKT");
        java.lang.String str8 = metaphone0.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
        int int9 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "AKPKMNSKT" + "'", str6, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT" + "'", str8, "ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test1795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1795");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        boolean boolean16 = caverphone0.isCaverphoneEqual("hi!", "ORKP");
        boolean boolean19 = caverphone0.isCaverphoneEqual("A111111111e", "ORKPXKMNSKTSNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test1796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1796");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.encode("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str11 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: ORKP");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A093138363836931589313836383693158" + "'", str9, "A093138363836931589313836383693158");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0940103030808306030830609053016080931" + "'", str11, "O0940103030808306030830609053016080931");
    }

    @Test
    public void test1797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1797");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        metaphone0.setMaxCodeLen(0);
        boolean boolean11 = metaphone0.isMetaphoneEqual("A1", "ARKPXKMNSK");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str14 = doubleMetaphone12.doubleMetaphone("H");
        doubleMetaphone12.setMaxCodeLen((int) (byte) 0);
        java.lang.String str19 = doubleMetaphone12.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone12.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult21.append('#', 'a');
        doubleMetaphoneResult21.append('O');
        doubleMetaphoneResult21.append("O621", "org.apache.commons.codec.EncoderException: A0");
        doubleMetaphoneResult21.append(" ", "ARKP");
        java.lang.Object obj33 = metaphone0.encode((java.lang.Object) " ");
        int int34 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + " " + "'", obj33, " ");
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test1798() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1798");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AKPKSKMNSK", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1799");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = 100;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "");
        int int21 = doubleMetaphone0.maxCodeLen;
        char char24 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: O000", (int) '9');
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult26 = doubleMetaphone0.new DoubleMetaphoneResult(4);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
    }

    @Test
    public void test1800() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1800");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex9.setMaxLength((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            int int14 = soundex9.difference("aorg.apache.commons.codec.Encode", "ARKPKMNSKTKNKTRKSPKSNRKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1801");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O09401030308083060308306090530160809315383", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1802() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1802");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.metaphone("O000");
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) "O000");
        boolean boolean23 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTION", "O0");
        boolean boolean26 = caverphone0.isCaverphoneEqual("H0", "org.apache.commons.codec.EncoderException: A0");
        java.lang.String str28 = caverphone0.caverphone("A09315383");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "A111111111" + "'", obj20, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
    }

    @Test
    public void test1803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1803");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        java.lang.String str4 = soundex1.soundex("01230120022455012623010202");
        java.lang.String str6 = soundex1.encode("1111111111");
        soundex1.setMaxLength((int) '6');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test1804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1804");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int6 = soundex2.getMaxLength();
        java.lang.String str8 = soundex2.encode("A062125232523621256212523252362125");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        boolean boolean15 = doubleMetaphone9.isDoubleMetaphoneEqual("O000", "A ", true);
        java.lang.String str17 = doubleMetaphone9.doubleMetaphone("org.apache.commons.codec.EncoderException: hi!");
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone9, "", "H000");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = soundex2.encode((java.lang.Object) doubleMetaphone9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test1805() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1805");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) 'a');
        metaphone0.setMaxCodeLen(111);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test1806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1806");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "", "AKPKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test1807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1807");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        java.lang.String str6 = soundex1.encode("O0940103030808306030830609053016080931");
        int int9 = soundex1.difference("HI", "O000");
        int int10 = soundex1.getMaxLength();
        java.lang.String str12 = soundex1.encode("AHM");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O000" + "'", str6, "O000");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A800" + "'", str12, "A800");
    }

    @Test
    public void test1808() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1808");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int10 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test1809() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1809");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        char char29 = refinedSoundex0.getMappingCode('S');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '3' + "'", char29 == '3');
    }

    @Test
    public void test1810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1810");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean13 = caverphone0.isCaverphoneEqual("", "ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str15 = caverphone0.caverphone("AA");
        java.lang.String str17 = caverphone0.encode("A0212523");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AA11111111" + "'", str15, "AA11111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
    }

    @Test
    public void test1811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1811");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex5, "A093153836383693158", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = refinedSoundex5.soundex("ORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test1812() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1812");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        java.lang.String str15 = metaphone0.encode("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str17 = metaphone0.encode("ARKPKMNSKTKNKTRKSPKSNRKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKPXKMNSK" + "'", str15, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ARKPKMNSKT" + "'", str17, "ARKPKMNSKT");
    }

    @Test
    public void test1813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1813");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        soundex0.setMaxLength(0);
        soundex0.setMaxLength((int) (short) 0);
        soundex0.setMaxLength((int) ' ');
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        metaphone12.setMaxCodeLen(3);
        int int15 = metaphone12.getMaxCodeLen();
        java.lang.String str17 = metaphone12.encode("hi!");
        java.lang.String str19 = metaphone12.encode("O621");
        java.lang.String str21 = metaphone12.metaphone("HI");
        int int24 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone12, "4", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        boolean boolean27 = metaphone12.isMetaphoneEqual("O000", "A212");
        java.lang.Object obj28 = soundex0.encode((java.lang.Object) "O000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "H" + "'", str17, "H");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "H" + "'", str21, "H");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "O000" + "'", obj28, "O000");
    }

    @Test
    public void test1814() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1814");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        java.lang.String str18 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A ");
        java.lang.String str20 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        java.lang.String str22 = refinedSoundex0.soundex("ARKPXKMNSKTKNKTRKSPXNKPK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0940103030808306030830609053016080" + "'", str18, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O0940103030808306030830609053016080313836" + "'", str20, "O0940103030808306030830609053016080313836");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A093153836383693158313" + "'", str22, "A093153836383693158313");
    }

    @Test
    public void test1815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1815");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("K111111111");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "K" + "'", str1, "K");
    }

    @Test
    public void test1816() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1816");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        int int5 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone6 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str8 = metaphone6.encode("");
        int int9 = metaphone6.getMaxCodeLen();
        boolean boolean12 = metaphone6.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str15 = metaphone13.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = metaphone13.metaphone("A");
        java.lang.Object obj18 = metaphone6.encode((java.lang.Object) "A");
        java.lang.Object obj19 = metaphone0.encode((java.lang.Object) "A");
        java.lang.String str21 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int22 = metaphone0.getMaxCodeLen();
        int int23 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone24 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone24.maxCodeLen = 0;
        char char29 = doubleMetaphone24.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean33 = doubleMetaphone24.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char36 = doubleMetaphone24.charAt("01230120022455012623010202", (int) (short) 1);
        char char39 = doubleMetaphone24.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone24.maxCodeLen = (byte) 10;
        int int44 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone24, "A", "A");
        java.lang.String str47 = doubleMetaphone24.doubleMetaphone("", true);
        java.lang.Object obj48 = metaphone0.encode((java.lang.Object) "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKP" + "'", str15, "ORKP");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A" + "'", str17, "A");
        org.junit.Assert.assertEquals("'" + obj18 + "' != '" + "A" + "'", obj18, "A");
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "A" + "'", obj19, "A");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "O" + "'", str21, "O");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '\000' + "'", char29 == '\000');
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '1' + "'", char36 == '1');
        org.junit.Assert.assertTrue("'" + char39 + "' != '" + 'O' + "'", char39 == 'O');
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertEquals("'" + obj48 + "' != '" + "" + "'", obj48, "");
    }

    @Test
    public void test1817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1817");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("a");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test1818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1818");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult9 = doubleMetaphone0.new DoubleMetaphoneResult(0);
        int int10 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str13 = doubleMetaphone0.doubleMetaphone("AK11111111", true);
        int int14 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.Metaphone metaphone15 = new org.apache.commons.codec.language.Metaphone();
        metaphone15.setMaxCodeLen(3);
        int int18 = metaphone15.getMaxCodeLen();
        metaphone15.setMaxCodeLen((int) (byte) 1);
        java.lang.String str22 = metaphone15.metaphone("A#");
        java.lang.String str24 = metaphone15.encode("A");
        java.lang.Object obj25 = doubleMetaphone0.encode((java.lang.Object) str24);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A" + "'", str22, "A");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A" + "'", str24, "A");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
    }

    @Test
    public void test1819() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1819");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        char char5 = refinedSoundex3.getMappingCode('O');
        int int8 = refinedSoundex3.difference("hi!", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
        java.lang.String str10 = refinedSoundex3.encode("O0");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0" + "'", str10, "O0");
    }

    @Test
    public void test1820() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1820");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str6 = doubleMetaphone0.encode("H");
        int int7 = doubleMetaphone0.getMaxCodeLen();
        int int8 = doubleMetaphone0.maxCodeLen;
        java.lang.String str11 = doubleMetaphone0.doubleMetaphone("O0", false);
        int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "AKP", "");
        int int15 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str17 = doubleMetaphone0.doubleMetaphone("A621org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
    }

    @Test
    public void test1821() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1821");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: ", "ARK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1822() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1822");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test1823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1823");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        boolean boolean24 = caverphone0.isCaverphoneEqual("AKP1111111", "A1111111114r");
        boolean boolean27 = caverphone0.isCaverphoneEqual("ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT", "org.apache.commons.codec.EncoderException: A062125232523621256212523252362125");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test1824() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1824");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.encode("ARKPXKMNSKTKNKTRKS");
        java.lang.String str8 = soundex4.encode("O620#");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A621" + "'", str6, "A621");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O000" + "'", str8, "O000");
    }

    @Test
    public void test1825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1825");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        boolean boolean17 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("AK11111111", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean24 = doubleMetaphone0.isDoubleMetaphoneEqual("O0", "", false);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "  ");
        doubleMetaphone0.maxCodeLen = 0;
        char char32 = doubleMetaphone0.charAt("9", (-1));
        int int33 = doubleMetaphone0.maxCodeLen;
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + char32 + "' != '" + '\000' + "'", char32 == '\000');
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test1826() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1826");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        char char6 = refinedSoundex0.getMappingCode('P');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080931" + "'", str4, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '1' + "'", char6 == '1');
    }

    @Test
    public void test1827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1827");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        int int3 = soundex0.difference("H", "");
        int int4 = soundex0.getMaxLength();
        int int5 = soundex0.getMaxLength();
        int int6 = soundex0.getMaxLength();
        char[] charArray7 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        int int9 = soundex8.getMaxLength();
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex8, "ORKPXKMNSKTKNKTRKSSPXNH", "A621");
        int int13 = soundex8.getMaxLength();
        int int16 = soundex8.difference("O0931", "A111111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = soundex0.encode((java.lang.Object) soundex8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test1828() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1828");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone0.maxCodeLen = 0;
        int int7 = doubleMetaphone0.getMaxCodeLen();
        int int8 = doubleMetaphone0.getMaxCodeLen();
        doubleMetaphone0.setMaxCodeLen(0);
        int int13 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "H", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1829() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1829");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        boolean boolean11 = metaphone0.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        boolean boolean14 = metaphone0.isMetaphoneEqual("ARKPKSKMNSKTKNKTRKSPKSN", "A093153836383693158");
        int int15 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone16 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str18 = metaphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = metaphone16.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str22 = metaphone16.encode("A0");
        java.lang.String str24 = metaphone16.encode("ARKP");
        java.lang.String str26 = metaphone16.encode("org.apache.commons.codec.EncoderException: AK11111111");
        java.lang.String str28 = metaphone16.encode("aORGAPACHECOMMONSCODECENCODEREXC");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = metaphone0.encode((java.lang.Object) metaphone16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORKP" + "'", str18, "ORKP");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "ORKP" + "'", str20, "ORKP");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A" + "'", str22, "A");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ARKP" + "'", str24, "ARKP");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "ORKP" + "'", str26, "ORKP");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "ARKP" + "'", str28, "ARKP");
    }

    @Test
    public void test1830() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1830");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTSNKTRKSSPXNRKP", "ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test1831() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1831");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("");
        java.lang.String str29 = caverphone0.encode("A#");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O093", "ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("");
        boolean boolean37 = caverphone0.isCaverphoneEqual("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK", "AKPKSKMNS1");
        java.lang.String str39 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "1111111111" + "'", str27, "1111111111");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "1111111111" + "'", str34, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "AKPKKMNSKT" + "'", str39, "AKPKKMNSKT");
    }

    @Test
    public void test1832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1832");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean(" O620");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test1833() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1833");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPKKMNSKTKNKTRKSPXNRKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPKKMNSKTKNKTRKSPXNRKP" + "'", str1, "ARKPKKMNSKTKNKTRKSPXNRKP");
    }

    @Test
    public void test1834() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1834");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.caverphone("O941");
        java.lang.String str14 = caverphone0.encode("AKPKMNSK");
        boolean boolean17 = caverphone0.isCaverphoneEqual("ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKT", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str19 = caverphone0.caverphone("O0931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSK11" + "'", str14, "AKPKMNSK11");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A111111111" + "'", str19, "A111111111");
    }

    @Test
    public void test1835() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1835");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        boolean boolean15 = caverphone0.isCaverphoneEqual("AKPKKMNSKT", "A0931383");
        boolean boolean18 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTION", "AKPKSKMNSK");
        java.lang.String str20 = caverphone0.caverphone(" AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKTK" + "'", str20, "AKPKMNSKTK");
    }

    @Test
    public void test1836() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1836");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O0940103030808306030830609053016080313836");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test1837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1837");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(105);
        boolean boolean13 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: ORKPXKMNSK", "org.apache.commons.codec.EncoderException: ARKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test1838() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1838");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.metaphone("O0940103030808306030830609053016080");
        java.lang.String str7 = metaphone0.metaphone("#");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O" + "'", str5, "O");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "#" + "'", str7, "#");
    }

    @Test
    public void test1839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1839");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("a4", "AA11111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1840() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1840");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str16 = soundex1.soundex("O0931");
        java.lang.String str18 = soundex1.encode("i0a");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O000" + "'", str16, "O000");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "I000" + "'", str18, "I000");
    }

    @Test
    public void test1841() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1841");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        java.lang.String str15 = metaphone0.encode("O093");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test1842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1842");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        java.lang.String str23 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        boolean boolean26 = metaphone0.isMetaphoneEqual("AKPKSKMNS1", "O09401030308083060308306090530160809315383");
        boolean boolean29 = metaphone0.isMetaphoneEqual("", "ARKPKSKMNSKTSNKTRKSPKSNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str23, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test1843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1843");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        char char7 = doubleMetaphone0.charAt("hi!", 1);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A621", "H");
        doubleMetaphone0.maxCodeLen = '0';
        int int13 = doubleMetaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult15 = doubleMetaphone0.new DoubleMetaphoneResult((int) (byte) -1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'i' + "'", char7 == 'i');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 48 + "'", int13 == 48);
    }

    @Test
    public void test1844() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1844");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj12 = refinedSoundex0.encode((java.lang.Object) "O941");
        char char14 = refinedSoundex0.getMappingCode('a');
        int int17 = refinedSoundex0.difference("AKPKKMNSKT", "A0931");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "O0" + "'", obj12, "O0");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '0' + "'", char14 == '0');
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test1845() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1845");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.String str16 = metaphone0.encode(" AKP1111111 ");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "KP" + "'", str16, "KP");
    }

    @Test
    public void test1846() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1846");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("org.apache.commons.codec.EncoderException: ORKP", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        int int8 = soundex1.getMaxLength();
        int int11 = soundex1.difference("org.apache.commons.codec.EncoderException: A093153836383693158", "O0931538363836931589315383638369315893109");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test1847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1847");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1848() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1848");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen(48);
        java.lang.String str10 = metaphone0.encode("AR");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = 0;
        char char16 = doubleMetaphone11.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str18 = doubleMetaphone11.encode("A");
        java.lang.Object obj20 = doubleMetaphone11.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone11.maxCodeLen = (byte) 1;
        doubleMetaphone11.maxCodeLen = 'a';
        doubleMetaphone11.setMaxCodeLen((int) 'o');
        java.lang.String str29 = doubleMetaphone11.doubleMetaphone("ORKPXKMNSK", true);
        doubleMetaphone11.setMaxCodeLen(97);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = metaphone0.encode((java.lang.Object) 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AR" + "'", str10, "AR");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "" + "'", obj20, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ARKPKSKMNSK" + "'", str29, "ARKPKSKMNSK");
    }

    @Test
    public void test1849() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1849");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str14 = refinedSoundex0.soundex("H0");
        java.lang.String str16 = refinedSoundex0.encode("a4");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "H0" + "'", str14, "H0");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A0" + "'", str16, "A0");
    }

    @Test
    public void test1850() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1850");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        char char7 = doubleMetaphone0.charAt("hi!", 1);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A621", "H");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        doubleMetaphone0.setMaxCodeLen(54);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'i' + "'", char7 == 'i');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test1851() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1851");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        java.lang.String str10 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "ORKPXKMNSK" + "'", str10, "ORKPXKMNSK");
    }

    @Test
    public void test1852() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1852");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        boolean boolean15 = caverphone0.isCaverphoneEqual("ARKPKSKMNS", "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        boolean boolean18 = caverphone0.isCaverphoneEqual("", "A#");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test1853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1853");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        int int5 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test1854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1854");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("A621");
        java.lang.String str12 = metaphone0.metaphone("O0931538363836931589315383638369315893109");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
    }

    @Test
    public void test1855() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1855");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("", "");
        metaphone0.setMaxCodeLen((int) 'H');
        boolean boolean21 = metaphone0.isMetaphoneEqual("O0931538363836931589313836383693138", "A ");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        java.lang.String str25 = metaphone0.metaphone("A093153836383693");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A" + "'", str25, "A");
    }

    @Test
    public void test1856() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1856");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char3 = refinedSoundex1.getMappingCode('a');
        int int6 = refinedSoundex1.difference("", "hi!");
        char char8 = refinedSoundex1.getMappingCode('#');
        java.lang.String str10 = refinedSoundex1.soundex("01230120022455012623010202");
        java.lang.String str12 = refinedSoundex1.encode("A621");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) str12);
        java.lang.String str15 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        boolean boolean18 = caverphone0.isCaverphoneEqual("A09313836383693158931", "I000");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone19 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str21 = doubleMetaphone19.doubleMetaphone("H");
        doubleMetaphone19.setMaxCodeLen((int) (byte) 0);
        java.lang.String str26 = doubleMetaphone19.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult28 = doubleMetaphone19.new DoubleMetaphoneResult(0);
        int int29 = doubleMetaphone19.getMaxCodeLen();
        java.lang.String str32 = doubleMetaphone19.doubleMetaphone("AK11111111", true);
        doubleMetaphone19.setMaxCodeLen(48);
        java.lang.String str36 = doubleMetaphone19.doubleMetaphone("ARKPXKMNSKTKNKTRKSPXNRKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = caverphone0.encode((java.lang.Object) doubleMetaphone19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex1);
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '0' + "'", char3 == '0');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0" + "'", str12, "A0");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "A111111111" + "'", obj13, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "ARKPKSKMNSKTKNKTRKSPKSNRKP" + "'", str36, "ARKPKSKMNSKTKNKTRKSPKSNRKP");
    }

    @Test
    public void test1857() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1857");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("K", "Aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1858() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1858");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 100);
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "");
        char char12 = doubleMetaphone0.charAt("", (int) (byte) 1);
        java.lang.String str14 = doubleMetaphone0.encode("4");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test1859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1859");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        java.lang.Object obj17 = refinedSoundex0.encode((java.lang.Object) "A0");
        java.lang.String str19 = refinedSoundex0.soundex("A");
        java.lang.String str21 = refinedSoundex0.soundex("A0931");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "A0" + "'", obj17, "A0");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A0" + "'", str19, "A0");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A0" + "'", str21, "A0");
    }

    @Test
    public void test1860() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1860");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean7 = caverphone0.isCaverphoneEqual("O", "01230120022455012623010202");
        boolean boolean10 = caverphone0.isCaverphoneEqual("ARKP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        java.lang.String str12 = caverphone0.encode("org.apache.commons.codec.EncoderException: A093153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
    }

    @Test
    public void test1861() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1861");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference("O09315383638369315893153836383693158", "ARKPKKMNSK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test1862() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1862");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A ", "O0940103030808306030830609053016080931");
        int int10 = refinedSoundex0.difference("O", "1111111111");
        java.lang.String str12 = refinedSoundex0.encode("01");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080931" + "'", str4, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test1863() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1863");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("HI");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str13 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A0");
        metaphone0.setMaxCodeLen(4);
        java.lang.Class<?> wildcardClass16 = metaphone0.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H" + "'", str9, "H");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test1864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1864");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.encode("O09315383638369315893153836383693158");
        int int11 = soundex0.getMaxLength();
        int int12 = soundex0.getMaxLength();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test1865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1865");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.soundex("");
        java.lang.String str15 = refinedSoundex0.soundex("O");
        java.lang.String str17 = refinedSoundex0.soundex("A ");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A0" + "'", str17, "A0");
    }

    @Test
    public void test1866() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1866");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A0O");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AO" + "'", str1, "AO");
    }

    @Test
    public void test1867() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1867");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.metaphone("01230120022455012623010202");
        java.lang.String str7 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str9 = metaphone0.metaphone("ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = '\000';
        doubleMetaphone10.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone10.new DoubleMetaphoneResult((int) '1');
        java.lang.String str17 = doubleMetaphoneResult16.getPrimary();
        doubleMetaphoneResult16.appendAlternate("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        doubleMetaphoneResult16.append('A', 'M');
        java.lang.String str23 = doubleMetaphoneResult16.getAlternate();
        doubleMetaphoneResult16.append("H", "ORKPXKMNSKTSNKTRKSSPXNRKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = metaphone0.encode((java.lang.Object) doubleMetaphoneResult16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORK" + "'", str9, "ORK");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHIM" + "'", str23, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHIM");
    }

    @Test
    public void test1868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1868");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) '4');
        metaphone0.setMaxCodeLen((int) '8');
        boolean boolean22 = metaphone0.isMetaphoneEqual("A093138363836931589313836383693158", "org.apache.commons.codec.EncoderException: A111111111O620");
        metaphone0.setMaxCodeLen(44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test1869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1869");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        int int3 = soundex0.getMaxLength();
        int int4 = soundex0.getMaxLength();
        java.lang.String str6 = soundex0.encode("O09401030308083060308306090530160809315383");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O000" + "'", str6, "O000");
    }

    @Test
    public void test1870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1870");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        java.lang.String str11 = soundex1.encode("org.apache.commons.codec.EncoderException: hi!");
        soundex1.setMaxLength((int) '9');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O941" + "'", str11, "O941");
    }

    @Test
    public void test1871() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1871");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.setMaxCodeLen(10);
        doubleMetaphone0.maxCodeLen = 1;
        doubleMetaphone0.maxCodeLen = 4;
        int int7 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str9 = doubleMetaphone0.encode("org.apache.commons.codec.EncoderException: AK11111111");
        org.apache.commons.codec.language.Caverphone caverphone10 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str12 = caverphone10.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str14 = caverphone10.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str16 = caverphone10.encode("");
        java.lang.String str18 = caverphone10.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone19 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str21 = doubleMetaphone19.doubleMetaphone("H");
        doubleMetaphone19.setMaxCodeLen((int) (byte) 0);
        char char26 = doubleMetaphone19.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult28 = doubleMetaphone19.new DoubleMetaphoneResult((int) '4');
        java.lang.String str29 = doubleMetaphoneResult28.getPrimary();
        java.lang.Object obj30 = caverphone10.encode((java.lang.Object) str29);
        java.lang.String str32 = caverphone10.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        boolean boolean35 = caverphone10.isCaverphoneEqual("org.apache.commons.codec.EncoderExc", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str37 = caverphone10.encode(" org.apache.commons.codec.EncoderException: ORGAP");
        java.lang.String str39 = caverphone10.encode("ARKPXKMNSKTKNKTRKS");
        java.lang.String str41 = caverphone10.caverphone("org.apache.commons.codec.EncoderException: A093153836383693158");
        java.lang.Object obj42 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A093153836383693158");
        boolean boolean45 = doubleMetaphone0.isDoubleMetaphoneEqual("A#", "ORKP");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ARKP" + "'", str9, "ARKP");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKKMNSKT" + "'", str14, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "1111111111" + "'", str16, "1111111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "1111111111" + "'", str18, "1111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + 'i' + "'", char26 == 'i');
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "1111111111" + "'", obj30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKPKKMNSKT" + "'", str32, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "AKPKKMNSKT" + "'", str37, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "AKPKMNSKTK" + "'", str39, "AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "AKPKKMNSKT" + "'", str41, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "ARKP" + "'", obj42, "ARKP");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test1872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1872");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = soundex1.encode("A031");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test1873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1873");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("");
        boolean boolean16 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: org.ap", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str19 = doubleMetaphone17.doubleMetaphone("H");
        java.lang.String str21 = doubleMetaphone17.doubleMetaphone("");
        java.lang.String str24 = doubleMetaphone17.doubleMetaphone("ORKP", true);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone17, "O621", "A111111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = caverphone0.encode((java.lang.Object) int27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ARKP" + "'", str24, "ARKP");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test1874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1874");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKTRKSPXNRKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "A621" + "'", str3, "A621");
    }

    @Test
    public void test1875() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1875");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        boolean boolean12 = metaphone0.isMetaphoneEqual("K", "");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone13, "hi!", "");
        metaphone13.setMaxCodeLen(0);
        java.lang.String str24 = metaphone13.encode("AK11111111");
        java.lang.String str26 = metaphone13.encode("A1");
        java.lang.String str28 = metaphone13.metaphone("A000");
        java.lang.String str30 = metaphone13.encode("A621r");
        java.lang.Object obj31 = metaphone0.encode((java.lang.Object) "A621r");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + obj31 + "' != '" + "AR" + "'", obj31, "AR");
    }

    @Test
    public void test1876() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1876");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        java.lang.String str12 = metaphone0.encode("ARKPXKMNSKTKNKTRKSPXN");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str15 = doubleMetaphone13.doubleMetaphone("H");
        java.lang.String str17 = doubleMetaphone13.doubleMetaphone("");
        java.lang.String str20 = doubleMetaphone13.doubleMetaphone("ORKP", true);
        java.lang.String str23 = doubleMetaphone13.doubleMetaphone("", false);
        java.lang.String str25 = doubleMetaphone13.encode("");
        doubleMetaphone13.setMaxCodeLen(10);
        boolean boolean30 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        boolean boolean33 = doubleMetaphone13.isDoubleMetaphoneEqual("AK11111111", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean37 = doubleMetaphone13.isDoubleMetaphoneEqual("ARKPKSKMNS", "org.apache.commons.codec.EncoderException: O000", true);
        int int38 = doubleMetaphone13.maxCodeLen;
        boolean boolean41 = doubleMetaphone13.isDoubleMetaphoneEqual("ORK", "A0");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj42 = metaphone0.encode((java.lang.Object) boolean41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ARKPKSKMNS" + "'", str12, "ARKPKSKMNS");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "ARKP" + "'", str20, "ARKP");
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test1877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1877");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        java.lang.String str10 = caverphone0.encode("1111111111");
        boolean boolean13 = caverphone0.isCaverphoneEqual("O620", "1111111111");
        java.lang.String str15 = caverphone0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        java.lang.String str17 = caverphone0.caverphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "1111111111" + "'", str10, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
    }

    @Test
    public void test1878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1878");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean7 = caverphone0.isCaverphoneEqual("O", "01230120022455012623010202");
        java.lang.String str9 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str12 = doubleMetaphone10.doubleMetaphone("H");
        doubleMetaphone10.setMaxCodeLen((int) (byte) 0);
        java.lang.String str17 = doubleMetaphone10.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone10.new DoubleMetaphoneResult(0);
        java.lang.String str20 = doubleMetaphoneResult19.getPrimary();
        doubleMetaphoneResult19.appendAlternate('O');
        java.lang.String str23 = doubleMetaphoneResult19.getPrimary();
        doubleMetaphoneResult19.appendPrimary('1');
        doubleMetaphoneResult19.append("0123012002245501262301020201230120022455012623010", "A621");
        java.lang.Object obj29 = caverphone0.encode((java.lang.Object) "A621");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKPKKMNSKT" + "'", str9, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "A111111111" + "'", obj29, "A111111111");
    }

    @Test
    public void test1879() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1879");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        org.apache.commons.codec.language.Metaphone metaphone19 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str21 = metaphone19.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone19.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone24 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str26 = caverphone24.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str28 = caverphone24.caverphone("hi!");
        java.lang.Object obj29 = metaphone19.encode((java.lang.Object) "hi!");
        java.lang.String str31 = metaphone19.encode("O0940103030808306030830609053016080");
        java.lang.Object obj32 = metaphone0.encode((java.lang.Object) str31);
        boolean boolean35 = metaphone0.isMetaphoneEqual("ARKPKMNSKTKNKTRKSPKSNRKPKMNSKTKNKTRKSPKSN", "ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        java.lang.String str37 = metaphone0.encode("  ");
        boolean boolean40 = metaphone0.isMetaphoneEqual("ORKPXKMNSKTSNKTRKSSPXNRKP", "AHM");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ORKP" + "'", str21, "ORKP");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "AKPKKMNSKT" + "'", str26, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AA11111111" + "'", str28, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "H" + "'", obj29, "H");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "O" + "'", str31, "O");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "O" + "'", obj32, "O");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test1880() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1880");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "A111111111O620", "ARKPKSKMNSK");
        int int10 = metaphone0.getMaxCodeLen();
        java.lang.String str12 = metaphone0.encode("org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ORKP" + "'", str12, "ORKP");
    }

    @Test
    public void test1881() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1881");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int3 = soundex2.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone4 = new org.apache.commons.codec.language.Metaphone();
        metaphone4.setMaxCodeLen(3);
        java.lang.String str8 = metaphone4.encode("");
        java.lang.String str10 = metaphone4.encode("");
        metaphone4.setMaxCodeLen((int) (short) 10);
        int int13 = metaphone4.getMaxCodeLen();
        java.lang.String str15 = metaphone4.encode("ORKP");
        int int16 = metaphone4.getMaxCodeLen();
        int int17 = metaphone4.getMaxCodeLen();
        int int18 = metaphone4.getMaxCodeLen();
        boolean boolean21 = metaphone4.isMetaphoneEqual("AKPKMNSKT", "AKPKMNSKT");
        java.lang.Object obj22 = soundex2.encode((java.lang.Object) "AKPKMNSKT");
        soundex2.setMaxLength((int) (short) 10);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex2, "ARKPXKMNSKTKNKTRKSPXNKPK", "AKPKMNSKTK");
        java.lang.String str29 = soundex2.encode("AKPKMNSK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKP" + "'", str15, "ORKP");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A313" + "'", obj22, "A313");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A313" + "'", str29, "A313");
    }

    @Test
    public void test1882() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1882");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str30 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        java.lang.String str32 = caverphone0.caverphone("AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKKMNSKT" + "'", str30, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKPKMNSKT1" + "'", str32, "AKPKMNSKT1");
    }

    @Test
    public void test1883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1883");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("AKPKKMNSKT");
        boolean boolean13 = metaphone0.isMetaphoneEqual("O0931", "ORKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test1884() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1884");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: A000");
        boolean boolean15 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: O620", "A0");
        java.lang.String str17 = caverphone0.encode("A313");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
    }

    @Test
    public void test1885() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1885");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A0313", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1886() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1886");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.encode("O09315383638369315893153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A111111111" + "'", str11, "A111111111");
    }

    @Test
    public void test1887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1887");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        soundex3.setMaxLength((int) (short) 100);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = soundex3.encode("ORKPXKMNSKTKNKTRKSSPXNRKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1888() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1888");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode('0');
        int int10 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: A093153836383693158", "");
        int int13 = refinedSoundex0.difference("O0940103030808306030830609053016080940103030808306030830609053016080", "H0");
        java.lang.String str15 = refinedSoundex0.soundex("A062125232523621256212523252362125");
        java.lang.String str17 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A0" + "'", str15, "A0");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0940103030808306030830609053016080931" + "'", str17, "O0940103030808306030830609053016080931");
    }

    @Test
    public void test1889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1889");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.soundex("O094010303080830603083060905301608");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O0" + "'", str7, "O0");
    }

    @Test
    public void test1890() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1890");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int6 = soundex2.getMaxLength();
        java.lang.String str8 = soundex2.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test1891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1891");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("ARKPKSKMNS");
        boolean boolean11 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: AKPKKMNSKT", "");
        java.lang.String str13 = caverphone0.caverphone("KP");
        org.apache.commons.codec.language.Metaphone metaphone14 = new org.apache.commons.codec.language.Metaphone();
        metaphone14.setMaxCodeLen(3);
        java.lang.String str18 = metaphone14.encode("");
        int int21 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone14, "hi!", "");
        metaphone14.setMaxCodeLen(0);
        java.lang.String str25 = metaphone14.encode("AK11111111");
        java.lang.String str27 = metaphone14.encode("A1");
        java.lang.String str29 = metaphone14.metaphone("A000");
        java.lang.String str31 = metaphone14.metaphone("ORKPXKMNSKTKNKTRKSSPXN");
        int int32 = metaphone14.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = caverphone0.encode((java.lang.Object) metaphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKSKMNS1" + "'", str8, "AKPKSKMNS1");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "KP11111111" + "'", str13, "KP11111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test1892() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1892");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int6 = soundex3.difference("ORKPXKMNSKTKNKTRKSSPXNRKP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        soundex3.setMaxLength(65);
        java.lang.String str10 = soundex3.encode("aORGAPACHECOMMONSCODECENCODEREXC");
        soundex3.setMaxLength(49);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A941" + "'", str10, "A941");
    }

    @Test
    public void test1893() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1893");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: AKPK", "0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1894");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O931", "O0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1895() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1895");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str7 = doubleMetaphone0.encode("A");
        java.lang.Object obj9 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        int int10 = doubleMetaphone0.getMaxCodeLen();
        int int11 = doubleMetaphone0.getMaxCodeLen();
        int int12 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str15 = soundex13.encode("ARKP");
        java.lang.String str17 = soundex13.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj19 = soundex13.encode((java.lang.Object) "ORK");
        java.lang.Object obj20 = doubleMetaphone0.encode((java.lang.Object) "ORK");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A621" + "'", str15, "A621");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O621" + "'", str17, "O621");
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "O620" + "'", obj19, "O620");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "" + "'", obj20, "");
    }

    @Test
    public void test1896() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1896");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        int int11 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(3);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str16 = doubleMetaphone14.doubleMetaphone("H");
        doubleMetaphone14.setMaxCodeLen((int) (byte) 0);
        boolean boolean22 = doubleMetaphone14.isDoubleMetaphoneEqual("O620", "O000", false);
        doubleMetaphone14.setMaxCodeLen((int) (short) 10);
        char char27 = doubleMetaphone14.charAt("org.apache.commons.codec.EncoderException: hi!", 1);
        boolean boolean30 = doubleMetaphone14.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ARK", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = metaphone0.encode((java.lang.Object) doubleMetaphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + 'r' + "'", char27 == 'r');
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test1897() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1897");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A111111111O000");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AO" + "'", str1, "AO");
    }

    @Test
    public void test1898() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1898");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = '\000';
        char char5 = doubleMetaphone0.charAt("", 0);
        java.lang.String str7 = doubleMetaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str11 = doubleMetaphone0.encode("O0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone12.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult19.append(' ');
        doubleMetaphoneResult19.appendPrimary("A621");
        doubleMetaphoneResult19.appendPrimary('a');
        doubleMetaphoneResult19.appendPrimary('O');
        doubleMetaphoneResult19.appendAlternate("i4org.apache.commons.codec.EncoderException: A000");
        java.lang.Object obj30 = doubleMetaphone0.encode((java.lang.Object) "i4org.apache.commons.codec.EncoderException: A000");
        char[] charArray31 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex32 = new org.apache.commons.codec.language.Soundex(charArray31);
        org.apache.commons.codec.language.Soundex soundex33 = new org.apache.commons.codec.language.Soundex(charArray31);
        int int36 = soundex33.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str38 = soundex33.encode("AKPKKMNSKT");
        java.lang.String str40 = soundex33.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj41 = doubleMetaphone0.encode((java.lang.Object) soundex33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "" + "'", obj30, "");
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "A313" + "'", str38, "A313");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "" + "'", str40, "");
    }

    @Test
    public void test1899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1899");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex5.setMaxLength(0);
        soundex5.setMaxLength(1);
        int int12 = soundex5.difference(" ", "A111111111");
        soundex5.setMaxLength((int) 'O');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = 0;
        char char20 = doubleMetaphone15.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean24 = doubleMetaphone15.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char27 = doubleMetaphone15.charAt("01230120022455012623010202", (int) (short) 1);
        char char30 = doubleMetaphone15.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone15.maxCodeLen = (byte) 10;
        boolean boolean35 = doubleMetaphone15.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult37 = doubleMetaphone15.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult37.appendPrimary('i');
        doubleMetaphoneResult37.append('.');
        doubleMetaphoneResult37.append(" AKP1111111 ");
        doubleMetaphoneResult37.append("A111111111O000");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj46 = soundex5.encode((java.lang.Object) "A111111111O000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '1' + "'", char27 == '1');
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + 'O' + "'", char30 == 'O');
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test1900() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1900");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        java.lang.String str24 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931");
        int int25 = metaphone0.getMaxCodeLen();
        java.lang.String str27 = metaphone0.metaphone("I");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ARKPKSKMNS" + "'", str22, "ARKPKSKMNS");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORKPXKMNSK" + "'", str24, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "I" + "'", str27, "I");
    }

    @Test
    public void test1901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1901");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = (byte) 10;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A", "A");
        boolean boolean23 = doubleMetaphone0.isDoubleMetaphoneEqual("H000", "1111111111");
        boolean boolean26 = doubleMetaphone0.isDoubleMetaphoneEqual("ARKPXKMNSKTSNKTRKSK", "8org.apache.commons.codec.EncoderException: A0931");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test1902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1902");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        java.lang.String str14 = metaphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str16 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        metaphone0.setMaxCodeLen((int) 'g');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP" + "'", str16, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
    }

    @Test
    public void test1903() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1903");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        int int7 = metaphone0.getMaxCodeLen();
        java.lang.String str9 = metaphone0.metaphone("A621HIo");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AH" + "'", str9, "AH");
    }

    @Test
    public void test1904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1904");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AKPKMNSK11");
        org.apache.commons.codec.language.Caverphone caverphone31 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str33 = caverphone31.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str35 = caverphone31.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str37 = caverphone31.encode("");
        java.lang.String str39 = caverphone31.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone40 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone40.maxCodeLen = 0;
        char char45 = doubleMetaphone40.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult47 = doubleMetaphone40.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult47.appendAlternate('\000');
        java.lang.String str50 = doubleMetaphoneResult47.getAlternate();
        java.lang.String str51 = doubleMetaphoneResult47.getPrimary();
        java.lang.Object obj52 = caverphone31.encode((java.lang.Object) str51);
        java.lang.String str54 = caverphone31.caverphone("");
        int int57 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone31, "AKPKKMNSKT", "ORKP");
        boolean boolean60 = caverphone31.isCaverphoneEqual("", "HI");
        boolean boolean63 = caverphone31.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str65 = caverphone31.encode("A0");
        java.lang.Object obj66 = caverphone0.encode((java.lang.Object) str65);
        java.lang.Class<?> wildcardClass67 = obj66.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKMNSK11" + "'", str30, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "AKPKKMNSKT" + "'", str33, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "AKPKKMNSKT" + "'", str35, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "1111111111" + "'", str37, "1111111111");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "1111111111" + "'", str39, "1111111111");
        org.junit.Assert.assertTrue("'" + char45 + "' != '" + '\000' + "'", char45 == '\000');
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "" + "'", str50, "");
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
        org.junit.Assert.assertEquals("'" + obj52 + "' != '" + "1111111111" + "'", obj52, "1111111111");
        org.junit.Assert.assertEquals("'" + str54 + "' != '" + "1111111111" + "'", str54, "1111111111");
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertEquals("'" + str65 + "' != '" + "A111111111" + "'", str65, "A111111111");
        org.junit.Assert.assertEquals("'" + obj66 + "' != '" + "A111111111" + "'", obj66, "A111111111");
        org.junit.Assert.assertNotNull(wildcardClass67);
    }

    @Test
    public void test1905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1905");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean12 = metaphone0.isMetaphoneEqual("A621", "");
        boolean boolean15 = metaphone0.isMetaphoneEqual("AKPKKMNSKT", "A111111111");
        boolean boolean18 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHIM", "O09315383638369315893153836383693158931");
        char[] charArray19 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex20 = new org.apache.commons.codec.language.Soundex(charArray19);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex21 = new org.apache.commons.codec.language.RefinedSoundex(charArray19);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex22 = new org.apache.commons.codec.language.RefinedSoundex(charArray19);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex23 = new org.apache.commons.codec.language.RefinedSoundex(charArray19);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = metaphone0.encode((java.lang.Object) refinedSoundex23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(charArray19);
    }

    @Test
    public void test1906() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1906");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        java.lang.String str6 = metaphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = 0;
        char char12 = doubleMetaphone7.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean16 = doubleMetaphone7.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone7.maxCodeLen = 3;
        boolean boolean22 = doubleMetaphone7.isDoubleMetaphoneEqual("H0", "1111111111", false);
        java.lang.String str25 = doubleMetaphone7.doubleMetaphone("A0", true);
        java.lang.String str27 = doubleMetaphone7.doubleMetaphone("ARKPKSKMNSKTKNKTRKSPKSN");
        java.lang.Object obj28 = metaphone0.encode((java.lang.Object) str27);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O" + "'", str6, "O");
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A" + "'", str25, "A");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "ARK" + "'", str27, "ARK");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "ARK" + "'", obj28, "ARK");
    }

    @Test
    public void test1907() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1907");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        metaphone0.setMaxCodeLen((int) ' ');
        boolean boolean9 = metaphone0.isMetaphoneEqual("ARKPXKMNSKTKNKTRKSPXN", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test1908() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1908");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: AKPK", "ARK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1909() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1909");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A000 1", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test1910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1910");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ARKP");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0940103030808306030830609053016080931" + "'", str10, "O0940103030808306030830609053016080931");
    }

    @Test
    public void test1911() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1911");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        int int11 = refinedSoundex0.difference("O", "AK11111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean21 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char24 = doubleMetaphone12.charAt("01230120022455012623010202", (int) (short) 1);
        char char27 = doubleMetaphone12.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone12.maxCodeLen = (byte) 10;
        boolean boolean32 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult34 = doubleMetaphone12.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult34.appendPrimary('i');
        doubleMetaphoneResult34.appendPrimary("ORKPXKMNSKTKNKTRKSSPXNH");
        doubleMetaphoneResult34.appendPrimary('A');
        doubleMetaphoneResult34.append('c');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = refinedSoundex0.encode((java.lang.Object) 'c');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '1' + "'", char24 == '1');
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + 'O' + "'", char27 == 'O');
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test1912() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1912");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str7 = soundex1.encode("AA11111111");
        int int8 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) 'c');
        java.lang.String str12 = soundex1.encode("ARK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A620" + "'", str12, "A620");
    }

    @Test
    public void test1913() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1913");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str15 = caverphone0.caverphone("ORKP");
        java.lang.String str17 = caverphone0.caverphone("A031383");
        java.lang.Object obj18 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = caverphone0.encode(obj18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKP1111111" + "'", str15, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
    }

    @Test
    public void test1914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1914");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = 0;
        char char19 = doubleMetaphone14.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean23 = doubleMetaphone14.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone14.maxCodeLen = 3;
        java.lang.String str27 = doubleMetaphone14.encode("A111111111");
        java.lang.Object obj28 = refinedSoundex0.encode((java.lang.Object) str27);
        int int31 = refinedSoundex0.difference("A0313836", "O620");
        int int34 = refinedSoundex0.difference("ORKP", "A031383");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A" + "'", str27, "A");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "A0" + "'", obj28, "A0");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test1915() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1915");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str6 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str8 = refinedSoundex0.soundex("4");
        java.lang.String str10 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTION");
        java.lang.String str12 = refinedSoundex0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080" + "'", str4, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O0" + "'", str6, "O0");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O094010303080830603083060905301608" + "'", str10, "O094010303080830603083060905301608");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test1916() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1916");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean13 = caverphone0.isCaverphoneEqual("", "ARKPXKMNSKTKNKTRKSPXN");
        java.lang.Object obj15 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        int int18 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "");
        java.lang.String str20 = caverphone0.encode("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str22 = caverphone0.encode("org.apache.commons.codec.EncoderException: ");
        java.lang.String str24 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + obj15 + "' != '" + "AKPKKMNSKT" + "'", obj15, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKTK" + "'", str20, "AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
    }

    @Test
    public void test1917() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1917");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        int int18 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "O941", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        int int21 = refinedSoundex0.difference("Aa", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        java.lang.String str23 = refinedSoundex0.encode("A093153836383693");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A0" + "'", str23, "A0");
    }

    @Test
    public void test1918() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1918");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str6 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str8 = refinedSoundex0.soundex("H000");
        java.lang.String str10 = refinedSoundex0.encode("A0O");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080" + "'", str4, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O0" + "'", str6, "O0");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "H0" + "'", str8, "H0");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A0" + "'", str10, "A0");
    }

    @Test
    public void test1919() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1919");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        boolean boolean3 = caverphone0.isCaverphoneEqual("AKPK", "AKP1111111");
        java.lang.String str5 = caverphone0.encode("AKP1111111");
        int int8 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "KPKMNSKTKN", "A0");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "AKP1111111" + "'", str5, "AKP1111111");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test1920() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1920");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "H");
        java.lang.String str18 = metaphone0.encode("A093138363836931589313836383693158");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex19 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char21 = refinedSoundex19.getMappingCode('a');
        int int24 = refinedSoundex19.difference("", "hi!");
        int int27 = refinedSoundex19.difference("hi!", "");
        char char29 = refinedSoundex19.getMappingCode('#');
        char char31 = refinedSoundex19.getMappingCode('a');
        java.lang.String str33 = refinedSoundex19.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = metaphone0.encode((java.lang.Object) refinedSoundex19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNotNull(refinedSoundex19);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '0' + "'", char21 == '0');
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '\000' + "'", char29 == '\000');
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "O0940103030808306030830609053016080931" + "'", str33, "O0940103030808306030830609053016080931");
    }

    @Test
    public void test1921() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1921");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPKSKMNS", "A313");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1922");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        doubleMetaphone0.setMaxCodeLen(97);
        java.lang.String str16 = doubleMetaphone0.doubleMetaphone("O094010303080830603083060905301608093", false);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
    }

    @Test
    public void test1923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1923");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        java.lang.String str10 = soundex1.encode("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            int int13 = soundex1.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: AKPK");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test1924() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1924");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = '\000';
        char char5 = doubleMetaphone0.charAt("", 0);
        java.lang.String str7 = doubleMetaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str12 = doubleMetaphone0.doubleMetaphone("A1", true);
        char char15 = doubleMetaphone0.charAt("O620", (int) '0');
        doubleMetaphone0.maxCodeLen = (short) 100;
        java.lang.String str19 = doubleMetaphone0.doubleMetaphone("A ");
        org.apache.commons.codec.language.Metaphone metaphone20 = new org.apache.commons.codec.language.Metaphone();
        metaphone20.setMaxCodeLen(3);
        java.lang.String str24 = metaphone20.encode("");
        java.lang.String str26 = metaphone20.encode("");
        metaphone20.setMaxCodeLen((int) (short) 10);
        boolean boolean31 = metaphone20.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str33 = metaphone20.encode("A1");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone34 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone34.maxCodeLen = '\000';
        boolean boolean39 = doubleMetaphone34.isDoubleMetaphoneEqual("ORKP", "H");
        java.lang.Object obj40 = metaphone20.encode((java.lang.Object) "H");
        metaphone20.setMaxCodeLen(65);
        java.lang.String str44 = metaphone20.metaphone("AHM");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj45 = doubleMetaphone0.encode((java.lang.Object) metaphone20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A" + "'", str19, "A");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "A" + "'", str33, "A");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertEquals("'" + obj40 + "' != '" + "H" + "'", obj40, "H");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "AM" + "'", str44, "AM");
    }

    @Test
    public void test1925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1925");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex4.getMaxLength();
        soundex4.setMaxLength((int) (byte) 100);
        java.lang.String str9 = soundex4.encode("ARKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A621" + "'", str9, "A621");
    }

    @Test
    public void test1926() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1926");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("");
        java.lang.String str9 = soundex0.soundex(" O620");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
    }

    @Test
    public void test1927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1927");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.encode("");
        boolean boolean28 = caverphone0.isCaverphoneEqual("", "A#");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.String str32 = caverphone0.caverphone("AR");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AA11111111" + "'", str32, "AA11111111");
    }

    @Test
    public void test1928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1928");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.encode("A1");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "", "O000");
        java.lang.String str18 = refinedSoundex0.encode("O09315383638369315893153836383693158");
        char char20 = refinedSoundex0.getMappingCode('o');
        char char22 = refinedSoundex0.getMappingCode('.');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0" + "'", str13, "A0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0" + "'", str18, "O0");
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '0' + "'", char20 == '0');
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
    }

    @Test
    public void test1929() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1929");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.soundex("A800");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A000" + "'", str4, "A000");
    }

    @Test
    public void test1930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1930");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) '#');
        int int8 = doubleMetaphone0.maxCodeLen;
        java.lang.String str10 = doubleMetaphone0.encode("O");
        int int13 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A031383", "");
        java.lang.String str15 = doubleMetaphone0.doubleMetaphone("A02125232");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test1931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1931");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.soundex("HI");
        java.lang.String str9 = refinedSoundex0.encode("hi!");
        int int12 = refinedSoundex0.difference("A621", "");
        java.lang.String str14 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str16 = refinedSoundex0.soundex("A1111111114r");
        int int19 = refinedSoundex0.difference("ORKPXKMNSK", "4");
        int int22 = refinedSoundex0.difference("Aa", "R");
        java.lang.String str24 = refinedSoundex0.soundex("hi!");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H0" + "'", str9, "H0");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O0940103030808306030830609053016080" + "'", str14, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A09" + "'", str16, "A09");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "H0" + "'", str24, "H0");
    }

    @Test
    public void test1932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1932");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (short) 0);
        java.lang.String str11 = soundex1.encode("A000");
        int int14 = soundex1.difference("ORKPXKMNSKTKNKTRKSK", "A621HI0A093138363836931589313836383693158M5");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A000" + "'", str11, "A000");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test1933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1933");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("");
        int int11 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "A600", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test1934() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1934");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("A621");
        java.lang.String str13 = refinedSoundex0.encode("O000");
        java.lang.String str15 = refinedSoundex0.encode("01230120022455012623010202");
        int int18 = refinedSoundex0.difference("O062010202050520302052030602013050", "A621HI0A093138363836931589313836383693158");
        java.lang.Class<?> wildcardClass19 = refinedSoundex0.getClass();
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test1935() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1935");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) ' ');
        boolean boolean7 = metaphone0.isMetaphoneEqual("A09315383", "org.apache.commons.codec.EncoderException: A111111111O620");
        boolean boolean10 = metaphone0.isMetaphoneEqual("r", "");
        java.lang.String str12 = metaphone0.encode("A621r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AR" + "'", str12, "AR");
    }

    @Test
    public void test1936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1936");
        char[] charArray2 = new char[] { '1', 'a' };
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray2);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            int int7 = refinedSoundex4.difference("org.apache.commons.codec.EncoderException: A ", "AHM");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', 'a' });
    }

    @Test
    public void test1937() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1937");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        java.lang.String str14 = metaphone0.encode("O0940103030808306030830609053016080");
        boolean boolean17 = metaphone0.isMetaphoneEqual("O09401030308083060308306090530160809315383638369315893153836383693158931", "A09315383");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test1938() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1938");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        int int9 = soundex3.difference("A111111111", "01230120022455012623010202");
        java.lang.String str11 = soundex3.soundex("");
        java.lang.String str13 = soundex3.encode("A093153836383693");
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A000" + "'", str13, "A000");
    }

    @Test
    public void test1939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1939");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = refinedSoundex6.soundex("ARKPXKMNSKTSNKTRKSPXN");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1940() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1940");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("org.apache.commons.codec.EncoderException: ORKP", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str9 = soundex1.encode("K000");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "K000" + "'", str9, "K000");
    }

    @Test
    public void test1941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1941");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("ORKP");
        char char12 = refinedSoundex0.getMappingCode('1');
        char char14 = refinedSoundex0.getMappingCode('O');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str17 = doubleMetaphone15.doubleMetaphone("H");
        doubleMetaphone15.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone15.maxCodeLen = '0';
        java.lang.String str24 = doubleMetaphone15.doubleMetaphone("A", true);
        boolean boolean27 = doubleMetaphone15.isDoubleMetaphoneEqual("A0", "");
        boolean boolean30 = doubleMetaphone15.isDoubleMetaphoneEqual("A ", "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone15.setMaxCodeLen((int) 'A');
        int int35 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone15, "ARK", "A ");
        doubleMetaphone15.setMaxCodeLen((int) '#');
        boolean boolean40 = doubleMetaphone15.isDoubleMetaphoneEqual("O620", "");
        char[] charArray41 = null;
        org.apache.commons.codec.language.Soundex soundex42 = new org.apache.commons.codec.language.Soundex(charArray41);
        java.lang.String str44 = soundex42.soundex("");
        java.lang.Object obj45 = doubleMetaphone15.encode((java.lang.Object) "");
        doubleMetaphone15.setMaxCodeLen(4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj48 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0931" + "'", str10, "O0931");
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '0' + "'", char14 == '0');
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A" + "'", str24, "A");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
        org.junit.Assert.assertNull(obj45);
    }

    @Test
    public void test1942() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1942");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("A621");
        java.lang.String str13 = refinedSoundex0.encode("O000");
        java.lang.String str15 = refinedSoundex0.encode("01230120022455012623010202");
        int int18 = refinedSoundex0.difference("O062010202050520302052030602013050", "A621HI0A093138363836931589313836383693158");
        int int21 = refinedSoundex0.difference("A621HIo", "  ");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test1943() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1943");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        boolean boolean16 = metaphone0.isMetaphoneEqual("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "AA11111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone17.maxCodeLen = 0;
        boolean boolean23 = doubleMetaphone17.isDoubleMetaphoneEqual("O000", "A ", true);
        java.lang.String str25 = doubleMetaphone17.doubleMetaphone("org.apache.commons.codec.EncoderException: hi!");
        java.lang.Object obj26 = metaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: hi!");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "" + "'", obj26, "");
    }

    @Test
    public void test1944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1944");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "AKPKMNSKTK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1945");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        java.lang.String str29 = refinedSoundex0.encode("A0212523");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A0" + "'", str29, "A0");
    }

    @Test
    public void test1946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1946");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = (byte) 10;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A", "A");
        char char23 = doubleMetaphone0.charAt("A621org.apache.commons.codec.EncoderException: A0", (int) '.');
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + ' ' + "'", char23 == ' ');
    }

    @Test
    public void test1947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1947");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        java.lang.Object obj17 = refinedSoundex0.encode((java.lang.Object) "A0");
        java.lang.String str19 = refinedSoundex0.soundex("A");
        java.lang.String[] strArray38 = new java.lang.String[] {};
        boolean boolean39 = org.apache.commons.codec.language.DoubleMetaphone.contains("01230120022455012623010202", (int) 'a', (int) (short) 0, strArray38);
        boolean boolean40 = org.apache.commons.codec.language.DoubleMetaphone.contains("1111111111", (int) (byte) 10, (int) (byte) 0, strArray38);
        boolean boolean41 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKPKSKMNS", (int) (short) 100, 52, strArray38);
        boolean boolean42 = org.apache.commons.codec.language.DoubleMetaphone.contains("org.apache.commons.codec.EncoderException: ORKP", (int) (byte) -1, 19, strArray38);
        boolean boolean43 = org.apache.commons.codec.language.DoubleMetaphone.contains("O0621", (int) '#', (int) (short) 1, strArray38);
        boolean boolean44 = org.apache.commons.codec.language.DoubleMetaphone.contains("AR", 0, 38, strArray38);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj45 = refinedSoundex0.encode((java.lang.Object) boolean44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "A0" + "'", obj17, "A0");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A0" + "'", str19, "A0");
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertArrayEquals(strArray38, new java.lang.String[] {});
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test1948() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1948");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: ORKPXKMNSK", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test1949() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1949");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str24 = doubleMetaphone22.doubleMetaphone("H");
        java.lang.String str26 = doubleMetaphone22.doubleMetaphone("");
        java.lang.String str29 = doubleMetaphone22.doubleMetaphone("ORKP", true);
        java.lang.String str32 = doubleMetaphone22.doubleMetaphone("", false);
        java.lang.String str34 = doubleMetaphone22.encode("");
        doubleMetaphone22.setMaxCodeLen(10);
        java.lang.String str38 = doubleMetaphone22.doubleMetaphone("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult40 = doubleMetaphone22.new DoubleMetaphoneResult(2);
        doubleMetaphoneResult40.append("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ARKP" + "'", str29, "ARKP");
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
    }

    @Test
    public void test1950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1950");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        metaphone0.setMaxCodeLen((int) '0');
        metaphone0.setMaxCodeLen(0);
        java.lang.String str18 = metaphone0.encode("O0940103030808306030830609053016080");
        int int21 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "org.apache.commons.codec.EncoderException: hi!", "org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test1951() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1951");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test1952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1952");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) '0');
        java.lang.String str7 = soundex1.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        int int10 = soundex1.difference("", "A111111111");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O941" + "'", str7, "O941");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test1953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1953");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int6 = soundex3.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0");
        int int7 = soundex3.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test1954() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1954");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AO", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1955() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1955");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        int int9 = soundex0.getMaxLength();
        int int10 = soundex0.getMaxLength();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test1956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1956");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.soundex("O0940103030808306030830609053016080931");
        java.lang.String str9 = refinedSoundex5.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O0" + "'", str7, "O0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O0620102020505203020520306020130506212520" + "'", str9, "O0620102020505203020520306020130506212520");
    }

    @Test
    public void test1957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1957");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A093153836383693158", "org.apache.commons.codec.EncoderException: 4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1958() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1958");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        java.lang.String str10 = soundex4.encode(" AKPK");
        int int13 = soundex4.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "KP11111111");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A212" + "'", str10, "A212");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1959() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1959");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        java.lang.String str21 = caverphone0.encode("AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKMNSKT1" + "'", str21, "AKPKMNSKT1");
    }

    @Test
    public void test1960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1960");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        java.lang.String str14 = soundex3.soundex("");
        java.lang.String str16 = soundex3.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex17 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char19 = refinedSoundex17.getMappingCode('a');
        int int22 = refinedSoundex17.difference("", "hi!");
        int int25 = refinedSoundex17.difference("hi!", "");
        int int28 = refinedSoundex17.difference("hi!", "");
        java.lang.String str30 = refinedSoundex17.encode("AKPKMNSKT");
        java.lang.String str32 = refinedSoundex17.soundex("O0940103030808306030830609053016080");
        char char34 = refinedSoundex17.getMappingCode('\000');
        int int37 = refinedSoundex17.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT", "O0940103030808306030830609053016080");
        java.lang.Object obj38 = soundex3.encode((java.lang.Object) "O0940103030808306030830609053016080");
        java.lang.String str40 = soundex3.encode("ORKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O000" + "'", str16, "O000");
        org.junit.Assert.assertNotNull(refinedSoundex17);
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '0' + "'", char19 == '0');
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "A0313836" + "'", str30, "A0313836");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "O0" + "'", str32, "O0");
        org.junit.Assert.assertTrue("'" + char34 + "' != '" + '\000' + "'", char34 == '\000');
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertEquals("'" + obj38 + "' != '" + "O000" + "'", obj38, "O000");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "O621" + "'", str40, "O621");
    }

    @Test
    public void test1961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1961");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: ARKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONARKP" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONARKP");
    }

    @Test
    public void test1962() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1962");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("R");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "R" + "'", str1, "R");
    }

    @Test
    public void test1963() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1963");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("org.apache.commons.codec.EncoderException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test1964() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1964");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "ARK", "H0");
        char char12 = refinedSoundex4.getMappingCode('r');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '6' + "'", char12 == '6');
    }

    @Test
    public void test1965() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1965");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        java.lang.String str4 = metaphone0.encode("A621");
        java.lang.String str6 = metaphone0.encode("AKPK");
        java.lang.String str8 = metaphone0.encode("ARKPKKMNSKTKNKTRKSPXNRKP");
        java.lang.String str10 = metaphone0.metaphone("ORKPXKMNSKTSNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "AKPK" + "'", str6, "AKPK");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ARKP" + "'", str8, "ARKP");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "ORKP" + "'", str10, "ORKP");
    }

    @Test
    public void test1966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1966");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        java.lang.String str13 = caverphone0.encode("HI");
        boolean boolean16 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AA11111111" + "'", str13, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test1967() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1967");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A620");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test1968() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1968");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.String str12 = caverphone0.encode("O0940103030808306030830609053016080931");
        java.lang.String str14 = caverphone0.encode(" AKP1111111 ");
        java.lang.String str16 = caverphone0.caverphone("AKP1111111");
        java.lang.String str18 = caverphone0.caverphone("1111111111");
        java.lang.String str20 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ARK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKP1111111" + "'", str14, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKP1111111" + "'", str16, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "1111111111" + "'", str18, "1111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
    }

    @Test
    public void test1969() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1969");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        boolean boolean13 = metaphone0.isMetaphoneEqual("O000", "O620");
        java.lang.String str15 = metaphone0.encode("H0");
        int int16 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

    @Test
    public void test1970() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1970");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Caverphone caverphone9 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str11 = caverphone9.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str13 = caverphone9.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone9.encode("");
        java.lang.String str17 = caverphone9.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone18.maxCodeLen = 0;
        char char23 = doubleMetaphone18.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult25 = doubleMetaphone18.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult25.appendAlternate('\000');
        java.lang.String str28 = doubleMetaphoneResult25.getAlternate();
        java.lang.String str29 = doubleMetaphoneResult25.getPrimary();
        java.lang.Object obj30 = caverphone9.encode((java.lang.Object) str29);
        java.lang.String str32 = caverphone9.caverphone("");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex33 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char35 = refinedSoundex33.getMappingCode('a');
        int int38 = refinedSoundex33.difference("", "hi!");
        int int41 = refinedSoundex33.difference("", "A");
        java.lang.Object obj42 = caverphone9.encode((java.lang.Object) "");
        java.lang.String str44 = caverphone9.caverphone("O0940103030808306030830609053016080940103030808306030830609053016080931");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj45 = refinedSoundex8.encode((java.lang.Object) caverphone9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "1111111111" + "'", obj30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "1111111111" + "'", str32, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex33);
        org.junit.Assert.assertTrue("'" + char35 + "' != '" + '0' + "'", char35 == '0');
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "1111111111" + "'", obj42, "1111111111");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "A111111111" + "'", str44, "A111111111");
    }

    @Test
    public void test1971() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1971");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str13 = metaphone0.encode("A313");
        java.lang.String str15 = metaphone0.encode("ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test1972() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1972");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str7 = metaphone0.metaphone("A#");
        java.lang.String str9 = metaphone0.encode("org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A" + "'", str7, "A");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
    }

    @Test
    public void test1973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1973");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.encode("");
        boolean boolean28 = caverphone0.isCaverphoneEqual("", "A#");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.String str32 = caverphone0.encode("A621HI0A093138363836931589313836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AA11111111" + "'", str32, "AA11111111");
    }

    @Test
    public void test1974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1974");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        metaphone0.setMaxCodeLen((int) '0');
        metaphone0.setMaxCodeLen(0);
        java.lang.String str18 = metaphone0.encode("ARKP");
        int int19 = metaphone0.getMaxCodeLen();
        boolean boolean22 = metaphone0.isMetaphoneEqual("ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKT", "H0");
        char[] charArray24 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex25 = new org.apache.commons.codec.language.RefinedSoundex(charArray24);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex26 = new org.apache.commons.codec.language.RefinedSoundex(charArray24);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex27 = new org.apache.commons.codec.language.RefinedSoundex(charArray24);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = metaphone0.encode((java.lang.Object) charArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertArrayEquals(charArray24, new char[] { 'a' });
    }

    @Test
    public void test1975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1975");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        boolean boolean10 = metaphone0.isMetaphoneEqual("AA11111111", "A212");
        java.lang.Object obj11 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = metaphone0.encode(obj11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test1976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1976");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        char char13 = refinedSoundex0.getMappingCode('4');
        java.lang.String str15 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        char char17 = refinedSoundex0.getMappingCode('K');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O09401030308083060308306090530160809315383638369315893153836383693158931" + "'", str15, "O09401030308083060308306090530160809315383638369315893153836383693158931");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '3' + "'", char17 == '3');
    }

    @Test
    public void test1977() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1977");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        java.lang.String str10 = refinedSoundex8.soundex("");
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test1978() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1978");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        int int7 = soundex0.getMaxLength();
        java.lang.String str9 = soundex0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
    }

    @Test
    public void test1979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1979");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.soundex("O0940103030808306030830609053016080931");
        int int10 = refinedSoundex5.difference("O0940103030808306030830609053016080313836", "ARKPXKMNSKTKNKTRKS");
        int int13 = refinedSoundex5.difference("org.apache.commons.codec.EncoderException: 4", "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSNi");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O0" + "'", str7, "O0");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
    }

    @Test
    public void test1980() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1980");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test1981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1981");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone0.maxCodeLen = '0';
        int int7 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str9 = doubleMetaphone0.encode("AKP");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "AKPK111111", "org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 48 + "'", int7 == 48);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKP" + "'", str9, "AKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test1982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1982");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        soundex1.setMaxLength(0);
        java.lang.String str13 = soundex1.encode("A0313");
        java.lang.String str15 = soundex1.soundex("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A000" + "'", str13, "A000");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test1983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1983");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray2);
        java.lang.String str7 = soundex5.soundex("A000");
        char[] charArray8 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray8);
        soundex9.setMaxLength(1);
        int int12 = soundex9.getMaxLength();
        int int15 = soundex9.difference("HI", "");
        java.lang.String str17 = soundex9.soundex("O0940103030808306030830609053016080");
        int int20 = soundex9.difference("A#", "H0");
        int int21 = soundex9.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = soundex5.encode((java.lang.Object) int21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O000" + "'", str17, "O000");
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test1984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1984");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "ARK", "H0");
        java.lang.String str12 = refinedSoundex4.soundex("A0");
        java.lang.String str14 = refinedSoundex4.encode("org.apache.commons.codec.EncoderException: A ");
        int int17 = refinedSoundex4.difference("org.apache.commons.codec.EncoderException: O000", " AKPKMNSKTK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0" + "'", str12, "A0");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O062010202050520302052030602013050" + "'", str14, "O062010202050520302052030602013050");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test1985() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1985");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        boolean boolean13 = doubleMetaphone8.isDoubleMetaphoneEqual("01230120022455012623010202", "");
        java.lang.Object obj14 = soundex1.encode((java.lang.Object) "01230120022455012623010202");
        java.lang.String str16 = soundex1.encode("");
        int int17 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int20 = soundex1.difference("1111111111", "A313");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "" + "'", obj14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test1986() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1986");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int9 = soundex4.difference("AKP1111111", "AKPK");
        int int12 = soundex4.difference("org.apache.commons.codec.EncoderException: ", "ARKP");
        soundex4.setMaxLength((int) (byte) 0);
        soundex4.setMaxLength(65);
        int int17 = soundex4.getMaxLength();
        soundex4.setMaxLength(0);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 65 + "'", int17 == 65);
    }

    @Test
    public void test1987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1987");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        java.lang.String str10 = soundex4.encode(" AKPK");
        java.lang.String str12 = soundex4.soundex("A620");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A212" + "'", str10, "A212");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A000" + "'", str12, "A000");
    }

    @Test
    public void test1988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1988");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKTRKSPXNRKP", "org.apache.commons.codec.EncoderException: A000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test1989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1989");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        soundex0.setMaxLength(65);
        int int6 = soundex0.difference("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080940103030808306030830609053016080", "O09315383638369315893153836383693158");
        int int9 = soundex0.difference("", "A621HI0A093138363836931589313836383693158g");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test1990() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1990");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        java.lang.String str13 = metaphone0.encode("hi!");
        int int14 = metaphone0.getMaxCodeLen();
        java.lang.Object obj15 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = metaphone0.encode(obj15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test1991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1991");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = soundex1.encode("A621HI0A093138363836931589313836383693158");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test1992() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1992");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str13 = caverphone0.encode("HI");
        java.lang.String str15 = caverphone0.caverphone("ORK");
        boolean boolean18 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "A621HIo");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A111111111" + "'", str11, "A111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AA11111111" + "'", str13, "AA11111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test1993() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1993");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("ARKP");
        boolean boolean11 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "ORK");
        int int12 = metaphone0.getMaxCodeLen();
        java.lang.String str14 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen(45);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ARKP" + "'", str8, "ARKP");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPK" + "'", str14, "AKPK");
    }

    @Test
    public void test1994() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1994");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.caverphone("O941");
        java.lang.String str14 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        java.lang.String str16 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKKMNSKT" + "'", str14, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKKMNSKT" + "'", str16, "AKPKKMNSKT");
    }

    @Test
    public void test1995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1995");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = '\000';
        doubleMetaphone8.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone8.new DoubleMetaphoneResult((int) '1');
        doubleMetaphoneResult14.appendPrimary(' ');
        doubleMetaphoneResult14.appendAlternate("A621");
        doubleMetaphoneResult14.appendAlternate('#');
        doubleMetaphoneResult14.append("O941", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Object obj24 = refinedSoundex4.encode((java.lang.Object) "O941");
        char char26 = refinedSoundex4.getMappingCode('a');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "O0" + "'", obj24, "O0");
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
    }

    @Test
    public void test1996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1996");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (short) 0);
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        metaphone10.setMaxCodeLen(3);
        int int13 = metaphone10.getMaxCodeLen();
        boolean boolean16 = metaphone10.isMetaphoneEqual("", "");
        boolean boolean19 = metaphone10.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean22 = metaphone10.isMetaphoneEqual("A621", "");
        boolean boolean25 = metaphone10.isMetaphoneEqual("AKPKKMNSKT", "A111111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = soundex1.encode((java.lang.Object) metaphone10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test1997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1997");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (short) 1);
        int int6 = soundex1.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone7 = new org.apache.commons.codec.language.Metaphone();
        metaphone7.setMaxCodeLen(3);
        int int10 = metaphone7.getMaxCodeLen();
        boolean boolean13 = metaphone7.isMetaphoneEqual("", "");
        boolean boolean16 = metaphone7.isMetaphoneEqual("01230120022455012623010202", "");
        int int19 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone7, "01230120022455012623010202", "");
        metaphone7.setMaxCodeLen((int) '0');
        metaphone7.setMaxCodeLen(0);
        java.lang.String str25 = metaphone7.encode("O093");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = soundex1.encode((java.lang.Object) metaphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
    }

    @Test
    public void test1998() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1998");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A000");
        java.lang.String str8 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ARKP");
        java.lang.String str10 = caverphone0.encode("");
        java.lang.String str12 = caverphone0.encode("ARK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "1111111111" + "'", str10, "1111111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AK11111111" + "'", str12, "AK11111111");
    }

    @Test
    public void test1999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1999");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) '0');
        int int8 = soundex1.getMaxLength();
        int int9 = soundex1.getMaxLength();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 48 + "'", int8 == 48);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 48 + "'", int9 == 48);
    }

    @Test
    public void test2000() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test2000");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("ARKP");
        java.lang.String str10 = metaphone0.encode("org.apache.commons.codec.EncoderException: AK11111111");
        java.lang.String str12 = metaphone0.encode("aORGAPACHECOMMONSCODECENCODEREXC");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean22 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone13.maxCodeLen = 3;
        boolean boolean28 = doubleMetaphone13.isDoubleMetaphoneEqual("H0", "1111111111", false);
        java.lang.String str31 = doubleMetaphone13.doubleMetaphone("A0", true);
        java.lang.String str33 = doubleMetaphone13.doubleMetaphone("ARKPKSKMNSKTKNKTRKSPKSN");
        java.lang.Object obj34 = metaphone0.encode((java.lang.Object) str33);
        int int35 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone36 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str38 = doubleMetaphone36.doubleMetaphone("H");
        doubleMetaphone36.setMaxCodeLen((int) (byte) 0);
        java.lang.String str43 = doubleMetaphone36.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult45 = doubleMetaphone36.new DoubleMetaphoneResult(0);
        int int46 = doubleMetaphone36.maxCodeLen;
        java.lang.String str48 = doubleMetaphone36.encode("O941");
        int int49 = doubleMetaphone36.maxCodeLen;
        java.lang.String str51 = doubleMetaphone36.encode("org.apache.commons.codec.EncoderException: org.ap");
        doubleMetaphone36.maxCodeLen = '.';
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj54 = metaphone0.encode((java.lang.Object) '.');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ARKP" + "'", str8, "ARKP");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "ORKP" + "'", str10, "ORKP");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ARKP" + "'", str12, "ARKP");
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "A" + "'", str31, "A");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "ARK" + "'", str33, "ARK");
        org.junit.Assert.assertEquals("'" + obj34 + "' != '" + "ARK" + "'", obj34, "ARK");
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "" + "'", str48, "");
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
    }
}

