package org.apache.commons.codec.language;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1001");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        int int3 = doubleMetaphone0.maxCodeLen;
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ORK", "A111111111");
        doubleMetaphone0.maxCodeLen = 0;
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("A0313836");
        doubleMetaphone0.setMaxCodeLen(38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test1002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1002");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        org.apache.commons.codec.language.Caverphone caverphone6 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str8 = caverphone6.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str10 = caverphone6.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str12 = caverphone6.encode("");
        java.lang.String str14 = caverphone6.encode("01230120022455012623010202");
        java.lang.String str16 = caverphone6.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str18 = caverphone6.caverphone("A");
        java.lang.String str20 = caverphone6.caverphone("");
        java.lang.String str22 = caverphone6.caverphone("org.apache.commons.codec.EncoderException: O000");
        java.lang.Object obj23 = refinedSoundex0.encode((java.lang.Object) str22);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "1111111111" + "'", str12, "1111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "1111111111" + "'", str14, "1111111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKKMNSKT" + "'", str16, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A111111111" + "'", str18, "A111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "1111111111" + "'", str20, "1111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + obj23 + "' != '" + "A0313836" + "'", obj23, "A0313836");
    }

    @Test
    public void test1003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1003");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        java.lang.String str6 = metaphone0.encode("ARKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "ARKP" + "'", str6, "ARKP");
    }

    @Test
    public void test1004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1004");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        soundex0.setMaxLength(65);
        int int6 = soundex0.difference("  ", "org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = 0;
        char char12 = doubleMetaphone7.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone7.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult14.appendAlternate("A111111111");
        java.lang.String str17 = doubleMetaphoneResult14.getAlternate();
        java.lang.Object obj18 = soundex0.encode((java.lang.Object) str17);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone19 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone19.maxCodeLen = 0;
        java.lang.String str23 = doubleMetaphone19.encode("A621");
        boolean boolean27 = doubleMetaphone19.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        java.lang.String str29 = doubleMetaphone19.encode("");
        boolean boolean33 = doubleMetaphone19.isDoubleMetaphoneEqual("A621", "org.apache.commons.codec.EncoderException: hi!", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = soundex0.encode((java.lang.Object) doubleMetaphone19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
        org.junit.Assert.assertEquals("'" + obj18 + "' != '" + "A000" + "'", obj18, "A000");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test1005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1005");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (short) 0);
        java.lang.Class<?> wildcardClass10 = soundex1.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test1006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1006");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        int int10 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) 'a');
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.String str16 = metaphone0.encode("AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKMNSKTK" + "'", str16, "AKPKMNSKTK");
    }

    @Test
    public void test1007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1007");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTKNKTRKSSPXNH", "AKP1111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1008");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        char char6 = refinedSoundex4.getMappingCode('4');
        java.lang.String str8 = refinedSoundex4.encode("A093153836383693158");
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A1" + "'", str8, "A1");
    }

    @Test
    public void test1009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1009");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.metaphone("A0");
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str11 = caverphone5.encode("");
        java.lang.String str13 = caverphone5.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = 0;
        char char19 = doubleMetaphone14.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone14.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult21.appendAlternate('\000');
        java.lang.String str24 = doubleMetaphoneResult21.getAlternate();
        java.lang.String str25 = doubleMetaphoneResult21.getPrimary();
        java.lang.Object obj26 = caverphone5.encode((java.lang.Object) str25);
        java.lang.String str28 = caverphone5.caverphone("");
        int int31 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone5, "AKPKKMNSKT", "ORKP");
        java.lang.Object obj32 = metaphone0.encode((java.lang.Object) "AKPKKMNSKT");
        int int35 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA", "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKPKKMNSKT" + "'", str9, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "1111111111" + "'", obj26, "1111111111");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "1111111111" + "'", str28, "1111111111");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "" + "'", obj32, "");
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test1010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1010");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        int int7 = soundex1.getMaxLength();
        int int10 = soundex1.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = 0;
        char char16 = doubleMetaphone11.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone11.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult18.append(' ');
        java.lang.String str21 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj22 = soundex1.encode((java.lang.Object) str21);
        java.lang.Class<?> wildcardClass23 = soundex1.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + " " + "'", str21, " ");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "" + "'", obj22, "");
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test1011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1011");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("", "Aa");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test1012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1012");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.soundex("O0940103030808306030830609053016080");
        java.lang.String str15 = refinedSoundex0.soundex("AKPKKMNSKT");
        char char17 = refinedSoundex0.getMappingCode('1');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A0313836" + "'", str15, "A0313836");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
    }

    @Test
    public void test1013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1013");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex1.difference("hi!", "A313");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test1014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1014");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        char char16 = doubleMetaphone9.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone9.new DoubleMetaphoneResult((int) '4');
        java.lang.String str19 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) str19);
        boolean boolean23 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: 01230120022455012623010202", "org.apache.commons.codec.EncoderException: A111111111O620");
        java.lang.String str25 = caverphone0.caverphone("A093138363836931589313836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + 'i' + "'", char16 == 'i');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "1111111111" + "'", obj20, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A111111111" + "'", str25, "A111111111");
    }

    @Test
    public void test1015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1015");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: A093153836383693158", "K");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1016");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int3 = soundex0.difference("A1", " ");
        java.lang.String str5 = soundex0.encode("K3");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "K000" + "'", str5, "K000");
    }

    @Test
    public void test1017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1017");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        soundex3.setMaxLength((-1));
        int int9 = soundex3.getMaxLength();
        java.lang.String str11 = soundex3.encode("A09");
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A000" + "'", str11, "A000");
    }

    @Test
    public void test1018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1018");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTSNKTRKSSPXN", "A0931383");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1019");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        char char24 = doubleMetaphone11.charAt("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", (int) 'A');
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone26 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str28 = doubleMetaphone26.doubleMetaphone("H");
        doubleMetaphone26.setMaxCodeLen((int) (byte) 0);
        char char33 = doubleMetaphone26.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult35 = doubleMetaphone26.new DoubleMetaphoneResult((int) '4');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = refinedSoundex0.encode((java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0931" + "'", str10, "O0931");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "O0940103030808306030830609053016080" + "'", obj25, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertTrue("'" + char33 + "' != '" + 'i' + "'", char33 == 'i');
    }

    @Test
    public void test1020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1020");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj12 = refinedSoundex0.encode((java.lang.Object) "O941");
        char char14 = refinedSoundex0.getMappingCode('0');
        java.lang.String str16 = refinedSoundex0.encode("ARKPKKMNSKTKNKTRKSPXNRKP");
        int int19 = refinedSoundex0.difference("hi!", "");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "O0" + "'", obj12, "O0");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A09313836383693158931" + "'", str16, "A09313836383693158931");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test1021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1021");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK", "ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test1022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1022");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        metaphone0.setMaxCodeLen(43);
    }

    @Test
    public void test1023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1023");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        boolean boolean12 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "AKPK");
        java.lang.String str14 = metaphone0.encode("A0");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A" + "'", str14, "A");
    }

    @Test
    public void test1024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1024");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.Class<?> wildcardClass4 = metaphone0.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test1025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1025");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = soundex1.soundex("O0940103030808306030830609053016080313836");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test1026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1026");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone0.maxCodeLen = '0';
        int int7 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str9 = doubleMetaphone0.encode("AKP");
        doubleMetaphone0.setMaxCodeLen(48);
        java.lang.String str14 = doubleMetaphone0.doubleMetaphone("A111111111O620", false);
        java.lang.String str17 = doubleMetaphone0.doubleMetaphone("Aa", false);
        org.apache.commons.codec.language.Soundex soundex18 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str20 = soundex18.encode("ARKP");
        java.lang.String str22 = soundex18.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int23 = soundex18.getMaxLength();
        java.lang.String str25 = soundex18.encode("");
        char[] charArray26 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex27 = new org.apache.commons.codec.language.Soundex(charArray26);
        java.lang.String str29 = soundex27.encode("org.apache.commons.codec.EncoderException: hi!");
        java.lang.Object obj30 = soundex18.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: hi!");
        int int33 = soundex18.difference("AKPKMNSKTK", "AKPKSKMNSK");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = doubleMetaphone0.encode((java.lang.Object) int33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 48 + "'", int7 == 48);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKP" + "'", str9, "AKP");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A" + "'", str14, "A");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A" + "'", str17, "A");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "A621" + "'", str20, "A621");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O621" + "'", str22, "O621");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "O621" + "'", str29, "O621");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "O621" + "'", obj30, "O621");
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
    }

    @Test
    public void test1027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1027");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.soundex("HI");
        java.lang.String str9 = refinedSoundex0.encode("A212");
        java.lang.String str11 = refinedSoundex0.soundex("O621");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A0" + "'", str9, "A0");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
    }

    @Test
    public void test1028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1028");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        java.lang.String str23 = metaphone0.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSK" + "'", str23, "ORKPXKMNSK");
    }

    @Test
    public void test1029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1029");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int3 = soundex0.getMaxLength();
        soundex0.setMaxLength(10);
        java.lang.String str7 = soundex0.soundex("A621HI");
        java.lang.String str9 = soundex0.encode("A931");
        soundex0.setMaxLength(97);
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A000" + "'", str9, "A000");
    }

    @Test
    public void test1030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1030");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: HI");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
    }

    @Test
    public void test1031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1031");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: O620");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test1032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1032");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        java.lang.String str19 = caverphone0.caverphone("ARKPXKMNSK");
        java.lang.String str21 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str23 = caverphone0.encode("A031");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSK11" + "'", str19, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKMNSKT1" + "'", str21, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A111111111" + "'", str23, "A111111111");
    }

    @Test
    public void test1033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1033");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        java.lang.String str14 = soundex3.encode("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        int int15 = soundex3.getMaxLength();
        int int16 = soundex3.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O621" + "'", str14, "O621");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test1034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1034");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        java.lang.String str10 = metaphone0.metaphone("A931");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.setMaxCodeLen(10);
        doubleMetaphone11.maxCodeLen = 1;
        doubleMetaphone11.maxCodeLen = 4;
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone11.new DoubleMetaphoneResult((int) (short) -1);
        doubleMetaphone11.setMaxCodeLen(100);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = metaphone0.encode((java.lang.Object) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
    }

    @Test
    public void test1035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1035");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        org.apache.commons.codec.language.Metaphone metaphone19 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str21 = metaphone19.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone19.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone24 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str26 = caverphone24.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str28 = caverphone24.caverphone("hi!");
        java.lang.Object obj29 = metaphone19.encode((java.lang.Object) "hi!");
        java.lang.String str31 = metaphone19.encode("O0940103030808306030830609053016080");
        java.lang.Object obj32 = metaphone0.encode((java.lang.Object) str31);
        metaphone0.setMaxCodeLen((int) '8');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ORKP" + "'", str21, "ORKP");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "AKPKKMNSKT" + "'", str26, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AA11111111" + "'", str28, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "H" + "'", obj29, "H");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "O" + "'", str31, "O");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "O" + "'", obj32, "O");
    }

    @Test
    public void test1036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1036");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("AKPKMNSKT1", "");
        java.lang.String str7 = soundex2.soundex("org.apache.commons.codec.EncoderException: ORKP");
        int int8 = soundex2.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O621" + "'", str7, "O621");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test1037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1037");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int9 = soundex6.difference("org.apache.commons.codec.EncoderException: ARKP", "AKPKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1038");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        soundex0.setMaxLength(0);
        java.lang.String str12 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int13 = soundex0.getMaxLength();
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("HI");
        org.apache.commons.codec.EncoderException encoderException17 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray18 = encoderException17.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException20 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException17.addSuppressed((java.lang.Throwable) encoderException20);
        encoderException15.addSuppressed((java.lang.Throwable) encoderException20);
        org.apache.commons.codec.EncoderException encoderException24 = new org.apache.commons.codec.EncoderException("A ");
        org.apache.commons.codec.EncoderException encoderException26 = new org.apache.commons.codec.EncoderException("A0");
        java.lang.Throwable[] throwableArray27 = encoderException26.getSuppressed();
        encoderException24.addSuppressed((java.lang.Throwable) encoderException26);
        java.lang.Throwable[] throwableArray29 = encoderException24.getSuppressed();
        encoderException15.addSuppressed((java.lang.Throwable) encoderException24);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = soundex0.encode((java.lang.Object) encoderException24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O000" + "'", str12, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertArrayEquals(throwableArray18, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertArrayEquals(throwableArray27, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray29);
    }

    @Test
    public void test1039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1039");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        java.lang.String str13 = metaphone0.encode("hi!");
        java.lang.Object obj14 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = metaphone0.encode(obj14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
    }

    @Test
    public void test1040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1040");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("");
        java.lang.String str10 = metaphone0.metaphone("A1111111114r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AR" + "'", str10, "AR");
    }

    @Test
    public void test1041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1041");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "AKPKSKMNSK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1042");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str18 = metaphone0.encode("A111111111");
        boolean boolean21 = metaphone0.isMetaphoneEqual("O931", "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNH" + "'", str16, "ORKPXKMNSKTKNKTRKSSPXNH");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A" + "'", str18, "A");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test1043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1043");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength(2);
        java.lang.String str4 = soundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
    }

    @Test
    public void test1044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1044");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        java.lang.String str6 = soundex4.encode("");
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test1045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1045");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str10 = metaphone0.metaphone("O");
        boolean boolean13 = metaphone0.isMetaphoneEqual("A0313836", "ORK");
        java.lang.String str15 = metaphone0.metaphone("A03138363");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test1046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1046");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT", "AKPKSKMNS1");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test1047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1047");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = '\000';
        int int3 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str5 = doubleMetaphone0.encode("ARKP");
        java.lang.String str8 = doubleMetaphone0.doubleMetaphone("", true);
        org.apache.commons.codec.language.Metaphone metaphone9 = new org.apache.commons.codec.language.Metaphone();
        metaphone9.setMaxCodeLen(3);
        java.lang.String str13 = metaphone9.encode("");
        java.lang.String str15 = metaphone9.encode("");
        metaphone9.setMaxCodeLen((int) (byte) 0);
        java.lang.String str19 = metaphone9.metaphone("O");
        java.lang.String str21 = metaphone9.encode("O093");
        java.lang.Object obj22 = doubleMetaphone0.encode((java.lang.Object) "O093");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult24 = doubleMetaphone0.new DoubleMetaphoneResult(111);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "" + "'", obj22, "");
    }

    @Test
    public void test1048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1048");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.caverphone("A");
        java.lang.String str36 = caverphone0.encode("A09315383");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone37 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone37.maxCodeLen = 0;
        char char42 = doubleMetaphone37.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str44 = doubleMetaphone37.encode("A");
        java.lang.Object obj46 = doubleMetaphone37.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone37.maxCodeLen = (byte) 1;
        char char51 = doubleMetaphone37.charAt("", (int) (short) -1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult53 = doubleMetaphone37.new DoubleMetaphoneResult((int) '0');
        doubleMetaphoneResult53.append("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj57 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "A111111111" + "'", str36, "A111111111");
        org.junit.Assert.assertTrue("'" + char42 + "' != '" + '\000' + "'", char42 == '\000');
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
        org.junit.Assert.assertEquals("'" + obj46 + "' != '" + "" + "'", obj46, "");
        org.junit.Assert.assertTrue("'" + char51 + "' != '" + '\000' + "'", char51 == '\000');
    }

    @Test
    public void test1049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1049");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str13 = caverphone0.encode("AKP1111111");
        java.lang.String str15 = caverphone0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKP1111111" + "'", str13, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
    }

    @Test
    public void test1050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1050");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.encode("A0313836");
        int int23 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A" + "'", str22, "A");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
    }

    @Test
    public void test1051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1051");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 100);
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "");
        char char12 = doubleMetaphone0.charAt("", (int) (byte) 1);
        doubleMetaphone0.setMaxCodeLen((int) (short) 10);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
    }

    @Test
    public void test1052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1052");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        java.lang.String str12 = doubleMetaphone8.doubleMetaphone("");
        java.lang.String str15 = doubleMetaphone8.doubleMetaphone("ORKP", true);
        java.lang.String str18 = doubleMetaphone8.doubleMetaphone("", false);
        java.lang.String str20 = doubleMetaphone8.encode("");
        java.lang.Object obj21 = refinedSoundex0.encode((java.lang.Object) "");
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: hi!");
        java.lang.Throwable[] throwableArray24 = encoderException23.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException26 = new org.apache.commons.codec.EncoderException("AA11111111");
        org.apache.commons.codec.EncoderException encoderException28 = new org.apache.commons.codec.EncoderException("AKPKKMNSKT");
        encoderException26.addSuppressed((java.lang.Throwable) encoderException28);
        org.apache.commons.codec.EncoderException encoderException31 = new org.apache.commons.codec.EncoderException("01230120022455012623010202");
        encoderException26.addSuppressed((java.lang.Throwable) encoderException31);
        encoderException23.addSuppressed((java.lang.Throwable) encoderException26);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = refinedSoundex0.encode((java.lang.Object) encoderException26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ARKP" + "'", str15, "ARKP");
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "" + "'", obj21, "");
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertArrayEquals(throwableArray24, new java.lang.Throwable[] {});
    }

    @Test
    public void test1053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1053");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        metaphone0.setMaxCodeLen((int) '0');
        metaphone0.setMaxCodeLen(0);
        java.lang.String str18 = metaphone0.encode("O093");
        java.lang.String str20 = metaphone0.encode("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
    }

    @Test
    public void test1054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1054");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.String str16 = metaphone0.metaphone("A");
        int int17 = metaphone0.getMaxCodeLen();
        boolean boolean20 = metaphone0.isMetaphoneEqual("ARK", "ARKPXKMNSKTSNKTRKSPXN");
        java.lang.String str22 = metaphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O" + "'", str22, "O");
    }

    @Test
    public void test1055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1055");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str13 = caverphone0.encode("AKP1111111");
        java.lang.String str15 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: A093153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKP1111111" + "'", str13, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
    }

    @Test
    public void test1056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1056");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        int int17 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(0);
        boolean boolean22 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: A#", "org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        metaphone0.setMaxCodeLen((int) 'A');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test1057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1057");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("A1111111114r");
        java.lang.String str12 = caverphone0.caverphone("A000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
    }

    @Test
    public void test1058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1058");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        int int17 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(0);
        boolean boolean22 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: A#", "org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        metaphone0.setMaxCodeLen((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test1059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1059");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        java.lang.String str19 = caverphone0.encode("H");
        boolean boolean22 = caverphone0.isCaverphoneEqual("O0931", "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A111111111" + "'", str19, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test1060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1060");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKMNSKTK" + "'", str10, "AKPKMNSKTK");
    }

    @Test
    public void test1061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1061");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        java.lang.String str19 = caverphone0.caverphone("ARKPXKMNSK");
        java.lang.String str21 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str23 = caverphone0.encode("A621");
        boolean boolean26 = caverphone0.isCaverphoneEqual("ARKPKKMNSKTKNKTRKSPXNRKP", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSK11" + "'", str19, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKMNSKT1" + "'", str21, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A111111111" + "'", str23, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test1062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1062");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex1.encode(" AKPK");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test1063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1063");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone13.encode("O621");
        char[] charArray18 = null;
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray18);
        java.lang.String str21 = soundex19.soundex("");
        java.lang.String str23 = soundex19.encode("");
        java.lang.Object obj24 = caverphone13.encode((java.lang.Object) str23);
        java.lang.Class<?> wildcardClass25 = obj24.getClass();
        java.lang.Object obj26 = refinedSoundex5.encode(obj24);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str28 = refinedSoundex5.encode("ORKPXKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "1111111111" + "'", obj24, "1111111111");
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "" + "'", obj26, "");
    }

    @Test
    public void test1064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1064");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("A0313836");
        int int27 = refinedSoundex0.difference("O0940103030808306030830609053016080", "A1111111114r");
        org.apache.commons.codec.EncoderException encoderException29 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException31 = new org.apache.commons.codec.EncoderException("");
        encoderException29.addSuppressed((java.lang.Throwable) encoderException31);
        org.apache.commons.codec.EncoderException encoderException34 = new org.apache.commons.codec.EncoderException("hi!");
        encoderException31.addSuppressed((java.lang.Throwable) encoderException34);
        org.apache.commons.codec.EncoderException encoderException37 = new org.apache.commons.codec.EncoderException("HI");
        encoderException34.addSuppressed((java.lang.Throwable) encoderException37);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = refinedSoundex0.encode((java.lang.Object) encoderException37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A0" + "'", str24, "A0");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test1065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1065");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = '\000';
        char char18 = doubleMetaphone13.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone13.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult20.append("ORK", "O620");
        java.lang.Object obj24 = metaphone0.encode((java.lang.Object) "O620");
        metaphone0.setMaxCodeLen((int) (byte) -1);
        java.lang.String str28 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNH");
        org.apache.commons.codec.language.Metaphone metaphone29 = new org.apache.commons.codec.language.Metaphone();
        metaphone29.setMaxCodeLen(3);
        java.lang.String str33 = metaphone29.encode("");
        int int36 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone29, "hi!", "");
        metaphone29.setMaxCodeLen(0);
        java.lang.String str40 = metaphone29.encode("AK11111111");
        java.lang.String str42 = metaphone29.encode("A1");
        boolean boolean45 = metaphone29.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "H");
        boolean boolean48 = metaphone29.isMetaphoneEqual("A0313", "A062125232523621256212523252362125");
        java.lang.Object obj49 = metaphone0.encode((java.lang.Object) "A062125232523621256212523252362125");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "O" + "'", obj24, "O");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "" + "'", str40, "");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertEquals("'" + obj49 + "' != '" + "" + "'", obj49, "");
    }

    @Test
    public void test1066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1066");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
    }

    @Test
    public void test1067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1067");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        java.lang.String str12 = doubleMetaphone0.encode("A#");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
    }

    @Test
    public void test1068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1068");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("KPK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "KPK" + "'", str1, "KPK");
    }

    @Test
    public void test1069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1069");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        soundex1.setMaxLength((int) (byte) 1);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test1070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1070");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A621HI0A093138363836931589313836383693158M");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AHIAM" + "'", str1, "AHIAM");
    }

    @Test
    public void test1071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1071");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        java.lang.Class<?> wildcardClass8 = soundex1.getClass();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test1072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1072");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.soundex("O0940103030808306030830609053016080931");
        char char9 = refinedSoundex5.getMappingCode('i');
        int int12 = refinedSoundex5.difference("", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O0" + "'", str7, "O0");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test1073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1073");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = soundex9.soundex("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1074");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        org.apache.commons.codec.EncoderException encoderException30 = new org.apache.commons.codec.EncoderException("HI");
        org.apache.commons.codec.EncoderException encoderException32 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray33 = encoderException32.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException35 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException32.addSuppressed((java.lang.Throwable) encoderException35);
        encoderException30.addSuppressed((java.lang.Throwable) encoderException35);
        org.apache.commons.codec.EncoderException encoderException39 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException41 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray42 = encoderException41.getSuppressed();
        encoderException39.addSuppressed((java.lang.Throwable) encoderException41);
        org.apache.commons.codec.EncoderException encoderException45 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: A0");
        encoderException41.addSuppressed((java.lang.Throwable) encoderException45);
        java.lang.Throwable[] throwableArray47 = encoderException41.getSuppressed();
        encoderException30.addSuppressed((java.lang.Throwable) encoderException41);
        java.lang.Throwable[] throwableArray49 = encoderException30.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj50 = caverphone0.encode((java.lang.Object) throwableArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertArrayEquals(throwableArray33, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertArrayEquals(throwableArray42, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test1075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1075");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex4.setMaxLength((int) (short) 0);
        java.lang.String str8 = soundex4.encode("");
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test1076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1076");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = 100;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "");
        int int21 = doubleMetaphone0.maxCodeLen;
        char char24 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: O000", (int) '9');
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult26 = doubleMetaphone0.new DoubleMetaphoneResult((int) (byte) 0);
        doubleMetaphoneResult26.append('8');
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
    }

    @Test
    public void test1077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1077");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONO" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
    }

    @Test
    public void test1078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1078");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int6 = soundex3.difference("org.apache.commons.codec.EncoderException: ARK", "O941");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test1079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1079");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("O093");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A313", "org.apache.commons.codec.EncoderException: ");
        java.lang.String str19 = metaphone0.encode("AKPKKMNSKT");
        char[] charArray20 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex21 = new org.apache.commons.codec.language.Soundex(charArray20);
        org.apache.commons.codec.language.Soundex soundex22 = new org.apache.commons.codec.language.Soundex(charArray20);
        java.lang.String str24 = soundex22.soundex("org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        java.lang.Object obj25 = metaphone0.encode((java.lang.Object) str24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKP" + "'", str19, "AKP");
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O621" + "'", str24, "O621");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "O" + "'", obj25, "O");
    }

    @Test
    public void test1080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1080");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex11.soundex("AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1081");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("ORKP");
        char char12 = refinedSoundex0.getMappingCode('1');
        java.lang.String str14 = refinedSoundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0931" + "'", str10, "O0931");
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O0" + "'", str14, "O0");
    }

    @Test
    public void test1082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1082");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        java.lang.String str5 = refinedSoundex3.soundex("A000");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = refinedSoundex3.encode("O941");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A1" + "'", str5, "A1");
    }

    @Test
    public void test1083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1083");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str7 = soundex2.soundex("O620");
        java.lang.String str9 = soundex2.soundex("A621");
        java.lang.String str11 = soundex2.encode("A ");
        java.lang.String str13 = soundex2.encode("ORKPXKMNSKTKNKTRKSSPXNH");
        int int16 = soundex2.difference("AK11111111", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O000" + "'", str7, "O000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A000" + "'", str9, "A000");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A000" + "'", str11, "A000");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O931" + "'", str13, "O931");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test1084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1084");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.encode("ARKPXKMNSKTKNKTRKS");
        java.lang.String str8 = soundex4.soundex("A621");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        java.lang.String str16 = doubleMetaphone9.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone9.new DoubleMetaphoneResult(0);
        int int19 = doubleMetaphone9.getMaxCodeLen();
        doubleMetaphone9.setMaxCodeLen((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = soundex4.encode((java.lang.Object) doubleMetaphone9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A621" + "'", str6, "A621");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test1085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1085");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        metaphone0.setMaxCodeLen(19);
        java.lang.String str14 = metaphone0.encode(" AKP1111111 ");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "KP" + "'", str14, "KP");
    }

    @Test
    public void test1086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1086");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        java.lang.Object obj17 = refinedSoundex0.encode((java.lang.Object) "A0");
        java.lang.String str19 = refinedSoundex0.encode("ORK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "A0" + "'", obj17, "A0");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O093" + "'", str19, "O093");
    }

    @Test
    public void test1087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1087");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
    }

    @Test
    public void test1088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1088");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.Object obj3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj4 = refinedSoundex0.encode(obj3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
    }

    @Test
    public void test1089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1089");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        java.lang.String str11 = soundex1.encode("org.apache.commons.codec.EncoderException: hi!");
        int int14 = soundex1.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "01230120022455012623010202");
        int int17 = soundex1.difference("", "org.apache.commons.codec.EncoderExc");
        int int20 = soundex1.difference("ARKPKSKMNSKTKNKTRKSPKSN", "A111111111O620");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O941" + "'", str11, "O941");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test1090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1090");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.encode("A");
        java.lang.String str8 = refinedSoundex4.soundex("O093");
        java.lang.String str10 = refinedSoundex4.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A0" + "'", str6, "A0");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O0" + "'", str8, "O0");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test1091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1091");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int4 = soundex3.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone5 = new org.apache.commons.codec.language.Metaphone();
        metaphone5.setMaxCodeLen(3);
        int int8 = metaphone5.getMaxCodeLen();
        boolean boolean11 = metaphone5.isMetaphoneEqual("", "");
        boolean boolean14 = metaphone5.isMetaphoneEqual("01230120022455012623010202", "");
        java.lang.String str16 = metaphone5.metaphone("01230120022455012623010202");
        java.lang.Object obj17 = soundex3.encode((java.lang.Object) "01230120022455012623010202");
        int int18 = soundex3.getMaxLength();
        java.lang.String str20 = soundex3.encode("HI");
        soundex3.setMaxLength(5);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "" + "'", obj17, "");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H000" + "'", str20, "H000");
    }

    @Test
    public void test1092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1092");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str7 = soundex2.encode("AKPKKMNSKT");
        char[] charArray8 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex12 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = soundex2.encode((java.lang.Object) charArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A313" + "'", str7, "A313");
        org.junit.Assert.assertNotNull(charArray8);
    }

    @Test
    public void test1093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1093");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = soundex7.soundex("ARKPKSKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test1094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1094");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        metaphone0.setMaxCodeLen((int) 'A');
        boolean boolean9 = metaphone0.isMetaphoneEqual("K", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        int int10 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 65 + "'", int10 == 65);
    }

    @Test
    public void test1095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1095");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.soundex(" ");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone5 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str7 = doubleMetaphone5.doubleMetaphone("H");
        doubleMetaphone5.setMaxCodeLen((int) (byte) 0);
        java.lang.String str11 = doubleMetaphone5.encode("H");
        boolean boolean14 = doubleMetaphone5.isDoubleMetaphoneEqual("hi!", "AKPKKMNSKT");
        int int15 = doubleMetaphone5.getMaxCodeLen();
        char char18 = doubleMetaphone5.charAt("1111111111", (int) '1');
        java.lang.String str21 = doubleMetaphone5.doubleMetaphone("ORKP", true);
        boolean boolean24 = doubleMetaphone5.isDoubleMetaphoneEqual("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "O620");
        int int25 = doubleMetaphone5.getMaxCodeLen();
        char char28 = doubleMetaphone5.charAt("HI", (int) (short) 10);
        java.lang.String str30 = doubleMetaphone5.encode("org.apache.commons.codec.EncoderException: ARKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '\000' + "'", char28 == '\000');
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
    }

    @Test
    public void test1096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1096");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        int int5 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone6 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str8 = metaphone6.encode("");
        int int9 = metaphone6.getMaxCodeLen();
        boolean boolean12 = metaphone6.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str15 = metaphone13.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = metaphone13.metaphone("A");
        java.lang.Object obj18 = metaphone6.encode((java.lang.Object) "A");
        java.lang.Object obj19 = metaphone0.encode((java.lang.Object) "A");
        java.lang.String str21 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int22 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone23 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone23.maxCodeLen = 0;
        java.lang.String str27 = doubleMetaphone23.encode("A621");
        boolean boolean31 = doubleMetaphone23.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        java.lang.String str33 = doubleMetaphone23.encode("");
        boolean boolean37 = doubleMetaphone23.isDoubleMetaphoneEqual("A621", "org.apache.commons.codec.EncoderException: hi!", false);
        doubleMetaphone23.maxCodeLen = '0';
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult41 = doubleMetaphone23.new DoubleMetaphoneResult(100);
        int int42 = doubleMetaphone23.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = metaphone0.encode((java.lang.Object) int42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKP" + "'", str15, "ORKP");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A" + "'", str17, "A");
        org.junit.Assert.assertEquals("'" + obj18 + "' != '" + "A" + "'", obj18, "A");
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "A" + "'", obj19, "A");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "O" + "'", str21, "O");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 48 + "'", int42 == 48);
    }

    @Test
    public void test1097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1097");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = soundex8.soundex("ARKPKKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1098");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("HI");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str13 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A0");
        metaphone0.setMaxCodeLen(4);
        boolean boolean18 = metaphone0.isMetaphoneEqual("ORKPXKMNSK", "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H" + "'", str9, "H");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test1099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1099");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str15 = caverphone0.encode("AK11111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str18 = doubleMetaphone16.doubleMetaphone("H");
        doubleMetaphone16.setMaxCodeLen((int) (byte) 0);
        java.lang.String str23 = doubleMetaphone16.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult25 = doubleMetaphone16.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult25.append('#', 'a');
        doubleMetaphoneResult25.append('O');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = caverphone0.encode((java.lang.Object) 'O');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKT1" + "'", str13, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test1100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1100");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        java.lang.String str24 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        boolean boolean27 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN", "A621HIo");
        java.lang.String str29 = metaphone0.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORKPXKMNSK" + "'", str24, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ORKPXKMNSK" + "'", str29, "ORKPXKMNSK");
    }

    @Test
    public void test1101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1101");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: hi!", "AKP");
        soundex1.setMaxLength((int) '#');
        int int10 = soundex1.difference(" ", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str12 = soundex1.encode("O");
        soundex1.setMaxLength(52);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O000" + "'", str12, "O000");
    }

    @Test
    public void test1102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1102");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("K120");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "K" + "'", str1, "K");
    }

    @Test
    public void test1103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1103");
        char[] charArray2 = new char[] { '1', 'a' };
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            int int7 = soundex4.difference("AR", "org.apache.commons.codec.EncoderException: AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', 'a' });
    }

    @Test
    public void test1104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1104");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        java.lang.String str29 = refinedSoundex0.encode("A621r");
        java.lang.String str31 = refinedSoundex0.encode("AR");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A09" + "'", str29, "A09");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "A09" + "'", str31, "A09");
    }

    @Test
    public void test1105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1105");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.encode("");
        java.lang.String str27 = caverphone0.caverphone("ARKPXKMNSK");
        boolean boolean30 = caverphone0.isCaverphoneEqual("A03138363", "A093153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "AKPKMNSK11" + "'", str27, "AKPKMNSK11");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test1106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1106");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = refinedSoundex5.encode("O0940103030808306030830609053016080931");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test1107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1107");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str8 = metaphone0.encode("O931");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O" + "'", str8, "O");
    }

    @Test
    public void test1108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1108");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str8 = metaphone0.encode("");
        java.lang.String str10 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "ORKPXKMNSKTSNKTRKSSPXN" + "'", str10, "ORKPXKMNSKTSNKTRKSSPXN");
    }

    @Test
    public void test1109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1109");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
    }

    @Test
    public void test1110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1110");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A111111111", "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1111");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.encode("H");
        boolean boolean16 = caverphone0.isCaverphoneEqual("A111111111O620", "hi!");
        java.lang.String str18 = caverphone0.caverphone("01");
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "1111111111" + "'", str18, "1111111111");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "AKPKKMNSKT" + "'", obj20, "AKPKKMNSKT");
    }

    @Test
    public void test1112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1112");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength(100);
        java.lang.String str11 = soundex1.soundex("1111111111");
        // The following exception was thrown during execution in test generation
        try {
            int int14 = soundex1.difference("O941", "org.apache.commons.codec.EncoderException: AA11111111");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
    }

    @Test
    public void test1113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1113");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "ORKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1114");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("H0");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "O09401030308083060308306090530160809315383638369315893153836383693158931", "A1");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone17.maxCodeLen = 0;
        char char22 = doubleMetaphone17.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean26 = doubleMetaphone17.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone17.maxCodeLen = 3;
        java.lang.String str30 = doubleMetaphone17.doubleMetaphone(" ");
        int int31 = doubleMetaphone17.maxCodeLen;
        java.lang.String str34 = doubleMetaphone17.doubleMetaphone("ARKP", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult36 = doubleMetaphone17.new DoubleMetaphoneResult((int) (short) -1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "ARK" + "'", str34, "ARK");
    }

    @Test
    public void test1115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1115");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: A0931");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
    }

    @Test
    public void test1116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1116");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        java.lang.String str10 = caverphone0.encode("1111111111");
        java.lang.String str12 = caverphone0.encode("O941");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "1111111111" + "'", str10, "1111111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
    }

    @Test
    public void test1117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1117");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("A621");
        java.lang.String str13 = refinedSoundex0.encode("O000");
        char char15 = refinedSoundex0.getMappingCode('a');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone16.maxCodeLen = 0;
        char char21 = doubleMetaphone16.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean25 = doubleMetaphone16.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone16.maxCodeLen = 3;
        int int28 = doubleMetaphone16.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = refinedSoundex0.encode((java.lang.Object) int28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '0' + "'", char15 == '0');
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
    }

    @Test
    public void test1118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1118");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str10 = caverphone0.caverphone("ARK");
        int int13 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "O0940103030808306030830609053016080", "O");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKMNSKT", "");
        boolean boolean19 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: A000", "ARKPKKMNSKTKNKTRKSPXNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AK11111111" + "'", str10, "AK11111111");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test1119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1119");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        boolean boolean10 = metaphone0.isMetaphoneEqual("AKP1111111", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        java.lang.String str12 = metaphone0.encode("A931");
        java.lang.String str14 = metaphone0.encode("org.apache.commons.codec.EncoderException: O");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ORKP" + "'", str14, "ORKP");
    }

    @Test
    public void test1120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1120");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.encode("A");
        java.lang.String str8 = refinedSoundex4.soundex("O093");
        java.lang.String str10 = refinedSoundex4.encode("AKPKMNSKT1");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A0" + "'", str6, "A0");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O0" + "'", str8, "O0");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A0212523" + "'", str10, "A0212523");
    }

    @Test
    public void test1121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1121");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        java.lang.String str29 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ORKPXKMNSKTSNKTRKSSPXNRKP" + "'", str29, "ORKPXKMNSKTSNKTRKSSPXNRKP");
    }

    @Test
    public void test1122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1122");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        char char12 = refinedSoundex0.getMappingCode('a');
        java.lang.String str14 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int17 = refinedSoundex0.difference("O094010303080830603083060905301608093", "01230120022455012623010202");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O0940103030808306030830609053016080931" + "'", str14, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test1123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1123");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: hi!");
        int int17 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str20 = doubleMetaphone18.doubleMetaphone("H");
        doubleMetaphone18.setMaxCodeLen((int) (byte) 0);
        java.lang.String str25 = doubleMetaphone18.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult27 = doubleMetaphone18.new DoubleMetaphoneResult(0);
        java.lang.String str28 = doubleMetaphoneResult27.getAlternate();
        doubleMetaphoneResult27.append('\000');
        doubleMetaphoneResult27.appendPrimary('#');
        java.lang.String str33 = doubleMetaphoneResult27.getAlternate();
        doubleMetaphoneResult27.appendPrimary('H');
        doubleMetaphoneResult27.appendPrimary("HI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj38 = metaphone0.encode((java.lang.Object) doubleMetaphoneResult27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNH" + "'", str16, "ORKPXKMNSKTKNKTRKSSPXNH");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
    }

    @Test
    public void test1124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1124");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = 100;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "");
        int int21 = doubleMetaphone0.maxCodeLen;
        char char24 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: O000", (int) '9');
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult26 = doubleMetaphone0.new DoubleMetaphoneResult((int) (byte) 0);
        boolean boolean30 = doubleMetaphone0.isDoubleMetaphoneEqual("Aa", "AKPKMNSK11", false);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test1125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1125");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AKPKSKMNS1", "A621HI0A093138363836931589313836383693158");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1126");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        java.lang.String str6 = soundex1.encode("O0940103030808306030830609053016080931");
        int int9 = soundex1.difference("HI", "O000");
        int int10 = soundex1.getMaxLength();
        java.lang.String str12 = soundex1.soundex("AKP1111111");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O000" + "'", str6, "O000");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A310" + "'", str12, "A310");
    }

    @Test
    public void test1127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1127");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.encode("O09315383638369315893153836383693158931");
        java.lang.String str6 = metaphone0.encode("H");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char9 = refinedSoundex7.getMappingCode('a');
        int int12 = refinedSoundex7.difference("", "hi!");
        char char14 = refinedSoundex7.getMappingCode('#');
        int int17 = refinedSoundex7.difference("AKPKKMNSKT", "A621");
        char char19 = refinedSoundex7.getMappingCode('\000');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = metaphone0.encode((java.lang.Object) refinedSoundex7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "H" + "'", str6, "H");
        org.junit.Assert.assertNotNull(refinedSoundex7);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
    }

    @Test
    public void test1128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1128");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        java.lang.String str9 = soundex1.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = soundex1.encode("H000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test1129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1129");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("1111111111", "A111111111O620");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test1130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1130");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.soundex("org.apache.commons.codec.EncoderException: HI");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O0940103030808306030830609053016080" + "'", str7, "O0940103030808306030830609053016080");
    }

    @Test
    public void test1131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1131");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("", "");
        metaphone0.setMaxCodeLen((int) 'H');
        java.lang.String str20 = metaphone0.metaphone("AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKTK" + "'", str20, "AKPKMNSKTK");
    }

    @Test
    public void test1132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1132");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        java.lang.String str6 = metaphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test1133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1133");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int6 = soundex2.getMaxLength();
        java.lang.String str8 = soundex2.encode("A062125232523621256212523252362125");
        soundex2.setMaxLength((int) (byte) 1);
        int int11 = soundex2.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test1134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1134");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = refinedSoundex3.soundex("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 17 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
    }

    @Test
    public void test1135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1135");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.Class<?> wildcardClass9 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test1136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1136");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        java.lang.String str12 = metaphone0.encode("ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str14 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str16 = metaphone0.encode("01230120022455012623010202");
        java.lang.String str18 = metaphone0.metaphone("H000");
        java.lang.String str20 = metaphone0.metaphone("ARKPKKMNSK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ARKPKSKMNS" + "'", str12, "ARKPKSKMNS");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ORKPXKMNSK" + "'", str14, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "ARKPKMNSK" + "'", str20, "ARKPKMNSK");
    }

    @Test
    public void test1137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1137");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("");
        boolean boolean11 = metaphone0.isMetaphoneEqual("AKPK", "");
        java.lang.String str13 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKS");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ARKP" + "'", str13, "ARKP");
    }

    @Test
    public void test1138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1138");
        char[] charArray6 = new char[] { 'r', '1', ' ', 'i', '#', '#' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        java.lang.String str11 = refinedSoundex9.encode("");
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertArrayEquals(charArray6, new char[] { 'r', '1', ' ', 'i', '#', '#' });
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
    }

    @Test
    public void test1139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1139");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        int int13 = metaphone0.getMaxCodeLen();
        boolean boolean16 = metaphone0.isMetaphoneEqual("", "AA11111111");
        int int19 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "KPK");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone20 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone20.maxCodeLen = 0;
        char char25 = doubleMetaphone20.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str27 = doubleMetaphone20.encode("A");
        doubleMetaphone20.setMaxCodeLen((int) (short) 10);
        boolean boolean32 = doubleMetaphone20.isDoubleMetaphoneEqual("H", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        boolean boolean36 = doubleMetaphone20.isDoubleMetaphoneEqual("A062125232523621256212523252362125", "O", true);
        doubleMetaphone20.setMaxCodeLen(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = metaphone0.encode((java.lang.Object) doubleMetaphone20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '\000' + "'", char25 == '\000');
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test1140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1140");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORKPXKMNSK", "A031");
        java.lang.String str13 = caverphone0.caverphone("ORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKP1111111" + "'", str13, "AKP1111111");
    }

    @Test
    public void test1141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1141");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char3 = refinedSoundex1.getMappingCode('a');
        int int6 = refinedSoundex1.difference("", "hi!");
        char char8 = refinedSoundex1.getMappingCode('#');
        java.lang.String str10 = refinedSoundex1.soundex("01230120022455012623010202");
        java.lang.String str12 = refinedSoundex1.encode("A621");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) str12);
        java.lang.String str15 = caverphone0.caverphone("O");
        org.apache.commons.codec.language.Metaphone metaphone16 = new org.apache.commons.codec.language.Metaphone();
        metaphone16.setMaxCodeLen(3);
        java.lang.String str20 = metaphone16.encode("");
        java.lang.String str22 = metaphone16.encode("");
        metaphone16.setMaxCodeLen((int) (short) 10);
        int int25 = metaphone16.getMaxCodeLen();
        java.lang.String str27 = metaphone16.encode("ORKP");
        int int28 = metaphone16.getMaxCodeLen();
        boolean boolean31 = metaphone16.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean34 = metaphone16.isMetaphoneEqual("O093", "HI");
        java.lang.String str36 = metaphone16.metaphone("AKPKKMNSKT");
        metaphone16.setMaxCodeLen((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = caverphone0.encode((java.lang.Object) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex1);
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '0' + "'", char3 == '0');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0" + "'", str12, "A0");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "A111111111" + "'", obj13, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "ORKP" + "'", str27, "ORKP");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "AKPKMNSKT" + "'", str36, "AKPKMNSKT");
    }

    @Test
    public void test1142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1142");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("O0940103030808306030830609053016080");
        java.lang.String str6 = refinedSoundex0.encode("A111111111O000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0" + "'", str4, "O0");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A0" + "'", str6, "A0");
    }

    @Test
    public void test1143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1143");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        int int16 = refinedSoundex0.difference("AA11111111", "01230120022455012623010202");
        java.lang.String str18 = refinedSoundex0.soundex("");
        int int21 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931", "ARKPKSKMNSKTKNKTRKSPKSNRKP");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
    }

    @Test
    public void test1144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1144");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.setMaxCodeLen(10);
        int int5 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "AKP", "");
        org.apache.commons.codec.language.Metaphone metaphone6 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str8 = metaphone6.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone6.setMaxCodeLen((int) (byte) 100);
        boolean boolean13 = metaphone6.isMetaphoneEqual("", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str15 = metaphone6.encode("O09401030308083060308306090530160809315383638369315893153836383693158931");
        java.lang.String str17 = metaphone6.metaphone("O062010202050520302052030602013050");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = doubleMetaphone0.encode((java.lang.Object) metaphone6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKP" + "'", str8, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O" + "'", str15, "O");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O" + "'", str17, "O");
    }

    @Test
    public void test1145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1145");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str9 = doubleMetaphone7.doubleMetaphone("H");
        doubleMetaphone7.setMaxCodeLen((int) (byte) 0);
        java.lang.String str14 = doubleMetaphone7.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone7.new DoubleMetaphoneResult(0);
        java.lang.String str17 = doubleMetaphoneResult16.getPrimary();
        doubleMetaphoneResult16.appendPrimary('1');
        java.lang.String str20 = doubleMetaphoneResult16.getAlternate();
        java.lang.Object obj21 = metaphone0.encode((java.lang.Object) str20);
        java.lang.Class<?> wildcardClass22 = obj21.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "" + "'", obj21, "");
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test1146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1146");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str30 = caverphone0.encode("A1");
        java.lang.String str32 = caverphone0.caverphone("ARKPXKMNSKTSNKTRKSPXN");
        org.apache.commons.codec.EncoderException encoderException34 = new org.apache.commons.codec.EncoderException("hi!");
        java.lang.Throwable[] throwableArray35 = encoderException34.getSuppressed();
        java.lang.Throwable[] throwableArray36 = encoderException34.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = caverphone0.encode((java.lang.Object) throwableArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AKPKKMNSKT" + "'", str28, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "A111111111" + "'", str30, "A111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKPKMNSKTS" + "'", str32, "AKPKMNSKTS");
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertArrayEquals(throwableArray35, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertArrayEquals(throwableArray36, new java.lang.Throwable[] {});
    }

    @Test
    public void test1147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1147");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.encode("A111111111O000");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A000" + "'", str6, "A000");
    }

    @Test
    public void test1148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1148");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("ARK", "AA11111111");
        java.lang.String str18 = caverphone0.encode("org.apache.commons.codec.EncoderException: A093153836383693158");
        boolean boolean21 = caverphone0.isCaverphoneEqual("", "A000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test1149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1149");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "ORKPXKMNSKTKNKTRKSSPXNH", "A621");
        java.lang.String str7 = soundex1.encode("A313");
        int int8 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test1150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1150");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.encode("ARKPXKMNSKTKNKTRKS");
        java.lang.String str8 = soundex4.soundex("A621");
        soundex4.setMaxLength(0);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A621" + "'", str6, "A621");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
    }

    @Test
    public void test1151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1151");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone0.maxCodeLen = 3;
        java.lang.String str13 = doubleMetaphone0.encode("A111111111");
        doubleMetaphone0.maxCodeLen = 48;
        org.apache.commons.codec.language.Soundex soundex16 = new org.apache.commons.codec.language.Soundex();
        int int19 = soundex16.difference("A1", " ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = doubleMetaphone0.encode((java.lang.Object) soundex16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A" + "'", str13, "A");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test1152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1152");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int8 = metaphone0.getMaxCodeLen();
        char[] charArray15 = new char[] { 'r', '1', ' ', 'i', '#', '#' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex16 = new org.apache.commons.codec.language.RefinedSoundex(charArray15);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = metaphone0.encode((java.lang.Object) charArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertArrayEquals(charArray15, new char[] { 'r', '1', ' ', 'i', '#', '#' });
    }

    @Test
    public void test1153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1153");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("HI");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str13 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A0");
        metaphone0.setMaxCodeLen(4);
        java.lang.String str17 = metaphone0.metaphone("ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H" + "'", str9, "H");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ARKP" + "'", str17, "ARKP");
    }

    @Test
    public void test1154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1154");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT", "ORK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test1155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1155");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        boolean boolean13 = doubleMetaphone8.isDoubleMetaphoneEqual("01230120022455012623010202", "");
        java.lang.Object obj14 = soundex1.encode((java.lang.Object) "01230120022455012623010202");
        java.lang.String str16 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str18 = soundex1.soundex("A0931");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "" + "'", obj14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
    }

    @Test
    public void test1156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1156");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = soundex6.encode("K000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test1157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1157");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        java.lang.String str29 = metaphone0.metaphone("A621HI0A093138363836931589313836383693158M");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "AHM" + "'", str29, "AHM");
    }

    @Test
    public void test1158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1158");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        int int22 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A ", "A1111111114r");
        char char24 = refinedSoundex0.getMappingCode('0');
        int int27 = refinedSoundex0.difference("", "A");
        java.lang.String str29 = refinedSoundex0.encode("  ");
        java.lang.String str31 = refinedSoundex0.soundex("  ");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
    }

    @Test
    public void test1159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1159");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str13 = caverphone0.encode("AKP1111111");
        java.lang.String str15 = caverphone0.encode("");
        boolean boolean18 = caverphone0.isCaverphoneEqual("01230120022455012623010202", "A621HI0A093138363836931589313836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKP1111111" + "'", str13, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test1160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1160");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int3 = soundex0.getMaxLength();
        soundex0.setMaxLength(10);
        java.lang.String str7 = soundex0.soundex("A621HI");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex0, "O0940103030808306030830609053016080940103030808306030830609053016080931", "");
        int int11 = soundex0.getMaxLength();
        int int12 = soundex0.getMaxLength();
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test1161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1161");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        metaphone0.setMaxCodeLen((int) (short) 0);
        java.lang.String str14 = metaphone0.metaphone("ARKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test1162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1162");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AKPKMNSK", "A0O");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1163");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str15 = caverphone0.caverphone("ORKP");
        boolean boolean18 = caverphone0.isCaverphoneEqual("I", "ORKPXKMNSKTKNKTRKSSPXN");
        boolean boolean21 = caverphone0.isCaverphoneEqual("AA11111111", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKP1111111" + "'", str15, "AKP1111111");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test1164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1164");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("");
        boolean boolean16 = caverphone0.isCaverphoneEqual("A0O", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test1165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1165");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException:  ");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTION" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTION");
    }

    @Test
    public void test1166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1166");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        char char16 = doubleMetaphone9.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone9.new DoubleMetaphoneResult((int) '4');
        java.lang.String str19 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) str19);
        java.lang.String str22 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        boolean boolean25 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderExc", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str27 = caverphone0.encode(" org.apache.commons.codec.EncoderException: ORGAP");
        java.lang.String str29 = caverphone0.encode("A09315383");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = caverphone0.encode((java.lang.Object) 43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + 'i' + "'", char16 == 'i');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "1111111111" + "'", obj20, "1111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "AKPKKMNSKT" + "'", str27, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
    }

    @Test
    public void test1167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1167");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str15 = refinedSoundex0.soundex("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        char char17 = refinedSoundex0.getMappingCode('8');
        int int20 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ARKP", "org.apache.commons.codec.EncoderException: A#");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0940103030808306030830609053016080" + "'", str13, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0931538363836931589313836383693138" + "'", str15, "O0931538363836931589313836383693138");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
    }

    @Test
    public void test1168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1168");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        java.lang.String str12 = soundex1.encode("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int13 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O941" + "'", str12, "O941");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test1169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1169");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str14 = metaphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test1170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1170");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("K", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1171");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        java.lang.String str13 = refinedSoundex0.encode("O09315383638369315893153836383693158");
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str16 = soundex14.encode("ARKP");
        int int17 = soundex14.getMaxLength();
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex14, "AKPKMNSKT1", "O093");
        soundex14.setMaxLength((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = refinedSoundex0.encode((java.lang.Object) soundex14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A621" + "'", str16, "A621");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test1172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1172");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        java.lang.String str13 = metaphone0.encode("hi!");
        int int14 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(10);
        char[] charArray17 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex18 = new org.apache.commons.codec.language.Soundex(charArray17);
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray17);
        org.apache.commons.codec.language.Soundex soundex20 = new org.apache.commons.codec.language.Soundex(charArray17);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex21 = new org.apache.commons.codec.language.RefinedSoundex(charArray17);
        org.apache.commons.codec.language.Soundex soundex22 = new org.apache.commons.codec.language.Soundex(charArray17);
        org.apache.commons.codec.language.Soundex soundex23 = new org.apache.commons.codec.language.Soundex(charArray17);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = metaphone0.encode((java.lang.Object) soundex23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertNotNull(charArray17);
    }

    @Test
    public void test1173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1173");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.encode("org.apache.commons.codec.EncoderException: O0");
        boolean boolean16 = caverphone0.isCaverphoneEqual("", "A093153836383693158");
        boolean boolean19 = caverphone0.isCaverphoneEqual("O0940103030808306030830609053016080931", "");
        java.lang.String str21 = caverphone0.caverphone(" org.apache.commons.codec.EncoderException: ORGAP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKKMNSKT" + "'", str21, "AKPKKMNSKT");
    }

    @Test
    public void test1174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1174");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.metaphone("O000");
        char[] charArray8 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex12 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex15 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex16 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = metaphone0.encode((java.lang.Object) charArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O" + "'", str6, "O");
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertArrayEquals(charArray8, new char[] { 'a' });
    }

    @Test
    public void test1175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1175");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) '#');
        // The following exception was thrown during execution in test generation
        try {
            int int13 = soundex1.difference("A621", "A03138363");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test1176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1176");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.String str12 = caverphone0.encode("O0940103030808306030830609053016080931");
        java.lang.String str14 = caverphone0.encode(" AKP1111111 ");
        java.lang.String str16 = caverphone0.caverphone("AKP1111111");
        char[] charArray19 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex20 = new org.apache.commons.codec.language.RefinedSoundex(charArray19);
        org.apache.commons.codec.language.Soundex soundex21 = new org.apache.commons.codec.language.Soundex(charArray19);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = caverphone0.encode((java.lang.Object) soundex21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKP1111111" + "'", str14, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKP1111111" + "'", str16, "AKP1111111");
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertArrayEquals(charArray19, new char[] { '1', ' ' });
    }

    @Test
    public void test1177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1177");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) (short) 0);
        java.lang.String str9 = doubleMetaphone0.encode("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str18 = doubleMetaphone16.doubleMetaphone("H");
        java.lang.String str20 = doubleMetaphone16.doubleMetaphone("HI");
        java.lang.String str22 = doubleMetaphone16.encode("O621");
        java.lang.Object obj23 = refinedSoundex10.encode((java.lang.Object) "O621");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone24 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str26 = doubleMetaphone24.doubleMetaphone("H");
        doubleMetaphone24.setMaxCodeLen((int) (byte) 0);
        boolean boolean32 = doubleMetaphone24.isDoubleMetaphoneEqual("O620", "O000", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult34 = doubleMetaphone24.new DoubleMetaphoneResult((int) 'r');
        doubleMetaphoneResult34.append("A0");
        java.lang.String str37 = doubleMetaphoneResult34.getAlternate();
        doubleMetaphoneResult34.append("O093", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj41 = refinedSoundex10.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj42 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A" + "'", str22, "A");
        org.junit.Assert.assertEquals("'" + obj23 + "' != '" + "O0" + "'", obj23, "O0");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "A0" + "'", str37, "A0");
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0940103030808306030830609053016080931" + "'", obj41, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "" + "'", obj42, "");
    }

    @Test
    public void test1178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1178");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.encode("");
        java.lang.String str24 = metaphone0.metaphone("AKPKSKMNSK");
        boolean boolean27 = metaphone0.isMetaphoneEqual("ARKPXKMNSK", "org.apache.commons.codec.EncoderException: A#");
        java.lang.String str29 = metaphone0.encode("org.apache.commons.codec.EncoderException: A093153836383693158");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKSKMNSK" + "'", str24, "AKPKSKMNSK");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ORKPXKMNSK" + "'", str29, "ORKPXKMNSK");
    }

    @Test
    public void test1179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1179");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone2 = new org.apache.commons.codec.language.Metaphone();
        metaphone2.setMaxCodeLen(3);
        java.lang.String str6 = metaphone2.encode("");
        java.lang.String str8 = metaphone2.encode("");
        java.lang.Object obj9 = soundex0.encode((java.lang.Object) "");
        soundex0.setMaxLength(0);
        int int12 = soundex0.getMaxLength();
        int int15 = soundex0.difference("ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT", "O062010202050520302052030602013050");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test1180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1180");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone0.maxCodeLen = '0';
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("A", true);
        boolean boolean12 = doubleMetaphone0.isDoubleMetaphoneEqual("A0", "");
        boolean boolean15 = doubleMetaphone0.isDoubleMetaphoneEqual("A ", "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone0.setMaxCodeLen((int) 'A');
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ARK", "A ");
        doubleMetaphone0.setMaxCodeLen((int) '#');
        boolean boolean25 = doubleMetaphone0.isDoubleMetaphoneEqual("O620", "");
        boolean boolean28 = doubleMetaphone0.isDoubleMetaphoneEqual("A621r", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str30 = doubleMetaphone0.doubleMetaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        boolean boolean33 = doubleMetaphone0.isDoubleMetaphoneEqual("ORKPXKMNSKTKNKTRKSSPXNRKP", "A621HI0A093138363836931589313836383693158g");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK" + "'", str30, "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test1181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1181");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("AKPKMNSKT1");
        java.lang.String str12 = caverphone0.encode("H000");
        java.lang.String str14 = caverphone0.caverphone("#");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.setMaxCodeLen(10);
        java.lang.String str20 = doubleMetaphone15.doubleMetaphone("", false);
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKMNSKT1" + "'", str10, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "1111111111" + "'", str14, "1111111111");
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
    }

    @Test
    public void test1182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1182");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str30 = doubleMetaphone28.doubleMetaphone("H");
        java.lang.String str32 = doubleMetaphone28.doubleMetaphone("HI");
        java.lang.String str34 = doubleMetaphone28.doubleMetaphone("AKPKMNSKT1");
        java.lang.Object obj35 = metaphone0.encode((java.lang.Object) str34);
        boolean boolean38 = metaphone0.isMetaphoneEqual("I", "4");
        java.lang.String str40 = metaphone0.encode("O0931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPK" + "'", str34, "AKPK");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "AKPK" + "'", obj35, "AKPK");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "O" + "'", str40, "O");
    }

    @Test
    public void test1183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1183");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        java.lang.String str9 = refinedSoundex4.soundex("A0O");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A0" + "'", str9, "A0");
    }

    @Test
    public void test1184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1184");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        java.lang.String str13 = caverphone0.encode("org.apache.commons.codec.EncoderException: org.ap");
        java.lang.String str15 = caverphone0.encode("A093138363836931589313836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
    }

    @Test
    public void test1185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1185");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("HI");
        int int10 = metaphone0.getMaxCodeLen();
        java.lang.String str12 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        int int13 = metaphone0.getMaxCodeLen();
        java.lang.String str15 = metaphone0.encode("Aa");
        java.lang.Class<?> wildcardClass16 = metaphone0.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H" + "'", str9, "H");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ORK" + "'", str12, "ORK");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A" + "'", str15, "A");
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test1186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1186");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.soundex("O0940103030808306030830609053016080931");
        char char9 = refinedSoundex5.getMappingCode('i');
        org.apache.commons.codec.EncoderException encoderException11 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("HI");
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray16 = encoderException15.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException15.addSuppressed((java.lang.Throwable) encoderException18);
        encoderException13.addSuppressed((java.lang.Throwable) encoderException18);
        org.apache.commons.codec.EncoderException encoderException22 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException24 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray25 = encoderException24.getSuppressed();
        encoderException22.addSuppressed((java.lang.Throwable) encoderException24);
        org.apache.commons.codec.EncoderException encoderException28 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: A0");
        encoderException24.addSuppressed((java.lang.Throwable) encoderException28);
        java.lang.Throwable[] throwableArray30 = encoderException24.getSuppressed();
        encoderException13.addSuppressed((java.lang.Throwable) encoderException24);
        encoderException11.addSuppressed((java.lang.Throwable) encoderException13);
        java.lang.Throwable[] throwableArray33 = encoderException13.getSuppressed();
        java.lang.Throwable[] throwableArray34 = encoderException13.getSuppressed();
        java.lang.Throwable[] throwableArray35 = encoderException13.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException37 = new org.apache.commons.codec.EncoderException("i4org.apache.commons.codec.EncoderException: A000");
        encoderException13.addSuppressed((java.lang.Throwable) encoderException37);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = refinedSoundex5.encode((java.lang.Object) encoderException37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O0" + "'", str7, "O0");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertArrayEquals(throwableArray16, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertArrayEquals(throwableArray25, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test1187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1187");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) 'a');
        metaphone0.setMaxCodeLen(0);
        boolean boolean15 = metaphone0.isMetaphoneEqual("ARKPXKMNSKTKNKTRKSPXN", "A1111111114r");
        java.lang.String str17 = metaphone0.encode("O0");
        java.lang.Object obj19 = metaphone0.encode((java.lang.Object) "ORKP");
        int int20 = metaphone0.getMaxCodeLen();
        java.lang.String str22 = metaphone0.encode("");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "" + "'", obj19, "");
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
    }

    @Test
    public void test1188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1188");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("HI");
        int int10 = metaphone0.getMaxCodeLen();
        java.lang.String str12 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str14 = metaphone0.encode("#");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A313", "");
        int int18 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H" + "'", str9, "H");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ORK" + "'", str12, "ORK");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "#" + "'", str14, "#");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test1189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1189");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        int int3 = soundex0.getMaxLength();
        int int4 = soundex0.getMaxLength();
        int int7 = soundex0.difference("H", "O0");
        int int8 = soundex0.getMaxLength();
        java.lang.String str10 = soundex0.soundex("#");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test1190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1190");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength(100);
        int int10 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = soundex1.soundex("A0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test1191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1191");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        java.lang.String str14 = soundex1.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str16 = soundex1.encode("AA11111111");
        java.lang.String str18 = soundex1.encode("org.apache.commons.codec.EncoderException: O620");
        java.lang.String str20 = soundex1.soundex("O09315383638369315893153836383693158");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O941" + "'", str14, "O941");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A000" + "'", str16, "A000");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O941" + "'", str18, "O941");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O000" + "'", str20, "O000");
    }

    @Test
    public void test1192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1192");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A621HIo");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AHIO" + "'", str1, "AHIO");
    }

    @Test
    public void test1193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1193");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        java.lang.String str14 = caverphone0.encode("AKPKKMNSKT");
        boolean boolean17 = caverphone0.isCaverphoneEqual("O941", "");
        java.lang.String str19 = caverphone0.encode("org.apache.commons.codec.EncoderException: O000");
        java.lang.String str21 = caverphone0.caverphone("A1111111114r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKT1" + "'", str14, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKKMNSKT" + "'", str19, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AA11111111" + "'", str21, "AA11111111");
    }

    @Test
    public void test1194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1194");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        int int11 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray14 = encoderException13.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = metaphone0.encode((java.lang.Object) encoderException13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertArrayEquals(throwableArray14, new java.lang.Throwable[] {});
    }

    @Test
    public void test1195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1195");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "ORK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1196");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.encode("AKPKMNSK");
        java.lang.Class<?> wildcardClass9 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKMNSK11" + "'", str8, "AKPKMNSK11");
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test1197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1197");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        int int4 = soundex1.getMaxLength();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char7 = refinedSoundex5.getMappingCode('a');
        int int10 = refinedSoundex5.difference("", "hi!");
        int int13 = refinedSoundex5.difference("hi!", "");
        char char15 = refinedSoundex5.getMappingCode('#');
        char char17 = refinedSoundex5.getMappingCode('a');
        java.lang.String str19 = refinedSoundex5.soundex("org.apache.commons.codec.EncoderException: A0");
        java.lang.Object obj20 = soundex1.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A0");
        soundex1.setMaxLength(35);
        java.lang.Object obj23 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = soundex1.encode(obj23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(refinedSoundex5);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '0' + "'", char17 == '0');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0940103030808306030830609053016080" + "'", str19, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "O621" + "'", obj20, "O621");
    }

    @Test
    public void test1198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1198");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        int int30 = refinedSoundex0.difference("O094010303080830603083060905301608093", "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test1199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1199");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        char char24 = doubleMetaphone11.charAt("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", (int) 'A');
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        char[] charArray26 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex27 = new org.apache.commons.codec.language.Soundex(charArray26);
        int int28 = soundex27.getMaxLength();
        int int31 = soundex27.difference("ORKP", "AA11111111");
        soundex27.setMaxLength(10);
        soundex27.setMaxLength((int) (short) 0);
        java.lang.String str37 = soundex27.encode("A000");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj38 = refinedSoundex0.encode((java.lang.Object) soundex27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0931" + "'", str10, "O0931");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "O0940103030808306030830609053016080" + "'", obj25, "O0940103030808306030830609053016080");
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "A000" + "'", str37, "A000");
    }

    @Test
    public void test1200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1200");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str14 = refinedSoundex0.soundex("H0");
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "ORGAPACHECOMMONSCODECENCODEREXCEPTION", "O0940103030808306030830609053016080931");
        java.lang.String str19 = refinedSoundex0.soundex("");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "H0" + "'", str14, "H0");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
    }

    @Test
    public void test1201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1201");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A000");
        java.lang.String str8 = caverphone0.caverphone("A093153836383693");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
    }

    @Test
    public void test1202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1202");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("O093", "AKP1111111");
        java.lang.String str18 = caverphone0.caverphone("A0");
        java.lang.String str20 = caverphone0.caverphone("H");
        java.lang.String str22 = caverphone0.caverphone("AA11111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone23 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone23.maxCodeLen = '\000';
        char char28 = doubleMetaphone23.charAt("", 0);
        java.lang.String str30 = doubleMetaphone23.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str32 = doubleMetaphone23.doubleMetaphone("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = caverphone0.encode((java.lang.Object) str32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A111111111" + "'", str18, "A111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "A111111111" + "'", str20, "A111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AA11111111" + "'", str22, "AA11111111");
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '\000' + "'", char28 == '\000');
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test1203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1203");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex24 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char26 = refinedSoundex24.getMappingCode('a');
        int int29 = refinedSoundex24.difference("", "hi!");
        int int32 = refinedSoundex24.difference("", "A");
        java.lang.Object obj33 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str35 = caverphone0.caverphone("O0940103030808306030830609053016080940103030808306030830609053016080931");
        boolean boolean38 = caverphone0.isCaverphoneEqual("4", "O0931");
        java.lang.String str40 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex24);
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "1111111111" + "'", obj33, "1111111111");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "A111111111" + "'", str35, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "AKPKKMNSKT" + "'", str40, "AKPKKMNSKT");
    }

    @Test
    public void test1204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1204");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        metaphone0.setMaxCodeLen((int) 'A');
        boolean boolean9 = metaphone0.isMetaphoneEqual("K", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        java.lang.String str11 = metaphone0.metaphone("#");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "#" + "'", str11, "#");
    }

    @Test
    public void test1205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1205");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str8 = refinedSoundex6.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O062125232523621256212523252362125" + "'", str8, "O062125232523621256212523252362125");
    }

    @Test
    public void test1206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1206");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("A ");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A0" + "'", str24, "A0");
    }

    @Test
    public void test1207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1207");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode(' ');
        char char9 = refinedSoundex0.getMappingCode('#');
        java.lang.String str11 = refinedSoundex0.encode("AA");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
    }

    @Test
    public void test1208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1208");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        java.lang.String str14 = soundex3.encode("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        int int15 = soundex3.getMaxLength();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone16.maxCodeLen = 0;
        char char21 = doubleMetaphone16.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean25 = doubleMetaphone16.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char28 = doubleMetaphone16.charAt("01230120022455012623010202", (int) (short) 1);
        char char31 = doubleMetaphone16.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone16.maxCodeLen = (byte) 10;
        doubleMetaphone16.maxCodeLen = 3;
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult37 = doubleMetaphone16.new DoubleMetaphoneResult(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj38 = soundex3.encode((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O621" + "'", str14, "O621");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '1' + "'", char28 == '1');
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + 'O' + "'", char31 == 'O');
    }

    @Test
    public void test1209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1209");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) '4');
        boolean boolean20 = metaphone0.isMetaphoneEqual("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK", "");
        java.lang.String str22 = metaphone0.metaphone(" org.apache.commons.codec.EncoderException: ORGAP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "RKPXKMNSKTKNKTRKSSPXNRKP" + "'", str22, "RKPXKMNSKTKNKTRKSSPXNRKP");
    }

    @Test
    public void test1210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1210");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.Encoder", "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1211");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int10 = soundex1.getMaxLength();
        org.apache.commons.codec.language.Caverphone caverphone11 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str13 = caverphone11.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone11.encode("O621");
        boolean boolean18 = caverphone11.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str20 = caverphone11.caverphone("A");
        java.lang.String str22 = caverphone11.caverphone("");
        java.lang.String str24 = caverphone11.encode("org.apache.commons.codec.EncoderException: org.ap");
        java.lang.Object obj25 = soundex1.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: org.ap");
        java.lang.String str27 = soundex1.encode("O094010303080830603083060905301608093");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "A111111111" + "'", str20, "A111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "O941" + "'", obj25, "O941");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "O000" + "'", str27, "O000");
    }

    @Test
    public void test1212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1212");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        java.lang.String str9 = soundex1.soundex("");
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        metaphone10.setMaxCodeLen(3);
        int int13 = metaphone10.getMaxCodeLen();
        boolean boolean16 = metaphone10.isMetaphoneEqual("", "");
        boolean boolean19 = metaphone10.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone10.setMaxCodeLen(0);
        int int22 = metaphone10.getMaxCodeLen();
        metaphone10.setMaxCodeLen((int) (short) 100);
        java.lang.String str26 = metaphone10.encode("ARKP");
        java.lang.String str28 = metaphone10.encode("");
        java.lang.String str30 = metaphone10.encode("H");
        java.lang.String str32 = metaphone10.metaphone("AKPKMNSKT1");
        metaphone10.setMaxCodeLen((int) 'r');
        int int35 = metaphone10.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = soundex1.encode((java.lang.Object) int35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "ARKP" + "'", str26, "ARKP");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "H" + "'", str30, "H");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKPKMNSKT" + "'", str32, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 114 + "'", int35 == 114);
    }

    @Test
    public void test1213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1213");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) '#');
        int int8 = doubleMetaphone0.maxCodeLen;
        boolean boolean12 = doubleMetaphone0.isDoubleMetaphoneEqual("4", "", false);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone13.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult20.appendAlternate("A111111111");
        java.lang.String str23 = doubleMetaphoneResult20.getAlternate();
        boolean boolean24 = doubleMetaphoneResult20.isComplete();
        java.lang.String str25 = doubleMetaphoneResult20.getAlternate();
        doubleMetaphoneResult20.appendAlternate('\000');
        doubleMetaphoneResult20.appendPrimary("ORKPXKMNSKTKNKTRKSSPXN");
        java.lang.Object obj30 = doubleMetaphone0.encode((java.lang.Object) "ORKPXKMNSKTKNKTRKSSPXN");
        char[] charArray31 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex32 = new org.apache.commons.codec.language.Soundex(charArray31);
        org.apache.commons.codec.language.Soundex soundex33 = new org.apache.commons.codec.language.Soundex(charArray31);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex34 = new org.apache.commons.codec.language.RefinedSoundex(charArray31);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex35 = new org.apache.commons.codec.language.RefinedSoundex(charArray31);
        int int38 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex35, "A111111111", "O941");
        int int41 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex35, "ARK", "H0");
        java.lang.String str43 = refinedSoundex35.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj44 = doubleMetaphone0.encode((java.lang.Object) refinedSoundex35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A111111111" + "'", str23, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A111111111" + "'", str25, "A111111111");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "" + "'", obj30, "");
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "O0" + "'", str43, "O0");
    }

    @Test
    public void test1214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1214");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        boolean boolean12 = metaphone0.isMetaphoneEqual("A0", "");
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKP", "hi!");
        int int18 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "AKPK");
        int int19 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test1215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1215");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPKSKMNSKTKNKTRKSPKSNRKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPKSKMNSKTKNKTRKSPKSNRKP" + "'", str1, "ARKPKSKMNSKTKNKTRKSPKSNRKP");
    }

    @Test
    public void test1216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1216");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        java.lang.String str14 = caverphone0.encode("AKPKKMNSKT");
        boolean boolean17 = caverphone0.isCaverphoneEqual("O941", "");
        java.lang.String str19 = caverphone0.encode("O");
        boolean boolean22 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP", "org.apache.commons.codec.EncoderException: A ");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone23 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone23.maxCodeLen = 0;
        char char28 = doubleMetaphone23.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean32 = doubleMetaphone23.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone23.maxCodeLen = 3;
        java.lang.String str36 = doubleMetaphone23.encode("A111111111");
        java.lang.Object obj37 = caverphone0.encode((java.lang.Object) str36);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKT1" + "'", str14, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A111111111" + "'", str19, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '\000' + "'", char28 == '\000');
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "A" + "'", str36, "A");
        org.junit.Assert.assertEquals("'" + obj37 + "' != '" + "A111111111" + "'", obj37, "A111111111");
    }

    @Test
    public void test1217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1217");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int9 = soundex4.difference("1111111111", "A111111111O620");
        int int10 = soundex4.getMaxLength();
        java.lang.String str12 = soundex4.encode("A062125232523621256212523252362125");
        java.lang.String str14 = soundex4.soundex("ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A000" + "'", str12, "A000");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A621" + "'", str14, "A621");
    }

    @Test
    public void test1218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1218");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: hi!");
        char char15 = refinedSoundex0.getMappingCode('.');
        java.lang.String str17 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0940103030808306030830609053016080" + "'", str13, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0940103030808306030830609053016080313836" + "'", str17, "O0940103030808306030830609053016080313836");
    }

    @Test
    public void test1219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1219");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: A111111111O620");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAO" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAO");
    }

    @Test
    public void test1220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1220");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        int int9 = soundex0.getMaxLength();
        soundex0.setMaxLength((int) (byte) -1);
        java.lang.String str13 = soundex0.soundex("ORKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O621" + "'", str13, "O621");
    }

    @Test
    public void test1221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1221");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        java.lang.String str17 = metaphone0.metaphone("");
        org.apache.commons.codec.language.Caverphone caverphone18 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str20 = caverphone18.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone18.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str24 = caverphone18.encode("A");
        char[] charArray25 = null;
        org.apache.commons.codec.language.Soundex soundex26 = new org.apache.commons.codec.language.Soundex(charArray25);
        java.lang.String str28 = soundex26.soundex("");
        java.lang.String str30 = soundex26.encode("");
        java.lang.Object obj31 = caverphone18.encode((java.lang.Object) "");
        boolean boolean34 = caverphone18.isCaverphoneEqual("O093", "AKP1111111");
        java.lang.String str36 = caverphone18.caverphone("A0");
        java.lang.Object obj37 = metaphone0.encode((java.lang.Object) "A0");
        java.lang.String str39 = metaphone0.encode("AK11111111");
        java.lang.String str41 = metaphone0.encode("O931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A111111111" + "'", str24, "A111111111");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + obj31 + "' != '" + "1111111111" + "'", obj31, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "A111111111" + "'", str36, "A111111111");
        org.junit.Assert.assertEquals("'" + obj37 + "' != '" + "A" + "'", obj37, "A");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "AK" + "'", str39, "AK");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "O" + "'", str41, "O");
    }

    @Test
    public void test1222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1222");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('\000');
        java.lang.String str8 = refinedSoundex4.encode("A313");
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A#" + "'", str8, "A#");
    }

    @Test
    public void test1223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1223");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: AK11111111", "A062125232523621256212523252362125");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1224");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray3);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex7.difference("A600", "O0931538363836931589313836383693138");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test1225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1225");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "H000");
        java.lang.String str16 = refinedSoundex0.encode("O620");
        java.lang.String str18 = refinedSoundex0.soundex("A0931383");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O0" + "'", str16, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A0" + "'", str18, "A0");
    }

    @Test
    public void test1226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1226");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        int int25 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone26 = new org.apache.commons.codec.language.Metaphone();
        metaphone26.setMaxCodeLen(0);
        java.lang.String str30 = metaphone26.metaphone("A0");
        java.lang.String str32 = metaphone26.encode("H");
        java.lang.String str34 = metaphone26.metaphone("hi!");
        java.lang.String str36 = metaphone26.metaphone("O0940103030808306030830609053016080931");
        java.lang.Object obj37 = metaphone0.encode((java.lang.Object) "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 114 + "'", int25 == 114);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
        org.junit.Assert.assertEquals("'" + obj37 + "' != '" + "O" + "'", obj37, "O");
    }

    @Test
    public void test1227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1227");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        int int7 = soundex0.getMaxLength();
        java.lang.String str9 = soundex0.encode("A0");
        soundex0.setMaxLength(1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A000" + "'", str9, "A000");
    }

    @Test
    public void test1228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1228");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("R", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1229");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        java.lang.String str14 = soundex3.soundex("");
        java.lang.String str16 = soundex3.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException20 = new org.apache.commons.codec.EncoderException("");
        encoderException18.addSuppressed((java.lang.Throwable) encoderException20);
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException25 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray26 = encoderException25.getSuppressed();
        encoderException23.addSuppressed((java.lang.Throwable) encoderException25);
        org.apache.commons.codec.EncoderException encoderException29 = new org.apache.commons.codec.EncoderException("A ");
        encoderException25.addSuppressed((java.lang.Throwable) encoderException29);
        encoderException20.addSuppressed((java.lang.Throwable) encoderException29);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = soundex3.encode((java.lang.Object) encoderException20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O000" + "'", str16, "O000");
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertArrayEquals(throwableArray26, new java.lang.Throwable[] {});
    }

    @Test
    public void test1230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1230");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        int int11 = refinedSoundex0.difference("O", "AK11111111");
        char[] charArray12 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray12);
        soundex13.setMaxLength(1);
        int int16 = soundex13.getMaxLength();
        int int19 = soundex13.difference("HI", "");
        java.lang.String str21 = soundex13.soundex("O0940103030808306030830609053016080");
        int int24 = soundex13.difference("A#", "H0");
        soundex13.setMaxLength((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = refinedSoundex0.encode((java.lang.Object) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "O000" + "'", str21, "O000");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
    }

    @Test
    public void test1231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1231");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AHIAM", "org.apache.commons.codec.EncoderException: O620");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1232");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        boolean boolean12 = metaphone0.isMetaphoneEqual("", "A621HI");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test1233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1233");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int6 = soundex3.difference("ORKPXKMNSKTKNKTRKSSPXNRKP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        java.lang.String str8 = soundex3.soundex("Aa");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
    }

    @Test
    public void test1234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1234");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.soundex("org.apache.commons.codec.EncoderException: ");
        java.lang.String str6 = soundex0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test1235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1235");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        soundex0.setMaxLength(0);
        java.lang.String str9 = soundex0.soundex("1111111111");
        java.lang.String str11 = soundex0.soundex("A093153836383693158");
        java.lang.String str13 = soundex0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A000" + "'", str11, "A000");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
    }

    @Test
    public void test1236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1236");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        boolean boolean14 = metaphone0.isMetaphoneEqual("A1", "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test1237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1237");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        java.lang.Object obj17 = refinedSoundex0.encode((java.lang.Object) "A0");
        char char19 = refinedSoundex0.getMappingCode('T');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "A0" + "'", obj17, "A0");
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '6' + "'", char19 == '6');
    }

    @Test
    public void test1238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1238");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.Object obj9 = doubleMetaphone0.encode((java.lang.Object) "ORKP");
        doubleMetaphone0.maxCodeLen = 0;
        boolean boolean15 = doubleMetaphone0.isDoubleMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", true);
        org.apache.commons.codec.language.Metaphone metaphone16 = new org.apache.commons.codec.language.Metaphone();
        metaphone16.setMaxCodeLen(3);
        java.lang.String str20 = metaphone16.encode("");
        java.lang.String str22 = metaphone16.encode("");
        metaphone16.setMaxCodeLen((int) (short) 10);
        int int25 = metaphone16.getMaxCodeLen();
        java.lang.String str27 = metaphone16.encode("ORKP");
        int int28 = metaphone16.getMaxCodeLen();
        boolean boolean31 = metaphone16.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean34 = metaphone16.isMetaphoneEqual("O093", "HI");
        java.lang.String str36 = metaphone16.metaphone("AKPKKMNSKT");
        metaphone16.setMaxCodeLen((int) (byte) 10);
        java.lang.String str40 = metaphone16.encode("org.apache.commons.codec.EncoderException: ");
        int int41 = metaphone16.getMaxCodeLen();
        java.lang.Class<?> wildcardClass42 = metaphone16.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = doubleMetaphone0.encode((java.lang.Object) metaphone16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "ORKP" + "'", str27, "ORKP");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "AKPKMNSKT" + "'", str36, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "ORKPXKMNSK" + "'", str40, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test1239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1239");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int8 = refinedSoundex5.difference("AKPK", "");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test1240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1240");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("AKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AKPKSKMNSK" + "'", str1, "AKPKSKMNSK");
    }

    @Test
    public void test1241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1241");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode(' ');
        char char9 = refinedSoundex0.getMappingCode('\000');
        char char11 = refinedSoundex0.getMappingCode('g');
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '4' + "'", char11 == '4');
    }

    @Test
    public void test1242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1242");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("");
        boolean boolean16 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: org.ap", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.language.Metaphone metaphone17 = new org.apache.commons.codec.language.Metaphone();
        metaphone17.setMaxCodeLen(3);
        int int20 = metaphone17.getMaxCodeLen();
        java.lang.String str22 = metaphone17.encode("hi!");
        java.lang.String str24 = metaphone17.encode("O621");
        java.lang.String str26 = metaphone17.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = caverphone0.encode((java.lang.Object) metaphone17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "H" + "'", str22, "H");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O" + "'", str24, "O");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "O" + "'", str26, "O");
    }

    @Test
    public void test1243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1243");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.apache.commons.codec.language.Caverphone caverphone29 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str31 = caverphone29.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str33 = caverphone29.encode("O621");
        boolean boolean36 = caverphone29.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str38 = caverphone29.caverphone("A");
        java.lang.String str40 = caverphone29.caverphone("AA11111111");
        boolean boolean43 = caverphone29.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj44 = caverphone0.encode((java.lang.Object) caverphone29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AKPKKMNSKT" + "'", str28, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AKPKKMNSKT" + "'", str31, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "A111111111" + "'", str33, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "A111111111" + "'", str38, "A111111111");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "AA11111111" + "'", str40, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test1244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1244");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str14 = metaphone0.encode("A1");
        metaphone0.setMaxCodeLen((int) 'r');
        java.lang.String str18 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK" + "'", str18, "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
    }

    @Test
    public void test1245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1245");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("hi!", "O0940103030808306030830609053016080931");
        org.apache.commons.codec.EncoderException encoderException7 = new org.apache.commons.codec.EncoderException("A931");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = refinedSoundex0.encode((java.lang.Object) encoderException7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test1246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1246");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        java.lang.String str9 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str11 = metaphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
    }

    @Test
    public void test1247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1247");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        char char21 = refinedSoundex0.getMappingCode('A');
        char char23 = refinedSoundex0.getMappingCode('T');
        java.lang.String str25 = refinedSoundex0.soundex("A621HI");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone26 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone26.maxCodeLen = '\000';
        doubleMetaphone26.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult32 = doubleMetaphone26.new DoubleMetaphoneResult((int) '1');
        java.lang.String str33 = doubleMetaphoneResult32.getPrimary();
        doubleMetaphoneResult32.appendAlternate("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        doubleMetaphoneResult32.append('A', 'M');
        java.lang.String str39 = doubleMetaphoneResult32.getAlternate();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj40 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '0' + "'", char21 == '0');
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '6' + "'", char23 == '6');
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A0" + "'", str25, "A0");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHIM" + "'", str39, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHIM");
    }

    @Test
    public void test1248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1248");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        int int7 = soundex1.getMaxLength();
        int int10 = soundex1.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = 0;
        char char16 = doubleMetaphone11.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone11.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult18.append(' ');
        java.lang.String str21 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj22 = soundex1.encode((java.lang.Object) str21);
        soundex1.setMaxLength((int) 'r');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + " " + "'", str21, " ");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "" + "'", obj22, "");
    }

    @Test
    public void test1249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1249");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
    }

    @Test
    public void test1250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1250");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        int int8 = refinedSoundex0.difference("i0a", "org.apache.commons.codec.EncoderException: A0");
        char char10 = refinedSoundex0.getMappingCode('.');
        char char12 = refinedSoundex0.getMappingCode('e');
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
    }

    @Test
    public void test1251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1251");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        int int7 = soundex1.getMaxLength();
        java.lang.Class<?> wildcardClass8 = soundex1.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test1252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1252");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        int int17 = metaphone0.getMaxCodeLen();
        boolean boolean20 = metaphone0.isMetaphoneEqual("ARKPXKMNSKTKNKTRKSPXN", "hi!");
        metaphone0.setMaxCodeLen(65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test1253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1253");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone29 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str31 = doubleMetaphone29.doubleMetaphone("H");
        java.lang.String str33 = doubleMetaphone29.doubleMetaphone("");
        java.lang.String str36 = doubleMetaphone29.doubleMetaphone("ORKP", true);
        java.lang.String str39 = doubleMetaphone29.doubleMetaphone("", false);
        java.lang.String str41 = doubleMetaphone29.encode("");
        doubleMetaphone29.setMaxCodeLen(10);
        java.lang.String str45 = doubleMetaphone29.doubleMetaphone("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult47 = doubleMetaphone29.new DoubleMetaphoneResult(2);
        boolean boolean48 = doubleMetaphoneResult47.isComplete();
        java.lang.String str49 = doubleMetaphoneResult47.getAlternate();
        doubleMetaphoneResult47.append('.', 'i');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj53 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "ARKP" + "'", str36, "ARKP");
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "" + "'", str45, "");
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "" + "'", str49, "");
    }

    @Test
    public void test1254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1254");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str8 = soundex6.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O941" + "'", str8, "O941");
    }

    @Test
    public void test1255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1255");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = '\000';
        doubleMetaphone8.setMaxCodeLen(4);
        java.lang.String str14 = doubleMetaphone8.encode("org.apache.commons.codec.EncoderException: HI");
        char char17 = doubleMetaphone8.charAt("ORKP", (int) 'r');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = soundex1.encode((java.lang.Object) char17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ARKP" + "'", str14, "ARKP");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
    }

    @Test
    public void test1256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1256");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        java.lang.String str4 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone5 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str7 = doubleMetaphone5.doubleMetaphone("H");
        doubleMetaphone5.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = doubleMetaphone5.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone5.new DoubleMetaphoneResult(0);
        java.lang.String str15 = doubleMetaphoneResult14.getAlternate();
        doubleMetaphoneResult14.append("hi!");
        doubleMetaphoneResult14.append("O", "O0940103030808306030830609053016080940103030808306030830609053016080");
        boolean boolean21 = doubleMetaphoneResult14.isComplete();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080" + "'", str4, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test1257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1257");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK" + "'", str1, "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
    }

    @Test
    public void test1258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1258");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        java.lang.String str13 = refinedSoundex0.soundex("AKP1111111");
        java.lang.String str15 = refinedSoundex0.encode("O621");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A031" + "'", str13, "A031");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
    }

    @Test
    public void test1259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1259");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        int int1 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test1260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1260");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char3 = refinedSoundex1.getMappingCode('a');
        int int6 = refinedSoundex1.difference("", "hi!");
        char char8 = refinedSoundex1.getMappingCode('#');
        java.lang.String str10 = refinedSoundex1.soundex("01230120022455012623010202");
        java.lang.String str12 = refinedSoundex1.encode("A621");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) str12);
        boolean boolean16 = caverphone0.isCaverphoneEqual("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "O094010303080830603083060905301608093");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str19 = doubleMetaphone17.doubleMetaphone("H");
        doubleMetaphone17.setMaxCodeLen((int) (byte) 0);
        java.lang.String str24 = doubleMetaphone17.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult26 = doubleMetaphone17.new DoubleMetaphoneResult(0);
        java.lang.String str27 = doubleMetaphoneResult26.getAlternate();
        doubleMetaphoneResult26.append('\000');
        doubleMetaphoneResult26.append('#', '#');
        java.lang.String str33 = doubleMetaphoneResult26.getPrimary();
        java.lang.String str34 = doubleMetaphoneResult26.getAlternate();
        java.lang.String str35 = doubleMetaphoneResult26.getAlternate();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex1);
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '0' + "'", char3 == '0');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0" + "'", str12, "A0");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "A111111111" + "'", obj13, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
    }

    @Test
    public void test1261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1261");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        boolean boolean11 = metaphone0.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        boolean boolean14 = metaphone0.isMetaphoneEqual("ARKPKSKMNSKTKNKTRKSPKSN", "A093153836383693158");
        int int15 = metaphone0.getMaxCodeLen();
        java.lang.String str17 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ORK" + "'", str17, "ORK");
    }

    @Test
    public void test1262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1262");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        java.lang.String str13 = caverphone0.encode(" ");
        java.lang.String str15 = caverphone0.caverphone(" ");
        boolean boolean18 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test1263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1263");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("H", "A");
        java.lang.String str13 = refinedSoundex0.soundex("HI");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H0" + "'", str13, "H0");
    }

    @Test
    public void test1264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1264");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray3);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char8 = refinedSoundex6.getMappingCode('A');
        java.lang.String str10 = refinedSoundex6.soundex("");
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '#' + "'", char8 == '#');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test1265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1265");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 1);
        java.lang.String str7 = metaphone0.metaphone("O000");
        char[] charArray9 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = new org.apache.commons.codec.language.RefinedSoundex(charArray9);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = new org.apache.commons.codec.language.RefinedSoundex(charArray9);
        org.apache.commons.codec.language.Soundex soundex12 = new org.apache.commons.codec.language.Soundex(charArray9);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = new org.apache.commons.codec.language.RefinedSoundex(charArray9);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex14 = new org.apache.commons.codec.language.RefinedSoundex(charArray9);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = metaphone0.encode((java.lang.Object) refinedSoundex14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertArrayEquals(charArray9, new char[] { 'a' });
    }

    @Test
    public void test1266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1266");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("org.apache.commons.codec.EncoderException: AKPKKMNSKT", "");
        org.apache.commons.codec.EncoderException encoderException7 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.EncoderException encoderException9 = new org.apache.commons.codec.EncoderException("A#");
        encoderException7.addSuppressed((java.lang.Throwable) encoderException9);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = soundex2.encode((java.lang.Object) encoderException7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test1267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1267");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: hi!");
        int int16 = refinedSoundex0.difference("AKPKKMNSKT", "O0940103030808306030830609053016080");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderExc", "ORKPXKMNSKTKNKTRKSSPXNH");
        char char21 = refinedSoundex0.getMappingCode('5');
        int int24 = refinedSoundex0.difference("O931", "0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0940103030808306030830609053016080" + "'", str13, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test1268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1268");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "A ");
        java.lang.String str13 = metaphone0.metaphone("H");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex14 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char16 = refinedSoundex14.getMappingCode('a');
        int int19 = refinedSoundex14.difference("", "hi!");
        char char21 = refinedSoundex14.getMappingCode('0');
        char char23 = refinedSoundex14.getMappingCode('a');
        java.lang.String str25 = refinedSoundex14.soundex("1111111111");
        int int28 = refinedSoundex14.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone29 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone29.maxCodeLen = '\000';
        doubleMetaphone29.setMaxCodeLen(4);
        java.lang.String str35 = doubleMetaphone29.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj36 = refinedSoundex14.encode((java.lang.Object) str35);
        java.lang.String str38 = refinedSoundex14.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        java.lang.String str40 = refinedSoundex14.encode("org.apache.commons.codec.EncoderException: O");
        java.lang.Object obj41 = metaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
        org.junit.Assert.assertNotNull(refinedSoundex14);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '0' + "'", char16 == '0');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '0' + "'", char23 == '0');
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 35 + "'", int28 == 35);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "ARKP" + "'", str35, "ARKP");
        org.junit.Assert.assertEquals("'" + obj36 + "' != '" + "A0931" + "'", obj36, "A0931");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "O0940103030808306030830609053016080" + "'", str38, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "O0940103030808306030830609053016080" + "'", str40, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "ORKPXKMNSK" + "'", obj41, "ORKPXKMNSK");
    }

    @Test
    public void test1269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1269");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        java.lang.String str17 = metaphone0.encode("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.Metaphone metaphone18 = new org.apache.commons.codec.language.Metaphone();
        metaphone18.setMaxCodeLen(3);
        java.lang.String str22 = metaphone18.encode("");
        java.lang.String str24 = metaphone18.encode("");
        metaphone18.setMaxCodeLen((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = metaphone0.encode((java.lang.Object) metaphone18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN" + "'", str17, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
    }

    @Test
    public void test1270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1270");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        java.lang.String str15 = refinedSoundex0.soundex("");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test1271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1271");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("");
        boolean boolean16 = caverphone0.isCaverphoneEqual("i4org.apache.commons.codec.EncoderException: A000", "KP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test1272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1272");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        soundex1.setMaxLength(5);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
    }

    @Test
    public void test1273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1273");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        soundex1.setMaxLength(0);
        int int12 = soundex1.difference("O931", "");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test1274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1274");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        java.lang.String str12 = metaphone0.encode("AA11111111");
        java.lang.String str14 = metaphone0.metaphone(" AKPKMNSKTK");
        boolean boolean17 = metaphone0.isMetaphoneEqual("ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT", "ARKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "K" + "'", str14, "K");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test1275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1275");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A062125232523621256212523252362125");
        java.lang.String str29 = refinedSoundex0.soundex("A621r");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A09" + "'", str29, "A09");
    }

    @Test
    public void test1276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1276");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen(48);
        boolean boolean11 = metaphone0.isMetaphoneEqual("O620", "A09313836383693158931");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: ORKPXKMNSK", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 48 + "'", int12 == 48);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test1277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1277");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        int int5 = soundex4.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex4.encode("AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test1278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1278");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("01230120022455012623010202", "AA11111111");
        java.lang.String str10 = refinedSoundex0.soundex("AKPKMNSKT1");
        java.lang.Object obj11 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = refinedSoundex0.encode(obj11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A0313836" + "'", str10, "A0313836");
    }

    @Test
    public void test1279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1279");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength((int) '\000');
        soundex4.setMaxLength((int) 'i');
        java.lang.String str10 = soundex4.encode("A621r");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A600" + "'", str10, "A600");
    }

    @Test
    public void test1280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1280");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "org.apache.commons.codec.EncoderException: ARKP", "K111111111");
        java.lang.String str8 = refinedSoundex0.soundex("A111111111O000");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A0" + "'", str8, "A0");
    }

    @Test
    public void test1281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1281");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex5.setMaxLength((int) (short) -1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = soundex5.soundex("org.apache.commons.codec.EncoderException: AA11111111");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1282");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("A621");
        java.lang.String str13 = refinedSoundex0.encode("O000");
        char char15 = refinedSoundex0.getMappingCode('a');
        java.lang.String str17 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '0' + "'", char15 == '0');
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0940103030808306030830609053016080940103030808306030830609053016080931" + "'", str17, "O0940103030808306030830609053016080940103030808306030830609053016080931");
    }

    @Test
    public void test1283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1283");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = metaphone0.encode("A212");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A" + "'", str17, "A");
    }

    @Test
    public void test1284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1284");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.encode("H");
        java.lang.String str15 = caverphone0.encode("AK11111111");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone25 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str27 = doubleMetaphone25.doubleMetaphone("H");
        doubleMetaphone25.setMaxCodeLen((int) (byte) 0);
        char char32 = doubleMetaphone25.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult34 = doubleMetaphone25.new DoubleMetaphoneResult((int) '4');
        java.lang.String str35 = doubleMetaphoneResult34.getPrimary();
        java.lang.Object obj36 = caverphone16.encode((java.lang.Object) str35);
        java.lang.String str38 = caverphone16.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        boolean boolean41 = caverphone16.isCaverphoneEqual("org.apache.commons.codec.EncoderExc", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj42 = caverphone0.encode((java.lang.Object) caverphone16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertTrue("'" + char32 + "' != '" + 'i' + "'", char32 == 'i');
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertEquals("'" + obj36 + "' != '" + "1111111111" + "'", obj36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKKMNSKT" + "'", str38, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test1285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1285");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ORK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORK" + "'", str1, "ORK");
    }

    @Test
    public void test1286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1286");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.encode("org.apache.commons.codec.EncoderException: O0");
        boolean boolean16 = caverphone0.isCaverphoneEqual("", "A093153836383693158");
        boolean boolean19 = caverphone0.isCaverphoneEqual("O0940103030808306030830609053016080931", "");
        boolean boolean22 = caverphone0.isCaverphoneEqual("", "");
        char[] charArray27 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex28 = new org.apache.commons.codec.language.RefinedSoundex(charArray27);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = new org.apache.commons.codec.language.RefinedSoundex(charArray27);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = caverphone0.encode((java.lang.Object) refinedSoundex29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertArrayEquals(charArray27, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1287");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("ORKP");
        int int3 = metaphone0.getMaxCodeLen();
        char[] charArray4 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex5.setMaxLength(1);
        int int8 = soundex5.getMaxLength();
        java.lang.String str10 = soundex5.encode("O0940103030808306030830609053016080931");
        java.lang.Object obj11 = metaphone0.encode((java.lang.Object) "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertEquals("'" + obj11 + "' != '" + "O" + "'", obj11, "O");
    }

    @Test
    public void test1288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1288");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.encode("A0931");
        java.lang.Class<?> wildcardClass7 = soundex4.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A000" + "'", str6, "A000");
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test1289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1289");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str9 = metaphone0.encode("O09401030308083060308306090530160809315383638369315893153836383693158931");
        java.lang.String str11 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: hi!");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNH" + "'", str11, "ORKPXKMNSKTKNKTRKSSPXNH");
    }

    @Test
    public void test1290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1290");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        boolean boolean17 = metaphone0.isMetaphoneEqual("AKPKMNSK11", "");
        boolean boolean20 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSK", "A1");
        boolean boolean23 = metaphone0.isMetaphoneEqual("O620", "org.apache.commons.codec.EncoderException: A093153836383693158");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test1291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1291");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1292");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str15 = caverphone0.encode("AK11111111");
        char[] charArray16 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray16);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = new org.apache.commons.codec.language.RefinedSoundex(charArray16);
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray16);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = caverphone0.encode((java.lang.Object) charArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKT1" + "'", str13, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertNotNull(charArray16);
    }

    @Test
    public void test1293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1293");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "H");
        java.lang.String str18 = metaphone0.encode("A093138363836931589313836383693158");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: AK11111111", "a");
        java.lang.String str23 = metaphone0.encode("A09315383");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
    }

    @Test
    public void test1294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1294");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        int int5 = metaphone0.getMaxCodeLen();
        java.lang.String str7 = metaphone0.encode("A062125232523621256212523252362125");
        java.lang.String str9 = metaphone0.encode("ORKPXKMNSK");
        java.lang.Object obj10 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = metaphone0.encode(obj10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A" + "'", str7, "A");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
    }

    @Test
    public void test1295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1295");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        boolean boolean12 = doubleMetaphone0.isDoubleMetaphoneEqual("O621", "O0");
        doubleMetaphone0.setMaxCodeLen((int) 'a');
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "org.apache.commons.codec.EncoderException: AKPK", "O062125232523621256212523252362125");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test1296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1296");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 100);
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "");
        char char12 = doubleMetaphone0.charAt("", (int) (byte) 1);
        doubleMetaphone0.setMaxCodeLen((int) 'g');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
    }

    @Test
    public void test1297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1297");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex9.setMaxLength((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex9.encode("ARKPKKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1298");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        boolean boolean13 = metaphone0.isMetaphoneEqual("", "hi!");
        java.lang.String str15 = metaphone0.encode("O0940103030808306030830609053016080931");
        boolean boolean18 = metaphone0.isMetaphoneEqual("#", " AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test1299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1299");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.Encoder");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODER" + "'", str1, "ORGAPACHECOMMONSCODECENCODER");
    }

    @Test
    public void test1300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1300");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str5 = soundex1.encode("AA");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A000" + "'", str5, "A000");
    }

    @Test
    public void test1301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1301");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) 'o');
        java.lang.String str4 = soundex0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        int int7 = soundex0.difference("ORKP", "O0940103030808306030830609053016080");
        soundex0.setMaxLength(114);
        java.lang.Object obj10 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = soundex0.encode(obj10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test1302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1302");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("O0940103030808306030830609053016080");
        java.lang.Object obj12 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = caverphone0.encode(obj12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A111111111" + "'", str11, "A111111111");
    }

    @Test
    public void test1303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1303");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str9 = soundex7.encode("");
        soundex7.setMaxLength((int) '0');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex7.encode("ORKPXKMNSKTKNKTRKSSPXNH");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test1304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1304");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str13 = caverphone0.caverphone("O0931");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str16 = doubleMetaphone14.doubleMetaphone("H");
        doubleMetaphone14.setMaxCodeLen((int) (byte) 0);
        boolean boolean21 = doubleMetaphone14.isDoubleMetaphoneEqual("ORKP", "01230120022455012623010202");
        doubleMetaphone14.maxCodeLen = 0;
        java.lang.String str26 = doubleMetaphone14.doubleMetaphone("AKPKMNSKTS", true);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = caverphone0.encode((java.lang.Object) doubleMetaphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A111111111" + "'", str11, "A111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
    }

    @Test
    public void test1305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1305");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        boolean boolean15 = caverphone0.isCaverphoneEqual("ARKPKSKMNS", "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        boolean boolean18 = caverphone0.isCaverphoneEqual("1111111111", "O0931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test1306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1306");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        soundex4.setMaxLength((int) 'O');
        java.lang.String str12 = soundex4.encode("");
        int int13 = soundex4.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 79 + "'", int13 == 79);
    }

    @Test
    public void test1307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1307");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone13.encode("O621");
        char[] charArray18 = null;
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray18);
        java.lang.String str21 = soundex19.soundex("");
        java.lang.String str23 = soundex19.encode("");
        java.lang.Object obj24 = caverphone13.encode((java.lang.Object) str23);
        java.lang.Class<?> wildcardClass25 = obj24.getClass();
        java.lang.Object obj26 = refinedSoundex5.encode(obj24);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str28 = refinedSoundex5.encode("ARKPXKMNSKTKNKTRKSPXNRKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "1111111111" + "'", obj24, "1111111111");
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "" + "'", obj26, "");
    }

    @Test
    public void test1308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1308");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("AKPKMNSKT1", "");
        soundex2.setMaxLength(9);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test1309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1309");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone25 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str27 = doubleMetaphone25.doubleMetaphone("H");
        doubleMetaphone25.setMaxCodeLen((int) (byte) 0);
        java.lang.String str32 = doubleMetaphone25.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult34 = doubleMetaphone25.new DoubleMetaphoneResult(0);
        java.lang.String str35 = doubleMetaphoneResult34.getAlternate();
        doubleMetaphoneResult34.append("A621", "");
        doubleMetaphoneResult34.append("A1");
        doubleMetaphoneResult34.append("o");
        java.lang.Object obj43 = refinedSoundex0.encode((java.lang.Object) "o");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O0940103030808306030830609053016080" + "'", str24, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertEquals("'" + obj43 + "' != '" + "O0" + "'", obj43, "O0");
    }

    @Test
    public void test1310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1310");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: ", "A0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1311");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (short) 0);
        java.lang.String str11 = soundex1.encode("A0212523");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A000" + "'", str11, "A000");
    }

    @Test
    public void test1312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1312");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int5 = refinedSoundex2.difference("i4org.apache.commons.codec.EncoderException: A000", "AKPKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1313");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int9 = soundex6.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test1314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1314");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 1);
        int int6 = metaphone0.getMaxCodeLen();
        java.lang.String str8 = metaphone0.metaphone("A621");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A" + "'", str8, "A");
    }

    @Test
    public void test1315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1315");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        java.lang.String str9 = soundex1.encode("01230120022455012623010202");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(97);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test1316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1316");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        java.lang.String str12 = metaphone0.encode("AA11111111");
        int int13 = metaphone0.getMaxCodeLen();
        java.lang.Object obj15 = metaphone0.encode((java.lang.Object) "A111111111O000");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertEquals("'" + obj15 + "' != '" + "A" + "'", obj15, "A");
    }

    @Test
    public void test1317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1317");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AKPKMNSK11");
        org.apache.commons.codec.language.Caverphone caverphone31 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str33 = caverphone31.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str35 = caverphone31.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str37 = caverphone31.encode("");
        java.lang.String str39 = caverphone31.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone40 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone40.maxCodeLen = 0;
        char char45 = doubleMetaphone40.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult47 = doubleMetaphone40.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult47.appendAlternate('\000');
        java.lang.String str50 = doubleMetaphoneResult47.getAlternate();
        java.lang.String str51 = doubleMetaphoneResult47.getPrimary();
        java.lang.Object obj52 = caverphone31.encode((java.lang.Object) str51);
        java.lang.String str54 = caverphone31.caverphone("");
        int int57 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone31, "AKPKKMNSKT", "ORKP");
        boolean boolean60 = caverphone31.isCaverphoneEqual("", "HI");
        boolean boolean63 = caverphone31.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str65 = caverphone31.encode("A0");
        java.lang.Object obj66 = caverphone0.encode((java.lang.Object) str65);
        boolean boolean69 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKMNSK11" + "'", str30, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "AKPKKMNSKT" + "'", str33, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "AKPKKMNSKT" + "'", str35, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "1111111111" + "'", str37, "1111111111");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "1111111111" + "'", str39, "1111111111");
        org.junit.Assert.assertTrue("'" + char45 + "' != '" + '\000' + "'", char45 == '\000');
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "" + "'", str50, "");
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
        org.junit.Assert.assertEquals("'" + obj52 + "' != '" + "1111111111" + "'", obj52, "1111111111");
        org.junit.Assert.assertEquals("'" + str54 + "' != '" + "1111111111" + "'", str54, "1111111111");
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertEquals("'" + str65 + "' != '" + "A111111111" + "'", str65, "A111111111");
        org.junit.Assert.assertEquals("'" + obj66 + "' != '" + "A111111111" + "'", obj66, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test1318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1318");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        boolean boolean15 = caverphone0.isCaverphoneEqual("AKPKKMNSKT", "A0931383");
        java.lang.String str17 = caverphone0.encode("hi!");
        java.lang.String str19 = caverphone0.caverphone("K");
        java.lang.String str21 = caverphone0.caverphone("A0212523");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "K111111111" + "'", str19, "K111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A111111111" + "'", str21, "A111111111");
    }

    @Test
    public void test1319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1319");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        java.lang.String str38 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str40 = caverphone0.caverphone("H");
        boolean boolean43 = caverphone0.isCaverphoneEqual("A03138363", "A031");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKKMNSKT" + "'", str38, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "A111111111" + "'", str40, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test1320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1320");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        java.lang.String str23 = metaphone0.metaphone("");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
    }

    @Test
    public void test1321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1321");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "O062125232523621256212523252362125");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1322");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        int int13 = metaphone0.getMaxCodeLen();
        int int14 = metaphone0.getMaxCodeLen();
        int int15 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test1323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1323");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        java.lang.String str24 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        int int25 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) -1);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORKPXKMNSK" + "'", str24, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
    }

    @Test
    public void test1324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1324");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        int int11 = soundex0.difference("H000", "HI");
        soundex0.setMaxLength((int) 'H');
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex14 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char16 = refinedSoundex14.getMappingCode('a');
        int int19 = refinedSoundex14.difference("", "hi!");
        char char21 = refinedSoundex14.getMappingCode('#');
        java.lang.String str23 = refinedSoundex14.soundex("01230120022455012623010202");
        java.lang.String str25 = refinedSoundex14.encode("O");
        int int28 = refinedSoundex14.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        java.lang.Object obj29 = soundex0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A0");
        java.lang.String str31 = soundex0.soundex("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone32 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str34 = doubleMetaphone32.doubleMetaphone("H");
        doubleMetaphone32.setMaxCodeLen((int) (byte) 0);
        char char39 = doubleMetaphone32.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult41 = doubleMetaphone32.new DoubleMetaphoneResult((int) '4');
        java.lang.String str42 = doubleMetaphoneResult41.getAlternate();
        doubleMetaphoneResult41.append('r');
        doubleMetaphoneResult41.appendPrimary('O');
        doubleMetaphoneResult41.append('i');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj49 = soundex0.encode((java.lang.Object) doubleMetaphoneResult41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(refinedSoundex14);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '0' + "'", char16 == '0');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "O0" + "'", str25, "O0");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "O621" + "'", obj29, "O621");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "O621" + "'", str31, "O621");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertTrue("'" + char39 + "' != '" + 'i' + "'", char39 == 'i');
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
    }

    @Test
    public void test1325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1325");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            int int12 = refinedSoundex9.difference("RKPXKMNSKTKNKTRKSSPXNRKP", "A0931383");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1326");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        soundex0.setMaxLength((int) '8');
        int int13 = soundex0.getMaxLength();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 56 + "'", int13 == 56);
    }

    @Test
    public void test1327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1327");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: A#", "A621r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1328");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) 'o');
        java.lang.String str4 = soundex0.soundex("org.apache.commons.codec.EncoderException: org.ap");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
    }

    @Test
    public void test1329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1329");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        java.lang.String str9 = soundex1.soundex("");
        int int10 = soundex1.getMaxLength();
        int int11 = soundex1.getMaxLength();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test1330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1330");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        boolean boolean33 = caverphone0.isCaverphoneEqual("AKPK", "ARKPKKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test1331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1331");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = '\000';
        doubleMetaphone7.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult13 = doubleMetaphone7.new DoubleMetaphoneResult((int) '1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = soundex0.encode((java.lang.Object) doubleMetaphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
    }

    @Test
    public void test1332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1332");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
    }

    @Test
    public void test1333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1333");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.encode("H");
        boolean boolean16 = caverphone0.isCaverphoneEqual("A111111111O620", "hi!");
        java.lang.String str18 = caverphone0.caverphone("AKPKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKMNSK11" + "'", str18, "AKPKMNSK11");
    }

    @Test
    public void test1334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1334");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("org.apache.commons.codec.EncoderException: AKPKKMNSKT", "");
        int int8 = soundex2.difference("", "ARKPKSKMNS");
        org.apache.commons.codec.EncoderException encoderException10 = new org.apache.commons.codec.EncoderException("ORKP");
        java.lang.Throwable[] throwableArray11 = encoderException10.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = soundex2.encode((java.lang.Object) throwableArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertArrayEquals(throwableArray11, new java.lang.Throwable[] {});
    }

    @Test
    public void test1335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1335");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen(48);
        java.lang.String str6 = metaphone0.metaphone("AK11111111");
        char[] charArray7 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray7);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray7);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = new org.apache.commons.codec.language.RefinedSoundex(charArray7);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex12 = new org.apache.commons.codec.language.RefinedSoundex(charArray7);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = metaphone0.encode((java.lang.Object) refinedSoundex12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "AK" + "'", str6, "AK");
        org.junit.Assert.assertNotNull(charArray7);
    }

    @Test
    public void test1336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1336");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        int int5 = metaphone0.getMaxCodeLen();
        java.lang.String str7 = metaphone0.encode("A062125232523621256212523252362125");
        java.lang.String str9 = metaphone0.encode("ORKPXKMNSK");
        metaphone0.setMaxCodeLen(0);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A" + "'", str7, "A");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
    }

    @Test
    public void test1337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1337");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str8 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        char[] charArray13 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex14 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex15 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex16 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex17 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex18 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex20 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex21 = new org.apache.commons.codec.language.Soundex(charArray13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = metaphone0.encode((java.lang.Object) charArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKPXKMNSK" + "'", str8, "ORKPXKMNSK");
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertArrayEquals(charArray13, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1338");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = refinedSoundex3.difference("K111111111", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
    }

    @Test
    public void test1339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1339");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        char[] charArray12 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = new org.apache.commons.codec.language.RefinedSoundex(charArray12);
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray12);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex15 = new org.apache.commons.codec.language.RefinedSoundex(charArray12);
        org.apache.commons.codec.language.Soundex soundex16 = new org.apache.commons.codec.language.Soundex(charArray12);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = caverphone0.encode((java.lang.Object) soundex16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertArrayEquals(charArray12, new char[] { 'a' });
    }

    @Test
    public void test1340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1340");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        java.lang.String str15 = caverphone0.encode("AK");
        java.lang.String str17 = caverphone0.caverphone("ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean20 = caverphone0.isCaverphoneEqual("ARKPKKMNSK", "A0212523");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKMNSKTK" + "'", str17, "AKPKMNSKTK");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test1341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1341");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.caverphone("A");
        java.lang.String str36 = caverphone0.encode("A09315383");
        char[] charArray37 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex38 = new org.apache.commons.codec.language.Soundex(charArray37);
        org.apache.commons.codec.language.Soundex soundex39 = new org.apache.commons.codec.language.Soundex(charArray37);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex40 = new org.apache.commons.codec.language.RefinedSoundex(charArray37);
        org.apache.commons.codec.language.Soundex soundex41 = new org.apache.commons.codec.language.Soundex(charArray37);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex42 = new org.apache.commons.codec.language.RefinedSoundex(charArray37);
        org.apache.commons.codec.language.Soundex soundex43 = new org.apache.commons.codec.language.Soundex(charArray37);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj44 = caverphone0.encode((java.lang.Object) charArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "A111111111" + "'", str36, "A111111111");
        org.junit.Assert.assertNotNull(charArray37);
    }

    @Test
    public void test1342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1342");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('4');
        java.lang.String str8 = refinedSoundex4.soundex("");
        java.lang.String str10 = refinedSoundex4.encode("AA");
        java.lang.String str12 = refinedSoundex4.soundex("");
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A#" + "'", str10, "A#");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test1343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1343");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int13 = soundex0.difference("AKPKMNSKTK", "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str15 = soundex0.encode("");
        java.lang.String str17 = soundex0.encode("1111111111");
        java.lang.String[] strArray30 = new java.lang.String[] {};
        boolean boolean31 = org.apache.commons.codec.language.DoubleMetaphone.contains("01230120022455012623010202", (int) 'a', (int) (short) 0, strArray30);
        boolean boolean32 = org.apache.commons.codec.language.DoubleMetaphone.contains("1111111111", (int) (byte) 10, (int) (byte) 0, strArray30);
        boolean boolean33 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKPKSKMNS", (int) (short) 100, 52, strArray30);
        boolean boolean34 = org.apache.commons.codec.language.DoubleMetaphone.contains("org.apache.commons.codec.EncoderException: ORKP", (int) (byte) -1, 19, strArray30);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj35 = soundex0.encode((java.lang.Object) strArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertArrayEquals(strArray30, new java.lang.String[] {});
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test1344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1344");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("A313");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A0" + "'", str4, "A0");
    }

    @Test
    public void test1345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1345");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        java.lang.String str24 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        metaphone0.setMaxCodeLen((int) '#');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORKPXKMNSK" + "'", str24, "ORKPXKMNSK");
    }

    @Test
    public void test1346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1346");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        char char12 = refinedSoundex0.getMappingCode('a');
        java.lang.String str14 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('K');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O0940103030808306030830609053016080" + "'", str14, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '3' + "'", char16 == '3');
    }

    @Test
    public void test1347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1347");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: AA11111111");
        java.lang.String str32 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKKMNSKT" + "'", str30, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKPKKMNSKT" + "'", str32, "AKPKKMNSKT");
    }

    @Test
    public void test1348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1348");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        metaphone0.setMaxCodeLen((int) '0');
        metaphone0.setMaxCodeLen(0);
        java.lang.String str18 = metaphone0.encode("ARKP");
        int int19 = metaphone0.getMaxCodeLen();
        int int20 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test1349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1349");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        java.lang.String str24 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ARKPKSKMNS" + "'", str22, "ARKPKSKMNS");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORKPXKMNSK" + "'", str24, "ORKPXKMNSK");
    }

    @Test
    public void test1350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1350");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength(100);
        java.lang.String str11 = soundex1.soundex("1111111111");
        soundex1.setMaxLength((int) (short) 0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str15 = soundex1.encode("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: ORKPXKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
    }

    @Test
    public void test1351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1351");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("A621");
        java.lang.Object obj12 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = refinedSoundex0.encode(obj12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
    }

    @Test
    public void test1352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1352");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("I000");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "I" + "'", str1, "I");
    }

    @Test
    public void test1353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1353");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex7.difference("A093153836383693158", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test1354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1354");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("ORKP", "");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "org.apache.commons.codec.EncoderExc", "A1111111114r");
        int int13 = soundex1.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "AKPKMNSKTS");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1355");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.encode("");
        java.lang.String str24 = metaphone0.metaphone("AKPKSKMNSK");
        java.lang.String str26 = metaphone0.metaphone("A09");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKSKMNSK" + "'", str24, "AKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "A" + "'", str26, "A");
    }

    @Test
    public void test1356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1356");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        java.lang.String str13 = caverphone0.encode("HI");
        boolean boolean16 = caverphone0.isCaverphoneEqual("i4org.apache.commons.codec.EncoderException: A000", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AA11111111" + "'", str13, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test1357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1357");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test1358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1358");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        int int11 = metaphone0.getMaxCodeLen();
        java.lang.String str13 = metaphone0.encode("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O" + "'", str13, "O");
    }

    @Test
    public void test1359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1359");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        java.lang.String str12 = metaphone0.encode("AA11111111");
        java.lang.String str14 = metaphone0.encode("org.apache.commons.codec.EncoderException:  ");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
    }

    @Test
    public void test1360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1360");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        java.lang.String str5 = soundex1.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str7 = soundex1.encode("A09");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O000" + "'", str5, "O000");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
    }

    @Test
    public void test1361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1361");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        int int10 = metaphone0.getMaxCodeLen();
        int int11 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test1362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1362");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        boolean boolean10 = metaphone0.isMetaphoneEqual("AKP1111111", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        java.lang.String str12 = metaphone0.encode("A931");
        char[] charArray13 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex15 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex16 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex17 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = metaphone0.encode((java.lang.Object) charArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertNotNull(charArray13);
    }

    @Test
    public void test1363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1363");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        java.lang.String str29 = refinedSoundex0.encode("A621r");
        int int32 = refinedSoundex0.difference("ARKPKSKMNSKTKNKTRKSPKSN", "ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str34 = refinedSoundex0.encode("K111111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A09" + "'", str29, "A09");
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "K3" + "'", str34, "K3");
    }

    @Test
    public void test1364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1364");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 100);
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O0", "A000");
        java.lang.Class<?> wildcardClass13 = doubleMetaphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test1365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1365");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPKSKMNSK" + "'", str1, "ARKPKSKMNSK");
    }

    @Test
    public void test1366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1366");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str14 = metaphone0.encode("A1");
        java.lang.String str16 = metaphone0.metaphone("");
        java.lang.String str18 = metaphone0.metaphone("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
    }

    @Test
    public void test1367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1367");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str9 = soundex7.encode("");
        soundex7.setMaxLength((int) (byte) 100);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex7.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAO");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test1368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1368");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A313");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
    }

    @Test
    public void test1369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1369");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.metaphone("01230120022455012623010202");
        java.lang.String str7 = metaphone0.encode("AKPK");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A212", " org.apache.commons.codec.EncoderException: ORGAP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKP" + "'", str7, "AKP");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test1370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1370");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        int int16 = metaphone13.getMaxCodeLen();
        boolean boolean19 = metaphone13.isMetaphoneEqual("", "");
        boolean boolean22 = metaphone13.isMetaphoneEqual("01230120022455012623010202", "");
        int int25 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone13, "01230120022455012623010202", "");
        java.lang.String str27 = metaphone13.encode("O093");
        boolean boolean30 = metaphone13.isMetaphoneEqual("A313", "org.apache.commons.codec.EncoderException: ");
        java.lang.String str32 = metaphone13.metaphone("O620");
        java.lang.Object obj33 = metaphone0.encode((java.lang.Object) str32);
        boolean boolean36 = metaphone0.isMetaphoneEqual("AKPKMNSK11", "");
        java.lang.String str38 = metaphone0.metaphone("  ");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "O" + "'", str27, "O");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "O" + "'", str32, "O");
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "O" + "'", obj33, "O");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
    }

    @Test
    public void test1371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1371");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        int int10 = metaphone0.getMaxCodeLen();
        boolean boolean13 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "");
        java.lang.String str15 = metaphone0.encode("a");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A" + "'", str15, "A");
    }

    @Test
    public void test1372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1372");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone13.encode("O621");
        char[] charArray18 = null;
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray18);
        java.lang.String str21 = soundex19.soundex("");
        java.lang.String str23 = soundex19.encode("");
        java.lang.Object obj24 = caverphone13.encode((java.lang.Object) str23);
        java.lang.Class<?> wildcardClass25 = obj24.getClass();
        java.lang.Object obj26 = refinedSoundex5.encode(obj24);
        // The following exception was thrown during execution in test generation
        try {
            int int29 = refinedSoundex5.difference("AKPKMNSKTS", "org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080940103030808306030830609053016080");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "1111111111" + "'", obj24, "1111111111");
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "" + "'", obj26, "");
    }

    @Test
    public void test1373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1373");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        java.lang.String str8 = soundex3.soundex("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            int int11 = soundex3.difference("org.apache.commons.codec.Encoder", "A111111111O000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test1374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1374");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP" + "'", str1, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
    }

    @Test
    public void test1375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1375");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AKP1111111", "K000");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1376");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        boolean boolean11 = metaphone0.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        metaphone0.setMaxCodeLen((int) 'A');
        int int14 = metaphone0.getMaxCodeLen();
        java.lang.String str16 = metaphone0.encode("A0");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 65 + "'", int14 == 65);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
    }

    @Test
    public void test1377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1377");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        int int3 = soundex0.getMaxLength();
        int int4 = soundex0.getMaxLength();
        int int7 = soundex0.difference("H", "O0");
        int int10 = soundex0.difference("O09401030308083060308306090530160809315383", "ORGAPACHECOMMONSCODECENCODER");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test1378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1378");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str15 = refinedSoundex0.soundex("O0940103030808306030830609053016080");
        char char17 = refinedSoundex0.getMappingCode('#');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
    }

    @Test
    public void test1379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1379");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: AK11111111", "A0313");
        int int8 = soundex1.difference("O094010303080830603083060905301608093", "A931");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test1380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1380");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str8 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        int int9 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str12 = metaphone10.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone10.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone15 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str17 = caverphone15.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str19 = caverphone15.caverphone("hi!");
        java.lang.Object obj20 = metaphone10.encode((java.lang.Object) "hi!");
        int int21 = metaphone10.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = metaphone0.encode((java.lang.Object) int21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKPXKMNSK" + "'", str8, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ORKP" + "'", str12, "ORKP");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AA11111111" + "'", str19, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "H" + "'", obj20, "H");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
    }

    @Test
    public void test1381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1381");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        java.lang.String str14 = caverphone0.encode("AKPKKMNSKT");
        boolean boolean17 = caverphone0.isCaverphoneEqual("O941", "");
        java.lang.String str19 = caverphone0.encode("org.apache.commons.codec.EncoderException: O000");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone20 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone20.maxCodeLen = '\000';
        doubleMetaphone20.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult26 = doubleMetaphone20.new DoubleMetaphoneResult((int) '1');
        doubleMetaphoneResult26.appendPrimary(' ');
        boolean boolean29 = doubleMetaphoneResult26.isComplete();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKT1" + "'", str14, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKKMNSKT" + "'", str19, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test1382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1382");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 1);
        int int6 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) -1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test1383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1383");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("org.apache.commons.codec.Encoder");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test1384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1384");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        boolean boolean7 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ARK", "A");
        metaphone0.setMaxCodeLen((int) 'o');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test1385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1385");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.Object obj32 = caverphone0.encode((java.lang.Object) "AKPKMNSKT1");
        java.lang.String str34 = caverphone0.caverphone("O0940103030808306030830609053016080931");
        int int37 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.language.Caverphone caverphone38 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str40 = caverphone38.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str42 = caverphone38.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str44 = caverphone38.encode("");
        java.lang.String str46 = caverphone38.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone47 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone47.maxCodeLen = 0;
        char char52 = doubleMetaphone47.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult54 = doubleMetaphone47.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult54.appendAlternate('\000');
        java.lang.String str57 = doubleMetaphoneResult54.getAlternate();
        java.lang.String str58 = doubleMetaphoneResult54.getPrimary();
        java.lang.Object obj59 = caverphone38.encode((java.lang.Object) str58);
        java.lang.String str61 = caverphone38.caverphone("");
        int int64 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone38, "AKPKKMNSKT", "ORKP");
        java.lang.String str66 = caverphone38.encode("O0");
        java.lang.String str68 = caverphone38.encode("");
        java.lang.Object obj70 = caverphone38.encode((java.lang.Object) "AKPKMNSKT1");
        boolean boolean73 = caverphone38.isCaverphoneEqual("", "AK11111111");
        java.lang.Object obj74 = caverphone0.encode((java.lang.Object) "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "AKPKMNSKT1" + "'", obj32, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "AKPKKMNSKT" + "'", str40, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "AKPKKMNSKT" + "'", str42, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "1111111111" + "'", str44, "1111111111");
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "1111111111" + "'", str46, "1111111111");
        org.junit.Assert.assertTrue("'" + char52 + "' != '" + '\000' + "'", char52 == '\000');
        org.junit.Assert.assertEquals("'" + str57 + "' != '" + "" + "'", str57, "");
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "" + "'", str58, "");
        org.junit.Assert.assertEquals("'" + obj59 + "' != '" + "1111111111" + "'", obj59, "1111111111");
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + "1111111111" + "'", str61, "1111111111");
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertEquals("'" + str66 + "' != '" + "A111111111" + "'", str66, "A111111111");
        org.junit.Assert.assertEquals("'" + str68 + "' != '" + "1111111111" + "'", str68, "1111111111");
        org.junit.Assert.assertEquals("'" + obj70 + "' != '" + "AKPKMNSKT1" + "'", obj70, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertEquals("'" + obj74 + "' != '" + "1111111111" + "'", obj74, "1111111111");
    }

    @Test
    public void test1386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1386");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        java.lang.String str15 = metaphone0.metaphone("A000");
        java.lang.String str17 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXN");
        int int18 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) '5');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test1387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1387");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        int int16 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "A000");
        java.lang.String str18 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
        int int21 = refinedSoundex0.difference("A062125232523621256212523252362125", "A ");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0940103030808306030830609053016080313836" + "'", str18, "O0940103030808306030830609053016080313836");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test1388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1388");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A0313836", "AHIAM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1389");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('\000');
        char char8 = refinedSoundex4.getMappingCode('A');
        // The following exception was thrown during execution in test generation
        try {
            int int11 = refinedSoundex4.difference("O0940103030808306030830609053016080931", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '#' + "'", char8 == '#');
    }

    @Test
    public void test1390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1390");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = soundex6.encode("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1391");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        char char13 = refinedSoundex0.getMappingCode('4');
        java.lang.String str15 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        char char17 = refinedSoundex0.getMappingCode('1');
        char char19 = refinedSoundex0.getMappingCode('o');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O09401030308083060308306090530160809315383638369315893153836383693158931" + "'", str15, "O09401030308083060308306090530160809315383638369315893153836383693158931");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '0' + "'", char19 == '0');
    }

    @Test
    public void test1392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1392");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O0931");
        java.lang.String str6 = caverphone0.caverphone(" O620");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
    }

    @Test
    public void test1393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1393");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPKMNSKTKNKTRKSPKSNRKPKMNSKTKNKTRKSPKSN", "A621org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1394");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        boolean boolean39 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.Encoder", "");
        int int42 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKPor", "org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
    }

    @Test
    public void test1395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1395");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int5 = soundex0.difference("A0", "");
        java.lang.String str7 = soundex0.soundex("");
        int int10 = soundex0.difference("O09315383638369315893153836383693158", "ORKPXKMNSKTKNKTRKSSPXN");
        java.lang.String str12 = soundex0.soundex("A093153836383693158");
        int int15 = soundex0.difference("A621HI", "A ");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A000" + "'", str12, "A000");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test1396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1396");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str1, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
    }

    @Test
    public void test1397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1397");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        int int11 = soundex0.difference("H000", "HI");
        soundex0.setMaxLength((int) 'H');
        int int16 = soundex0.difference("A062125232523621256212523252362125", "OA1111111114r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test1398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1398");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        int int3 = doubleMetaphone0.maxCodeLen;
        int int4 = doubleMetaphone0.maxCodeLen;
        doubleMetaphone0.maxCodeLen = (short) 10;
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: AKPK", "ORKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test1399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1399");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.soundex("A931");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A000" + "'", str6, "A000");
    }

    @Test
    public void test1400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1400");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str14 = metaphone0.encode("A1");
        boolean boolean17 = metaphone0.isMetaphoneEqual("AHIAM", "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test1401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1401");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean22 = caverphone0.isCaverphoneEqual("A#", "AKP1111111");
        java.lang.String str24 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        boolean boolean27 = caverphone0.isCaverphoneEqual("ORK", "");
        java.lang.String str29 = caverphone0.caverphone("A09315383");
        java.lang.String str31 = caverphone0.encode("AA11111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AA11111111" + "'", str31, "AA11111111");
    }

    @Test
    public void test1402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1402");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("9", "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1403");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A ");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) "A ");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A1", "O941");
        java.lang.String str19 = metaphone0.metaphone("AKPKMNSKT1");
        java.lang.String str21 = metaphone0.encode("A ");
        int int22 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "A" + "'", obj14, "A");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSKT" + "'", str19, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A" + "'", str21, "A");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
    }

    @Test
    public void test1404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1404");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        boolean boolean13 = doubleMetaphone8.isDoubleMetaphoneEqual("01230120022455012623010202", "");
        java.lang.Object obj14 = soundex1.encode((java.lang.Object) "01230120022455012623010202");
        java.lang.String str16 = soundex1.encode("");
        java.lang.Object obj17 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = soundex1.encode(obj17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "" + "'", obj14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
    }

    @Test
    public void test1405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1405");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("AK11111111", "01230120022455012623010202");
        boolean boolean14 = caverphone0.isCaverphoneEqual("AKPKMNSK11", "ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKT");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test1406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1406");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = soundex3.difference("aorg.apache.commons.codec.Encode", "O09401030308083060308306090530160809315383");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1407");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str15 = caverphone0.encode("H0");
        java.lang.String str17 = caverphone0.caverphone("ARK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AK11111111" + "'", str17, "AK11111111");
    }

    @Test
    public void test1408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1408");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str7 = soundex2.encode("AKPKKMNSKT");
        int int10 = soundex2.difference("hi!", "A0");
        soundex2.setMaxLength(56);
        soundex2.setMaxLength(43);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A313" + "'", str7, "A313");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test1409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1409");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str30 = doubleMetaphone28.doubleMetaphone("H");
        java.lang.String str32 = doubleMetaphone28.doubleMetaphone("HI");
        java.lang.String str34 = doubleMetaphone28.doubleMetaphone("AKPKMNSKT1");
        java.lang.Object obj35 = metaphone0.encode((java.lang.Object) str34);
        boolean boolean38 = metaphone0.isMetaphoneEqual("", "A111111111");
        boolean boolean41 = metaphone0.isMetaphoneEqual("AHIAM", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPK" + "'", str34, "AKPK");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "AKPK" + "'", obj35, "AKPK");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test1410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1410");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080940103030808306030830609053016080", "org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44 + "'", int2 == 44);
    }

    @Test
    public void test1411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1411");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str7 = soundex1.encode("AA11111111");
        java.lang.String str9 = soundex1.encode("org.apache.commons.codec.EncoderException: A0");
        int int10 = soundex1.getMaxLength();
        int int11 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) 'e');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test1412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1412");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        java.lang.String str38 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean41 = caverphone0.isCaverphoneEqual("", " AKPK");
        java.lang.String str43 = caverphone0.encode("O093");
        boolean boolean46 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone47 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone47.maxCodeLen = 0;
        java.lang.String str51 = doubleMetaphone47.encode("A621");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult53 = doubleMetaphone47.new DoubleMetaphoneResult(48);
        doubleMetaphoneResult53.append(' ');
        doubleMetaphoneResult53.append("AKP1111111");
        doubleMetaphoneResult53.append(" ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj60 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKKMNSKT" + "'", str38, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "A111111111" + "'", str43, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
    }

    @Test
    public void test1413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1413");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = soundex10.encode("ARKPKMNSKTKNKTRKSPKSNRKPKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1414");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex8.setMaxLength((int) '1');
        java.lang.String str12 = soundex8.soundex("#");
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test1415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1415");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex8.setMaxLength((int) '1');
        java.lang.String str12 = soundex8.soundex("");
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test1416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1416");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = (byte) 10;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A", "A");
        boolean boolean23 = doubleMetaphone0.isDoubleMetaphoneEqual("H000", "1111111111");
        char char26 = doubleMetaphone0.charAt("O0", 1);
        doubleMetaphone0.maxCodeLen = 38;
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
    }

    @Test
    public void test1417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1417");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        java.lang.String str14 = soundex3.encode("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        soundex3.setMaxLength(38);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O621" + "'", str14, "O621");
    }

    @Test
    public void test1418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1418");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        soundex0.setMaxLength(0);
        soundex0.setMaxLength((int) '#');
        soundex0.setMaxLength((int) 'i');
        int int12 = soundex0.getMaxLength();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 105 + "'", int12 == 105);
    }

    @Test
    public void test1419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1419");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            int int12 = soundex9.difference(" ", " org.apache.commons.codec.EncoderException: ORGAP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test1420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1420");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.String str12 = caverphone0.encode("O0940103030808306030830609053016080931");
        boolean boolean15 = caverphone0.isCaverphoneEqual("A621", "");
        java.lang.String str17 = caverphone0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
    }

    @Test
    public void test1421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1421");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        int int7 = refinedSoundex0.difference("KPK", "");
        int int10 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "O000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080" + "'", str4, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test1422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1422");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex5.setMaxLength((int) (short) -1);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex5.difference("1111111111", "AR");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test1423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1423");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("AA");
        int int8 = soundex0.getMaxLength();
        java.lang.String str10 = soundex0.encode(" AKPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A212" + "'", str10, "A212");
    }

    @Test
    public void test1424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1424");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('a');
        int int10 = refinedSoundex0.difference("AK", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        java.lang.String str12 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str14 = refinedSoundex0.soundex("ORKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O0940103030808306030830609053016080" + "'", str12, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O0931" + "'", str14, "O0931");
    }

    @Test
    public void test1425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1425");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        int int28 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "", "");
        java.lang.String str30 = caverphone0.caverphone("AK11111111");
        boolean boolean33 = caverphone0.isCaverphoneEqual("", "O621");
        org.apache.commons.codec.language.Caverphone caverphone34 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str36 = caverphone34.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str38 = caverphone34.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str40 = caverphone34.encode("A");
        java.lang.String str42 = caverphone34.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Object obj43 = caverphone0.encode((java.lang.Object) "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AK11111111" + "'", str30, "AK11111111");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "AKPKKMNSKT" + "'", str36, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKKMNSKT" + "'", str38, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "A111111111" + "'", str40, "A111111111");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "AKPKKMNSKT" + "'", str42, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + obj43 + "' != '" + "AKPKKMNSKT" + "'", obj43, "AKPKKMNSKT");
    }

    @Test
    public void test1426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1426");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = refinedSoundex5.soundex("ARKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test1427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1427");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (byte) 100);
        int int15 = soundex1.getMaxLength();
        java.lang.Object obj16 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = soundex1.encode(obj16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
    }

    @Test
    public void test1428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1428");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "O620", "org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        java.lang.Object obj11 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = metaphone0.encode(obj11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test1429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1429");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.soundex("A0313836");
        java.lang.String str12 = soundex0.soundex("O0940103030808306030830609053016080");
        java.lang.Object obj13 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = soundex0.encode(obj13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O000" + "'", str12, "O000");
    }

    @Test
    public void test1430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1430");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("");
        boolean boolean11 = metaphone0.isMetaphoneEqual("AKPK", "");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A111111111O620", "ARKPXKMNSKTKNKTRKSPXN");
        boolean boolean18 = metaphone0.isMetaphoneEqual("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKPor", "AKP1111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test1431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1431");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str11 = metaphone0.encode("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str14 = doubleMetaphone12.doubleMetaphone("H");
        doubleMetaphone12.setMaxCodeLen((int) (byte) 0);
        java.lang.String str19 = doubleMetaphone12.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone12.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult21.append('#', 'a');
        doubleMetaphoneResult21.append('O');
        java.lang.String str27 = doubleMetaphoneResult21.getPrimary();
        java.lang.Object obj28 = metaphone0.encode((java.lang.Object) str27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "" + "'", obj28, "");
    }

    @Test
    public void test1432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1432");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        soundex4.setMaxLength((int) 'O');
        int int13 = soundex4.difference("A313", "");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1433");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean10 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        metaphone0.setMaxCodeLen((int) 'a');
        metaphone0.setMaxCodeLen((int) 'M');
        java.lang.String str16 = metaphone0.metaphone("A313");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
    }

    @Test
    public void test1434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1434");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        int int4 = soundex1.getMaxLength();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char7 = refinedSoundex5.getMappingCode('a');
        int int10 = refinedSoundex5.difference("", "hi!");
        int int13 = refinedSoundex5.difference("hi!", "");
        char char15 = refinedSoundex5.getMappingCode('#');
        char char17 = refinedSoundex5.getMappingCode('a');
        java.lang.String str19 = refinedSoundex5.soundex("org.apache.commons.codec.EncoderException: A0");
        java.lang.Object obj20 = soundex1.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A0");
        soundex1.setMaxLength(35);
        java.lang.String str24 = soundex1.encode("O931");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(refinedSoundex5);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '0' + "'", char17 == '0');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0940103030808306030830609053016080" + "'", str19, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "O621" + "'", obj20, "O621");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O000" + "'", str24, "O000");
    }

    @Test
    public void test1435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1435");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        int int9 = soundex0.getMaxLength();
        soundex0.setMaxLength((int) (byte) -1);
        java.lang.String str13 = soundex0.soundex("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
    }

    @Test
    public void test1436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1436");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("");
        boolean boolean10 = metaphone0.isMetaphoneEqual("", "H");
        java.lang.String str12 = metaphone0.metaphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test1437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1437");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.caverphone("O941");
        java.lang.String str14 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        java.lang.String str16 = caverphone0.encode("I");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKKMNSKT" + "'", str14, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A111111111" + "'", str16, "A111111111");
    }

    @Test
    public void test1438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1438");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = '\000';
        doubleMetaphone8.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone8.new DoubleMetaphoneResult((int) '1');
        doubleMetaphoneResult14.appendPrimary(' ');
        doubleMetaphoneResult14.appendAlternate("A621");
        doubleMetaphoneResult14.appendAlternate('#');
        doubleMetaphoneResult14.append("O941", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Object obj24 = refinedSoundex4.encode((java.lang.Object) "O941");
        java.lang.String str26 = refinedSoundex4.encode("O094010303080830603083060905301608093");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "O0" + "'", obj24, "O0");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "O0" + "'", str26, "O0");
    }

    @Test
    public void test1439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1439");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO", "org.apache.commons.codec.EncoderException: HI");
        int int22 = refinedSoundex0.difference("K111111111", "O09401030308083060308306090530160809315383");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test1440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1440");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("H", "A");
        char char13 = refinedSoundex0.getMappingCode('a');
        char[] charArray14 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex15 = new org.apache.commons.codec.language.Soundex(charArray14);
        soundex15.setMaxLength(1);
        int int18 = soundex15.getMaxLength();
        java.lang.String str20 = soundex15.encode("O0940103030808306030830609053016080931");
        java.lang.Object obj21 = refinedSoundex0.encode((java.lang.Object) "O0940103030808306030830609053016080931");
        java.lang.String str23 = refinedSoundex0.soundex("ARKPKSKMNSK");
        int int26 = refinedSoundex0.difference("ARKPKMNSKTKNKTRKSPKSNRKPKMNSKTKNKTRKSPKSN", "A ");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O000" + "'", str20, "O000");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "O0" + "'", obj21, "O0");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A0931383" + "'", str23, "A0931383");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test1441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1441");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str15 = refinedSoundex0.soundex("O0940103030808306030830609053016080");
        java.lang.String str17 = refinedSoundex0.encode("");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
    }

    @Test
    public void test1442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1442");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) '4');
        boolean boolean20 = metaphone0.isMetaphoneEqual("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK", "");
        java.lang.Class<?> wildcardClass21 = metaphone0.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test1443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1443");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str13 = metaphone0.encode("A1");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "", "org.apache.commons.codec.EncoderException: A0");
        int int17 = metaphone0.getMaxCodeLen();
        int int18 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A" + "'", str13, "A");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
    }

    @Test
    public void test1444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1444");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: AKPK", "ARKPKSKMNSKTKNKTRKSPKSNRKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1445");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        int int10 = soundex1.difference("1111111111", "01230120022455012623010202");
        int int13 = soundex1.difference("A093153836383693158", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int16 = soundex1.difference("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "AKPKSKMNSK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test1446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1446");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        int int10 = soundex1.difference("1111111111", "01230120022455012623010202");
        int int13 = soundex1.difference("K111111111", "ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str15 = soundex1.encode("A031");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A000" + "'", str15, "A000");
    }

    @Test
    public void test1447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1447");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("K000");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "K" + "'", str1, "K");
    }

    @Test
    public void test1448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1448");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT", "R");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1449");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        char char6 = refinedSoundex4.getMappingCode('a');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str9 = doubleMetaphone7.doubleMetaphone("O0940103030808306030830609053016080");
        java.lang.Object obj10 = refinedSoundex4.encode((java.lang.Object) str9);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '1' + "'", char6 == '1');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "A1" + "'", obj10, "A1");
    }

    @Test
    public void test1450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1450");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str5 = soundex1.encode("A09");
        int int6 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "O621" + "'", str3, "O621");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A000" + "'", str5, "A000");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test1451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1451");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: hi!", "org.apache.commons.codec.EncoderException: ARKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test1452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1452");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "H000");
        java.lang.String str16 = refinedSoundex0.encode("");
        java.lang.String[] strArray35 = new java.lang.String[] { "HI", "H", "HI", "01230120022455012623010202", "01230120022455012623010202", "" };
        boolean boolean36 = org.apache.commons.codec.language.DoubleMetaphone.contains("", (int) (byte) -1, (int) (byte) 1, strArray35);
        boolean boolean37 = org.apache.commons.codec.language.DoubleMetaphone.contains("", (int) '0', (int) (byte) 10, strArray35);
        boolean boolean38 = org.apache.commons.codec.language.DoubleMetaphone.contains("ORKP", 2, 3, strArray35);
        boolean boolean39 = org.apache.commons.codec.language.DoubleMetaphone.contains("AK11111111", 7, 100, strArray35);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj40 = refinedSoundex0.encode((java.lang.Object) strArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertArrayEquals(strArray35, new java.lang.String[] { "HI", "H", "HI", "01230120022455012623010202", "01230120022455012623010202", "" });
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test1453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1453");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('a');
        int int10 = refinedSoundex0.difference("AK", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        java.lang.String str12 = refinedSoundex0.encode("");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.encode("");
        metaphone13.setMaxCodeLen((int) (short) 10);
        java.lang.String str23 = metaphone13.encode("A621");
        java.lang.String str25 = metaphone13.metaphone("org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        boolean boolean28 = metaphone13.isMetaphoneEqual("O0940103030808306030830609053016080931", "AK");
        java.lang.Object obj29 = refinedSoundex0.encode((java.lang.Object) "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A" + "'", str23, "A");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "ORKPXKMNSK" + "'", str25, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "O0" + "'", obj29, "O0");
    }

    @Test
    public void test1454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1454");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        boolean boolean12 = metaphone0.isMetaphoneEqual("K", "");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str15 = metaphone13.encode("");
        int int16 = metaphone13.getMaxCodeLen();
        metaphone13.setMaxCodeLen((int) (byte) 10);
        boolean boolean21 = metaphone13.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = metaphone0.encode((java.lang.Object) "A111111111");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A" + "'", obj22, "A");
    }

    @Test
    public void test1455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1455");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("OA1111111114r", "A111111111O000");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test1456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1456");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        int int16 = refinedSoundex0.difference("AA11111111", "01230120022455012623010202");
        int int19 = refinedSoundex0.difference("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "A");
        int int22 = refinedSoundex0.difference("a", "AKP1111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
    }

    @Test
    public void test1457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1457");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str9 = soundex7.encode("");
        soundex7.setMaxLength((int) '0');
        int int12 = soundex7.getMaxLength();
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 48 + "'", int12 == 48);
    }

    @Test
    public void test1458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1458");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        boolean boolean6 = doubleMetaphone0.isDoubleMetaphoneEqual("O000", "A ", true);
        java.lang.String str8 = doubleMetaphone0.doubleMetaphone("org.apache.commons.codec.EncoderException: hi!");
        int int11 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "", "H000");
        boolean boolean14 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: AK11111111", "ARKPXKMNSKTKNKTRKSPXNKPK");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test1459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1459");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        char char13 = refinedSoundex0.getMappingCode('4');
        java.lang.String str15 = refinedSoundex0.soundex("");
        java.lang.String str17 = refinedSoundex0.encode("");
        java.lang.String str19 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int22 = refinedSoundex0.difference("", "org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0940103030808306030830609053016080931" + "'", str19, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test1460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1460");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        java.lang.String str10 = caverphone0.encode("1111111111");
        boolean boolean13 = caverphone0.isCaverphoneEqual("O620", "1111111111");
        org.apache.commons.codec.language.Metaphone metaphone14 = new org.apache.commons.codec.language.Metaphone();
        metaphone14.setMaxCodeLen(3);
        int int17 = metaphone14.getMaxCodeLen();
        boolean boolean20 = metaphone14.isMetaphoneEqual("", "");
        boolean boolean23 = metaphone14.isMetaphoneEqual("01230120022455012623010202", "");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone14, "01230120022455012623010202", "");
        java.lang.String str28 = metaphone14.metaphone("");
        boolean boolean31 = metaphone14.isMetaphoneEqual(" AKPK", "org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931");
        metaphone14.setMaxCodeLen((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = caverphone0.encode((java.lang.Object) metaphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "1111111111" + "'", str10, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test1461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1461");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        metaphone0.setMaxCodeLen((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
    }

    @Test
    public void test1462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1462");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.encode("A0931");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = 0;
        char char12 = doubleMetaphone7.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone7.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult14.append(' ');
        doubleMetaphoneResult14.appendPrimary("A621");
        doubleMetaphoneResult14.appendPrimary("A0931");
        doubleMetaphoneResult14.appendPrimary('\000');
        doubleMetaphoneResult14.append('8', '5');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = soundex4.encode((java.lang.Object) '5');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A000" + "'", str6, "A000");
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
    }

    @Test
    public void test1463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1463");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char20 = refinedSoundex18.getMappingCode('a');
        int int23 = refinedSoundex18.difference("", "hi!");
        char char25 = refinedSoundex18.getMappingCode('0');
        char char27 = refinedSoundex18.getMappingCode('a');
        java.lang.String str29 = refinedSoundex18.soundex("1111111111");
        int int32 = refinedSoundex18.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone33 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone33.maxCodeLen = '\000';
        doubleMetaphone33.setMaxCodeLen(4);
        java.lang.String str39 = doubleMetaphone33.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj40 = refinedSoundex18.encode((java.lang.Object) str39);
        java.lang.String str42 = refinedSoundex18.soundex("A0313836");
        java.lang.Object obj43 = caverphone0.encode((java.lang.Object) "A0313836");
        java.lang.String str45 = caverphone0.encode("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex46 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char48 = refinedSoundex46.getMappingCode('a');
        int int51 = refinedSoundex46.difference("", "hi!");
        char char53 = refinedSoundex46.getMappingCode('0');
        char char55 = refinedSoundex46.getMappingCode('a');
        java.lang.String str57 = refinedSoundex46.soundex("1111111111");
        java.lang.String str59 = refinedSoundex46.encode("A1");
        int int62 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex46, "", "O000");
        java.lang.String str64 = refinedSoundex46.encode("O09315383638369315893153836383693158");
        java.lang.String str66 = refinedSoundex46.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj67 = caverphone0.encode((java.lang.Object) refinedSoundex46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertNotNull(refinedSoundex18);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '0' + "'", char20 == '0');
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '\000' + "'", char25 == '\000');
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '0' + "'", char27 == '0');
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 35 + "'", int32 == 35);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "ARKP" + "'", str39, "ARKP");
        org.junit.Assert.assertEquals("'" + obj40 + "' != '" + "A0931" + "'", obj40, "A0931");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "A0" + "'", str42, "A0");
        org.junit.Assert.assertEquals("'" + obj43 + "' != '" + "A111111111" + "'", obj43, "A111111111");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "AKPKKMNSKT" + "'", str45, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex46);
        org.junit.Assert.assertTrue("'" + char48 + "' != '" + '0' + "'", char48 == '0');
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + char53 + "' != '" + '\000' + "'", char53 == '\000');
        org.junit.Assert.assertTrue("'" + char55 + "' != '" + '0' + "'", char55 == '0');
        org.junit.Assert.assertEquals("'" + str57 + "' != '" + "" + "'", str57, "");
        org.junit.Assert.assertEquals("'" + str59 + "' != '" + "A0" + "'", str59, "A0");
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertEquals("'" + str64 + "' != '" + "O0" + "'", str64, "O0");
        org.junit.Assert.assertEquals("'" + str66 + "' != '" + "O0940103030808306030830609053016080" + "'", str66, "O0940103030808306030830609053016080");
    }

    @Test
    public void test1464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1464");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        java.lang.String str10 = soundex4.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
    }

    @Test
    public void test1465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1465");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        boolean boolean6 = doubleMetaphone0.isDoubleMetaphoneEqual("O000", "A ", true);
        doubleMetaphone0.setMaxCodeLen((int) '4');
        boolean boolean12 = doubleMetaphone0.isDoubleMetaphoneEqual("ORKP", "H000", false);
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ARKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str18 = doubleMetaphone0.doubleMetaphone(" AKP1111111 ", false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKP" + "'", str18, "AKP");
    }

    @Test
    public void test1466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1466");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("A621");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char13 = refinedSoundex11.getMappingCode('a');
        int int16 = refinedSoundex11.difference("", "hi!");
        char char18 = refinedSoundex11.getMappingCode('#');
        java.lang.String str20 = refinedSoundex11.soundex("01230120022455012623010202");
        java.lang.String str22 = refinedSoundex11.encode("O");
        java.lang.String str24 = refinedSoundex11.soundex("O");
        int int27 = refinedSoundex11.difference(" ", "O620");
        int int30 = refinedSoundex11.difference("org.apache.commons.codec.EncoderException: HI", "");
        char char32 = refinedSoundex11.getMappingCode('A');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = metaphone0.encode((java.lang.Object) 'A');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertNotNull(refinedSoundex11);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O0" + "'", str22, "O0");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O0" + "'", str24, "O0");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + char32 + "' != '" + '0' + "'", char32 == '0');
    }

    @Test
    public void test1467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1467");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(0);
        int int11 = soundex0.difference("ORKP", "o");
        int int12 = soundex0.getMaxLength();
        java.lang.String str14 = soundex0.soundex("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKPor");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O621" + "'", str14, "O621");
    }

    @Test
    public void test1468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1468");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str5 = soundex1.soundex("A0313836");
        soundex1.setMaxLength(32);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A000" + "'", str5, "A000");
    }

    @Test
    public void test1469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1469");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("O093");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A313", "org.apache.commons.codec.EncoderException: ");
        java.lang.String str19 = metaphone0.metaphone("O620");
        int int20 = metaphone0.getMaxCodeLen();
        java.lang.String str22 = metaphone0.encode("O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O" + "'", str22, "O");
    }

    @Test
    public void test1470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1470");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        java.lang.String str7 = soundex1.encode("org.apache.commons.codec.EncoderException: ");
        int int8 = soundex1.getMaxLength();
        int int9 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O941" + "'", str7, "O941");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test1471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1471");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.metaphone("A0");
        java.lang.String str6 = metaphone0.encode("H");
        java.lang.String str8 = metaphone0.metaphone("hi!");
        metaphone0.setMaxCodeLen((int) 'O');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "H" + "'", str6, "H");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test1472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1472");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("HI");
        int int10 = metaphone0.getMaxCodeLen();
        java.lang.String str12 = metaphone0.metaphone("ARKPKSKMNSKTKNKTRKSPKSN");
        int int13 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H" + "'", str9, "H");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ARK" + "'", str12, "ARK");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test1473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1473");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult9 = doubleMetaphone0.new DoubleMetaphoneResult(0);
        int int10 = doubleMetaphone0.maxCodeLen;
        boolean boolean14 = doubleMetaphone0.isDoubleMetaphoneEqual("HI", "O0940103030808306030830609053016080931", false);
        doubleMetaphone0.setMaxCodeLen(100);
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: O000");
        java.lang.Object obj19 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O000");
        org.apache.commons.codec.language.Caverphone caverphone20 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str22 = caverphone20.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str24 = caverphone20.caverphone("hi!");
        java.lang.String str26 = caverphone20.caverphone("");
        int int29 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone20, "AA11111111", "hi!");
        java.lang.String str31 = caverphone20.encode("ARKP");
        java.lang.String str33 = caverphone20.caverphone("AKPKMNSKT");
        java.lang.String str35 = caverphone20.encode("AK11111111");
        java.lang.Object obj36 = doubleMetaphone0.encode((java.lang.Object) "AK11111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "ARKPXKMNSKTKNKTRKSPXN" + "'", obj19, "ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AA11111111" + "'", str24, "AA11111111");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "1111111111" + "'", str26, "1111111111");
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AKP1111111" + "'", str31, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "AKPKMNSKT1" + "'", str33, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "AK11111111" + "'", str35, "AK11111111");
        org.junit.Assert.assertEquals("'" + obj36 + "' != '" + "AK" + "'", obj36, "AK");
    }

    @Test
    public void test1474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1474");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int3 = soundex0.getMaxLength();
        soundex0.setMaxLength(10);
        java.lang.String str7 = soundex0.soundex("A621HI");
        java.lang.String str9 = soundex0.soundex("0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test1475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1475");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("ORKPXKMNSKTKNKTRKSSPXNRKP");
        java.lang.String str6 = caverphone0.caverphone(" org.apache.commons.codec.EncoderException: ORGAP");
        boolean boolean9 = caverphone0.isCaverphoneEqual("", "K000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKMNSKTK" + "'", str4, "AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "AKPKKMNSKT" + "'", str6, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test1476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1476");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str12 = metaphone10.encode("");
        java.lang.Object obj13 = metaphone0.encode((java.lang.Object) "");
        int int14 = metaphone0.getMaxCodeLen();
        int int15 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "" + "'", obj13, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test1477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1477");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) '#');
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult9 = doubleMetaphone0.new DoubleMetaphoneResult((-1));
        doubleMetaphone0.maxCodeLen = (-1);
        int int12 = doubleMetaphone0.getMaxCodeLen();
        int int13 = doubleMetaphone0.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ORGAPACHECOMMONSCODECENCODER", "A000");
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: -1");
        } catch (java.lang.NegativeArraySizeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test1478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1478");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("ARKPXKMNSKTSNKTRKSPXN");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = 0;
        char char20 = doubleMetaphone15.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean24 = doubleMetaphone15.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char27 = doubleMetaphone15.charAt("01230120022455012623010202", (int) (short) 1);
        char char30 = doubleMetaphone15.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone15.maxCodeLen = (byte) 10;
        int int35 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone15, "A", "A");
        int int36 = doubleMetaphone15.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = metaphone0.encode((java.lang.Object) doubleMetaphone15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ARK" + "'", str14, "ARK");
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '1' + "'", char27 == '1');
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + 'O' + "'", char30 == 'O');
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
    }

    @Test
    public void test1479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1479");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int9 = soundex4.difference("1111111111", "A111111111O620");
        int int10 = soundex4.getMaxLength();
        java.lang.String str12 = soundex4.encode("A062125232523621256212523252362125");
        int int13 = soundex4.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A000" + "'", str12, "A000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1480");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = 100;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "");
        int int21 = doubleMetaphone0.maxCodeLen;
        java.lang.String str23 = doubleMetaphone0.encode("A600");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A" + "'", str23, "A");
    }

    @Test
    public void test1481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1481");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str8 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        java.lang.String str10 = metaphone0.encode("A062125232523621256212523252362125");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKPXKMNSK" + "'", str8, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
    }

    @Test
    public void test1482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1482");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode(' ');
        java.lang.String str9 = refinedSoundex0.soundex("O0931538363836931589313836383693138");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O0" + "'", str9, "O0");
    }

    @Test
    public void test1483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1483");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("org.apache.commons.codec.EncoderException: O");
        soundex1.setMaxLength((int) 'i');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O941" + "'", str5, "O941");
    }

    @Test
    public void test1484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1484");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSKTSNKTRKSPKSNRKPR", "org.apache.commons.codec.EncoderException: ARK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test1485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1485");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = metaphone0.metaphone("A000");
        boolean boolean20 = metaphone0.isMetaphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTION");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone21 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone21.maxCodeLen = 0;
        char char26 = doubleMetaphone21.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str28 = doubleMetaphone21.encode("A");
        java.lang.Object obj30 = doubleMetaphone21.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone21.maxCodeLen = (byte) 1;
        boolean boolean35 = doubleMetaphone21.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = metaphone0.encode((java.lang.Object) boolean35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A" + "'", str17, "A");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '\000' + "'", char26 == '\000');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "" + "'", obj30, "");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test1486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1486");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        int int23 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((-1));
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ARKPKSKMNS" + "'", str22, "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
    }

    @Test
    public void test1487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1487");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("AKPKMNSKTS");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AKPKMNSKTS" + "'", str1, "AKPKMNSKTS");
    }

    @Test
    public void test1488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1488");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O094010303080830603083060905301608093", "ORK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test1489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1489");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode(' ');
        char char9 = refinedSoundex0.getMappingCode('o');
        char char11 = refinedSoundex0.getMappingCode(' ');
        java.lang.String str13 = refinedSoundex0.encode("A000");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '\000' + "'", char11 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0" + "'", str13, "A0");
    }

    @Test
    public void test1490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1490");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = soundex1.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKPor");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test1491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1491");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        int int10 = soundex1.difference("A02125232", "AM");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test1492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1492");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str5 = soundex3.soundex("01230120022455012623010202");
        soundex3.setMaxLength(0);
        int int8 = soundex3.getMaxLength();
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test1493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1493");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        java.lang.String str38 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str40 = caverphone0.encode("O062010202050520302052030602013050");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKKMNSKT" + "'", str38, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "A111111111" + "'", str40, "A111111111");
    }

    @Test
    public void test1494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1494");
        char[] charArray0 = new char[] {};
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        // The following exception was thrown during execution in test generation
        try {
            int int7 = soundex4.difference("K000", "RKPXKMNSKTKNKTRKSSPXNRKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertArrayEquals(charArray0, new char[] {});
    }

    @Test
    public void test1495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1495");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        char char8 = refinedSoundex6.getMappingCode('0');
        // The following exception was thrown during execution in test generation
        try {
            int int11 = refinedSoundex6.difference("org.apache.commons.codec.EncoderException: O", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
    }

    @Test
    public void test1496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1496");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        metaphone0.setMaxCodeLen((int) (short) 0);
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "A0621252", "org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test1497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1497");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("O093", "AKP1111111");
        boolean boolean19 = caverphone0.isCaverphoneEqual("A0", "H000");
        org.apache.commons.codec.language.Metaphone metaphone20 = new org.apache.commons.codec.language.Metaphone();
        metaphone20.setMaxCodeLen(3);
        int int23 = metaphone20.getMaxCodeLen();
        boolean boolean26 = metaphone20.isMetaphoneEqual("", "");
        boolean boolean29 = metaphone20.isMetaphoneEqual("01230120022455012623010202", "");
        int int32 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone20, "01230120022455012623010202", "");
        java.lang.String str34 = metaphone20.metaphone("");
        java.lang.String str36 = metaphone20.metaphone("A");
        int int37 = metaphone20.getMaxCodeLen();
        int int38 = metaphone20.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = caverphone0.encode((java.lang.Object) int38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "A" + "'", str36, "A");
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 3 + "'", int37 == 3);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
    }

    @Test
    public void test1498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1498");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str15 = caverphone0.caverphone("ORKP");
        java.lang.String str17 = caverphone0.caverphone("A031383");
        java.lang.String str19 = caverphone0.caverphone("ARKPXKMNSKTSNKTRKSPXN");
        org.apache.commons.codec.language.Metaphone metaphone20 = new org.apache.commons.codec.language.Metaphone();
        metaphone20.setMaxCodeLen(3);
        int int23 = metaphone20.getMaxCodeLen();
        int int24 = metaphone20.getMaxCodeLen();
        metaphone20.setMaxCodeLen((int) (short) 10);
        metaphone20.setMaxCodeLen(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = caverphone0.encode((java.lang.Object) metaphone20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKP1111111" + "'", str15, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSKTS" + "'", str19, "AKPKMNSKTS");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
    }

    @Test
    public void test1499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1499");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str13 = caverphone0.encode("AKP1111111");
        java.lang.String str15 = caverphone0.encode("AKPKSKMNS");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKP1111111" + "'", str13, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKSKMNS1" + "'", str15, "AKPKSKMNS1");
    }

    @Test
    public void test1500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1500");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex2.setMaxLength((int) '1');
        int int7 = soundex2.difference("A0", "H");
        java.lang.String str9 = soundex2.encode("org.apache.commons.codec.EncoderException: ARK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O941" + "'", str9, "O941");
    }
}

