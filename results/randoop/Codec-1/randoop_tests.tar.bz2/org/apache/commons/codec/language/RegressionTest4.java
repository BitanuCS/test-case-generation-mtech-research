package org.apache.commons.codec.language;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test2001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2001");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        java.lang.String str10 = doubleMetaphone6.doubleMetaphone("HI");
        java.lang.String str12 = doubleMetaphone6.encode("O621");
        java.lang.Object obj13 = refinedSoundex0.encode((java.lang.Object) "O621");
        java.lang.String str15 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: Aa");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "H" + "'", str10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "O0" + "'", obj13, "O0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0940103030808306030830609053016080" + "'", str15, "O0940103030808306030830609053016080");
    }

    @Test
    public void test2002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2002");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: hi!", "AKP");
        soundex1.setMaxLength((int) '#');
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "A621", "AKPK");
        int int11 = soundex1.getMaxLength();
        java.lang.String str13 = soundex1.soundex("A031383");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A000" + "'", str13, "A000");
    }

    @Test
    public void test2003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2003");
        char[] charArray0 = new char[] {};
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = refinedSoundex2.encode("AK11111111");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertArrayEquals(charArray0, new char[] {});
    }

    @Test
    public void test2004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2004");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        char char7 = doubleMetaphone0.charAt("hi!", 1);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A621", "H");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str13 = doubleMetaphone0.encode("A621HI0A093138363836931589313836383693158M5");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'i' + "'", char7 == 'i');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
    }

    @Test
    public void test2005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2005");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex5, "", "A313");
        char char17 = refinedSoundex5.getMappingCode('A');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str19 = refinedSoundex5.encode("org.apache.commons.codec.EncoderException: O0");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + ' ' + "'", char17 == ' ');
    }

    @Test
    public void test2006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2006");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "O0931");
        java.lang.String str7 = soundex2.soundex("");
        soundex2.setMaxLength(38);
        soundex2.setMaxLength((-1));
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test2007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2007");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("");
        boolean boolean11 = metaphone0.isMetaphoneEqual("AKPK", "");
        java.lang.String str13 = metaphone0.metaphone("AK");
        java.lang.String str15 = metaphone0.encode("RKPKSKMNSKTKNKTRKSPKSNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AK" + "'", str13, "AK");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "RKPK" + "'", str15, "RKPK");
    }

    @Test
    public void test2008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2008");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean7 = caverphone0.isCaverphoneEqual("O", "01230120022455012623010202");
        java.lang.String str9 = caverphone0.encode("  ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "1111111111" + "'", str9, "1111111111");
    }

    @Test
    public void test2009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2009");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode(' ');
        char char9 = refinedSoundex0.getMappingCode('o');
        int int12 = refinedSoundex0.difference("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "org.apache.commons.codec.EncoderException: ARKP");
        int int15 = refinedSoundex0.difference("O620ORGAPACHECOMMONSCODECENCODER", "org.apache.commons.codec.EncoderException: A111111111O620");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 26 + "'", int15 == 26);
    }

    @Test
    public void test2010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2010");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        java.lang.String str18 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A ");
        java.lang.String str20 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        java.lang.String str22 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0940103030808306030830609053016080" + "'", str18, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O0940103030808306030830609053016080313836" + "'", str20, "O0940103030808306030830609053016080313836");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O0" + "'", str22, "O0");
    }

    @Test
    public void test2011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2011");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("");
        java.lang.String str9 = soundex0.encode("9");
        java.lang.Object obj11 = soundex0.encode((java.lang.Object) "ORKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + obj11 + "' != '" + "O621" + "'", obj11, "O621");
    }

    @Test
    public void test2012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2012");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        metaphone0.setMaxCodeLen(0);
        metaphone0.setMaxCodeLen((int) 'i');
        java.lang.String str12 = metaphone0.encode("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test2013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2013");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        java.lang.String str6 = metaphone0.metaphone("A1");
        java.lang.Class<?> wildcardClass7 = metaphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test2014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2014");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex4.setMaxLength((int) (short) 0);
        soundex4.setMaxLength((int) (short) -1);
        java.lang.String str10 = soundex4.soundex("A031383");
        soundex4.setMaxLength((int) '6');
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
    }

    @Test
    public void test2015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2015");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str13 = caverphone0.encode("AKP1111111");
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str16 = soundex14.encode("ARKP");
        java.lang.String str18 = soundex14.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj20 = soundex14.encode((java.lang.Object) "ORK");
        soundex14.setMaxLength(4);
        java.lang.String str24 = soundex14.soundex("A0313836");
        java.lang.Object obj25 = caverphone0.encode((java.lang.Object) str24);
        int int28 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, " O620", "O0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone29 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str31 = doubleMetaphone29.doubleMetaphone("H");
        doubleMetaphone29.setMaxCodeLen((int) (byte) 0);
        java.lang.String str36 = doubleMetaphone29.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult38 = doubleMetaphone29.new DoubleMetaphoneResult(0);
        java.lang.String str39 = doubleMetaphoneResult38.getPrimary();
        doubleMetaphoneResult38.append('1', 'a');
        doubleMetaphoneResult38.appendPrimary("ARKPXKMNSKTKNKTRKS");
        doubleMetaphoneResult38.append('T');
        doubleMetaphoneResult38.append('e', 'c');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj50 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKP1111111" + "'", str13, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A621" + "'", str16, "A621");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O621" + "'", str18, "O621");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "O620" + "'", obj20, "O620");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A000" + "'", str24, "A000");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "A111111111" + "'", obj25, "A111111111");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "" + "'", str39, "");
    }

    @Test
    public void test2016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2016");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        java.lang.String str23 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        int int24 = metaphone0.getMaxCodeLen();
        boolean boolean27 = metaphone0.isMetaphoneEqual("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN", "A0621252");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str23, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test2017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2017");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = 100;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "");
        doubleMetaphone0.maxCodeLen = 0;
        doubleMetaphone0.setMaxCodeLen(0);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test2018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2018");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int6 = soundex5.getMaxLength();
        int int9 = soundex5.difference("", "A931");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test2019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2019");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        boolean boolean10 = metaphone0.isMetaphoneEqual("K120", " ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test2020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2020");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int4 = soundex1.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "hi!");
        soundex1.setMaxLength(100);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = 0;
        char char12 = doubleMetaphone7.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone7.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult14.appendAlternate("A111111111");
        doubleMetaphoneResult14.append("O620");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = soundex1.encode((java.lang.Object) doubleMetaphoneResult14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
    }

    @Test
    public void test2021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2021");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O0931");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "A621");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = '\000';
        char char13 = doubleMetaphone8.charAt("", 0);
        boolean boolean17 = doubleMetaphone8.isDoubleMetaphoneEqual("A111111111", "A", false);
        java.lang.Object obj18 = caverphone0.encode((java.lang.Object) "A");
        java.lang.String str20 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTION");
        boolean boolean23 = caverphone0.isCaverphoneEqual("A", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertEquals("'" + obj18 + "' != '" + "A111111111" + "'", obj18, "A111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test2022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2022");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        java.lang.String str13 = metaphone0.encode("hi!");
        int int14 = metaphone0.getMaxCodeLen();
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "AKPKMNSKT");
        metaphone0.setMaxCodeLen(52);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test2023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2023");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) ' ');
        boolean boolean7 = metaphone0.isMetaphoneEqual("A09315383", "org.apache.commons.codec.EncoderException: A111111111O620");
        java.lang.String str9 = metaphone0.encode("A093153836383693158313");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
    }

    @Test
    public void test2024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2024");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTKNKTRKSSPXNH", "org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2025");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str6 = doubleMetaphone0.encode("H");
        java.lang.String str8 = doubleMetaphone0.encode("");
        int int11 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ORKPXKMNSKTSNKTRKSSPXN", "4");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test2026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2026");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        int int10 = metaphone0.getMaxCodeLen();
        boolean boolean13 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "");
        boolean boolean16 = metaphone0.isMetaphoneEqual("o", "org.apache.commons.codec.EncoderException: A ");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2027");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int4 = refinedSoundex1.difference("ORKPXKMNSK", " org.apache.commons.codec.EncoderException: ORGAP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
    }

    @Test
    public void test2028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2028");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int3 = soundex2.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone4 = new org.apache.commons.codec.language.Metaphone();
        metaphone4.setMaxCodeLen(3);
        java.lang.String str8 = metaphone4.encode("");
        java.lang.String str10 = metaphone4.encode("");
        metaphone4.setMaxCodeLen((int) (short) 10);
        int int13 = metaphone4.getMaxCodeLen();
        java.lang.String str15 = metaphone4.encode("ORKP");
        int int16 = metaphone4.getMaxCodeLen();
        int int17 = metaphone4.getMaxCodeLen();
        int int18 = metaphone4.getMaxCodeLen();
        boolean boolean21 = metaphone4.isMetaphoneEqual("AKPKMNSKT", "AKPKMNSKT");
        java.lang.Object obj22 = soundex2.encode((java.lang.Object) "AKPKMNSKT");
        soundex2.setMaxLength((int) (short) 10);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex2, "ARKPXKMNSKTKNKTRKSPXNKPK", "AKPKMNSKTK");
        java.lang.Object obj28 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = soundex2.encode(obj28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKP" + "'", str15, "ORKP");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A313" + "'", obj22, "A313");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test2029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2029");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = 0;
        char char12 = doubleMetaphone7.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str14 = doubleMetaphone7.encode("A");
        java.lang.Object obj16 = doubleMetaphone7.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone7.maxCodeLen = (byte) 1;
        char char21 = doubleMetaphone7.charAt("", (int) (short) -1);
        java.lang.String str23 = doubleMetaphone7.encode("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.Object obj24 = soundex1.encode((java.lang.Object) str23);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + obj16 + "' != '" + "" + "'", obj16, "");
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A" + "'", str23, "A");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "A000" + "'", obj24, "A000");
    }

    @Test
    public void test2030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2030");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int5 = soundex0.difference("A0", "");
        java.lang.String str7 = soundex0.soundex("");
        int int10 = soundex0.difference("O09315383638369315893153836383693158", "ORKPXKMNSKTKNKTRKSSPXN");
        java.lang.String str12 = soundex0.soundex("A093153836383693158");
        java.lang.String str14 = soundex0.soundex("ORKPXKMNSK");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A000" + "'", str12, "A000");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O621" + "'", str14, "O621");
    }

    @Test
    public void test2031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2031");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        int int28 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "", "");
        java.lang.String str30 = caverphone0.caverphone("AK11111111");
        boolean boolean33 = caverphone0.isCaverphoneEqual("", "O621");
        java.lang.String str35 = caverphone0.encode("RKPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AK11111111" + "'", str30, "AK11111111");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "KPK1111111" + "'", str35, "KPK1111111");
    }

    @Test
    public void test2032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2032");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        int int17 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(0);
        boolean boolean22 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: A#", "org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        boolean boolean25 = metaphone0.isMetaphoneEqual("O941", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean28 = metaphone0.isMetaphoneEqual("ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKT", "A0O");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test2033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2033");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        metaphone0.setMaxCodeLen((int) (short) 0);
        metaphone0.setMaxCodeLen((int) 'H');
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A0");
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("O0");
        encoderException13.addSuppressed((java.lang.Throwable) encoderException15);
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Throwable[] throwableArray19 = encoderException18.getSuppressed();
        java.lang.Throwable[] throwableArray20 = encoderException18.getSuppressed();
        encoderException15.addSuppressed((java.lang.Throwable) encoderException18);
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException25 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray26 = encoderException25.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException28 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException25.addSuppressed((java.lang.Throwable) encoderException28);
        org.apache.commons.codec.EncoderException encoderException31 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray32 = encoderException31.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException34 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException36 = new org.apache.commons.codec.EncoderException("");
        encoderException34.addSuppressed((java.lang.Throwable) encoderException36);
        encoderException31.addSuppressed((java.lang.Throwable) encoderException36);
        org.apache.commons.codec.EncoderException encoderException40 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        encoderException36.addSuppressed((java.lang.Throwable) encoderException40);
        encoderException25.addSuppressed((java.lang.Throwable) encoderException40);
        java.lang.Throwable[] throwableArray43 = encoderException40.getSuppressed();
        encoderException23.addSuppressed((java.lang.Throwable) encoderException40);
        encoderException18.addSuppressed((java.lang.Throwable) encoderException23);
        org.apache.commons.codec.EncoderException encoderException47 = new org.apache.commons.codec.EncoderException("O0940103030808306030830609053016080931");
        encoderException23.addSuppressed((java.lang.Throwable) encoderException47);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj49 = metaphone0.encode((java.lang.Object) encoderException47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertArrayEquals(throwableArray19, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertArrayEquals(throwableArray20, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertArrayEquals(throwableArray26, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertArrayEquals(throwableArray32, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertArrayEquals(throwableArray43, new java.lang.Throwable[] {});
    }

    @Test
    public void test2034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2034");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str7 = soundex1.encode("AA11111111");
        java.lang.String str9 = soundex1.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str11 = soundex1.encode("AO");
        int int12 = soundex1.getMaxLength();
        java.lang.String str14 = soundex1.soundex("AKPKMNSKT");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A000" + "'", str11, "A000");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A212" + "'", str14, "A212");
    }

    @Test
    public void test2035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2035");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        int int4 = soundex1.getMaxLength();
        soundex1.setMaxLength(0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test2036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2036");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        java.lang.String str38 = caverphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        boolean boolean41 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA", "O931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKMNSKTK" + "'", str38, "AKPKMNSKTK");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test2037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2037");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        metaphone0.setMaxCodeLen(19);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = new org.apache.commons.codec.language.RefinedSoundex();
        char char15 = refinedSoundex13.getMappingCode('0');
        int int18 = refinedSoundex13.difference("O0", "O0");
        int int21 = refinedSoundex13.difference("i0a", "org.apache.commons.codec.EncoderException: A0");
        int int24 = refinedSoundex13.difference("O0931538363836931589313836383693138", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = metaphone0.encode((java.lang.Object) refinedSoundex13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
    }

    @Test
    public void test2038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2038");
        char[] charArray6 = new char[] { 'r', '1', ' ', 'i', '#', '#' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        java.lang.String str11 = refinedSoundex9.encode("A09315383");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = refinedSoundex9.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAO");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertArrayEquals(charArray6, new char[] { 'r', '1', ' ', 'i', '#', '#' });
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "Ar" + "'", str11, "Ar");
    }

    @Test
    public void test2039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2039");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("");
        java.lang.String str29 = caverphone0.encode("A#");
        java.lang.String str31 = caverphone0.encode("ARKPKSKMNS");
        java.lang.String[] strArray51 = new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" };
        boolean boolean52 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 1, (int) (short) 1, strArray51);
        boolean boolean53 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 10, (int) '#', strArray51);
        boolean boolean54 = org.apache.commons.codec.language.DoubleMetaphone.contains("O621", (int) (byte) 0, (int) (short) 10, strArray51);
        boolean boolean55 = org.apache.commons.codec.language.DoubleMetaphone.contains("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", 0, (int) (byte) 0, strArray51);
        boolean boolean56 = org.apache.commons.codec.language.DoubleMetaphone.contains("HI", (int) 'a', 38, strArray51);
        boolean boolean57 = org.apache.commons.codec.language.DoubleMetaphone.contains("org.apache.commons.codec.EncoderException: i0a", (int) 'e', 35, strArray51);
        java.lang.Object obj58 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: i0a");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "1111111111" + "'", str27, "1111111111");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AKPKSKMNS1" + "'", str31, "AKPKSKMNS1");
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertArrayEquals(strArray51, new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" });
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertEquals("'" + obj58 + "' != '" + "AKPKKMNSKT" + "'", obj58, "AKPKKMNSKT");
    }

    @Test
    public void test2040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2040");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int6 = soundex0.getMaxLength();
        soundex0.setMaxLength((int) 'r');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test2041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2041");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        soundex1.setMaxLength(0);
        int int14 = soundex1.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ");
        java.lang.String str16 = soundex1.encode("A111111111O620");
        java.lang.String str18 = soundex1.encode("org.apache.commons.codec.EncoderException: A ");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A000" + "'", str16, "A000");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O941" + "'", str18, "O941");
    }

    @Test
    public void test2042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2042");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str6 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int9 = refinedSoundex0.difference("KP", "K120");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080" + "'", str4, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O0" + "'", str6, "O0");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test2043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2043");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean22 = caverphone0.isCaverphoneEqual("A#", "AKP1111111");
        java.lang.String str24 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        boolean boolean27 = caverphone0.isCaverphoneEqual("ORK", "");
        java.lang.String str29 = caverphone0.caverphone("A09315383");
        boolean boolean32 = caverphone0.isCaverphoneEqual("ARKPKSKMNS", "0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test2044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2044");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("ARKPKSKMNS");
        boolean boolean11 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: AKPKKMNSKT", "");
        java.lang.String str13 = caverphone0.encode("01");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKSKMNS1" + "'", str8, "AKPKSKMNS1");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
    }

    @Test
    public void test2045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2045");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone0.maxCodeLen = '0';
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("A", true);
        boolean boolean12 = doubleMetaphone0.isDoubleMetaphoneEqual("A0", "");
        boolean boolean15 = doubleMetaphone0.isDoubleMetaphoneEqual("A ", "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone0.setMaxCodeLen((int) 'A');
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ARK", "A ");
        doubleMetaphone0.setMaxCodeLen((int) '#');
        int int23 = doubleMetaphone0.getMaxCodeLen();
        doubleMetaphone0.setMaxCodeLen(65);
        doubleMetaphone0.setMaxCodeLen(0);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 35 + "'", int23 == 35);
    }

    @Test
    public void test2046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2046");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("KPK", "K31");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test2047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2047");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.soundex("ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str7 = refinedSoundex0.encode("A212");
        int int10 = refinedSoundex0.difference("a", "A621HI");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A093153836383693158" + "'", str5, "A093153836383693158");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A0" + "'", str7, "A0");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test2048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2048");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength((int) 'T');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test2049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2049");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex4.getMaxLength();
        int int8 = soundex4.difference("AHIO", "org.apache.commons.codec.EncoderException: A111111111O620");
        java.lang.String str10 = soundex4.soundex("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O621" + "'", str10, "O621");
    }

    @Test
    public void test2050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2050");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex3.setMaxLength(1);
        int int8 = soundex3.difference("O", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = soundex3.encode("O620");
        java.lang.String str12 = soundex3.encode("ARKPXKMNSKTKNKTRKSPXN");
        java.lang.Class<?> wildcardClass13 = soundex3.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A621" + "'", str12, "A621");
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test2051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2051");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.String str32 = caverphone0.caverphone("ORKP");
        java.lang.String str34 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAO");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKP1111111" + "'", str32, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPKKMNSKT" + "'", str34, "AKPKKMNSKT");
    }

    @Test
    public void test2052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2052");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str30 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        boolean boolean33 = caverphone0.isCaverphoneEqual("", "A09315383");
        org.apache.commons.codec.language.Caverphone caverphone34 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str36 = caverphone34.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str38 = caverphone34.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str40 = caverphone34.encode("");
        java.lang.String str42 = caverphone34.encode("01230120022455012623010202");
        java.lang.String str44 = caverphone34.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str46 = caverphone34.caverphone("O941");
        java.lang.String str48 = caverphone34.encode("AKPKMNSK");
        java.lang.String str50 = caverphone34.caverphone("4");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj51 = caverphone0.encode((java.lang.Object) caverphone34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKKMNSKT" + "'", str30, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "AKPKKMNSKT" + "'", str36, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKKMNSKT" + "'", str38, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "1111111111" + "'", str40, "1111111111");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "1111111111" + "'", str42, "1111111111");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "AKPKKMNSKT" + "'", str44, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "A111111111" + "'", str46, "A111111111");
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "AKPKMNSK11" + "'", str48, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "1111111111" + "'", str50, "1111111111");
    }

    @Test
    public void test2053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2053");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean10 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        java.lang.String str12 = metaphone0.metaphone("A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str15 = doubleMetaphone13.doubleMetaphone("H");
        java.lang.String str17 = doubleMetaphone13.doubleMetaphone("");
        java.lang.String str20 = doubleMetaphone13.doubleMetaphone("ORKP", true);
        java.lang.String str23 = doubleMetaphone13.doubleMetaphone("", false);
        java.lang.String str25 = doubleMetaphone13.encode("");
        doubleMetaphone13.setMaxCodeLen(10);
        java.lang.String str29 = doubleMetaphone13.doubleMetaphone("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult31 = doubleMetaphone13.new DoubleMetaphoneResult(2);
        doubleMetaphone13.maxCodeLen = 0;
        java.lang.String str35 = doubleMetaphone13.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int36 = doubleMetaphone13.maxCodeLen;
        java.lang.String str39 = doubleMetaphone13.doubleMetaphone("A0931383", true);
        int int40 = doubleMetaphone13.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj41 = metaphone0.encode((java.lang.Object) int40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "ARKP" + "'", str20, "ARKP");
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "" + "'", str39, "");
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test2054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2054");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("A0931");
        java.lang.String str26 = refinedSoundex0.soundex("K120");
        java.lang.String str28 = refinedSoundex0.encode("O0940103030808306030830609");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A0" + "'", str24, "A0");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "K3" + "'", str26, "K3");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "O0" + "'", str28, "O0");
    }

    @Test
    public void test2055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2055");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        java.lang.String str14 = soundex1.soundex("A");
        soundex1.setMaxLength((int) 'H');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A000" + "'", str14, "A000");
    }

    @Test
    public void test2056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2056");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str7 = soundex2.encode("AKPKKMNSKT");
        java.lang.String str9 = soundex2.encode("");
        soundex2.setMaxLength((int) 'o');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = '\000';
        doubleMetaphone12.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone12.new DoubleMetaphoneResult((int) '1');
        java.lang.String str19 = doubleMetaphoneResult18.getPrimary();
        doubleMetaphoneResult18.appendAlternate("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        doubleMetaphoneResult18.appendAlternate('8');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = soundex2.encode((java.lang.Object) doubleMetaphoneResult18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A313" + "'", str7, "A313");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
    }

    @Test
    public void test2057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2057");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("AA11111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean21 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char24 = doubleMetaphone12.charAt("01230120022455012623010202", (int) (short) 1);
        char char27 = doubleMetaphone12.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone12.maxCodeLen = (byte) 10;
        boolean boolean32 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0940103030808306030830609053016080");
        int int33 = doubleMetaphone12.getMaxCodeLen();
        java.lang.String str35 = doubleMetaphone12.encode("org.apache.commons.codec.EncoderException: HI");
        int int38 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone12, "org.apache.commons.codec.EncoderException: ORKP", "hi!");
        java.lang.Object obj39 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean42 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: AKPKKMNSKT", "A093153836383693");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AA11111111" + "'", str11, "AA11111111");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '1' + "'", char24 == '1');
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + 'O' + "'", char27 == 'O');
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "ARKPXKMNSK" + "'", str35, "ARKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertEquals("'" + obj39 + "' != '" + "AA11111111" + "'", obj39, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test2058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2058");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str5 = soundex1.soundex("A0313836");
        java.lang.String str7 = soundex1.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
        char[] charArray8 = new char[] {};
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = soundex1.encode((java.lang.Object) charArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A000" + "'", str5, "A000");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O621" + "'", str7, "O621");
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertArrayEquals(charArray8, new char[] {});
    }

    @Test
    public void test2059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2059");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "A02125232", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test2060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2060");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("O000");
        java.lang.String str5 = soundex1.encode("A0313836");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "O000" + "'", str3, "O000");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A000" + "'", str5, "A000");
    }

    @Test
    public void test2061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2061");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AKPKMNSK11");
        org.apache.commons.codec.language.Caverphone caverphone31 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str33 = caverphone31.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str35 = caverphone31.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str37 = caverphone31.encode("");
        java.lang.String str39 = caverphone31.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone40 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone40.maxCodeLen = 0;
        char char45 = doubleMetaphone40.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult47 = doubleMetaphone40.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult47.appendAlternate('\000');
        java.lang.String str50 = doubleMetaphoneResult47.getAlternate();
        java.lang.String str51 = doubleMetaphoneResult47.getPrimary();
        java.lang.Object obj52 = caverphone31.encode((java.lang.Object) str51);
        java.lang.String str54 = caverphone31.caverphone("");
        int int57 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone31, "AKPKKMNSKT", "ORKP");
        boolean boolean60 = caverphone31.isCaverphoneEqual("", "HI");
        boolean boolean63 = caverphone31.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str65 = caverphone31.encode("A0");
        java.lang.Object obj66 = caverphone0.encode((java.lang.Object) str65);
        java.lang.String str68 = caverphone0.caverphone("");
        boolean boolean71 = caverphone0.isCaverphoneEqual("AKP1111111", "org.apache.commons.codec.EncoderException: A093153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKMNSK11" + "'", str30, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "AKPKKMNSKT" + "'", str33, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "AKPKKMNSKT" + "'", str35, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "1111111111" + "'", str37, "1111111111");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "1111111111" + "'", str39, "1111111111");
        org.junit.Assert.assertTrue("'" + char45 + "' != '" + '\000' + "'", char45 == '\000');
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "" + "'", str50, "");
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
        org.junit.Assert.assertEquals("'" + obj52 + "' != '" + "1111111111" + "'", obj52, "1111111111");
        org.junit.Assert.assertEquals("'" + str54 + "' != '" + "1111111111" + "'", str54, "1111111111");
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertEquals("'" + str65 + "' != '" + "A111111111" + "'", str65, "A111111111");
        org.junit.Assert.assertEquals("'" + obj66 + "' != '" + "A111111111" + "'", obj66, "A111111111");
        org.junit.Assert.assertEquals("'" + str68 + "' != '" + "1111111111" + "'", str68, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test2062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2062");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        boolean boolean16 = caverphone0.isCaverphoneEqual("hi!", "ORKP");
        java.lang.String str18 = caverphone0.encode("AKPKMNSKT1");
        java.lang.String str20 = caverphone0.encode("i0a");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKMNSKT1" + "'", str18, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AA11111111" + "'", str20, "AA11111111");
    }

    @Test
    public void test2063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2063");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        int int16 = refinedSoundex0.difference("A000", "01230120022455012623010202");
        int int19 = refinedSoundex0.difference("AKPK", "AKP1111111");
        int int22 = refinedSoundex0.difference("H000", "ORKPXKMNSKTKNKTRKSSPXNH");
        java.lang.String str24 = refinedSoundex0.soundex("A000a");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A0" + "'", str24, "A0");
    }

    @Test
    public void test2064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2064");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str30 = doubleMetaphone28.doubleMetaphone("H");
        java.lang.String str32 = doubleMetaphone28.doubleMetaphone("HI");
        java.lang.String str34 = doubleMetaphone28.doubleMetaphone("AKPKMNSKT1");
        java.lang.Object obj35 = metaphone0.encode((java.lang.Object) str34);
        java.lang.String str37 = metaphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPK" + "'", str34, "AKPK");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "AKPK" + "'", obj35, "AKPK");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "ORKPKSKMNSKTKNKTRKSPKSNRKP" + "'", str37, "ORKPKSKMNSKTKNKTRKSPKSNRKP");
    }

    @Test
    public void test2065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2065");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex12 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char14 = refinedSoundex12.getMappingCode('a');
        int int17 = refinedSoundex12.difference("", "hi!");
        char char19 = refinedSoundex12.getMappingCode('#');
        java.lang.String str21 = refinedSoundex12.soundex("01230120022455012623010202");
        java.lang.String str23 = refinedSoundex12.encode("A621");
        java.lang.String str25 = refinedSoundex12.encode("O000");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = caverphone0.encode((java.lang.Object) refinedSoundex12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex12);
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '0' + "'", char14 == '0');
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A0" + "'", str23, "A0");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "O0" + "'", str25, "O0");
    }

    @Test
    public void test2066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2066");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = 100;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "");
        doubleMetaphone0.maxCodeLen = 0;
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult24 = doubleMetaphone0.new DoubleMetaphoneResult((int) 'S');
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test2067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2067");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode('0');
        java.lang.String str9 = refinedSoundex0.encode("A031383");
        char char11 = refinedSoundex0.getMappingCode('a');
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A0");
        java.lang.Throwable[] throwableArray14 = encoderException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = encoderException13.getSuppressed();
        java.lang.Throwable[] throwableArray16 = encoderException13.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException20 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray21 = encoderException20.getSuppressed();
        encoderException18.addSuppressed((java.lang.Throwable) encoderException20);
        org.apache.commons.codec.EncoderException encoderException24 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: A0");
        encoderException20.addSuppressed((java.lang.Throwable) encoderException24);
        org.apache.commons.codec.EncoderException encoderException27 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException29 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray30 = encoderException29.getSuppressed();
        encoderException27.addSuppressed((java.lang.Throwable) encoderException29);
        org.apache.commons.codec.EncoderException encoderException33 = new org.apache.commons.codec.EncoderException("A ");
        encoderException29.addSuppressed((java.lang.Throwable) encoderException33);
        org.apache.commons.codec.EncoderException encoderException36 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException38 = new org.apache.commons.codec.EncoderException("");
        encoderException36.addSuppressed((java.lang.Throwable) encoderException38);
        org.apache.commons.codec.EncoderException encoderException41 = new org.apache.commons.codec.EncoderException("hi!");
        encoderException38.addSuppressed((java.lang.Throwable) encoderException41);
        encoderException29.addSuppressed((java.lang.Throwable) encoderException41);
        encoderException24.addSuppressed((java.lang.Throwable) encoderException41);
        encoderException13.addSuppressed((java.lang.Throwable) encoderException41);
        java.lang.Throwable[] throwableArray46 = encoderException41.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException48 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        encoderException41.addSuppressed((java.lang.Throwable) encoderException48);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj50 = refinedSoundex0.encode((java.lang.Object) encoderException41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A0" + "'", str9, "A0");
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '0' + "'", char11 == '0');
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertArrayEquals(throwableArray14, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertArrayEquals(throwableArray15, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertArrayEquals(throwableArray16, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertArrayEquals(throwableArray21, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertArrayEquals(throwableArray30, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertArrayEquals(throwableArray46, new java.lang.Throwable[] {});
    }

    @Test
    public void test2068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2068");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O0940103030808306030830609053016080", "AKPKMNSK11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2069");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AKPKMNSK11");
        boolean boolean33 = caverphone0.isCaverphoneEqual("O062010202050520302052030602013050", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKMNSK11" + "'", str30, "AKPKMNSK11");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test2070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2070");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str15 = caverphone0.caverphone("");
        java.lang.String str17 = caverphone0.caverphone("O0620102020505203020520306020130506212520");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
    }

    @Test
    public void test2071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2071");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) 'a');
        metaphone0.setMaxCodeLen(0);
        boolean boolean15 = metaphone0.isMetaphoneEqual("ARKPXKMNSKTKNKTRKSPXN", "A1111111114r");
        java.lang.String str17 = metaphone0.metaphone("A000");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone18.maxCodeLen = '\000';
        char char23 = doubleMetaphone18.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult25 = doubleMetaphone18.new DoubleMetaphoneResult((int) ' ');
        java.lang.String str26 = doubleMetaphoneResult25.getPrimary();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = metaphone0.encode((java.lang.Object) doubleMetaphoneResult25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
    }

    @Test
    public void test2072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2072");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.doubleMetaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str15 = doubleMetaphone0.doubleMetaphone("ORK", false);
        int int16 = doubleMetaphone0.getMaxCodeLen();
        doubleMetaphone0.maxCodeLen = 10;
        int int21 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "org.apache.commons.codec.EncoderException: O000", "");
        java.lang.String str23 = doubleMetaphone0.doubleMetaphone("org.apache.commons.codec.EncoderException: A093153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ARKP" + "'", str12, "ARKP");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ARK" + "'", str15, "ARK");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ARKPXKMNSK" + "'", str23, "ARKPXKMNSK");
    }

    @Test
    public void test2073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2073");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        boolean boolean17 = metaphone0.isMetaphoneEqual("AKPKMNSK11", "");
        boolean boolean20 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSK", "A1");
        java.lang.String str22 = metaphone0.metaphone("");
        org.apache.commons.codec.language.Caverphone caverphone23 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str25 = caverphone23.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str27 = caverphone23.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str29 = caverphone23.encode("");
        java.lang.String str31 = caverphone23.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone32 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone32.maxCodeLen = 0;
        char char37 = doubleMetaphone32.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult39 = doubleMetaphone32.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult39.appendAlternate('\000');
        java.lang.String str42 = doubleMetaphoneResult39.getAlternate();
        java.lang.String str43 = doubleMetaphoneResult39.getPrimary();
        java.lang.Object obj44 = caverphone23.encode((java.lang.Object) str43);
        java.lang.String str46 = caverphone23.caverphone("");
        java.lang.String str48 = caverphone23.encode("");
        java.lang.String str50 = caverphone23.encode("9");
        java.lang.Object obj51 = metaphone0.encode((java.lang.Object) str50);
        java.lang.String str53 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSNi");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "AKPKKMNSKT" + "'", str25, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "AKPKKMNSKT" + "'", str27, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "1111111111" + "'", str29, "1111111111");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "1111111111" + "'", str31, "1111111111");
        org.junit.Assert.assertTrue("'" + char37 + "' != '" + '\000' + "'", char37 == '\000');
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "" + "'", str43, "");
        org.junit.Assert.assertEquals("'" + obj44 + "' != '" + "1111111111" + "'", obj44, "1111111111");
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "1111111111" + "'", str46, "1111111111");
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "1111111111" + "'", str48, "1111111111");
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "1111111111" + "'", str50, "1111111111");
        org.junit.Assert.assertEquals("'" + obj51 + "' != '" + "" + "'", obj51, "");
        org.junit.Assert.assertEquals("'" + str53 + "' != '" + "ORK" + "'", str53, "ORK");
    }

    @Test
    public void test2074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2074");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        char char4 = refinedSoundex2.getMappingCode('H');
        int int7 = refinedSoundex2.difference("org.apache.commons.codec.EncoderException: A0931383", "OA1111111114r");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = '\000';
        char char13 = doubleMetaphone8.charAt("", 0);
        java.lang.String str15 = doubleMetaphone8.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = doubleMetaphone8.doubleMetaphone("");
        java.lang.String str19 = doubleMetaphone8.encode("O0");
        char char22 = doubleMetaphone8.charAt("O0940103030808306030830609053016080931", 0);
        java.lang.String str24 = doubleMetaphone8.encode("");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult26 = doubleMetaphone8.new DoubleMetaphoneResult((int) 'O');
        doubleMetaphoneResult26.append('4', '1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = refinedSoundex2.encode((java.lang.Object) '1');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char4 + "' != '" + '0' + "'", char4 == '0');
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + 'O' + "'", char22 == 'O');
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test2075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2075");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str8 = refinedSoundex6.soundex(" org.apache.commons.codec.EncoderException: ORGAP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O0620102020505203020520306020130506201" + "'", str8, "O0620102020505203020520306020130506201");
    }

    @Test
    public void test2076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2076");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('i');
        int int10 = refinedSoundex0.difference("A111111111", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test2077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2077");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.encode("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        boolean boolean16 = caverphone0.isCaverphoneEqual("A111111111e", "KPK1111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKTK" + "'", str13, "AKPKMNSKTK");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2078");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        java.lang.String str9 = metaphone0.metaphone("A111111111");
        metaphone0.setMaxCodeLen(52);
        java.lang.String str13 = metaphone0.encode("O");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O" + "'", str13, "O");
    }

    @Test
    public void test2079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2079");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        boolean boolean7 = metaphone0.isMetaphoneEqual("i0a", "  ");
        boolean boolean10 = metaphone0.isMetaphoneEqual("O620ORGAPACHECOMMONSCODECENCODER", "ARKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test2080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2080");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int3 = soundex2.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone4 = new org.apache.commons.codec.language.Metaphone();
        metaphone4.setMaxCodeLen(3);
        java.lang.String str8 = metaphone4.encode("");
        java.lang.String str10 = metaphone4.encode("");
        metaphone4.setMaxCodeLen((int) (short) 10);
        int int13 = metaphone4.getMaxCodeLen();
        java.lang.String str15 = metaphone4.encode("ORKP");
        int int16 = metaphone4.getMaxCodeLen();
        int int17 = metaphone4.getMaxCodeLen();
        int int18 = metaphone4.getMaxCodeLen();
        boolean boolean21 = metaphone4.isMetaphoneEqual("AKPKMNSKT", "AKPKMNSKT");
        java.lang.Object obj22 = soundex2.encode((java.lang.Object) "AKPKMNSKT");
        soundex2.setMaxLength((int) (short) 10);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex2, "ARKPXKMNSKTKNKTRKSPXNKPK", "AKPKMNSKTK");
        soundex2.setMaxLength((int) (byte) 100);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKP" + "'", str15, "ORKP");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A313" + "'", obj22, "A313");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test2081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2081");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A ", "O0940103030808306030830609053016080931");
        java.lang.String str9 = refinedSoundex0.soundex("  ");
        java.lang.String str11 = refinedSoundex0.encode("aorg.apache.commons.codec.Encode");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080931" + "'", str4, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A094010303080830603083060" + "'", str11, "A094010303080830603083060");
    }

    @Test
    public void test2082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2082");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex9.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex9.soundex("ARKPXKMNSKTSNKTRKSK");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test2083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2083");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("A621");
        java.lang.String str13 = refinedSoundex0.encode("O000");
        java.lang.String str15 = refinedSoundex0.encode("01230120022455012623010202");
        java.lang.String str17 = refinedSoundex0.soundex("O0931");
        java.lang.String str19 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0931383");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0" + "'", str17, "O0");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0940103030808306030830609053016080" + "'", str19, "O0940103030808306030830609053016080");
    }

    @Test
    public void test2084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2084");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str8 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        java.lang.String str10 = metaphone0.metaphone("A031383");
        java.lang.String str12 = metaphone0.metaphone("O621");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKPXKMNSK" + "'", str8, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
    }

    @Test
    public void test2085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2085");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        int int11 = soundex0.difference("H000", "HI");
        soundex0.setMaxLength((int) 'H');
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex14 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char16 = refinedSoundex14.getMappingCode('a');
        int int19 = refinedSoundex14.difference("", "hi!");
        char char21 = refinedSoundex14.getMappingCode('#');
        java.lang.String str23 = refinedSoundex14.soundex("01230120022455012623010202");
        java.lang.String str25 = refinedSoundex14.encode("O");
        int int28 = refinedSoundex14.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        java.lang.Object obj29 = soundex0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A0");
        java.lang.String str31 = soundex0.soundex("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str33 = soundex0.encode("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(refinedSoundex14);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '0' + "'", char16 == '0');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "O0" + "'", str25, "O0");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "O621" + "'", obj29, "O621");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "O621" + "'", str31, "O621");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "O621" + "'", str33, "O621");
    }

    @Test
    public void test2086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2086");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.Object obj32 = caverphone0.encode((java.lang.Object) "AKPKMNSKT1");
        java.lang.Class<?> wildcardClass33 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "AKPKMNSKT1" + "'", obj32, "AKPKMNSKT1");
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test2087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2087");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        int int13 = metaphone0.getMaxCodeLen();
        java.lang.String str15 = metaphone0.metaphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test2088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2088");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.String str12 = caverphone0.encode("O0940103030808306030830609053016080931");
        java.lang.String str14 = caverphone0.encode(" AKP1111111 ");
        java.lang.String str16 = caverphone0.caverphone("AKP1111111");
        java.lang.String str18 = caverphone0.encode("A1111111114r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKP1111111" + "'", str14, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKP1111111" + "'", str16, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AA11111111" + "'", str18, "AA11111111");
    }

    @Test
    public void test2089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2089");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex4.setMaxLength((int) (short) 0);
        soundex4.setMaxLength((int) (short) -1);
        java.lang.String str10 = soundex4.soundex("A031383");
        char[] charArray11 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex12 = new org.apache.commons.codec.language.Soundex(charArray11);
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray11);
        java.lang.String str15 = soundex13.soundex("H");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = soundex4.encode((java.lang.Object) str15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: H");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "H000" + "'", str15, "H000");
    }

    @Test
    public void test2090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2090");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        int int16 = refinedSoundex0.difference("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK", "");
        java.lang.String str18 = refinedSoundex0.soundex("ARKPKKMNSKTKNKTRKSPXNRKP");
        java.lang.String str20 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A09313836383693158931" + "'", str18, "A09313836383693158931");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O0" + "'", str20, "O0");
    }

    @Test
    public void test2091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2091");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        soundex0.setMaxLength(32);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
    }

    @Test
    public void test2092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2092");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char31 = refinedSoundex29.getMappingCode('a');
        int int34 = refinedSoundex29.difference("", "hi!");
        char char36 = refinedSoundex29.getMappingCode('#');
        int int39 = refinedSoundex29.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj41 = refinedSoundex29.encode((java.lang.Object) "O941");
        java.lang.Object obj42 = caverphone0.encode(obj41);
        boolean boolean45 = caverphone0.isCaverphoneEqual("H000", "AA");
        java.lang.String str47 = caverphone0.encode("AA");
        java.lang.String str49 = caverphone0.encode("");
        boolean boolean52 = caverphone0.isCaverphoneEqual("A621HI0A093138363836931589313836383693158", "O09401030308083060308306090530160809315383");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(refinedSoundex29);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0" + "'", obj41, "O0");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "A111111111" + "'", obj42, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "AA11111111" + "'", str47, "AA11111111");
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "1111111111" + "'", str49, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test2093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2093");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        java.lang.String str10 = soundex4.soundex("A111111111O620");
        int int13 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex4, "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O000");
        int int16 = soundex4.difference("  ", " org.apache.commons.codec.EncoderException: ORGAP");
        int int19 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex4, "O620", " AKPK");
        int int20 = soundex4.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test2094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2094");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.encode("ARKPXKMNSKTKNKTRKS");
        int int9 = soundex4.difference("ORKPXKMNSK", "ARKPKMNSKTKNKTRKSPKSNRKPKMNSKTKNKTRKSPKSN");
        int int10 = soundex4.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A621" + "'", str6, "A621");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test2095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2095");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.caverphone("A");
        java.lang.String str14 = caverphone0.caverphone("");
        java.lang.String str16 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O000");
        java.lang.String str18 = caverphone0.encode("A0931");
        java.lang.String str20 = caverphone0.caverphone("A212");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "1111111111" + "'", str14, "1111111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKKMNSKT" + "'", str16, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A111111111" + "'", str18, "A111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "A111111111" + "'", str20, "A111111111");
    }

    @Test
    public void test2096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2096");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex24 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char26 = refinedSoundex24.getMappingCode('a');
        int int29 = refinedSoundex24.difference("", "hi!");
        int int32 = refinedSoundex24.difference("", "A");
        java.lang.Object obj33 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str35 = caverphone0.caverphone("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str37 = caverphone0.encode("i4org.apache.commons.codec.EncoderException: A000");
        java.lang.String str39 = caverphone0.encode("A000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex24);
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "1111111111" + "'", obj33, "1111111111");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "A111111111" + "'", str35, "A111111111");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "AKPKKMNSKT" + "'", str37, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "A111111111" + "'", str39, "A111111111");
    }

    @Test
    public void test2097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2097");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str10 = metaphone0.metaphone("O621");
        java.lang.Object obj12 = metaphone0.encode((java.lang.Object) "A111111111e");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
    }

    @Test
    public void test2098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2098");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        java.lang.String str17 = metaphone0.encode("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.Caverphone caverphone18 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str20 = caverphone18.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone18.caverphone("hi!");
        java.lang.String str24 = caverphone18.caverphone("");
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone18, "AA11111111", "hi!");
        java.lang.String str29 = caverphone18.encode("ARKP");
        java.lang.String str31 = caverphone18.caverphone("AKPKMNSKT");
        java.lang.String str33 = caverphone18.encode("AK11111111");
        java.lang.Object obj34 = metaphone0.encode((java.lang.Object) "AK11111111");
        java.lang.String str36 = metaphone0.metaphone("ORKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN" + "'", str17, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AA11111111" + "'", str22, "AA11111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "AKP1111111" + "'", str29, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AKPKMNSKT1" + "'", str31, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "AK11111111" + "'", str33, "AK11111111");
        org.junit.Assert.assertEquals("'" + obj34 + "' != '" + "AK" + "'", obj34, "AK");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "ORKPKSKMNSKTSNKTRKSPKSNRKP" + "'", str36, "ORKPKSKMNSKTSNKTRKSPKSNRKP");
    }

    @Test
    public void test2099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2099");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: i0a", "org.apache.commons.codec.EncoderException: A ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test2100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2100");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "H000");
        java.lang.String str16 = refinedSoundex0.encode("O620");
        java.lang.String str18 = refinedSoundex0.encode("O0620102020505203020520306020130506212520");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O0" + "'", str16, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0" + "'", str18, "O0");
    }

    @Test
    public void test2101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2101");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORGAPACHECOMMONSCODECENCODEREXCEPTION", "AM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2102");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("ORKP");
        char char12 = refinedSoundex0.getMappingCode('1');
        int int15 = refinedSoundex0.difference("A09315383", "org.apache.commons.codec.EncoderException: AA11111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0931" + "'", str10, "O0931");
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test2103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2103");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        metaphone0.setMaxCodeLen((int) ' ');
        boolean boolean9 = metaphone0.isMetaphoneEqual("O", "ORKP");
        java.lang.String str11 = metaphone0.metaphone("A000");
        metaphone0.setMaxCodeLen(1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A" + "'", str11, "A");
    }

    @Test
    public void test2104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2104");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "O0931");
        java.lang.String str7 = soundex2.soundex("");
        soundex2.setMaxLength(38);
        java.lang.String str11 = soundex2.soundex("A621HI0A093138363836931589313836383693158g");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A200" + "'", str11, "A200");
    }

    @Test
    public void test2105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2105");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        java.lang.String str12 = metaphone0.encode("AA11111111");
        java.lang.String str14 = metaphone0.metaphone(" AKPKMNSKTK");
        int int15 = metaphone0.getMaxCodeLen();
        java.lang.String str17 = metaphone0.encode("A621HIo");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "K" + "'", str14, "K");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A" + "'", str17, "A");
    }

    @Test
    public void test2106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2106");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str6 = refinedSoundex0.encode("9");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080931" + "'", str4, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test2107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2107");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("A03138363", "ORKPKSKMNSKTKNKTRKSPKSN");
        boolean boolean10 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderExca", "e");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test2108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2108");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str6 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "HI", "A");
        char char11 = refinedSoundex0.getMappingCode('\000');
        java.lang.String str13 = refinedSoundex0.soundex("ARKPXKMNSKTKNKTRKSPXNKPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080" + "'", str4, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O0" + "'", str6, "O0");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '\000' + "'", char11 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A093153836383693158313" + "'", str13, "A093153836383693158313");
    }

    @Test
    public void test2109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2109");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.encode("");
        boolean boolean28 = caverphone0.isCaverphoneEqual("", "A#");
        java.lang.String str30 = caverphone0.caverphone("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        boolean boolean33 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException:  ", "A093153836383693");
        java.lang.String str35 = caverphone0.caverphone("O0620102020505203020520306020130506212520");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKMNSKTK" + "'", str30, "AKPKMNSKTK");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "A111111111" + "'", str35, "A111111111");
    }

    @Test
    public void test2110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2110");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        java.lang.String str4 = metaphone0.encode("A621");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "org.apache.commons.codec.EncoderException:  ", "");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "A093153836383693", "RKPXKMNSKTKNKTRKSSPXNRKP");
        metaphone0.setMaxCodeLen(43);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test2111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2111");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        java.lang.String str18 = refinedSoundex0.soundex("");
        char char20 = refinedSoundex0.getMappingCode('#');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
    }

    @Test
    public void test2112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2112");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex5, "", "A313");
        // The following exception was thrown during execution in test generation
        try {
            char char17 = refinedSoundex5.getMappingCode('K');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test2113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2113");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        boolean boolean10 = metaphone0.isMetaphoneEqual("AKP1111111", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        java.lang.String str12 = metaphone0.metaphone("A1");
        org.apache.commons.codec.EncoderException encoderException14 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException16 = new org.apache.commons.codec.EncoderException("AA11111111");
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray19 = encoderException18.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException21 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("");
        encoderException21.addSuppressed((java.lang.Throwable) encoderException23);
        encoderException18.addSuppressed((java.lang.Throwable) encoderException23);
        org.apache.commons.codec.EncoderException encoderException27 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray28 = encoderException27.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException30 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException32 = new org.apache.commons.codec.EncoderException("");
        encoderException30.addSuppressed((java.lang.Throwable) encoderException32);
        encoderException27.addSuppressed((java.lang.Throwable) encoderException32);
        encoderException18.addSuppressed((java.lang.Throwable) encoderException27);
        encoderException16.addSuppressed((java.lang.Throwable) encoderException27);
        encoderException14.addSuppressed((java.lang.Throwable) encoderException16);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj38 = metaphone0.encode((java.lang.Object) encoderException16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertArrayEquals(throwableArray19, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertArrayEquals(throwableArray28, new java.lang.Throwable[] {});
    }

    @Test
    public void test2114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2114");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        int int19 = refinedSoundex0.difference("1111111111", "O621");
        char char21 = refinedSoundex0.getMappingCode('r');
        char char23 = refinedSoundex0.getMappingCode('o');
        char char25 = refinedSoundex0.getMappingCode('a');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '9' + "'", char21 == '9');
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '0' + "'", char23 == '0');
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '0' + "'", char25 == '0');
    }

    @Test
    public void test2115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2115");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex24 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char26 = refinedSoundex24.getMappingCode('a');
        int int29 = refinedSoundex24.difference("", "hi!");
        int int32 = refinedSoundex24.difference("", "A");
        java.lang.Object obj33 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str35 = caverphone0.caverphone("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str37 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.language.Caverphone caverphone38 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str40 = caverphone38.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str42 = caverphone38.caverphone("hi!");
        java.lang.String str44 = caverphone38.caverphone("");
        int int47 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone38, "AA11111111", "hi!");
        java.lang.String str49 = caverphone38.caverphone("A0");
        java.lang.String str51 = caverphone38.caverphone("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str53 = caverphone38.encode("A621HI0A093138363836931589313836383693158g");
        java.lang.Object obj54 = caverphone0.encode((java.lang.Object) str53);
        java.lang.String str56 = caverphone0.caverphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex24);
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "1111111111" + "'", obj33, "1111111111");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "A111111111" + "'", str35, "A111111111");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "AKPKKMNSKT" + "'", str37, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "AKPKKMNSKT" + "'", str40, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "AA11111111" + "'", str42, "AA11111111");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "1111111111" + "'", str44, "1111111111");
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "A111111111" + "'", str49, "A111111111");
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "AKPKKMNSKT" + "'", str51, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str53 + "' != '" + "AK11111111" + "'", str53, "AK11111111");
        org.junit.Assert.assertEquals("'" + obj54 + "' != '" + "AK11111111" + "'", obj54, "AK11111111");
        org.junit.Assert.assertEquals("'" + str56 + "' != '" + "1111111111" + "'", str56, "1111111111");
    }

    @Test
    public void test2116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2116");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        int int16 = refinedSoundex0.difference("AA11111111", "01230120022455012623010202");
        int int19 = refinedSoundex0.difference("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "A");
        java.lang.String str21 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: O620");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "O0940103030808306030830609053016080" + "'", str21, "O0940103030808306030830609053016080");
    }

    @Test
    public void test2117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2117");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone0.maxCodeLen = '0';
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("A", true);
        boolean boolean12 = doubleMetaphone0.isDoubleMetaphoneEqual("A0", "");
        boolean boolean15 = doubleMetaphone0.isDoubleMetaphoneEqual("A ", "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone0.setMaxCodeLen((int) 'A');
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ARK", "A ");
        doubleMetaphone0.setMaxCodeLen((int) '#');
        boolean boolean25 = doubleMetaphone0.isDoubleMetaphoneEqual("O620", "");
        char[] charArray26 = null;
        org.apache.commons.codec.language.Soundex soundex27 = new org.apache.commons.codec.language.Soundex(charArray26);
        java.lang.String str29 = soundex27.soundex("");
        java.lang.Object obj30 = doubleMetaphone0.encode((java.lang.Object) "");
        doubleMetaphone0.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone33 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str35 = doubleMetaphone33.doubleMetaphone("H");
        java.lang.String str37 = doubleMetaphone33.doubleMetaphone("HI");
        java.lang.String str39 = doubleMetaphone33.encode("O621");
        doubleMetaphone33.maxCodeLen = (byte) 1;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj42 = doubleMetaphone0.encode((java.lang.Object) doubleMetaphone33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "H" + "'", str37, "H");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "A" + "'", str39, "A");
    }

    @Test
    public void test2118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2118");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.encode("A1");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "", "O000");
        java.lang.String str18 = refinedSoundex0.encode("O09315383638369315893153836383693158");
        java.lang.String str20 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        char char22 = refinedSoundex0.getMappingCode('a');
        java.lang.String str24 = refinedSoundex0.soundex("");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0" + "'", str13, "A0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0" + "'", str18, "O0");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O0940103030808306030830609053016080" + "'", str20, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '0' + "'", char22 == '0');
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
    }

    @Test
    public void test2119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2119");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str7 = soundex1.encode("AA11111111");
        java.lang.String str9 = soundex1.encode("org.apache.commons.codec.EncoderException: A0");
        int int10 = soundex1.getMaxLength();
        int int11 = soundex1.getMaxLength();
        java.lang.String str13 = soundex1.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O621" + "'", str13, "O621");
    }

    @Test
    public void test2120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2120");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj12 = refinedSoundex0.encode((java.lang.Object) "O941");
        char char14 = refinedSoundex0.getMappingCode('0');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = 0;
        char char20 = doubleMetaphone15.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str22 = doubleMetaphone15.encode("A");
        java.lang.Object obj24 = doubleMetaphone15.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        int int25 = doubleMetaphone15.getMaxCodeLen();
        java.lang.String str28 = doubleMetaphone15.doubleMetaphone("A", false);
        boolean boolean32 = doubleMetaphone15.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ", "org.apache.commons.codec.EncoderException: A0", true);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult34 = doubleMetaphone15.new DoubleMetaphoneResult((int) '\000');
        doubleMetaphoneResult34.append("A313", "");
        java.lang.Object obj38 = refinedSoundex0.encode((java.lang.Object) "A313");
        org.apache.commons.codec.language.Caverphone caverphone39 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str41 = caverphone39.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str43 = caverphone39.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str45 = caverphone39.encode("");
        java.lang.String str47 = caverphone39.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone48 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone48.maxCodeLen = 0;
        char char53 = doubleMetaphone48.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult55 = doubleMetaphone48.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult55.appendAlternate('\000');
        java.lang.String str58 = doubleMetaphoneResult55.getAlternate();
        java.lang.String str59 = doubleMetaphoneResult55.getPrimary();
        java.lang.Object obj60 = caverphone39.encode((java.lang.Object) str59);
        boolean boolean63 = caverphone39.isCaverphoneEqual("AKP1111111", "A1111111114r");
        java.lang.Object obj64 = refinedSoundex0.encode((java.lang.Object) "AKP1111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "O0" + "'", obj12, "O0");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertEquals("'" + obj38 + "' != '" + "A0" + "'", obj38, "A0");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "AKPKKMNSKT" + "'", str41, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "AKPKKMNSKT" + "'", str43, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "1111111111" + "'", str45, "1111111111");
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "1111111111" + "'", str47, "1111111111");
        org.junit.Assert.assertTrue("'" + char53 + "' != '" + '\000' + "'", char53 == '\000');
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "" + "'", str58, "");
        org.junit.Assert.assertEquals("'" + str59 + "' != '" + "" + "'", str59, "");
        org.junit.Assert.assertEquals("'" + obj60 + "' != '" + "1111111111" + "'", obj60, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertEquals("'" + obj64 + "' != '" + "A031" + "'", obj64, "A031");
    }

    @Test
    public void test2121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2121");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean5 = metaphone0.isMetaphoneEqual("ARK", "A0931");
        boolean boolean8 = metaphone0.isMetaphoneEqual("hi!", "O093");
        metaphone0.setMaxCodeLen((int) '\000');
        java.lang.String str12 = metaphone0.metaphone("AKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test2122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2122");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "KP11111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2123");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str30 = doubleMetaphone28.doubleMetaphone("H");
        java.lang.String str32 = doubleMetaphone28.doubleMetaphone("HI");
        java.lang.String str34 = doubleMetaphone28.doubleMetaphone("AKPKMNSKT1");
        java.lang.Object obj35 = metaphone0.encode((java.lang.Object) str34);
        metaphone0.setMaxCodeLen((int) 'r');
        int int38 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPK" + "'", str34, "AKPK");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "AKPK" + "'", obj35, "AKPK");
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 114 + "'", int38 == 114);
    }

    @Test
    public void test2124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2124");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        java.lang.String str13 = refinedSoundex0.soundex("AKP1111111");
        java.lang.String str15 = refinedSoundex0.soundex("ARKPKMNSKTKNKTRKSPKSNRKPKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A031" + "'", str13, "A031");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A093138363836931389313836383693138" + "'", str15, "A093138363836931389313836383693138");
    }

    @Test
    public void test2125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2125");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        boolean boolean7 = metaphone0.isMetaphoneEqual("i0a", "  ");
        java.lang.String str9 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: O620");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
    }

    @Test
    public void test2126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2126");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult9 = doubleMetaphone0.new DoubleMetaphoneResult(0);
        java.lang.String str11 = doubleMetaphone0.encode("H000");
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        metaphone12.setMaxCodeLen(3);
        int int15 = metaphone12.getMaxCodeLen();
        java.lang.String str17 = metaphone12.encode("hi!");
        java.lang.String str19 = metaphone12.encode("O621");
        java.lang.String str21 = metaphone12.metaphone("HI");
        int int22 = metaphone12.getMaxCodeLen();
        java.lang.String str24 = metaphone12.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        int int25 = metaphone12.getMaxCodeLen();
        java.lang.String str27 = metaphone12.encode("Aa");
        boolean boolean30 = metaphone12.isMetaphoneEqual("9", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKPor");
        java.lang.Object obj31 = doubleMetaphone0.encode((java.lang.Object) "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKPor");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "H" + "'", str17, "H");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "H" + "'", str21, "H");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORK" + "'", str24, "ORK");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A" + "'", str27, "A");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertEquals("'" + obj31 + "' != '" + "" + "'", obj31, "");
    }

    @Test
    public void test2127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2127");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.encode("");
        boolean boolean28 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: AKPK", "ARKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test2128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2128");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        metaphone0.setMaxCodeLen(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
    }

    @Test
    public void test2129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2129");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        boolean boolean13 = metaphone0.isMetaphoneEqual("AK11111111", "A621");
        int int14 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone15 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str17 = metaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str19 = metaphone15.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        boolean boolean22 = metaphone15.isMetaphoneEqual("i0a", "  ");
        boolean boolean25 = metaphone15.isMetaphoneEqual("O062125232523621256212523252362125", "org.apache.commons.codec.EncoderException: O0");
        java.lang.Object obj26 = metaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ORKP" + "'", str17, "ORKP");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ORKP" + "'", str19, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "ORKPXKMNSK" + "'", obj26, "ORKPXKMNSK");
    }

    @Test
    public void test2130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2130");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str6 = doubleMetaphone0.encode("H");
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("hi!", "AKPKKMNSKT");
        int int10 = doubleMetaphone0.getMaxCodeLen();
        boolean boolean14 = doubleMetaphone0.isDoubleMetaphoneEqual("A0", "O0931", true);
        java.lang.String str16 = doubleMetaphone0.doubleMetaphone("A#");
        int int19 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "AKPKMNSK", "AKPKMNSKT1");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone0.new DoubleMetaphoneResult(111);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone22.maxCodeLen = '\000';
        char char27 = doubleMetaphone22.charAt("", 0);
        java.lang.String str29 = doubleMetaphone22.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str31 = doubleMetaphone22.doubleMetaphone("");
        java.lang.String str33 = doubleMetaphone22.encode("ARKPXKMNSK");
        java.lang.String str35 = doubleMetaphone22.doubleMetaphone("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str37 = doubleMetaphone22.doubleMetaphone("A1111111114r");
        java.lang.Object obj38 = doubleMetaphone0.encode((java.lang.Object) "A1111111114r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '\000' + "'", char27 == '\000');
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
        org.junit.Assert.assertEquals("'" + obj38 + "' != '" + "" + "'", obj38, "");
    }

    @Test
    public void test2131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2131");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int5 = refinedSoundex2.difference("A#", "ORK");
        char char7 = refinedSoundex2.getMappingCode('H');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
    }

    @Test
    public void test2132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2132");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        java.lang.String str6 = metaphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str8 = metaphone0.metaphone("  ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O" + "'", str6, "O");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test2133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2133");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        int int7 = soundex1.getMaxLength();
        int int10 = soundex1.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        int int11 = soundex1.getMaxLength();
        java.lang.String str13 = soundex1.encode("org.apache.commons.codec.EncoderExc");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O941" + "'", str13, "O941");
    }

    @Test
    public void test2134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2134");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        java.lang.String str15 = metaphone0.metaphone("A000");
        metaphone0.setMaxCodeLen(48);
        java.lang.String str19 = metaphone0.metaphone("hi!");
        java.lang.String str21 = metaphone0.metaphone("A031383");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "H" + "'", str19, "H");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A" + "'", str21, "A");
    }

    @Test
    public void test2135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2135");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int10 = refinedSoundex7.difference("A111111111", "O0931538363836931589315383638369315893109");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test2136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2136");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "A111111111O620", "ARKPKSKMNSK");
        java.lang.String str11 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: ARK");
        java.lang.String str13 = metaphone0.encode("AR");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AR" + "'", str13, "AR");
    }

    @Test
    public void test2137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2137");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int9 = soundex4.difference("1111111111", "A111111111O620");
        org.apache.commons.codec.language.Caverphone caverphone10 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str12 = caverphone10.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char15 = refinedSoundex13.getMappingCode('a');
        int int18 = refinedSoundex13.difference("", "hi!");
        char char20 = refinedSoundex13.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone21 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str23 = doubleMetaphone21.doubleMetaphone("H");
        java.lang.String str25 = doubleMetaphone21.doubleMetaphone("");
        java.lang.String str28 = doubleMetaphone21.doubleMetaphone("ORKP", true);
        java.lang.String str31 = doubleMetaphone21.doubleMetaphone("", false);
        java.lang.String str33 = doubleMetaphone21.encode("");
        java.lang.Object obj34 = refinedSoundex13.encode((java.lang.Object) "");
        java.lang.Object obj35 = caverphone10.encode(obj34);
        boolean boolean38 = caverphone10.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str40 = caverphone10.encode("A212");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj41 = soundex4.encode((java.lang.Object) caverphone10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex13);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '0' + "'", char15 == '0');
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "ARKP" + "'", str28, "ARKP");
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertEquals("'" + obj34 + "' != '" + "" + "'", obj34, "");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "1111111111" + "'", obj35, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "A111111111" + "'", str40, "A111111111");
    }

    @Test
    public void test2138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2138");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        int int28 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "", "");
        boolean boolean31 = caverphone0.isCaverphoneEqual("", "ARKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone32 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone32.maxCodeLen = 0;
        java.lang.String str36 = doubleMetaphone32.encode("A621");
        boolean boolean40 = doubleMetaphone32.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        java.lang.String str42 = doubleMetaphone32.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = caverphone0.encode((java.lang.Object) str42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test2139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2139");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        org.apache.commons.codec.language.Caverphone caverphone9 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str11 = caverphone9.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str13 = caverphone9.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone9.encode("");
        java.lang.String str17 = caverphone9.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone18.maxCodeLen = 0;
        char char23 = doubleMetaphone18.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult25 = doubleMetaphone18.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult25.appendAlternate('\000');
        java.lang.String str28 = doubleMetaphoneResult25.getAlternate();
        java.lang.String str29 = doubleMetaphoneResult25.getPrimary();
        java.lang.Object obj30 = caverphone9.encode((java.lang.Object) str29);
        java.lang.String str32 = caverphone9.caverphone("");
        java.lang.String str34 = caverphone9.encode("");
        boolean boolean37 = caverphone9.isCaverphoneEqual("", "A#");
        java.lang.Object obj38 = refinedSoundex0.encode((java.lang.Object) "A#");
        java.lang.String str40 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONARKP");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "1111111111" + "'", obj30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "1111111111" + "'", str32, "1111111111");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "1111111111" + "'", str34, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertEquals("'" + obj38 + "' != '" + "A0" + "'", obj38, "A0");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "O0940103030808306030830609053016080931" + "'", str40, "O0940103030808306030830609053016080931");
    }

    @Test
    public void test2140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2140");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        int int13 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(49);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test2141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2141");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int13 = soundex0.difference("AKPKMNSKTK", "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str15 = soundex0.encode("");
        java.lang.String str17 = soundex0.encode("ARKPXKMNSKTKNKTRKS");
        org.apache.commons.codec.EncoderException encoderException19 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray20 = encoderException19.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException22 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException19.addSuppressed((java.lang.Throwable) encoderException22);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = soundex0.encode((java.lang.Object) encoderException22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A621" + "'", str17, "A621");
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertArrayEquals(throwableArray20, new java.lang.Throwable[] {});
    }

    @Test
    public void test2142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2142");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.caverphone("A");
        java.lang.String str36 = caverphone0.encode("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: AKPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "AKPKKMNSKT" + "'", str36, "AKPKKMNSKT");
    }

    @Test
    public void test2143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2143");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        boolean boolean15 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "Aa");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test2144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2144");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        java.lang.String str4 = soundex1.encode("O094010303080830603083060905301608093");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O000" + "'", str4, "O000");
    }

    @Test
    public void test2145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2145");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.soundex("0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test2146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2146");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength((int) '\000');
        java.lang.Object obj8 = soundex4.encode((java.lang.Object) "AKPKMNSKTK");
        int int9 = soundex4.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + obj8 + "' != '" + "A212" + "'", obj8, "A212");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test2147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2147");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O0931");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "A621");
        java.lang.String str9 = caverphone0.encode("ARKPKSKMNSK");
        java.lang.String str11 = caverphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKPKSKMNSK" + "'", str9, "AKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
    }

    @Test
    public void test2148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2148");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        metaphone0.setMaxCodeLen((int) (short) 0);
        java.lang.String str12 = metaphone0.encode("");
        metaphone0.setMaxCodeLen(65);
        int int15 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 65 + "'", int15 == 65);
    }

    @Test
    public void test2149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2149");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean22 = caverphone0.isCaverphoneEqual("A#", "AKP1111111");
        java.lang.String str24 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        boolean boolean27 = caverphone0.isCaverphoneEqual("", "org.apache.commons.codec.EncoderExc");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test2150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2150");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("9", "0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2151");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        int int16 = refinedSoundex0.difference("A000", "01230120022455012623010202");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN", "ORKPXKMNSK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test2152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2152");
        char[] charArray6 = new char[] { 'r', '1', ' ', 'i', '#', '#' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex12 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = refinedSoundex12.encode("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSNi");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertArrayEquals(charArray6, new char[] { 'r', '1', ' ', 'i', '#', '#' });
    }

    @Test
    public void test2153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2153");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        soundex3.setMaxLength((int) (short) 100);
        soundex3.setMaxLength(48);
        soundex3.setMaxLength(19);
        // The following exception was thrown during execution in test generation
        try {
            int int14 = soundex3.difference("org.apache.commons.codec.EncoderException: A0931", "org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test2154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2154");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        java.lang.String str13 = caverphone0.encode(" ");
        java.lang.String str15 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
    }

    @Test
    public void test2155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2155");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean7 = caverphone0.isCaverphoneEqual("O", "01230120022455012623010202");
        java.lang.String str9 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = 0;
        char char15 = doubleMetaphone10.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult17 = doubleMetaphone10.new DoubleMetaphoneResult((int) (byte) -1);
        java.lang.String str18 = doubleMetaphoneResult17.getAlternate();
        doubleMetaphoneResult17.append('4');
        doubleMetaphoneResult17.appendPrimary('\000');
        doubleMetaphoneResult17.appendPrimary('4');
        doubleMetaphoneResult17.append('a', 'O');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKPKKMNSKT" + "'", str9, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
    }

    @Test
    public void test2156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2156");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        int int23 = metaphone0.getMaxCodeLen();
        char[] charArray24 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex25 = new org.apache.commons.codec.language.Soundex(charArray24);
        org.apache.commons.codec.language.Soundex soundex26 = new org.apache.commons.codec.language.Soundex(charArray24);
        org.apache.commons.codec.language.Soundex soundex27 = new org.apache.commons.codec.language.Soundex(charArray24);
        org.apache.commons.codec.language.Soundex soundex28 = new org.apache.commons.codec.language.Soundex(charArray24);
        int int31 = soundex28.difference("A1111111114r", "O0940103030808306030830609053016080931");
        java.lang.String str33 = soundex28.soundex("A621HIo");
        java.lang.Object obj34 = metaphone0.encode((java.lang.Object) str33);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ARKPKSKMNS" + "'", str22, "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "A000" + "'", str33, "A000");
        org.junit.Assert.assertEquals("'" + obj34 + "' != '" + "A" + "'", obj34, "A");
    }

    @Test
    public void test2157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2157");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        java.lang.String str15 = caverphone0.encode("AK");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex16 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char18 = refinedSoundex16.getMappingCode('a');
        int int21 = refinedSoundex16.difference("", "hi!");
        char char23 = refinedSoundex16.getMappingCode('0');
        char char25 = refinedSoundex16.getMappingCode('a');
        java.lang.String str27 = refinedSoundex16.soundex("1111111111");
        char char29 = refinedSoundex16.getMappingCode('i');
        int int32 = refinedSoundex16.difference("A000", "01230120022455012623010202");
        int int35 = refinedSoundex16.difference("AKPK", "AKP1111111");
        java.lang.Object obj36 = caverphone0.encode((java.lang.Object) "AKP1111111");
        java.lang.String str38 = caverphone0.encode("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone39 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str41 = doubleMetaphone39.doubleMetaphone("H");
        doubleMetaphone39.setMaxCodeLen((int) (byte) 0);
        java.lang.String str45 = doubleMetaphone39.encode("H");
        boolean boolean48 = doubleMetaphone39.isDoubleMetaphoneEqual("hi!", "AKPKKMNSKT");
        int int49 = doubleMetaphone39.getMaxCodeLen();
        boolean boolean53 = doubleMetaphone39.isDoubleMetaphoneEqual("A0", "O0931", true);
        java.lang.String str55 = doubleMetaphone39.doubleMetaphone("A#");
        boolean boolean58 = doubleMetaphone39.isDoubleMetaphoneEqual("A111111111O620", "AA11111111");
        java.lang.String str61 = doubleMetaphone39.doubleMetaphone("O062010202050520302052030602013050", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult63 = doubleMetaphone39.new DoubleMetaphoneResult(19);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj64 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertNotNull(refinedSoundex16);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '0' + "'", char18 == '0');
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '0' + "'", char25 == '0');
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '0' + "'", char29 == '0');
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertEquals("'" + obj36 + "' != '" + "AKP1111111" + "'", obj36, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "1111111111" + "'", str38, "1111111111");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "" + "'", str41, "");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "" + "'", str45, "");
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "" + "'", str55, "");
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + "" + "'", str61, "");
    }

    @Test
    public void test2158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2158");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.encode("O0940103030808306030830609053016080931");
        org.apache.commons.codec.language.Metaphone metaphone11 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str13 = metaphone11.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = metaphone11.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        boolean boolean18 = metaphone11.isMetaphoneEqual("i0a", "  ");
        java.lang.Object obj19 = soundex0.encode((java.lang.Object) "i0a");
        java.lang.String str21 = soundex0.encode("org.apache.commons.codec.EncoderException: O000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ORKP" + "'", str13, "ORKP");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKP" + "'", str15, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "I000" + "'", obj19, "I000");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "O621" + "'", str21, "O621");
    }

    @Test
    public void test2159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2159");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str7 = soundex1.encode("AA11111111");
        java.lang.String str9 = soundex1.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str11 = soundex1.soundex("org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = '\000';
        char char17 = doubleMetaphone12.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone12.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult19.appendPrimary('#');
        doubleMetaphoneResult19.appendAlternate('i');
        doubleMetaphoneResult19.append("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        doubleMetaphoneResult19.append('o');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = soundex1.encode((java.lang.Object) doubleMetaphoneResult19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O621" + "'", str11, "O621");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
    }

    @Test
    public void test2160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2160");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str15 = caverphone0.caverphone("ARKPKSKMNSK");
        java.lang.String str17 = caverphone0.caverphone("ORK");
        java.lang.String str19 = caverphone0.caverphone("A0212523");
        boolean boolean22 = caverphone0.isCaverphoneEqual("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKT1" + "'", str13, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKSKMNSK" + "'", str15, "AKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AK11111111" + "'", str17, "AK11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A111111111" + "'", str19, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test2161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2161");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        int int3 = doubleMetaphone0.maxCodeLen;
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean10 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A000", "", false);
        char char13 = doubleMetaphone0.charAt("O0931", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
    }

    @Test
    public void test2162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2162");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("A0931");
        char char26 = refinedSoundex0.getMappingCode('1');
        java.lang.String str28 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A0" + "'", str24, "A0");
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '\000' + "'", char26 == '\000');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "O0940103030808306030830609053016080" + "'", str28, "O0940103030808306030830609053016080");
    }

    @Test
    public void test2163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2163");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        int int13 = metaphone0.getMaxCodeLen();
        java.lang.String str15 = metaphone0.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        java.lang.String str17 = metaphone0.encode("org.apache.commons.codec.EncoderExc");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKPXKMNSKTSNKTRKSSPXN" + "'", str15, "ORKPXKMNSKTSNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ORKPXKMNSKTKNKTRKSK" + "'", str17, "ORKPXKMNSKTKNKTRKSK");
    }

    @Test
    public void test2164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2164");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.soundex("A0313836");
        int int11 = soundex0.getMaxLength();
        int int14 = soundex0.difference("H0", "ARKPKSKMNSK");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = 0;
        char char20 = doubleMetaphone15.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean24 = doubleMetaphone15.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char27 = doubleMetaphone15.charAt("01230120022455012623010202", (int) (short) 1);
        doubleMetaphone15.setMaxCodeLen(35);
        boolean boolean33 = doubleMetaphone15.isDoubleMetaphoneEqual("AKPKMNSKT1", "", false);
        int int34 = doubleMetaphone15.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj35 = soundex0.encode((java.lang.Object) int34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '1' + "'", char27 == '1');
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 35 + "'", int34 == 35);
    }

    @Test
    public void test2165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2165");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKTRKSPXNRKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKTRKSPXNRKP" + "'", str1, "ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKTRKSPXNRKP");
    }

    @Test
    public void test2166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2166");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str4 = soundex2.soundex("org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        soundex2.setMaxLength((int) (short) 0);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
    }

    @Test
    public void test2167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2167");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        int int16 = refinedSoundex0.difference("A000", "01230120022455012623010202");
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException20 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray21 = encoderException20.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException20.addSuppressed((java.lang.Throwable) encoderException23);
        org.apache.commons.codec.EncoderException encoderException26 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray27 = encoderException26.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException29 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException31 = new org.apache.commons.codec.EncoderException("");
        encoderException29.addSuppressed((java.lang.Throwable) encoderException31);
        encoderException26.addSuppressed((java.lang.Throwable) encoderException31);
        org.apache.commons.codec.EncoderException encoderException35 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        encoderException31.addSuppressed((java.lang.Throwable) encoderException35);
        encoderException20.addSuppressed((java.lang.Throwable) encoderException35);
        java.lang.Throwable[] throwableArray38 = encoderException35.getSuppressed();
        encoderException18.addSuppressed((java.lang.Throwable) encoderException35);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj40 = refinedSoundex0.encode((java.lang.Object) encoderException18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertArrayEquals(throwableArray21, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertArrayEquals(throwableArray27, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertArrayEquals(throwableArray38, new java.lang.Throwable[] {});
    }

    @Test
    public void test2168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2168");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str8 = metaphone0.encode("ORKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKPKSKMNS" + "'", str8, "ORKPKSKMNS");
    }

    @Test
    public void test2169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2169");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("A111111111O620");
        java.lang.String str5 = soundex1.encode("ARKPKKMNSKTKNKTRKSPXNRKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "A000" + "'", str3, "A000");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A931" + "'", str5, "A931");
    }

    @Test
    public void test2170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2170");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: AKPK", "org.apache.commons.codec.EncoderException: H000");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test2171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2171");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        java.lang.String str6 = metaphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str8 = metaphone0.metaphone("O");
        java.lang.String str10 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A093153836383693158");
        java.lang.String str12 = metaphone0.encode("A800");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O" + "'", str6, "O");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O" + "'", str8, "O");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "ORKP" + "'", str10, "ORKP");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
    }

    @Test
    public void test2172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2172");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str8 = refinedSoundex6.encode("O062125232523621256212523252362125");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O0" + "'", str8, "O0");
    }

    @Test
    public void test2173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2173");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AA11111111");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex31 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char33 = refinedSoundex31.getMappingCode('a');
        int int36 = refinedSoundex31.difference("", "hi!");
        char char38 = refinedSoundex31.getMappingCode('#');
        int int41 = refinedSoundex31.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj43 = refinedSoundex31.encode((java.lang.Object) "O941");
        char char45 = refinedSoundex31.getMappingCode('0');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj46 = caverphone0.encode((java.lang.Object) refinedSoundex31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AA11111111" + "'", str30, "AA11111111");
        org.junit.Assert.assertNotNull(refinedSoundex31);
        org.junit.Assert.assertTrue("'" + char33 + "' != '" + '0' + "'", char33 == '0');
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + char38 + "' != '" + '\000' + "'", char38 == '\000');
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertEquals("'" + obj43 + "' != '" + "O0" + "'", obj43, "O0");
        org.junit.Assert.assertTrue("'" + char45 + "' != '" + '\000' + "'", char45 == '\000');
    }

    @Test
    public void test2174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2174");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        java.lang.String str14 = caverphone0.encode("AKPKKMNSKT");
        java.lang.String str16 = caverphone0.encode("ORKPXKMNSKTKNKTRKSSPXNH");
        org.apache.commons.codec.language.Caverphone caverphone17 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str19 = caverphone17.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str21 = caverphone17.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str23 = caverphone17.encode("");
        java.lang.String str25 = caverphone17.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone26 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone26.maxCodeLen = 0;
        char char31 = doubleMetaphone26.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult33 = doubleMetaphone26.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult33.appendAlternate('\000');
        java.lang.String str36 = doubleMetaphoneResult33.getAlternate();
        java.lang.String str37 = doubleMetaphoneResult33.getPrimary();
        java.lang.Object obj38 = caverphone17.encode((java.lang.Object) str37);
        java.lang.String str40 = caverphone17.caverphone("");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex41 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char43 = refinedSoundex41.getMappingCode('a');
        int int46 = refinedSoundex41.difference("", "hi!");
        int int49 = refinedSoundex41.difference("", "A");
        java.lang.Object obj50 = caverphone17.encode((java.lang.Object) "");
        java.lang.String str52 = caverphone17.caverphone("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str54 = caverphone17.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.Object obj55 = caverphone0.encode((java.lang.Object) str54);
        boolean boolean58 = caverphone0.isCaverphoneEqual("ARKPKMNSKT", "9");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKT1" + "'", str14, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKMNSKTK" + "'", str16, "AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKKMNSKT" + "'", str19, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKKMNSKT" + "'", str21, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '\000' + "'", char31 == '\000');
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
        org.junit.Assert.assertEquals("'" + obj38 + "' != '" + "1111111111" + "'", obj38, "1111111111");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "1111111111" + "'", str40, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex41);
        org.junit.Assert.assertTrue("'" + char43 + "' != '" + '0' + "'", char43 == '0');
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertEquals("'" + obj50 + "' != '" + "1111111111" + "'", obj50, "1111111111");
        org.junit.Assert.assertEquals("'" + str52 + "' != '" + "A111111111" + "'", str52, "A111111111");
        org.junit.Assert.assertEquals("'" + str54 + "' != '" + "AKPKKMNSKT" + "'", str54, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + obj55 + "' != '" + "AKPKMNSKT1" + "'", obj55, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test2175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2175");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        java.lang.String str4 = metaphone0.encode("A621");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "org.apache.commons.codec.EncoderException:  ", "");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "A093153836383693", "RKPXKMNSKTKNKTRKSSPXNRKP");
        java.lang.String str12 = metaphone0.metaphone("A");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
    }

    @Test
    public void test2176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2176");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int6 = soundex3.difference("org.apache.commons.codec.EncoderException: O0", "");
        int int7 = soundex3.getMaxLength();
        java.lang.String str9 = soundex3.soundex("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test2177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2177");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A0313836");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
    }

    @Test
    public void test2178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2178");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str9 = refinedSoundex7.encode("ORKPXKMNSK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O0621252" + "'", str9, "O0621252");
    }

    @Test
    public void test2179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2179");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.encode("H");
        boolean boolean16 = caverphone0.isCaverphoneEqual("A111111111O620", "hi!");
        java.lang.String str18 = caverphone0.caverphone("AK11111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AK11111111" + "'", str18, "AK11111111");
    }

    @Test
    public void test2180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2180");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: ", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2181");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "H");
        boolean boolean19 = metaphone0.isMetaphoneEqual("A0313", "A062125232523621256212523252362125");
        java.lang.String str21 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        int int22 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test2182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2182");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("ORKPXKMNSKTKNKTRKSSPXNH", "");
        char char16 = refinedSoundex0.getMappingCode(' ');
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex17 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char19 = refinedSoundex17.getMappingCode('a');
        int int22 = refinedSoundex17.difference("", "hi!");
        char char24 = refinedSoundex17.getMappingCode('0');
        char char26 = refinedSoundex17.getMappingCode('a');
        java.lang.String str28 = refinedSoundex17.soundex("1111111111");
        int int31 = refinedSoundex17.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone32 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone32.maxCodeLen = '\000';
        doubleMetaphone32.setMaxCodeLen(4);
        java.lang.String str38 = doubleMetaphone32.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj39 = refinedSoundex17.encode((java.lang.Object) str38);
        java.lang.String str41 = refinedSoundex17.soundex("A0931");
        char char43 = refinedSoundex17.getMappingCode('1');
        char char45 = refinedSoundex17.getMappingCode('6');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj46 = refinedSoundex0.encode((java.lang.Object) '6');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertNotNull(refinedSoundex17);
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '0' + "'", char19 == '0');
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "ARKP" + "'", str38, "ARKP");
        org.junit.Assert.assertEquals("'" + obj39 + "' != '" + "A0931" + "'", obj39, "A0931");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "A0" + "'", str41, "A0");
        org.junit.Assert.assertTrue("'" + char43 + "' != '" + '\000' + "'", char43 == '\000');
        org.junit.Assert.assertTrue("'" + char45 + "' != '" + '\000' + "'", char45 == '\000');
    }

    @Test
    public void test2183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2183");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex7.difference("9", "aorg.apache.commons.codec.Encode");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test2184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2184");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.encode("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        char[] charArray18 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex19 = new org.apache.commons.codec.language.RefinedSoundex(charArray18);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex20 = new org.apache.commons.codec.language.RefinedSoundex(charArray18);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex21 = new org.apache.commons.codec.language.RefinedSoundex(charArray18);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = caverphone0.encode((java.lang.Object) refinedSoundex21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKTK" + "'", str13, "AKPKMNSKTK");
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertArrayEquals(charArray18, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test2185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2185");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("");
        java.lang.String str29 = caverphone0.encode("A#");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O093", "ARKPXKMNSKTKNKTRKSPXN");
        boolean boolean35 = caverphone0.isCaverphoneEqual("0123012002245501262301020201230120022455012623010", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        boolean boolean38 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: hi!", "ARKPKSKMNSKTKNKTRKSPKSNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "1111111111" + "'", str27, "1111111111");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test2186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2186");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        java.lang.String str38 = caverphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        java.lang.String str40 = caverphone0.encode("A111111111O000");
        java.lang.String str42 = caverphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKMNSKTK" + "'", str38, "AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "AA11111111" + "'", str40, "AA11111111");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "1111111111" + "'", str42, "1111111111");
    }

    @Test
    public void test2187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2187");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.encode("A1");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "org.apache.commons.codec.EncoderException: ARKP", "org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone17.maxCodeLen = 0;
        char char22 = doubleMetaphone17.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean26 = doubleMetaphone17.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char29 = doubleMetaphone17.charAt("01230120022455012623010202", (int) (short) 1);
        char char32 = doubleMetaphone17.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone17.maxCodeLen = 100;
        boolean boolean37 = doubleMetaphone17.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        boolean boolean40 = doubleMetaphone17.isDoubleMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str42 = doubleMetaphone17.encode("AKPKKMNSKT");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult44 = doubleMetaphone17.new DoubleMetaphoneResult((int) (byte) 10);
        doubleMetaphoneResult44.append("", "01230120022455012623010202");
        doubleMetaphoneResult44.appendPrimary('o');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj50 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0" + "'", str13, "A0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 38 + "'", int16 == 38);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '1' + "'", char29 == '1');
        org.junit.Assert.assertTrue("'" + char32 + "' != '" + 'O' + "'", char32 == 'O');
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "AKPKMNSKT" + "'", str42, "AKPKMNSKT");
    }

    @Test
    public void test2188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2188");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        java.lang.String str18 = refinedSoundex0.soundex("AKPK");
        char char20 = refinedSoundex0.getMappingCode('o');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A0313" + "'", str18, "A0313");
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '0' + "'", char20 == '0');
    }

    @Test
    public void test2189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2189");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen((int) '0');
        doubleMetaphone0.maxCodeLen = 'r';
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test2190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2190");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        java.lang.String str23 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str25 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) '\000');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str23, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
    }

    @Test
    public void test2191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2191");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        java.lang.String str5 = soundex1.soundex("A031");
        java.lang.String str7 = soundex1.encode("ARKPKMNSK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A000" + "'", str5, "A000");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A931" + "'", str7, "A931");
    }

    @Test
    public void test2192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2192");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean7 = caverphone0.isCaverphoneEqual("O", "01230120022455012623010202");
        java.lang.String str9 = caverphone0.encode("A09313836383693158931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
    }

    @Test
    public void test2193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2193");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: O000", "O062010202050520302052030602013050");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2194");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = '\000';
        doubleMetaphone8.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone8.new DoubleMetaphoneResult((int) '1');
        doubleMetaphoneResult14.appendPrimary(' ');
        doubleMetaphoneResult14.appendAlternate("A621");
        doubleMetaphoneResult14.appendAlternate('#');
        doubleMetaphoneResult14.append("O941", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Object obj24 = refinedSoundex4.encode((java.lang.Object) "O941");
        int int27 = refinedSoundex4.difference("R9", "K");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "O0" + "'", obj24, "O0");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test2195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2195");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str10 = metaphone0.metaphone("O621");
        int int11 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) 'g');
        boolean boolean16 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSK", "org.apache.commons.codec.EncoderException: AKPK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2196");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = 0;
        char char15 = doubleMetaphone10.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult17 = doubleMetaphone10.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult17.appendAlternate('\000');
        doubleMetaphoneResult17.append('#');
        doubleMetaphoneResult17.appendPrimary('a');
        doubleMetaphoneResult17.appendPrimary('o');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
    }

    @Test
    public void test2197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2197");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        java.lang.String str10 = doubleMetaphone6.doubleMetaphone("HI");
        java.lang.String str12 = doubleMetaphone6.encode("O621");
        java.lang.Object obj13 = refinedSoundex0.encode((java.lang.Object) "O621");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str16 = doubleMetaphone14.doubleMetaphone("H");
        doubleMetaphone14.setMaxCodeLen((int) (byte) 0);
        boolean boolean22 = doubleMetaphone14.isDoubleMetaphoneEqual("O620", "O000", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult24 = doubleMetaphone14.new DoubleMetaphoneResult((int) 'r');
        doubleMetaphoneResult24.append("A0");
        java.lang.String str27 = doubleMetaphoneResult24.getAlternate();
        doubleMetaphoneResult24.append("O093", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj31 = refinedSoundex0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        int int34 = refinedSoundex0.difference("A09313836383693158931", "org.apache.commons.codec.EncoderException: A111111111O620");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone35 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone35.maxCodeLen = 0;
        java.lang.String str39 = doubleMetaphone35.encode("A621");
        doubleMetaphone35.maxCodeLen = 'a';
        int int42 = doubleMetaphone35.getMaxCodeLen();
        java.lang.String str45 = doubleMetaphone35.doubleMetaphone("", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj46 = refinedSoundex0.encode((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "H" + "'", str10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "O0" + "'", obj13, "O0");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertEquals("'" + obj31 + "' != '" + "O0940103030808306030830609053016080931" + "'", obj31, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "" + "'", str39, "");
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 97 + "'", int42 == 97);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test2198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2198");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = 100;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "");
        int int21 = doubleMetaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
    }

    @Test
    public void test2199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2199");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        java.lang.String str15 = metaphone0.metaphone("A000");
        int int16 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) -1);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test2200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2200");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone2 = new org.apache.commons.codec.language.Metaphone();
        metaphone2.setMaxCodeLen(3);
        java.lang.String str6 = metaphone2.encode("");
        java.lang.String str8 = metaphone2.encode("");
        java.lang.Object obj9 = soundex0.encode((java.lang.Object) "");
        java.lang.String str11 = soundex0.encode("O941");
        int int12 = soundex0.getMaxLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O000" + "'", str11, "O000");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test2201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2201");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        java.lang.String str10 = soundex4.soundex("AKPKMNSKT1");
        int int13 = soundex4.difference("org.apache.commons.codec.EncoderException: A0", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        int int14 = soundex4.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A212" + "'", str10, "A212");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test2202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2202");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPXKMNSKTKNKTRKS");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPXKMNSKTKNKTRKS" + "'", str1, "ARKPXKMNSKTKNKTRKS");
    }

    @Test
    public void test2203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2203");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 100);
        doubleMetaphone0.setMaxCodeLen((int) 'O');
        int int9 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.Caverphone caverphone10 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str12 = caverphone10.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str14 = caverphone10.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str16 = caverphone10.encode("A");
        java.lang.String str18 = caverphone10.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str20 = caverphone10.encode("hi!");
        java.lang.Object obj22 = caverphone10.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        org.apache.commons.codec.language.Metaphone metaphone23 = new org.apache.commons.codec.language.Metaphone();
        metaphone23.setMaxCodeLen(3);
        java.lang.String str27 = metaphone23.encode("");
        java.lang.String str29 = metaphone23.metaphone("O000");
        java.lang.Object obj30 = caverphone10.encode((java.lang.Object) "O000");
        boolean boolean33 = caverphone10.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTION", "O0");
        boolean boolean36 = caverphone10.isCaverphoneEqual("H0", "org.apache.commons.codec.EncoderException: A0");
        boolean boolean39 = caverphone10.isCaverphoneEqual("ARKPKKMNSKTSNKTRKSPXN", "O941");
        java.lang.Object obj40 = doubleMetaphone0.encode((java.lang.Object) "O941");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 79 + "'", int9 == 79);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKKMNSKT" + "'", str14, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A111111111" + "'", str16, "A111111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AA11111111" + "'", str20, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "AKPKKMNSKT" + "'", obj22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "O" + "'", str29, "O");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "A111111111" + "'", obj30, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertEquals("'" + obj40 + "' != '" + "A" + "'", obj40, "A");
    }

    @Test
    public void test2204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2204");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str14 = metaphone0.encode("O0621252");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test2205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2205");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        int int3 = soundex0.getMaxLength();
        int int4 = soundex0.getMaxLength();
        int int7 = soundex0.difference("H", "O0");
        int int10 = soundex0.difference("", "ARKPXKMNSKTKNKTRKSPXN");
        org.apache.commons.codec.language.Metaphone metaphone11 = new org.apache.commons.codec.language.Metaphone();
        metaphone11.setMaxCodeLen(3);
        java.lang.String str15 = metaphone11.encode("");
        java.lang.String str17 = metaphone11.encode("");
        metaphone11.setMaxCodeLen((int) (short) 10);
        int int20 = metaphone11.getMaxCodeLen();
        java.lang.String str22 = metaphone11.encode("ORKP");
        int int23 = metaphone11.getMaxCodeLen();
        boolean boolean26 = metaphone11.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean29 = metaphone11.isMetaphoneEqual("O093", "HI");
        java.lang.String str31 = metaphone11.metaphone("AKPKKMNSKT");
        java.lang.String str33 = metaphone11.encode("ARKPXKMNSK");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = soundex0.encode((java.lang.Object) metaphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ORKP" + "'", str22, "ORKP");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AKPKMNSKT" + "'", str31, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "ARKPKSKMNS" + "'", str33, "ARKPKSKMNS");
    }

    @Test
    public void test2206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2206");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 100);
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "");
        int int10 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult12 = doubleMetaphone0.new DoubleMetaphoneResult(105);
        boolean boolean16 = doubleMetaphone0.isDoubleMetaphoneEqual("O062010202050520302052030602013050", "H0", true);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2207");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        boolean boolean3 = caverphone0.isCaverphoneEqual("AKPK", "AKP1111111");
        java.lang.String str5 = caverphone0.encode("AKP1111111");
        java.lang.String str7 = caverphone0.caverphone("01230120022455012623010202");
        java.lang.String str9 = caverphone0.encode("ORKPKSKMNSKTSNKTRKSPKSNRKP");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "AKP1111111" + "'", str5, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "1111111111" + "'", str7, "1111111111");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKPKSKMNSK" + "'", str9, "AKPKSKMNSK");
    }

    @Test
    public void test2208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2208");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        java.lang.String str4 = doubleMetaphone0.encode("A621");
        doubleMetaphone0.maxCodeLen = 'a';
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", true);
        char[] charArray10 = null;
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray10);
        java.lang.String str13 = soundex11.soundex("");
        java.lang.String str15 = soundex11.encode("");
        java.lang.Object obj16 = doubleMetaphone0.encode((java.lang.Object) str15);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN" + "'", str9, "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test2209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2209");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("AA");
        java.lang.String str9 = soundex0.encode("A621org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A621" + "'", str9, "A621");
    }

    @Test
    public void test2210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2210");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int6 = soundex3.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0");
        java.lang.String str8 = soundex3.encode("AK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A200" + "'", str8, "A200");
    }

    @Test
    public void test2211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2211");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: A093153836383693158", "A313");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2212");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int5 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) '1');
        boolean boolean10 = metaphone0.isMetaphoneEqual("ARKPKSKMNSKTKNKTRKSPKSN", "ARKPKKMNSKTSNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test2213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2213");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean22 = caverphone0.isCaverphoneEqual("A#", "AKP1111111");
        java.lang.String str24 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        boolean boolean27 = caverphone0.isCaverphoneEqual("ORK", "");
        java.lang.String str29 = caverphone0.encode("A111111111");
        java.lang.String str31 = caverphone0.caverphone("A931");
        java.lang.String str33 = caverphone0.caverphone("O0940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone34 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone34.maxCodeLen = 0;
        char char39 = doubleMetaphone34.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult41 = doubleMetaphone34.new DoubleMetaphoneResult((int) '#');
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult43 = doubleMetaphone34.new DoubleMetaphoneResult((-1));
        doubleMetaphone34.maxCodeLen = (-1);
        int int46 = doubleMetaphone34.getMaxCodeLen();
        int int47 = doubleMetaphone34.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj48 = caverphone0.encode((java.lang.Object) doubleMetaphone34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "A111111111" + "'", str31, "A111111111");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "A111111111" + "'", str33, "A111111111");
        org.junit.Assert.assertTrue("'" + char39 + "' != '" + '\000' + "'", char39 == '\000');
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test2214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2214");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = refinedSoundex7.encode("O0940103030808306030830609053016080");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test2215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2215");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        boolean boolean13 = metaphone0.isMetaphoneEqual("AK11111111", "A621");
        int int14 = metaphone0.getMaxCodeLen();
        java.lang.String str16 = metaphone0.metaphone("O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O" + "'", str16, "O");
    }

    @Test
    public void test2216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2216");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex5, "A093153836383693158", "");
        // The following exception was thrown during execution in test generation
        try {
            int int13 = refinedSoundex5.difference("O094010303080830603083060905301608093", "O0620102020505203020520306020130506212520");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test2217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2217");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.encode("A1");
        java.lang.String str11 = caverphone0.caverphone("a");
        boolean boolean14 = caverphone0.isCaverphoneEqual("o", "A031");
        java.lang.String str16 = caverphone0.caverphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A111111111" + "'", str11, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "1111111111" + "'", str16, "1111111111");
    }

    @Test
    public void test2218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2218");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode('0');
        int int10 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: A093153836383693158", "");
        int int13 = refinedSoundex0.difference("O0940103030808306030830609053016080940103030808306030830609053016080", "H0");
        java.lang.String str15 = refinedSoundex0.soundex("A062125232523621256212523252362125");
        java.lang.Class<?> wildcardClass16 = refinedSoundex0.getClass();
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A0" + "'", str15, "A0");
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test2219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2219");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("AR");
        java.lang.String str7 = refinedSoundex0.encode("");
        char char9 = refinedSoundex0.getMappingCode('O');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A09" + "'", str5, "A09");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
    }

    @Test
    public void test2220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2220");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str6 = doubleMetaphone0.encode("H");
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("hi!", "AKPKKMNSKT");
        int int10 = doubleMetaphone0.getMaxCodeLen();
        doubleMetaphone0.maxCodeLen = '.';
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone13.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean20 = caverphone13.isCaverphoneEqual("O", "01230120022455012623010202");
        boolean boolean23 = caverphone13.isCaverphoneEqual("ARKP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = doubleMetaphone0.encode((java.lang.Object) boolean23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test2221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2221");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str7 = doubleMetaphone0.encode("A");
        doubleMetaphone0.setMaxCodeLen((int) (short) 10);
        int int10 = doubleMetaphone0.maxCodeLen;
        int int13 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHIM", "AKPKMNSKT1");
        doubleMetaphone0.maxCodeLen = 0;
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test2222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2222");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone12.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult19.appendAlternate("A111111111");
        doubleMetaphoneResult19.append("O620");
        java.lang.String str24 = doubleMetaphoneResult19.getAlternate();
        doubleMetaphoneResult19.appendAlternate('#');
        doubleMetaphoneResult19.appendPrimary('H');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A111111111O620" + "'", str24, "A111111111O620");
    }

    @Test
    public void test2223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2223");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) ' ');
        int int13 = soundex1.getMaxLength();
        int int16 = soundex1.difference("AKPKMNSK", "A#");
        java.lang.String str18 = soundex1.soundex("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
    }

    @Test
    public void test2224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2224");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        java.lang.String str9 = metaphone0.metaphone("A111111111");
        metaphone0.setMaxCodeLen(52);
        java.lang.String str13 = metaphone0.metaphone("A ");
        boolean boolean16 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: i0a", "O09401030308083060308306090530160809315383");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A" + "'", str13, "A");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2225");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex4.getMaxLength();
        java.lang.String str7 = soundex4.encode("");
        java.lang.Class<?> wildcardClass8 = soundex4.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test2226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2226");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.caverphone("O941");
        java.lang.String str14 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
        boolean boolean17 = caverphone0.isCaverphoneEqual("ARK", "A313");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKKMNSKT" + "'", str14, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test2227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2227");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = (byte) 10;
        doubleMetaphone0.maxCodeLen = 3;
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone0.new DoubleMetaphoneResult((int) '0');
        char char24 = doubleMetaphone0.charAt("ORKPXKMNSKTKNKTRKSK", 7);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone25 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str27 = doubleMetaphone25.doubleMetaphone("H");
        doubleMetaphone25.setMaxCodeLen((int) (byte) 0);
        java.lang.String str32 = doubleMetaphone25.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult34 = doubleMetaphone25.new DoubleMetaphoneResult(0);
        int int35 = doubleMetaphone25.maxCodeLen;
        java.lang.String str37 = doubleMetaphone25.encode("");
        int int40 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone25, "O09315383638369315893153836383693158", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.Object obj41 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str44 = doubleMetaphone0.doubleMetaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO", false);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + 'N' + "'", char24 == 'N');
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "ARK" + "'", obj41, "ARK");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "ARK" + "'", str44, "ARK");
    }

    @Test
    public void test2228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2228");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        boolean boolean12 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "AKPK");
        java.lang.String str14 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str18 = metaphone0.metaphone("");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ORK" + "'", str14, "ORK");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
    }

    @Test
    public void test2229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2229");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str9 = metaphone0.metaphone("4");
        java.lang.String str11 = metaphone0.encode("ARKPKKMNSK");
        int int12 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "4" + "'", str9, "4");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test2230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2230");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (byte) 100);
        int int15 = soundex1.getMaxLength();
        int int16 = soundex1.getMaxLength();
        java.lang.String str18 = soundex1.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str20 = soundex1.encode("A09315383");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O941" + "'", str18, "O941");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "A000" + "'", str20, "A000");
    }

    @Test
    public void test2231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2231");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        int int14 = metaphone0.getMaxCodeLen();
        boolean boolean17 = metaphone0.isMetaphoneEqual("AKPKMNSKT", "AKPKMNSKT");
        java.lang.String str19 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ORKPXKMNSK" + "'", str19, "ORKPXKMNSK");
    }

    @Test
    public void test2232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2232");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str13 = metaphone0.encode("A1");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = '\000';
        boolean boolean19 = doubleMetaphone14.isDoubleMetaphoneEqual("ORKP", "H");
        java.lang.Object obj20 = metaphone0.encode((java.lang.Object) "H");
        int int23 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "A000", "Aa");
        boolean boolean26 = metaphone0.isMetaphoneEqual("", "ORK1");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A" + "'", str13, "A");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "H" + "'", obj20, "H");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test2233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2233");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        int int4 = soundex1.getMaxLength();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char7 = refinedSoundex5.getMappingCode('a');
        int int10 = refinedSoundex5.difference("", "hi!");
        int int13 = refinedSoundex5.difference("hi!", "");
        char char15 = refinedSoundex5.getMappingCode('#');
        char char17 = refinedSoundex5.getMappingCode('a');
        java.lang.String str19 = refinedSoundex5.soundex("org.apache.commons.codec.EncoderException: A0");
        java.lang.Object obj20 = soundex1.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A0");
        java.lang.String str22 = soundex1.encode("H");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(refinedSoundex5);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '0' + "'", char17 == '0');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0940103030808306030830609053016080" + "'", str19, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "O621" + "'", obj20, "O621");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "H000" + "'", str22, "H000");
    }

    @Test
    public void test2234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2234");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "H");
        metaphone0.setMaxCodeLen((int) '6');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2235");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.encode("A111111111O000");
        java.lang.String str9 = refinedSoundex5.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A0" + "'", str7, "A0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O06201020205052030205203060201305062125232523621256212523252362125621" + "'", str9, "O06201020205052030205203060201305062125232523621256212523252362125621");
    }

    @Test
    public void test2236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2236");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A200", "ARKPKSKMNSKTKNKTRKSPKSNRKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test2237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2237");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.String str16 = metaphone0.metaphone("A");
        int int17 = metaphone0.getMaxCodeLen();
        int int18 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone19 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str21 = doubleMetaphone19.doubleMetaphone("H");
        doubleMetaphone19.setMaxCodeLen((int) (byte) 0);
        java.lang.String str26 = doubleMetaphone19.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult28 = doubleMetaphone19.new DoubleMetaphoneResult(0);
        int int29 = doubleMetaphone19.maxCodeLen;
        java.lang.String str31 = doubleMetaphone19.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = metaphone0.encode((java.lang.Object) doubleMetaphone19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test2238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2238");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderExca", "org.apache.commons.codec.EncoderExca");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test2239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2239");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("R", "HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2240");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        int int15 = doubleMetaphone0.maxCodeLen;
        int int16 = doubleMetaphone0.maxCodeLen;
        java.lang.String str18 = doubleMetaphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        boolean boolean21 = doubleMetaphone0.isDoubleMetaphoneEqual("O", "ORKPXKMNSKTKNKTRKSSPXNRKP");
        char char24 = doubleMetaphone0.charAt("A0313836", (int) ' ');
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "org.apache.commons.codec.EncoderException: A0931383", "A621");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKPKSKMNS" + "'", str18, "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test2241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2241");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("O093", "AKP1111111");
        boolean boolean19 = caverphone0.isCaverphoneEqual("A0", "H000");
        boolean boolean22 = caverphone0.isCaverphoneEqual("AKPKKMNSKT", "org.apache.commons.codec.EncoderException: O");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test2242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2242");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AA11111111");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex31 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char33 = refinedSoundex31.getMappingCode('a');
        int int36 = refinedSoundex31.difference("", "hi!");
        char char38 = refinedSoundex31.getMappingCode('0');
        char char40 = refinedSoundex31.getMappingCode('a');
        java.lang.String str42 = refinedSoundex31.soundex("1111111111");
        int int45 = refinedSoundex31.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone46 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone46.maxCodeLen = '\000';
        doubleMetaphone46.setMaxCodeLen(4);
        java.lang.String str52 = doubleMetaphone46.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj53 = refinedSoundex31.encode((java.lang.Object) str52);
        java.lang.Object obj54 = caverphone0.encode((java.lang.Object) str52);
        java.lang.String str56 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA");
        java.lang.String str58 = caverphone0.encode("OA1111111114r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AA11111111" + "'", str30, "AA11111111");
        org.junit.Assert.assertNotNull(refinedSoundex31);
        org.junit.Assert.assertTrue("'" + char33 + "' != '" + '0' + "'", char33 == '0');
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + char38 + "' != '" + '\000' + "'", char38 == '\000');
        org.junit.Assert.assertTrue("'" + char40 + "' != '" + '0' + "'", char40 == '0');
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 35 + "'", int45 == 35);
        org.junit.Assert.assertEquals("'" + str52 + "' != '" + "ARKP" + "'", str52, "ARKP");
        org.junit.Assert.assertEquals("'" + obj53 + "' != '" + "A0931" + "'", obj53, "A0931");
        org.junit.Assert.assertEquals("'" + obj54 + "' != '" + "AKP1111111" + "'", obj54, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str56 + "' != '" + "AKPKKMNSKT" + "'", str56, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "AA11111111" + "'", str58, "AA11111111");
    }

    @Test
    public void test2243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2243");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone0.maxCodeLen = '0';
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("A", true);
        boolean boolean13 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621", false);
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A031", "ORKPXKMNSKTKNKTRKSSPXNH");
        java.lang.String str19 = doubleMetaphone0.doubleMetaphone("org.apache.commons.codec.EncoderException: ORKP", false);
        doubleMetaphone0.setMaxCodeLen(10);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ARKPXKMNSKTKNKTRKSPXNRKP" + "'", str19, "ARKPXKMNSKTKNKTRKSPXNRKP");
    }

    @Test
    public void test2244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2244");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        java.lang.String str23 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str25 = metaphone0.metaphone("O0940103030808306030830609053016080313836");
        metaphone0.setMaxCodeLen(1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str23, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "O" + "'", str25, "O");
    }

    @Test
    public void test2245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2245");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int3 = soundex0.getMaxLength();
        int int6 = soundex0.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "A09315383");
        java.lang.String str8 = soundex0.encode("O09315383638369315893153836383693158931");
        int int11 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex0, "org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080940103030808306030830609053016080", "org.apache.commons.codec.EncoderException:  ");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O000" + "'", str8, "O000");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test2246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2246");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        int int28 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "", "");
        java.lang.String str30 = caverphone0.encode(" A621A0931\000i");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AA11111111" + "'", str30, "AA11111111");
    }

    @Test
    public void test2247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2247");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONARKP", "KPKSKMNSKT");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test2248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2248");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        int int8 = refinedSoundex0.difference("i0a", "org.apache.commons.codec.EncoderException: A0");
        java.lang.String str10 = refinedSoundex0.soundex("ARKPKKMNSKTKNKTRKSPXNRKP");
        int int13 = refinedSoundex0.difference("A200", "A111111111");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A09313836383693158931" + "'", str10, "A09313836383693158931");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test2249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2249");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str16 = soundex1.soundex("O0931");
        java.lang.String str18 = soundex1.encode("org.apache.commons.codec.EncoderException: ARKP");
        int int21 = soundex1.difference("AKPK111111", "A111111111e");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O000" + "'", str16, "O000");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O941" + "'", str18, "O941");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test2250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2250");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.encode("01230120022455012623010202");
        char char13 = refinedSoundex0.getMappingCode('8');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
    }

    @Test
    public void test2251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2251");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode('0');
        java.lang.String str9 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: 4");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O094010303080830603083060905301608" + "'", str9, "O094010303080830603083060905301608");
    }

    @Test
    public void test2252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2252");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.soundex("1111111111");
        java.lang.String str10 = soundex4.soundex("AKPKMNSKT1");
        java.lang.String str12 = soundex4.soundex(" ");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A212" + "'", str10, "A212");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test2253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2253");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str14 = metaphone0.encode("A1");
        java.lang.String str16 = metaphone0.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAO");
        int int17 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test2254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2254");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        int int9 = soundex0.getMaxLength();
        java.lang.String str11 = soundex0.encode("");
        java.lang.String str13 = soundex0.encode("O0931");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex0, "", "RKPXKMNSKTKNKTRKSSPXNRKP");
        java.lang.String str18 = soundex0.encode("0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O000" + "'", str13, "O000");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
    }

    @Test
    public void test2255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2255");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) (short) 0);
        int int8 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex();
        char char11 = refinedSoundex9.getMappingCode('0');
        int int14 = refinedSoundex9.difference("O0", "O0");
        java.lang.String str16 = refinedSoundex9.soundex("HI");
        java.lang.Object obj17 = doubleMetaphone0.encode((java.lang.Object) "HI");
        doubleMetaphone0.setMaxCodeLen(38);
        char char22 = doubleMetaphone0.charAt("hi!", 26);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '\000' + "'", char11 == '\000');
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "H0" + "'", str16, "H0");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "" + "'", obj17, "");
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
    }

    @Test
    public void test2256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2256");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str14 = refinedSoundex0.soundex("H0");
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "ORGAPACHECOMMONSCODECENCODEREXCEPTION", "O0940103030808306030830609053016080931");
        int int20 = refinedSoundex0.difference("org.apache.commons.codec.EncoderExc", "A621HI0A093138363836931589313836383693158M5");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "H0" + "'", str14, "H0");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test2257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2257");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.encode("ARKPXKMNSKTKNKTRKS");
        java.lang.String str8 = soundex4.soundex("A621");
        java.lang.String str10 = soundex4.soundex("A093138363836931589313836383693158");
        int int13 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex4, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "");
        java.lang.String str15 = soundex4.soundex("O0931538363836931589313836383693138");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("A");
        java.lang.String str24 = caverphone16.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str26 = caverphone16.encode("hi!");
        java.lang.Object obj28 = caverphone16.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        boolean boolean31 = caverphone16.isCaverphoneEqual("AKPKKMNSKT", "A0931383");
        boolean boolean34 = caverphone16.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTION", "AKPKSKMNSK");
        boolean boolean37 = caverphone16.isCaverphoneEqual(" AKPKMNSKTK", "");
        java.lang.Object obj38 = soundex4.encode((java.lang.Object) " AKPKMNSKTK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A621" + "'", str6, "A621");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O000" + "'", str15, "O000");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A111111111" + "'", str22, "A111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "AA11111111" + "'", str26, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "AKPKKMNSKT" + "'", obj28, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertEquals("'" + obj38 + "' != '" + "A212" + "'", obj38, "A212");
    }

    @Test
    public void test2258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2258");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO", "org.apache.commons.codec.EncoderException: HI");
        java.lang.Class<?> wildcardClass20 = refinedSoundex0.getClass();
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test2259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2259");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A000 1", "ORGAPACHECOMMONSCODECENCODEREXCEPTION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2260");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex8.setMaxLength((int) '1');
        int int11 = soundex8.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex8.soundex("O09315383638369315893153836383693158");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 49 + "'", int11 == 49);
    }

    @Test
    public void test2261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2261");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        int int19 = refinedSoundex0.difference("1111111111", "O621");
        char char21 = refinedSoundex0.getMappingCode('r');
        int int24 = refinedSoundex0.difference(" org.apache.commons.codec.EncoderException: AA111", "O620");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '9' + "'", char21 == '9');
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
    }

    @Test
    public void test2262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2262");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str8 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        int int9 = metaphone0.getMaxCodeLen();
        int int10 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKPXKMNSK" + "'", str8, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test2263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2263");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "A111111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2264");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('4');
        org.apache.commons.codec.language.Metaphone metaphone7 = new org.apache.commons.codec.language.Metaphone();
        metaphone7.setMaxCodeLen(3);
        java.lang.String str11 = metaphone7.encode("");
        int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone7, "hi!", "");
        metaphone7.setMaxCodeLen(0);
        java.lang.String str18 = metaphone7.encode("AK11111111");
        java.lang.String str20 = metaphone7.encode("A1");
        java.lang.String str22 = metaphone7.metaphone("A000");
        java.lang.String str24 = metaphone7.metaphone("ORKPXKMNSKTKNKTRKSSPXN");
        java.lang.Object obj25 = refinedSoundex4.encode((java.lang.Object) str24);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str27 = refinedSoundex4.encode("A621HI0A093138363836931589313836383693158g");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
    }

    @Test
    public void test2265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2265");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A ");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) "A ");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A1", "O941");
        java.lang.String str19 = metaphone0.metaphone("AKPKMNSKT1");
        int int20 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "A" + "'", obj14, "A");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSKT" + "'", str19, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
    }

    @Test
    public void test2266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2266");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("H", "A");
        char char13 = refinedSoundex0.getMappingCode('A');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = 0;
        char char19 = doubleMetaphone14.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone14.new DoubleMetaphoneResult((int) '#');
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult23 = doubleMetaphone14.new DoubleMetaphoneResult((-1));
        doubleMetaphone14.maxCodeLen = (-1);
        int int26 = doubleMetaphone14.maxCodeLen;
        java.lang.Class<?> wildcardClass27 = doubleMetaphone14.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = refinedSoundex0.encode((java.lang.Object) wildcardClass27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test2267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2267");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        int int22 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A ", "A1111111114r");
        org.apache.commons.codec.language.Soundex soundex23 = new org.apache.commons.codec.language.Soundex();
        int int24 = soundex23.getMaxLength();
        soundex23.setMaxLength(65);
        int int29 = soundex23.difference("  ", "org.apache.commons.codec.EncoderException: HI");
        java.lang.String str31 = soundex23.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Object obj32 = refinedSoundex0.encode((java.lang.Object) str31);
        java.lang.String str34 = refinedSoundex0.soundex("O0931");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "O621" + "'", str31, "O621");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "O0" + "'", obj32, "O0");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "O0" + "'", str34, "O0");
    }

    @Test
    public void test2268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2268");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AKPKMNSK11");
        boolean boolean33 = caverphone0.isCaverphoneEqual("AKPKSKMNS", "O");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKMNSK11" + "'", str30, "AKPKMNSK11");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test2269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2269");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        java.lang.String str19 = caverphone0.caverphone("ARKPXKMNSK");
        java.lang.String str21 = caverphone0.caverphone("O620ORGAPACHECOMMONSCODECENCODER");
        java.lang.String str23 = caverphone0.caverphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSK11" + "'", str19, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKKMNSKT" + "'", str21, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
    }

    @Test
    public void test2270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2270");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.soundex("");
        int int16 = refinedSoundex0.difference("O621", "A111111111");
        java.lang.String str18 = refinedSoundex0.encode("A062125232523621256212523252362125");
        char char20 = refinedSoundex0.getMappingCode('T');
        int int23 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "O06201020205052030205203060201305062125232523621256212523252362125621");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A0" + "'", str18, "A0");
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '6' + "'", char20 == '6');
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
    }

    @Test
    public void test2271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2271");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        char char9 = refinedSoundex4.getMappingCode('a');
        int int12 = refinedSoundex4.difference("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "H000");
        java.lang.String str14 = refinedSoundex4.soundex("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test2272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2272");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("ORKP", "");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "org.apache.commons.codec.EncoderExc", "A1111111114r");
        int int13 = soundex1.difference("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125", "O09401030308083060308306090530160809315383");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "org.apache.commons.codec.EncoderException: A#");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test2273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2273");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        boolean boolean7 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ARK", "A");
        java.lang.String str9 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: hi!");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
    }

    @Test
    public void test2274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2274");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean13 = caverphone0.isCaverphoneEqual("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        boolean boolean16 = caverphone0.isCaverphoneEqual("O0940103030808306030830609053016080940103030808306030830609053016080", "ORKPXKMNSKTKNKTRKSSPXN");
        java.lang.String str18 = caverphone0.caverphone("A062125232523621256212523252362125");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A111111111" + "'", str18, "A111111111");
    }

    @Test
    public void test2275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2275");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean10 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        metaphone0.setMaxCodeLen((int) 'a');
        metaphone0.setMaxCodeLen((int) (short) 1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test2276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2276");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode('i');
        java.lang.String str9 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O0940103030808306030830609053016080" + "'", str9, "O0940103030808306030830609053016080");
    }

    @Test
    public void test2277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2277");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str7 = soundex2.encode("ORKPXKMNSKTKNKTRKSSPXN");
        int int10 = soundex2.difference("ARKPXKMNSKTSNKTRKSPXNRKPXKMNSKTSNKTRKSPXNRKPKSKMNSK", "ARKPXKMNSK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O621" + "'", str7, "O621");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test2278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2278");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        java.lang.String str4 = metaphone0.encode("A621");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "org.apache.commons.codec.EncoderException:  ", "");
        java.lang.String str9 = metaphone0.encode("AR");
        metaphone0.setMaxCodeLen((int) 'S');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AR" + "'", str9, "AR");
    }

    @Test
    public void test2279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2279");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.caverphone("AKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKP1111111" + "'", str10, "AKP1111111");
    }

    @Test
    public void test2280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2280");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str12 = metaphone10.encode("");
        java.lang.Object obj13 = metaphone0.encode((java.lang.Object) "");
        metaphone0.setMaxCodeLen((int) '#');
        metaphone0.setMaxCodeLen((int) 'O');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "" + "'", obj13, "");
    }

    @Test
    public void test2281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2281");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        boolean boolean15 = caverphone0.isCaverphoneEqual("AKPKKMNSKT", "A0931383");
        boolean boolean18 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTION", "AKPKSKMNSK");
        boolean boolean21 = caverphone0.isCaverphoneEqual(" AKPKMNSKTK", "");
        boolean boolean24 = caverphone0.isCaverphoneEqual("", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test2282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2282");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "H000");
        java.lang.String str16 = refinedSoundex0.encode("O620");
        java.lang.String str18 = refinedSoundex0.encode("ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O0" + "'", str16, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A093153836383693158" + "'", str18, "A093153836383693158");
    }

    @Test
    public void test2283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2283");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        char char13 = refinedSoundex0.getMappingCode('4');
        java.lang.String str15 = refinedSoundex0.soundex("");
        java.lang.String str17 = refinedSoundex0.encode("");
        java.lang.String str19 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        char char21 = refinedSoundex0.getMappingCode('r');
        java.lang.String str23 = refinedSoundex0.soundex("1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0940103030808306030830609053016080931" + "'", str19, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '9' + "'", char21 == '9');
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
    }

    @Test
    public void test2284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2284");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        java.lang.String str14 = soundex3.encode("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        int int15 = soundex3.getMaxLength();
        java.lang.String str17 = soundex3.soundex("K000");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O621" + "'", str14, "O621");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "K000" + "'", str17, "K000");
    }

    @Test
    public void test2285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2285");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: hi!");
        int int17 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Caverphone caverphone18 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str20 = caverphone18.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj21 = metaphone0.encode((java.lang.Object) str20);
        int int22 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNH" + "'", str16, "ORKPXKMNSKTKNKTRKSSPXNH");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "AKPKMNSKT" + "'", obj21, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
    }

    @Test
    public void test2286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2286");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.caverphone("A111111111e");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
    }

    @Test
    public void test2287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2287");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        java.lang.String str21 = refinedSoundex0.encode("H0");
        java.lang.String str23 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: I");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "H0" + "'", str21, "H0");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "O0940103030808306030830609053016080" + "'", str23, "O0940103030808306030830609053016080");
    }

    @Test
    public void test2288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2288");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AA11111111", "ARKPXKMNSKTKNKTRKSPXNKPK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test2289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2289");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int9 = soundex4.difference("AKP1111111", "AKPK");
        int int12 = soundex4.difference("org.apache.commons.codec.EncoderException: ", "ARKP");
        java.lang.String str14 = soundex4.soundex("A111111111e");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A000" + "'", str14, "A000");
    }

    @Test
    public void test2290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2290");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        int int21 = metaphone0.getMaxCodeLen();
        boolean boolean24 = metaphone0.isMetaphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTION");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test2291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2291");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        java.lang.String str13 = caverphone0.encode("HI");
        java.lang.String str15 = caverphone0.encode(" 1");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AA11111111" + "'", str13, "AA11111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
    }

    @Test
    public void test2292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2292");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: O");
        java.lang.String str4 = refinedSoundex0.encode("R");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "O0940103030808306030830609053016080" + "'", str2, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "R9" + "'", str4, "R9");
    }

    @Test
    public void test2293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2293");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int13 = soundex0.difference("AKPKMNSKTK", "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        soundex0.setMaxLength((int) 'T');
        soundex0.setMaxLength(43);
        java.lang.String str19 = soundex0.encode(" AKP1111111 ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A210" + "'", str19, "A210");
    }

    @Test
    public void test2294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2294");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        int int22 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
    }

    @Test
    public void test2295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2295");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = '\000';
        doubleMetaphone0.setMaxCodeLen(4);
        java.lang.String str6 = doubleMetaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str8 = doubleMetaphone0.encode("AKPKKMNSKT");
        java.lang.String str11 = doubleMetaphone0.doubleMetaphone("org.apache.commons.codec.EncoderException: HI", true);
        int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ARKPKSKMNSKTSNKTRKSPKSN", "org.apache.commons.codec.EncoderException: H000");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "ARKP" + "'", str6, "ARKP");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPK" + "'", str8, "AKPK");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ARKP" + "'", str11, "ARKP");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test2296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2296");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str30 = caverphone0.caverphone("A0313");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "A111111111" + "'", str30, "A111111111");
    }

    @Test
    public void test2297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2297");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.soundex("A0313836");
        int int11 = soundex0.getMaxLength();
        int int14 = soundex0.difference("H0", "ARKPKSKMNSK");
        java.lang.String str16 = soundex0.encode("O094010303080830603083060905301608093");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O000" + "'", str16, "O000");
    }

    @Test
    public void test2298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2298");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        char char12 = refinedSoundex0.getMappingCode('\000');
        java.lang.String str14 = refinedSoundex0.encode("");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test2299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2299");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str15 = caverphone0.caverphone("");
        java.lang.String str17 = caverphone0.encode("A#");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
    }

    @Test
    public void test2300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2300");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        int int12 = refinedSoundex0.difference("O0940103030808306030830609053016080940103030808306030830609053016080931", "AKP1111111");
        int int15 = refinedSoundex0.difference("", "A ");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str18 = doubleMetaphone16.doubleMetaphone("H");
        doubleMetaphone16.setMaxCodeLen((int) (byte) 0);
        boolean boolean24 = doubleMetaphone16.isDoubleMetaphoneEqual("O0931", "", false);
        java.lang.String str27 = doubleMetaphone16.doubleMetaphone("O0", false);
        java.lang.String str29 = doubleMetaphone16.doubleMetaphone("org.apache.commons.codec.EncoderException: AA11111111");
        java.lang.String str31 = doubleMetaphone16.doubleMetaphone("ARKPXKMNSKTKNKTRKSPXNRKP");
        boolean boolean35 = doubleMetaphone16.isDoubleMetaphoneEqual("AKPKMNSK", "AKPKMNSKT", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = refinedSoundex0.encode((java.lang.Object) boolean35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test2301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2301");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('\000');
        // The following exception was thrown during execution in test generation
        try {
            int int9 = refinedSoundex4.difference("01230120022455012623010202", "ARKPXKMNSKTKNKTRKSPXNKPK");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
    }

    @Test
    public void test2302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2302");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        java.lang.String str12 = soundex1.encode("O620ORGAPACHECOMMONSCODECENCODER");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O941" + "'", str12, "O941");
    }

    @Test
    public void test2303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2303");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength((int) '\000');
        java.lang.Object obj8 = soundex4.encode((java.lang.Object) "AKPKMNSKTK");
        java.lang.String str10 = soundex4.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + obj8 + "' != '" + "A212" + "'", obj8, "A212");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O621" + "'", str10, "O621");
    }

    @Test
    public void test2304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2304");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        java.lang.Object obj11 = metaphone0.encode((java.lang.Object) "A ");
        java.lang.String str13 = metaphone0.encode("org.apache.commons.codec.EncoderException: hi!");
        boolean boolean16 = metaphone0.isMetaphoneEqual("AHIO", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertEquals("'" + obj11 + "' != '" + "A" + "'", obj11, "A");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ORK" + "'", str13, "ORK");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2305");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('\000');
        java.lang.Object obj14 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = refinedSoundex0.encode(obj14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
    }

    @Test
    public void test2306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2306");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A000");
        java.lang.String str8 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ARKP");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "A09");
        java.lang.String str13 = caverphone0.encode("A02125232");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
    }

    @Test
    public void test2307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2307");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        char char5 = refinedSoundex3.getMappingCode('O');
        java.lang.String str7 = refinedSoundex3.soundex("A0931383");
        int int10 = refinedSoundex3.difference("", "AKP1111111");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A0" + "'", str7, "A0");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test2308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2308");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("org.apache.commons.codec.EncoderException: A#");
        boolean boolean14 = caverphone0.isCaverphoneEqual("A310", "O");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test2309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2309");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "H");
        java.lang.String str18 = metaphone0.encode("A093138363836931589313836383693158");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: AK11111111", "a");
        java.lang.String str23 = metaphone0.metaphone("ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone24 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str26 = doubleMetaphone24.doubleMetaphone("H");
        doubleMetaphone24.setMaxCodeLen((int) (byte) 0);
        java.lang.String str31 = doubleMetaphone24.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult33 = doubleMetaphone24.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult33.append('#', 'a');
        doubleMetaphoneResult33.append('O');
        doubleMetaphoneResult33.append("O621", "org.apache.commons.codec.EncoderException: A0");
        doubleMetaphoneResult33.append('S');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj44 = metaphone0.encode((java.lang.Object) 'S');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test2310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2310");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        boolean boolean13 = caverphone0.isCaverphoneEqual("A111111111O000", "A0212523");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test2311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2311");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.encode("");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A800", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSKTSNKTRKSPKSNRKPR");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test2312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2312");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.metaphone("01230120022455012623010202");
        java.lang.String str7 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int8 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test2313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2313");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        boolean boolean9 = metaphone0.isMetaphoneEqual("O", "AKPKSKMNS1");
        java.lang.String str11 = metaphone0.metaphone("O621");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O" + "'", str11, "O");
    }

    @Test
    public void test2314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2314");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        char char21 = refinedSoundex0.getMappingCode('A');
        char char23 = refinedSoundex0.getMappingCode('T');
        java.lang.String str25 = refinedSoundex0.encode("");
        char char27 = refinedSoundex0.getMappingCode('H');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '0' + "'", char21 == '0');
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '6' + "'", char23 == '6');
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '0' + "'", char27 == '0');
    }

    @Test
    public void test2315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2315");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("ARKPKSKMNS");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "");
        boolean boolean14 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "A03");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKSKMNS1" + "'", str8, "AKPKSKMNS1");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test2316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2316");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("AKPKMNSKT1");
        java.lang.String str12 = caverphone0.caverphone("A0313836");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKMNSKT1" + "'", str10, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
    }

    @Test
    public void test2317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2317");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        soundex0.setMaxLength(0);
        soundex0.setMaxLength((int) (short) 0);
        int int12 = soundex0.difference("O0931", "ARKPKMNSKTKNKTRKSPKSNRKPKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test2318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2318");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str6 = soundex4.encode("ARKPXKMNSKTKNKTRKS");
        java.lang.String str8 = soundex4.soundex("A621");
        java.lang.String str10 = soundex4.soundex("A093138363836931589313836383693158");
        int int13 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex4, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "");
        java.lang.String str15 = soundex4.soundex("O0931538363836931589313836383693138");
        int int16 = soundex4.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A621" + "'", str6, "A621");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O000" + "'", str15, "O000");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test2319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2319");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex8.setMaxLength((int) '1');
        int int11 = soundex8.getMaxLength();
        int int12 = soundex8.getMaxLength();
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone13.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str19 = caverphone13.encode("");
        java.lang.String str21 = caverphone13.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone22.maxCodeLen = 0;
        char char27 = doubleMetaphone22.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult29 = doubleMetaphone22.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult29.appendAlternate('\000');
        java.lang.String str32 = doubleMetaphoneResult29.getAlternate();
        java.lang.String str33 = doubleMetaphoneResult29.getPrimary();
        java.lang.Object obj34 = caverphone13.encode((java.lang.Object) str33);
        java.lang.String str36 = caverphone13.caverphone("");
        int int39 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone13, "AKPKKMNSKT", "ORKP");
        boolean boolean42 = caverphone13.isCaverphoneEqual("", "HI");
        boolean boolean45 = caverphone13.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str47 = caverphone13.encode("A0");
        java.lang.String str49 = caverphone13.caverphone("");
        boolean boolean52 = caverphone13.isCaverphoneEqual("A031", "AKPKKMNSKT");
        boolean boolean55 = caverphone13.isCaverphoneEqual("O941", "A111111111O000");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj56 = soundex8.encode((java.lang.Object) boolean55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 49 + "'", int11 == 49);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 49 + "'", int12 == 49);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "1111111111" + "'", str19, "1111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "1111111111" + "'", str21, "1111111111");
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '\000' + "'", char27 == '\000');
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + obj34 + "' != '" + "1111111111" + "'", obj34, "1111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "A111111111" + "'", str47, "A111111111");
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "1111111111" + "'", str49, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test2320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2320");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.setMaxCodeLen(10);
        int int3 = doubleMetaphone0.maxCodeLen;
        java.lang.String str6 = doubleMetaphone0.doubleMetaphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0", true);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str9 = doubleMetaphone7.doubleMetaphone("H");
        doubleMetaphone7.setMaxCodeLen((int) (byte) 0);
        java.lang.String str14 = doubleMetaphone7.doubleMetaphone("1111111111", false);
        java.lang.String str17 = doubleMetaphone7.doubleMetaphone("hi!", false);
        java.lang.String str20 = doubleMetaphone7.doubleMetaphone("", true);
        doubleMetaphone7.setMaxCodeLen((int) 'O');
        boolean boolean26 = doubleMetaphone7.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: 01230120022455012623010202", "AKPKMNSK", true);
        java.lang.Object obj27 = doubleMetaphone0.encode((java.lang.Object) "AKPKMNSK");
        boolean boolean31 = doubleMetaphone0.isDoubleMetaphoneEqual("AKPKMNSK", "AKPKMNSKT", false);
        boolean boolean34 = doubleMetaphone0.isDoubleMetaphoneEqual("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "AKPKSKMNS");
        org.apache.commons.codec.language.Metaphone metaphone35 = new org.apache.commons.codec.language.Metaphone();
        metaphone35.setMaxCodeLen(3);
        int int38 = metaphone35.getMaxCodeLen();
        boolean boolean41 = metaphone35.isMetaphoneEqual("", "");
        boolean boolean44 = metaphone35.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone35.setMaxCodeLen(0);
        int int47 = metaphone35.getMaxCodeLen();
        metaphone35.setMaxCodeLen((int) (short) 100);
        java.lang.String str51 = metaphone35.encode("ARKP");
        int int54 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone35, "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "O0931");
        boolean boolean57 = metaphone35.isMetaphoneEqual("ORKPXKMNSKTKNKTRKSSPXN", "O0940103030808306030830609053016080931");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj58 = doubleMetaphone0.encode((java.lang.Object) metaphone35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "ARKPKKMNSK" + "'", str6, "ARKPKKMNSK");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + "AKPKMNSK" + "'", obj27, "AKPKMNSK");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "ARKP" + "'", str51, "ARKP");
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test2321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2321");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        java.lang.String str12 = metaphone0.encode("ARKPXKMNSKTKNKTRKSPXN");
        int int13 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ARKPKSKMNS" + "'", str12, "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test2322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2322");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A ");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) "A ");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A1", "O941");
        java.lang.String str19 = metaphone0.metaphone("AKPKMNSKT1");
        java.lang.String str21 = metaphone0.encode("A ");
        java.lang.String str23 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSNi");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "A" + "'", obj14, "A");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSKT" + "'", str19, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A" + "'", str21, "A");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPKSKMNS" + "'", str23, "ORKPKSKMNS");
    }

    @Test
    public void test2323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2323");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("A111111111O620");
        java.lang.String str12 = metaphone0.encode("H000");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test2324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2324");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAO", "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2325");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORGAPACHECOMMONSCODECENCODEREXCEPTIONARKP", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2326");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        int int9 = soundex0.getMaxLength();
        soundex0.setMaxLength((int) (byte) -1);
        int int12 = soundex0.getMaxLength();
        int int15 = soundex0.difference("A#", "A621r");
        soundex0.setMaxLength((int) (byte) 0);
        java.lang.String str19 = soundex0.encode("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: AKPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O621" + "'", str19, "O621");
    }

    @Test
    public void test2327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2327");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int5 = soundex0.difference("A0", "");
        int int6 = soundex0.getMaxLength();
        java.lang.String str8 = soundex0.encode("A0313836");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
    }

    @Test
    public void test2328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2328");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("", "");
        metaphone0.setMaxCodeLen((int) 'H');
        java.lang.String str20 = metaphone0.encode("org.apache.commons.codec.EncoderException: A0931");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXN" + "'", str20, "ORKPXKMNSKTKNKTRKSSPXN");
    }

    @Test
    public void test2329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2329");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 100);
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "");
        int int10 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult12 = doubleMetaphone0.new DoubleMetaphoneResult(105);
        doubleMetaphone0.setMaxCodeLen(49);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test2330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2330");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char3 = refinedSoundex1.getMappingCode('a');
        int int6 = refinedSoundex1.difference("", "hi!");
        char char8 = refinedSoundex1.getMappingCode('#');
        java.lang.String str10 = refinedSoundex1.soundex("01230120022455012623010202");
        java.lang.String str12 = refinedSoundex1.encode("A621");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) str12);
        java.lang.String str15 = caverphone0.caverphone("A621");
        java.lang.String str17 = caverphone0.encode("O093");
        java.lang.String str19 = caverphone0.encode("ARK");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = caverphone0.encode((java.lang.Object) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex1);
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '0' + "'", char3 == '0');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0" + "'", str12, "A0");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "A111111111" + "'", obj13, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AK11111111" + "'", str19, "AK11111111");
    }

    @Test
    public void test2331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2331");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult9 = doubleMetaphone0.new DoubleMetaphoneResult(0);
        int int10 = doubleMetaphone0.maxCodeLen;
        java.lang.String str12 = doubleMetaphone0.encode("");
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O09315383638369315893153836383693158", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str18 = doubleMetaphone0.doubleMetaphone("", false);
        org.apache.commons.codec.language.Metaphone metaphone19 = new org.apache.commons.codec.language.Metaphone();
        metaphone19.setMaxCodeLen(3);
        int int22 = metaphone19.getMaxCodeLen();
        java.lang.String str24 = metaphone19.encode("hi!");
        java.lang.String str26 = metaphone19.encode("O621");
        java.lang.String str28 = metaphone19.metaphone("HI");
        metaphone19.setMaxCodeLen(0);
        java.lang.Class<?> wildcardClass31 = metaphone19.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = doubleMetaphone0.encode((java.lang.Object) wildcardClass31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "H" + "'", str24, "H");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "O" + "'", str26, "O");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "H" + "'", str28, "H");
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test2332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2332");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str7 = soundex1.encode("AHIO");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
    }

    @Test
    public void test2333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2333");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.soundex(" ");
        int int7 = refinedSoundex0.difference("", "org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        char char9 = refinedSoundex0.getMappingCode('a');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
    }

    @Test
    public void test2334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2334");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) '#');
        int int8 = doubleMetaphone0.getMaxCodeLen();
        java.lang.String str10 = doubleMetaphone0.encode("ORK");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "a4", "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test2335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2335");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = (byte) 10;
        doubleMetaphone0.maxCodeLen = 3;
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone0.new DoubleMetaphoneResult((int) '0');
        java.lang.String str23 = doubleMetaphone0.encode(" ");
        char[] charArray24 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex25 = new org.apache.commons.codec.language.Soundex(charArray24);
        java.lang.String str27 = soundex25.soundex("");
        soundex25.setMaxLength((int) (short) 0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = doubleMetaphone0.encode((java.lang.Object) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
    }

    @Test
    public void test2336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2336");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = 0;
        char char13 = doubleMetaphone8.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean17 = doubleMetaphone8.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone8.maxCodeLen = 3;
        java.lang.String str21 = doubleMetaphone8.doubleMetaphone(" ");
        int int22 = doubleMetaphone8.maxCodeLen;
        boolean boolean26 = doubleMetaphone8.isDoubleMetaphoneEqual("H000", "O093", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult28 = doubleMetaphone8.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult28.appendAlternate("A093153836383693");
        doubleMetaphoneResult28.appendPrimary('a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = soundex1.encode((java.lang.Object) doubleMetaphoneResult28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test2337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2337");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.encode("H");
        boolean boolean16 = caverphone0.isCaverphoneEqual("A111111111O620", "hi!");
        java.lang.String str18 = caverphone0.caverphone("01");
        boolean boolean21 = caverphone0.isCaverphoneEqual("A093153836383693158313", "AKPKSKMNS1");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "1111111111" + "'", str18, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test2338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2338");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.Object obj32 = caverphone0.encode((java.lang.Object) "AKPKMNSKT1");
        java.lang.String str34 = caverphone0.caverphone("O0940103030808306030830609053016080931");
        int int37 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str39 = caverphone0.caverphone("A0");
        java.lang.String str41 = caverphone0.encode("A ");
        java.lang.String str43 = caverphone0.caverphone("AKP1111111");
        java.lang.String str45 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: 4");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "AKPKMNSKT1" + "'", obj32, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "A111111111" + "'", str39, "A111111111");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "A111111111" + "'", str41, "A111111111");
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "AKP1111111" + "'", str43, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "AKPKKMNSKT" + "'", str45, "AKPKKMNSKT");
    }

    @Test
    public void test2339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2339");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONARKP", "I");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test2340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2340");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("ARKPXKMNSKTSNKTRKSPXN");
        boolean boolean17 = metaphone0.isMetaphoneEqual("O620#", "A931");
        java.lang.String str19 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ARK" + "'", str14, "ARK");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ORK" + "'", str19, "ORK");
    }

    @Test
    public void test2341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2341");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AKPKSKMNS1", "ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test2342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2342");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.encode("A1");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "", "O000");
        java.lang.String str18 = refinedSoundex0.encode("O09315383638369315893153836383693158");
        char char20 = refinedSoundex0.getMappingCode('o');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone21 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone21.maxCodeLen = 0;
        char char26 = doubleMetaphone21.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult28 = doubleMetaphone21.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult28.appendPrimary('#');
        doubleMetaphoneResult28.appendAlternate('o');
        java.lang.Class<?> wildcardClass33 = doubleMetaphoneResult28.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = refinedSoundex0.encode((java.lang.Object) wildcardClass33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0" + "'", str13, "A0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0" + "'", str18, "O0");
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '0' + "'", char20 == '0');
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '\000' + "'", char26 == '\000');
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test2343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2343");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        java.lang.String str18 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str20 = metaphone0.encode("A111111111O620");
        boolean boolean23 = metaphone0.isMetaphoneEqual("ARKPXKMNSKTKNKTRKS", "org.apache.commons.codec.EncoderException: O000");
        int int24 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORKPXKMNSK" + "'", str18, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "A" + "'", str20, "A");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
    }

    @Test
    public void test2344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2344");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORK1", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test2345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2345");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("A0931");
        char char26 = refinedSoundex0.getMappingCode('1');
        char char28 = refinedSoundex0.getMappingCode('i');
        char char30 = refinedSoundex0.getMappingCode('a');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A0" + "'", str24, "A0");
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '\000' + "'", char26 == '\000');
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '0' + "'", char28 == '0');
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + '0' + "'", char30 == '0');
    }

    @Test
    public void test2346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2346");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        char char16 = doubleMetaphone9.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone9.new DoubleMetaphoneResult((int) '4');
        java.lang.String str19 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) str19);
        boolean boolean23 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: 01230120022455012623010202", "org.apache.commons.codec.EncoderException: A111111111O620");
        boolean boolean26 = caverphone0.isCaverphoneEqual("ARKPKKMNSKTKNKTRKSPXNRKP", "4");
        boolean boolean29 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + 'i' + "'", char16 == 'i');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "1111111111" + "'", obj20, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test2347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2347");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        int int12 = refinedSoundex5.difference(" ", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean22 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone13.maxCodeLen = 3;
        java.lang.String str26 = doubleMetaphone13.doubleMetaphone(" ");
        java.lang.Object obj27 = refinedSoundex5.encode((java.lang.Object) " ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str29 = refinedSoundex5.encode(" org.apache.commons.codec.EncoderException: ORGAP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + "" + "'", obj27, "");
    }

    @Test
    public void test2348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2348");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength(100);
        int int10 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int13 = soundex1.difference("O09315383", "org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test2349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2349");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        boolean boolean12 = metaphone0.isMetaphoneEqual("A0", "");
        java.lang.String str14 = metaphone0.encode("K31");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test2350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2350");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: A621HI", "org.apache.commons.codec.EncoderException: H000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test2351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2351");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        int int3 = soundex0.difference("H", "");
        int int4 = soundex0.getMaxLength();
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN", "AKPKMNSK11");
        int int11 = soundex0.difference("01230120022455012623010202", "A200");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test2352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2352");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        boolean boolean7 = metaphone0.isMetaphoneEqual("i0a", "  ");
        java.lang.String str9 = metaphone0.encode("ARKPXKMNSKTKNKTRKSPXNRKP");
        metaphone0.setMaxCodeLen((int) 'K');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ARKP" + "'", str9, "ARKP");
    }

    @Test
    public void test2353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2353");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        char char9 = refinedSoundex4.getMappingCode('a');
        char char11 = refinedSoundex4.getMappingCode('1');
        java.lang.String str13 = refinedSoundex4.encode(" AKPK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '\000' + "'", char11 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0212" + "'", str13, "A0212");
    }

    @Test
    public void test2354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2354");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        java.lang.String str21 = refinedSoundex0.encode("H0");
        org.apache.commons.codec.language.Soundex soundex22 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str24 = soundex22.encode("ARKP");
        java.lang.String str26 = soundex22.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int27 = soundex22.getMaxLength();
        soundex22.setMaxLength(0);
        soundex22.setMaxLength((int) (short) 0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = refinedSoundex0.encode((java.lang.Object) soundex22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "H0" + "'", str21, "H0");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A621" + "'", str24, "A621");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "O621" + "'", str26, "O621");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
    }

    @Test
    public void test2355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2355");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "O09401030308083060308306090530160809315383638369315893153836383693158931", "org.apache.commons.codec.EncoderException: hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test2356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2356");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int4 = soundex3.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone5 = new org.apache.commons.codec.language.Metaphone();
        metaphone5.setMaxCodeLen(3);
        int int8 = metaphone5.getMaxCodeLen();
        boolean boolean11 = metaphone5.isMetaphoneEqual("", "");
        boolean boolean14 = metaphone5.isMetaphoneEqual("01230120022455012623010202", "");
        java.lang.String str16 = metaphone5.metaphone("01230120022455012623010202");
        java.lang.Object obj17 = soundex3.encode((java.lang.Object) "01230120022455012623010202");
        java.lang.String str19 = soundex3.encode("H0");
        soundex3.setMaxLength((int) 'H');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "" + "'", obj17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "H000" + "'", str19, "H000");
    }

    @Test
    public void test2357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2357");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        int int11 = doubleMetaphone0.maxCodeLen;
        boolean boolean14 = doubleMetaphone0.isDoubleMetaphoneEqual("RKPK", "A000a");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test2358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2358");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.soundex("HI");
        java.lang.String str9 = refinedSoundex0.encode("hi!");
        int int12 = refinedSoundex0.difference("A621", "");
        java.lang.String str14 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str16 = refinedSoundex0.soundex("A1111111114r");
        int int19 = refinedSoundex0.difference("ORKPXKMNSK", "4");
        int int22 = refinedSoundex0.difference("Aa", "R");
        int int25 = refinedSoundex0.difference("K120", "org.apache.commons.codec.EncoderExc");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H0" + "'", str9, "H0");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O0940103030808306030830609053016080" + "'", str14, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A09" + "'", str16, "A09");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test2359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2359");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = 0;
        char char19 = doubleMetaphone14.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean23 = doubleMetaphone14.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone14.maxCodeLen = 3;
        java.lang.String str27 = doubleMetaphone14.encode("A111111111");
        java.lang.Object obj28 = refinedSoundex0.encode((java.lang.Object) str27);
        char char30 = refinedSoundex0.getMappingCode('4');
        int int33 = refinedSoundex0.difference("O941", "org.apache.commons.codec.EncoderException: A0");
        java.lang.String str35 = refinedSoundex0.encode("a");
        int int38 = refinedSoundex0.difference("AKPKMNSKTK", "O094010303080830603083060905301608093");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A" + "'", str27, "A");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "A0" + "'", obj28, "A0");
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + '\000' + "'", char30 == '\000');
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "A0" + "'", str35, "A0");
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test2360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2360");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        int int3 = soundex0.getMaxLength();
        int int4 = soundex0.getMaxLength();
        int int5 = soundex0.getMaxLength();
        soundex0.setMaxLength(56);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test2361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2361");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("");
        java.lang.String str29 = caverphone0.encode("A#");
        boolean boolean32 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " org.apache.commons.codec.EncoderException: ORGAP");
        java.lang.String str34 = caverphone0.caverphone("O0931538363836931589313836383693138");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "1111111111" + "'", str27, "1111111111");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
    }

    @Test
    public void test2362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2362");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        java.lang.String str29 = refinedSoundex0.soundex("AKPKMNSK");
        java.lang.String str31 = refinedSoundex0.encode("K31");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone32 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone32.maxCodeLen = 0;
        char char37 = doubleMetaphone32.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult39 = doubleMetaphone32.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult39.appendAlternate('\000');
        doubleMetaphoneResult39.append('#');
        java.lang.String str44 = doubleMetaphoneResult39.getAlternate();
        doubleMetaphoneResult39.appendPrimary('1');
        doubleMetaphoneResult39.appendAlternate('4');
        doubleMetaphoneResult39.append('#');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj51 = refinedSoundex0.encode((java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A031383" + "'", str29, "A031383");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "K3" + "'", str31, "K3");
        org.junit.Assert.assertTrue("'" + char37 + "' != '" + '\000' + "'", char37 == '\000');
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
    }

    @Test
    public void test2363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2363");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Metaphone metaphone7 = new org.apache.commons.codec.language.Metaphone();
        metaphone7.setMaxCodeLen(3);
        java.lang.String str11 = metaphone7.encode("");
        int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone7, "hi!", "");
        metaphone7.setMaxCodeLen(0);
        java.lang.String str18 = metaphone7.encode("AK11111111");
        java.lang.String str20 = metaphone7.encode("A1");
        java.lang.String str22 = metaphone7.metaphone("A000");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = soundex6.encode((java.lang.Object) metaphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
    }

    @Test
    public void test2364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2364");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        java.lang.String str7 = refinedSoundex0.encode("");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test2365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2365");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean22 = caverphone0.isCaverphoneEqual("A#", "AKP1111111");
        java.lang.String str24 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        boolean boolean27 = caverphone0.isCaverphoneEqual("ORK", "");
        java.lang.String str29 = caverphone0.encode("A111111111");
        java.lang.String str31 = caverphone0.caverphone("ARKPKSKMNSKTKNKTRKSPKSNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AKPKSKMNSK" + "'", str31, "AKPKSKMNSK");
    }

    @Test
    public void test2366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2366");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean5 = metaphone0.isMetaphoneEqual("ARK", "A0931");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        doubleMetaphone6.setMaxCodeLen((int) (byte) 0);
        java.lang.String str13 = doubleMetaphone6.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult15 = doubleMetaphone6.new DoubleMetaphoneResult(0);
        java.lang.String str16 = doubleMetaphoneResult15.getAlternate();
        doubleMetaphoneResult15.append('\000');
        doubleMetaphoneResult15.append('#', '#');
        java.lang.String str22 = doubleMetaphoneResult15.getPrimary();
        java.lang.String str23 = doubleMetaphoneResult15.getAlternate();
        doubleMetaphoneResult15.append("org.apache.commons.codec.EncoderException: hi!");
        doubleMetaphoneResult15.append("ORKP");
        doubleMetaphoneResult15.append("");
        doubleMetaphoneResult15.append('\000', 'a');
        java.lang.String str33 = doubleMetaphoneResult15.getAlternate();
        java.lang.Object obj34 = metaphone0.encode((java.lang.Object) str33);
        java.lang.Class<?> wildcardClass35 = metaphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + obj34 + "' != '" + "" + "'", obj34, "");
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test2367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2367");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        java.lang.String str12 = metaphone0.encode("AA11111111");
        java.lang.String str14 = metaphone0.metaphone(" AKPKMNSKTK");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = 0;
        java.lang.String str19 = doubleMetaphone15.encode("A621");
        boolean boolean23 = doubleMetaphone15.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        java.lang.String str25 = doubleMetaphone15.encode("");
        boolean boolean29 = doubleMetaphone15.isDoubleMetaphoneEqual("A621", "org.apache.commons.codec.EncoderException: hi!", false);
        doubleMetaphone15.maxCodeLen = '0';
        int int32 = doubleMetaphone15.getMaxCodeLen();
        boolean boolean35 = doubleMetaphone15.isDoubleMetaphoneEqual("AKPKMNSKT", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        java.lang.String str38 = doubleMetaphone15.doubleMetaphone("I000", false);
        boolean boolean42 = doubleMetaphone15.isDoubleMetaphoneEqual("ORKPXKMNSKTKNKTRKSSPXNH", "org.apache.commons.codec.EncoderException: ", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = metaphone0.encode((java.lang.Object) doubleMetaphone15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "K" + "'", str14, "K");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 48 + "'", int32 == 48);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "A" + "'", str38, "A");
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test2368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2368");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        soundex0.setMaxLength((int) '1');
        soundex0.setMaxLength((int) 'S');
        java.lang.String str6 = soundex0.encode("ARKPKKMNSKTKNKTRKSPXNRKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str9 = doubleMetaphone7.doubleMetaphone("H");
        doubleMetaphone7.setMaxCodeLen((int) (byte) 0);
        java.lang.String str14 = doubleMetaphone7.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone7.new DoubleMetaphoneResult(0);
        java.lang.String str17 = doubleMetaphoneResult16.getPrimary();
        doubleMetaphoneResult16.appendAlternate('O');
        doubleMetaphoneResult16.appendAlternate('\000');
        boolean boolean22 = doubleMetaphoneResult16.isComplete();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = soundex0.encode((java.lang.Object) boolean22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A621" + "'", str6, "A621");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test2369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2369");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.encode("AKPKMNSKTK");
        java.lang.String str8 = refinedSoundex4.soundex("ARKPKMNSK");
        java.lang.String str10 = refinedSoundex4.encode("O");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A02125232" + "'", str6, "A02125232");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A0621252" + "'", str8, "A0621252");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0" + "'", str10, "O0");
    }

    @Test
    public void test2370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2370");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("01230120022455012623010202", "AA11111111");
        int int11 = refinedSoundex0.difference("01230120022455012623010202", "A621");
        int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "org.apache.commons.codec.EncoderException: A0931", "ARKPXKMNSKTKNKTRKSPXNRKP");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test2371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2371");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str16 = soundex1.soundex("O0931");
        soundex1.setMaxLength(65);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O000" + "'", str16, "O000");
    }

    @Test
    public void test2372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2372");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        java.lang.String str26 = refinedSoundex0.encode("O093");
        java.lang.Class<?> wildcardClass27 = refinedSoundex0.getClass();
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O0940103030808306030830609053016080" + "'", str24, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "O0" + "'", str26, "O0");
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test2373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2373");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str7 = metaphone0.metaphone("A#");
        java.lang.String str9 = metaphone0.encode("A");
        metaphone0.setMaxCodeLen(5);
        java.lang.String[] strArray27 = new java.lang.String[] { "HI", "H", "HI", "01230120022455012623010202", "01230120022455012623010202", "" };
        boolean boolean28 = org.apache.commons.codec.language.DoubleMetaphone.contains("", (int) (byte) -1, (int) (byte) 1, strArray27);
        boolean boolean29 = org.apache.commons.codec.language.DoubleMetaphone.contains("", (int) '0', (int) (byte) 10, strArray27);
        boolean boolean30 = org.apache.commons.codec.language.DoubleMetaphone.contains("01230120022455012623010202", (int) (byte) 1, (int) (short) 0, strArray27);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = metaphone0.encode((java.lang.Object) boolean30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A" + "'", str7, "A");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertArrayEquals(strArray27, new java.lang.String[] { "HI", "H", "HI", "01230120022455012623010202", "01230120022455012623010202", "" });
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test2374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2374");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        org.apache.commons.codec.language.Soundex soundex6 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex6.setMaxLength((int) (byte) -1);
        int int11 = soundex6.difference("A0", "");
        java.lang.String str13 = soundex6.soundex("");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) str13);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(soundex6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "" + "'", obj14, "");
    }

    @Test
    public void test2375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2375");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str14 = metaphone0.encode("A1");
        metaphone0.setMaxCodeLen((int) 'r');
        java.lang.Class<?> wildcardClass17 = metaphone0.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test2376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2376");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        int int19 = metaphone0.getMaxCodeLen();
        java.lang.String str21 = metaphone0.encode("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXN" + "'", str21, "ORKPXKMNSKTKNKTRKSSPXN");
    }

    @Test
    public void test2377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2377");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("Aa", "A093138363836931389313836383693138");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test2378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2378");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("O093", "AKP1111111");
        boolean boolean19 = caverphone0.isCaverphoneEqual("A0", "H000");
        java.lang.String str21 = caverphone0.encode("AKP1111111");
        java.lang.String str23 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0931");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "O0931538363836931589315383638369315893109", "AM");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKP1111111" + "'", str21, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "AKPKKMNSKT" + "'", str23, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
    }

    @Test
    public void test2379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2379");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('a');
        int int10 = refinedSoundex0.difference("AK", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        java.lang.String str12 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str14 = refinedSoundex0.encode("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O0940103030808306030830609053016080" + "'", str12, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A09313836383693138931383" + "'", str14, "A09313836383693138931383");
    }

    @Test
    public void test2380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2380");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("A621");
        java.lang.String str13 = refinedSoundex0.encode("O000");
        char char15 = refinedSoundex0.getMappingCode('T');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '6' + "'", char15 == '6');
    }

    @Test
    public void test2381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2381");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        int int25 = metaphone0.getMaxCodeLen();
        java.lang.String str27 = metaphone0.encode("org.apache.commons.codec.EncoderException: org.ap");
        boolean boolean30 = metaphone0.isMetaphoneEqual("A09", "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 114 + "'", int25 == 114);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKP" + "'", str27, "ORKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test2382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2382");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        char char29 = refinedSoundex0.getMappingCode('e');
        java.lang.String str31 = refinedSoundex0.soundex("9");
        char char33 = refinedSoundex0.getMappingCode('4');
        char char35 = refinedSoundex0.getMappingCode('a');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '0' + "'", char29 == '0');
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertTrue("'" + char33 + "' != '" + '\000' + "'", char33 == '\000');
        org.junit.Assert.assertTrue("'" + char35 + "' != '" + '0' + "'", char35 == '0');
    }

    @Test
    public void test2383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2383");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("A0313836");
        java.lang.String str26 = refinedSoundex0.soundex("A0931");
        char char28 = refinedSoundex0.getMappingCode('8');
        int int31 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "", "A310");
        java.lang.String str33 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: AKPK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A0" + "'", str24, "A0");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "A0" + "'", str26, "A0");
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '\000' + "'", char28 == '\000');
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "O0940103030808306030830609053016080940103030808306030830609053016080313" + "'", str33, "O0940103030808306030830609053016080940103030808306030830609053016080313");
    }

    @Test
    public void test2384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2384");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("AA11111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean21 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char24 = doubleMetaphone12.charAt("01230120022455012623010202", (int) (short) 1);
        char char27 = doubleMetaphone12.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone12.maxCodeLen = (byte) 10;
        boolean boolean32 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0940103030808306030830609053016080");
        int int33 = doubleMetaphone12.getMaxCodeLen();
        java.lang.String str35 = doubleMetaphone12.encode("org.apache.commons.codec.EncoderException: HI");
        int int38 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone12, "org.apache.commons.codec.EncoderException: ORKP", "hi!");
        java.lang.Object obj39 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean42 = caverphone0.isCaverphoneEqual("ARKPKMNSKTKNKTRKSPKSNRKPKMNSKTKNKTRKSPKSN", "AKPKKMNSKT");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone43 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone43.maxCodeLen = '\000';
        doubleMetaphone43.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult49 = doubleMetaphone43.new DoubleMetaphoneResult((int) '1');
        java.lang.String str50 = doubleMetaphoneResult49.getPrimary();
        java.lang.String str51 = doubleMetaphoneResult49.getPrimary();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj52 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AA11111111" + "'", str11, "AA11111111");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '1' + "'", char24 == '1');
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + 'O' + "'", char27 == 'O');
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "ARKPXKMNSK" + "'", str35, "ARKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertEquals("'" + obj39 + "' != '" + "AA11111111" + "'", obj39, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "" + "'", str50, "");
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
    }

    @Test
    public void test2385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2385");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str9 = soundex7.encode("org.apache.commons.codec.EncoderException: ARK");
        java.lang.String str11 = soundex7.soundex("A0212523");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A000" + "'", str11, "A000");
    }

    @Test
    public void test2386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2386");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        java.lang.String str14 = caverphone0.encode("AKPKKMNSKT");
        java.lang.String str16 = caverphone0.encode("ORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKT1" + "'", str14, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKP1111111" + "'", str16, "AKP1111111");
    }

    @Test
    public void test2387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2387");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) '0');
        int int8 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = soundex1.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 48 + "'", int8 == 48);
    }

    @Test
    public void test2388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2388");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.soundex("ARKPXKMNSKTKNKTRKS");
        java.lang.String str8 = refinedSoundex4.encode("A09315383");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A093153836383693" + "'", str6, "A093153836383693");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A0" + "'", str8, "A0");
    }

    @Test
    public void test2389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2389");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        char char7 = refinedSoundex5.getMappingCode('5');
        java.lang.String str9 = refinedSoundex5.soundex("K111111111");
        java.lang.String str11 = refinedSoundex5.encode("A093138363836931589313836383693158");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "K3" + "'", str9, "K3");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
    }

    @Test
    public void test2390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2390");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        int int9 = soundex0.getMaxLength();
        int int12 = soundex0.difference("ORKPXKMNSKTSNKTRKSSPXN", "01230120022455012623010202");
        java.lang.String str14 = soundex0.encode("ARKPXKMNSKTSNKTR");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A621" + "'", str14, "A621");
    }

    @Test
    public void test2391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2391");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str30 = caverphone0.encode("");
        boolean boolean33 = caverphone0.isCaverphoneEqual("K", "KPK1111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AKPKKMNSKT" + "'", str28, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test2392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2392");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int5 = soundex0.difference("A0", "");
        int int6 = soundex0.getMaxLength();
        java.lang.Object obj8 = soundex0.encode((java.lang.Object) "ARKPXKMNSKTSNKTRKSPXNRKPXKMNSKTSNKTRKSPXNRKPKSKMNSK");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertEquals("'" + obj8 + "' != '" + "A621" + "'", obj8, "A621");
    }

    @Test
    public void test2393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2393");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean7 = caverphone0.isCaverphoneEqual("O", "01230120022455012623010202");
        boolean boolean10 = caverphone0.isCaverphoneEqual("ARKPXKMNSK", "9");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test2394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2394");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = 0;
        char char19 = doubleMetaphone14.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean23 = doubleMetaphone14.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone14.maxCodeLen = 3;
        java.lang.String str27 = doubleMetaphone14.encode("A111111111");
        java.lang.Object obj28 = refinedSoundex0.encode((java.lang.Object) str27);
        char char30 = refinedSoundex0.getMappingCode('4');
        java.lang.String str32 = refinedSoundex0.encode("");
        int int35 = refinedSoundex0.difference("AKPKMNSKT1", "RKPK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A" + "'", str27, "A");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "A0" + "'", obj28, "A0");
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + '\000' + "'", char30 == '\000');
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
    }

    @Test
    public void test2395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2395");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.encode("");
        boolean boolean33 = caverphone0.isCaverphoneEqual("aorg.apache.commons.codec.Encode", "org.apache.commons.codec.EncoderException: Aa");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test2396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2396");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        char char8 = refinedSoundex6.getMappingCode('0');
        // The following exception was thrown during execution in test generation
        try {
            int int11 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex6, "A031", "org.apache.commons.codec.EncoderException: AKPK");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
    }

    @Test
    public void test2397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2397");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        java.lang.String str5 = soundex1.soundex("A031");
        java.lang.String str7 = soundex1.soundex("org.apache.commons.codec.EncoderException: AA11111111");
        int int8 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A000" + "'", str5, "A000");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O941" + "'", str7, "O941");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test2398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2398");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int11 = soundex8.difference("A111111111O620", "A621HI0A093138363836931589313836383693158M");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test2399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2399");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.encode("01230120022455012623010202");
        int int14 = refinedSoundex0.difference("aORGAPACHECOMMONSCODECENCODEREXC", "A621HI0A093138363836931589313836383693158");
        int int17 = refinedSoundex0.difference("ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT", "");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test2400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2400");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        char[] charArray37 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex38 = new org.apache.commons.codec.language.Soundex(charArray37);
        org.apache.commons.codec.language.Soundex soundex39 = new org.apache.commons.codec.language.Soundex(charArray37);
        org.apache.commons.codec.language.Soundex soundex40 = new org.apache.commons.codec.language.Soundex(charArray37);
        org.apache.commons.codec.language.Soundex soundex41 = new org.apache.commons.codec.language.Soundex(charArray37);
        org.apache.commons.codec.language.Soundex soundex42 = new org.apache.commons.codec.language.Soundex(charArray37);
        org.apache.commons.codec.language.Soundex soundex43 = new org.apache.commons.codec.language.Soundex(charArray37);
        org.apache.commons.codec.language.Soundex soundex44 = new org.apache.commons.codec.language.Soundex(charArray37);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj45 = caverphone0.encode((java.lang.Object) charArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertNotNull(charArray37);
    }

    @Test
    public void test2401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2401");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        soundex1.setMaxLength(0);
        java.lang.String str13 = soundex1.encode("A0313");
        int int14 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) ' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone17.maxCodeLen = 0;
        char char22 = doubleMetaphone17.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult24 = doubleMetaphone17.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult24.appendAlternate('\000');
        doubleMetaphoneResult24.append('#');
        java.lang.String str29 = doubleMetaphoneResult24.getAlternate();
        java.lang.String str30 = doubleMetaphoneResult24.getAlternate();
        doubleMetaphoneResult24.append('a', '#');
        boolean boolean34 = doubleMetaphoneResult24.isComplete();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj35 = soundex1.encode((java.lang.Object) doubleMetaphoneResult24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A000" + "'", str13, "A000");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test2402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2402");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.String str12 = caverphone0.encode("O0940103030808306030830609053016080931");
        java.lang.String str14 = caverphone0.encode(" AKP1111111 ");
        java.lang.String str16 = caverphone0.encode("A111111111O620");
        java.lang.Object obj18 = caverphone0.encode((java.lang.Object) "ARKPKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKP1111111" + "'", str14, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AA11111111" + "'", str16, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj18 + "' != '" + "AKPKMNSK11" + "'", obj18, "AKPKMNSK11");
    }

    @Test
    public void test2403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2403");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        soundex1.setMaxLength(0);
        int int14 = soundex1.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ");
        soundex1.setMaxLength(0);
        int int17 = soundex1.getMaxLength();
        soundex1.setMaxLength(111);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test2404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2404");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int9 = soundex4.difference("AKP1111111", "AKPK");
        int int12 = soundex4.difference("org.apache.commons.codec.EncoderException: ", "ARKP");
        soundex4.setMaxLength((int) (byte) 0);
        soundex4.setMaxLength(65);
        soundex4.setMaxLength((int) '5');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test2405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2405");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.encode("A062125232523621256212523252362125");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A0" + "'", str6, "A0");
    }

    @Test
    public void test2406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2406");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = refinedSoundex5.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test2407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2407");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O931", "O0620102020505203020520306020130506201");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test2408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2408");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        int int6 = refinedSoundex0.difference("A111111111", "O0940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = 0;
        char char12 = doubleMetaphone7.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone7.new DoubleMetaphoneResult((int) (short) 0);
        java.lang.String str16 = doubleMetaphone7.encode("A");
        java.lang.String str18 = doubleMetaphone7.doubleMetaphone("AKP1111111");
        java.lang.Object obj19 = refinedSoundex0.encode((java.lang.Object) str18);
        int int22 = refinedSoundex0.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTION", "");
        int int25 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "O09315383638369315893153836383693158931", "");
        char char27 = refinedSoundex0.getMappingCode('i');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "" + "'", obj19, "");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '0' + "'", char27 == '0');
    }

    @Test
    public void test2409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2409");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char31 = refinedSoundex29.getMappingCode('a');
        int int34 = refinedSoundex29.difference("", "hi!");
        char char36 = refinedSoundex29.getMappingCode('#');
        int int39 = refinedSoundex29.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj41 = refinedSoundex29.encode((java.lang.Object) "O941");
        java.lang.Object obj42 = caverphone0.encode(obj41);
        boolean boolean45 = caverphone0.isCaverphoneEqual("H000", "AA");
        java.lang.String str47 = caverphone0.encode("AA");
        java.lang.String str49 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Object obj50 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj51 = caverphone0.encode(obj50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(refinedSoundex29);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0" + "'", obj41, "O0");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "A111111111" + "'", obj42, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "AA11111111" + "'", str47, "AA11111111");
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "AKPKKMNSKT" + "'", str49, "AKPKKMNSKT");
    }

    @Test
    public void test2410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2410");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        java.lang.String str15 = metaphone0.metaphone("A000");
        metaphone0.setMaxCodeLen(48);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char20 = refinedSoundex18.getMappingCode('a');
        int int23 = refinedSoundex18.difference("", "hi!");
        int int26 = refinedSoundex18.difference("hi!", "");
        int int29 = refinedSoundex18.difference("H", "A");
        char char31 = refinedSoundex18.getMappingCode('4');
        int int34 = refinedSoundex18.difference("AO", "");
        java.lang.Object obj35 = metaphone0.encode((java.lang.Object) "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNotNull(refinedSoundex18);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '0' + "'", char20 == '0');
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '\000' + "'", char31 == '\000');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "" + "'", obj35, "");
    }

    @Test
    public void test2411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2411");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        int int22 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A ", "A1111111114r");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone23 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone23.maxCodeLen = 0;
        char char28 = doubleMetaphone23.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean32 = doubleMetaphone23.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char35 = doubleMetaphone23.charAt("01230120022455012623010202", (int) (short) 1);
        char char38 = doubleMetaphone23.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone23.maxCodeLen = 100;
        boolean boolean43 = doubleMetaphone23.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        doubleMetaphone23.maxCodeLen = 0;
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult47 = doubleMetaphone23.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult47.appendPrimary('K');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj50 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '\000' + "'", char28 == '\000');
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + char35 + "' != '" + '1' + "'", char35 == '1');
        org.junit.Assert.assertTrue("'" + char38 + "' != '" + 'O' + "'", char38 == 'O');
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test2412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2412");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.encode("org.apache.commons.codec.EncoderException: A0931383");
        java.lang.String str24 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A062125232523621256212523252362125");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXN" + "'", str22, "ORKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXN" + "'", str24, "ORKPXKMNSKTKNKTRKSSPXN");
    }

    @Test
    public void test2413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2413");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("O093", "AKP1111111");
        java.lang.String str18 = caverphone0.caverphone("A0");
        boolean boolean21 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderExc", "ORKPXKMNSKTKNKTRKSSPXN");
        int int24 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "", "ARKPKKMNSK");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone25 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone25.maxCodeLen = '\000';
        char char30 = doubleMetaphone25.charAt("", 0);
        java.lang.String str32 = doubleMetaphone25.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str34 = doubleMetaphone25.doubleMetaphone("");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult36 = doubleMetaphone25.new DoubleMetaphoneResult((int) (byte) 100);
        doubleMetaphoneResult36.append("A", "O621");
        java.lang.String str40 = doubleMetaphoneResult36.getAlternate();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj41 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A111111111" + "'", str18, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + '\000' + "'", char30 == '\000');
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "O621" + "'", str40, "O621");
    }

    @Test
    public void test2414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2414");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("HI");
        java.lang.String str16 = metaphone0.encode("A212");
        java.lang.String str18 = metaphone0.encode("org.apache.commons.codec.EncoderException: AA11111111");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "H" + "'", str14, "H");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORK" + "'", str18, "ORK");
    }

    @Test
    public void test2415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2415");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("H", "A");
        char char13 = refinedSoundex0.getMappingCode('a');
        char[] charArray14 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex15 = new org.apache.commons.codec.language.Soundex(charArray14);
        soundex15.setMaxLength(1);
        int int18 = soundex15.getMaxLength();
        java.lang.String str20 = soundex15.encode("O0940103030808306030830609053016080931");
        java.lang.Object obj21 = refinedSoundex0.encode((java.lang.Object) "O0940103030808306030830609053016080931");
        java.lang.String str23 = refinedSoundex0.encode("A09");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O000" + "'", str20, "O000");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "O0" + "'", obj21, "O0");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A0" + "'", str23, "A0");
    }

    @Test
    public void test2416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2416");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        java.lang.String str14 = soundex3.encode("A#");
        int int17 = soundex3.difference("A0313836", "org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex3, "01230120022455012623010202", " ");
        java.lang.String str22 = soundex3.encode("");
        int int23 = soundex3.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A000" + "'", str14, "A000");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
    }

    @Test
    public void test2417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2417");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("ARKP");
        boolean boolean11 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "ORK");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ARKP" + "'", str8, "ARKP");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test2418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2418");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        metaphone0.setMaxCodeLen((int) '0');
        metaphone0.setMaxCodeLen(0);
        org.apache.commons.codec.language.Soundex soundex17 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex17.setMaxLength((int) (byte) -1);
        int int20 = soundex17.getMaxLength();
        soundex17.setMaxLength(10);
        java.lang.String str24 = soundex17.soundex("A621HI");
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex17, "O0940103030808306030830609053016080940103030808306030830609053016080931", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = metaphone0.encode((java.lang.Object) int27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(soundex17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A000" + "'", str24, "A000");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test2419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2419");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode(' ');
        char char9 = refinedSoundex0.getMappingCode('\000');
        int int12 = refinedSoundex0.difference("", "O0940103030808306030830609053016080");
        char char14 = refinedSoundex0.getMappingCode('5');
        char char16 = refinedSoundex0.getMappingCode('E');
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '0' + "'", char16 == '0');
    }

    @Test
    public void test2420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2420");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone0.new DoubleMetaphoneResult((int) '1');
        java.lang.String str18 = doubleMetaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        int int21 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        java.lang.String str24 = doubleMetaphone0.doubleMetaphone("A093153836383693158", false);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKPXKMNSK" + "'", str18, "ARKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A" + "'", str24, "A");
    }

    @Test
    public void test2421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2421");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: A000", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test2422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2422");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int13 = soundex0.difference("AKPKMNSKTK", "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        soundex0.setMaxLength((int) 'T');
        soundex0.setMaxLength(43);
        int int18 = soundex0.getMaxLength();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 43 + "'", int18 == 43);
    }

    @Test
    public void test2423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2423");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int11 = soundex8.difference("A621", "r");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test2424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2424");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.encode("01230120022455012623010202");
        int int14 = refinedSoundex0.difference("aORGAPACHECOMMONSCODECENCODEREXC", "A621HI0A093138363836931589313836383693158");
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "ARKPXKMN", "K111111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test2425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2425");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        char[] charArray3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray3);
        soundex4.setMaxLength(1);
        int int7 = soundex4.getMaxLength();
        int int10 = soundex4.difference("HI", "");
        java.lang.String str12 = soundex4.soundex("O0940103030808306030830609053016080");
        int int13 = soundex4.getMaxLength();
        soundex4.setMaxLength(10);
        java.lang.String str17 = soundex4.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = soundex2.encode((java.lang.Object) soundex4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O000" + "'", str12, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
    }

    @Test
    public void test2426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2426");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str9 = metaphone0.metaphone("4");
        java.lang.String str11 = metaphone0.encode("ARKPKKMNSK");
        metaphone0.setMaxCodeLen(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "4" + "'", str9, "4");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
    }

    @Test
    public void test2427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2427");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        char char5 = refinedSoundex0.getMappingCode(' ');
        java.lang.String str7 = refinedSoundex0.encode("");
        java.lang.String str9 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O0940103030808306030830609053016080" + "'", str9, "O0940103030808306030830609053016080");
    }

    @Test
    public void test2428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2428");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "", "A0O093");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test2429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2429");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str7 = soundex1.encode("AA11111111");
        java.lang.String str9 = soundex1.encode("org.apache.commons.codec.EncoderException: A0");
        int int10 = soundex1.getMaxLength();
        int int13 = soundex1.difference("", "A210");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test2430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2430");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        java.lang.String str38 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str40 = caverphone0.caverphone("");
        boolean boolean43 = caverphone0.isCaverphoneEqual("ORKP", "K");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKKMNSKT" + "'", str38, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "1111111111" + "'", str40, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test2431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2431");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        int int6 = refinedSoundex0.difference("A111111111", "O0940103030808306030830609053016080");
        org.apache.commons.codec.language.Caverphone caverphone7 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str9 = caverphone7.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str11 = caverphone7.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str13 = caverphone7.encode("A");
        java.lang.String str15 = caverphone7.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str17 = caverphone7.encode("hi!");
        java.lang.String str19 = caverphone7.encode("O0940103030808306030830609053016080931");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = refinedSoundex0.encode((java.lang.Object) caverphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKPKKMNSKT" + "'", str9, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A111111111" + "'", str19, "A111111111");
    }

    @Test
    public void test2432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2432");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.metaphone("01230120022455012623010202");
        java.lang.String str7 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str9 = metaphone0.encode("");
        boolean boolean12 = metaphone0.isMetaphoneEqual("A03", "org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test2433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2433");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj12 = refinedSoundex0.encode((java.lang.Object) "O941");
        char char14 = refinedSoundex0.getMappingCode('0');
        int int17 = refinedSoundex0.difference("O0940103030808306030830609053016080940103030808306030830609053016080931", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "H0", "O0620102020505203020520306020130506201");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "O0" + "'", obj12, "O0");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test2434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2434");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str14 = refinedSoundex0.soundex("AKPKMNSKT1");
        int int17 = refinedSoundex0.difference("K111111111", "ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT");
        java.lang.Class<?> wildcardClass18 = refinedSoundex0.getClass();
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A0313836" + "'", str14, "A0313836");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test2435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2435");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str18 = metaphone0.metaphone("O09401030308083060308306090530160809315383638369315893153836383693158931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKPKSKMNSKTKNKTRKSPKSN" + "'", str16, "ARKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O" + "'", str18, "O");
    }

    @Test
    public void test2436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2436");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        java.lang.String str13 = refinedSoundex0.encode("O09315383638369315893153836383693158");
        int int16 = refinedSoundex0.difference("", "O09315383638369315893153836383693158931");
        char char18 = refinedSoundex0.getMappingCode('a');
        char char20 = refinedSoundex0.getMappingCode('a');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '0' + "'", char18 == '0');
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '0' + "'", char20 == '0');
    }

    @Test
    public void test2437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2437");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char31 = refinedSoundex29.getMappingCode('a');
        int int34 = refinedSoundex29.difference("", "hi!");
        char char36 = refinedSoundex29.getMappingCode('#');
        int int39 = refinedSoundex29.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj41 = refinedSoundex29.encode((java.lang.Object) "O941");
        java.lang.Object obj42 = caverphone0.encode(obj41);
        boolean boolean45 = caverphone0.isCaverphoneEqual("H000", "AA");
        java.lang.String str47 = caverphone0.encode("AA");
        java.lang.String str49 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str51 = caverphone0.caverphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(refinedSoundex29);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0" + "'", obj41, "O0");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "A111111111" + "'", obj42, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "AA11111111" + "'", str47, "AA11111111");
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "AKPKKMNSKT" + "'", str49, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "1111111111" + "'", str51, "1111111111");
    }

    @Test
    public void test2438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2438");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode('i');
        java.lang.String str9 = refinedSoundex0.encode("ARKPKMNSK");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A0931383" + "'", str9, "A0931383");
    }

    @Test
    public void test2439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2439");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str3 = refinedSoundex1.encode("");
        java.lang.String str5 = refinedSoundex1.soundex("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        doubleMetaphone6.setMaxCodeLen((int) (byte) 0);
        java.lang.String str13 = doubleMetaphone6.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult15 = doubleMetaphone6.new DoubleMetaphoneResult(0);
        int int16 = doubleMetaphone6.maxCodeLen;
        java.lang.String str18 = doubleMetaphone6.encode("O941");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone6.new DoubleMetaphoneResult(48);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = refinedSoundex1.encode((java.lang.Object) 48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0940103030808306030830609053016080940103030808306030830609053016080" + "'", str5, "O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
    }

    @Test
    public void test2440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2440");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char20 = refinedSoundex18.getMappingCode('a');
        int int23 = refinedSoundex18.difference("", "hi!");
        char char25 = refinedSoundex18.getMappingCode('0');
        char char27 = refinedSoundex18.getMappingCode('a');
        java.lang.String str29 = refinedSoundex18.soundex("1111111111");
        int int32 = refinedSoundex18.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone33 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone33.maxCodeLen = '\000';
        doubleMetaphone33.setMaxCodeLen(4);
        java.lang.String str39 = doubleMetaphone33.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj40 = refinedSoundex18.encode((java.lang.Object) str39);
        java.lang.String str42 = refinedSoundex18.soundex("A0313836");
        java.lang.Object obj43 = caverphone0.encode((java.lang.Object) "A0313836");
        boolean boolean46 = caverphone0.isCaverphoneEqual("A621HI0A093138363836931589313836383693158M", "AA");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertNotNull(refinedSoundex18);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '0' + "'", char20 == '0');
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '\000' + "'", char25 == '\000');
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '0' + "'", char27 == '0');
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 35 + "'", int32 == 35);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "ARKP" + "'", str39, "ARKP");
        org.junit.Assert.assertEquals("'" + obj40 + "' != '" + "A0931" + "'", obj40, "A0931");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "A0" + "'", str42, "A0");
        org.junit.Assert.assertEquals("'" + obj43 + "' != '" + "A111111111" + "'", obj43, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test2441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2441");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        soundex0.setMaxLength((int) '1');
        soundex0.setMaxLength((int) 'S');
        java.lang.String str6 = soundex0.encode("ARKPKKMNSKTKNKTRKSPXNRKP");
        int int9 = soundex0.difference("org.apache.commons.codec.EncoderException: A0931", "O094010303080830603083060905301608");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A621" + "'", str6, "A621");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test2442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2442");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray4);
        soundex11.setMaxLength((int) '\000');
        // The following exception was thrown during execution in test generation
        try {
            int int16 = soundex11.difference("K120", "org.apache.commons.codec.EncoderException: 4");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test2443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2443");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("A1111111114r");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        doubleMetaphone11.setMaxCodeLen((int) (byte) 0);
        boolean boolean19 = doubleMetaphone11.isDoubleMetaphoneEqual("O620", "O000", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone11.new DoubleMetaphoneResult((int) 'r');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = caverphone0.encode((java.lang.Object) 'r');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test2444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2444");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex2.setMaxLength((int) '1');
        int int7 = soundex2.difference("A0", "H");
        org.apache.commons.codec.language.Metaphone metaphone8 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str10 = metaphone8.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str12 = metaphone8.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str14 = metaphone8.encode("A0");
        java.lang.String str16 = metaphone8.encode("ARKP");
        boolean boolean19 = metaphone8.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "ORK");
        java.lang.String str21 = metaphone8.encode("A062125232523621256212523252362125");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = soundex2.encode((java.lang.Object) metaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "ORKP" + "'", str10, "ORKP");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ORKP" + "'", str12, "ORKP");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A" + "'", str14, "A");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A" + "'", str21, "A");
    }

    @Test
    public void test2445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2445");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        soundex0.setMaxLength(65);
        int int6 = soundex0.difference("  ", "org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str9 = doubleMetaphone7.doubleMetaphone("H");
        doubleMetaphone7.setMaxCodeLen((int) (byte) 0);
        java.lang.String str14 = doubleMetaphone7.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone7.new DoubleMetaphoneResult(0);
        int int17 = doubleMetaphone7.getMaxCodeLen();
        doubleMetaphone7.setMaxCodeLen((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = soundex0.encode((java.lang.Object) doubleMetaphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test2446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2446");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        java.lang.String str17 = metaphone0.encode("O062010202050520302052030602013050");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O" + "'", str17, "O");
    }

    @Test
    public void test2447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2447");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str30 = doubleMetaphone28.doubleMetaphone("H");
        doubleMetaphone28.setMaxCodeLen((int) (byte) 0);
        char char35 = doubleMetaphone28.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult37 = doubleMetaphone28.new DoubleMetaphoneResult((int) '4');
        java.lang.String str38 = doubleMetaphoneResult37.getAlternate();
        doubleMetaphoneResult37.appendPrimary("O0931");
        doubleMetaphoneResult37.appendAlternate('0');
        java.lang.String str43 = doubleMetaphoneResult37.getPrimary();
        java.lang.Object obj44 = refinedSoundex0.encode((java.lang.Object) str43);
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertTrue("'" + char35 + "' != '" + 'i' + "'", char35 == 'i');
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "O0931" + "'", str43, "O0931");
        org.junit.Assert.assertEquals("'" + obj44 + "' != '" + "O0" + "'", obj44, "O0");
    }

    @Test
    public void test2448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2448");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.encode("A111111111O000");
        char char9 = refinedSoundex5.getMappingCode('o');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = 0;
        char char15 = doubleMetaphone10.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean19 = doubleMetaphone10.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char22 = doubleMetaphone10.charAt("01230120022455012623010202", (int) (short) 1);
        char char25 = doubleMetaphone10.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone10.maxCodeLen = 100;
        boolean boolean30 = doubleMetaphone10.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        boolean boolean33 = doubleMetaphone10.isDoubleMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str35 = doubleMetaphone10.encode("AKPKKMNSKT");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult37 = doubleMetaphone10.new DoubleMetaphoneResult((int) (byte) 10);
        boolean boolean41 = doubleMetaphone10.isDoubleMetaphoneEqual("A111111111O620", "org.apache.commons.codec.EncoderException: 01230120022455012623010202", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult43 = doubleMetaphone10.new DoubleMetaphoneResult(43);
        boolean boolean46 = doubleMetaphone10.isDoubleMetaphoneEqual("A621", "ARKPXKMNSKTKNKTRKSPXNRKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj47 = refinedSoundex5.encode((java.lang.Object) doubleMetaphone10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A0" + "'", str7, "A0");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '1' + "'", char22 == '1');
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + 'O' + "'", char25 == 'O');
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "AKPKMNSKT" + "'", str35, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test2449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2449");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        org.apache.commons.codec.language.Metaphone metaphone19 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str21 = metaphone19.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone19.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone24 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str26 = caverphone24.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str28 = caverphone24.caverphone("hi!");
        java.lang.Object obj29 = metaphone19.encode((java.lang.Object) "hi!");
        java.lang.String str31 = metaphone19.encode("O0940103030808306030830609053016080");
        java.lang.Object obj32 = metaphone0.encode((java.lang.Object) str31);
        metaphone0.setMaxCodeLen((int) 'i');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ORKP" + "'", str21, "ORKP");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "AKPKKMNSKT" + "'", str26, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AA11111111" + "'", str28, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "H" + "'", obj29, "H");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "O" + "'", str31, "O");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "O" + "'", obj32, "O");
    }

    @Test
    public void test2450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2450");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        boolean boolean13 = doubleMetaphone8.isDoubleMetaphoneEqual("01230120022455012623010202", "");
        java.lang.Object obj14 = soundex1.encode((java.lang.Object) "01230120022455012623010202");
        int int15 = soundex1.getMaxLength();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "" + "'", obj14, "");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test2451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2451");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int8 = refinedSoundex5.difference("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "ARKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str10 = refinedSoundex5.encode("A000");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A0" + "'", str10, "A0");
    }

    @Test
    public void test2452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2452");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        metaphone0.setMaxCodeLen((int) ' ');
        int int7 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

    @Test
    public void test2453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2453");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        // The following exception was thrown during execution in test generation
        try {
            int int15 = refinedSoundex5.difference("A111111111O620", "A094010303080830603083060");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
    }

    @Test
    public void test2454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2454");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int12 = soundex1.difference("A#", "H0");
        int int15 = soundex1.difference("AK11111111", "A621r");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
    }

    @Test
    public void test2455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2455");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("AHIAM");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A08" + "'", str15, "A08");
    }

    @Test
    public void test2456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2456");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str9 = doubleMetaphone7.doubleMetaphone("H");
        doubleMetaphone7.setMaxCodeLen((int) (byte) 0);
        java.lang.String str13 = doubleMetaphone7.encode("H");
        boolean boolean17 = doubleMetaphone7.isDoubleMetaphoneEqual("ORKP", "O0", true);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone7.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult19.append('9', 'e');
        java.lang.String str23 = doubleMetaphoneResult19.getPrimary();
        java.lang.Object obj24 = metaphone0.encode((java.lang.Object) str23);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "9" + "'", str23, "9");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "9" + "'", obj24, "9");
    }

    @Test
    public void test2457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2457");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex4, "org.apache.commons.codec.EncoderException: A093153836383693158", "");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test2458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2458");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.encode("");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "ARK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test2459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2459");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        int int16 = refinedSoundex0.difference("AO", "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test2460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2460");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        boolean boolean16 = caverphone0.isCaverphoneEqual("hi!", "ORKP");
        java.lang.String str18 = caverphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str20 = caverphone0.encode("");
        boolean boolean23 = caverphone0.isCaverphoneEqual("ORKPKSKMNS", "org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKMNSKTK" + "'", str18, "AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "1111111111" + "'", str20, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test2461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2461");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.soundex("ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str7 = refinedSoundex0.encode("A212");
        int int10 = refinedSoundex0.difference("i0a", "A#");
        java.lang.String str12 = refinedSoundex0.encode("9");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A093153836383693158" + "'", str5, "A093153836383693158");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A0" + "'", str7, "A0");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test2462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2462");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str15 = caverphone0.encode("A111111111");
        java.lang.String str17 = caverphone0.caverphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKT1" + "'", str13, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
    }

    @Test
    public void test2463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2463");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        boolean boolean17 = metaphone0.isMetaphoneEqual("AKPKMNSK11", "");
        boolean boolean20 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSK", "A1");
        boolean boolean23 = metaphone0.isMetaphoneEqual("", "A093153836383693158");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "ORKPXKMNSKTSNKTRKSSPXNRKP", "A000");
        int int27 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
    }

    @Test
    public void test2464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2464");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        int int23 = metaphone0.getMaxCodeLen();
        java.lang.String str25 = metaphone0.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int26 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ARKPKSKMNS" + "'", str22, "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "ORKPXKMNSK" + "'", str25, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
    }

    @Test
    public void test2465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2465");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        int int25 = refinedSoundex0.difference("O", "H0");
        int int28 = refinedSoundex0.difference("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK", "KPK");
        java.lang.String str30 = refinedSoundex0.encode("ORK1");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "O093" + "'", str30, "O093");
    }

    @Test
    public void test2466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2466");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        doubleMetaphone0.maxCodeLen = (byte) 10;
        java.lang.String str14 = doubleMetaphone0.doubleMetaphone("ORKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ARKPKSKMNS" + "'", str14, "ARKPKSKMNS");
    }

    @Test
    public void test2467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2467");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        int int9 = soundex0.getMaxLength();
        soundex0.setMaxLength((int) (byte) -1);
        int int12 = soundex0.getMaxLength();
        int int15 = soundex0.difference("A#", "A621r");
        java.lang.String str17 = soundex0.encode("org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O621" + "'", str17, "O621");
    }

    @Test
    public void test2468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2468");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.encode("");
        boolean boolean28 = caverphone0.isCaverphoneEqual("", "A#");
        boolean boolean31 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: i0a", "org.apache.commons.codec.EncoderException: A111111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test2469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2469");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        char char7 = refinedSoundex5.getMappingCode('a');
        // The following exception was thrown during execution in test generation
        try {
            int int10 = refinedSoundex5.difference("org.apache.commons.codec.EncoderException: A093153836383693158", "A0931");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'a' + "'", char7 == 'a');
    }

    @Test
    public void test2470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2470");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        java.lang.String str19 = caverphone0.caverphone("ARKPXKMNSK");
        java.lang.String str21 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSK11" + "'", str19, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKKMNSKT" + "'", str21, "AKPKKMNSKT");
    }

    @Test
    public void test2471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2471");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        int int13 = metaphone0.getMaxCodeLen();
        boolean boolean16 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080313836", "ARKPXKMNSKTKNKTRKSPXNRKPXKMNSKTSNKT");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2472");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 1);
        java.lang.String str22 = metaphone0.metaphone("A1111111114r");
        int int23 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A" + "'", str22, "A");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test2473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2473");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        int int25 = metaphone0.getMaxCodeLen();
        java.lang.String str27 = metaphone0.encode("org.apache.commons.codec.EncoderException: org.ap");
        metaphone0.setMaxCodeLen((int) 'o');
        boolean boolean32 = metaphone0.isMetaphoneEqual("ARKPXKMNSK", "ARKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str34 = metaphone0.encode("org.apache.commons.codec.EncoderException:  ");
        java.lang.String str36 = metaphone0.encode("H0");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 114 + "'", int25 == 114);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKP" + "'", str27, "ORKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXN" + "'", str34, "ORKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
    }

    @Test
    public void test2474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2474");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char31 = refinedSoundex29.getMappingCode('a');
        int int34 = refinedSoundex29.difference("", "hi!");
        char char36 = refinedSoundex29.getMappingCode('#');
        int int39 = refinedSoundex29.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj41 = refinedSoundex29.encode((java.lang.Object) "O941");
        java.lang.Object obj42 = caverphone0.encode(obj41);
        boolean boolean45 = caverphone0.isCaverphoneEqual("H000", "AA");
        boolean boolean48 = caverphone0.isCaverphoneEqual("AKPKMNSK11", "AM");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(refinedSoundex29);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0" + "'", obj41, "O0");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "A111111111" + "'", obj42, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test2475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2475");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean13 = caverphone0.isCaverphoneEqual("", "ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str15 = caverphone0.caverphone("AA");
        boolean boolean18 = caverphone0.isCaverphoneEqual("", "O0931");
        java.lang.String str20 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str22 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTION");
        java.lang.String str24 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ARK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AA11111111" + "'", str15, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
    }

    @Test
    public void test2476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2476");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        int int8 = soundex1.getMaxLength();
        java.lang.String str10 = soundex1.encode("K3");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "K000" + "'", str10, "K000");
    }

    @Test
    public void test2477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2477");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        java.lang.String str13 = caverphone0.encode(" ");
        boolean boolean16 = caverphone0.isCaverphoneEqual("", " O620");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2478");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            int int7 = refinedSoundex4.difference("O09401030308083060308306090530160809315383638369315893153836383693158931", "");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
    }

    @Test
    public void test2479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2479");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str9 = soundex7.encode("");
        soundex7.setMaxLength((int) '0');
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        metaphone12.setMaxCodeLen(3);
        int int15 = metaphone12.getMaxCodeLen();
        boolean boolean18 = metaphone12.isMetaphoneEqual("", "");
        boolean boolean21 = metaphone12.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone12.setMaxCodeLen(0);
        int int24 = metaphone12.getMaxCodeLen();
        metaphone12.setMaxCodeLen((int) (short) 100);
        java.lang.String str28 = metaphone12.encode("ARKP");
        java.lang.String str30 = metaphone12.encode("");
        java.lang.String str32 = metaphone12.encode("H");
        java.lang.String str34 = metaphone12.metaphone("AKPKMNSKT1");
        metaphone12.setMaxCodeLen((int) 'r');
        boolean boolean39 = metaphone12.isMetaphoneEqual("AKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone40 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str42 = doubleMetaphone40.doubleMetaphone("H");
        java.lang.String str44 = doubleMetaphone40.doubleMetaphone("HI");
        java.lang.String str46 = doubleMetaphone40.doubleMetaphone("AKPKMNSKT1");
        java.lang.Object obj47 = metaphone12.encode((java.lang.Object) str46);
        boolean boolean50 = metaphone12.isMetaphoneEqual("", "A093153836383693158");
        java.lang.Object obj51 = soundex7.encode((java.lang.Object) "A093153836383693158");
        java.lang.String str53 = soundex7.encode("A#");
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "ARKP" + "'", str28, "ARKP");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPKMNSKT" + "'", str34, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "H" + "'", str44, "H");
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "AKPK" + "'", str46, "AKPK");
        org.junit.Assert.assertEquals("'" + obj47 + "' != '" + "AKPK" + "'", obj47, "AKPK");
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertEquals("'" + obj51 + "' != '" + "A000" + "'", obj51, "A000");
        org.junit.Assert.assertEquals("'" + str53 + "' != '" + "A000" + "'", str53, "A000");
    }

    @Test
    public void test2480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2480");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        java.lang.String str9 = metaphone0.metaphone("A111111111");
        metaphone0.setMaxCodeLen(52);
        metaphone0.setMaxCodeLen(48);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
    }

    @Test
    public void test2481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2481");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        java.lang.String str17 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0940103030808306030830609053016080313836" + "'", str17, "O0940103030808306030830609053016080313836");
    }

    @Test
    public void test2482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2482");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) ' ');
        java.lang.String str6 = metaphone0.encode(" AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "KPKMNSKTK" + "'", str6, "KPKMNSKTK");
    }

    @Test
    public void test2483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2483");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        java.lang.String str38 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean41 = caverphone0.isCaverphoneEqual("", " AKPK");
        boolean boolean44 = caverphone0.isCaverphoneEqual(" AKPKMNSKTK", "O0931");
        java.lang.String str46 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKKMNSKT" + "'", str38, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "AKPKKMNSKT" + "'", str46, "AKPKKMNSKT");
    }

    @Test
    public void test2484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2484");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("ARKP");
        java.lang.String str10 = metaphone0.encode("org.apache.commons.codec.EncoderException: AK11111111");
        java.lang.String str12 = metaphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ARKP" + "'", str8, "ARKP");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "ORKP" + "'", str10, "ORKP");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test2485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2485");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str10 = metaphone0.metaphone("O621");
        int int11 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("");
        encoderException13.addSuppressed((java.lang.Throwable) encoderException15);
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("A0");
        java.lang.Throwable[] throwableArray19 = encoderException18.getSuppressed();
        encoderException13.addSuppressed((java.lang.Throwable) encoderException18);
        java.lang.Throwable[] throwableArray21 = encoderException18.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = metaphone0.encode((java.lang.Object) encoderException18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertArrayEquals(throwableArray19, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertArrayEquals(throwableArray21, new java.lang.Throwable[] {});
    }

    @Test
    public void test2486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2486");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean22 = caverphone0.isCaverphoneEqual("A#", "AKP1111111");
        java.lang.String str24 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        boolean boolean27 = caverphone0.isCaverphoneEqual("ORK", "");
        java.lang.String str29 = caverphone0.encode("A111111111");
        java.lang.String str31 = caverphone0.caverphone("A931");
        java.lang.String str33 = caverphone0.caverphone("O0940103030808306030830609053016080");
        java.lang.String str35 = caverphone0.encode("O094010303080830603083060905301608093");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "A111111111" + "'", str31, "A111111111");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "A111111111" + "'", str33, "A111111111");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "A111111111" + "'", str35, "A111111111");
    }

    @Test
    public void test2487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2487");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean12 = metaphone0.isMetaphoneEqual("A621", "");
        boolean boolean15 = metaphone0.isMetaphoneEqual("AKPKKMNSKT", "A111111111");
        java.lang.String str17 = metaphone0.metaphone("");
        java.lang.String str19 = metaphone0.encode("");
        metaphone0.setMaxCodeLen(34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
    }

    @Test
    public void test2488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2488");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A200");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test2489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2489");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int7 = soundex4.difference("A1111111114r", "O0940103030808306030830609053016080931");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = '\000';
        doubleMetaphone8.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone8.new DoubleMetaphoneResult((int) '1');
        doubleMetaphoneResult14.appendPrimary(' ');
        doubleMetaphoneResult14.appendAlternate("A621");
        doubleMetaphoneResult14.appendAlternate('#');
        doubleMetaphoneResult14.append("O620", "");
        doubleMetaphoneResult14.appendAlternate("A313");
        java.lang.Object obj26 = soundex4.encode((java.lang.Object) "A313");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone27 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone27.maxCodeLen = 0;
        java.lang.String str31 = doubleMetaphone27.encode("A621");
        boolean boolean35 = doubleMetaphone27.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult37 = doubleMetaphone27.new DoubleMetaphoneResult(10);
        doubleMetaphoneResult37.appendAlternate('a');
        doubleMetaphoneResult37.appendAlternate('O');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj42 = soundex4.encode((java.lang.Object) doubleMetaphoneResult37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "A000" + "'", obj26, "A000");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test2490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2490");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A ");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) "A ");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A1", "O941");
        java.lang.String str19 = metaphone0.metaphone("AKPKMNSKT1");
        int int22 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "org.apache.commons.codec.EncoderExca", "A093153836383693158");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "A" + "'", obj14, "A");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSKT" + "'", str19, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test2491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2491");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = '\000';
        char char5 = doubleMetaphone0.charAt("", 0);
        java.lang.String str7 = doubleMetaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str11 = doubleMetaphone0.encode("ARKPXKMNSK");
        int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "R9", "O06201020205052030205203060201305062125232523621256212523252362125621");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test2492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2492");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        int int3 = soundex0.difference("H", "");
        int int4 = soundex0.getMaxLength();
        soundex0.setMaxLength((int) ' ');
        java.lang.String str8 = soundex0.encode("RKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "R212" + "'", str8, "R212");
    }

    @Test
    public void test2493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2493");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        java.lang.String str14 = metaphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str16 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSK" + "'", str16, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSK");
    }

    @Test
    public void test2494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2494");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        char char16 = doubleMetaphone9.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone9.new DoubleMetaphoneResult((int) '4');
        java.lang.String str19 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) str19);
        java.lang.String str22 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        org.apache.commons.codec.EncoderException encoderException24 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: A093153836383693158");
        java.lang.Object obj25 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A093153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + 'i' + "'", char16 == 'i');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "1111111111" + "'", obj20, "1111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "AKPKKMNSKT" + "'", obj25, "AKPKKMNSKT");
    }

    @Test
    public void test2495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2495");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int8 = refinedSoundex5.difference("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "ARKPKSKMNSKTKNKTRKSPKSN");
        int int11 = refinedSoundex5.difference("O941", "K3");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test2496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2496");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str6 = doubleMetaphone0.encode("H");
        int int7 = doubleMetaphone0.getMaxCodeLen();
        int int8 = doubleMetaphone0.maxCodeLen;
        java.lang.String str11 = doubleMetaphone0.doubleMetaphone("O0", false);
        int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "AKP", "");
        doubleMetaphone0.maxCodeLen = 52;
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test2497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2497");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.encode("org.apache.commons.codec.EncoderException: O0");
        boolean boolean16 = caverphone0.isCaverphoneEqual("RKPXKMNSKTKNKTRKSSPXNRKP", "A941");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2498");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test2499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2499");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        soundex1.setMaxLength(0);
        int int14 = soundex1.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ");
        soundex1.setMaxLength(0);
        int int17 = soundex1.getMaxLength();
        java.lang.Object obj18 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = soundex1.encode(obj18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test2500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test2500");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A621HI0A093138363836931589313836383693158", "");
        boolean boolean13 = metaphone0.isMetaphoneEqual("O094010303080830603083060905301608", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        boolean boolean16 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: O620", "1a");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }
}

