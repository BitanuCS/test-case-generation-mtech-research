package org.apache.commons.codec.language;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test0001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0001");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            int int6 = soundex1.difference("hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0002");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj2 = metaphone0.encode((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0003");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }

    @Test
    public void test0004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0004");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("hi!", "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test0005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0005");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("01230120022455012623010202", "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0006");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = refinedSoundex2.soundex("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 7 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0007");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = refinedSoundex2.encode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 7 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0008");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("01230120022455012623010202");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }

    @Test
    public void test0009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0009");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex3.encode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: H");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0010");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        org.apache.commons.codec.language.Metaphone metaphone3 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str5 = metaphone3.encode("");
        boolean boolean8 = metaphone3.isMetaphoneEqual("hi!", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = metaphone0.encode((java.lang.Object) boolean8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test0011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0011");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = refinedSoundex5.encode((java.lang.Object) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 7 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test0012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0012");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("hi!");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "HI" + "'", str1, "HI");
    }

    @Test
    public void test0013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0013");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        org.apache.commons.codec.language.Metaphone metaphone3 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str5 = metaphone3.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = metaphone0.encode((java.lang.Object) metaphone3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0014");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        java.lang.Object obj8 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = refinedSoundex0.encode(obj8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
    }

    @Test
    public void test0015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0015");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("org.apache.commons.codec.EncoderException: HI");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0016");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        java.lang.Object obj3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj4 = metaphone0.encode(obj3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
    }

    @Test
    public void test0017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0017");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        java.lang.String str11 = metaphone0.metaphone("01230120022455012623010202");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex12 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char14 = refinedSoundex12.getMappingCode('a');
        int int17 = refinedSoundex12.difference("", "hi!");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = metaphone0.encode((java.lang.Object) refinedSoundex12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertNotNull(refinedSoundex12);
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '0' + "'", char14 == '0');
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test0018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0018");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = soundex1.encode("HI");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test0019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0019");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "org.apache.commons.codec.EncoderException: HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0020");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        char[] charArray1 = null;
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str4 = soundex2.encode("");
        java.lang.String str6 = soundex2.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = caverphone0.encode((java.lang.Object) soundex2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test0021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0021");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = soundex1.encode("HI");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test0022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0022");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: ORKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
    }

    @Test
    public void test0023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0023");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        org.apache.commons.codec.language.Metaphone metaphone8 = new org.apache.commons.codec.language.Metaphone();
        metaphone8.setMaxCodeLen(3);
        int int11 = metaphone8.getMaxCodeLen();
        boolean boolean14 = metaphone8.isMetaphoneEqual("", "");
        boolean boolean17 = metaphone8.isMetaphoneEqual("01230120022455012623010202", "");
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone8, "01230120022455012623010202", "");
        java.lang.String str22 = metaphone8.metaphone("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = refinedSoundex0.encode((java.lang.Object) metaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
    }

    @Test
    public void test0024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0024");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone3 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str5 = doubleMetaphone3.doubleMetaphone("H");
        java.lang.String str7 = doubleMetaphone3.doubleMetaphone("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = soundex0.encode((java.lang.Object) doubleMetaphone3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test0025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0025");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone5 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str7 = doubleMetaphone5.doubleMetaphone("H");
        doubleMetaphone5.setMaxCodeLen((int) (byte) 0);
        char char12 = doubleMetaphone5.charAt("hi!", 1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = soundex0.encode((java.lang.Object) doubleMetaphone5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + 'i' + "'", char12 == 'i');
    }

    @Test
    public void test0026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0026");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char[] charArray1 = null;
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str4 = soundex2.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = refinedSoundex0.encode((java.lang.Object) soundex2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
    }

    @Test
    public void test0027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0027");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: ORKP", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0028");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        java.lang.Object obj7 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = metaphone0.encode(obj7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test0029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0029");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        char[] charArray3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj4 = caverphone0.encode((java.lang.Object) charArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(charArray3);
    }

    @Test
    public void test0030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0030");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.Object obj15 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = metaphone0.encode(obj15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test0031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0031");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        java.lang.String str4 = soundex1.soundex("01230120022455012623010202");
        char[] charArray5 = null;
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = soundex1.encode((java.lang.Object) soundex6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
    }

    @Test
    public void test0032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0032");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        org.apache.commons.codec.language.Caverphone caverphone4 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str6 = caverphone4.caverphone("org.apache.commons.codec.EncoderException: HI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = soundex1.encode((java.lang.Object) caverphone4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "AKPKKMNSKT" + "'", str6, "AKPKKMNSKT");
    }

    @Test
    public void test0033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0033");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        java.lang.String str11 = metaphone0.metaphone("01230120022455012623010202");
        java.lang.Class<?> wildcardClass12 = metaphone0.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0034");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "1111111111", "O0940103030808306030830609053016080931");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0035");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A621");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0036");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = caverphone0.encode((java.lang.Object) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
    }

    @Test
    public void test0037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0037");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ORKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORKP" + "'", str1, "ORKP");
    }

    @Test
    public void test0038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0038");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = metaphone0.encode((java.lang.Object) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
    }

    @Test
    public void test0039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0039");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        char[] charArray5 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = soundex0.encode((java.lang.Object) soundex6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test0040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0040");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        java.lang.String str12 = doubleMetaphone8.doubleMetaphone("HI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "H" + "'", str12, "H");
    }

    @Test
    public void test0041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0041");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = refinedSoundex0.encode((java.lang.Object) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
    }

    @Test
    public void test0042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0042");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0043");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) '0');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = soundex1.encode((java.lang.Object) '0');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0044");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex();
        int int8 = refinedSoundex5.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = caverphone0.encode((java.lang.Object) int8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test0045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0045");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int5 = refinedSoundex2.difference("O0940103030808306030830609053016080931", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0046");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = 0;
        char char20 = doubleMetaphone15.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult22 = doubleMetaphone15.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult22.appendAlternate('\000');
        doubleMetaphoneResult22.append('#');
        java.lang.String str27 = doubleMetaphoneResult22.getAlternate();
        doubleMetaphoneResult22.appendPrimary('1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = metaphone0.encode((java.lang.Object) '1');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
    }

    @Test
    public void test0047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0047");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex3.encode("O0940103030808306030830609053016080931");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0048");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "H");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0049");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.Object obj9 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = caverphone0.encode(obj9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
    }

    @Test
    public void test0050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0050");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = refinedSoundex0.encode((java.lang.Object) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test0051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0051");
        char[] charArray1 = new char[] { 'i' };
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode('#');
        int int13 = refinedSoundex3.difference("AKPKKMNSKT", "A621");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = soundex2.encode((java.lang.Object) refinedSoundex3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'i' });
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test0052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0052");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex5.encode("O0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0053");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.soundex("AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0054");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.Metaphone metaphone9 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str11 = metaphone9.encode("");
        int int12 = metaphone9.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = caverphone0.encode((java.lang.Object) int12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test0055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0055");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AA11111111", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0056");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0057");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex1.soundex("AA11111111");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0058");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = 0;
        char char12 = doubleMetaphone7.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone7.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult14.appendAlternate('\000');
        doubleMetaphoneResult14.append('#');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
    }

    @Test
    public void test0059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0059");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = metaphone0.encode((java.lang.Object) refinedSoundex10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(refinedSoundex10);
    }

    @Test
    public void test0060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0060");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        char[] charArray8 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = caverphone0.encode((java.lang.Object) charArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(charArray8);
    }

    @Test
    public void test0061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0061");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str6 = refinedSoundex4.soundex("O000");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0062");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.Object obj9 = new java.lang.Object();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = caverphone0.encode(obj9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
    }

    @Test
    public void test0063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0063");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        int int4 = soundex3.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int7 = soundex3.difference("O0", "ORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test0064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0064");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        char[] charArray11 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex12 = new org.apache.commons.codec.language.RefinedSoundex(charArray11);
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray11);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = metaphone0.encode((java.lang.Object) soundex13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertArrayEquals(charArray11, new char[] { 'a' });
    }

    @Test
    public void test0065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0065");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        char[] charArray12 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = new org.apache.commons.codec.language.RefinedSoundex(charArray12);
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray12);
        int int15 = soundex14.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = caverphone0.encode((java.lang.Object) soundex14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertArrayEquals(charArray12, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test0066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0066");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        int int10 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test0067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0067");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A0");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0068");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: A0", "1111111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0069");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex1.difference("O620", "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test0070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0070");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex1.encode("AA11111111");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0071");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = soundex1.soundex("org.apache.commons.codec.EncoderException: ORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test0072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0072");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = '\000';
        doubleMetaphone11.setMaxCodeLen(4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = caverphone0.encode((java.lang.Object) 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
    }

    @Test
    public void test0073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0073");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = 0;
        char char16 = doubleMetaphone11.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone11.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult18.appendAlternate('\000');
        doubleMetaphoneResult18.append('#');
        java.lang.String str23 = doubleMetaphoneResult18.getAlternate();
        doubleMetaphoneResult18.appendPrimary('1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = refinedSoundex0.encode((java.lang.Object) '1');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0931" + "'", str10, "O0931");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
    }

    @Test
    public void test0074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0074");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        java.lang.String str10 = doubleMetaphone6.doubleMetaphone("HI");
        java.lang.String str12 = doubleMetaphone6.encode("O621");
        java.lang.Object obj13 = refinedSoundex0.encode((java.lang.Object) "O621");
        java.lang.Class<?> wildcardClass14 = refinedSoundex0.getClass();
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "H" + "'", str10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "O0" + "'", obj13, "O0");
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0075");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "1111111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0076");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        char[] charArray10 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = metaphone0.encode((java.lang.Object) soundex11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(charArray10);
    }

    @Test
    public void test0077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0077");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = metaphone0.encode((java.lang.Object) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test0078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0078");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        int int4 = soundex3.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int7 = soundex3.difference("O620", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test0079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0079");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        java.lang.String str11 = metaphone0.metaphone("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone12.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult19.appendAlternate('\000');
        java.lang.String str22 = doubleMetaphoneResult19.getAlternate();
        java.lang.String str23 = doubleMetaphoneResult19.getPrimary();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = metaphone0.encode((java.lang.Object) doubleMetaphoneResult19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
    }

    @Test
    public void test0080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0080");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) '0');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = soundex1.encode((java.lang.Object) 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0081");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        java.lang.String str4 = soundex1.soundex("01230120022455012623010202");
        java.lang.String str6 = soundex1.encode("1111111111");
        // The following exception was thrown during execution in test generation
        try {
            int int9 = soundex1.difference("org.apache.commons.codec.EncoderException: HI", "O");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test0082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0082");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("1111111111", false);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("hi!", false);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char13 = refinedSoundex11.getMappingCode('a');
        int int16 = refinedSoundex11.difference("", "hi!");
        int int19 = refinedSoundex11.difference("hi!", "");
        int int22 = refinedSoundex11.difference("", "");
        char char24 = refinedSoundex11.getMappingCode('i');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = doubleMetaphone0.encode((java.lang.Object) char24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(refinedSoundex11);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '0' + "'", char24 == '0');
    }

    @Test
    public void test0083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0083");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        org.apache.commons.codec.language.Metaphone metaphone1 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str3 = metaphone1.encode("");
        int int4 = metaphone1.getMaxCodeLen();
        metaphone1.setMaxCodeLen((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = refinedSoundex0.encode((java.lang.Object) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test0084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0084");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char3 = refinedSoundex1.getMappingCode('a');
        int int6 = refinedSoundex1.difference("", "hi!");
        char char8 = refinedSoundex1.getMappingCode('#');
        java.lang.String str10 = refinedSoundex1.soundex("01230120022455012623010202");
        java.lang.String str12 = refinedSoundex1.encode("A621");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) str12);
        boolean boolean16 = caverphone0.isCaverphoneEqual("O0", "A0");
        org.junit.Assert.assertNotNull(refinedSoundex1);
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '0' + "'", char3 == '0');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0" + "'", str12, "A0");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "A111111111" + "'", obj13, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test0085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0085");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        java.lang.Class<?> wildcardClass12 = metaphone0.getClass();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0086");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        // The following exception was thrown during execution in test generation
        try {
            int int12 = refinedSoundex5.difference("ORKP", "O0931");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
    }

    @Test
    public void test0087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0087");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        soundex1.setMaxLength((-1));
        // The following exception was thrown during execution in test generation
        try {
            int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "A ", "A");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test0088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0088");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        org.apache.commons.codec.language.Metaphone metaphone1 = new org.apache.commons.codec.language.Metaphone();
        metaphone1.setMaxCodeLen(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj4 = metaphone0.encode((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0089");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str12 = metaphone10.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str14 = metaphone10.encode("org.apache.commons.codec.EncoderException: ORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = refinedSoundex5.encode((java.lang.Object) metaphone10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ORKP" + "'", str12, "ORKP");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ORKP" + "'", str14, "ORKP");
    }

    @Test
    public void test0090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0090");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0091");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("org.apache.commons.codec.EncoderException: ORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test0092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0092");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str6 = refinedSoundex4.soundex("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 7 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0093");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str10 = metaphone0.metaphone("O");
        int int11 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test0094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0094");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int7 = refinedSoundex4.difference("", "org.apache.commons.codec.EncoderException: ORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0095");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone24 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone24.maxCodeLen = '\000';
        char char29 = doubleMetaphone24.charAt("", 0);
        boolean boolean33 = doubleMetaphone24.isDoubleMetaphoneEqual("A111111111", "A", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = caverphone0.encode((java.lang.Object) doubleMetaphone24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '\000' + "'", char29 == '\000');
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test0096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0096");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        soundex0.setMaxLength((int) '1');
        int int5 = soundex0.difference("H0", "AKP1111111");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test0097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0097");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O0931");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0098");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            int int7 = refinedSoundex4.difference("A ", "O621");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test0099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0099");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AKPKKMNSKT", "A");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0100");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        char[] charArray6 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray6);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = caverphone0.encode((java.lang.Object) charArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertArrayEquals(charArray6, new char[] { 'a' });
    }

    @Test
    public void test0101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0101");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: hi!", "O");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0102");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = '\000';
        char char12 = doubleMetaphone7.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult14 = doubleMetaphone7.new DoubleMetaphoneResult((int) ' ');
        java.lang.String str15 = doubleMetaphoneResult14.getPrimary();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = metaphone0.encode((java.lang.Object) doubleMetaphoneResult14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test0103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0103");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex1.difference("O620", "AA11111111");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test0104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0104");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "", " ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0105");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.Object obj24 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = caverphone0.encode(obj24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
    }

    @Test
    public void test0106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0106");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int5 = soundex1.difference("", "H0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test0107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0107");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("O000");
        char[] charArray5 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = soundex1.encode((java.lang.Object) charArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "O000" + "'", str3, "O000");
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertArrayEquals(charArray5, new char[] { 'a' });
    }

    @Test
    public void test0108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0108");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0109");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray8 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = caverphone0.encode((java.lang.Object) refinedSoundex9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertArrayEquals(charArray8, new char[] { 'a' });
    }

    @Test
    public void test0110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0110");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("HI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = refinedSoundex5.encode((java.lang.Object) "HI");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 7 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "H" + "'", str15, "H");
    }

    @Test
    public void test0111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0111");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("1111111111");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }

    @Test
    public void test0112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0112");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        java.lang.String str10 = doubleMetaphone6.doubleMetaphone("HI");
        java.lang.String str12 = doubleMetaphone6.encode("O621");
        java.lang.Object obj13 = refinedSoundex0.encode((java.lang.Object) "O621");
        char[] charArray14 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex15 = new org.apache.commons.codec.language.Soundex(charArray14);
        org.apache.commons.codec.language.Soundex soundex16 = new org.apache.commons.codec.language.Soundex(charArray14);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = refinedSoundex0.encode((java.lang.Object) charArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "H" + "'", str10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "O0" + "'", obj13, "O0");
        org.junit.Assert.assertNotNull(charArray14);
    }

    @Test
    public void test0113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0113");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = refinedSoundex3.difference("A1", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0114");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        java.lang.String str4 = metaphone0.encode("A621");
        org.apache.commons.codec.EncoderException encoderException6 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException8 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray9 = encoderException8.getSuppressed();
        encoderException6.addSuppressed((java.lang.Throwable) encoderException8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = metaphone0.encode((java.lang.Object) encoderException6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertArrayEquals(throwableArray9, new java.lang.Throwable[] {});
    }

    @Test
    public void test0115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0115");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        char[] charArray5 = null;
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray5);
        java.lang.String str8 = soundex6.encode("");
        soundex6.setMaxLength((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = caverphone0.encode((java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test0116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0116");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.soundex("H");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0117");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        java.lang.String str10 = metaphone0.metaphone("AKP1111111");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKP" + "'", str10, "AKP");
    }

    @Test
    public void test0118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0118");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A111111111", "A1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test0119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0119");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A111111111");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0120");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String[] strArray24 = new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" };
        boolean boolean25 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 1, (int) (short) 1, strArray24);
        boolean boolean26 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 10, (int) '#', strArray24);
        boolean boolean27 = org.apache.commons.codec.language.DoubleMetaphone.contains("O621", (int) (byte) 0, (int) (short) 10, strArray24);
        boolean boolean28 = org.apache.commons.codec.language.DoubleMetaphone.contains("A621", 3, 10, strArray24);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = caverphone0.encode((java.lang.Object) 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertArrayEquals(strArray24, new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" });
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test0121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0121");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        int int11 = metaphone0.getMaxCodeLen();
        java.lang.Object obj12 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = metaphone0.encode(obj12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test0122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0122");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int3 = soundex0.getMaxLength();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex();
        int int7 = refinedSoundex4.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = soundex0.encode((java.lang.Object) int7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test0123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0123");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0124");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A ");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) "A ");
        boolean boolean17 = metaphone0.isMetaphoneEqual("ORK", "H");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "A" + "'", obj14, "A");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test0125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0125");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("HI", "A111111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0126");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AKP", "01230120022455012623010202");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0127");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0128");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char[] charArray9 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = new org.apache.commons.codec.language.RefinedSoundex(charArray9);
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray9);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = refinedSoundex5.encode((java.lang.Object) soundex11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertArrayEquals(charArray9, new char[] { 'a' });
    }

    @Test
    public void test0129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0129");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int11 = soundex1.difference("ORKP", "A ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test0130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0130");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("01230120022455012623010202", "H0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0131");
        char[] charArray1 = new char[] { 'i' };
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = soundex2.soundex("ARK");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'i' });
    }

    @Test
    public void test0132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0132");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.setMaxCodeLen(10);
        doubleMetaphone0.maxCodeLen = 1;
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "1111111111", " ");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test0133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0133");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O0", "A111111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0134");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean12 = metaphone0.isMetaphoneEqual("A621", "");
        boolean boolean15 = metaphone0.isMetaphoneEqual("AKPKKMNSKT", "A111111111");
        org.apache.commons.codec.language.Metaphone metaphone16 = new org.apache.commons.codec.language.Metaphone();
        metaphone16.setMaxCodeLen(3);
        java.lang.String str20 = metaphone16.encode("");
        java.lang.String str22 = metaphone16.encode("");
        int int23 = metaphone16.getMaxCodeLen();
        int int24 = metaphone16.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = metaphone0.encode((java.lang.Object) metaphone16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
    }

    @Test
    public void test0135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0135");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex3.encode("org.apache.commons.codec.EncoderException: hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0136");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        java.lang.String str6 = refinedSoundex4.soundex("A621");
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A#" + "'", str6, "A#");
    }

    @Test
    public void test0137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0137");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        char[] charArray22 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex23 = new org.apache.commons.codec.language.Soundex(charArray22);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = caverphone0.encode((java.lang.Object) soundex23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertNotNull(charArray22);
    }

    @Test
    public void test0138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0138");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.encode("ORK");
        char[] charArray10 = null;
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray10);
        java.lang.String str13 = soundex11.soundex("");
        java.lang.Class<?> wildcardClass14 = soundex11.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = refinedSoundex0.encode((java.lang.Object) wildcardClass14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O093" + "'", str9, "O093");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0139");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        java.lang.String str4 = doubleMetaphone0.encode("A621");
        org.apache.commons.codec.language.Metaphone metaphone5 = new org.apache.commons.codec.language.Metaphone();
        metaphone5.setMaxCodeLen(3);
        java.lang.String str9 = metaphone5.encode("");
        java.lang.String str11 = metaphone5.encode("");
        metaphone5.setMaxCodeLen((int) (short) 10);
        int int14 = metaphone5.getMaxCodeLen();
        int int15 = metaphone5.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = doubleMetaphone0.encode((java.lang.Object) int15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test0140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0140");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult9 = doubleMetaphone0.new DoubleMetaphoneResult(0);
        int int10 = doubleMetaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Caverphone caverphone11 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str13 = caverphone11.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone11.caverphone("hi!");
        java.lang.String str17 = caverphone11.caverphone("");
        java.lang.String str19 = caverphone11.caverphone("HI");
        java.lang.String str21 = caverphone11.encode("1111111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = doubleMetaphone0.encode((java.lang.Object) caverphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AA11111111" + "'", str15, "AA11111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AA11111111" + "'", str19, "AA11111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "1111111111" + "'", str21, "1111111111");
    }

    @Test
    public void test0141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0141");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("AKP1111111");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AKP" + "'", str1, "AKP");
    }

    @Test
    public void test0142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0142");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        // The following exception was thrown during execution in test generation
        try {
            int int15 = refinedSoundex5.difference("O0931", "1111111111");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
    }

    @Test
    public void test0143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0143");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex1.soundex("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0144");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = '\000';
        char char19 = doubleMetaphone14.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone14.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult21.appendPrimary("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
    }

    @Test
    public void test0145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0145");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        java.lang.Object obj8 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = soundex1.encode(obj8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0146");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        org.apache.commons.codec.EncoderException encoderException5 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException7 = new org.apache.commons.codec.EncoderException("HI");
        encoderException5.addSuppressed((java.lang.Throwable) encoderException7);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = soundex1.encode((java.lang.Object) encoderException5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0147");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean7 = caverphone0.isCaverphoneEqual("O", "01230120022455012623010202");
        boolean boolean10 = caverphone0.isCaverphoneEqual("A ", "H");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test0148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0148");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "ARK", "org.apache.commons.codec.EncoderException: hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0149");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORK", "O620");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0150");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        int int8 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = soundex1.encode("O621");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test0151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0151");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone17.maxCodeLen = 0;
        char char22 = doubleMetaphone17.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult24 = doubleMetaphone17.new DoubleMetaphoneResult((int) '#');
        int int25 = doubleMetaphone17.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = metaphone0.encode((java.lang.Object) doubleMetaphone17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test0152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0152");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            int int8 = soundex1.difference("A111111111", "A1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0153");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str7 = soundex5.soundex("A0");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = soundex5.soundex("O0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
    }

    @Test
    public void test0154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0154");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char10 = refinedSoundex8.getMappingCode('a');
        int int13 = refinedSoundex8.difference("", "hi!");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = refinedSoundex0.encode((java.lang.Object) int13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertNotNull(refinedSoundex8);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '0' + "'", char10 == '0');
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test0155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0155");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        int int3 = doubleMetaphone0.maxCodeLen;
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ORK", "A111111111");
        doubleMetaphone0.maxCodeLen = 0;
        java.lang.String[] strArray22 = new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" };
        boolean boolean23 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 1, (int) (short) 1, strArray22);
        boolean boolean24 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 10, (int) '#', strArray22);
        boolean boolean25 = org.apache.commons.codec.language.DoubleMetaphone.contains("O621", (int) (byte) 0, (int) (short) 10, strArray22);
        boolean boolean26 = org.apache.commons.codec.language.DoubleMetaphone.contains("A621", 3, 10, strArray22);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = doubleMetaphone0.encode((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertArrayEquals(strArray22, new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" });
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test0156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0156");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = '\000';
        char char16 = doubleMetaphone11.charAt("", 0);
        java.lang.String str18 = doubleMetaphone11.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str22 = doubleMetaphone11.encode("O0");
        char char25 = doubleMetaphone11.charAt("O0940103030808306030830609053016080931", 0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = metaphone0.encode((java.lang.Object) doubleMetaphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + 'O' + "'", char25 == 'O');
    }

    @Test
    public void test0157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0157");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            int int7 = refinedSoundex4.difference("O621", "H000");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test0158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0158");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
    }

    @Test
    public void test0159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0159");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O093");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0160");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('\000');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = refinedSoundex4.encode("org.apache.commons.codec.EncoderException: A0");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
    }

    @Test
    public void test0161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0161");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("O0940103030808306030830609053016080931");
        java.lang.Object obj16 = refinedSoundex0.encode((java.lang.Object) "O0940103030808306030830609053016080931");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + obj16 + "' != '" + "O0" + "'", obj16, "O0");
    }

    @Test
    public void test0162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0162");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        char[] charArray10 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = new org.apache.commons.codec.language.RefinedSoundex(charArray10);
        org.apache.commons.codec.language.Soundex soundex12 = new org.apache.commons.codec.language.Soundex(charArray10);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = new org.apache.commons.codec.language.RefinedSoundex(charArray10);
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray10);
        int int15 = soundex14.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = soundex0.encode((java.lang.Object) int15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertArrayEquals(charArray10, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test0163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0163");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = '\000';
        boolean boolean14 = doubleMetaphone9.isDoubleMetaphoneEqual("ORKP", "H");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = soundex1.encode((java.lang.Object) "ORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test0164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0164");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AK11111111", "H0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0165");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "A1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0166");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        org.apache.commons.codec.language.Caverphone caverphone3 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str5 = caverphone3.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char8 = refinedSoundex6.getMappingCode('a');
        int int11 = refinedSoundex6.difference("", "hi!");
        char char13 = refinedSoundex6.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str16 = doubleMetaphone14.doubleMetaphone("H");
        java.lang.String str18 = doubleMetaphone14.doubleMetaphone("");
        java.lang.String str21 = doubleMetaphone14.doubleMetaphone("ORKP", true);
        java.lang.String str24 = doubleMetaphone14.doubleMetaphone("", false);
        java.lang.String str26 = doubleMetaphone14.encode("");
        java.lang.Object obj27 = refinedSoundex6.encode((java.lang.Object) "");
        java.lang.Object obj28 = caverphone3.encode(obj27);
        boolean boolean31 = caverphone3.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = refinedSoundex0.encode((java.lang.Object) caverphone3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "AKPKKMNSKT" + "'", str5, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex6);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '0' + "'", char8 == '0');
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + "" + "'", obj27, "");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "1111111111" + "'", obj28, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test0167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0167");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.Soundex soundex9 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex9.setMaxLength((int) (byte) -1);
        int int12 = soundex9.getMaxLength();
        soundex9.setMaxLength(10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = caverphone0.encode((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(soundex9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test0168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0168");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen(48);
        java.lang.Class<?> wildcardClass5 = metaphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0169");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        int int9 = soundex3.difference("A111111111", "01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            int int12 = soundex3.difference("O620", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test0170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0170");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char10 = refinedSoundex8.getMappingCode('a');
        int int13 = refinedSoundex8.difference("", "hi!");
        char char15 = refinedSoundex8.getMappingCode('#');
        java.lang.String str17 = refinedSoundex8.soundex("01230120022455012623010202");
        java.lang.String str19 = refinedSoundex8.encode("O");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = metaphone0.encode((java.lang.Object) refinedSoundex8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ORK" + "'", str7, "ORK");
        org.junit.Assert.assertNotNull(refinedSoundex8);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '0' + "'", char10 == '0');
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0" + "'", str19, "O0");
    }

    @Test
    public void test0171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0171");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        int int3 = soundex0.difference("H", "");
        org.apache.commons.codec.language.Metaphone metaphone4 = new org.apache.commons.codec.language.Metaphone();
        metaphone4.setMaxCodeLen(3);
        int int7 = metaphone4.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = soundex0.encode((java.lang.Object) metaphone4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test0172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0172");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.Object obj12 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = metaphone0.encode(obj12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test0173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0173");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex1.soundex("O0940103030808306030830609053016080940103030808306030830609053016080");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test0174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0174");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        java.lang.String str17 = doubleMetaphone13.encode("A621");
        boolean boolean21 = doubleMetaphone13.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult23 = doubleMetaphone13.new DoubleMetaphoneResult(10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = metaphone0.encode((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test0175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0175");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        soundex3.setMaxLength((int) (byte) -1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = soundex3.soundex("AKP1111111");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test0176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0176");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex1.difference("", "A000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0177");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex1.soundex("H000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0178");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = '\000';
        char char5 = doubleMetaphone0.charAt("", 0);
        java.lang.String str7 = doubleMetaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult11 = doubleMetaphone0.new DoubleMetaphoneResult((int) (byte) 100);
        int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "H0");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test0179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0179");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex3.encode("org.apache.commons.codec.EncoderException: A0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0180");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O941");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0181");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("ORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj4 = metaphone0.encode((java.lang.Object) 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
    }

    @Test
    public void test0182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0182");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            char char9 = refinedSoundex5.getMappingCode('O');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test0183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0183");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj5 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = metaphone0.encode(obj5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
    }

    @Test
    public void test0184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0184");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.EncoderException encoderException11 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("");
        encoderException11.addSuppressed((java.lang.Throwable) encoderException13);
        org.apache.commons.codec.EncoderException encoderException16 = new org.apache.commons.codec.EncoderException("hi!");
        encoderException13.addSuppressed((java.lang.Throwable) encoderException16);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = metaphone0.encode((java.lang.Object) encoderException13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test0185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0185");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        java.lang.Object obj11 = metaphone0.encode((java.lang.Object) "A ");
        char[] charArray12 = null;
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray12);
        int int14 = soundex13.getMaxLength();
        int int15 = soundex13.getMaxLength();
        soundex13.setMaxLength((int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = metaphone0.encode((java.lang.Object) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertEquals("'" + obj11 + "' != '" + "A" + "'", obj11, "A");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test0186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0186");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex14 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char16 = refinedSoundex14.getMappingCode('a');
        int int19 = refinedSoundex14.difference("", "hi!");
        int int22 = refinedSoundex14.difference("", "A");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = caverphone0.encode((java.lang.Object) refinedSoundex14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex14);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '0' + "'", char16 == '0');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test0187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0187");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength(100);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str12 = doubleMetaphone10.doubleMetaphone("H");
        doubleMetaphone10.setMaxCodeLen((int) (byte) 0);
        java.lang.String str17 = doubleMetaphone10.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone10.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult19.append('#', 'a');
        doubleMetaphoneResult19.append('O');
        doubleMetaphoneResult19.append("O621", "org.apache.commons.codec.EncoderException: A0");
        doubleMetaphoneResult19.append(" ", "ARKP");
        doubleMetaphoneResult19.append("AKPKMNSKT", "O000");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = soundex1.encode((java.lang.Object) "O000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test0188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0188");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char3 = refinedSoundex1.getMappingCode('a');
        int int6 = refinedSoundex1.difference("", "hi!");
        char char8 = refinedSoundex1.getMappingCode('#');
        java.lang.String str10 = refinedSoundex1.soundex("01230120022455012623010202");
        java.lang.String str12 = refinedSoundex1.encode("A621");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) str12);
        java.lang.String str15 = caverphone0.caverphone("O");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str18 = doubleMetaphone16.doubleMetaphone("H");
        doubleMetaphone16.setMaxCodeLen((int) (byte) 0);
        char char23 = doubleMetaphone16.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult25 = doubleMetaphone16.new DoubleMetaphoneResult((int) '4');
        java.lang.String str26 = doubleMetaphoneResult25.getAlternate();
        doubleMetaphoneResult25.append("A000");
        java.lang.Object obj29 = caverphone0.encode((java.lang.Object) "A000");
        org.junit.Assert.assertNotNull(refinedSoundex1);
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '0' + "'", char3 == '0');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0" + "'", str12, "A0");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "A111111111" + "'", obj13, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + 'i' + "'", char23 == 'i');
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "A111111111" + "'", obj29, "A111111111");
    }

    @Test
    public void test0189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0189");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A1");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0190");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        java.lang.String str5 = refinedSoundex3.soundex("A000");
        // The following exception was thrown during execution in test generation
        try {
            int int8 = refinedSoundex3.difference("O621", "ARKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A1" + "'", str5, "A1");
    }

    @Test
    public void test0191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0191");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        java.lang.String str4 = doubleMetaphone0.encode("A621");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult6 = doubleMetaphone0.new DoubleMetaphoneResult(48);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str9 = refinedSoundex7.soundex("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = doubleMetaphone0.encode((java.lang.Object) refinedSoundex7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test0192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0192");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = '\000';
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = caverphone0.encode((java.lang.Object) '\000');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
    }

    @Test
    public void test0193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0193");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: hi!");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
    }

    @Test
    public void test0194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0194");
        char[] charArray1 = new char[] { 'i' };
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = soundex2.soundex("O000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'i' });
    }

    @Test
    public void test0195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0195");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A ", "AKPK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0196");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        int int13 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test0197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0197");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        char char12 = refinedSoundex0.getMappingCode('a');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = '\000';
        char char18 = doubleMetaphone13.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone13.new DoubleMetaphoneResult((int) ' ');
        java.lang.String str21 = doubleMetaphoneResult20.getPrimary();
        boolean boolean22 = doubleMetaphoneResult20.isComplete();
        doubleMetaphoneResult20.append('a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test0198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0198");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = 0;
        char char15 = doubleMetaphone10.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str17 = doubleMetaphone10.encode("A");
        java.lang.Object obj19 = doubleMetaphone10.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        int int20 = doubleMetaphone10.getMaxCodeLen();
        java.lang.String str23 = doubleMetaphone10.doubleMetaphone("A", false);
        doubleMetaphone10.setMaxCodeLen((int) (short) 100);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = metaphone0.encode((java.lang.Object) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "" + "'", obj19, "");
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
    }

    @Test
    public void test0199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0199");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean(" ");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }

    @Test
    public void test0200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0200");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str16 = doubleMetaphone14.doubleMetaphone("H");
        doubleMetaphone14.setMaxCodeLen((int) (byte) 0);
        java.lang.String str21 = doubleMetaphone14.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone14.encode("hi!");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
    }

    @Test
    public void test0201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0201");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        int int9 = soundex3.difference("A111111111", "01230120022455012623010202");
        int int10 = soundex3.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone11 = new org.apache.commons.codec.language.Metaphone();
        metaphone11.setMaxCodeLen(3);
        int int14 = metaphone11.getMaxCodeLen();
        java.lang.String str16 = metaphone11.encode("hi!");
        java.lang.String str18 = metaphone11.encode("O621");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = soundex3.encode((java.lang.Object) metaphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "H" + "'", str16, "H");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O" + "'", str18, "O");
    }

    @Test
    public void test0202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0202");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("1111111111", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0203");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080");
        java.lang.Object obj13 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = metaphone0.encode(obj13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
    }

    @Test
    public void test0204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0204");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        int int6 = soundex5.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = soundex5.encode("O0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test0205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0205");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        metaphone0.setMaxCodeLen((int) '4');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test0206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0206");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        char char15 = refinedSoundex0.getMappingCode('i');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '0' + "'", char15 == '0');
    }

    @Test
    public void test0207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0207");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.metaphone("A0");
        java.lang.String str6 = metaphone0.encode("H");
        org.apache.commons.codec.EncoderException encoderException8 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Object obj9 = metaphone0.encode((java.lang.Object) "HI");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "H" + "'", str6, "H");
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
    }

    @Test
    public void test0208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0208");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("");
        boolean boolean10 = metaphone0.isMetaphoneEqual("", "H");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str15 = doubleMetaphone13.doubleMetaphone("H");
        doubleMetaphone13.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone13.maxCodeLen = 1;
        java.lang.String str22 = doubleMetaphone13.doubleMetaphone("O0931", true);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = metaphone0.encode((java.lang.Object) doubleMetaphone13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A" + "'", str22, "A");
    }

    @Test
    public void test0209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0209");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str13 = soundex11.encode("ARKP");
        java.lang.String str15 = soundex11.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj17 = soundex11.encode((java.lang.Object) "ORK");
        soundex11.setMaxLength(4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = doubleMetaphone0.encode((java.lang.Object) soundex11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A621" + "'", str13, "A621");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O621" + "'", str15, "O621");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "O620" + "'", obj17, "O620");
    }

    @Test
    public void test0210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0210");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        doubleMetaphone6.setMaxCodeLen((int) (byte) 0);
        java.lang.String str13 = doubleMetaphone6.doubleMetaphone("", false);
        int int14 = doubleMetaphone6.maxCodeLen;
        org.apache.commons.codec.language.Caverphone caverphone15 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str17 = caverphone15.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str19 = caverphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str21 = caverphone15.encode("A");
        java.lang.Object obj22 = doubleMetaphone6.encode((java.lang.Object) str21);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = soundex3.encode((java.lang.Object) doubleMetaphone6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKKMNSKT" + "'", str19, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A111111111" + "'", str21, "A111111111");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "" + "'", obj22, "");
    }

    @Test
    public void test0211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0211");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "A ");
        java.lang.String str13 = metaphone0.encode("ARK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ARK" + "'", str13, "ARK");
    }

    @Test
    public void test0212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0212");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A000");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0213");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        int int10 = refinedSoundex5.difference("", " ");
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test0214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0214");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength(100);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = soundex1.encode("A#");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0215");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = soundex2.encode((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test0216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0216");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("ARK", "AA11111111");
        char[] charArray18 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex19 = new org.apache.commons.codec.language.RefinedSoundex(charArray18);
        org.apache.commons.codec.language.Soundex soundex20 = new org.apache.commons.codec.language.Soundex(charArray18);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex21 = new org.apache.commons.codec.language.RefinedSoundex(charArray18);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = caverphone0.encode((java.lang.Object) refinedSoundex21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertArrayEquals(charArray18, new char[] { 'a' });
    }

    @Test
    public void test0217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0217");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str7 = soundex1.encode("AA11111111");
        int int8 = soundex1.getMaxLength();
        java.lang.String str10 = soundex1.encode("ORKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O621" + "'", str10, "O621");
    }

    @Test
    public void test0218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0218");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int11 = soundex1.difference("", "org.apache.commons.codec.EncoderException: O000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test0219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0219");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0220");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: HI", "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0221");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("org.apache.commons.codec.EncoderException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0222");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean13 = doubleMetaphone4.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char16 = doubleMetaphone4.charAt("01230120022455012623010202", (int) (short) 1);
        char char19 = doubleMetaphone4.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone4.maxCodeLen = (byte) 10;
        boolean boolean24 = doubleMetaphone4.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0940103030808306030830609053016080");
        int int25 = doubleMetaphone4.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '1' + "'", char16 == '1');
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + 'O' + "'", char19 == 'O');
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
    }

    @Test
    public void test0223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0223");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "O0931");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0224");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("A000", "");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test0225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0225");
        char[] charArray0 = null;
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str3 = refinedSoundex1.encode("AKP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0226");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A", "O093");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0227");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("ORKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        doubleMetaphone8.setMaxCodeLen((int) (byte) 0);
        char char15 = doubleMetaphone8.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult17 = doubleMetaphone8.new DoubleMetaphoneResult((int) '4');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = soundex1.encode((java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'i' + "'", char15 == 'i');
    }

    @Test
    public void test0228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0228");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.Class<?> wildcardClass12 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test0229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0229");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A ", "O0940103030808306030830609053016080931");
        int int10 = refinedSoundex0.difference("O", "1111111111");
        org.apache.commons.codec.language.Metaphone metaphone11 = new org.apache.commons.codec.language.Metaphone();
        metaphone11.setMaxCodeLen(3);
        java.lang.String str15 = metaphone11.encode("");
        java.lang.String str17 = metaphone11.encode("");
        metaphone11.setMaxCodeLen((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = refinedSoundex0.encode((java.lang.Object) metaphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080931" + "'", str4, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
    }

    @Test
    public void test0230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0230");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.caverphone("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone26 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone26.maxCodeLen = '\000';
        char char31 = doubleMetaphone26.charAt("", 0);
        java.lang.String str33 = doubleMetaphone26.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str35 = doubleMetaphone26.doubleMetaphone("");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult37 = doubleMetaphone26.new DoubleMetaphoneResult((int) (byte) 100);
        int int38 = doubleMetaphone26.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = caverphone0.encode((java.lang.Object) int38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '\000' + "'", char31 == '\000');
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test0231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0231");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            int int13 = soundex1.difference("O0931", "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test0232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0232");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        int int9 = soundex3.difference("A111111111", "01230120022455012623010202");
        int int10 = soundex3.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int13 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex3, "O000", "H");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test0233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0233");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Metaphone metaphone2 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str4 = metaphone2.encode("");
        boolean boolean7 = metaphone2.isMetaphoneEqual("hi!", "");
        java.lang.String str9 = metaphone2.encode("");
        boolean boolean12 = metaphone2.isMetaphoneEqual("", "H");
        java.lang.String str14 = metaphone2.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = soundex1.encode((java.lang.Object) metaphone2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
    }

    @Test
    public void test0234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0234");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
    }

    @Test
    public void test0235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0235");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        char char9 = refinedSoundex5.getMappingCode('1');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
    }

    @Test
    public void test0236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0236");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        java.lang.String str5 = refinedSoundex3.soundex("A000");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        doubleMetaphone6.setMaxCodeLen((int) (byte) 0);
        java.lang.String str13 = doubleMetaphone6.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult15 = doubleMetaphone6.new DoubleMetaphoneResult(0);
        java.lang.String str16 = doubleMetaphoneResult15.getPrimary();
        doubleMetaphoneResult15.append("H");
        doubleMetaphoneResult15.append("AKP1111111", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = refinedSoundex3.encode((java.lang.Object) doubleMetaphoneResult15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A1" + "'", str5, "A1");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
    }

    @Test
    public void test0237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0237");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        java.lang.String str4 = doubleMetaphone0.encode("A621");
        boolean boolean8 = doubleMetaphone0.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        org.apache.commons.codec.language.SoundexUtils soundexUtils9 = new org.apache.commons.codec.language.SoundexUtils();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = doubleMetaphone0.encode((java.lang.Object) soundexUtils9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test0238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0238");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        java.lang.String str5 = refinedSoundex3.soundex("A000");
        // The following exception was thrown during execution in test generation
        try {
            int int8 = refinedSoundex3.difference("hi!", "org.apache.commons.codec.EncoderException: O000");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 7 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A1" + "'", str5, "A1");
    }

    @Test
    public void test0239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0239");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        metaphone0.setMaxCodeLen((-1));
        boolean boolean14 = metaphone0.isMetaphoneEqual("A0", "HI");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test0240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0240");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str14 = metaphone12.encode("");
        boolean boolean17 = metaphone12.isMetaphoneEqual("hi!", "");
        java.lang.String str19 = metaphone12.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = caverphone0.encode((java.lang.Object) metaphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
    }

    @Test
    public void test0241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0241");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.soundex("O621");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0242");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = soundex1.encode("A0313836");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test0243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0243");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A#");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0244");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex16 = new org.apache.commons.codec.language.RefinedSoundex(charArray15);
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray15);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = new org.apache.commons.codec.language.RefinedSoundex(charArray15);
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray15);
        org.apache.commons.codec.language.Soundex soundex20 = new org.apache.commons.codec.language.Soundex(charArray15);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = refinedSoundex0.encode((java.lang.Object) charArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertArrayEquals(charArray15, new char[] { 'a' });
    }

    @Test
    public void test0245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0245");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("H", "A");
        char char13 = refinedSoundex0.getMappingCode('a');
        java.lang.Class<?> wildcardClass14 = refinedSoundex0.getClass();
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0246");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0247");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A0931");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0248");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = 0;
        char char13 = doubleMetaphone8.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean17 = doubleMetaphone8.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char20 = doubleMetaphone8.charAt("01230120022455012623010202", (int) (short) 1);
        char char23 = doubleMetaphone8.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone8.maxCodeLen = 100;
        int int28 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone8, "O621", "");
        int int29 = doubleMetaphone8.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = soundex1.encode((java.lang.Object) doubleMetaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '1' + "'", char20 == '1');
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + 'O' + "'", char23 == 'O');
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
    }

    @Test
    public void test0249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0249");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = refinedSoundex5.encode("O000");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0250");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int6 = soundex1.difference("AA11111111", "O0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test0251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0251");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        java.lang.String str12 = refinedSoundex0.soundex("AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
    }

    @Test
    public void test0252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0252");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int3 = soundex0.getMaxLength();
        soundex0.setMaxLength((int) (short) -1);
        org.apache.commons.codec.language.Metaphone metaphone6 = new org.apache.commons.codec.language.Metaphone();
        metaphone6.setMaxCodeLen(3);
        int int9 = metaphone6.getMaxCodeLen();
        java.lang.String str11 = metaphone6.metaphone("01230120022455012623010202");
        java.lang.String str13 = metaphone6.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str15 = metaphone6.metaphone("ORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = soundex0.encode((java.lang.Object) metaphone6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O" + "'", str13, "O");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORK" + "'", str15, "ORK");
    }

    @Test
    public void test0253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0253");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        int int16 = refinedSoundex0.difference("AA11111111", "01230120022455012623010202");
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("ORKP");
        java.lang.Throwable[] throwableArray19 = encoderException18.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = refinedSoundex0.encode((java.lang.Object) encoderException18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertArrayEquals(throwableArray19, new java.lang.Throwable[] {});
    }

    @Test
    public void test0254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0254");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 100);
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "");
        char char12 = doubleMetaphone0.charAt("H0", 4);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
    }

    @Test
    public void test0255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0255");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int6 = soundex1.difference("O0", "org.apache.commons.codec.EncoderException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test0256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0256");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0257");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str19 = doubleMetaphone12.encode("A");
        java.lang.Object obj21 = doubleMetaphone12.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        int int22 = doubleMetaphone12.getMaxCodeLen();
        java.lang.String str25 = doubleMetaphone12.doubleMetaphone("A", false);
        boolean boolean29 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ", "org.apache.commons.codec.EncoderException: A0", true);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult31 = doubleMetaphone12.new DoubleMetaphoneResult((int) '\000');
        doubleMetaphoneResult31.append("A313", "");
        java.lang.Object obj35 = caverphone0.encode((java.lang.Object) "A313");
        java.lang.String str37 = caverphone0.encode("ARKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "" + "'", obj21, "");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "A111111111" + "'", obj35, "A111111111");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "AKPKMNSK11" + "'", str37, "AKPKMNSK11");
    }

    @Test
    public void test0258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0258");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        java.lang.String str10 = metaphone0.metaphone("O620");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
    }

    @Test
    public void test0259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0259");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = (byte) 10;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A", "A");
        int int21 = doubleMetaphone0.maxCodeLen;
        boolean boolean24 = doubleMetaphone0.isDoubleMetaphoneEqual("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "O000");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test0260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0260");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str5 = soundex3.soundex("01230120022455012623010202");
        soundex3.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex3.difference("O0940103030808306030830609053016080940103030808306030830609053016080", "A1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0261");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("AA11111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = '\000';
        doubleMetaphone12.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone12.new DoubleMetaphoneResult((int) '1');
        doubleMetaphoneResult18.appendPrimary(' ');
        doubleMetaphoneResult18.appendAlternate("A621");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AA11111111" + "'", str11, "AA11111111");
    }

    @Test
    public void test0262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0262");
        char[] charArray0 = new char[] {};
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        char char3 = refinedSoundex1.getMappingCode('1');
        // The following exception was thrown during execution in test generation
        try {
            int int6 = refinedSoundex1.difference("AA11111111", "A000");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 0 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertArrayEquals(charArray0, new char[] {});
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '\000' + "'", char3 == '\000');
    }

    @Test
    public void test0263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0263");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        int int12 = refinedSoundex5.difference(" ", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = refinedSoundex5.soundex("O000");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test0264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0264");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        metaphone0.setMaxCodeLen((int) 'o');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
    }

    @Test
    public void test0265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0265");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char11 = refinedSoundex9.getMappingCode('a');
        int int14 = refinedSoundex9.difference("", "hi!");
        char char16 = refinedSoundex9.getMappingCode('0');
        char char18 = refinedSoundex9.getMappingCode('a');
        java.lang.String str20 = refinedSoundex9.soundex("1111111111");
        char char22 = refinedSoundex9.getMappingCode('\000');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = caverphone0.encode((java.lang.Object) refinedSoundex9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex9);
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '0' + "'", char11 == '0');
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '0' + "'", char18 == '0');
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
    }

    @Test
    public void test0266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0266");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPXKMNSK" + "'", str1, "ARKPXKMNSK");
    }

    @Test
    public void test0267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0267");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        java.lang.String str9 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int10 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test0268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0268");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("AA11111111");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AA" + "'", str1, "AA");
    }

    @Test
    public void test0269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0269");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("A313");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone28.maxCodeLen = '\000';
        int int31 = doubleMetaphone28.getMaxCodeLen();
        boolean boolean34 = doubleMetaphone28.isDoubleMetaphoneEqual("A621", "AKPKKMNSKT");
        doubleMetaphone28.maxCodeLen = 35;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = caverphone0.encode((java.lang.Object) doubleMetaphone28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A111111111" + "'", str27, "A111111111");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test0270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0270");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O0940103030808306030830609053016080", "ARK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0271");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int5 = soundex0.difference("A0", "");
        java.lang.String str7 = soundex0.encode("A0313836");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
    }

    @Test
    public void test0272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0272");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        boolean boolean9 = caverphone0.isCaverphoneEqual("A0931", "A0931");
        boolean boolean12 = caverphone0.isCaverphoneEqual("ORKPXKMNSK", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test0273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0273");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.soundex("A0313836");
        java.lang.Object obj11 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = soundex0.encode(obj11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
    }

    @Test
    public void test0274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0274");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('\000');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone7.maxCodeLen = 0;
        char char12 = doubleMetaphone7.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean16 = doubleMetaphone7.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char19 = doubleMetaphone7.charAt("01230120022455012623010202", (int) (short) 1);
        char char22 = doubleMetaphone7.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone7.maxCodeLen = 100;
        boolean boolean27 = doubleMetaphone7.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        boolean boolean30 = doubleMetaphone7.isDoubleMetaphoneEqual("O621", "O093");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = refinedSoundex4.encode((java.lang.Object) "O093");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '1' + "'", char19 == '1');
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + 'O' + "'", char22 == 'O');
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test0275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0275");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
    }

    @Test
    public void test0276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0276");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        metaphone0.setMaxCodeLen((int) (short) 0);
        org.apache.commons.codec.language.Caverphone caverphone11 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str13 = caverphone11.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone11.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone11.encode("");
        java.lang.String str19 = caverphone11.encode("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = metaphone0.encode((java.lang.Object) caverphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "1111111111" + "'", str19, "1111111111");
    }

    @Test
    public void test0277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0277");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O0", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0278");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        int int9 = soundex1.getMaxLength();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test0279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0279");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.encode("ORK");
        char[] charArray14 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex15 = new org.apache.commons.codec.language.RefinedSoundex(charArray14);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex16 = new org.apache.commons.codec.language.RefinedSoundex(charArray14);
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray14);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = new org.apache.commons.codec.language.RefinedSoundex(charArray14);
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray14);
        org.apache.commons.codec.language.Soundex soundex20 = new org.apache.commons.codec.language.Soundex(charArray14);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = refinedSoundex0.encode((java.lang.Object) soundex20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O093" + "'", str9, "O093");
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertArrayEquals(charArray14, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test0280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0280");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('\000');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
    }

    @Test
    public void test0281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0281");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("ORKP");
        char char12 = refinedSoundex0.getMappingCode('1');
        char char14 = refinedSoundex0.getMappingCode('O');
        java.lang.String str16 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str19 = doubleMetaphone17.doubleMetaphone("H");
        doubleMetaphone17.setMaxCodeLen((int) (byte) 0);
        java.lang.String str24 = doubleMetaphone17.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult26 = doubleMetaphone17.new DoubleMetaphoneResult(0);
        java.lang.String str27 = doubleMetaphoneResult26.getAlternate();
        doubleMetaphoneResult26.append('\000');
        doubleMetaphoneResult26.append('#', '#');
        java.lang.String str33 = doubleMetaphoneResult26.getPrimary();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0931" + "'", str10, "O0931");
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '0' + "'", char14 == '0');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O0940103030808306030830609053016080940103030808306030830609053016080931" + "'", str16, "O0940103030808306030830609053016080940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
    }

    @Test
    public void test0282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0282");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Metaphone metaphone6 = new org.apache.commons.codec.language.Metaphone();
        metaphone6.setMaxCodeLen(3);
        int int9 = metaphone6.getMaxCodeLen();
        int int10 = metaphone6.getMaxCodeLen();
        int int11 = metaphone6.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = refinedSoundex5.encode((java.lang.Object) metaphone6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test0283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0283");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("AA11111111");
        java.lang.Object obj12 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = caverphone0.encode(obj12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AA11111111" + "'", str11, "AA11111111");
    }

    @Test
    public void test0284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0284");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("O000");
        java.lang.String str5 = soundex1.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "O000" + "'", str3, "O000");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0285");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKP", "A031");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0286");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPKSKMNSK", "AKP1111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0287");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A0313836");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0288");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            int int13 = soundex1.difference("ARK", "O093");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test0289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0289");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        java.lang.Class<?> wildcardClass17 = metaphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0290");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        char char9 = refinedSoundex4.getMappingCode('a');
        int int12 = refinedSoundex4.difference("ARKP", "org.apache.commons.codec.EncoderException: hi!");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test0291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0291");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        int int16 = metaphone13.getMaxCodeLen();
        boolean boolean19 = metaphone13.isMetaphoneEqual("", "");
        boolean boolean22 = metaphone13.isMetaphoneEqual("01230120022455012623010202", "");
        int int25 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone13, "01230120022455012623010202", "");
        java.lang.String str27 = metaphone13.encode("O093");
        boolean boolean30 = metaphone13.isMetaphoneEqual("A313", "org.apache.commons.codec.EncoderException: ");
        java.lang.String str32 = metaphone13.metaphone("O620");
        java.lang.Object obj33 = metaphone0.encode((java.lang.Object) str32);
        metaphone0.setMaxCodeLen((int) '1');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "O" + "'", str27, "O");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "O" + "'", str32, "O");
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "O" + "'", obj33, "O");
    }

    @Test
    public void test0292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0292");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARK", "O0931");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0293");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone13.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str19 = caverphone13.encode("");
        java.lang.String str21 = caverphone13.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone22.maxCodeLen = 0;
        char char27 = doubleMetaphone22.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult29 = doubleMetaphone22.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult29.appendAlternate('\000');
        java.lang.String str32 = doubleMetaphoneResult29.getAlternate();
        java.lang.String str33 = doubleMetaphoneResult29.getPrimary();
        java.lang.Object obj34 = caverphone13.encode((java.lang.Object) str33);
        java.lang.String str36 = caverphone13.caverphone("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = caverphone0.encode((java.lang.Object) caverphone13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "1111111111" + "'", str19, "1111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "1111111111" + "'", str21, "1111111111");
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '\000' + "'", char27 == '\000');
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + obj34 + "' != '" + "1111111111" + "'", obj34, "1111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
    }

    @Test
    public void test0294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0294");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str13 = metaphone0.encode("A313");
        char[] charArray14 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = metaphone0.encode((java.lang.Object) charArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNotNull(charArray14);
    }

    @Test
    public void test0295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0295");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        boolean boolean31 = caverphone0.isCaverphoneEqual("ARKPXKMNSKTKNKTRKSPXN", "ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AKPKKMNSKT" + "'", str28, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test0296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0296");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.String str16 = metaphone0.metaphone("A");
        boolean boolean19 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ", "ARKPXKMNSKTKNKTRKS");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test0297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0297");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A111111111O620", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0298");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str5 = refinedSoundex3.encode("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A062125232523621256212523252362125" + "'", str5, "A062125232523621256212523252362125");
    }

    @Test
    public void test0299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0299");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) 'a');
        boolean boolean13 = metaphone0.isMetaphoneEqual("O941", "ARKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test0300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0300");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str16 = doubleMetaphone14.doubleMetaphone("H");
        doubleMetaphone14.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone14.maxCodeLen = '0';
        int int21 = doubleMetaphone14.getMaxCodeLen();
        java.lang.String str23 = doubleMetaphone14.encode("AKP");
        java.lang.Object obj24 = metaphone0.encode((java.lang.Object) str23);
        boolean boolean27 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 48 + "'", int21 == 48);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "AKP" + "'", str23, "AKP");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "AKP" + "'", obj24, "AKP");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test0301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0301");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.caverphone("A0");
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        metaphone12.setMaxCodeLen(3);
        java.lang.String str16 = metaphone12.encode("");
        java.lang.String str18 = metaphone12.encode("");
        metaphone12.setMaxCodeLen((int) (short) 10);
        int int21 = metaphone12.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone22 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str24 = metaphone22.encode("");
        java.lang.Object obj25 = metaphone12.encode((java.lang.Object) "");
        int int26 = metaphone12.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = caverphone0.encode((java.lang.Object) int26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A111111111" + "'", str11, "A111111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
    }

    @Test
    public void test0302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0302");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        int int7 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (byte) 1);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test0303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0303");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str7 = metaphone0.metaphone("A#");
        java.lang.String str9 = metaphone0.encode("A");
        org.apache.commons.codec.EncoderException encoderException11 = new org.apache.commons.codec.EncoderException("HI");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray14 = encoderException13.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException16 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException13.addSuppressed((java.lang.Throwable) encoderException16);
        encoderException11.addSuppressed((java.lang.Throwable) encoderException16);
        java.lang.Throwable[] throwableArray19 = encoderException11.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = metaphone0.encode((java.lang.Object) encoderException11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A" + "'", str7, "A");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertArrayEquals(throwableArray14, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test0304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0304");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        soundex0.setMaxLength(0);
        java.lang.String str9 = soundex0.encode("1111111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test0305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0305");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str15 = caverphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
    }

    @Test
    public void test0306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0306");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        int int11 = soundex0.difference("H000", "HI");
        char[] charArray12 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray12);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex14 = new org.apache.commons.codec.language.RefinedSoundex(charArray12);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = soundex0.encode((java.lang.Object) charArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test0307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0307");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.Caverphone caverphone10 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str12 = caverphone10.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str14 = caverphone10.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str16 = caverphone10.encode("A");
        java.lang.String str18 = caverphone10.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = caverphone0.encode((java.lang.Object) caverphone10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKKMNSKT" + "'", str14, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A111111111" + "'", str16, "A111111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "1111111111" + "'", str18, "1111111111");
    }

    @Test
    public void test0308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0308");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        // The following exception was thrown during execution in test generation
        try {
            int int15 = refinedSoundex5.difference("org.apache.commons.codec.EncoderExc", "AKPKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
    }

    @Test
    public void test0309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0309");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        java.lang.String str23 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        boolean boolean26 = metaphone0.isMetaphoneEqual("ORK", "AKP1111111");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str23, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test0310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0310");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0311");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        java.lang.String str13 = doubleMetaphone9.doubleMetaphone("");
        java.lang.String str16 = doubleMetaphone9.doubleMetaphone("ORKP", true);
        java.lang.String str19 = doubleMetaphone9.doubleMetaphone("", false);
        java.lang.String str21 = doubleMetaphone9.doubleMetaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int22 = doubleMetaphone9.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = caverphone0.encode((java.lang.Object) int22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
    }

    @Test
    public void test0312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0312");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: HI", "ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0313");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int12 = soundex1.difference("A#", "H0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        java.lang.String str17 = doubleMetaphone13.encode("A621");
        boolean boolean21 = doubleMetaphone13.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        java.lang.String str23 = doubleMetaphone13.encode("");
        boolean boolean27 = doubleMetaphone13.isDoubleMetaphoneEqual("A621", "org.apache.commons.codec.EncoderException: hi!", false);
        doubleMetaphone13.maxCodeLen = '0';
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult31 = doubleMetaphone13.new DoubleMetaphoneResult(100);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = soundex1.encode((java.lang.Object) doubleMetaphoneResult31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test0314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0314");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        java.lang.String str10 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.Metaphone metaphone11 = new org.apache.commons.codec.language.Metaphone();
        metaphone11.setMaxCodeLen(3);
        java.lang.String str15 = metaphone11.encode("");
        int int18 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone11, "hi!", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = refinedSoundex0.encode((java.lang.Object) int18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0940103030808306030830609053016080" + "'", str10, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test0315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0315");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKP" + "'", str1, "ARKP");
    }

    @Test
    public void test0316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0316");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0317");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        java.lang.String str9 = soundex1.encode("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            int int12 = soundex1.difference("O0", "A1111111114r");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test0318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0318");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex4.setMaxLength((int) (short) 0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = soundex4.encode("AKPKMNSK11");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0319");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "4", "A0313836");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0320");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.Object obj4 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = metaphone0.encode(obj4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test0321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0321");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        metaphone10.setMaxCodeLen(3);
        java.lang.String str14 = metaphone10.encode("");
        java.lang.String str16 = metaphone10.encode("");
        int int19 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone10, "AKPKKMNSKT", "A");
        java.lang.Class<?> wildcardClass20 = metaphone10.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = metaphone0.encode((java.lang.Object) wildcardClass20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test0322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0322");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) (short) 0);
        int int8 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str11 = soundex9.encode("ARKP");
        java.lang.String str13 = soundex9.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int14 = soundex9.getMaxLength();
        soundex9.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = doubleMetaphone0.encode((java.lang.Object) soundex9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A621" + "'", str11, "A621");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O621" + "'", str13, "O621");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test0323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0323");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("");
        boolean boolean30 = caverphone0.isCaverphoneEqual("4", "AA");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "1111111111" + "'", str27, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test0324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0324");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O0", "ARK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0325");
        char[] charArray1 = new char[] { 'i' };
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode('0');
        char char12 = refinedSoundex3.getMappingCode('a');
        java.lang.String str14 = refinedSoundex3.soundex("1111111111");
        char char16 = refinedSoundex3.getMappingCode('i');
        int int19 = refinedSoundex3.difference("A000", "01230120022455012623010202");
        int int22 = refinedSoundex3.difference("AKPK", "AKP1111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = soundex2.encode((java.lang.Object) "AKPK");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'i' });
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '0' + "'", char16 == '0');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
    }

    @Test
    public void test0326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0326");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = refinedSoundex7.difference("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "A1");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 17 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0327");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O0931");
        java.lang.Class<?> wildcardClass5 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test0328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0328");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        metaphone0.setMaxCodeLen(48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test0329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0329");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("AKPKMNSKT");
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("A ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = caverphone0.encode((java.lang.Object) encoderException15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKT1" + "'", str13, "AKPKMNSKT1");
    }

    @Test
    public void test0330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0330");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: org.ap");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
    }

    @Test
    public void test0331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0331");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex5, "", "A313");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = refinedSoundex5.soundex("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test0332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0332");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        org.apache.commons.codec.EncoderException encoderException6 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException8 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray9 = encoderException8.getSuppressed();
        encoderException6.addSuppressed((java.lang.Throwable) encoderException8);
        org.apache.commons.codec.EncoderException encoderException12 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: A0");
        encoderException8.addSuppressed((java.lang.Throwable) encoderException12);
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException17 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray18 = encoderException17.getSuppressed();
        encoderException15.addSuppressed((java.lang.Throwable) encoderException17);
        org.apache.commons.codec.EncoderException encoderException21 = new org.apache.commons.codec.EncoderException("A ");
        encoderException17.addSuppressed((java.lang.Throwable) encoderException21);
        org.apache.commons.codec.EncoderException encoderException24 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException26 = new org.apache.commons.codec.EncoderException("");
        encoderException24.addSuppressed((java.lang.Throwable) encoderException26);
        org.apache.commons.codec.EncoderException encoderException29 = new org.apache.commons.codec.EncoderException("hi!");
        encoderException26.addSuppressed((java.lang.Throwable) encoderException29);
        encoderException17.addSuppressed((java.lang.Throwable) encoderException29);
        encoderException12.addSuppressed((java.lang.Throwable) encoderException29);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = metaphone0.encode((java.lang.Object) encoderException29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertArrayEquals(throwableArray9, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertArrayEquals(throwableArray18, new java.lang.Throwable[] {});
    }

    @Test
    public void test0333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0333");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        org.apache.commons.codec.EncoderException encoderException21 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("");
        encoderException21.addSuppressed((java.lang.Throwable) encoderException23);
        org.apache.commons.codec.EncoderException encoderException26 = new org.apache.commons.codec.EncoderException("hi!");
        encoderException23.addSuppressed((java.lang.Throwable) encoderException26);
        java.lang.Class<?> wildcardClass28 = encoderException26.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = caverphone0.encode((java.lang.Object) wildcardClass28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test0334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0334");
        char[] charArray0 = new char[] {};
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Metaphone metaphone2 = new org.apache.commons.codec.language.Metaphone();
        metaphone2.setMaxCodeLen(3);
        java.lang.String str6 = metaphone2.encode("");
        java.lang.String str8 = metaphone2.encode("");
        metaphone2.setMaxCodeLen((int) (short) 10);
        int int11 = metaphone2.getMaxCodeLen();
        java.lang.String str13 = metaphone2.encode("ORKP");
        int int14 = metaphone2.getMaxCodeLen();
        int int15 = metaphone2.getMaxCodeLen();
        int int16 = metaphone2.getMaxCodeLen();
        int int17 = metaphone2.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = refinedSoundex1.encode((java.lang.Object) int17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertArrayEquals(charArray0, new char[] {});
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ORKP" + "'", str13, "ORKP");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
    }

    @Test
    public void test0335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0335");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("1111111111", "  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0336");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int3 = soundex0.getMaxLength();
        soundex0.setMaxLength(10);
        java.lang.String str7 = soundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O621" + "'", str7, "O621");
    }

    @Test
    public void test0337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0337");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean31 = caverphone0.isCaverphoneEqual("AK11111111", "ARKPKSKMNSK");
        java.lang.String str33 = caverphone0.encode("AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "AKPKMNSK11" + "'", str33, "AKPKMNSK11");
    }

    @Test
    public void test0338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0338");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARK" + "'", str1, "ARK");
    }

    @Test
    public void test0339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0339");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        boolean boolean12 = metaphone0.isMetaphoneEqual("A0", "");
        char[] charArray17 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = new org.apache.commons.codec.language.RefinedSoundex(charArray17);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex19 = new org.apache.commons.codec.language.RefinedSoundex(charArray17);
        org.apache.commons.codec.language.Soundex soundex20 = new org.apache.commons.codec.language.Soundex(charArray17);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex21 = new org.apache.commons.codec.language.RefinedSoundex(charArray17);
        org.apache.commons.codec.language.Soundex soundex22 = new org.apache.commons.codec.language.Soundex(charArray17);
        org.apache.commons.codec.language.Soundex soundex23 = new org.apache.commons.codec.language.Soundex(charArray17);
        org.apache.commons.codec.language.Soundex soundex24 = new org.apache.commons.codec.language.Soundex(charArray17);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = metaphone0.encode((java.lang.Object) soundex24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertArrayEquals(charArray17, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test0340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0340");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str4 = soundex2.encode("01230120022455012623010202");
        java.lang.String str6 = soundex2.encode("HI");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "H000" + "'", str6, "H000");
    }

    @Test
    public void test0341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0341");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A313", "A1111111114r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test0342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0342");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        java.lang.String str4 = soundex1.soundex("01230120022455012623010202");
        java.lang.String str6 = soundex1.encode("1111111111");
        soundex1.setMaxLength((int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test0343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0343");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        char char16 = doubleMetaphone9.charAt("hi!", 1);
        int int19 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone9, "A621", "H");
        doubleMetaphone9.maxCodeLen = '0';
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + 'i' + "'", char16 == 'i');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test0344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0344");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.soundex("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0345");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str25 = caverphone0.encode("org.apache.commons.codec.EncoderException: ");
        java.lang.Class<?> wildcardClass26 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "AKPKKMNSKT" + "'", str25, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test0346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0346");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        java.lang.String str11 = metaphone0.metaphone("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str14 = doubleMetaphone12.doubleMetaphone("H");
        doubleMetaphone12.setMaxCodeLen((int) (byte) 0);
        java.lang.String str19 = doubleMetaphone12.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone12.new DoubleMetaphoneResult(0);
        java.lang.String str22 = doubleMetaphoneResult21.getPrimary();
        doubleMetaphoneResult21.appendPrimary('1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = metaphone0.encode((java.lang.Object) '1');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
    }

    @Test
    public void test0347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0347");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        org.apache.commons.codec.language.Caverphone caverphone17 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str19 = caverphone17.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str21 = caverphone17.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str23 = caverphone17.encode("A");
        java.lang.String str25 = caverphone17.caverphone("O0931");
        java.lang.String str27 = caverphone17.encode("AK11111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = refinedSoundex0.encode((java.lang.Object) caverphone17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKKMNSKT" + "'", str19, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKKMNSKT" + "'", str21, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A111111111" + "'", str23, "A111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A111111111" + "'", str25, "A111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "AK11111111" + "'", str27, "AK11111111");
    }

    @Test
    public void test0348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0348");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('\000');
        char char8 = refinedSoundex4.getMappingCode('A');
        // The following exception was thrown during execution in test generation
        try {
            int int11 = refinedSoundex4.difference("1111111111", "AKPKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '#' + "'", char8 == '#');
    }

    @Test
    public void test0349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0349");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = '\000';
        char char18 = doubleMetaphone13.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone13.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult20.append("ORK", "O620");
        java.lang.Object obj24 = metaphone0.encode((java.lang.Object) "O620");
        java.lang.String str26 = metaphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "O" + "'", obj24, "O");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
    }

    @Test
    public void test0350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0350");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        metaphone10.setMaxCodeLen(3);
        java.lang.String str14 = metaphone10.encode("");
        java.lang.String str16 = metaphone10.encode("");
        int int17 = metaphone10.getMaxCodeLen();
        int int18 = metaphone10.getMaxCodeLen();
        boolean boolean21 = metaphone10.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        boolean boolean24 = metaphone10.isMetaphoneEqual("H", "ARKPXKMNSKTKNKTRKS");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = caverphone0.encode((java.lang.Object) boolean24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test0351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0351");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        int int3 = soundex0.getMaxLength();
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex0, "AKPKMNSKT1", "O093");
        org.apache.commons.codec.EncoderException encoderException8 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException10 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray11 = encoderException10.getSuppressed();
        encoderException8.addSuppressed((java.lang.Throwable) encoderException10);
        org.apache.commons.codec.EncoderException encoderException14 = new org.apache.commons.codec.EncoderException("A ");
        encoderException10.addSuppressed((java.lang.Throwable) encoderException14);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = soundex0.encode((java.lang.Object) encoderException10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertArrayEquals(throwableArray11, new java.lang.Throwable[] {});
    }

    @Test
    public void test0352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0352");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
    }

    @Test
    public void test0353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0353");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.encode("hi!");
        char char9 = refinedSoundex0.getMappingCode('1');
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
    }

    @Test
    public void test0354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0354");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        int int4 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int7 = soundex1.difference("ARK", "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test0355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0355");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str7 = refinedSoundex5.soundex("O0940103030808306030830609053016080931");
        char char9 = refinedSoundex5.getMappingCode('i');
        java.lang.String str11 = refinedSoundex5.encode("O09401030308083060308306090530160809315383638369315893153836383693158931");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O0" + "'", str7, "O0");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
    }

    @Test
    public void test0356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0356");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("org.apache.commons.codec.EncoderException: O000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKKMNSKT" + "'", str30, "AKPKKMNSKT");
    }

    @Test
    public void test0357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0357");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: org.ap", "org.apache.commons.codec.EncoderException: ARKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test0358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0358");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "AKP1111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0359");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O621", "org.apache.commons.codec.EncoderException: org.ap");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0360");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int9 = soundex3.difference("ARKPXKMNSKTKNKTRKSPXN", "org.apache.commons.codec.EncoderException: ARKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test0361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0361");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        char[] charArray10 = new char[] { 'i' };
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = soundex0.encode((java.lang.Object) charArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertArrayEquals(charArray10, new char[] { 'i' });
    }

    @Test
    public void test0362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0362");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARK", " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0363");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("AA11111111");
        int int4 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "A000" + "'", str3, "A000");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test0364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0364");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        java.lang.String str4 = metaphone0.encode("A621");
        java.lang.String str6 = metaphone0.encode("01");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test0365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0365");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        metaphone0.setMaxCodeLen(0);
        boolean boolean11 = metaphone0.isMetaphoneEqual("A1", "ARKPXKMNSK");
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str14 = metaphone12.encode("");
        int int15 = metaphone12.getMaxCodeLen();
        metaphone12.setMaxCodeLen((int) (byte) 10);
        boolean boolean20 = metaphone12.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone12.setMaxCodeLen((int) (short) -1);
        metaphone12.setMaxCodeLen(35);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = metaphone0.encode((java.lang.Object) metaphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test0366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0366");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("O0");
        java.lang.Class<?> wildcardClass28 = refinedSoundex0.getClass();
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "O0" + "'", str27, "O0");
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test0367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0367");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        soundex4.setMaxLength((int) (short) 100);
        java.lang.String str8 = soundex4.encode("A");
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A000" + "'", str8, "A000");
    }

    @Test
    public void test0368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0368");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str5 = soundex3.soundex("01230120022455012623010202");
        soundex3.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = soundex3.difference("ARKP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0369");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        int int18 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "O941", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        java.lang.String str20 = refinedSoundex0.encode("AKPK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "A0313" + "'", str20, "A0313");
    }

    @Test
    public void test0370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0370");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('4');
        java.lang.String str8 = refinedSoundex4.soundex("");
        java.lang.String str10 = refinedSoundex4.soundex("  ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = refinedSoundex4.encode("O621");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test0371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0371");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.String str16 = metaphone0.metaphone("A");
        java.lang.String[] strArray33 = new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" };
        boolean boolean34 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 1, (int) (short) 1, strArray33);
        boolean boolean35 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 10, (int) '#', strArray33);
        boolean boolean36 = org.apache.commons.codec.language.DoubleMetaphone.contains("O621", (int) (byte) 0, (int) (short) 10, strArray33);
        boolean boolean37 = org.apache.commons.codec.language.DoubleMetaphone.contains("A621", 3, 10, strArray33);
        boolean boolean38 = org.apache.commons.codec.language.DoubleMetaphone.contains("", (int) (byte) 100, (int) (byte) -1, strArray33);
        java.lang.Class<?> wildcardClass39 = strArray33.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj40 = metaphone0.encode((java.lang.Object) strArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertArrayEquals(strArray33, new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" });
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test0372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0372");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: hi!");
        int int16 = refinedSoundex0.difference("AKPKKMNSKT", "O0940103030808306030830609053016080");
        java.lang.Class<?> wildcardClass17 = refinedSoundex0.getClass();
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0940103030808306030830609053016080" + "'", str13, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test0373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0373");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "O093");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0374");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.Object obj11 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = soundex0.encode(obj11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
    }

    @Test
    public void test0375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0375");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AA11111111");
        boolean boolean33 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "H000");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex34 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char36 = refinedSoundex34.getMappingCode('a');
        int int39 = refinedSoundex34.difference("", "hi!");
        char char41 = refinedSoundex34.getMappingCode('0');
        char char43 = refinedSoundex34.getMappingCode('a');
        java.lang.String str45 = refinedSoundex34.soundex("1111111111");
        char char47 = refinedSoundex34.getMappingCode('0');
        java.lang.String str49 = refinedSoundex34.encode("O");
        char char51 = refinedSoundex34.getMappingCode('\000');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj52 = caverphone0.encode((java.lang.Object) char51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AA11111111" + "'", str30, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(refinedSoundex34);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '0' + "'", char36 == '0');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + char41 + "' != '" + '\000' + "'", char41 == '\000');
        org.junit.Assert.assertTrue("'" + char43 + "' != '" + '0' + "'", char43 == '0');
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "" + "'", str45, "");
        org.junit.Assert.assertTrue("'" + char47 + "' != '" + '\000' + "'", char47 == '\000');
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "O0" + "'", str49, "O0");
        org.junit.Assert.assertTrue("'" + char51 + "' != '" + '\000' + "'", char51 == '\000');
    }

    @Test
    public void test0376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0376");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = soundex9.soundex("O093");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test0377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0377");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone22.maxCodeLen = 0;
        char char27 = doubleMetaphone22.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean31 = doubleMetaphone22.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char34 = doubleMetaphone22.charAt("01230120022455012623010202", (int) (short) 1);
        char char37 = doubleMetaphone22.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone22.maxCodeLen = (byte) 10;
        int int42 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone22, "A", "A");
        boolean boolean45 = doubleMetaphone22.isDoubleMetaphoneEqual("H000", "1111111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj46 = caverphone0.encode((java.lang.Object) boolean45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '\000' + "'", char27 == '\000');
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + char34 + "' != '" + '1' + "'", char34 == '1');
        org.junit.Assert.assertTrue("'" + char37 + "' != '" + 'O' + "'", char37 == 'O');
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test0378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0378");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 1);
        java.lang.Class<?> wildcardClass21 = metaphone0.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test0379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0379");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        boolean boolean11 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderExc", "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str14 = doubleMetaphone12.doubleMetaphone("H");
        doubleMetaphone12.setMaxCodeLen((int) (byte) 0);
        java.lang.String str19 = doubleMetaphone12.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone12.new DoubleMetaphoneResult(0);
        int int22 = doubleMetaphone12.maxCodeLen;
        java.lang.String str24 = doubleMetaphone12.encode("O941");
        int int25 = doubleMetaphone12.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = caverphone0.encode((java.lang.Object) int25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test0380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0380");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        java.lang.Object obj17 = refinedSoundex0.encode((java.lang.Object) "A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str20 = doubleMetaphone18.doubleMetaphone("H");
        doubleMetaphone18.setMaxCodeLen((int) (byte) 0);
        char char25 = doubleMetaphone18.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult27 = doubleMetaphone18.new DoubleMetaphoneResult((int) '4');
        java.lang.String str28 = doubleMetaphoneResult27.getAlternate();
        doubleMetaphoneResult27.append('r');
        doubleMetaphoneResult27.appendPrimary('O');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "A0" + "'", obj17, "A0");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + 'i' + "'", char25 == 'i');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
    }

    @Test
    public void test0381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0381");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("AKPKMNSKT1");
        java.lang.String str12 = caverphone0.encode("H000");
        char[] charArray13 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex15 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex16 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex17 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex17, "A111111111", "O941");
        char char22 = refinedSoundex17.getMappingCode('a');
        char char24 = refinedSoundex17.getMappingCode('1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = caverphone0.encode((java.lang.Object) '1');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKMNSKT1" + "'", str10, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '0' + "'", char22 == '0');
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
    }

    @Test
    public void test0382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0382");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("H000");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "H" + "'", str1, "H");
    }

    @Test
    public void test0383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0383");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        metaphone0.setMaxCodeLen((int) (short) 0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = metaphone0.encode((java.lang.Object) 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test0384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0384");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.soundex("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str14 = refinedSoundex0.soundex("4");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A093138363836931589313836383693158" + "'", str12, "A093138363836931589313836383693158");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test0385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0385");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Metaphone metaphone6 = new org.apache.commons.codec.language.Metaphone();
        metaphone6.setMaxCodeLen(3);
        int int9 = metaphone6.getMaxCodeLen();
        java.lang.String str11 = metaphone6.metaphone("01230120022455012623010202");
        java.lang.String str13 = metaphone6.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str15 = metaphone6.metaphone("ORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = refinedSoundex5.encode((java.lang.Object) "ORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O" + "'", str13, "O");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORK" + "'", str15, "ORK");
    }

    @Test
    public void test0386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0386");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: hi!", "AKP");
        java.lang.String str7 = soundex1.soundex("ARKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A621" + "'", str7, "A621");
    }

    @Test
    public void test0387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0387");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "ARK", "H0");
        int int13 = refinedSoundex4.difference("A031", "HI");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test0388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0388");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        java.lang.String str9 = soundex1.soundex("");
        int int10 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            int int13 = soundex1.difference("AKPK", "ARKPXKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test0389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0389");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        char[] charArray3 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = caverphone0.encode((java.lang.Object) charArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(charArray3);
    }

    @Test
    public void test0390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0390");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A031", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0391");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("O093", "AKP1111111");
        java.lang.String str18 = caverphone0.caverphone("A0");
        boolean boolean21 = caverphone0.isCaverphoneEqual("", "org.apache.commons.codec.EncoderException: org.ap");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A111111111" + "'", str18, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test0392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0392");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ORKPXKMNSKTKNKTRKSSPXNH");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNH" + "'", str1, "ORKPXKMNSKTKNKTRKSSPXNH");
    }

    @Test
    public void test0393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0393");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str8 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        java.lang.String str10 = metaphone0.encode("A062125232523621256212523252362125");
        java.lang.String str12 = metaphone0.metaphone("1111111111");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKPXKMNSK" + "'", str8, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
    }

    @Test
    public void test0394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0394");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A", "A0313");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0395");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        org.apache.commons.codec.language.Caverphone caverphone12 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str14 = caverphone12.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str16 = caverphone12.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str18 = caverphone12.encode("");
        java.lang.String str20 = caverphone12.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean23 = caverphone12.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = caverphone0.encode((java.lang.Object) caverphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKKMNSKT" + "'", str14, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKKMNSKT" + "'", str16, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "1111111111" + "'", str18, "1111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test0396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0396");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        int int10 = refinedSoundex0.difference("ORKPXKMNSK", "ORK");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = '\000';
        doubleMetaphone11.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult17 = doubleMetaphone11.new DoubleMetaphoneResult((int) '1');
        java.lang.String str18 = doubleMetaphoneResult17.getPrimary();
        boolean boolean19 = doubleMetaphoneResult17.isComplete();
        doubleMetaphoneResult17.append("A0");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test0397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0397");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        char[] charArray13 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray13);
        int int15 = soundex14.getMaxLength();
        int int18 = soundex14.difference("org.apache.commons.codec.EncoderException: hi!", "AKP");
        soundex14.setMaxLength((int) '#');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = metaphone0.encode((java.lang.Object) soundex14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test0398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0398");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        java.lang.String str8 = metaphone0.metaphone("");
        boolean boolean11 = metaphone0.isMetaphoneEqual("O", "A0");
        java.lang.String str13 = metaphone0.encode("O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O" + "'", str13, "O");
    }

    @Test
    public void test0399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0399");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex5, "A093153836383693158", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = refinedSoundex5.encode("AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test0400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0400");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        int int8 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = soundex1.encode("AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test0401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0401");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) '0');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        doubleMetaphone8.setMaxCodeLen((int) (byte) 0);
        java.lang.String str15 = doubleMetaphone8.doubleMetaphone("", false);
        java.lang.String str17 = doubleMetaphone8.encode("hi!");
        boolean boolean21 = doubleMetaphone8.isDoubleMetaphoneEqual("A111111111", "AKPKKMNSKT", false);
        boolean boolean24 = doubleMetaphone8.isDoubleMetaphoneEqual("A621", "1111111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = soundex1.encode((java.lang.Object) doubleMetaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test0402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0402");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("AKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AKP" + "'", str1, "AKP");
    }

    @Test
    public void test0403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0403");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.metaphone("A0");
        java.lang.Object obj5 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = metaphone0.encode(obj5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
    }

    @Test
    public void test0404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0404");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "ARK", "H000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0405");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        char char6 = refinedSoundex4.getMappingCode('4');
        org.apache.commons.codec.language.Metaphone metaphone7 = new org.apache.commons.codec.language.Metaphone();
        metaphone7.setMaxCodeLen(3);
        java.lang.String str11 = metaphone7.encode("");
        java.lang.String str13 = metaphone7.encode("");
        metaphone7.setMaxCodeLen((int) (short) 10);
        int int16 = metaphone7.getMaxCodeLen();
        int int17 = metaphone7.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = refinedSoundex4.encode((java.lang.Object) metaphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
    }

    @Test
    public void test0406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0406");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0407");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
    }

    @Test
    public void test0408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0408");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        metaphone0.setMaxCodeLen(43);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test0409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0409");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.String str16 = metaphone0.metaphone("A");
        int int17 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = new org.apache.commons.codec.language.RefinedSoundex();
        char char20 = refinedSoundex18.getMappingCode('0');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = metaphone0.encode((java.lang.Object) refinedSoundex18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
    }

    @Test
    public void test0410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0410");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex4.setMaxLength((int) (short) 0);
        org.apache.commons.codec.language.Metaphone metaphone7 = new org.apache.commons.codec.language.Metaphone();
        metaphone7.setMaxCodeLen(3);
        int int10 = metaphone7.getMaxCodeLen();
        boolean boolean13 = metaphone7.isMetaphoneEqual("", "");
        boolean boolean16 = metaphone7.isMetaphoneEqual("01230120022455012623010202", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = soundex4.encode((java.lang.Object) metaphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test0411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0411");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str14 = doubleMetaphone12.doubleMetaphone("H");
        doubleMetaphone12.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone12.maxCodeLen = '0';
        doubleMetaphone12.setMaxCodeLen(100);
        doubleMetaphone12.maxCodeLen = (byte) 100;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test0412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0412");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char12 = doubleMetaphone0.charAt("01230120022455012623010202", (int) (short) 1);
        char char15 = doubleMetaphone0.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone0.maxCodeLen = (byte) 10;
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A", "A");
        int int21 = doubleMetaphone0.maxCodeLen;
        java.lang.Class<?> wildcardClass22 = doubleMetaphone0.getClass();
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + 'O' + "'", char15 == 'O');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test0413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0413");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0414");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean11 = metaphone0.isMetaphoneEqual("O0931", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        metaphone12.setMaxCodeLen(3);
        java.lang.String str16 = metaphone12.encode("");
        java.lang.String str18 = metaphone12.encode("");
        metaphone12.setMaxCodeLen((int) (short) 10);
        int int21 = metaphone12.getMaxCodeLen();
        java.lang.String str23 = metaphone12.encode("ORKP");
        int int24 = metaphone12.getMaxCodeLen();
        boolean boolean27 = metaphone12.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = metaphone0.encode((java.lang.Object) boolean27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKP" + "'", str23, "ORKP");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test0415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0415");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        int int4 = soundex0.difference("org.apache.commons.codec.EncoderException: ARKP", "A621");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test0416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0416");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str14 = refinedSoundex0.soundex("AKPKMNSKT1");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str17 = doubleMetaphone15.doubleMetaphone("H");
        doubleMetaphone15.setMaxCodeLen((int) (byte) 0);
        java.lang.String str22 = doubleMetaphone15.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult24 = doubleMetaphone15.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult24.appendAlternate("01230120022455012623010202");
        doubleMetaphoneResult24.append('\000', 'i');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = refinedSoundex0.encode((java.lang.Object) 'i');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A0313836" + "'", str14, "A0313836");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test0417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0417");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.soundex("A0313836");
        java.lang.String str12 = soundex0.soundex("O0940103030808306030830609053016080");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str15 = refinedSoundex13.soundex("01230120022455012623010202");
        java.lang.String str17 = refinedSoundex13.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str19 = refinedSoundex13.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int22 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex13, "HI", "A");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone23 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone23.maxCodeLen = '\000';
        char char28 = doubleMetaphone23.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult30 = doubleMetaphone23.new DoubleMetaphoneResult((int) ' ');
        java.lang.String str31 = doubleMetaphoneResult30.getPrimary();
        doubleMetaphoneResult30.append('o', '4');
        boolean boolean35 = doubleMetaphoneResult30.isComplete();
        doubleMetaphoneResult30.append("O941", "");
        java.lang.Object obj39 = refinedSoundex13.encode((java.lang.Object) "O941");
        java.lang.Object obj40 = soundex0.encode((java.lang.Object) "O941");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O000" + "'", str12, "O000");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0940103030808306030830609053016080" + "'", str17, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0" + "'", str19, "O0");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '\000' + "'", char28 == '\000');
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals("'" + obj39 + "' != '" + "O0" + "'", obj39, "O0");
        org.junit.Assert.assertEquals("'" + obj40 + "' != '" + "O000" + "'", obj40, "O000");
    }

    @Test
    public void test0418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0418");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("H0");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "H" + "'", str1, "H");
    }

    @Test
    public void test0419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0419");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int12 = soundex1.difference("A#", "H0");
        java.lang.String str14 = soundex1.soundex("A0313");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A000" + "'", str14, "A000");
    }

    @Test
    public void test0420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0420");
        char[] charArray6 = new char[] { 'r', '1', ' ', 'i', '#', '#' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = refinedSoundex7.encode("org.apache.commons.codec.EncoderException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertArrayEquals(charArray6, new char[] { 'r', '1', ' ', 'i', '#', '#' });
    }

    @Test
    public void test0421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0421");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O620");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0422");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        java.lang.String str10 = refinedSoundex8.soundex("A");
        // The following exception was thrown during execution in test generation
        try {
            int int13 = refinedSoundex8.difference("org.apache.commons.codec.EncoderException: O000", "");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "Aa" + "'", str10, "Aa");
    }

    @Test
    public void test0423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0423");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "O0", "O0931");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0424");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        java.lang.String str9 = soundex1.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "AKP", "01230120022455012623010202");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test0425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0425");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int10 = soundex1.getMaxLength();
        int int11 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test0426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0426");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("ORKP");
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0931" + "'", str10, "O0931");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
    }

    @Test
    public void test0427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0427");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        int int8 = doubleMetaphone0.maxCodeLen;
        org.apache.commons.codec.language.Caverphone caverphone9 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str11 = caverphone9.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str13 = caverphone9.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone9.encode("A");
        java.lang.Object obj16 = doubleMetaphone0.encode((java.lang.Object) str15);
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("H000", "ARKP", true);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertEquals("'" + obj16 + "' != '" + "" + "'", obj16, "");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test0428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0428");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode(' ');
        java.lang.String str9 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: HI");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O0940103030808306030830609053016080" + "'", str9, "O0940103030808306030830609053016080");
    }

    @Test
    public void test0429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0429");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            int int9 = refinedSoundex6.difference("", "ARKPKSKMNS");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 17 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0430");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        org.apache.commons.codec.language.Metaphone metaphone15 = new org.apache.commons.codec.language.Metaphone();
        metaphone15.setMaxCodeLen(3);
        java.lang.String str19 = metaphone15.encode("");
        java.lang.String str21 = metaphone15.encode("");
        int int22 = metaphone15.getMaxCodeLen();
        int int23 = metaphone15.getMaxCodeLen();
        boolean boolean26 = metaphone15.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        metaphone15.setMaxCodeLen((int) 'A');
        int int29 = metaphone15.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = metaphone0.encode((java.lang.Object) metaphone15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 65 + "'", int29 == 65);
    }

    @Test
    public void test0431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0431");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        boolean boolean11 = metaphone0.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        metaphone0.setMaxCodeLen((int) 'A');
        java.lang.Class<?> wildcardClass14 = metaphone0.getClass();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0432");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN", "i0a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0433");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone0.maxCodeLen = 3;
        boolean boolean15 = doubleMetaphone0.isDoubleMetaphoneEqual("H0", "1111111111", false);
        org.apache.commons.codec.language.Metaphone metaphone16 = new org.apache.commons.codec.language.Metaphone();
        metaphone16.setMaxCodeLen(3);
        java.lang.String str20 = metaphone16.encode("");
        java.lang.String str22 = metaphone16.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = doubleMetaphone0.encode((java.lang.Object) metaphone16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
    }

    @Test
    public void test0434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0434");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str11 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
    }

    @Test
    public void test0435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0435");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str7 = soundex5.soundex("A0");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = soundex5.encode("AKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
    }

    @Test
    public void test0436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0436");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A0313", "org.apache.commons.codec.EncoderException: ORKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0437");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.EncoderException encoderException17 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray18 = encoderException17.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException20 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException22 = new org.apache.commons.codec.EncoderException("");
        encoderException20.addSuppressed((java.lang.Throwable) encoderException22);
        encoderException17.addSuppressed((java.lang.Throwable) encoderException22);
        org.apache.commons.codec.EncoderException encoderException26 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        encoderException22.addSuppressed((java.lang.Throwable) encoderException26);
        java.lang.Throwable[] throwableArray28 = encoderException26.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = metaphone0.encode((java.lang.Object) throwableArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertArrayEquals(throwableArray18, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertArrayEquals(throwableArray28, new java.lang.Throwable[] {});
    }

    @Test
    public void test0438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0438");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Metaphone metaphone6 = new org.apache.commons.codec.language.Metaphone();
        metaphone6.setMaxCodeLen(3);
        int int9 = metaphone6.getMaxCodeLen();
        boolean boolean12 = metaphone6.isMetaphoneEqual("", "");
        metaphone6.setMaxCodeLen(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = refinedSoundex5.encode((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test0439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0439");
        char[] charArray0 = new char[] {};
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        // The following exception was thrown during execution in test generation
        try {
            int int4 = refinedSoundex1.difference("O0940103030808306030830609053016080", "AA11111111");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertArrayEquals(charArray0, new char[] {});
    }

    @Test
    public void test0440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0440");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A0313");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0441");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) '0');
        int int8 = soundex1.getMaxLength();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = soundex1.encode((java.lang.Object) refinedSoundex9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 48 + "'", int8 == 48);
        org.junit.Assert.assertNotNull(refinedSoundex9);
    }

    @Test
    public void test0442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0442");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        boolean boolean13 = metaphone0.isMetaphoneEqual("", "hi!");
        boolean boolean16 = metaphone0.isMetaphoneEqual("O09401030308083060308306090530160809315383638369315893153836383693158931", "A093138363836931589313836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test0443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0443");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        java.lang.String str38 = caverphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone39 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone39.maxCodeLen = '\000';
        int int42 = doubleMetaphone39.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult44 = doubleMetaphone39.new DoubleMetaphoneResult((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj45 = caverphone0.encode((java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKMNSKTK" + "'", str38, "AKPKMNSKTK");
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test0444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0444");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.soundex("O0940103030808306030830609053016080");
        java.lang.String str15 = refinedSoundex0.soundex("AKPKKMNSKT");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str18 = doubleMetaphone16.doubleMetaphone("H");
        doubleMetaphone16.setMaxCodeLen((int) (byte) 0);
        java.lang.String str23 = doubleMetaphone16.doubleMetaphone("", false);
        java.lang.String str25 = doubleMetaphone16.encode("hi!");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A0313836" + "'", str15, "A0313836");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
    }

    @Test
    public void test0445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0445");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A000", "A0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test0446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0446");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone3 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str5 = doubleMetaphone3.doubleMetaphone("H");
        doubleMetaphone3.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone3.maxCodeLen = '0';
        java.lang.String str12 = doubleMetaphone3.doubleMetaphone("A", true);
        boolean boolean15 = doubleMetaphone3.isDoubleMetaphoneEqual("A0", "");
        boolean boolean18 = doubleMetaphone3.isDoubleMetaphoneEqual("A ", "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone3.setMaxCodeLen((int) 'A');
        int int23 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone3, "ARK", "A ");
        doubleMetaphone3.setMaxCodeLen((int) '#');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = soundex2.encode((java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test0447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0447");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("AKP1111111", "O000");
        org.apache.commons.codec.EncoderException encoderException21 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray22 = encoderException21.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException24 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException26 = new org.apache.commons.codec.EncoderException("");
        encoderException24.addSuppressed((java.lang.Throwable) encoderException26);
        encoderException21.addSuppressed((java.lang.Throwable) encoderException26);
        org.apache.commons.codec.EncoderException encoderException30 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        encoderException26.addSuppressed((java.lang.Throwable) encoderException30);
        java.lang.Throwable[] throwableArray32 = encoderException30.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = refinedSoundex0.encode((java.lang.Object) encoderException30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertArrayEquals(throwableArray22, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertArrayEquals(throwableArray32, new java.lang.Throwable[] {});
    }

    @Test
    public void test0448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0448");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: 01230120022455012623010202", "org.apache.commons.codec.EncoderException: hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test0449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0449");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        java.lang.String str5 = refinedSoundex3.soundex("A000");
        // The following exception was thrown during execution in test generation
        try {
            char char7 = refinedSoundex3.getMappingCode('r');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 17 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A1" + "'", str5, "A1");
    }

    @Test
    public void test0450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0450");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.metaphone("A0");
        java.lang.String str6 = metaphone0.encode("H");
        java.lang.Object obj7 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = metaphone0.encode(obj7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "H" + "'", str6, "H");
    }

    @Test
    public void test0451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0451");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        java.lang.String str9 = metaphone0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORK" + "'", str9, "ORK");
    }

    @Test
    public void test0452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0452");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str15 = refinedSoundex0.soundex("O0940103030808306030830609053016080");
        char[] charArray16 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray16);
        int int18 = soundex17.getMaxLength();
        int int21 = soundex17.difference("ORKP", "AA11111111");
        soundex17.setMaxLength(10);
        int int24 = soundex17.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) soundex17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
    }

    @Test
    public void test0453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0453");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        int int12 = refinedSoundex5.difference(" ", "");
        char[] charArray14 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex15 = new org.apache.commons.codec.language.RefinedSoundex(charArray14);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex16 = new org.apache.commons.codec.language.RefinedSoundex(charArray14);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = refinedSoundex5.encode((java.lang.Object) charArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertArrayEquals(charArray14, new char[] { 'a' });
    }

    @Test
    public void test0454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0454");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        char char21 = refinedSoundex0.getMappingCode('A');
        char char23 = refinedSoundex0.getMappingCode('o');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '0' + "'", char21 == '0');
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '0' + "'", char23 == '0');
    }

    @Test
    public void test0455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0455");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str25 = caverphone0.encode("org.apache.commons.codec.EncoderException: ");
        java.lang.String str27 = caverphone0.encode("org.apache.commons.codec.EncoderException: ARKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "AKPKKMNSKT" + "'", str25, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "AKPKKMNSKT" + "'", str27, "AKPKKMNSKT");
    }

    @Test
    public void test0456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0456");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex3.setMaxLength(1);
        int int8 = soundex3.difference("O", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.apache.commons.codec.EncoderException encoderException10 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException12 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray13 = encoderException12.getSuppressed();
        encoderException10.addSuppressed((java.lang.Throwable) encoderException12);
        org.apache.commons.codec.EncoderException encoderException16 = new org.apache.commons.codec.EncoderException("");
        encoderException12.addSuppressed((java.lang.Throwable) encoderException16);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = soundex3.encode((java.lang.Object) encoderException16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertArrayEquals(throwableArray13, new java.lang.Throwable[] {});
    }

    @Test
    public void test0457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0457");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        java.lang.String str5 = soundex3.soundex("01230120022455012623010202");
        int int6 = soundex3.getMaxLength();
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test0458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0458");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen(48);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        java.lang.String str13 = doubleMetaphone9.encode("A621");
        boolean boolean17 = doubleMetaphone9.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        int int18 = doubleMetaphone9.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = metaphone0.encode((java.lang.Object) doubleMetaphone9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test0459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0459");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        // The following exception was thrown during execution in test generation
        try {
            int int13 = refinedSoundex5.difference("", "AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test0460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0460");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str15 = caverphone0.encode("ORK");
        java.lang.Class<?> wildcardClass16 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0461");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("A0931");
        char char26 = refinedSoundex0.getMappingCode('i');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A0" + "'", str24, "A0");
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
    }

    @Test
    public void test0462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0462");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        java.lang.Object obj11 = metaphone0.encode((java.lang.Object) "A ");
        java.lang.String str13 = metaphone0.encode("org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.language.Caverphone caverphone14 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str16 = caverphone14.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str18 = caverphone14.caverphone("hi!");
        java.lang.String str20 = caverphone14.caverphone("");
        int int23 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone14, "AA11111111", "hi!");
        java.lang.String str25 = caverphone14.encode("O0940103030808306030830609053016080");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = metaphone0.encode((java.lang.Object) caverphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertEquals("'" + obj11 + "' != '" + "A" + "'", obj11, "A");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ORK" + "'", str13, "ORK");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKKMNSKT" + "'", str16, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AA11111111" + "'", str18, "AA11111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "1111111111" + "'", str20, "1111111111");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A111111111" + "'", str25, "A111111111");
    }

    @Test
    public void test0463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0463");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult7 = doubleMetaphone0.new DoubleMetaphoneResult((int) (byte) -1);
        boolean boolean11 = doubleMetaphone0.isDoubleMetaphoneEqual("H000", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", false);
        char[] charArray12 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray12);
        soundex13.setMaxLength((int) (byte) 100);
        soundex13.setMaxLength((int) (byte) 100);
        java.lang.String str19 = soundex13.encode("AA11111111");
        java.lang.String str21 = soundex13.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.Object obj22 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A0");
        boolean boolean25 = doubleMetaphone0.isDoubleMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        java.lang.String str27 = doubleMetaphone0.encode("AA");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A000" + "'", str19, "A000");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "O621" + "'", str21, "O621");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "" + "'", obj22, "");
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
    }

    @Test
    public void test0464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0464");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        java.lang.String str12 = metaphone0.encode("A111111111O620");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str15 = doubleMetaphone13.doubleMetaphone("H");
        doubleMetaphone13.setMaxCodeLen((int) (byte) 0);
        java.lang.String str20 = doubleMetaphone13.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult22 = doubleMetaphone13.new DoubleMetaphoneResult(0);
        java.lang.String str23 = doubleMetaphoneResult22.getAlternate();
        doubleMetaphoneResult22.append('\000');
        doubleMetaphoneResult22.append('#', '#');
        java.lang.String str29 = doubleMetaphoneResult22.getPrimary();
        doubleMetaphoneResult22.append("AA11111111", "org.apache.commons.codec.EncoderException: A0");
        doubleMetaphoneResult22.appendAlternate('1');
        doubleMetaphoneResult22.appendPrimary("org.apache.commons.codec.EncoderException: A0");
        doubleMetaphoneResult22.appendAlternate('0');
        doubleMetaphoneResult22.appendAlternate(" ");
        doubleMetaphoneResult22.append('r', 'A');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj44 = metaphone0.encode((java.lang.Object) doubleMetaphoneResult22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
    }

    @Test
    public void test0465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0465");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("H000", "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0466");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
    }

    @Test
    public void test0467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0467");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str7 = doubleMetaphone0.encode("A");
        doubleMetaphone0.setMaxCodeLen((int) (short) 10);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult11 = doubleMetaphone0.new DoubleMetaphoneResult((int) 'r');
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        metaphone12.setMaxCodeLen(3);
        int int15 = metaphone12.getMaxCodeLen();
        boolean boolean18 = metaphone12.isMetaphoneEqual("", "");
        boolean boolean21 = metaphone12.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone12.setMaxCodeLen(0);
        int int24 = metaphone12.getMaxCodeLen();
        metaphone12.setMaxCodeLen((int) (short) 100);
        java.lang.String str28 = metaphone12.encode("ARKP");
        java.lang.String str30 = metaphone12.encode("");
        java.lang.String str32 = metaphone12.encode("H");
        java.lang.String str34 = metaphone12.metaphone("AKPKMNSKT1");
        metaphone12.setMaxCodeLen((int) 'r');
        int int37 = metaphone12.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj38 = doubleMetaphone0.encode((java.lang.Object) int37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "ARKP" + "'", str28, "ARKP");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPKMNSKT" + "'", str34, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 114 + "'", int37 == 114);
    }

    @Test
    public void test0468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0468");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test0469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0469");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str14 = doubleMetaphone12.doubleMetaphone("H");
        java.lang.String str16 = doubleMetaphone12.doubleMetaphone("");
        java.lang.String str19 = doubleMetaphone12.doubleMetaphone("ORKP", true);
        java.lang.String str22 = doubleMetaphone12.doubleMetaphone("", false);
        java.lang.String str24 = doubleMetaphone12.encode("");
        doubleMetaphone12.setMaxCodeLen(10);
        boolean boolean29 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        boolean boolean32 = doubleMetaphone12.isDoubleMetaphoneEqual("AK11111111", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean36 = doubleMetaphone12.isDoubleMetaphoneEqual("ARKPKSKMNS", "org.apache.commons.codec.EncoderException: O000", true);
        int int37 = doubleMetaphone12.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj38 = caverphone0.encode((java.lang.Object) int37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ARKP" + "'", str19, "ARKP");
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
    }

    @Test
    public void test0470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0470");
        char[] charArray0 = new char[] {};
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        // The following exception was thrown during execution in test generation
        try {
            int int5 = soundex2.difference("A621", "O0940103030808306030830609053016080");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: A");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertArrayEquals(charArray0, new char[] {});
    }

    @Test
    public void test0471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0471");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str8 = metaphone0.encode("");
        int int9 = metaphone0.getMaxCodeLen();
        boolean boolean12 = metaphone0.isMetaphoneEqual("  ", "ARKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test0472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0472");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("ARK", "AA11111111");
        java.lang.String str18 = caverphone0.encode("org.apache.commons.codec.EncoderException: A093153836383693158");
        boolean boolean21 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#", "HI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = caverphone0.encode((java.lang.Object) 'A');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test0473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0473");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        char char9 = refinedSoundex0.getMappingCode('a');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str12 = doubleMetaphone10.doubleMetaphone("H");
        doubleMetaphone10.setMaxCodeLen((int) (byte) 0);
        java.lang.String str16 = doubleMetaphone10.encode("H");
        boolean boolean19 = doubleMetaphone10.isDoubleMetaphoneEqual("hi!", "AKPKKMNSKT");
        int int20 = doubleMetaphone10.getMaxCodeLen();
        boolean boolean24 = doubleMetaphone10.isDoubleMetaphoneEqual("A0", "O0931", true);
        java.lang.String str26 = doubleMetaphone10.doubleMetaphone("A#");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
    }

    @Test
    public void test0474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0474");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("AA");
        java.lang.String str9 = soundex0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
    }

    @Test
    public void test0475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0475");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        int int10 = metaphone0.getMaxCodeLen();
        java.lang.String str12 = metaphone0.encode("org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ORKPXKMNSK" + "'", str12, "ORKPXKMNSK");
    }

    @Test
    public void test0476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0476");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray2);
        int int6 = soundex5.getMaxLength();
        int int9 = soundex5.difference("A0313", "A ");
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test0477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0477");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        java.lang.String str5 = refinedSoundex3.soundex("A000");
        char char7 = refinedSoundex3.getMappingCode('1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = refinedSoundex3.soundex("O093");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A1" + "'", str5, "A1");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
    }

    @Test
    public void test0478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0478");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        java.lang.String str21 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080931");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "O0" + "'", str21, "O0");
    }

    @Test
    public void test0479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0479");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        java.lang.String str12 = refinedSoundex5.soundex("A111111111");
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone13.encode("O621");
        char[] charArray18 = null;
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray18);
        java.lang.String str21 = soundex19.soundex("");
        java.lang.String str23 = soundex19.encode("");
        java.lang.Object obj24 = caverphone13.encode((java.lang.Object) str23);
        java.lang.Class<?> wildcardClass25 = obj24.getClass();
        java.lang.Object obj26 = refinedSoundex5.encode(obj24);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str28 = refinedSoundex5.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A " + "'", str12, "A ");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A111111111" + "'", str17, "A111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "1111111111" + "'", obj24, "1111111111");
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "" + "'", obj26, "");
    }

    @Test
    public void test0480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0480");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        soundex0.setMaxLength(0);
        java.lang.String str12 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080");
        int int15 = soundex0.difference("AA", "1111111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O000" + "'", str12, "O000");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test0481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0481");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        org.apache.commons.codec.language.Caverphone caverphone15 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str17 = caverphone15.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char20 = refinedSoundex18.getMappingCode('a');
        int int23 = refinedSoundex18.difference("", "hi!");
        char char25 = refinedSoundex18.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone26 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str28 = doubleMetaphone26.doubleMetaphone("H");
        java.lang.String str30 = doubleMetaphone26.doubleMetaphone("");
        java.lang.String str33 = doubleMetaphone26.doubleMetaphone("ORKP", true);
        java.lang.String str36 = doubleMetaphone26.doubleMetaphone("", false);
        java.lang.String str38 = doubleMetaphone26.encode("");
        java.lang.Object obj39 = refinedSoundex18.encode((java.lang.Object) "");
        java.lang.Object obj40 = caverphone15.encode(obj39);
        java.lang.String str42 = caverphone15.caverphone("");
        java.lang.String str44 = caverphone15.encode("A#");
        boolean boolean47 = caverphone15.isCaverphoneEqual("O093", "ARKPXKMNSKTKNKTRKSPXN");
        java.lang.Object obj48 = metaphone0.encode((java.lang.Object) "ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex18);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '0' + "'", char20 == '0');
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '\000' + "'", char25 == '\000');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "ARKP" + "'", str33, "ARKP");
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertEquals("'" + obj39 + "' != '" + "" + "'", obj39, "");
        org.junit.Assert.assertEquals("'" + obj40 + "' != '" + "1111111111" + "'", obj40, "1111111111");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "1111111111" + "'", str42, "1111111111");
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "A111111111" + "'", str44, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertEquals("'" + obj48 + "' != '" + "ARKPKSKMNSKTKNKTRKSPKSN" + "'", obj48, "ARKPKSKMNSKTKNKTRKSPKSN");
    }

    @Test
    public void test0482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0482");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        boolean boolean3 = caverphone0.isCaverphoneEqual("AKPK", "AKP1111111");
        java.lang.String str5 = caverphone0.encode("AKP1111111");
        java.lang.String str7 = caverphone0.caverphone("01230120022455012623010202");
        java.lang.String str9 = caverphone0.encode("A931");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "AKP1111111" + "'", str5, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "1111111111" + "'", str7, "1111111111");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
    }

    @Test
    public void test0483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0483");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AKPKMNSKTK", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0484");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        org.apache.commons.codec.EncoderException encoderException8 = new org.apache.commons.codec.EncoderException("AA11111111");
        org.apache.commons.codec.EncoderException encoderException10 = new org.apache.commons.codec.EncoderException("AKPKKMNSKT");
        encoderException8.addSuppressed((java.lang.Throwable) encoderException10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = metaphone0.encode((java.lang.Object) encoderException8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
    }

    @Test
    public void test0485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0485");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.metaphone("A0");
        java.lang.String str6 = metaphone0.encode("H");
        int int7 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "H" + "'", str6, "H");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test0486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0486");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        java.lang.String str9 = metaphone0.metaphone("AKPK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKP" + "'", str9, "AKP");
    }

    @Test
    public void test0487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0487");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPKSKMNSKTKNKTRKSPKSN" + "'", str1, "ARKPKSKMNSKTKNKTRKSPKSN");
    }

    @Test
    public void test0488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0488");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("AA");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = 0;
        char char13 = doubleMetaphone8.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean17 = doubleMetaphone8.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char20 = doubleMetaphone8.charAt("01230120022455012623010202", (int) (short) 1);
        char char23 = doubleMetaphone8.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone8.maxCodeLen = 100;
        boolean boolean28 = doubleMetaphone8.isDoubleMetaphoneEqual("AKP", "AKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = soundex0.encode((java.lang.Object) doubleMetaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '1' + "'", char20 == '1');
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + 'O' + "'", char23 == 'O');
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test0489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0489");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("O09315383638369315893153836383693158", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0490");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: O0", "ORKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0491");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        char[] charArray15 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex16 = new org.apache.commons.codec.language.Soundex(charArray15);
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray15);
        java.lang.String str19 = soundex17.encode("01230120022455012623010202");
        java.lang.String str21 = soundex17.soundex("ARKPKSKMNS");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = metaphone0.encode((java.lang.Object) soundex17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A931" + "'", str21, "A931");
    }

    @Test
    public void test0492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0492");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        int int4 = soundex1.getMaxLength();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char7 = refinedSoundex5.getMappingCode('a');
        int int10 = refinedSoundex5.difference("", "hi!");
        int int13 = refinedSoundex5.difference("hi!", "");
        char char15 = refinedSoundex5.getMappingCode('#');
        char char17 = refinedSoundex5.getMappingCode('a');
        java.lang.String str19 = refinedSoundex5.soundex("org.apache.commons.codec.EncoderException: A0");
        java.lang.Object obj20 = soundex1.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A0");
        java.lang.String str22 = soundex1.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(refinedSoundex5);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '0' + "'", char17 == '0');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0940103030808306030830609053016080" + "'", str19, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "O621" + "'", obj20, "O621");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
    }

    @Test
    public void test0493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0493");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            int int8 = soundex1.difference("A1111111114r", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0494");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A111111111O620");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AO" + "'", str1, "AO");
    }

    @Test
    public void test0495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0495");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        java.lang.String str12 = doubleMetaphone0.encode("");
        char[] charArray13 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray13);
        int int15 = soundex14.getMaxLength();
        int int18 = soundex14.difference("ORKP", "AA11111111");
        soundex14.setMaxLength(10);
        java.lang.String str22 = soundex14.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.Object obj23 = doubleMetaphone0.encode((java.lang.Object) str22);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O000" + "'", str22, "O000");
        org.junit.Assert.assertEquals("'" + obj23 + "' != '" + "A" + "'", obj23, "A");
    }

    @Test
    public void test0496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0496");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        java.lang.String str29 = refinedSoundex0.soundex("AKPKMNSK");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone30 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone30.maxCodeLen = '\000';
        char char35 = doubleMetaphone30.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult37 = doubleMetaphone30.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult37.appendPrimary("");
        doubleMetaphoneResult37.appendAlternate("01230120022455012623010202");
        java.lang.String str42 = doubleMetaphoneResult37.getPrimary();
        doubleMetaphoneResult37.append("A1", "ORKPXKMNSK");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj46 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A031383" + "'", str29, "A031383");
        org.junit.Assert.assertTrue("'" + char35 + "' != '" + '\000' + "'", char35 == '\000');
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
    }

    @Test
    public void test0497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0497");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength(100);
        java.lang.String str11 = soundex1.soundex("1111111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = soundex1.soundex("A0931383");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
    }

    @Test
    public void test0498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0498");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        int int3 = doubleMetaphone0.maxCodeLen;
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ORK", "A111111111");
        char char9 = doubleMetaphone0.charAt("A09", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
    }

    @Test
    public void test0499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0499");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        int int12 = metaphone0.getMaxCodeLen();
        java.lang.String str14 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKS");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ARKPKSKMNS" + "'", str14, "ARKPKSKMNS");
    }

    @Test
    public void test0500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0500");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        java.lang.String str14 = metaphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str16 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.apache.commons.codec.language.Metaphone metaphone17 = new org.apache.commons.codec.language.Metaphone();
        metaphone17.setMaxCodeLen(3);
        java.lang.String str21 = metaphone17.encode("");
        java.lang.String str23 = metaphone17.encode("");
        metaphone17.setMaxCodeLen((int) (short) 10);
        int int26 = metaphone17.getMaxCodeLen();
        java.lang.String str28 = metaphone17.metaphone("");
        java.lang.Object obj29 = metaphone0.encode((java.lang.Object) str28);
        java.lang.String str31 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP" + "'", str16, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "" + "'", obj29, "");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXN" + "'", str31, "ORKPXKMNSKTKNKTRKSSPXN");
    }
}

