package org.apache.commons.codec.language;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test0501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0501");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        int int19 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.EncoderException encoderException21 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("");
        encoderException21.addSuppressed((java.lang.Throwable) encoderException23);
        org.apache.commons.codec.EncoderException encoderException26 = new org.apache.commons.codec.EncoderException("hi!");
        encoderException23.addSuppressed((java.lang.Throwable) encoderException26);
        java.lang.Class<?> wildcardClass28 = encoderException26.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = metaphone0.encode((java.lang.Object) encoderException26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test0502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0502");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("ORKPXKMNSKTKNKTRKSSPXNH", "");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex15 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = refinedSoundex0.encode((java.lang.Object) refinedSoundex15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(refinedSoundex15);
    }

    @Test
    public void test0503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0503");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char31 = refinedSoundex29.getMappingCode('a');
        int int34 = refinedSoundex29.difference("", "hi!");
        char char36 = refinedSoundex29.getMappingCode('#');
        int int39 = refinedSoundex29.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj41 = refinedSoundex29.encode((java.lang.Object) "O941");
        java.lang.Object obj42 = caverphone0.encode(obj41);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone43 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone43.maxCodeLen = 0;
        char char48 = doubleMetaphone43.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult50 = doubleMetaphone43.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult50.appendAlternate('\000');
        doubleMetaphoneResult50.append('#');
        java.lang.String str55 = doubleMetaphoneResult50.getAlternate();
        doubleMetaphoneResult50.appendPrimary('1');
        doubleMetaphoneResult50.append('i', '1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj61 = caverphone0.encode((java.lang.Object) 'i');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(refinedSoundex29);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0" + "'", obj41, "O0");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "A111111111" + "'", obj42, "A111111111");
        org.junit.Assert.assertTrue("'" + char48 + "' != '" + '\000' + "'", char48 == '\000');
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "" + "'", str55, "");
    }

    @Test
    public void test0504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0504");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        char[] charArray8 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray8);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        char[] charArray16 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex17 = new org.apache.commons.codec.language.RefinedSoundex(charArray16);
        java.lang.String str19 = refinedSoundex17.encode("01230120022455012623010202");
        char char21 = refinedSoundex17.getMappingCode('#');
        int int24 = refinedSoundex17.difference(" ", "");
        java.lang.Object obj25 = refinedSoundex11.encode((java.lang.Object) " ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = soundex6.encode((java.lang.Object) refinedSoundex11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertArrayEquals(charArray8, new char[] { 'a' });
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertArrayEquals(charArray16, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
    }

    @Test
    public void test0505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0505");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean9 = metaphone0.isMetaphoneEqual("O000", "H");
        boolean boolean12 = metaphone0.isMetaphoneEqual("AKP1111111", "HI");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.encode("");
        metaphone13.setMaxCodeLen((int) (byte) 0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = metaphone0.encode((java.lang.Object) metaphone13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
    }

    @Test
    public void test0506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0506");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        java.lang.String str13 = metaphone0.encode("hi!");
        int int14 = metaphone0.getMaxCodeLen();
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "AKPKMNSKT");
        java.lang.String str19 = metaphone0.metaphone("A#");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone20 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone20.maxCodeLen = 0;
        java.lang.String str24 = doubleMetaphone20.encode("A621");
        boolean boolean28 = doubleMetaphone20.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        java.lang.String str30 = doubleMetaphone20.encode("");
        boolean boolean34 = doubleMetaphone20.isDoubleMetaphoneEqual("A621", "org.apache.commons.codec.EncoderException: hi!", false);
        doubleMetaphone20.maxCodeLen = '0';
        int int37 = doubleMetaphone20.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj38 = metaphone0.encode((java.lang.Object) int37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "H" + "'", str13, "H");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A" + "'", str19, "A");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 48 + "'", int37 == 48);
    }

    @Test
    public void test0507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0507");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("AA11111111", "org.apache.commons.codec.EncoderException: AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0508");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPXKMNSKTKNKTRKSPXN", "org.apache.commons.codec.EncoderExc");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0509");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        int int14 = refinedSoundex0.difference("1111111111", "org.apache.commons.codec.EncoderException: ");
        java.lang.String str16 = refinedSoundex0.encode("A");
        java.lang.String str18 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone19 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone19.maxCodeLen = 0;
        char char24 = doubleMetaphone19.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean28 = doubleMetaphone19.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char31 = doubleMetaphone19.charAt("01230120022455012623010202", (int) (short) 1);
        char char34 = doubleMetaphone19.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone19.maxCodeLen = 100;
        boolean boolean39 = doubleMetaphone19.isDoubleMetaphoneEqual("AKP", "AKP");
        java.lang.Object obj40 = refinedSoundex0.encode((java.lang.Object) "AKP");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A0" + "'", str16, "A0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O0" + "'", str18, "O0");
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '1' + "'", char31 == '1');
        org.junit.Assert.assertTrue("'" + char34 + "' != '" + 'O' + "'", char34 == 'O');
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertEquals("'" + obj40 + "' != '" + "A031" + "'", obj40, "A031");
    }

    @Test
    public void test0510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0510");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int3 = soundex0.getMaxLength();
        java.lang.String str5 = soundex0.soundex("O0");
        int int8 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex0, "A313", "O0");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O000" + "'", str5, "O000");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test0511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0511");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        java.lang.String str6 = soundex1.encode("O0940103030808306030830609053016080931");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char9 = refinedSoundex7.getMappingCode('a');
        int int12 = refinedSoundex7.difference("", "hi!");
        char char14 = refinedSoundex7.getMappingCode('0');
        char char16 = refinedSoundex7.getMappingCode('a');
        java.lang.String str18 = refinedSoundex7.soundex("1111111111");
        java.lang.String str20 = refinedSoundex7.soundex("O0940103030808306030830609053016080");
        java.lang.Object obj21 = soundex1.encode((java.lang.Object) "O0940103030808306030830609053016080");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O000" + "'", str6, "O000");
        org.junit.Assert.assertNotNull(refinedSoundex7);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '0' + "'", char16 == '0');
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O0" + "'", str20, "O0");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "O000" + "'", obj21, "O000");
    }

    @Test
    public void test0512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0512");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        org.apache.commons.codec.language.Caverphone caverphone11 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str13 = caverphone11.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone11.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str17 = caverphone11.encode("");
        java.lang.String str19 = caverphone11.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone20 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone20.maxCodeLen = 0;
        char char25 = doubleMetaphone20.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult27 = doubleMetaphone20.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult27.appendAlternate('\000');
        java.lang.String str30 = doubleMetaphoneResult27.getAlternate();
        java.lang.String str31 = doubleMetaphoneResult27.getPrimary();
        java.lang.Object obj32 = caverphone11.encode((java.lang.Object) str31);
        java.lang.String str34 = caverphone11.caverphone("");
        int int37 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone11, "AKPKKMNSKT", "ORKP");
        java.lang.String str39 = caverphone11.encode("O0");
        java.lang.String str41 = caverphone11.encode("");
        java.lang.Object obj43 = caverphone11.encode((java.lang.Object) "AKPKMNSKT1");
        java.lang.String str45 = caverphone11.caverphone("O0940103030808306030830609053016080931");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj46 = soundex0.encode((java.lang.Object) caverphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "1111111111" + "'", str19, "1111111111");
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '\000' + "'", char25 == '\000');
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "1111111111" + "'", obj32, "1111111111");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "1111111111" + "'", str34, "1111111111");
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "A111111111" + "'", str39, "A111111111");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "1111111111" + "'", str41, "1111111111");
        org.junit.Assert.assertEquals("'" + obj43 + "' != '" + "AKPKMNSKT1" + "'", obj43, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "A111111111" + "'", str45, "A111111111");
    }

    @Test
    public void test0513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0513");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        int int25 = refinedSoundex0.difference("O", "H0");
        char char27 = refinedSoundex0.getMappingCode(' ');
        int int30 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: O620", "ORKP");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '\000' + "'", char27 == '\000');
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
    }

    @Test
    public void test0514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0514");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        org.apache.commons.codec.language.Metaphone metaphone28 = new org.apache.commons.codec.language.Metaphone();
        metaphone28.setMaxCodeLen(3);
        int int31 = metaphone28.getMaxCodeLen();
        boolean boolean34 = metaphone28.isMetaphoneEqual("", "");
        boolean boolean37 = metaphone28.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean40 = metaphone28.isMetaphoneEqual("A621", "");
        java.lang.String str42 = metaphone28.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = refinedSoundex0.encode((java.lang.Object) metaphone28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "ORK" + "'", str42, "ORK");
    }

    @Test
    public void test0515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0515");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        int int16 = refinedSoundex0.difference("#", "org.apache.commons.codec.EncoderException: HI");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test0516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0516");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (byte) 100);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str17 = doubleMetaphone15.doubleMetaphone("H");
        java.lang.String str19 = doubleMetaphone15.doubleMetaphone("");
        doubleMetaphone15.setMaxCodeLen((int) (byte) 100);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = soundex1.encode((java.lang.Object) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test0517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0517");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = soundex1.soundex("A ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0518");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = '\000';
        char char16 = doubleMetaphone11.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone11.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult18.appendPrimary("");
        doubleMetaphoneResult18.appendPrimary("O620");
        doubleMetaphoneResult18.append('a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = caverphone0.encode((java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
    }

    @Test
    public void test0519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0519");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        soundex3.setMaxLength(2);
        // The following exception was thrown during execution in test generation
        try {
            int int11 = soundex3.difference("A0931383", "O0940103030808306030830609053016080931");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test0520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0520");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPKSKMNSKTKNKTRKSPKSN", "AKPKMNSK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0521");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        boolean boolean10 = metaphone0.isMetaphoneEqual("AKP1111111", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        int int11 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test0522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0522");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        boolean boolean16 = caverphone0.isCaverphoneEqual("hi!", "ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone17.maxCodeLen = 0;
        char char22 = doubleMetaphone17.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean26 = doubleMetaphone17.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult28 = doubleMetaphone17.new DoubleMetaphoneResult((int) '0');
        java.lang.String str29 = doubleMetaphoneResult28.getPrimary();
        boolean boolean30 = doubleMetaphoneResult28.isComplete();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test0523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0523");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        boolean boolean13 = doubleMetaphone8.isDoubleMetaphoneEqual("01230120022455012623010202", "");
        java.lang.Object obj14 = soundex1.encode((java.lang.Object) "01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = soundex1.encode("ARKP");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "" + "'", obj14, "");
    }

    @Test
    public void test0524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0524");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.caverphone("A");
        java.lang.String str36 = caverphone0.encode("A09315383");
        boolean boolean39 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT", "A ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "A111111111" + "'", str36, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test0525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0525");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        java.lang.String str14 = caverphone0.encode("AKPKKMNSKT");
        boolean boolean17 = caverphone0.isCaverphoneEqual("O941", "");
        java.lang.String str19 = caverphone0.encode("org.apache.commons.codec.EncoderException: O000");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone20 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str22 = doubleMetaphone20.doubleMetaphone("H");
        doubleMetaphone20.setMaxCodeLen((int) (byte) 0);
        java.lang.String str27 = doubleMetaphone20.doubleMetaphone("", false);
        java.lang.Object obj29 = doubleMetaphone20.encode((java.lang.Object) "ORKP");
        doubleMetaphone20.maxCodeLen = 0;
        boolean boolean35 = doubleMetaphone20.isDoubleMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", true);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = caverphone0.encode((java.lang.Object) boolean35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKT1" + "'", str14, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKKMNSKT" + "'", str19, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "" + "'", obj29, "");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test0526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0526");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        char char12 = refinedSoundex0.getMappingCode('#');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str15 = doubleMetaphone13.doubleMetaphone("H");
        doubleMetaphone13.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone13.maxCodeLen = '0';
        java.lang.String str22 = doubleMetaphone13.doubleMetaphone("A", true);
        boolean boolean25 = doubleMetaphone13.isDoubleMetaphoneEqual("A0", "");
        boolean boolean28 = doubleMetaphone13.isDoubleMetaphoneEqual("A ", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = doubleMetaphone13.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A" + "'", str22, "A");
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test0527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0527");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str8 = metaphone0.encode("org.apache.commons.codec.EncoderException: ");
        org.apache.commons.codec.language.Caverphone caverphone9 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str11 = caverphone9.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str13 = caverphone9.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone9.encode("");
        java.lang.String str17 = caverphone9.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone18.maxCodeLen = 0;
        char char23 = doubleMetaphone18.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult25 = doubleMetaphone18.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult25.appendAlternate('\000');
        java.lang.String str28 = doubleMetaphoneResult25.getAlternate();
        java.lang.String str29 = doubleMetaphoneResult25.getPrimary();
        java.lang.Object obj30 = caverphone9.encode((java.lang.Object) str29);
        java.lang.String str32 = caverphone9.caverphone("");
        int int35 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone9, "AKPKKMNSKT", "ORKP");
        boolean boolean38 = caverphone9.isCaverphoneEqual("", "HI");
        boolean boolean41 = caverphone9.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str43 = caverphone9.encode("A0");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj44 = metaphone0.encode((java.lang.Object) caverphone9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ORKPXKMNSK" + "'", str8, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "1111111111" + "'", obj30, "1111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "1111111111" + "'", str32, "1111111111");
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "A111111111" + "'", str43, "A111111111");
    }

    @Test
    public void test0528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0528");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = '\000';
        doubleMetaphone13.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone13.new DoubleMetaphoneResult((int) '1');
        java.lang.String str20 = doubleMetaphoneResult19.getPrimary();
        java.lang.String str21 = doubleMetaphoneResult19.getPrimary();
        doubleMetaphoneResult19.append("01230120022455012623010202");
        java.lang.String str24 = doubleMetaphoneResult19.getPrimary();
        doubleMetaphoneResult19.appendPrimary('4');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "01230120022455012623010202" + "'", str24, "01230120022455012623010202");
    }

    @Test
    public void test0529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0529");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str15 = caverphone0.encode("AA11111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AA11111111" + "'", str15, "AA11111111");
    }

    @Test
    public void test0530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0530");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char31 = refinedSoundex29.getMappingCode('a');
        int int34 = refinedSoundex29.difference("", "hi!");
        char char36 = refinedSoundex29.getMappingCode('#');
        int int39 = refinedSoundex29.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj41 = refinedSoundex29.encode((java.lang.Object) "O941");
        java.lang.Object obj42 = caverphone0.encode(obj41);
        boolean boolean45 = caverphone0.isCaverphoneEqual("H000", "AA");
        boolean boolean48 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: A093153836383693158", "A0313836");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(refinedSoundex29);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0" + "'", obj41, "O0");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "A111111111" + "'", obj42, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test0531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0531");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int3 = soundex0.difference("A1", " ");
        org.apache.commons.codec.language.Caverphone caverphone4 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str6 = caverphone4.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str8 = caverphone4.caverphone("hi!");
        java.lang.String str10 = caverphone4.caverphone("");
        java.lang.String str12 = caverphone4.caverphone("HI");
        boolean boolean15 = caverphone4.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str17 = caverphone4.caverphone("");
        java.lang.String str19 = caverphone4.encode("");
        java.lang.String str21 = caverphone4.caverphone("A111111111O620");
        java.lang.String str23 = caverphone4.caverphone("ARKPXKMNSK");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = soundex0.encode((java.lang.Object) caverphone4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "AKPKKMNSKT" + "'", str6, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "1111111111" + "'", str10, "1111111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AA11111111" + "'", str12, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "1111111111" + "'", str19, "1111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AA11111111" + "'", str21, "AA11111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "AKPKMNSK11" + "'", str23, "AKPKMNSK11");
    }

    @Test
    public void test0532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0532");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O09315383638369315893153836383693158931" + "'", str4, "O09315383638369315893153836383693158931");
    }

    @Test
    public void test0533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0533");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex2.setMaxLength((int) '1');
        int int7 = soundex2.difference("A0", "H");
        soundex2.setMaxLength((-1));
        java.lang.Object obj10 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = soundex2.encode(obj10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test0534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0534");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("");
        java.lang.String str29 = caverphone0.encode("A#");
        java.lang.Class<?> wildcardClass30 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "1111111111" + "'", str27, "1111111111");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A111111111" + "'", str29, "A111111111");
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test0535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0535");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("1111111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str11 = doubleMetaphone9.doubleMetaphone("H");
        doubleMetaphone9.setMaxCodeLen((int) (byte) 0);
        char char16 = doubleMetaphone9.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone9.new DoubleMetaphoneResult((int) '4');
        java.lang.String str19 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) str19);
        char[] charArray25 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex26 = new org.apache.commons.codec.language.RefinedSoundex(charArray25);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = caverphone0.encode((java.lang.Object) charArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + 'i' + "'", char16 == 'i');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "1111111111" + "'", obj20, "1111111111");
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertArrayEquals(charArray25, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test0536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0536");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: hi!", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0537");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            int int12 = soundex9.difference("ARKPKSKMNSK", "O09401030308083060308306090530160809315383638369315893153836383693158931");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: R");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test0538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0538");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ARKPXKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ARKPXKMNSKTKNKTRKSPXN" + "'", str1, "ARKPXKMNSKTKNKTRKSPXN");
    }

    @Test
    public void test0539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0539");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        int int7 = soundex0.getMaxLength();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone8.maxCodeLen = 0;
        char char13 = doubleMetaphone8.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str15 = doubleMetaphone8.encode("A");
        doubleMetaphone8.setMaxCodeLen((int) (short) 10);
        int int18 = doubleMetaphone8.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = soundex0.encode((java.lang.Object) doubleMetaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
    }

    @Test
    public void test0540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0540");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.String str16 = metaphone0.metaphone("A");
        int int17 = metaphone0.getMaxCodeLen();
        int int18 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) 'e');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test0541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0541");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("ARK", "AA11111111");
        java.lang.String str18 = caverphone0.encode("org.apache.commons.codec.EncoderException: A093153836383693158");
        boolean boolean21 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#", "HI");
        java.lang.String str23 = caverphone0.encode("H");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A111111111" + "'", str23, "A111111111");
    }

    @Test
    public void test0542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0542");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: hi!", "H0");
        java.lang.String str12 = metaphone0.metaphone("i0a");
        char[] charArray13 = null;
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray13);
        java.lang.String str16 = soundex14.encode("");
        java.lang.String str18 = soundex14.encode("");
        java.lang.String str20 = soundex14.soundex("");
        soundex14.setMaxLength((-1));
        java.lang.Class<?> wildcardClass23 = soundex14.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = metaphone0.encode((java.lang.Object) wildcardClass23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "I" + "'", str12, "I");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test0543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0543");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        char[] charArray7 = null;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        java.lang.String str10 = soundex8.soundex("");
        java.lang.String str12 = soundex8.encode("");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) "");
        boolean boolean16 = caverphone0.isCaverphoneEqual("O093", "AKP1111111");
        boolean boolean19 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#", " ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "1111111111" + "'", obj13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test0544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0544");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("ORKPXKMNSKTKNKTRKSSPXNH", "");
        char char16 = refinedSoundex0.getMappingCode(' ');
        org.apache.commons.codec.EncoderException encoderException18 = new org.apache.commons.codec.EncoderException("A ");
        org.apache.commons.codec.EncoderException encoderException20 = new org.apache.commons.codec.EncoderException("A0");
        java.lang.Throwable[] throwableArray21 = encoderException20.getSuppressed();
        encoderException18.addSuppressed((java.lang.Throwable) encoderException20);
        java.lang.Throwable[] throwableArray23 = encoderException18.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = refinedSoundex0.encode((java.lang.Object) throwableArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertArrayEquals(throwableArray21, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test0545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0545");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int5 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) '1');
        org.apache.commons.codec.EncoderException encoderException9 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray10 = encoderException9.getSuppressed();
        java.lang.Throwable[] throwableArray11 = encoderException9.getSuppressed();
        java.lang.Throwable[] throwableArray12 = encoderException9.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = metaphone0.encode((java.lang.Object) throwableArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertArrayEquals(throwableArray10, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertArrayEquals(throwableArray11, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertArrayEquals(throwableArray12, new java.lang.Throwable[] {});
    }

    @Test
    public void test0546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0546");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("ARKP");
        boolean boolean11 = metaphone0.isMetaphoneEqual("H0", "AKPKMNSKT");
        int int12 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.encode("");
        metaphone13.setMaxCodeLen((int) (short) 10);
        int int22 = metaphone13.getMaxCodeLen();
        java.lang.String str24 = metaphone13.encode("ORKP");
        int int25 = metaphone13.getMaxCodeLen();
        int int26 = metaphone13.getMaxCodeLen();
        int int27 = metaphone13.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj28 = metaphone0.encode((java.lang.Object) int27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ARKP" + "'", str8, "ARKP");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORKP" + "'", str24, "ORKP");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
    }

    @Test
    public void test0547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0547");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        java.lang.String str14 = caverphone0.encode("AKPKKMNSKT");
        boolean boolean17 = caverphone0.isCaverphoneEqual("O941", "");
        java.lang.String str19 = caverphone0.encode("O");
        java.lang.String str21 = caverphone0.encode("I");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKT1" + "'", str14, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A111111111" + "'", str19, "A111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A111111111" + "'", str21, "A111111111");
    }

    @Test
    public void test0548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0548");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int7 = soundex4.getMaxLength();
        java.lang.String str9 = soundex4.encode("A0313836");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A000" + "'", str9, "A000");
    }

    @Test
    public void test0549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0549");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str7 = soundex2.soundex("O620");
        java.lang.String str9 = soundex2.soundex("A621");
        java.lang.String str11 = soundex2.encode("AO");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O000" + "'", str7, "O000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A000" + "'", str9, "A000");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A000" + "'", str11, "A000");
    }

    @Test
    public void test0550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0550");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("org.apache.commons.codec.EncoderException: AKPKKMNSKT", "");
        soundex2.setMaxLength(35);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test0551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0551");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean(" org.apache.commons.codec.EncoderException: ORGAP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
    }

    @Test
    public void test0552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0552");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj12 = refinedSoundex0.encode((java.lang.Object) "O941");
        char char14 = refinedSoundex0.getMappingCode('0');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = 0;
        char char20 = doubleMetaphone15.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str22 = doubleMetaphone15.encode("A");
        java.lang.Object obj24 = doubleMetaphone15.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        int int25 = doubleMetaphone15.getMaxCodeLen();
        java.lang.String str28 = doubleMetaphone15.doubleMetaphone("A", false);
        boolean boolean32 = doubleMetaphone15.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ", "org.apache.commons.codec.EncoderException: A0", true);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult34 = doubleMetaphone15.new DoubleMetaphoneResult((int) '\000');
        doubleMetaphoneResult34.append("A313", "");
        java.lang.Object obj38 = refinedSoundex0.encode((java.lang.Object) "A313");
        java.lang.String str40 = refinedSoundex0.encode("AKPKSKMNS1");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "O0" + "'", obj12, "O0");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertEquals("'" + obj38 + "' != '" + "A0" + "'", obj38, "A0");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "A031383" + "'", str40, "A031383");
    }

    @Test
    public void test0553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0553");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        boolean boolean31 = caverphone0.isCaverphoneEqual("", "ARKPXKMNSKTKNKTRKS");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test0554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0554");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int7 = soundex4.getMaxLength();
        java.lang.String str9 = soundex4.soundex("ORKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
    }

    @Test
    public void test0555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0555");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("A111111111");
        int int10 = refinedSoundex5.difference("A ", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = refinedSoundex5.encode("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A " + "'", str7, "A ");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test0556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0556");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.metaphone("A0");
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str11 = caverphone5.encode("");
        java.lang.String str13 = caverphone5.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = 0;
        char char19 = doubleMetaphone14.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone14.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult21.appendAlternate('\000');
        java.lang.String str24 = doubleMetaphoneResult21.getAlternate();
        java.lang.String str25 = doubleMetaphoneResult21.getPrimary();
        java.lang.Object obj26 = caverphone5.encode((java.lang.Object) str25);
        java.lang.String str28 = caverphone5.caverphone("");
        int int31 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone5, "AKPKKMNSKT", "ORKP");
        java.lang.Object obj32 = metaphone0.encode((java.lang.Object) "AKPKKMNSKT");
        java.lang.String str34 = metaphone0.metaphone("A1");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone35 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone35.maxCodeLen = 0;
        char char40 = doubleMetaphone35.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean44 = doubleMetaphone35.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char47 = doubleMetaphone35.charAt("01230120022455012623010202", (int) (short) 1);
        char char50 = doubleMetaphone35.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone35.maxCodeLen = 100;
        boolean boolean55 = doubleMetaphone35.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        boolean boolean58 = doubleMetaphone35.isDoubleMetaphoneEqual("O621", "O093");
        doubleMetaphone35.setMaxCodeLen((int) '1');
        boolean boolean64 = doubleMetaphone35.isDoubleMetaphoneEqual("#", "A1", false);
        java.lang.Object obj65 = metaphone0.encode((java.lang.Object) "#");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AKPKKMNSKT" + "'", str9, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "1111111111" + "'", obj26, "1111111111");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "1111111111" + "'", str28, "1111111111");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "" + "'", obj32, "");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertTrue("'" + char40 + "' != '" + '\000' + "'", char40 == '\000');
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + char47 + "' != '" + '1' + "'", char47 == '1');
        org.junit.Assert.assertTrue("'" + char50 + "' != '" + 'O' + "'", char50 == 'O');
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertEquals("'" + obj65 + "' != '" + "#" + "'", obj65, "#");
    }

    @Test
    public void test0557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0557");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        char char12 = refinedSoundex0.getMappingCode('\000');
        org.apache.commons.codec.EncoderException encoderException14 = new org.apache.commons.codec.EncoderException("A0931");
        java.lang.Throwable[] throwableArray15 = encoderException14.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException17 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray18 = encoderException17.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException20 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException17.addSuppressed((java.lang.Throwable) encoderException20);
        encoderException14.addSuppressed((java.lang.Throwable) encoderException17);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = refinedSoundex0.encode((java.lang.Object) encoderException14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertArrayEquals(throwableArray15, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertArrayEquals(throwableArray18, new java.lang.Throwable[] {});
    }

    @Test
    public void test0558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0558");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        int int9 = soundex3.difference("A111111111", "01230120022455012623010202");
        int int10 = soundex3.getMaxLength();
        soundex3.setMaxLength(1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test0559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0559");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex2.setMaxLength((int) '1');
        org.apache.commons.codec.language.Metaphone metaphone5 = new org.apache.commons.codec.language.Metaphone();
        metaphone5.setMaxCodeLen(3);
        java.lang.String str9 = metaphone5.encode("");
        java.lang.String str11 = metaphone5.encode("");
        int int12 = metaphone5.getMaxCodeLen();
        int int13 = metaphone5.getMaxCodeLen();
        boolean boolean16 = metaphone5.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        boolean boolean19 = metaphone5.isMetaphoneEqual("ARKPKSKMNSKTKNKTRKSPKSN", "A093153836383693158");
        int int20 = metaphone5.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = soundex2.encode((java.lang.Object) metaphone5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
    }

    @Test
    public void test0560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0560");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        int int19 = refinedSoundex0.difference("1111111111", "O621");
        char char21 = refinedSoundex0.getMappingCode('r');
        char char23 = refinedSoundex0.getMappingCode('0');
        int int26 = refinedSoundex0.difference("AKPKMNSK", "AKPKMNSKTK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '9' + "'", char21 == '9');
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
    }

    @Test
    public void test0561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0561");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        java.lang.String str12 = metaphone0.encode("AA11111111");
        boolean boolean15 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "ARKPKKMNSKTKNKTRKSPXNRKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A" + "'", str12, "A");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test0562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0562");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        metaphone12.setMaxCodeLen(3);
        int int15 = metaphone12.getMaxCodeLen();
        metaphone12.setMaxCodeLen((int) (byte) 1);
        metaphone12.setMaxCodeLen((int) (byte) -1);
        boolean boolean22 = metaphone12.isMetaphoneEqual("O0940103030808306030830609053016080940103030808306030830609053016080", "01");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = caverphone0.encode((java.lang.Object) metaphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test0563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0563");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        int int5 = metaphone0.getMaxCodeLen();
        java.lang.String str7 = metaphone0.encode("A062125232523621256212523252362125");
        java.lang.String str9 = metaphone0.encode("ORKPXKMNSK");
        java.lang.String str11 = metaphone0.encode(" ");
        int int12 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A" + "'", str7, "A");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + " " + "'", str11, " ");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test0564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0564");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.Metaphone metaphone5 = new org.apache.commons.codec.language.Metaphone();
        metaphone5.setMaxCodeLen(3);
        java.lang.String str9 = metaphone5.encode("");
        java.lang.String str11 = metaphone5.encode("");
        int int12 = metaphone5.getMaxCodeLen();
        int int13 = metaphone5.getMaxCodeLen();
        boolean boolean16 = metaphone5.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        metaphone5.setMaxCodeLen((int) 'A');
        metaphone5.setMaxCodeLen((int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = metaphone0.encode((java.lang.Object) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test0565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0565");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.encode("A1");
        char[] charArray18 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex19 = new org.apache.commons.codec.language.RefinedSoundex(charArray18);
        java.lang.String str21 = refinedSoundex19.encode("01230120022455012623010202");
        char char23 = refinedSoundex19.getMappingCode('#');
        char char25 = refinedSoundex19.getMappingCode('1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = refinedSoundex0.encode((java.lang.Object) refinedSoundex19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0" + "'", str13, "A0");
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertArrayEquals(charArray18, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '\000' + "'", char25 == '\000');
    }

    @Test
    public void test0566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0566");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        int int7 = soundex0.getMaxLength();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        doubleMetaphone8.setMaxCodeLen((int) (byte) 0);
        java.lang.String str15 = doubleMetaphone8.doubleMetaphone("", false);
        java.lang.String str17 = doubleMetaphone8.encode("hi!");
        int int18 = doubleMetaphone8.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = soundex0.encode((java.lang.Object) doubleMetaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test0567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0567");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        boolean boolean3 = caverphone0.isCaverphoneEqual("AKPK", "AKP1111111");
        java.lang.String str5 = caverphone0.caverphone("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "AKPKMNSKTK" + "'", str5, "AKPKMNSKTK");
    }

    @Test
    public void test0568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0568");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean9 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone0.maxCodeLen = 3;
        java.lang.String str13 = doubleMetaphone0.doubleMetaphone(" ");
        int int14 = doubleMetaphone0.maxCodeLen;
        java.lang.String str17 = doubleMetaphone0.doubleMetaphone("ARKP", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone0.new DoubleMetaphoneResult((int) (short) -1);
        org.apache.commons.codec.language.Metaphone metaphone20 = new org.apache.commons.codec.language.Metaphone();
        metaphone20.setMaxCodeLen(3);
        int int23 = metaphone20.getMaxCodeLen();
        int int24 = metaphone20.getMaxCodeLen();
        metaphone20.setMaxCodeLen((int) (short) 10);
        java.lang.String str28 = metaphone20.encode("org.apache.commons.codec.EncoderException: ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = doubleMetaphone0.encode((java.lang.Object) metaphone20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ARK" + "'", str17, "ARK");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "ORKPXKMNSK" + "'", str28, "ORKPXKMNSK");
    }

    @Test
    public void test0569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0569");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "ORKPXKMNSKTKNKTRKSSPXNH", "A621");
        java.lang.String str7 = soundex1.encode("A313");
        soundex1.setMaxLength((int) '#');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
    }

    @Test
    public void test0570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0570");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        soundex1.setMaxLength((int) ' ');
        java.lang.Class<?> wildcardClass6 = soundex1.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test0571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0571");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int4 = soundex3.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone5 = new org.apache.commons.codec.language.Metaphone();
        metaphone5.setMaxCodeLen(3);
        int int8 = metaphone5.getMaxCodeLen();
        boolean boolean11 = metaphone5.isMetaphoneEqual("", "");
        boolean boolean14 = metaphone5.isMetaphoneEqual("01230120022455012623010202", "");
        java.lang.String str16 = metaphone5.metaphone("01230120022455012623010202");
        java.lang.Object obj17 = soundex3.encode((java.lang.Object) "01230120022455012623010202");
        java.lang.String str19 = soundex3.encode("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "" + "'", obj17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O621" + "'", str19, "O621");
    }

    @Test
    public void test0572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0572");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        int int12 = refinedSoundex5.difference(" ", "");
        // The following exception was thrown during execution in test generation
        try {
            int int15 = refinedSoundex5.difference("A212", "AKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test0573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0573");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: hi!");
        int int16 = refinedSoundex0.difference("AKPKKMNSKT", "O0940103030808306030830609053016080");
        int int19 = refinedSoundex0.difference("", "A621");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0940103030808306030830609053016080" + "'", str13, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test0574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0574");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str30 = caverphone0.caverphone("ARKP");
        java.lang.String str32 = caverphone0.caverphone("A0313");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AKPKKMNSKT" + "'", str28, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKP1111111" + "'", str30, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "A111111111" + "'", str32, "A111111111");
    }

    @Test
    public void test0575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0575");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        int int14 = refinedSoundex0.difference("1111111111", "org.apache.commons.codec.EncoderException: ");
        char char16 = refinedSoundex0.getMappingCode('i');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '0' + "'", char16 == '0');
    }

    @Test
    public void test0576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0576");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        int int6 = refinedSoundex0.difference("", "ORKPXKMNSKTKNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test0577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0577");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        java.lang.String str14 = soundex3.encode("O941");
        char[] charArray15 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex16 = new org.apache.commons.codec.language.Soundex(charArray15);
        soundex16.setMaxLength(1);
        int int19 = soundex16.getMaxLength();
        int int22 = soundex16.difference("HI", "");
        soundex16.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = soundex3.encode((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O000" + "'", str14, "O000");
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test0578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0578");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        java.lang.String str10 = metaphone0.encode("AR");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AR" + "'", str10, "AR");
    }

    @Test
    public void test0579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0579");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) ' ');
        boolean boolean7 = metaphone0.isMetaphoneEqual("A09315383", "org.apache.commons.codec.EncoderException: A111111111O620");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = metaphone0.encode((java.lang.Object) 'T');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test0580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0580");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        int int7 = soundex1.getMaxLength();
        int int10 = soundex1.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = 0;
        char char16 = doubleMetaphone11.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone11.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult18.append(' ');
        java.lang.String str21 = doubleMetaphoneResult18.getPrimary();
        java.lang.Object obj22 = soundex1.encode((java.lang.Object) str21);
        java.lang.String str24 = soundex1.soundex("org.apache.commons.codec.EncoderException: O620");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + " " + "'", str21, " ");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "" + "'", obj22, "");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O941" + "'", str24, "O941");
    }

    @Test
    public void test0581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0581");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone16 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str18 = caverphone16.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str20 = caverphone16.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str22 = caverphone16.encode("");
        java.lang.String str24 = caverphone16.encode("1111111111");
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "1111111111");
        java.lang.String str27 = refinedSoundex0.soundex("A031");
        java.lang.String str29 = refinedSoundex0.soundex("AKPKMNSK");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex30 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char32 = refinedSoundex30.getMappingCode('a');
        int int35 = refinedSoundex30.difference("", "hi!");
        char char37 = refinedSoundex30.getMappingCode('0');
        char char39 = refinedSoundex30.getMappingCode('a');
        java.lang.String str41 = refinedSoundex30.soundex("1111111111");
        char char43 = refinedSoundex30.getMappingCode('0');
        java.lang.String str45 = refinedSoundex30.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone46 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str48 = caverphone46.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str50 = caverphone46.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str52 = caverphone46.encode("");
        java.lang.String str54 = caverphone46.encode("1111111111");
        java.lang.Object obj55 = refinedSoundex30.encode((java.lang.Object) "1111111111");
        java.lang.String str57 = refinedSoundex30.soundex("A031");
        java.lang.String str59 = refinedSoundex30.encode("A621r");
        java.lang.Object obj60 = refinedSoundex0.encode((java.lang.Object) str59);
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKKMNSKT" + "'", str18, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKKMNSKT" + "'", str20, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "1111111111" + "'", str22, "1111111111");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A0" + "'", str27, "A0");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "A031383" + "'", str29, "A031383");
        org.junit.Assert.assertNotNull(refinedSoundex30);
        org.junit.Assert.assertTrue("'" + char32 + "' != '" + '0' + "'", char32 == '0');
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + char37 + "' != '" + '\000' + "'", char37 == '\000');
        org.junit.Assert.assertTrue("'" + char39 + "' != '" + '0' + "'", char39 == '0');
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "" + "'", str41, "");
        org.junit.Assert.assertTrue("'" + char43 + "' != '" + '\000' + "'", char43 == '\000');
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "O0" + "'", str45, "O0");
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "AKPKKMNSKT" + "'", str48, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "AKPKKMNSKT" + "'", str50, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str52 + "' != '" + "1111111111" + "'", str52, "1111111111");
        org.junit.Assert.assertEquals("'" + str54 + "' != '" + "1111111111" + "'", str54, "1111111111");
        org.junit.Assert.assertEquals("'" + obj55 + "' != '" + "" + "'", obj55, "");
        org.junit.Assert.assertEquals("'" + str57 + "' != '" + "A0" + "'", str57, "A0");
        org.junit.Assert.assertEquals("'" + str59 + "' != '" + "A09" + "'", str59, "A09");
        org.junit.Assert.assertEquals("'" + obj60 + "' != '" + "A0" + "'", obj60, "A0");
    }

    @Test
    public void test0582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0582");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("ARKP");
        boolean boolean11 = metaphone0.isMetaphoneEqual("H0", "AKPKMNSKT");
        java.lang.String str13 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ARKP" + "'", str8, "ARKP");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ORKP" + "'", str13, "ORKP");
    }

    @Test
    public void test0583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0583");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 1);
        java.lang.Object obj21 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = metaphone0.encode(obj21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
    }

    @Test
    public void test0584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0584");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("O");
        java.lang.Object obj17 = refinedSoundex0.encode((java.lang.Object) "A0");
        java.lang.String str19 = refinedSoundex0.soundex("A");
        int int22 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "AKP1111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0" + "'", str15, "O0");
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + "A0" + "'", obj17, "A0");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A0" + "'", str19, "A0");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test0585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0585");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        org.apache.commons.codec.language.Metaphone metaphone3 = new org.apache.commons.codec.language.Metaphone();
        metaphone3.setMaxCodeLen(3);
        int int6 = metaphone3.getMaxCodeLen();
        boolean boolean9 = metaphone3.isMetaphoneEqual("", "");
        boolean boolean12 = metaphone3.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone3.setMaxCodeLen(0);
        int int15 = metaphone3.getMaxCodeLen();
        metaphone3.setMaxCodeLen((int) (short) 100);
        java.lang.String str19 = metaphone3.encode("ARKP");
        java.lang.String str21 = metaphone3.encode("");
        java.lang.String str23 = metaphone3.encode("H");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = metaphone0.encode((java.lang.Object) metaphone3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ARKP" + "'", str19, "ARKP");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "H" + "'", str23, "H");
    }

    @Test
    public void test0586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0586");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        org.apache.commons.codec.EncoderException encoderException15 = new org.apache.commons.codec.EncoderException("O0940103030808306030830609053016080931");
        java.lang.Throwable[] throwableArray16 = encoderException15.getSuppressed();
        java.lang.Throwable[] throwableArray17 = encoderException15.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = refinedSoundex0.encode((java.lang.Object) throwableArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertArrayEquals(throwableArray16, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertArrayEquals(throwableArray17, new java.lang.Throwable[] {});
    }

    @Test
    public void test0587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0587");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        java.lang.String str15 = metaphone0.encode("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str17 = metaphone0.metaphone(" AKPK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "ORKPXKMNSK" + "'", str15, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "KPK" + "'", str17, "KPK");
    }

    @Test
    public void test0588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0588");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("1111111111", false);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("hi!", false);
        java.lang.String str13 = doubleMetaphone0.doubleMetaphone("", true);
        doubleMetaphone0.setMaxCodeLen((int) 'O');
        int int18 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "Aa", "O093");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test0589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0589");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean21 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char24 = doubleMetaphone12.charAt("01230120022455012623010202", (int) (short) 1);
        char char27 = doubleMetaphone12.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone12.maxCodeLen = 100;
        boolean boolean32 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        boolean boolean35 = doubleMetaphone12.isDoubleMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str37 = doubleMetaphone12.encode("A111111111");
        boolean boolean41 = doubleMetaphone12.isDoubleMetaphoneEqual("AKPKMNSK11", "A093153836383693158", false);
        doubleMetaphone12.setMaxCodeLen(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj44 = metaphone0.encode((java.lang.Object) doubleMetaphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '1' + "'", char24 == '1');
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + 'O' + "'", char27 == 'O');
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "A" + "'", str37, "A");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test0590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0590");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        int int3 = soundex0.getMaxLength();
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex0, "AKPKMNSKT1", "O093");
        char[] charArray7 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex8 = new org.apache.commons.codec.language.Soundex(charArray7);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray7);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray7);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = new org.apache.commons.codec.language.RefinedSoundex(charArray7);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex12 = new org.apache.commons.codec.language.RefinedSoundex(charArray7);
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray7);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = soundex0.encode((java.lang.Object) soundex13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray7);
    }

    @Test
    public void test0591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0591");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ORKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXN" + "'", str1, "ORKPXKMNSKTKNKTRKSSPXN");
    }

    @Test
    public void test0592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0592");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        java.lang.String str10 = refinedSoundex0.encode(" AKPK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A0313" + "'", str10, "A0313");
    }

    @Test
    public void test0593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0593");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        metaphone0.setMaxCodeLen((int) 'A');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
    }

    @Test
    public void test0594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0594");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.encode("A");
        java.lang.String str8 = refinedSoundex4.soundex("O093");
        int int11 = refinedSoundex4.difference("ARK", "org.apache.commons.codec.EncoderException: O620");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A0" + "'", str6, "A0");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O0" + "'", str8, "O0");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test0595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0595");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("O000");
        char[] charArray5 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray5);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray5);
        int int8 = soundex7.getMaxLength();
        soundex7.setMaxLength(114);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = soundex1.encode((java.lang.Object) soundex7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "O000" + "'", str3, "O000");
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertArrayEquals(charArray5, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test0596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0596");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        int int10 = refinedSoundex0.difference("ORKPXKMNSK", "ORK");
        char char12 = refinedSoundex0.getMappingCode('6');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '\000' + "'", char12 == '\000');
    }

    @Test
    public void test0597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0597");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        java.lang.String str10 = refinedSoundex8.soundex("A");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = refinedSoundex8.encode("AKPKMNSK");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "Aa" + "'", str10, "Aa");
    }

    @Test
    public void test0598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0598");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        java.lang.String str23 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        int int24 = metaphone0.getMaxCodeLen();
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKMNSKTK", "Aa");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str23, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test0599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0599");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        int int17 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.EncoderException encoderException19 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException21 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray22 = encoderException21.getSuppressed();
        encoderException19.addSuppressed((java.lang.Throwable) encoderException21);
        org.apache.commons.codec.EncoderException encoderException25 = new org.apache.commons.codec.EncoderException("");
        encoderException21.addSuppressed((java.lang.Throwable) encoderException25);
        java.lang.Throwable[] throwableArray27 = encoderException21.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException29 = new org.apache.commons.codec.EncoderException("O0");
        encoderException21.addSuppressed((java.lang.Throwable) encoderException29);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = metaphone0.encode((java.lang.Object) encoderException21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertArrayEquals(throwableArray22, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test0600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0600");
        char[] charArray2 = new char[] { '1', 'a' };
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str6 = soundex4.encode(" org.apache.commons.codec.EncoderException: ORGAP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', 'a' });
    }

    @Test
    public void test0601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0601");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        int int3 = doubleMetaphone0.maxCodeLen;
        int int6 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "org.apache.commons.codec.EncoderException: HI");
        int int7 = doubleMetaphone0.maxCodeLen;
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test0602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0602");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O09315383638369315893153836383693158");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0603");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        boolean boolean17 = metaphone0.isMetaphoneEqual("AKPKMNSK11", "");
        boolean boolean20 = metaphone0.isMetaphoneEqual("", "O0931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test0604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0604");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str7 = soundex2.encode("AKPKKMNSKT");
        org.apache.commons.codec.language.Metaphone metaphone8 = new org.apache.commons.codec.language.Metaphone();
        metaphone8.setMaxCodeLen(3);
        int int11 = metaphone8.getMaxCodeLen();
        int int12 = metaphone8.getMaxCodeLen();
        metaphone8.setMaxCodeLen((int) (short) 10);
        java.lang.String str16 = metaphone8.encode("org.apache.commons.codec.EncoderException: ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = soundex2.encode((java.lang.Object) metaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A313" + "'", str7, "A313");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORKPXKMNSK" + "'", str16, "ORKPXKMNSK");
    }

    @Test
    public void test0605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0605");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        char char9 = refinedSoundex4.getMappingCode('a');
        int int12 = refinedSoundex4.difference("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "H000");
        int int15 = refinedSoundex4.difference("org.apache.commons.codec.EncoderException: A093153836383693158", "O0931");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
    }

    @Test
    public void test0606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0606");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (short) 0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = 0;
        char char15 = doubleMetaphone10.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean19 = doubleMetaphone10.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char22 = doubleMetaphone10.charAt("01230120022455012623010202", (int) (short) 1);
        char char25 = doubleMetaphone10.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone10.maxCodeLen = (byte) 10;
        doubleMetaphone10.maxCodeLen = 3;
        java.lang.String str31 = doubleMetaphone10.doubleMetaphone("org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = soundex1.encode((java.lang.Object) doubleMetaphone10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '1' + "'", char22 == '1');
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + 'O' + "'", char25 == 'O');
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "ARK" + "'", str31, "ARK");
    }

    @Test
    public void test0607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0607");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode(' ');
        java.lang.String str9 = refinedSoundex0.soundex("1111111111");
        char char11 = refinedSoundex0.getMappingCode('i');
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '0' + "'", char11 == '0');
    }

    @Test
    public void test0608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0608");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str13 = metaphone0.encode("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
    }

    @Test
    public void test0609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0609");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone17.maxCodeLen = 0;
        char char22 = doubleMetaphone17.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult24 = doubleMetaphone17.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult24.appendAlternate('\000');
        doubleMetaphoneResult24.append('#');
        java.lang.String str29 = doubleMetaphoneResult24.getAlternate();
        java.lang.String str30 = doubleMetaphoneResult24.getAlternate();
        doubleMetaphoneResult24.append('a', '#');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = refinedSoundex0.encode((java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
    }

    @Test
    public void test0610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0610");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0611");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        int int5 = soundex0.difference("O0940103030808306030830609053016080931", "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test0612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0612");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("hi!", " AKP1111111 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0613");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray3);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = refinedSoundex6.encode(" AKPK");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test0614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0614");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.soundex("A0313836");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0615");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        int int8 = soundex1.getMaxLength();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char11 = refinedSoundex9.getMappingCode('a');
        int int14 = refinedSoundex9.difference("", "hi!");
        char char16 = refinedSoundex9.getMappingCode('0');
        char char18 = refinedSoundex9.getMappingCode('a');
        java.lang.String str20 = refinedSoundex9.soundex("1111111111");
        char char22 = refinedSoundex9.getMappingCode('i');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone23 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone23.maxCodeLen = 0;
        char char28 = doubleMetaphone23.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean32 = doubleMetaphone23.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone23.maxCodeLen = 3;
        java.lang.String str36 = doubleMetaphone23.encode("A111111111");
        java.lang.Object obj37 = refinedSoundex9.encode((java.lang.Object) str36);
        char char39 = refinedSoundex9.getMappingCode('4');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj40 = soundex1.encode((java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(refinedSoundex9);
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '0' + "'", char11 == '0');
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '0' + "'", char18 == '0');
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '0' + "'", char22 == '0');
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '\000' + "'", char28 == '\000');
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "A" + "'", str36, "A");
        org.junit.Assert.assertEquals("'" + obj37 + "' != '" + "A0" + "'", obj37, "A0");
        org.junit.Assert.assertTrue("'" + char39 + "' != '" + '\000' + "'", char39 == '\000');
    }

    @Test
    public void test0616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0616");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "ARKPXKMNSK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0617");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.encode("O0");
        java.lang.String str24 = metaphone0.encode("AKPKMNSK");
        metaphone0.setMaxCodeLen(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O" + "'", str22, "O");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKMNSK" + "'", str24, "AKPKMNSK");
    }

    @Test
    public void test0618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0618");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone7 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str9 = doubleMetaphone7.doubleMetaphone("H");
        doubleMetaphone7.maxCodeLen = '0';
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult13 = doubleMetaphone7.new DoubleMetaphoneResult((int) '1');
        java.lang.String str16 = doubleMetaphone7.doubleMetaphone("ARKPXKMNSK", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = metaphone0.encode((java.lang.Object) doubleMetaphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKPKSKMNSK" + "'", str16, "ARKPKSKMNSK");
    }

    @Test
    public void test0619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0619");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A093153836383693158", "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0620");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Object obj12 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = caverphone0.encode(obj12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test0621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0621");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        java.lang.String str18 = refinedSoundex0.encode("AKPKMNSK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A031383" + "'", str18, "A031383");
    }

    @Test
    public void test0622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0622");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, " AKPK", "AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0623");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        java.lang.String str27 = caverphone0.caverphone("A313");
        boolean boolean30 = caverphone0.isCaverphoneEqual("ARKPXKMNSK", "ARKPXKMNSKTSNKTRKSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A111111111" + "'", str27, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test0624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0624");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen(48);
        java.lang.String[] strArray12 = new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" };
        boolean boolean13 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 1, (int) (short) 1, strArray12);
        boolean boolean14 = org.apache.commons.codec.language.DoubleMetaphone.contains("", (int) (byte) 0, (int) (short) 1, strArray12);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = metaphone0.encode((java.lang.Object) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertArrayEquals(strArray12, new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" });
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test0625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0625");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        java.lang.String str18 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str20 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORKPXKMNSK" + "'", str18, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "ORKPXKMNSK" + "'", str20, "ORKPXKMNSK");
    }

    @Test
    public void test0626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0626");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        int int4 = soundex1.getMaxLength();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char7 = refinedSoundex5.getMappingCode('a');
        int int10 = refinedSoundex5.difference("", "hi!");
        int int13 = refinedSoundex5.difference("hi!", "");
        char char15 = refinedSoundex5.getMappingCode('#');
        char char17 = refinedSoundex5.getMappingCode('a');
        java.lang.String str19 = refinedSoundex5.soundex("org.apache.commons.codec.EncoderException: A0");
        java.lang.Object obj20 = soundex1.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: A0");
        soundex1.setMaxLength(35);
        int int25 = soundex1.difference("AKPK", "AKP");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(refinedSoundex5);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '0' + "'", char17 == '0');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0940103030808306030830609053016080" + "'", str19, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "O621" + "'", obj20, "O621");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
    }

    @Test
    public void test0627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0627");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.Object obj9 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = metaphone0.encode(obj9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test0628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0628");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("");
        org.apache.commons.codec.EncoderException encoderException9 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.Throwable[] throwableArray10 = encoderException9.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException12 = new org.apache.commons.codec.EncoderException("A111111111O620");
        encoderException9.addSuppressed((java.lang.Throwable) encoderException12);
        java.lang.Throwable[] throwableArray14 = encoderException12.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = soundex0.encode((java.lang.Object) encoderException12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertArrayEquals(throwableArray10, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertArrayEquals(throwableArray14, new java.lang.Throwable[] {});
    }

    @Test
    public void test0629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0629");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone4 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone4.maxCodeLen = 0;
        char char9 = doubleMetaphone4.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str11 = doubleMetaphone4.encode("A");
        java.lang.Object obj12 = soundex3.encode((java.lang.Object) str11);
        java.lang.String str14 = soundex3.soundex("");
        char[] charArray15 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex16 = new org.apache.commons.codec.language.Soundex(charArray15);
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray15);
        soundex17.setMaxLength((int) 'e');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = soundex3.encode((java.lang.Object) soundex17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "" + "'", obj12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test0630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0630");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        int int12 = refinedSoundex5.difference(" ", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean22 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone13.maxCodeLen = 3;
        java.lang.String str26 = doubleMetaphone13.doubleMetaphone(" ");
        java.lang.Object obj27 = refinedSoundex5.encode((java.lang.Object) " ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = refinedSoundex5.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + "" + "'", obj27, "");
    }

    @Test
    public void test0631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0631");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean(" AKP1111111 ");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AKP" + "'", str1, "AKP");
    }

    @Test
    public void test0632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0632");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("O093");
        java.lang.String str16 = metaphone0.metaphone("ORK");
        boolean boolean19 = metaphone0.isMetaphoneEqual("A0313836", "H0");
        boolean boolean22 = metaphone0.isMetaphoneEqual("O09315383638369315893153836383693158931", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORK" + "'", str16, "ORK");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test0633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0633");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        java.lang.String str30 = caverphone0.encode("");
        java.lang.Object obj32 = caverphone0.encode((java.lang.Object) "AKPKMNSKT1");
        java.lang.String str34 = caverphone0.caverphone("O0940103030808306030830609053016080931");
        java.lang.String str36 = caverphone0.encode("ORK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "1111111111" + "'", str30, "1111111111");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "AKPKMNSKT1" + "'", obj32, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "AK11111111" + "'", str36, "AK11111111");
    }

    @Test
    public void test0634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0634");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPKSKMNS", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0635");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: AA11111111");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONAA");
    }

    @Test
    public void test0636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0636");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("AA11111111");
        java.lang.String str13 = caverphone0.encode("ORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AA11111111" + "'", str11, "AA11111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKP1111111" + "'", str13, "AKP1111111");
    }

    @Test
    public void test0637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0637");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        int int16 = refinedSoundex0.difference("AA11111111", "01230120022455012623010202");
        char[] charArray17 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex18 = new org.apache.commons.codec.language.Soundex(charArray17);
        int int19 = soundex18.getMaxLength();
        int int20 = soundex18.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = refinedSoundex0.encode((java.lang.Object) int20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
    }

    @Test
    public void test0638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0638");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        java.lang.String str12 = metaphone0.encode("ARKPXKMNSKTKNKTRKSPXN");
        java.lang.Object obj13 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = metaphone0.encode(obj13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ARKPKSKMNS" + "'", str12, "ARKPKSKMNS");
    }

    @Test
    public void test0639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0639");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "H");
        boolean boolean19 = metaphone0.isMetaphoneEqual(" ", "O941");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone20 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone20.maxCodeLen = 0;
        char char25 = doubleMetaphone20.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean29 = doubleMetaphone20.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char32 = doubleMetaphone20.charAt("01230120022455012623010202", (int) (short) 1);
        char char35 = doubleMetaphone20.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone20.maxCodeLen = 100;
        boolean boolean40 = doubleMetaphone20.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        boolean boolean43 = doubleMetaphone20.isDoubleMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str45 = doubleMetaphone20.encode("AKPKKMNSKT");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult47 = doubleMetaphone20.new DoubleMetaphoneResult((int) (byte) 10);
        boolean boolean51 = doubleMetaphone20.isDoubleMetaphoneEqual("A111111111O620", "org.apache.commons.codec.EncoderException: 01230120022455012623010202", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj52 = metaphone0.encode((java.lang.Object) boolean51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '\000' + "'", char25 == '\000');
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + char32 + "' != '" + '1' + "'", char32 == '1');
        org.junit.Assert.assertTrue("'" + char35 + "' != '" + 'O' + "'", char35 == 'O');
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "AKPKMNSKT" + "'", str45, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test0640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0640");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        org.apache.commons.codec.language.Metaphone metaphone7 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str9 = metaphone7.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str11 = metaphone7.metaphone("A");
        java.lang.Object obj12 = metaphone0.encode((java.lang.Object) "A");
        java.lang.Class<?> wildcardClass13 = metaphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A" + "'", str11, "A");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "A" + "'", obj12, "A");
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test0641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0641");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str30 = doubleMetaphone28.doubleMetaphone("H");
        java.lang.String str32 = doubleMetaphone28.doubleMetaphone("HI");
        java.lang.String str34 = doubleMetaphone28.doubleMetaphone("AKPKMNSKT1");
        java.lang.Object obj35 = metaphone0.encode((java.lang.Object) str34);
        boolean boolean38 = metaphone0.isMetaphoneEqual("", "A093153836383693158");
        org.apache.commons.codec.language.Metaphone metaphone39 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str41 = metaphone39.encode("");
        int int42 = metaphone39.getMaxCodeLen();
        boolean boolean45 = metaphone39.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        java.lang.String str47 = metaphone39.metaphone("");
        java.lang.Object obj48 = metaphone0.encode((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPK" + "'", str34, "AKPK");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "AKPK" + "'", obj35, "AKPK");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "" + "'", str41, "");
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "" + "'", str47, "");
        org.junit.Assert.assertEquals("'" + obj48 + "' != '" + "" + "'", obj48, "");
    }

    @Test
    public void test0642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0642");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("O093");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A313", "org.apache.commons.codec.EncoderException: ");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone18.maxCodeLen = 0;
        char char23 = doubleMetaphone18.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean27 = doubleMetaphone18.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char30 = doubleMetaphone18.charAt("01230120022455012623010202", (int) (short) 1);
        char char33 = doubleMetaphone18.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone18.maxCodeLen = (byte) 10;
        boolean boolean38 = doubleMetaphone18.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult40 = doubleMetaphone18.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult40.appendPrimary('i');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = metaphone0.encode((java.lang.Object) 'i');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + '1' + "'", char30 == '1');
        org.junit.Assert.assertTrue("'" + char33 + "' != '" + 'O' + "'", char33 == 'O');
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test0643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0643");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        int int6 = refinedSoundex0.difference("A111111111", "O0940103030808306030830609053016080");
        java.lang.Object obj8 = refinedSoundex0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertEquals("'" + obj8 + "' != '" + "O0940103030808306030830609053016080940103030808306030830609053016080" + "'", obj8, "O0940103030808306030830609053016080940103030808306030830609053016080");
    }

    @Test
    public void test0644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0644");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: ");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTION" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTION");
    }

    @Test
    public void test0645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0645");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        boolean boolean10 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: A093153836383693158", "");
        boolean boolean13 = metaphone0.isMetaphoneEqual("ORKPXKMNSKTKNKTRKSSPXNRKP", "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        metaphone0.setMaxCodeLen(111);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test0646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0646");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        java.lang.String str8 = soundex4.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test0647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0647");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        int int16 = refinedSoundex0.difference("A000", "01230120022455012623010202");
        int int19 = refinedSoundex0.difference("AKPK", "AKP1111111");
        int int22 = refinedSoundex0.difference("H000", "ORKPXKMNSKTKNKTRKSSPXNH");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex23 = new org.apache.commons.codec.language.RefinedSoundex();
        int int26 = refinedSoundex23.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        char char28 = refinedSoundex23.getMappingCode(' ');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = refinedSoundex0.encode((java.lang.Object) char28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + char28 + "' != '" + '\000' + "'", char28 == '\000');
    }

    @Test
    public void test0648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0648");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        org.apache.commons.codec.language.Caverphone caverphone13 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str15 = caverphone13.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex16 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char18 = refinedSoundex16.getMappingCode('a');
        int int21 = refinedSoundex16.difference("", "hi!");
        char char23 = refinedSoundex16.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone24 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str26 = doubleMetaphone24.doubleMetaphone("H");
        java.lang.String str28 = doubleMetaphone24.doubleMetaphone("");
        java.lang.String str31 = doubleMetaphone24.doubleMetaphone("ORKP", true);
        java.lang.String str34 = doubleMetaphone24.doubleMetaphone("", false);
        java.lang.String str36 = doubleMetaphone24.encode("");
        java.lang.Object obj37 = refinedSoundex16.encode((java.lang.Object) "");
        java.lang.Object obj38 = caverphone13.encode(obj37);
        int int41 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone13, "", "");
        java.lang.String str43 = caverphone13.caverphone("AK11111111");
        boolean boolean46 = caverphone13.isCaverphoneEqual("", "O621");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj47 = refinedSoundex0.encode((java.lang.Object) caverphone13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex16);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '0' + "'", char18 == '0');
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "ARKP" + "'", str31, "ARKP");
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertEquals("'" + obj37 + "' != '" + "" + "'", obj37, "");
        org.junit.Assert.assertEquals("'" + obj38 + "' != '" + "1111111111" + "'", obj38, "1111111111");
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "AK11111111" + "'", str43, "AK11111111");
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test0649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0649");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        int int11 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean21 = doubleMetaphone12.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone12.maxCodeLen = 3;
        int int24 = doubleMetaphone12.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = metaphone0.encode((java.lang.Object) doubleMetaphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
    }

    @Test
    public void test0650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0650");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("AK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AK" + "'", str1, "AK");
    }

    @Test
    public void test0651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0651");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        boolean boolean20 = caverphone0.isCaverphoneEqual("AKPKMNSK11", "A#");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test0652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0652");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean5 = metaphone0.isMetaphoneEqual("ARK", "A0931");
        boolean boolean8 = metaphone0.isMetaphoneEqual("hi!", "O093");
        char[] charArray13 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex14 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex15 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex16 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex17 = new org.apache.commons.codec.language.RefinedSoundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex18 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex19 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex20 = new org.apache.commons.codec.language.Soundex(charArray13);
        org.apache.commons.codec.language.Soundex soundex21 = new org.apache.commons.codec.language.Soundex(charArray13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = metaphone0.encode((java.lang.Object) soundex21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertArrayEquals(charArray13, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test0653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0653");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength((int) (byte) 100);
        soundex1.setMaxLength((int) (byte) 100);
        int int8 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "", "O941");
        org.apache.commons.codec.language.Caverphone caverphone9 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str11 = caverphone9.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str13 = caverphone9.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone9.encode("A");
        char[] charArray16 = null;
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray16);
        java.lang.String str19 = soundex17.soundex("");
        java.lang.String str21 = soundex17.encode("");
        java.lang.Object obj22 = caverphone9.encode((java.lang.Object) "");
        java.lang.Object obj23 = soundex1.encode((java.lang.Object) "");
        java.lang.String str25 = soundex1.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKPKKMNSKT" + "'", str11, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A111111111" + "'", str15, "A111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "1111111111" + "'", obj22, "1111111111");
        org.junit.Assert.assertEquals("'" + obj23 + "' != '" + "" + "'", obj23, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
    }

    @Test
    public void test0654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0654");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.soundex("HI");
        char char9 = refinedSoundex0.getMappingCode('1');
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
    }

    @Test
    public void test0655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0655");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength(100);
        java.lang.String str11 = soundex1.soundex("1111111111");
        // The following exception was thrown during execution in test generation
        try {
            int int14 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "O620", "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
    }

    @Test
    public void test0656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0656");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        org.apache.commons.codec.language.Metaphone metaphone8 = new org.apache.commons.codec.language.Metaphone();
        metaphone8.setMaxCodeLen(3);
        java.lang.String str12 = metaphone8.encode("");
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone8, "hi!", "");
        metaphone8.setMaxCodeLen(0);
        boolean boolean20 = metaphone8.isMetaphoneEqual("A0", "");
        int int23 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone8, "AKP", "hi!");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = refinedSoundex5.encode((java.lang.Object) metaphone8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test0657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0657");
        char[] charArray0 = new char[] {};
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        int int11 = refinedSoundex3.difference("", "A");
        org.apache.commons.codec.language.Caverphone caverphone12 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str14 = caverphone12.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str16 = caverphone12.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str18 = caverphone12.encode("");
        java.lang.String str20 = caverphone12.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone21 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone21.maxCodeLen = 0;
        char char26 = doubleMetaphone21.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult28 = doubleMetaphone21.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult28.appendAlternate('\000');
        java.lang.String str31 = doubleMetaphoneResult28.getAlternate();
        java.lang.String str32 = doubleMetaphoneResult28.getPrimary();
        java.lang.Object obj33 = caverphone12.encode((java.lang.Object) str32);
        java.lang.String str35 = caverphone12.caverphone("");
        java.lang.String str37 = caverphone12.encode("");
        boolean boolean40 = caverphone12.isCaverphoneEqual("", "A#");
        java.lang.Object obj41 = refinedSoundex3.encode((java.lang.Object) "A#");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj42 = soundex2.encode((java.lang.Object) "A#");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: A");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertArrayEquals(charArray0, new char[] {});
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKKMNSKT" + "'", str14, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "AKPKKMNSKT" + "'", str16, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "1111111111" + "'", str18, "1111111111");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "1111111111" + "'", str20, "1111111111");
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '\000' + "'", char26 == '\000');
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "1111111111" + "'", obj33, "1111111111");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "1111111111" + "'", str35, "1111111111");
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "1111111111" + "'", str37, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "A0" + "'", obj41, "A0");
    }

    @Test
    public void test0658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0658");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A212", "ORKPXKMNSKTKNKTRKSK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0659");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = refinedSoundex7.encode("org.apache.commons.codec.EncoderException: O620");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0660");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        metaphone0.setMaxCodeLen(0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "A621r", "AA11111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test0661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0661");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.soundex("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str14 = refinedSoundex0.encode("0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A093138363836931589313836383693158" + "'", str12, "A093138363836931589313836383693158");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test0662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0662");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "O093");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0663");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        int int11 = metaphone0.getMaxCodeLen();
        int int12 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test0664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0664");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.soundex("HI");
        java.lang.String str9 = refinedSoundex0.encode("hi!");
        char char11 = refinedSoundex0.getMappingCode('0');
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H0" + "'", str9, "H0");
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '\000' + "'", char11 == '\000');
    }

    @Test
    public void test0665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0665");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        boolean boolean24 = caverphone0.isCaverphoneEqual("O09315383638369315893153836383693158931", "A212");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test0666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0666");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean7 = caverphone0.isCaverphoneEqual("O", "01230120022455012623010202");
        boolean boolean10 = caverphone0.isCaverphoneEqual("ARKP", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        java.lang.String str12 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        org.apache.commons.codec.EncoderException encoderException14 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray15 = encoderException14.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException17 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException19 = new org.apache.commons.codec.EncoderException("");
        encoderException17.addSuppressed((java.lang.Throwable) encoderException19);
        encoderException14.addSuppressed((java.lang.Throwable) encoderException19);
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray24 = encoderException23.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException26 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException28 = new org.apache.commons.codec.EncoderException("");
        encoderException26.addSuppressed((java.lang.Throwable) encoderException28);
        encoderException23.addSuppressed((java.lang.Throwable) encoderException28);
        encoderException14.addSuppressed((java.lang.Throwable) encoderException23);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = caverphone0.encode((java.lang.Object) encoderException14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertArrayEquals(throwableArray15, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertArrayEquals(throwableArray24, new java.lang.Throwable[] {});
    }

    @Test
    public void test0667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0667");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) 'a');
        metaphone0.setMaxCodeLen(0);
        java.lang.String str14 = metaphone0.metaphone("");
        java.lang.String str16 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
    }

    @Test
    public void test0668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0668");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0669");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A#", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0670");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0671");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('4');
        java.lang.String str8 = refinedSoundex4.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = refinedSoundex4.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test0672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0672");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.Metaphone metaphone5 = new org.apache.commons.codec.language.Metaphone();
        metaphone5.setMaxCodeLen(3);
        java.lang.String str9 = metaphone5.encode("");
        metaphone5.setMaxCodeLen((int) (short) 100);
        int int12 = metaphone5.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = metaphone0.encode((java.lang.Object) metaphone5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test0673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0673");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        org.apache.commons.codec.language.Metaphone metaphone19 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str21 = metaphone19.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone19.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone24 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str26 = caverphone24.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str28 = caverphone24.caverphone("hi!");
        java.lang.Object obj29 = metaphone19.encode((java.lang.Object) "hi!");
        java.lang.String str31 = metaphone19.encode("O0940103030808306030830609053016080");
        java.lang.Object obj32 = metaphone0.encode((java.lang.Object) str31);
        int int33 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ORKP" + "'", str21, "ORKP");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "AKPKKMNSKT" + "'", str26, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AA11111111" + "'", str28, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "H" + "'", obj29, "H");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "O" + "'", str31, "O");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "O" + "'", obj32, "O");
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
    }

    @Test
    public void test0674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0674");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.encode("AKPK");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0675");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        soundex0.setMaxLength(65);
        org.apache.commons.codec.language.Metaphone metaphone4 = new org.apache.commons.codec.language.Metaphone();
        metaphone4.setMaxCodeLen(3);
        int int7 = metaphone4.getMaxCodeLen();
        java.lang.String str9 = metaphone4.encode("hi!");
        java.lang.String str11 = metaphone4.encode("O621");
        java.lang.String str13 = metaphone4.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.Object obj14 = soundex0.encode((java.lang.Object) "O0940103030808306030830609053016080940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H" + "'", str9, "H");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O" + "'", str11, "O");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O" + "'", str13, "O");
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "O000" + "'", obj14, "O000");
    }

    @Test
    public void test0676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0676");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        java.lang.String str12 = metaphone0.encode("ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str14 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str16 = metaphone0.encode("01230120022455012623010202");
        java.lang.String str18 = metaphone0.metaphone("H000");
        char[] charArray20 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex21 = new org.apache.commons.codec.language.RefinedSoundex(charArray20);
        org.apache.commons.codec.language.Soundex soundex22 = new org.apache.commons.codec.language.Soundex(charArray20);
        soundex22.setMaxLength(10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = metaphone0.encode((java.lang.Object) soundex22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ARKPKSKMNS" + "'", str12, "ARKPKSKMNS");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ORKPXKMNSK" + "'", str14, "ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertArrayEquals(charArray20, new char[] { 'a' });
    }

    @Test
    public void test0677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0677");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char10 = refinedSoundex8.getMappingCode('a');
        int int13 = refinedSoundex8.difference("", "hi!");
        int int16 = refinedSoundex8.difference("hi!", "");
        int int19 = refinedSoundex8.difference("hi!", "");
        java.lang.String str21 = refinedSoundex8.soundex("");
        int int24 = refinedSoundex8.difference("O621", "A111111111");
        java.lang.Object obj25 = soundex1.encode((java.lang.Object) "O621");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(refinedSoundex8);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '0' + "'", char10 == '0');
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "O000" + "'", obj25, "O000");
    }

    @Test
    public void test0678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0678");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.EncoderException encoderException8 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = soundex6.encode((java.lang.Object) "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0679");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("");
        org.apache.commons.codec.EncoderException encoderException10 = new org.apache.commons.codec.EncoderException("ARKPXKMNSKTKNKTRKSPXN");
        org.apache.commons.codec.EncoderException encoderException12 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray13 = encoderException12.getSuppressed();
        java.lang.Throwable[] throwableArray14 = encoderException12.getSuppressed();
        encoderException10.addSuppressed((java.lang.Throwable) encoderException12);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = metaphone0.encode((java.lang.Object) encoderException12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertArrayEquals(throwableArray13, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertArrayEquals(throwableArray14, new java.lang.Throwable[] {});
    }

    @Test
    public void test0680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0680");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A313", "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0681");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        char char6 = refinedSoundex4.getMappingCode('\000');
        org.apache.commons.codec.language.Metaphone metaphone7 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str9 = metaphone7.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone7.setMaxCodeLen((int) (byte) 100);
        boolean boolean14 = metaphone7.isMetaphoneEqual("", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = refinedSoundex4.encode((java.lang.Object) metaphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test0682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0682");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.encode("O0940103030808306030830609053016080931");
        int int11 = soundex0.getMaxLength();
        java.lang.String str13 = soundex0.soundex("AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A212" + "'", str13, "A212");
    }

    @Test
    public void test0683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0683");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone1 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone1.maxCodeLen = 0;
        char char6 = doubleMetaphone1.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str8 = doubleMetaphone1.encode("A");
        java.lang.Object obj10 = doubleMetaphone1.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone1.maxCodeLen = (byte) 1;
        doubleMetaphone1.maxCodeLen = 'a';
        doubleMetaphone1.setMaxCodeLen((int) 'o');
        java.lang.String str19 = doubleMetaphone1.doubleMetaphone("ORKPXKMNSK", true);
        java.lang.Object obj20 = soundex0.encode((java.lang.Object) str19);
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\000' + "'", char6 == '\000');
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "" + "'", obj10, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ARKPKSKMNSK" + "'", str19, "ARKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "A621" + "'", obj20, "A621");
    }

    @Test
    public void test0684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0684");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A111111111", "A093138363836931589313836383693158");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test0685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0685");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.metaphone("");
        boolean boolean17 = metaphone0.isMetaphoneEqual("AKPKMNSK11", "");
        boolean boolean20 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKPXKMNSK", "A1");
        boolean boolean23 = metaphone0.isMetaphoneEqual("", "A093153836383693158");
        org.apache.commons.codec.EncoderException encoderException25 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray26 = encoderException25.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException28 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException30 = new org.apache.commons.codec.EncoderException("");
        encoderException28.addSuppressed((java.lang.Throwable) encoderException30);
        encoderException25.addSuppressed((java.lang.Throwable) encoderException30);
        org.apache.commons.codec.EncoderException encoderException34 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        encoderException30.addSuppressed((java.lang.Throwable) encoderException34);
        org.apache.commons.codec.EncoderException encoderException37 = new org.apache.commons.codec.EncoderException("A0");
        encoderException30.addSuppressed((java.lang.Throwable) encoderException37);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = metaphone0.encode((java.lang.Object) encoderException37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertArrayEquals(throwableArray26, new java.lang.Throwable[] {});
    }

    @Test
    public void test0686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0686");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        int int8 = soundex1.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone9 = new org.apache.commons.codec.language.Metaphone();
        metaphone9.setMaxCodeLen(3);
        int int12 = metaphone9.getMaxCodeLen();
        int int13 = metaphone9.getMaxCodeLen();
        metaphone9.setMaxCodeLen((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = soundex1.encode((java.lang.Object) metaphone9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test0687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0687");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("", "A");
        java.lang.String str10 = refinedSoundex0.encode("ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        char char24 = doubleMetaphone11.charAt("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", (int) 'A');
        java.lang.Object obj25 = refinedSoundex0.encode((java.lang.Object) "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        char[] charArray26 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex27 = new org.apache.commons.codec.language.Soundex(charArray26);
        org.apache.commons.codec.language.Soundex soundex28 = new org.apache.commons.codec.language.Soundex(charArray26);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = new org.apache.commons.codec.language.RefinedSoundex(charArray26);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex30 = new org.apache.commons.codec.language.RefinedSoundex(charArray26);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = refinedSoundex0.encode((java.lang.Object) charArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0931" + "'", str10, "O0931");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "O0940103030808306030830609053016080" + "'", obj25, "O0940103030808306030830609053016080");
        org.junit.Assert.assertNotNull(charArray26);
    }

    @Test
    public void test0688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0688");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen(48);
        java.lang.String str6 = metaphone0.metaphone("AK11111111");
        java.lang.Class<?> wildcardClass7 = metaphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "AK" + "'", str6, "AK");
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test0689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0689");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int5 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone6.maxCodeLen = '\000';
        char char11 = doubleMetaphone6.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult13 = doubleMetaphone6.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult13.appendPrimary("");
        doubleMetaphoneResult13.appendPrimary("O620");
        java.lang.Class<?> wildcardClass18 = doubleMetaphoneResult13.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = metaphone0.encode((java.lang.Object) wildcardClass18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '\000' + "'", char11 == '\000');
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0690");
        char[] charArray0 = new char[] {};
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Metaphone metaphone3 = new org.apache.commons.codec.language.Metaphone();
        metaphone3.setMaxCodeLen(3);
        int int6 = metaphone3.getMaxCodeLen();
        java.lang.String str8 = metaphone3.encode("hi!");
        java.lang.String str10 = metaphone3.encode("O621");
        boolean boolean13 = metaphone3.isMetaphoneEqual("A", "A");
        metaphone3.setMaxCodeLen(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = soundex2.encode((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertArrayEquals(charArray0, new char[] {});
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "H" + "'", str8, "H");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test0691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0691");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = '\000';
        char char18 = doubleMetaphone13.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone13.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult20.append("ORK", "O620");
        java.lang.Object obj24 = metaphone0.encode((java.lang.Object) "O620");
        metaphone0.setMaxCodeLen((int) (byte) -1);
        org.apache.commons.codec.EncoderException encoderException28 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException30 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray31 = encoderException30.getSuppressed();
        encoderException28.addSuppressed((java.lang.Throwable) encoderException30);
        org.apache.commons.codec.EncoderException encoderException34 = new org.apache.commons.codec.EncoderException("A ");
        encoderException30.addSuppressed((java.lang.Throwable) encoderException34);
        org.apache.commons.codec.EncoderException encoderException37 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException39 = new org.apache.commons.codec.EncoderException("");
        encoderException37.addSuppressed((java.lang.Throwable) encoderException39);
        org.apache.commons.codec.EncoderException encoderException42 = new org.apache.commons.codec.EncoderException("hi!");
        encoderException39.addSuppressed((java.lang.Throwable) encoderException42);
        encoderException30.addSuppressed((java.lang.Throwable) encoderException42);
        java.lang.Throwable[] throwableArray45 = encoderException30.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj46 = metaphone0.encode((java.lang.Object) encoderException30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "O" + "'", obj24, "O");
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertArrayEquals(throwableArray31, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test0692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0692");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str10 = metaphone0.metaphone("O");
        java.lang.String str12 = metaphone0.encode("O093");
        java.lang.String str14 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test0693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0693");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        int int13 = metaphone0.getMaxCodeLen();
        java.lang.String str15 = metaphone0.encode("AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test0694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0694");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        soundex1.setMaxLength((int) (byte) 100);
        java.lang.String str16 = soundex1.soundex("O0931");
        soundex1.setMaxLength(2);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O000" + "'", str16, "O000");
    }

    @Test
    public void test0695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0695");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            int int8 = refinedSoundex5.difference("ARKPKKMNSKTKNKTRKSPXNRKP", "A111111111O620");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 17 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test0696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0696");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        int int12 = refinedSoundex5.difference(" ", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean22 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone13.maxCodeLen = 3;
        java.lang.String str26 = doubleMetaphone13.doubleMetaphone(" ");
        java.lang.Object obj27 = refinedSoundex5.encode((java.lang.Object) " ");
        java.lang.Class<?> wildcardClass28 = refinedSoundex5.getClass();
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + "" + "'", obj27, "");
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test0697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0697");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        int int14 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = '\000';
        doubleMetaphone15.setMaxCodeLen(4);
        java.lang.String str21 = doubleMetaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) str21);
        java.lang.String str24 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        int int27 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: AK11111111", "AKPKMNSKTK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ARKP" + "'", str21, "ARKP");
        org.junit.Assert.assertEquals("'" + obj22 + "' != '" + "A0931" + "'", obj22, "A0931");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O0940103030808306030830609053016080" + "'", str24, "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test0698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0698");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str15 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str18 = doubleMetaphone16.doubleMetaphone("H");
        doubleMetaphone16.setMaxCodeLen((int) (byte) 0);
        java.lang.String str22 = doubleMetaphone16.encode("H");
        boolean boolean26 = doubleMetaphone16.isDoubleMetaphoneEqual("ORKP", "O0", true);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult28 = doubleMetaphone16.new DoubleMetaphoneResult((int) '#');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = caverphone0.encode((java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKKMNSKT" + "'", str15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test0699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0699");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.encode("A0");
        java.lang.String str36 = caverphone0.caverphone("");
        java.lang.String str38 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean41 = caverphone0.isCaverphoneEqual("", " AKPK");
        boolean boolean44 = caverphone0.isCaverphoneEqual("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN", "A");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "1111111111" + "'", str36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "AKPKKMNSKT" + "'", str38, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test0700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0700");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A ");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) "A ");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A1", "O941");
        java.lang.String str19 = metaphone0.encode("org.apache.commons.codec.EncoderException: A111111111O620");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "A" + "'", obj14, "A");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ORKPXKMNSK" + "'", str19, "ORKPXKMNSK");
    }

    @Test
    public void test0701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0701");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AKPKMNSKTK" + "'", str1, "AKPKMNSKTK");
    }

    @Test
    public void test0702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0702");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        char char15 = refinedSoundex0.getMappingCode('T');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '6' + "'", char15 == '6');
    }

    @Test
    public void test0703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0703");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        int int12 = refinedSoundex5.difference(" ", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean22 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone13.maxCodeLen = 3;
        java.lang.String str26 = doubleMetaphone13.doubleMetaphone(" ");
        java.lang.Object obj27 = refinedSoundex5.encode((java.lang.Object) " ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str29 = refinedSoundex5.encode("ARKPKMNSKTKNKTRKSPKSNRKPKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 17 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + "" + "'", obj27, "");
    }

    @Test
    public void test0704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0704");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str5 = refinedSoundex3.encode("1111111111");
        char char7 = refinedSoundex3.getMappingCode('r');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '6' + "'", char7 == '6');
    }

    @Test
    public void test0705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0705");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = refinedSoundex8.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test0706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0706");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        boolean boolean11 = metaphone0.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        metaphone0.setMaxCodeLen((int) 'A');
        metaphone0.setMaxCodeLen((int) (byte) 10);
        org.apache.commons.codec.language.Metaphone metaphone16 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str18 = metaphone16.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone16.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone21 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str23 = caverphone21.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str25 = caverphone21.caverphone("hi!");
        java.lang.Object obj26 = metaphone16.encode((java.lang.Object) "hi!");
        java.lang.String str28 = metaphone16.encode("");
        int int29 = metaphone16.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = metaphone0.encode((java.lang.Object) metaphone16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORKP" + "'", str18, "ORKP");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "AKPKKMNSKT" + "'", str23, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "AA11111111" + "'", str25, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "H" + "'", obj26, "H");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
    }

    @Test
    public void test0707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0707");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        java.lang.String str11 = soundex1.encode("org.apache.commons.codec.EncoderException: hi!");
        int int14 = soundex1.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "01230120022455012623010202");
        java.lang.String str16 = soundex1.soundex("ORKPXKMNSK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O941" + "'", str11, "O941");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O931" + "'", str16, "O931");
    }

    @Test
    public void test0708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0708");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = 0;
        char char16 = doubleMetaphone11.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone11.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult18.appendAlternate("A111111111");
        java.lang.String str21 = doubleMetaphoneResult18.getAlternate();
        boolean boolean22 = doubleMetaphoneResult18.isComplete();
        java.lang.String str23 = doubleMetaphoneResult18.getAlternate();
        doubleMetaphoneResult18.appendAlternate('O');
        boolean boolean26 = doubleMetaphoneResult18.isComplete();
        doubleMetaphoneResult18.append("AA11111111");
        doubleMetaphoneResult18.append("ARKPKSKMNS");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A111111111" + "'", str21, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A111111111" + "'", str23, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test0709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0709");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        int int12 = refinedSoundex5.difference(" ", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean22 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone13.maxCodeLen = 3;
        java.lang.String str26 = doubleMetaphone13.doubleMetaphone(" ");
        java.lang.Object obj27 = refinedSoundex5.encode((java.lang.Object) " ");
        // The following exception was thrown during execution in test generation
        try {
            int int30 = refinedSoundex5.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "AKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + "" + "'", obj27, "");
    }

    @Test
    public void test0710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0710");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength(10);
        java.lang.String str14 = soundex1.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str16 = soundex1.encode("AA11111111");
        soundex1.setMaxLength((int) (short) 1);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O941" + "'", str14, "O941");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A000" + "'", str16, "A000");
    }

    @Test
    public void test0711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0711");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        java.lang.String str15 = caverphone0.encode("AK");
        char[] charArray16 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray16);
        soundex17.setMaxLength(1);
        int int20 = soundex17.getMaxLength();
        int int23 = soundex17.difference("HI", "");
        java.lang.String str25 = soundex17.soundex("O0940103030808306030830609053016080");
        int int28 = soundex17.difference("A#", "H0");
        int int29 = soundex17.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = caverphone0.encode((java.lang.Object) soundex17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "O000" + "'", str25, "O000");
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test0712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0712");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AKPKMNSK11");
        char[] charArray31 = null;
        org.apache.commons.codec.language.Soundex soundex32 = new org.apache.commons.codec.language.Soundex(charArray31);
        java.lang.String str34 = soundex32.encode("");
        java.lang.String str36 = soundex32.encode("");
        java.lang.String str38 = soundex32.soundex("");
        int int39 = soundex32.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj40 = caverphone0.encode((java.lang.Object) int39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKMNSK11" + "'", str30, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
    }

    @Test
    public void test0713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0713");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("HI");
        metaphone0.setMaxCodeLen(0);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = '\000';
        int int15 = doubleMetaphone12.getMaxCodeLen();
        boolean boolean18 = doubleMetaphone12.isDoubleMetaphoneEqual("A621", "AKPKKMNSKT");
        doubleMetaphone12.maxCodeLen = 35;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = metaphone0.encode((java.lang.Object) doubleMetaphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H" + "'", str9, "H");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test0714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0714");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str15 = caverphone0.encode("ARKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKT1" + "'", str13, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AKPKSKMNSK" + "'", str15, "AKPKSKMNSK");
    }

    @Test
    public void test0715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0715");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex2.setMaxLength((int) '1');
        int int7 = soundex2.difference("A0", "H");
        soundex2.setMaxLength((-1));
        soundex2.setMaxLength(65);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test0716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0716");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str30 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        java.lang.String[] strArray44 = new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" };
        boolean boolean45 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 1, (int) (short) 1, strArray44);
        boolean boolean46 = org.apache.commons.codec.language.DoubleMetaphone.contains("ARKP", (int) (byte) 10, (int) '#', strArray44);
        boolean boolean47 = org.apache.commons.codec.language.DoubleMetaphone.contains("O621", (int) (byte) 0, (int) (short) 10, strArray44);
        boolean boolean48 = org.apache.commons.codec.language.DoubleMetaphone.contains("A621", 3, 10, strArray44);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj49 = caverphone0.encode((java.lang.Object) boolean48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKKMNSKT" + "'", str30, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertArrayEquals(strArray44, new java.lang.String[] { "org.apache.commons.codec.EncoderException: ORKP" });
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test0717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0717");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        int int14 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test0718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0718");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        java.lang.String str5 = refinedSoundex3.soundex("A000");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = refinedSoundex3.encode("AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "A1" + "'", str5, "A1");
    }

    @Test
    public void test0719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0719");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: hi!", "H0");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex11 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char13 = refinedSoundex11.getMappingCode('a');
        int int16 = refinedSoundex11.difference("", "hi!");
        int int19 = refinedSoundex11.difference("hi!", "");
        char char21 = refinedSoundex11.getMappingCode('#');
        java.lang.String str23 = refinedSoundex11.encode("AKPKMNSKT");
        java.lang.String str25 = refinedSoundex11.soundex("H0");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = metaphone0.encode((java.lang.Object) refinedSoundex11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(refinedSoundex11);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A0313836" + "'", str23, "A0313836");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "H0" + "'", str25, "H0");
    }

    @Test
    public void test0720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0720");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        metaphone0.setMaxCodeLen(0);
        int int9 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test0721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0721");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        java.lang.String str8 = metaphone0.metaphone("");
        boolean boolean11 = metaphone0.isMetaphoneEqual("O", "A0");
        boolean boolean14 = metaphone0.isMetaphoneEqual("AKPKMNSKT", "o");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test0722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0722");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        soundex3.setMaxLength((int) (short) 100);
        soundex3.setMaxLength(48);
        org.apache.commons.codec.language.Caverphone caverphone10 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str12 = caverphone10.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str14 = caverphone10.caverphone("hi!");
        java.lang.String str16 = caverphone10.caverphone("");
        java.lang.String str18 = caverphone10.caverphone("HI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = soundex3.encode((java.lang.Object) caverphone10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AA11111111" + "'", str14, "AA11111111");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "1111111111" + "'", str16, "1111111111");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AA11111111" + "'", str18, "AA11111111");
    }

    @Test
    public void test0723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0723");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.encode("ARKPKSKMNSK");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A0931383" + "'", str7, "A0931383");
    }

    @Test
    public void test0724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0724");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        boolean boolean29 = caverphone0.isCaverphoneEqual("", "HI");
        boolean boolean32 = caverphone0.isCaverphoneEqual("O", "ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.String str34 = caverphone0.caverphone("A");
        java.lang.String str36 = caverphone0.encode("A062125232523621256212523252362125");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "A111111111" + "'", str34, "A111111111");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "A111111111" + "'", str36, "A111111111");
    }

    @Test
    public void test0725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0725");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        int int10 = refinedSoundex0.difference("AKPKKMNSKT", "A621");
        java.lang.String str12 = refinedSoundex0.encode("ARKPXKMNSK");
        char char14 = refinedSoundex0.getMappingCode('i');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A09315383" + "'", str12, "A09315383");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '0' + "'", char14 == '0');
    }

    @Test
    public void test0726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0726");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        java.lang.String str6 = refinedSoundex4.soundex("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = refinedSoundex4.encode("A111111111O620");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test0727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0727");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        int int14 = metaphone0.getMaxCodeLen();
        boolean boolean17 = metaphone0.isMetaphoneEqual("AKPKMNSKT", "AKPKMNSKT");
        metaphone0.setMaxCodeLen(0);
        boolean boolean22 = metaphone0.isMetaphoneEqual("AKPK", "");
        java.lang.Object obj23 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = metaphone0.encode(obj23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test0728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0728");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        char char7 = doubleMetaphone0.charAt("hi!", 1);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A621", "H");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = 0;
        char char17 = doubleMetaphone12.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone12.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult19.appendAlternate("A111111111");
        java.lang.String str22 = doubleMetaphoneResult19.getAlternate();
        boolean boolean23 = doubleMetaphoneResult19.isComplete();
        java.lang.String str24 = doubleMetaphoneResult19.getAlternate();
        doubleMetaphoneResult19.appendAlternate('4');
        doubleMetaphoneResult19.appendAlternate('r');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = doubleMetaphone0.encode((java.lang.Object) 'r');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'i' + "'", char7 == 'i');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A111111111" + "'", str22, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A111111111" + "'", str24, "A111111111");
    }

    @Test
    public void test0729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0729");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        org.apache.commons.codec.language.Metaphone metaphone7 = new org.apache.commons.codec.language.Metaphone();
        metaphone7.setMaxCodeLen(3);
        java.lang.String str11 = metaphone7.encode("");
        java.lang.String str13 = metaphone7.encode("");
        metaphone7.setMaxCodeLen((int) (short) 10);
        java.lang.String str17 = metaphone7.encode("O0");
        boolean boolean20 = metaphone7.isMetaphoneEqual("O000", "O620");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = caverphone0.encode((java.lang.Object) metaphone7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O" + "'", str17, "O");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test0730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0730");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int13 = soundex0.difference("AKPKMNSKTK", "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str15 = soundex0.encode("");
        java.lang.String str17 = soundex0.encode("1111111111");
        org.apache.commons.codec.EncoderException encoderException19 = new org.apache.commons.codec.EncoderException("ARKPXKMNSKTKNKTRKSPXN");
        org.apache.commons.codec.EncoderException encoderException21 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray22 = encoderException21.getSuppressed();
        java.lang.Throwable[] throwableArray23 = encoderException21.getSuppressed();
        encoderException19.addSuppressed((java.lang.Throwable) encoderException21);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = soundex0.encode((java.lang.Object) encoderException19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertArrayEquals(throwableArray22, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertArrayEquals(throwableArray23, new java.lang.Throwable[] {});
    }

    @Test
    public void test0731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0731");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        java.lang.String str14 = caverphone0.encode("AKPKKMNSKT");
        boolean boolean17 = caverphone0.isCaverphoneEqual("O941", "");
        java.lang.String str19 = caverphone0.encode("O");
        java.lang.String str21 = caverphone0.encode(" AKP1111111 ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKT1" + "'", str14, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "A111111111" + "'", str19, "A111111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKP1111111" + "'", str21, "AKP1111111");
    }

    @Test
    public void test0732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0732");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.encode("ORK");
        char char11 = refinedSoundex0.getMappingCode('a');
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        metaphone12.setMaxCodeLen(3);
        java.lang.String str16 = metaphone12.encode("");
        java.lang.String str18 = metaphone12.encode("");
        metaphone12.setMaxCodeLen((int) (short) 10);
        java.lang.String str22 = metaphone12.encode("O0");
        java.lang.String str24 = metaphone12.encode("ARKPXKMNSKTKNKTRKSPXN");
        java.lang.String str26 = metaphone12.encode("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = refinedSoundex0.encode((java.lang.Object) metaphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O093" + "'", str9, "O093");
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '0' + "'", char11 == '0');
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O" + "'", str22, "O");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ARKPKSKMNS" + "'", str24, "ARKPKSKMNS");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "ORKPXKMNSK" + "'", str26, "ORKPXKMNSK");
    }

    @Test
    public void test0733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0733");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode(' ');
        char char9 = refinedSoundex0.getMappingCode('o');
        java.lang.String str11 = refinedSoundex0.soundex("");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
    }

    @Test
    public void test0734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0734");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        boolean boolean17 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("AK11111111", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean24 = doubleMetaphone0.isDoubleMetaphoneEqual("O0", "", false);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "  ");
        doubleMetaphone0.maxCodeLen = 0;
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone30 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone30.maxCodeLen = '\000';
        doubleMetaphone30.setMaxCodeLen(4);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult36 = doubleMetaphone30.new DoubleMetaphoneResult((int) '1');
        java.lang.String str37 = doubleMetaphoneResult36.getPrimary();
        doubleMetaphoneResult36.appendPrimary("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        java.lang.String str40 = doubleMetaphoneResult36.getPrimary();
        doubleMetaphoneResult36.appendAlternate("H0");
        doubleMetaphoneResult36.appendAlternate('6');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj45 = doubleMetaphone0.encode((java.lang.Object) '6');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "org.apache.commons.codec.EncoderException: org.ap" + "'", str40, "org.apache.commons.codec.EncoderException: org.ap");
    }

    @Test
    public void test0735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0735");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        boolean boolean16 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "H");
        java.lang.String str18 = metaphone0.encode("A093138363836931589313836383693158");
        int int19 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test0736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0736");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = refinedSoundex3.difference("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK", "1111111111");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 17 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
    }

    @Test
    public void test0737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0737");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK", "ORGAPACHECOMMONSCODECENCODEREXCEPTION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test0738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0738");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("K111111111", "A ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0739");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = refinedSoundex7.encode("O620");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0740");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0");
        org.apache.commons.codec.language.Metaphone metaphone29 = new org.apache.commons.codec.language.Metaphone();
        metaphone29.setMaxCodeLen(3);
        java.lang.String str33 = metaphone29.encode("");
        java.lang.String str35 = metaphone29.encode("");
        metaphone29.setMaxCodeLen((int) (byte) 1);
        metaphone29.setMaxCodeLen((int) (short) 0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj40 = caverphone0.encode((java.lang.Object) metaphone29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
    }

    @Test
    public void test0741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0741");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str7 = metaphone0.encode("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test0742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0742");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = soundex10.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test0743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0743");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean12 = metaphone0.isMetaphoneEqual("A621", "");
        boolean boolean15 = metaphone0.isMetaphoneEqual("AKPKKMNSKT", "A111111111");
        java.lang.String str17 = metaphone0.metaphone("");
        java.lang.Class<?> wildcardClass18 = metaphone0.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test0744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0744");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("H", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0745");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A09");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0746");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.soundex("A0313836");
        int int11 = soundex0.getMaxLength();
        int int12 = soundex0.getMaxLength();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test0747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0747");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = '\000';
        boolean boolean5 = doubleMetaphone0.isDoubleMetaphoneEqual("ORKP", "H");
        doubleMetaphone0.maxCodeLen = 0;
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char10 = refinedSoundex8.getMappingCode('a');
        int int13 = refinedSoundex8.difference("", "hi!");
        char char15 = refinedSoundex8.getMappingCode('0');
        char char17 = refinedSoundex8.getMappingCode('a');
        java.lang.String str19 = refinedSoundex8.soundex("1111111111");
        int int22 = refinedSoundex8.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone23 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone23.maxCodeLen = '\000';
        doubleMetaphone23.setMaxCodeLen(4);
        java.lang.String str29 = doubleMetaphone23.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj30 = refinedSoundex8.encode((java.lang.Object) str29);
        java.lang.Object obj31 = doubleMetaphone0.encode((java.lang.Object) str29);
        int int32 = doubleMetaphone0.maxCodeLen;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(refinedSoundex8);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '0' + "'", char10 == '0');
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '0' + "'", char17 == '0');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ARKP" + "'", str29, "ARKP");
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + "A0931" + "'", obj30, "A0931");
        org.junit.Assert.assertEquals("'" + obj31 + "' != '" + "" + "'", obj31, "");
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test0748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0748");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        int int4 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 10);
        metaphone0.setMaxCodeLen(0);
        java.lang.String str10 = metaphone0.encode("AR");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test0749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0749");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            int int8 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "ORK", "H0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0750");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) '4');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone18.maxCodeLen = '\000';
        char char23 = doubleMetaphone18.charAt("", 0);
        java.lang.String str25 = doubleMetaphone18.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str27 = doubleMetaphone18.doubleMetaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        doubleMetaphone18.setMaxCodeLen((int) (short) -1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = metaphone0.encode((java.lang.Object) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '\000' + "'", char23 == '\000');
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
    }

    @Test
    public void test0751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0751");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        java.lang.String str9 = soundex1.soundex("");
        int int10 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = soundex1.encode("o");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test0752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0752");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        int int9 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test0753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0753");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        java.lang.String str13 = refinedSoundex0.soundex("O");
        int int16 = refinedSoundex0.difference(" ", "O620");
        int int19 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: HI", "");
        char char21 = refinedSoundex0.getMappingCode('A');
        int int24 = refinedSoundex0.difference("AKPKSKMNSK", "org.apache.commons.codec.EncoderException: O620");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '0' + "'", char21 == '0');
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test0754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0754");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        java.lang.String str9 = soundex1.encode("01230120022455012623010202");
        soundex1.setMaxLength((int) '1');
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex12 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char14 = refinedSoundex12.getMappingCode('a');
        int int17 = refinedSoundex12.difference("", "hi!");
        char char19 = refinedSoundex12.getMappingCode('#');
        int int22 = refinedSoundex12.difference("AKPKKMNSKT", "A621");
        char char24 = refinedSoundex12.getMappingCode('\000');
        java.lang.String str26 = refinedSoundex12.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj27 = soundex1.encode((java.lang.Object) str26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertNotNull(refinedSoundex12);
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '0' + "'", char14 == '0');
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "O0940103030808306030830609053016080" + "'", str26, "O0940103030808306030830609053016080");
    }

    @Test
    public void test0755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0755");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone0.maxCodeLen = 0;
        char char5 = doubleMetaphone0.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str7 = doubleMetaphone0.encode("A");
        java.lang.Object obj9 = doubleMetaphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone0.maxCodeLen = (byte) 1;
        boolean boolean14 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " org.apache.commons.codec.EncoderException: ORGAP");
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\000' + "'", char5 == '\000');
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test0756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0756");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("");
        int int8 = soundex0.getMaxLength();
        java.lang.Class<?> wildcardClass9 = soundex0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test0757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0757");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean11 = metaphone0.isMetaphoneEqual("O0931", "org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str13 = metaphone0.encode("H0");
        java.lang.String str15 = metaphone0.encode("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test0758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0758");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.metaphone("O000");
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) "O000");
        java.lang.String str22 = caverphone0.caverphone("O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "A111111111" + "'", obj20, "A111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A111111111" + "'", str22, "A111111111");
    }

    @Test
    public void test0759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0759");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str14 = doubleMetaphone12.doubleMetaphone("H");
        java.lang.String str16 = doubleMetaphone12.doubleMetaphone("");
        java.lang.String str19 = doubleMetaphone12.doubleMetaphone("ORKP", true);
        java.lang.String str22 = doubleMetaphone12.doubleMetaphone("", false);
        java.lang.String str24 = doubleMetaphone12.doubleMetaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str27 = doubleMetaphone12.doubleMetaphone("ORK", false);
        char char30 = doubleMetaphone12.charAt("A111111111", 48);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = caverphone0.encode((java.lang.Object) char30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ARKP" + "'", str19, "ARKP");
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ARKP" + "'", str24, "ARKP");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "ARK" + "'", str27, "ARK");
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + '\000' + "'", char30 == '\000');
    }

    @Test
    public void test0760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0760");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        boolean boolean17 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("AK11111111", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean24 = doubleMetaphone0.isDoubleMetaphoneEqual("O0", "", false);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "  ");
        java.lang.String str29 = doubleMetaphone0.encode("");
        java.lang.String str31 = doubleMetaphone0.doubleMetaphone("org.apache.commons.codec.EncoderException: A093153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "ARKPXKMNSK" + "'", str31, "ARKPXKMNSK");
    }

    @Test
    public void test0761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0761");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        int int9 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test0762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0762");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str6 = refinedSoundex0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        char char8 = refinedSoundex0.getMappingCode('a');
        char char10 = refinedSoundex0.getMappingCode('r');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080" + "'", str4, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "O0" + "'", str6, "O0");
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '0' + "'", char8 == '0');
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '9' + "'", char10 == '9');
    }

    @Test
    public void test0763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0763");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean12 = metaphone0.isMetaphoneEqual("A621", "");
        java.lang.String str14 = metaphone0.metaphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str16 = metaphone0.metaphone("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "ORK" + "'", str14, "ORK");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
    }

    @Test
    public void test0764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0764");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("ORKPXKMNSKTKNKTRKSSPXNRKP");
        java.lang.String str6 = caverphone0.caverphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKMNSKTK" + "'", str4, "AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
    }

    @Test
    public void test0765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0765");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPXKMNSKTSNKTRKSPXN", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0766");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        boolean boolean17 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("AK11111111", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean24 = doubleMetaphone0.isDoubleMetaphoneEqual("O0", "", false);
        int int27 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O620", "  ");
        java.lang.String str29 = doubleMetaphone0.encode("");
        java.lang.String str31 = doubleMetaphone0.encode("AO");
        char[] charArray33 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex34 = new org.apache.commons.codec.language.RefinedSoundex(charArray33);
        org.apache.commons.codec.language.Soundex soundex35 = new org.apache.commons.codec.language.Soundex(charArray33);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex36 = new org.apache.commons.codec.language.RefinedSoundex(charArray33);
        char char38 = refinedSoundex36.getMappingCode('a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = doubleMetaphone0.encode((java.lang.Object) char38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "A" + "'", str31, "A");
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertArrayEquals(charArray33, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + char38 + "' != '" + 'a' + "'", char38 == 'a');
    }

    @Test
    public void test0767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0767");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char15 = refinedSoundex13.getMappingCode('a');
        int int18 = refinedSoundex13.difference("", "hi!");
        char char20 = refinedSoundex13.getMappingCode(' ');
        java.lang.String str22 = refinedSoundex13.encode("O000");
        java.lang.Object obj23 = caverphone0.encode((java.lang.Object) str22);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex13);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '0' + "'", char15 == '0');
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O0" + "'", str22, "O0");
        org.junit.Assert.assertEquals("'" + obj23 + "' != '" + "A111111111" + "'", obj23, "A111111111");
    }

    @Test
    public void test0768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0768");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str17 = refinedSoundex0.soundex("O621");
        java.lang.String str19 = refinedSoundex0.soundex("O0");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0940103030808306030830609053016080931" + "'", str15, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0" + "'", str17, "O0");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O0" + "'", str19, "O0");
    }

    @Test
    public void test0769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0769");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.soundex("");
        java.lang.String str8 = refinedSoundex4.encode(" ");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test0770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0770");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int9 = refinedSoundex6.difference("ARKPKSKMNSK", "O09315383638369315893153836383693158931");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test0771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0771");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        boolean boolean22 = caverphone0.isCaverphoneEqual("A#", "AKP1111111");
        java.lang.String str24 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: O0");
        boolean boolean27 = caverphone0.isCaverphoneEqual("O0940103030808306030830609053016080940103030808306030830609053016080931", "ORKPXKMNSKTKNKTRKSSPXN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test0772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0772");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str10 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.ap");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        doubleMetaphone11.setMaxCodeLen((int) (byte) 0);
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone11.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult20.append('#');
        doubleMetaphoneResult20.appendAlternate('r');
        boolean boolean25 = doubleMetaphoneResult20.isComplete();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = caverphone0.encode((java.lang.Object) boolean25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test0773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0773");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        int int3 = soundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: O620");
        int int4 = soundex0.getMaxLength();
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
// flaky "1) test0773(org.apache.commons.codec.language.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test0774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0774");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        boolean boolean31 = caverphone0.isCaverphoneEqual("A09", "AK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AKPKKMNSKT" + "'", str28, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test0775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0775");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.encode("O0");
        metaphone0.setMaxCodeLen((int) '5');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "O" + "'", str22, "O");
    }

    @Test
    public void test0776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0776");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int8 = soundex5.difference("O093", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test0777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0777");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("A621");
        java.lang.String str13 = refinedSoundex0.encode("O000");
        java.lang.String str15 = refinedSoundex0.encode("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = refinedSoundex0.encode((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A0" + "'", str11, "A0");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test0778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0778");
        char[] charArray2 = new char[] { '1', 'a' };
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        int int5 = soundex4.getMaxLength();
        java.lang.String str7 = soundex4.encode("A621");
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', 'a' });
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
    }

    @Test
    public void test0779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0779");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str15 = caverphone0.encode("ORK");
        java.lang.String str17 = caverphone0.caverphone("");
        java.lang.String str19 = caverphone0.encode("1111111111");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AK11111111" + "'", str15, "AK11111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "1111111111" + "'", str19, "1111111111");
    }

    @Test
    public void test0780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0780");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean11 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " ");
        java.lang.String str13 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        boolean boolean16 = caverphone0.isCaverphoneEqual("hi!", "ORKP");
        java.lang.String str18 = caverphone0.encode("AKPKMNSKT1");
        org.apache.commons.codec.EncoderException encoderException20 = new org.apache.commons.codec.EncoderException("AK11111111");
        org.apache.commons.codec.EncoderException encoderException22 = new org.apache.commons.codec.EncoderException("A ");
        org.apache.commons.codec.EncoderException encoderException24 = new org.apache.commons.codec.EncoderException("A0");
        java.lang.Throwable[] throwableArray25 = encoderException24.getSuppressed();
        encoderException22.addSuppressed((java.lang.Throwable) encoderException24);
        org.apache.commons.codec.EncoderException encoderException28 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException30 = new org.apache.commons.codec.EncoderException("");
        encoderException28.addSuppressed((java.lang.Throwable) encoderException30);
        org.apache.commons.codec.EncoderException encoderException33 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException35 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray36 = encoderException35.getSuppressed();
        encoderException33.addSuppressed((java.lang.Throwable) encoderException35);
        org.apache.commons.codec.EncoderException encoderException39 = new org.apache.commons.codec.EncoderException("A ");
        encoderException35.addSuppressed((java.lang.Throwable) encoderException39);
        encoderException30.addSuppressed((java.lang.Throwable) encoderException39);
        org.apache.commons.codec.EncoderException encoderException43 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        encoderException39.addSuppressed((java.lang.Throwable) encoderException43);
        encoderException22.addSuppressed((java.lang.Throwable) encoderException43);
        encoderException20.addSuppressed((java.lang.Throwable) encoderException22);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj47 = caverphone0.encode((java.lang.Object) encoderException22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "AKPKMNSKT1" + "'", str18, "AKPKMNSKT1");
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertArrayEquals(throwableArray25, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertArrayEquals(throwableArray36, new java.lang.Throwable[] {});
    }

    @Test
    public void test0781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0781");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        java.lang.String str15 = metaphone0.metaphone("A000");
        java.lang.String str17 = metaphone0.metaphone("ORKPXKMNSKTKNKTRKSSPXN");
        java.lang.String str19 = metaphone0.metaphone("K120");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
    }

    @Test
    public void test0782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0782");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        java.lang.String str5 = soundex1.encode("");
        java.lang.String str7 = soundex1.soundex("");
        java.lang.String str9 = soundex1.encode("01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = soundex1.soundex("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
    }

    @Test
    public void test0783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0783");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A09313836383693158931");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0784");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char12 = refinedSoundex10.getMappingCode('a');
        int int15 = refinedSoundex10.difference("", "hi!");
        int int18 = refinedSoundex10.difference("hi!", "");
        java.lang.Object obj19 = caverphone0.encode((java.lang.Object) "hi!");
        java.lang.String str21 = caverphone0.caverphone("AO");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(refinedSoundex10);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "AA11111111" + "'", obj19, "AA11111111");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AA11111111" + "'", str21, "AA11111111");
    }

    @Test
    public void test0785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0785");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.encode("AA");
        java.lang.String str9 = soundex0.encode("o");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A000" + "'", str7, "A000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
    }

    @Test
    public void test0786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0786");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        java.lang.String str15 = metaphone0.metaphone("A000");
        metaphone0.setMaxCodeLen(48);
        boolean boolean20 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN", "org.apache.commons.codec.EncoderException: O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test0787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0787");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        char char6 = refinedSoundex4.getMappingCode('a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = refinedSoundex4.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + 'a' + "'", char6 == 'a');
    }

    @Test
    public void test0788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0788");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str7 = soundex2.encode("AKPKKMNSKT");
        java.lang.String str9 = soundex2.encode("O");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A313" + "'", str7, "A313");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
    }

    @Test
    public void test0789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0789");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char20 = refinedSoundex18.getMappingCode('a');
        int int23 = refinedSoundex18.difference("", "hi!");
        char char25 = refinedSoundex18.getMappingCode('0');
        char char27 = refinedSoundex18.getMappingCode('a');
        java.lang.String str29 = refinedSoundex18.soundex("1111111111");
        int int32 = refinedSoundex18.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone33 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone33.maxCodeLen = '\000';
        doubleMetaphone33.setMaxCodeLen(4);
        java.lang.String str39 = doubleMetaphone33.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj40 = refinedSoundex18.encode((java.lang.Object) str39);
        java.lang.String str42 = refinedSoundex18.soundex("A0313836");
        java.lang.Object obj43 = caverphone0.encode((java.lang.Object) "A0313836");
        java.lang.String str45 = caverphone0.encode("01230120022455012623010202");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertNotNull(refinedSoundex18);
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '0' + "'", char20 == '0');
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '\000' + "'", char25 == '\000');
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '0' + "'", char27 == '0');
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 35 + "'", int32 == 35);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "ARKP" + "'", str39, "ARKP");
        org.junit.Assert.assertEquals("'" + obj40 + "' != '" + "A0931" + "'", obj40, "A0931");
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "A0" + "'", str42, "A0");
        org.junit.Assert.assertEquals("'" + obj43 + "' != '" + "A111111111" + "'", obj43, "A111111111");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "1111111111" + "'", str45, "1111111111");
    }

    @Test
    public void test0790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0790");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        int int9 = soundex3.difference("A111111111", "01230120022455012623010202");
        int int10 = soundex3.getMaxLength();
        soundex3.setMaxLength((int) (short) 100);
        // The following exception was thrown during execution in test generation
        try {
            int int15 = soundex3.difference("ORKPXKMNSK", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test0791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0791");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: hi!", "H0");
        java.lang.String str12 = metaphone0.metaphone("i0a");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) "HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex15 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char17 = refinedSoundex15.getMappingCode('a');
        int int20 = refinedSoundex15.difference("", "hi!");
        char char22 = refinedSoundex15.getMappingCode('0');
        char char24 = refinedSoundex15.getMappingCode('a');
        java.lang.String str26 = refinedSoundex15.soundex("1111111111");
        int int29 = refinedSoundex15.difference("org.apache.commons.codec.EncoderException: ORKP", "org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone30 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone30.maxCodeLen = '\000';
        doubleMetaphone30.setMaxCodeLen(4);
        java.lang.String str36 = doubleMetaphone30.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.Object obj37 = refinedSoundex15.encode((java.lang.Object) str36);
        java.lang.String str39 = refinedSoundex15.soundex("A0313836");
        int int42 = refinedSoundex15.difference("O0940103030808306030830609053016080", "A1111111114r");
        int int45 = refinedSoundex15.difference("", "A111111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj46 = metaphone0.encode((java.lang.Object) int45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "I" + "'", str12, "I");
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "H" + "'", obj14, "H");
        org.junit.Assert.assertNotNull(refinedSoundex15);
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '0' + "'", char17 == '0');
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '0' + "'", char24 == '0');
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 35 + "'", int29 == 35);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "ARKP" + "'", str36, "ARKP");
        org.junit.Assert.assertEquals("'" + obj37 + "' != '" + "A0931" + "'", obj37, "A0931");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "A0" + "'", str39, "A0");
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test0792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0792");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int13 = soundex0.difference("AKPKMNSKTK", "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str15 = soundex0.encode("");
        java.lang.String str17 = soundex0.encode("A621");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A000" + "'", str17, "A000");
    }

    @Test
    public void test0793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0793");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('a');
        java.lang.String str9 = refinedSoundex0.soundex("O0931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O0" + "'", str9, "O0");
    }

    @Test
    public void test0794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0794");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        java.lang.String str14 = metaphone0.encode("ORKP");
        metaphone0.setMaxCodeLen((int) (byte) 10);
        java.lang.String str18 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: A0");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone19 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone19.maxCodeLen = 0;
        char char24 = doubleMetaphone19.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean28 = doubleMetaphone19.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone19.maxCodeLen = 3;
        boolean boolean34 = doubleMetaphone19.isDoubleMetaphoneEqual("H0", "1111111111", false);
        int int35 = doubleMetaphone19.getMaxCodeLen();
        boolean boolean39 = doubleMetaphone19.isDoubleMetaphoneEqual("O0940103030808306030830609053016080940103030808306030830609053016080", "ARKPXKMNSKTKNKTRKSPXN", true);
        java.lang.String str41 = doubleMetaphone19.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO");
        java.lang.Object obj42 = metaphone0.encode((java.lang.Object) str41);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORKPXKMNSK" + "'", str18, "ORKPXKMNSK");
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "ARK" + "'", str41, "ARK");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "ARK" + "'", obj42, "ARK");
    }

    @Test
    public void test0795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0795");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str12 = doubleMetaphone10.doubleMetaphone("H");
        doubleMetaphone10.setMaxCodeLen((int) (byte) 0);
        java.lang.String str17 = doubleMetaphone10.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult19 = doubleMetaphone10.new DoubleMetaphoneResult(0);
        java.lang.String str20 = doubleMetaphoneResult19.getAlternate();
        doubleMetaphoneResult19.append('\000');
        doubleMetaphoneResult19.append('#', '#');
        java.lang.String str26 = doubleMetaphoneResult19.getPrimary();
        java.lang.String str27 = doubleMetaphoneResult19.getAlternate();
        doubleMetaphoneResult19.append("org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str30 = doubleMetaphoneResult19.getAlternate();
        doubleMetaphoneResult19.append('1');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
    }

    @Test
    public void test0796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0796");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: hi!", "AKP");
        soundex1.setMaxLength((int) '#');
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) soundex1, "A621", "AKPK");
        org.apache.commons.codec.language.Caverphone caverphone11 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str13 = caverphone11.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str15 = caverphone11.caverphone("hi!");
        java.lang.String str17 = caverphone11.caverphone("");
        java.lang.String str19 = caverphone11.caverphone("HI");
        boolean boolean22 = caverphone11.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str24 = caverphone11.caverphone("");
        java.lang.Object obj25 = soundex1.encode((java.lang.Object) str24);
        java.lang.String str27 = soundex1.soundex("org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AA11111111" + "'", str15, "AA11111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1111111111" + "'", str17, "1111111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AA11111111" + "'", str19, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "1111111111" + "'", str24, "1111111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "" + "'", obj25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "O621" + "'", str27, "O621");
    }

    @Test
    public void test0797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0797");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str17 = refinedSoundex0.soundex("O621");
        java.lang.Object obj18 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = refinedSoundex0.encode(obj18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0940103030808306030830609053016080931" + "'", str15, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O0" + "'", str17, "O0");
    }

    @Test
    public void test0798() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0798");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        char char12 = refinedSoundex0.getMappingCode('a');
        java.lang.String str14 = refinedSoundex0.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str16 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        java.lang.String str18 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: ARK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O0940103030808306030830609053016080931" + "'", str14, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "O09401030308083060308306090530160809315383" + "'", str16, "O09401030308083060308306090530160809315383");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O094010303080830603083060905301608093" + "'", str18, "O094010303080830603083060905301608093");
    }

    @Test
    public void test0799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0799");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("I", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0800() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0800");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        java.lang.String str10 = refinedSoundex8.soundex("A");
        // The following exception was thrown during execution in test generation
        try {
            int int13 = refinedSoundex8.difference("AKPKMNSKTK", "org.apache.commons.codec.EncoderException: org.ap");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "Aa" + "'", str10, "Aa");
    }

    @Test
    public void test0801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0801");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        java.lang.String str6 = metaphone0.metaphone("A1");
        int int7 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test0802() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0802");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0803");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        int int3 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test0804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0804");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char3 = refinedSoundex1.getMappingCode('a');
        int int6 = refinedSoundex1.difference("", "hi!");
        char char8 = refinedSoundex1.getMappingCode('#');
        java.lang.String str10 = refinedSoundex1.soundex("01230120022455012623010202");
        java.lang.String str12 = refinedSoundex1.encode("A621");
        java.lang.Object obj13 = caverphone0.encode((java.lang.Object) str12);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = caverphone0.encode((java.lang.Object) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex1);
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '0' + "'", char3 == '0');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\000' + "'", char8 == '\000');
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0" + "'", str12, "A0");
        org.junit.Assert.assertEquals("'" + obj13 + "' != '" + "A111111111" + "'", obj13, "A111111111");
    }

    @Test
    public void test0805() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0805");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("1111111111", "AKPKSKMNS1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0806");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("ARKP");
        java.lang.String str13 = caverphone0.caverphone("AKPKMNSKT");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str16 = doubleMetaphone14.doubleMetaphone("H");
        doubleMetaphone14.setMaxCodeLen((int) (byte) 0);
        java.lang.String str21 = doubleMetaphone14.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult23 = doubleMetaphone14.new DoubleMetaphoneResult(0);
        int int24 = doubleMetaphone14.maxCodeLen;
        java.lang.String str26 = doubleMetaphone14.encode("");
        doubleMetaphone14.maxCodeLen = 'i';
        java.lang.String str31 = doubleMetaphone14.doubleMetaphone("", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj32 = caverphone0.encode((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "AKP1111111" + "'", str11, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKMNSKT1" + "'", str13, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test0807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0807");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        int int16 = refinedSoundex0.difference("AA11111111", "01230120022455012623010202");
        int int19 = refinedSoundex0.difference("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN", "A");
        int int22 = refinedSoundex0.difference("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN", "AKPKMNSK");
        int int25 = refinedSoundex0.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "i4org.apache.commons.codec.EncoderException: A000");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 34 + "'", int25 == 34);
    }

    @Test
    public void test0808() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0808");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str30 = caverphone0.caverphone("A0931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AKPKKMNSKT" + "'", str28, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "A111111111" + "'", str30, "A111111111");
    }

    @Test
    public void test0809() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0809");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.Class<?> wildcardClass7 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test0810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0810");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        int int3 = soundex0.difference("H", "");
        int int4 = soundex0.getMaxLength();
        int int5 = soundex0.getMaxLength();
        java.lang.String str7 = soundex0.soundex("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
// flaky "2) test0810(org.apache.commons.codec.language.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
// flaky "1) test0810(org.apache.commons.codec.language.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O621" + "'", str7, "O621");
    }

    @Test
    public void test0811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0811");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        soundex1.setMaxLength((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            int int8 = soundex1.difference("org.apache.commons.codec.EncoderExc", "O941");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0812() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0812");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        char char11 = refinedSoundex5.getMappingCode('1');
        char[] charArray12 = null;
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray12);
        java.lang.String str15 = soundex13.soundex("");
        java.lang.Class<?> wildcardClass16 = soundex13.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = refinedSoundex5.encode((java.lang.Object) soundex13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '\000' + "'", char11 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test0813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0813");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.encode("H");
        boolean boolean16 = caverphone0.isCaverphoneEqual("A111111111O620", "hi!");
        java.lang.String str18 = caverphone0.caverphone("O062010202050520302052030602013050");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A111111111" + "'", str18, "A111111111");
    }

    @Test
    public void test0814() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0814");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str7 = refinedSoundex5.soundex("01230120022455012623010202");
        java.lang.String str9 = refinedSoundex5.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str11 = refinedSoundex5.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        char char13 = refinedSoundex5.getMappingCode('0');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = refinedSoundex4.encode((java.lang.Object) char13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O0940103030808306030830609053016080" + "'", str9, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
    }

    @Test
    public void test0815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0815");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A111111111O620", "A093138363836931589313836383693158");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test0816() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0816");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = refinedSoundex6.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0817");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O931");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0818");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('i');
        int int16 = refinedSoundex0.difference("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone17.maxCodeLen = 0;
        char char22 = doubleMetaphone17.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean26 = doubleMetaphone17.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char29 = doubleMetaphone17.charAt("01230120022455012623010202", (int) (short) 1);
        char char32 = doubleMetaphone17.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone17.maxCodeLen = (byte) 10;
        boolean boolean37 = doubleMetaphone17.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0940103030808306030830609053016080");
        int int38 = doubleMetaphone17.getMaxCodeLen();
        java.lang.String str40 = doubleMetaphone17.encode("org.apache.commons.codec.EncoderException: HI");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj41 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '\000' + "'", char22 == '\000');
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '1' + "'", char29 == '1');
        org.junit.Assert.assertTrue("'" + char32 + "' != '" + 'O' + "'", char32 == 'O');
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "ARKPXKMNSK" + "'", str40, "ARKPXKMNSK");
    }

    @Test
    public void test0819() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0819");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
    }

    @Test
    public void test0820() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0820");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        java.lang.String str6 = metaphone0.metaphone("A1");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str11 = soundex9.encode("ARKP");
        java.lang.String str13 = soundex9.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int14 = soundex9.getMaxLength();
        soundex9.setMaxLength(0);
        soundex9.setMaxLength((int) '#');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = metaphone0.encode((java.lang.Object) soundex9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A621" + "'", str11, "A621");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O621" + "'", str13, "O621");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test0821() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0821");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "AKPKKMNSKT", "A");
        boolean boolean12 = metaphone0.isMetaphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI", "AKPK");
        boolean boolean15 = metaphone0.isMetaphoneEqual(" org.apache.commons.codec.EncoderException: ORGAP", "A111111111O000");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test0822() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0822");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        int int7 = soundex0.getMaxLength();
        int int8 = soundex0.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone9 = new org.apache.commons.codec.language.Metaphone();
        metaphone9.setMaxCodeLen(3);
        int int12 = metaphone9.getMaxCodeLen();
        boolean boolean15 = metaphone9.isMetaphoneEqual("", "");
        boolean boolean18 = metaphone9.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone9.setMaxCodeLen(0);
        int int21 = metaphone9.getMaxCodeLen();
        metaphone9.setMaxCodeLen((int) (short) 100);
        java.lang.String str25 = metaphone9.encode("ARKP");
        java.lang.String str27 = metaphone9.encode("");
        java.lang.String str29 = metaphone9.encode("H");
        java.lang.String str31 = metaphone9.metaphone("AKPKMNSKT1");
        metaphone9.setMaxCodeLen((int) 'r');
        int int34 = metaphone9.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj35 = soundex0.encode((java.lang.Object) int34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "ARKP" + "'", str25, "ARKP");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "H" + "'", str29, "H");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AKPKMNSKT" + "'", str31, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 114 + "'", int34 == 114);
    }

    @Test
    public void test0823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0823");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: AK11111111", "A0313");
        int int8 = soundex1.difference("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test0824() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0824");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("A621");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone5 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone5.maxCodeLen = 0;
        char char10 = doubleMetaphone5.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult12 = doubleMetaphone5.new DoubleMetaphoneResult((int) (short) 0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = soundex0.encode((java.lang.Object) doubleMetaphone5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A000" + "'", str4, "A000");
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
    }

    @Test
    public void test0825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0825");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str8 = soundex6.soundex("ORGAPACHECOMMONSCODECENCODEREXCEPTIONAKPKKMNSKT");
        java.lang.String str10 = soundex6.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "O621" + "'", str8, "O621");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test0826() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0826");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        java.lang.String str9 = metaphone0.encode("O0931");
        java.lang.String str11 = metaphone0.encode("4");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "4" + "'", str11, "4");
    }

    @Test
    public void test0827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0827");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str14 = refinedSoundex0.soundex("H0");
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "ORGAPACHECOMMONSCODECENCODEREXCEPTION", "O0940103030808306030830609053016080931");
        int int20 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ARK", "org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "H0" + "'", str14, "H0");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
    }

    @Test
    public void test0828() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0828");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        boolean boolean13 = caverphone0.isCaverphoneEqual("", "ARKPXKMNSKTKNKTRKSPXN");
        java.lang.Object obj15 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        java.lang.String str17 = caverphone0.caverphone("Aa");
        java.lang.String str19 = caverphone0.caverphone("0123012002245501262301020201230120022455012623010");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + obj15 + "' != '" + "AKPKKMNSKT" + "'", obj15, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "1111111111" + "'", str19, "1111111111");
    }

    @Test
    public void test0829() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0829");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char[] charArray8 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex9 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex10 = new org.apache.commons.codec.language.RefinedSoundex(charArray8);
        org.apache.commons.codec.language.Soundex soundex11 = new org.apache.commons.codec.language.Soundex(charArray8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = refinedSoundex0.encode((java.lang.Object) charArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertArrayEquals(charArray8, new char[] { '1', ' ' });
    }

    @Test
    public void test0830() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0830");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("O062010202050520302052030602013050");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "O000" + "'", str3, "O000");
    }

    @Test
    public void test0831() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0831");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        char char7 = refinedSoundex5.getMappingCode('a');
        // The following exception was thrown during execution in test generation
        try {
            int int10 = refinedSoundex5.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONO", "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTKNKTRKSSPXN");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 14 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'a' + "'", char7 == 'a');
    }

    @Test
    public void test0832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0832");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("HI");
        java.lang.String str6 = doubleMetaphone0.encode("O621");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA", "KPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "H" + "'", str4, "H");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test0833() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0833");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray2);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex5.soundex("ORKPXKMNSKTSNKTRKSSPXNKPKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
    }

    @Test
    public void test0834() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0834");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        java.lang.String str8 = metaphone0.metaphone("");
        metaphone0.setMaxCodeLen((int) 'i');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test0835() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0835");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A000");
        boolean boolean9 = caverphone0.isCaverphoneEqual("A111111111O000", "A1");
        java.lang.Object obj10 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = caverphone0.encode(obj10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test0836() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0836");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('i');
        java.lang.String str9 = refinedSoundex0.encode("H");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H0" + "'", str9, "H0");
    }

    @Test
    public void test0837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0837");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.metaphone("O000");
        java.lang.Object obj20 = caverphone0.encode((java.lang.Object) "O000");
        java.lang.String str22 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        char[] charArray23 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex24 = new org.apache.commons.codec.language.Soundex(charArray23);
        org.apache.commons.codec.language.Soundex soundex25 = new org.apache.commons.codec.language.Soundex(charArray23);
        org.apache.commons.codec.language.Soundex soundex26 = new org.apache.commons.codec.language.Soundex(charArray23);
        int int29 = soundex26.difference("org.apache.commons.codec.EncoderException: O0", "");
        int int30 = soundex26.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = caverphone0.encode((java.lang.Object) soundex26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertEquals("'" + obj20 + "' != '" + "A111111111" + "'", obj20, "A111111111");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
    }

    @Test
    public void test0838() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0838");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("H", "A");
        char char13 = refinedSoundex0.getMappingCode('a');
        char[] charArray14 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex15 = new org.apache.commons.codec.language.Soundex(charArray14);
        soundex15.setMaxLength(1);
        int int18 = soundex15.getMaxLength();
        java.lang.String str20 = soundex15.encode("O0940103030808306030830609053016080931");
        java.lang.Object obj21 = refinedSoundex0.encode((java.lang.Object) "O0940103030808306030830609053016080931");
        java.lang.String str23 = refinedSoundex0.soundex("ARKPKSKMNSK");
        org.apache.commons.codec.language.Caverphone caverphone24 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str26 = caverphone24.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str28 = caverphone24.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str30 = caverphone24.encode("A");
        java.lang.String str32 = caverphone24.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str34 = caverphone24.encode("hi!");
        java.lang.Object obj36 = caverphone24.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        boolean boolean39 = caverphone24.isCaverphoneEqual("ARKPKSKMNS", "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj40 = refinedSoundex0.encode((java.lang.Object) caverphone24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '0' + "'", char13 == '0');
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "O000" + "'", str20, "O000");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "O0" + "'", obj21, "O0");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A0931383" + "'", str23, "A0931383");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "AKPKKMNSKT" + "'", str26, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AKPKKMNSKT" + "'", str28, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "A111111111" + "'", str30, "A111111111");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKPKKMNSKT" + "'", str32, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AA11111111" + "'", str34, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj36 + "' != '" + "AKPKKMNSKT" + "'", obj36, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test0839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0839");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.encode("");
        java.lang.String str27 = caverphone0.caverphone("ARKPXKMNSK");
        java.lang.String str29 = caverphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORGAP");
        java.lang.String str31 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "AKPKMNSK11" + "'", str27, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "AKPKKMNSKT" + "'", str29, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AKPKKMNSKT" + "'", str31, "AKPKKMNSKT");
    }

    @Test
    public void test0840() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0840");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        int int16 = metaphone13.getMaxCodeLen();
        boolean boolean19 = metaphone13.isMetaphoneEqual("", "");
        boolean boolean22 = metaphone13.isMetaphoneEqual("01230120022455012623010202", "");
        int int25 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone13, "01230120022455012623010202", "");
        java.lang.String str27 = metaphone13.encode("O093");
        boolean boolean30 = metaphone13.isMetaphoneEqual("A313", "org.apache.commons.codec.EncoderException: ");
        java.lang.String str32 = metaphone13.metaphone("O620");
        java.lang.Object obj33 = metaphone0.encode((java.lang.Object) str32);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone34 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str36 = doubleMetaphone34.doubleMetaphone("H");
        doubleMetaphone34.setMaxCodeLen((int) (byte) 0);
        java.lang.String str40 = doubleMetaphone34.encode("H");
        java.lang.String str42 = doubleMetaphone34.encode("");
        java.lang.Object obj43 = metaphone0.encode((java.lang.Object) "");
        metaphone0.setMaxCodeLen(4);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "O" + "'", str27, "O");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "O" + "'", str32, "O");
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "O" + "'", obj33, "O");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "" + "'", str40, "");
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertEquals("'" + obj43 + "' != '" + "" + "'", obj43, "");
    }

    @Test
    public void test0841() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0841");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        doubleMetaphone0.maxCodeLen = '\000';
        int int7 = doubleMetaphone0.maxCodeLen;
        doubleMetaphone0.maxCodeLen = 7;
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult11 = doubleMetaphone0.new DoubleMetaphoneResult((int) 'a');
        org.apache.commons.codec.language.Metaphone metaphone12 = new org.apache.commons.codec.language.Metaphone();
        metaphone12.setMaxCodeLen(3);
        java.lang.String str16 = metaphone12.encode("");
        java.lang.String str18 = metaphone12.encode("");
        int int19 = metaphone12.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = doubleMetaphone0.encode((java.lang.Object) metaphone12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test0842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0842");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        boolean boolean21 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "A#");
        java.lang.String str23 = metaphone0.encode("org.apache.commons.codec.EncoderException: ARKPXKMNSKTKNKTRKSPXN");
        boolean boolean26 = metaphone0.isMetaphoneEqual("AKPKSKMNS1", "O09401030308083060308306090530160809315383");
        org.apache.commons.codec.language.Caverphone caverphone27 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str29 = caverphone27.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str31 = caverphone27.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str33 = caverphone27.encode("");
        java.lang.String str35 = caverphone27.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone36 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone36.maxCodeLen = 0;
        char char41 = doubleMetaphone36.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult43 = doubleMetaphone36.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult43.appendAlternate('\000');
        java.lang.String str46 = doubleMetaphoneResult43.getAlternate();
        java.lang.String str47 = doubleMetaphoneResult43.getPrimary();
        java.lang.Object obj48 = caverphone27.encode((java.lang.Object) str47);
        java.lang.String str50 = caverphone27.caverphone("");
        int int53 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone27, "AKPKKMNSKT", "ORKP");
        java.lang.String str55 = caverphone27.encode("O0");
        java.lang.String str57 = caverphone27.encode("");
        java.lang.Object obj59 = caverphone27.encode((java.lang.Object) "AKPKMNSKT1");
        boolean boolean62 = caverphone27.isCaverphoneEqual("", "AK11111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj63 = metaphone0.encode((java.lang.Object) caverphone27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN" + "'", str23, "ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "AKPKKMNSKT" + "'", str29, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "AKPKKMNSKT" + "'", str31, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "1111111111" + "'", str33, "1111111111");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "1111111111" + "'", str35, "1111111111");
        org.junit.Assert.assertTrue("'" + char41 + "' != '" + '\000' + "'", char41 == '\000');
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "" + "'", str46, "");
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "" + "'", str47, "");
        org.junit.Assert.assertEquals("'" + obj48 + "' != '" + "1111111111" + "'", obj48, "1111111111");
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "1111111111" + "'", str50, "1111111111");
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "A111111111" + "'", str55, "A111111111");
        org.junit.Assert.assertEquals("'" + str57 + "' != '" + "1111111111" + "'", str57, "1111111111");
        org.junit.Assert.assertEquals("'" + obj59 + "' != '" + "AKPKMNSKT1" + "'", obj59, "AKPKMNSKT1");
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test0843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0843");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "hi!", "");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str11 = metaphone0.encode("AK11111111");
        java.lang.String str13 = metaphone0.encode("A1");
        char[] charArray15 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex16 = new org.apache.commons.codec.language.RefinedSoundex(charArray15);
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray15);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex18 = new org.apache.commons.codec.language.RefinedSoundex(charArray15);
        java.lang.Class<?> wildcardClass19 = charArray15.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = metaphone0.encode((java.lang.Object) charArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertArrayEquals(charArray15, new char[] { 'a' });
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test0844() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0844");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.soundex("HI");
        java.lang.String str9 = refinedSoundex0.encode("hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = 0;
        char char15 = doubleMetaphone10.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean19 = doubleMetaphone10.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char22 = doubleMetaphone10.charAt("01230120022455012623010202", (int) (short) 1);
        char char25 = doubleMetaphone10.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone10.maxCodeLen = 100;
        boolean boolean30 = doubleMetaphone10.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: A0", "O000");
        boolean boolean33 = doubleMetaphone10.isDoubleMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str35 = doubleMetaphone10.encode("AKPKKMNSKT");
        int int36 = doubleMetaphone10.maxCodeLen;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = refinedSoundex0.encode((java.lang.Object) int36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "H0" + "'", str7, "H0");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "H0" + "'", str9, "H0");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '1' + "'", char22 == '1');
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + 'O' + "'", char25 == 'O');
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "AKPKMNSKT" + "'", str35, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
    }

    @Test
    public void test0845() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0845");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.soundex("A ");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A000" + "'", str2, "A000");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
    }

    @Test
    public void test0846() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0846");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) '0');
        int int8 = soundex1.getMaxLength();
        soundex1.setMaxLength(65);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = soundex1.soundex("ARKPKSKMNSKTKNKTRKSPKSN");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 48 + "'", int8 == 48);
    }

    @Test
    public void test0847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0847");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex7 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex8 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex9 = new org.apache.commons.codec.language.Soundex(charArray4);
        org.apache.commons.codec.language.Soundex soundex10 = new org.apache.commons.codec.language.Soundex(charArray4);
        // The following exception was thrown during execution in test generation
        try {
            int int13 = soundex10.difference("O062010202050520302052030602013050", "K3");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
    }

    @Test
    public void test0848() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0848");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("A111111111O620");
        java.lang.String str12 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: ");
        metaphone0.setMaxCodeLen((int) '9');
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ORKPXKMNSK" + "'", str12, "ORKPXKMNSK");
    }

    @Test
    public void test0849() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0849");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A ", "O0940103030808306030830609053016080931");
        int int10 = refinedSoundex0.difference("org.apache.commons.codec.EncoderException: ORKP", "AA");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080931" + "'", str4, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test0850() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0850");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        java.lang.String str8 = soundex3.encode("1111111111");
        java.lang.String str10 = soundex3.encode("A0931");
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A000" + "'", str10, "A000");
    }

    @Test
    public void test0851() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0851");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        java.lang.String str4 = metaphone0.encode("A621");
        java.lang.String str6 = metaphone0.metaphone("KPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "KPK" + "'", str6, "KPK");
    }

    @Test
    public void test0852() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0852");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        java.lang.String str12 = doubleMetaphone0.encode("");
        char char15 = doubleMetaphone0.charAt("K120", (int) 'i');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
    }

    @Test
    public void test0853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0853");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A000");
        java.lang.String str8 = caverphone0.encode("A09313836383693158931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
    }

    @Test
    public void test0854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0854");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        int int19 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "O0931");
        java.lang.String str21 = metaphone0.encode("AK11111111");
        int int22 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AK" + "'", str21, "AK");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
    }

    @Test
    public void test0855() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0855");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("", "K120");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0856() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0856");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str13 = caverphone0.caverphone("O0931");
        java.lang.String str15 = caverphone0.encode("A621r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A111111111" + "'", str11, "A111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "AA11111111" + "'", str15, "AA11111111");
    }

    @Test
    public void test0857() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0857");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        int int26 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AKPKKMNSKT", "ORKP");
        java.lang.String str28 = caverphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str30 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone31 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str33 = doubleMetaphone31.doubleMetaphone("H");
        java.lang.String str35 = doubleMetaphone31.doubleMetaphone("");
        java.lang.String str38 = doubleMetaphone31.doubleMetaphone("ORKP", true);
        java.lang.String str41 = doubleMetaphone31.doubleMetaphone("", false);
        java.lang.String str43 = doubleMetaphone31.encode("");
        doubleMetaphone31.setMaxCodeLen(10);
        int int46 = doubleMetaphone31.maxCodeLen;
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone47 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone47.maxCodeLen = '\000';
        char char52 = doubleMetaphone47.charAt("", 0);
        java.lang.String str54 = doubleMetaphone47.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str56 = doubleMetaphone47.doubleMetaphone("");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult58 = doubleMetaphone47.new DoubleMetaphoneResult((int) (byte) 100);
        doubleMetaphoneResult58.appendPrimary('4');
        java.lang.String str61 = doubleMetaphoneResult58.getPrimary();
        java.lang.Object obj62 = doubleMetaphone31.encode((java.lang.Object) str61);
        doubleMetaphone31.setMaxCodeLen(2);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj65 = caverphone0.encode((java.lang.Object) 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "A111111111" + "'", str28, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKKMNSKT" + "'", str30, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "ARKP" + "'", str38, "ARKP");
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
        org.junit.Assert.assertTrue("'" + char52 + "' != '" + '\000' + "'", char52 == '\000');
        org.junit.Assert.assertEquals("'" + str54 + "' != '" + "" + "'", str54, "");
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + "4" + "'", str61, "4");
        org.junit.Assert.assertEquals("'" + obj62 + "' != '" + "" + "'", obj62, "");
    }

    @Test
    public void test0858() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0858");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080");
        int int15 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "org.apache.commons.codec.EncoderException: HI", " AKP1111111 ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test0859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0859");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("ORKP");
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.Object obj5 = metaphone0.encode((java.lang.Object) "ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        metaphone0.setMaxCodeLen(1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertEquals("'" + obj5 + "' != '" + "ORKP" + "'", obj5, "ORKP");
    }

    @Test
    public void test0860() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0860");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        java.lang.String str12 = metaphone0.metaphone("ARKPKSKMNSK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "ARKPKSKMNS" + "'", str12, "ARKPKSKMNS");
    }

    @Test
    public void test0861() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0861");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("ORKP", "AA11111111");
        soundex1.setMaxLength(10);
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int10 = soundex1.getMaxLength();
        java.lang.Class<?> wildcardClass11 = soundex1.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0862() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0862");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        int int5 = soundex0.getMaxLength();
        int int8 = soundex0.difference("", "A111111111");
        java.lang.String str10 = soundex0.encode("O0940103030808306030830609053016080931");
        int int11 = soundex0.getMaxLength();
        java.lang.String str13 = soundex0.encode("ARKPXKMNSKTKNKTRKS");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O000" + "'", str10, "O000");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A621" + "'", str13, "A621");
    }

    @Test
    public void test0863() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0863");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.caverphone("AA");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "AA11111111" + "'", str25, "AA11111111");
    }

    @Test
    public void test0864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0864");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        metaphone0.setMaxCodeLen((int) (short) 100);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = metaphone0.encode((java.lang.Object) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
    }

    @Test
    public void test0865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0865");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('#');
        java.lang.String str9 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str11 = refinedSoundex0.encode("O");
        int int14 = refinedSoundex0.difference("A0", "org.apache.commons.codec.EncoderException: A0");
        char char16 = refinedSoundex0.getMappingCode('0');
        int int19 = refinedSoundex0.difference("1111111111", "O621");
        java.lang.String str21 = refinedSoundex0.encode("A#");
        int int24 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "a", "org.apache.commons.codec.EncoderException:  ");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O0" + "'", str11, "O0");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "A0" + "'", str21, "A0");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test0866() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0866");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        char char13 = refinedSoundex0.getMappingCode('4');
        java.lang.String str15 = refinedSoundex0.soundex("");
        java.lang.String str17 = refinedSoundex0.encode("AKPKMNSKT1");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A0313836" + "'", str17, "A0313836");
    }

    @Test
    public void test0867() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0867");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A ", "O0940103030808306030830609053016080931");
        char char9 = refinedSoundex0.getMappingCode('O');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080931" + "'", str4, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
    }

    @Test
    public void test0868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0868");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("4");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }

    @Test
    public void test0869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0869");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex29 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char31 = refinedSoundex29.getMappingCode('a');
        int int34 = refinedSoundex29.difference("", "hi!");
        char char36 = refinedSoundex29.getMappingCode('#');
        int int39 = refinedSoundex29.difference("AKPKKMNSKT", "A621");
        java.lang.Object obj41 = refinedSoundex29.encode((java.lang.Object) "O941");
        java.lang.Object obj42 = caverphone0.encode(obj41);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone43 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str45 = doubleMetaphone43.doubleMetaphone("H");
        doubleMetaphone43.setMaxCodeLen((int) (byte) 0);
        java.lang.String str50 = doubleMetaphone43.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult52 = doubleMetaphone43.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult52.append('#');
        doubleMetaphoneResult52.appendAlternate('r');
        doubleMetaphoneResult52.appendAlternate('a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj59 = caverphone0.encode((java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(refinedSoundex29);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + '0' + "'", char31 == '0');
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertEquals("'" + obj41 + "' != '" + "O0" + "'", obj41, "O0");
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + "A111111111" + "'", obj42, "A111111111");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "" + "'", str45, "");
        org.junit.Assert.assertNull(str50);
    }

    @Test
    public void test0870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0870");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        int int7 = soundex1.getMaxLength();
        int int10 = soundex1.difference("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        int int11 = soundex1.getMaxLength();
        java.lang.String str13 = soundex1.encode("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        java.lang.Class<?> wildcardClass14 = soundex1.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A931" + "'", str13, "A931");
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test0871() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0871");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("AO");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "AO" + "'", str1, "AO");
    }

    @Test
    public void test0872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0872");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int5 = soundex2.difference("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str7 = soundex2.soundex("O620");
        java.lang.String str9 = soundex2.soundex("A621");
        java.lang.String str11 = soundex2.encode("A ");
        int int14 = soundex2.difference("org.apache.commons.codec.EncoderException: O0", "AKP1111111");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O000" + "'", str7, "O000");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A000" + "'", str9, "A000");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A000" + "'", str11, "A000");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test0873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0873");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("01", "O621");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0874");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = org.apache.commons.codec.language.SoundexUtils.difference(stringEncoder0, "", "A031383");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0875() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0875");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A093138363836931589313836383693158");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }

    @Test
    public void test0876() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0876");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex6 = new org.apache.commons.codec.language.Soundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = soundex6.encode("I");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: I");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0877");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode('i');
        char char9 = refinedSoundex0.getMappingCode('o');
        int int12 = refinedSoundex0.difference("AK11111111", "  ");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test0878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0878");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength((int) '0');
        int int8 = soundex1.getMaxLength();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = soundex1.encode("AKPKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 48 + "'", int8 == 48);
    }

    @Test
    public void test0879() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0879");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone6 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str8 = doubleMetaphone6.doubleMetaphone("H");
        doubleMetaphone6.setMaxCodeLen((int) (byte) 0);
        java.lang.String str13 = doubleMetaphone6.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult15 = doubleMetaphone6.new DoubleMetaphoneResult(0);
        java.lang.String str16 = doubleMetaphoneResult15.getPrimary();
        doubleMetaphoneResult15.appendPrimary('1');
        doubleMetaphoneResult15.appendAlternate("org.apache.commons.codec.EncoderException: O0");
        doubleMetaphoneResult15.append(' ', '1');
        doubleMetaphoneResult15.appendPrimary('O');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = refinedSoundex0.encode((java.lang.Object) doubleMetaphoneResult15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
    }

    @Test
    public void test0880() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0880");
        char[] charArray2 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray2);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = refinedSoundex3.encode("AKPKSKMNS1");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '1', ' ' });
    }

    @Test
    public void test0881() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0881");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.soundex("ARKPKKMNSKTKNKTRKSPXNRKPKKMNSKTKNKTRKSPXN");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = '\000';
        int int16 = doubleMetaphone13.getMaxCodeLen();
        java.lang.String str18 = doubleMetaphone13.encode("ARKP");
        char char21 = doubleMetaphone13.charAt("O", (int) ' ');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = refinedSoundex0.encode((java.lang.Object) doubleMetaphone13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A093138363836931589313836383693158" + "'", str12, "A093138363836931589313836383693158");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
    }

    @Test
    public void test0882() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0882");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        int int9 = soundex0.getMaxLength();
        java.lang.String str11 = soundex0.encode("");
        java.lang.String str13 = soundex0.encode("O0931");
        soundex0.setMaxLength(114);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O000" + "'", str13, "O000");
    }

    @Test
    public void test0883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0883");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("", false);
        int int8 = doubleMetaphone0.maxCodeLen;
        int int9 = doubleMetaphone0.getMaxCodeLen();
        boolean boolean12 = doubleMetaphone0.isDoubleMetaphoneEqual("ORKPXKMNSKTKNKTRKSSPXNH", "O0");
        java.lang.String str15 = doubleMetaphone0.doubleMetaphone("AKPKKMNSKT", false);
        org.apache.commons.codec.language.Metaphone metaphone16 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str18 = metaphone16.encode("org.apache.commons.codec.EncoderException: HI");
        boolean boolean21 = metaphone16.isMetaphoneEqual("ARK", "A0931");
        java.lang.String str23 = metaphone16.encode("O0940103030808306030830609053016080");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = doubleMetaphone0.encode((java.lang.Object) metaphone16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORKP" + "'", str18, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "O" + "'", str23, "O");
    }

    @Test
    public void test0884() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0884");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        java.lang.String str9 = soundex1.soundex("O0940103030808306030830609053016080");
        int int10 = soundex1.getMaxLength();
        soundex1.setMaxLength((int) ' ');
        int int13 = soundex1.getMaxLength();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone14 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone14.maxCodeLen = '\000';
        char char19 = doubleMetaphone14.charAt("", 0);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult21 = doubleMetaphone14.new DoubleMetaphoneResult((int) ' ');
        doubleMetaphoneResult21.appendPrimary('#');
        boolean boolean24 = doubleMetaphoneResult21.isComplete();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = soundex1.encode((java.lang.Object) boolean24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O000" + "'", str9, "O000");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\000' + "'", char19 == '\000');
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test0885() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0885");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: A#");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
    }

    @Test
    public void test0886() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0886");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("4", "O0940103030808306030830609053016080");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0887");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        java.lang.String str13 = metaphone0.encode("A1");
        java.lang.String str15 = metaphone0.encode("K3");
        metaphone0.setMaxCodeLen(0);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A" + "'", str13, "A");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "K" + "'", str15, "K");
    }

    @Test
    public void test0888() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0888");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.String str12 = caverphone0.encode("O0940103030808306030830609053016080931");
        java.lang.String str14 = caverphone0.encode("O093");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A111111111" + "'", str14, "A111111111");
    }

    @Test
    public void test0889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0889");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ARKPXKMNSK", "A1111111114r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0890() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0890");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: O000", "AKPKMNSK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0891");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex24 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char26 = refinedSoundex24.getMappingCode('a');
        int int29 = refinedSoundex24.difference("", "hi!");
        int int32 = refinedSoundex24.difference("", "A");
        java.lang.Object obj33 = caverphone0.encode((java.lang.Object) "");
        org.apache.commons.codec.EncoderException encoderException35 = new org.apache.commons.codec.EncoderException("A ");
        org.apache.commons.codec.EncoderException encoderException37 = new org.apache.commons.codec.EncoderException("A0");
        java.lang.Throwable[] throwableArray38 = encoderException37.getSuppressed();
        encoderException35.addSuppressed((java.lang.Throwable) encoderException37);
        org.apache.commons.codec.EncoderException encoderException41 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException43 = new org.apache.commons.codec.EncoderException("");
        encoderException41.addSuppressed((java.lang.Throwable) encoderException43);
        org.apache.commons.codec.EncoderException encoderException46 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException48 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray49 = encoderException48.getSuppressed();
        encoderException46.addSuppressed((java.lang.Throwable) encoderException48);
        org.apache.commons.codec.EncoderException encoderException52 = new org.apache.commons.codec.EncoderException("A ");
        encoderException48.addSuppressed((java.lang.Throwable) encoderException52);
        encoderException43.addSuppressed((java.lang.Throwable) encoderException52);
        org.apache.commons.codec.EncoderException encoderException56 = new org.apache.commons.codec.EncoderException("ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        encoderException52.addSuppressed((java.lang.Throwable) encoderException56);
        encoderException35.addSuppressed((java.lang.Throwable) encoderException56);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj59 = caverphone0.encode((java.lang.Object) encoderException35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex24);
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '0' + "'", char26 == '0');
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "1111111111" + "'", obj33, "1111111111");
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertArrayEquals(throwableArray38, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertArrayEquals(throwableArray49, new java.lang.Throwable[] {});
    }

    @Test
    public void test0892() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0892");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char5 = refinedSoundex3.getMappingCode('a');
        int int8 = refinedSoundex3.difference("", "hi!");
        char char10 = refinedSoundex3.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        java.lang.String str15 = doubleMetaphone11.doubleMetaphone("");
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("ORKP", true);
        java.lang.String str21 = doubleMetaphone11.doubleMetaphone("", false);
        java.lang.String str23 = doubleMetaphone11.encode("");
        java.lang.Object obj24 = refinedSoundex3.encode((java.lang.Object) "");
        java.lang.Object obj25 = caverphone0.encode(obj24);
        boolean boolean28 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str30 = caverphone0.caverphone("AKPKMNSK11");
        java.lang.String str32 = caverphone0.caverphone("A1111111114r");
        char[] charArray35 = new char[] { '1', ' ' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex36 = new org.apache.commons.codec.language.RefinedSoundex(charArray35);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = caverphone0.encode((java.lang.Object) refinedSoundex36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex3);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '0' + "'", char5 == '0');
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ARKP" + "'", str18, "ARKP");
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertEquals("'" + obj24 + "' != '" + "" + "'", obj24, "");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "1111111111" + "'", obj25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKMNSK11" + "'", str30, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AA11111111" + "'", str32, "AA11111111");
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertArrayEquals(charArray35, new char[] { '1', ' ' });
    }

    @Test
    public void test0893() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0893");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        char char13 = refinedSoundex0.getMappingCode('0');
        java.lang.String str15 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone16 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str18 = doubleMetaphone16.doubleMetaphone("H");
        doubleMetaphone16.setMaxCodeLen((int) (byte) 0);
        char char23 = doubleMetaphone16.charAt("hi!", 1);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult25 = doubleMetaphone16.new DoubleMetaphoneResult((int) '4');
        java.lang.String str26 = doubleMetaphoneResult25.getAlternate();
        doubleMetaphoneResult25.appendPrimary("O0931");
        java.lang.Object obj29 = refinedSoundex0.encode((java.lang.Object) "O0931");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone30 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone30.maxCodeLen = 0;
        char char35 = doubleMetaphone30.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult37 = doubleMetaphone30.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult37.appendPrimary("org.apache.commons.codec.EncoderException: HI");
        doubleMetaphoneResult37.append(' ', '0');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj43 = refinedSoundex0.encode((java.lang.Object) '0');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O0940103030808306030830609053016080931" + "'", str15, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + 'i' + "'", char23 == 'i');
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "O0" + "'", obj29, "O0");
        org.junit.Assert.assertTrue("'" + char35 + "' != '" + '\000' + "'", char35 == '\000');
    }

    @Test
    public void test0894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0894");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A0313836", "ARK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test0895() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0895");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        int int5 = metaphone0.getMaxCodeLen();
        java.lang.String str7 = metaphone0.encode("A062125232523621256212523252362125");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone8 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str10 = doubleMetaphone8.doubleMetaphone("H");
        doubleMetaphone8.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone8.maxCodeLen = '0';
        java.lang.String str17 = doubleMetaphone8.doubleMetaphone("A", true);
        boolean boolean20 = doubleMetaphone8.isDoubleMetaphoneEqual("A0", "");
        java.lang.Object obj21 = metaphone0.encode((java.lang.Object) "A0");
        metaphone0.setMaxCodeLen(34);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A" + "'", str7, "A");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "A" + "'", str17, "A");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "A" + "'", obj21, "A");
    }

    @Test
    public void test0896() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0896");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex5, "A093153836383693158", "");
        org.apache.commons.codec.language.Caverphone caverphone11 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str13 = caverphone11.caverphone("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex14 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char16 = refinedSoundex14.getMappingCode('a');
        int int19 = refinedSoundex14.difference("", "hi!");
        char char21 = refinedSoundex14.getMappingCode(' ');
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone22 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str24 = doubleMetaphone22.doubleMetaphone("H");
        java.lang.String str26 = doubleMetaphone22.doubleMetaphone("");
        java.lang.String str29 = doubleMetaphone22.doubleMetaphone("ORKP", true);
        java.lang.String str32 = doubleMetaphone22.doubleMetaphone("", false);
        java.lang.String str34 = doubleMetaphone22.encode("");
        java.lang.Object obj35 = refinedSoundex14.encode((java.lang.Object) "");
        java.lang.Object obj36 = caverphone11.encode(obj35);
        java.lang.String str38 = caverphone11.caverphone("");
        java.lang.String str40 = caverphone11.encode("A#");
        boolean boolean43 = caverphone11.isCaverphoneEqual("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP", " org.apache.commons.codec.EncoderException: ORGAP");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj44 = refinedSoundex5.encode((java.lang.Object) caverphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKPKKMNSKT" + "'", str13, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(refinedSoundex14);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '0' + "'", char16 == '0');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + '\000' + "'", char21 == '\000');
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "ARKP" + "'", str29, "ARKP");
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "" + "'", obj35, "");
        org.junit.Assert.assertEquals("'" + obj36 + "' != '" + "1111111111" + "'", obj36, "1111111111");
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "1111111111" + "'", str38, "1111111111");
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "A111111111" + "'", str40, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test0897() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0897");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        boolean boolean11 = caverphone0.isCaverphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str13 = caverphone0.encode("AKP1111111");
        java.lang.String str15 = caverphone0.caverphone(" ");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "AKP1111111" + "'", str13, "AKP1111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
    }

    @Test
    public void test0898() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0898");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        java.lang.String str10 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: O");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O0940103030808306030830609053016080" + "'", str10, "O0940103030808306030830609053016080");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O0940103030808306030830609053016080" + "'", str12, "O0940103030808306030830609053016080");
    }

    @Test
    public void test0899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0899");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int5 = soundex1.difference("org.apache.commons.codec.EncoderException: hi!", "AKP");
        soundex1.setMaxLength((int) '#');
        int int10 = soundex1.difference(" ", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.Class<?> wildcardClass11 = soundex1.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test0900() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0900");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.encode("H");
        boolean boolean16 = caverphone0.isCaverphoneEqual("A111111111O620", "hi!");
        boolean boolean19 = caverphone0.isCaverphoneEqual("AA11111111", "AKPKKMNSKT");
        org.apache.commons.codec.language.Soundex soundex20 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex20.setMaxLength((int) 'o');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = caverphone0.encode((java.lang.Object) soundex20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A111111111" + "'", str13, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(soundex20);
    }

    @Test
    public void test0901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0901");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.soundex("O0940103030808306030830609053016080");
        java.lang.String str15 = refinedSoundex0.soundex("AKPKKMNSKT");
        int int18 = refinedSoundex0.difference("A212", "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "O0" + "'", str13, "O0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A0313836" + "'", str15, "A0313836");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test0902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0902");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        java.lang.String str2 = soundex0.encode("ARKP");
        java.lang.String str4 = soundex0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.Object obj6 = soundex0.encode((java.lang.Object) "ORK");
        soundex0.setMaxLength(4);
        java.lang.String str10 = soundex0.soundex("org.apache.commons.codec.EncoderException: O0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "A621" + "'", str2, "A621");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O621" + "'", str4, "O621");
        org.junit.Assert.assertEquals("'" + obj6 + "' != '" + "O620" + "'", obj6, "O620");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O621" + "'", str10, "O621");
    }

    @Test
    public void test0903() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0903");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        boolean boolean15 = caverphone0.isCaverphoneEqual("AKPKKMNSKT", "A0931383");
        org.apache.commons.codec.language.Metaphone metaphone16 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str18 = metaphone16.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone16.setMaxCodeLen((int) (byte) 100);
        java.lang.String str22 = metaphone16.encode("AKPKMNSKT");
        java.lang.String str24 = metaphone16.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.Object obj25 = caverphone0.encode((java.lang.Object) str24);
        org.apache.commons.codec.language.Metaphone metaphone26 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str28 = metaphone26.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone26.setMaxCodeLen((int) (byte) 100);
        boolean boolean33 = metaphone26.isMetaphoneEqual("", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int34 = metaphone26.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj35 = caverphone0.encode((java.lang.Object) int34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORKP" + "'", str18, "ORKP");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "O" + "'", str24, "O");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "A111111111" + "'", obj25, "A111111111");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "ORKP" + "'", str28, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
    }

    @Test
    public void test0904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0904");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        java.lang.String str13 = caverphone0.caverphone("");
        java.lang.String str15 = caverphone0.encode("");
        java.lang.String str17 = caverphone0.caverphone("A111111111O620");
        java.lang.String str19 = caverphone0.caverphone("ARKPXKMNSK");
        java.lang.String str21 = caverphone0.caverphone("AKPKMNSKT");
        java.lang.String str23 = caverphone0.caverphone("A0931383");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "1111111111" + "'", str15, "1111111111");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AA11111111" + "'", str17, "AA11111111");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "AKPKMNSK11" + "'", str19, "AKPKMNSK11");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "AKPKMNSKT1" + "'", str21, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "A111111111" + "'", str23, "A111111111");
    }

    @Test
    public void test0905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0905");
        char[] charArray3 = new char[] { '#', '\000', '1' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray3);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex5.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKA#");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: O");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertArrayEquals(charArray3, new char[] { '#', '\000', '1' });
    }

    @Test
    public void test0906() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0906");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        int int8 = metaphone0.getMaxCodeLen();
        int int9 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test0907() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0907");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        int int15 = doubleMetaphone0.maxCodeLen;
        char char18 = doubleMetaphone0.charAt("O093", 65);
        int int21 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "", "AKP1111111");
        int int22 = doubleMetaphone0.getMaxCodeLen();
        int int25 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "A062125232523621256212523252362125", "ARKPKKMNSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test0908() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0908");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        org.apache.commons.codec.language.Metaphone metaphone13 = new org.apache.commons.codec.language.Metaphone();
        metaphone13.setMaxCodeLen(3);
        java.lang.String str17 = metaphone13.encode("");
        java.lang.String str19 = metaphone13.encode("");
        metaphone13.setMaxCodeLen((int) (short) 10);
        int int22 = metaphone13.getMaxCodeLen();
        java.lang.String str24 = metaphone13.encode("ORKP");
        java.lang.String str26 = metaphone13.encode("hi!");
        int int27 = metaphone13.getMaxCodeLen();
        int int30 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone13, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "AKPKMNSKT");
        java.lang.String str32 = metaphone13.metaphone("A#");
        java.lang.Object obj33 = metaphone0.encode((java.lang.Object) str32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ORKP" + "'", str24, "ORKP");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "H" + "'", str26, "H");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "A" + "'", str32, "A");
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "A" + "'", obj33, "A");
    }

    @Test
    public void test0909() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0909");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("AKPKMNSKT1");
        metaphone0.setMaxCodeLen((int) 'r');
        boolean boolean27 = metaphone0.isMetaphoneEqual("AKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone28 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str30 = doubleMetaphone28.doubleMetaphone("H");
        java.lang.String str32 = doubleMetaphone28.doubleMetaphone("HI");
        java.lang.String str34 = doubleMetaphone28.doubleMetaphone("AKPKMNSKT1");
        java.lang.Object obj35 = metaphone0.encode((java.lang.Object) str34);
        boolean boolean38 = metaphone0.isMetaphoneEqual("", "A111111111");
        java.lang.String str40 = metaphone0.metaphone("O0931");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKMNSKT" + "'", str22, "AKPKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "H" + "'", str32, "H");
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "AKPK" + "'", str34, "AKPK");
        org.junit.Assert.assertEquals("'" + obj35 + "' != '" + "AKPK" + "'", obj35, "AKPK");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "O" + "'", str40, "O");
    }

    @Test
    public void test0910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0910");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("org.apache.commons.codec.EncoderException: ORKPXKMNSK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSK" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSK");
    }

    @Test
    public void test0911() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0911");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        java.lang.String str7 = refinedSoundex0.soundex("ARKPKKMNSK");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A0931383" + "'", str7, "A0931383");
    }

    @Test
    public void test0912() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0912");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: AKPKKMNSKT", "org.apache.commons.codec.EncoderException: ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test0913() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0913");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O0940103030808306030830609053016080940103030808306030830609053016080931");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0914");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("O0940103030808306030830609053016080931", "");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "A111111111O620", "ARKPKSKMNSK");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = 0;
        char char15 = doubleMetaphone10.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean19 = doubleMetaphone10.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char22 = doubleMetaphone10.charAt("01230120022455012623010202", (int) (short) 1);
        char char25 = doubleMetaphone10.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone10.maxCodeLen = (byte) 10;
        int int30 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone10, "A", "A");
        boolean boolean33 = doubleMetaphone10.isDoubleMetaphoneEqual("H000", "1111111111");
        char char36 = doubleMetaphone10.charAt("O0", 1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = metaphone0.encode((java.lang.Object) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + char22 + "' != '" + '1' + "'", char22 == '1');
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + 'O' + "'", char25 == 'O');
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '0' + "'", char36 == '0');
    }

    @Test
    public void test0915() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0915");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        int int16 = refinedSoundex0.difference("AA11111111", "01230120022455012623010202");
        java.lang.String str18 = refinedSoundex0.soundex("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone19 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone19.maxCodeLen = 0;
        char char24 = doubleMetaphone19.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult26 = doubleMetaphone19.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult26.appendAlternate('\000');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj29 = refinedSoundex0.encode((java.lang.Object) '\000');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "O09401030308083060308306090530160809315383638369315893153836383693158931" + "'", str18, "O09401030308083060308306090530160809315383638369315893153836383693158931");
        org.junit.Assert.assertTrue("'" + char24 + "' != '" + '\000' + "'", char24 == '\000');
    }

    @Test
    public void test0916() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0916");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        int int14 = metaphone0.getMaxCodeLen();
        boolean boolean17 = metaphone0.isMetaphoneEqual("AKPKMNSKT", "AKPKMNSKT");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str21 = metaphone0.encode(" AKPK");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
    }

    @Test
    public void test0917() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0917");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "O0940103030808306030830609053016080940103030808306030830609053016080931");
        java.lang.String str9 = metaphone0.encode("O09401030308083060308306090530160809315383638369315893153836383693158931");
        java.lang.String str11 = metaphone0.metaphone("O062010202050520302052030602013050");
        int int12 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "O" + "'", str11, "O");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test0918() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0918");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("", "");
        char[] charArray12 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex13 = new org.apache.commons.codec.language.Soundex(charArray12);
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray12);
        soundex14.setMaxLength((int) '1');
        soundex14.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = refinedSoundex0.encode((java.lang.Object) soundex14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test0919() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0919");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        soundex0.setMaxLength(65);
        int int6 = soundex0.difference("  ", "org.apache.commons.codec.EncoderException: HI");
        soundex0.setMaxLength((int) 'r');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test0920() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0920");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        int int3 = refinedSoundex0.difference("A111111111", "org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str5 = refinedSoundex0.encode("O621");
        char char7 = refinedSoundex0.getMappingCode('a');
        int int10 = refinedSoundex0.difference("AK", "ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK");
        char char12 = refinedSoundex0.getMappingCode('o');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "O0" + "'", str5, "O0");
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '0' + "'", char12 == '0');
    }

    @Test
    public void test0921() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0921");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        java.lang.String str2 = refinedSoundex0.soundex("01230120022455012623010202");
        java.lang.String str4 = refinedSoundex0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "A ", "O0940103030808306030830609053016080931");
        int int10 = refinedSoundex0.difference("O", "1111111111");
        java.lang.String str12 = refinedSoundex0.soundex("AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "O0940103030808306030830609053016080931" + "'", str4, "O0940103030808306030830609053016080931");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
    }

    @Test
    public void test0922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0922");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        boolean boolean11 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: hi!");
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("A ");
        java.lang.Object obj14 = metaphone0.encode((java.lang.Object) "A ");
        boolean boolean17 = metaphone0.isMetaphoneEqual("A1", "O941");
        boolean boolean20 = metaphone0.isMetaphoneEqual("A621", "O0");
        int int21 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + "A" + "'", obj14, "A");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
    }

    @Test
    public void test0923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0923");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        java.lang.String str7 = refinedSoundex5.encode("01230120022455012623010202");
        char char9 = refinedSoundex5.getMappingCode('#');
        int int12 = refinedSoundex5.difference(" ", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        char char18 = doubleMetaphone13.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean22 = doubleMetaphone13.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        doubleMetaphone13.maxCodeLen = 3;
        java.lang.String str26 = doubleMetaphone13.doubleMetaphone(" ");
        java.lang.Object obj27 = refinedSoundex5.encode((java.lang.Object) " ");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str29 = refinedSoundex5.encode("A621r");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 17 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '\000' + "'", char9 == '\000');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '\000' + "'", char18 == '\000');
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + "" + "'", obj27, "");
    }

    @Test
    public void test0924() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0924");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        java.lang.String str20 = metaphone0.metaphone("AKPKKMNSKT");
        java.lang.String str22 = metaphone0.metaphone("ARKPXKMNSKTKNKTRKSPXNRKPKSKMNSK");
        int int25 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "K", "A111111111");
        boolean boolean28 = metaphone0.isMetaphoneEqual("", "org.apache.commons.codec.EncoderException: A ");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "AKPKMNSKT" + "'", str20, "AKPKMNSKT");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "ARKPKSKMNS" + "'", str22, "ARKPKSKMNS");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test0925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0925");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("org.apache.commons.codec.EncoderException: A#", "ORKPXKMNSKTKNKTRKSSPXNH");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0926() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0926");
        org.apache.commons.codec.language.Soundex soundex0 = new org.apache.commons.codec.language.Soundex();
        int int1 = soundex0.getMaxLength();
        org.apache.commons.codec.language.Metaphone metaphone2 = new org.apache.commons.codec.language.Metaphone();
        metaphone2.setMaxCodeLen(3);
        java.lang.String str6 = metaphone2.encode("");
        java.lang.String str8 = metaphone2.encode("");
        java.lang.Object obj9 = soundex0.encode((java.lang.Object) "");
        soundex0.setMaxLength(0);
        soundex0.setMaxLength((int) 'o');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + obj9 + "' != '" + "" + "'", obj9, "");
    }

    @Test
    public void test0927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0927");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        int int7 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex4, "A111111111", "O941");
        char char9 = refinedSoundex4.getMappingCode('a');
        char char11 = refinedSoundex4.getMappingCode('1');
        int int14 = refinedSoundex4.difference("", "AKP1111111");
        java.lang.String str16 = refinedSoundex4.soundex("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertTrue("'" + char11 + "' != '" + '\000' + "'", char11 == '\000');
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
    }

    @Test
    public void test0928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0928");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        doubleMetaphone0.setMaxCodeLen((int) (byte) 0);
        doubleMetaphone0.maxCodeLen = '0';
        java.lang.String str9 = doubleMetaphone0.doubleMetaphone("A", true);
        boolean boolean12 = doubleMetaphone0.isDoubleMetaphoneEqual("A0", "");
        boolean boolean15 = doubleMetaphone0.isDoubleMetaphoneEqual("A ", "org.apache.commons.codec.EncoderException: ORKP");
        doubleMetaphone0.setMaxCodeLen((int) 'A');
        int int20 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "ARK", "A ");
        doubleMetaphone0.setMaxCodeLen((int) '#');
        boolean boolean25 = doubleMetaphone0.isDoubleMetaphoneEqual("O620", "");
        boolean boolean28 = doubleMetaphone0.isDoubleMetaphoneEqual("A621r", "org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        java.lang.String str30 = doubleMetaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "ARKPXKMNSKTKNKTRKSPXNRKP" + "'", str30, "ARKPXKMNSKTKNKTRKSPXNRKP");
    }

    @Test
    public void test0929() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0929");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str10 = caverphone0.encode("hi!");
        java.lang.Object obj12 = caverphone0.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: O0");
        boolean boolean15 = caverphone0.isCaverphoneEqual("ARKPKSKMNS", "org.apache.commons.codec.EncoderException: 01230120022455012623010202");
        java.lang.String str17 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        org.apache.commons.codec.EncoderException encoderException19 = new org.apache.commons.codec.EncoderException("hi!");
        java.lang.Throwable[] throwableArray20 = encoderException19.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = caverphone0.encode((java.lang.Object) throwableArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AKPKKMNSKT" + "'", str8, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AA11111111" + "'", str10, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + "AKPKKMNSKT" + "'", obj12, "AKPKKMNSKT");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "AKPKKMNSKT" + "'", str17, "AKPKKMNSKT");
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertArrayEquals(throwableArray20, new java.lang.Throwable[] {});
    }

    @Test
    public void test0930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0930");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        int int19 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.Caverphone caverphone20 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str22 = caverphone20.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str24 = caverphone20.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str26 = caverphone20.encode("A");
        char[] charArray27 = null;
        org.apache.commons.codec.language.Soundex soundex28 = new org.apache.commons.codec.language.Soundex(charArray27);
        java.lang.String str30 = soundex28.soundex("");
        java.lang.String str32 = soundex28.encode("");
        java.lang.Object obj33 = caverphone20.encode((java.lang.Object) "");
        boolean boolean36 = caverphone20.isCaverphoneEqual("ARK", "AA11111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = metaphone0.encode((java.lang.Object) boolean36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AKPKKMNSKT" + "'", str24, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "A111111111" + "'", str26, "A111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertEquals("'" + obj33 + "' != '" + "1111111111" + "'", obj33, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test0931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0931");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        int int14 = metaphone0.getMaxCodeLen();
        java.lang.String str16 = metaphone0.encode("A ");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
    }

    @Test
    public void test0932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0932");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        java.lang.String str16 = metaphone0.encode("ARKP");
        java.lang.String str18 = metaphone0.encode("");
        java.lang.String str20 = metaphone0.encode("H");
        java.lang.String str22 = metaphone0.metaphone("A093153836383693158");
        java.lang.String str24 = metaphone0.metaphone("A#");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ARKP" + "'", str16, "ARKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "A" + "'", str22, "A");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "A" + "'", str24, "A");
    }

    @Test
    public void test0933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0933");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex1.setMaxLength(1);
        int int4 = soundex1.getMaxLength();
        int int7 = soundex1.difference("HI", "");
        int int10 = soundex1.difference("o", "O0931");
        char[] charArray11 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex12 = new org.apache.commons.codec.language.Soundex(charArray11);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex13 = new org.apache.commons.codec.language.RefinedSoundex(charArray11);
        org.apache.commons.codec.language.Soundex soundex14 = new org.apache.commons.codec.language.Soundex(charArray11);
        org.apache.commons.codec.language.Soundex soundex15 = new org.apache.commons.codec.language.Soundex(charArray11);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = soundex1.encode((java.lang.Object) charArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test0934() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0934");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        java.lang.String str10 = doubleMetaphone0.doubleMetaphone("", false);
        java.lang.String str12 = doubleMetaphone0.encode("");
        doubleMetaphone0.setMaxCodeLen(10);
        boolean boolean17 = doubleMetaphone0.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        boolean boolean20 = doubleMetaphone0.isDoubleMetaphoneEqual("AK11111111", "ORKPXKMNSKTKNKTRKSSPXNH");
        boolean boolean24 = doubleMetaphone0.isDoubleMetaphoneEqual("O0", "", false);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex25 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char27 = refinedSoundex25.getMappingCode('a');
        int int30 = refinedSoundex25.difference("", "hi!");
        int int33 = refinedSoundex25.difference("hi!", "");
        int int36 = refinedSoundex25.difference("hi!", "");
        char char38 = refinedSoundex25.getMappingCode('4');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = doubleMetaphone0.encode((java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(refinedSoundex25);
        org.junit.Assert.assertTrue("'" + char27 + "' != '" + '0' + "'", char27 == '0');
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + char38 + "' != '" + '\000' + "'", char38 == '\000');
    }

    @Test
    public void test0935() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0935");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str14 = refinedSoundex0.soundex("AKPKMNSKT1");
        char char16 = refinedSoundex0.getMappingCode('g');
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "A0313836" + "'", str14, "A0313836");
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '4' + "'", char16 == '4');
    }

    @Test
    public void test0936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0936");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength((int) (byte) -1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = soundex1.soundex("org.apache.commons.codec.EncoderException: 01230120022455012623010202");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0937() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0937");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult13 = doubleMetaphone0.new DoubleMetaphoneResult(38);
        org.apache.commons.codec.language.Metaphone metaphone14 = new org.apache.commons.codec.language.Metaphone();
        metaphone14.setMaxCodeLen(3);
        int int17 = metaphone14.getMaxCodeLen();
        boolean boolean20 = metaphone14.isMetaphoneEqual("", "");
        boolean boolean23 = metaphone14.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone14.setMaxCodeLen(0);
        int int26 = metaphone14.getMaxCodeLen();
        metaphone14.setMaxCodeLen((int) (short) 100);
        int int29 = metaphone14.getMaxCodeLen();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = doubleMetaphone0.encode((java.lang.Object) metaphone14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: DoubleMetaphone encode parameter is not of type String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
    }

    @Test
    public void test0938() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0938");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        int int9 = soundex3.difference("A111111111", "01230120022455012623010202");
        int int10 = soundex3.getMaxLength();
        soundex3.setMaxLength((int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone13.maxCodeLen = 0;
        java.lang.String str17 = doubleMetaphone13.encode("A621");
        boolean boolean21 = doubleMetaphone13.isDoubleMetaphoneEqual("O0940103030808306030830609053016080931", "", true);
        java.lang.String str23 = doubleMetaphone13.encode("");
        boolean boolean27 = doubleMetaphone13.isDoubleMetaphoneEqual("A621", "org.apache.commons.codec.EncoderException: hi!", false);
        doubleMetaphone13.maxCodeLen = '0';
        int int30 = doubleMetaphone13.getMaxCodeLen();
        boolean boolean34 = doubleMetaphone13.isDoubleMetaphoneEqual("ARK", "AKPKKMNSKT", true);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj35 = soundex3.encode((java.lang.Object) "AKPKKMNSKT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: K");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 48 + "'", int30 == 48);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test0939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0939");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = soundex1.encode("ARK");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }

    @Test
    public void test0940() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0940");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        java.lang.String str8 = soundex3.encode("1111111111");
        soundex3.setMaxLength((int) (short) -1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
    }

    @Test
    public void test0941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0941");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.caverphone("A");
        java.lang.String str11 = caverphone0.caverphone("");
        java.lang.String str13 = caverphone0.encode(" ");
        boolean boolean16 = caverphone0.isCaverphoneEqual("ORGAPACHECOMMONSCODECENCODEREXCEPTION", "KPK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "1111111111" + "'", str11, "1111111111");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "1111111111" + "'", str13, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test0942() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0942");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        soundex3.setMaxLength(10);
        int int6 = soundex3.getMaxLength();
        int int9 = soundex3.difference("A111111111", "01230120022455012623010202");
        int int10 = soundex3.getMaxLength();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str13 = doubleMetaphone11.doubleMetaphone("H");
        doubleMetaphone11.setMaxCodeLen((int) (byte) 0);
        java.lang.String str18 = doubleMetaphone11.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult20 = doubleMetaphone11.new DoubleMetaphoneResult(0);
        int int21 = doubleMetaphone11.getMaxCodeLen();
        java.lang.String str24 = doubleMetaphone11.doubleMetaphone("AK11111111", true);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = soundex3.encode((java.lang.Object) doubleMetaphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Soundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
    }

    @Test
    public void test0943() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0943");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        int int5 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) '1');
        int int8 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 49 + "'", int8 == 49);
    }

    @Test
    public void test0944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0944");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        int int9 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) caverphone0, "AA11111111", "hi!");
        java.lang.String str11 = caverphone0.encode("O0940103030808306030830609053016080");
        boolean boolean14 = caverphone0.isCaverphoneEqual("", "I000");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "A111111111" + "'", str11, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test0945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0945");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (byte) 1);
        java.lang.String str10 = metaphone0.encode("A621");
        int int11 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen(49);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "A" + "'", str10, "A");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test0946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0946");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone5 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str7 = caverphone5.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str9 = caverphone5.caverphone("hi!");
        java.lang.Object obj10 = metaphone0.encode((java.lang.Object) "hi!");
        java.lang.String str12 = metaphone0.encode("");
        java.lang.String str14 = metaphone0.encode("O0940103030808306030830609053016080");
        java.lang.String str16 = metaphone0.metaphone("org.apache.commons.codec.EncoderException: ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        java.lang.String str18 = metaphone0.metaphone("A093153836383693158");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "AKPKKMNSKT" + "'", str7, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "AA11111111" + "'", str9, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj10 + "' != '" + "H" + "'", obj10, "H");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "O" + "'", str14, "O");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP" + "'", str16, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "A" + "'", str18, "A");
    }

    @Test
    public void test0947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0947");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.caverphone("01230120022455012623010202");
        java.lang.String str27 = caverphone0.encode("A09313836383693158931");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A111111111" + "'", str27, "A111111111");
    }

    @Test
    public void test0948() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0948");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex3 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = refinedSoundex6.soundex("A621HIo");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 7 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0949() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0949");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = soundex1.soundex("O620");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
    }

    @Test
    public void test0950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0950");
        char[] charArray0 = null;
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str3 = refinedSoundex1.soundex("AA");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test0951() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0951");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.encode("");
        boolean boolean28 = caverphone0.isCaverphoneEqual("", "A#");
        java.lang.String str30 = caverphone0.caverphone("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        java.lang.String str32 = caverphone0.encode(" AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AKPKMNSKTK" + "'", str30, "AKPKMNSKTK");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "AKPKMNSKTK" + "'", str32, "AKPKMNSKTK");
    }

    @Test
    public void test0952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0952");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A111111111O000", "A313");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test0953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0953");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        char[] charArray3 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray3);
        org.apache.commons.codec.language.Soundex soundex5 = new org.apache.commons.codec.language.Soundex(charArray3);
        soundex5.setMaxLength((int) '1');
        java.lang.Class<?> wildcardClass8 = soundex5.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = metaphone0.encode((java.lang.Object) wildcardClass8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test0954() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0954");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex1 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str3 = refinedSoundex1.encode("AA11111111");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "A0" + "'", str3, "A0");
    }

    @Test
    public void test0955() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0955");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        int int7 = metaphone0.getMaxCodeLen();
        int int8 = metaphone0.getMaxCodeLen();
        boolean boolean11 = metaphone0.isMetaphoneEqual("O0931", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        metaphone0.setMaxCodeLen((int) 'A');
        int int14 = metaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str17 = doubleMetaphone15.doubleMetaphone("H");
        doubleMetaphone15.setMaxCodeLen((int) (byte) 0);
        java.lang.String str22 = doubleMetaphone15.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult24 = doubleMetaphone15.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult24.append('#', 'a');
        doubleMetaphoneResult24.append('O');
        doubleMetaphoneResult24.append("O621", "org.apache.commons.codec.EncoderException: A0");
        java.lang.String str33 = doubleMetaphoneResult24.getPrimary();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = metaphone0.encode((java.lang.Object) doubleMetaphoneResult24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 65 + "'", int14 == 65);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
    }

    @Test
    public void test0956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0956");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        boolean boolean15 = metaphone0.isMetaphoneEqual("A0", "org.apache.commons.codec.EncoderException: HI");
        boolean boolean18 = metaphone0.isMetaphoneEqual("O093", "HI");
        org.apache.commons.codec.language.Metaphone metaphone19 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str21 = metaphone19.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone19.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone24 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str26 = caverphone24.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str28 = caverphone24.caverphone("hi!");
        java.lang.Object obj29 = metaphone19.encode((java.lang.Object) "hi!");
        java.lang.String str31 = metaphone19.encode("O0940103030808306030830609053016080");
        java.lang.Object obj32 = metaphone0.encode((java.lang.Object) str31);
        char[] charArray33 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex34 = new org.apache.commons.codec.language.Soundex(charArray33);
        int int35 = soundex34.getMaxLength();
        int int36 = soundex34.getMaxLength();
        int int39 = soundex34.difference("ORKP", "O0");
        int int40 = soundex34.getMaxLength();
        java.lang.String str42 = soundex34.encode("HI");
        soundex34.setMaxLength(0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj45 = metaphone0.encode((java.lang.Object) soundex34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "ORKP" + "'", str21, "ORKP");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "AKPKKMNSKT" + "'", str26, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "AA11111111" + "'", str28, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "H" + "'", obj29, "H");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "O" + "'", str31, "O");
        org.junit.Assert.assertEquals("'" + obj32 + "' != '" + "O" + "'", obj32, "O");
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "H000" + "'", str42, "H000");
    }

    @Test
    public void test0957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0957");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("A1111111114r", "org.apache.commons.codec.EncoderException: AA11111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0958() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0958");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.encode("A1");
        int int16 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "", "O000");
        char char18 = refinedSoundex0.getMappingCode('a');
        java.lang.String str20 = refinedSoundex0.encode("1111111111");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0" + "'", str13, "A0");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + '0' + "'", char18 == '0');
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
    }

    @Test
    public void test0959() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0959");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        char char10 = refinedSoundex0.getMappingCode('#');
        java.lang.String str12 = refinedSoundex0.encode("AKPKMNSKT");
        java.lang.String str14 = refinedSoundex0.soundex("H0");
        int int17 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) refinedSoundex0, "ORGAPACHECOMMONSCODECENCODEREXCEPTION", "O0940103030808306030830609053016080931");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone18 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str20 = doubleMetaphone18.doubleMetaphone("H");
        doubleMetaphone18.maxCodeLen = '0';
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = refinedSoundex0.encode((java.lang.Object) '0');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + '\000' + "'", char10 == '\000');
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A0313836" + "'", str12, "A0313836");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "H0" + "'", str14, "H0");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
    }

    @Test
    public void test0960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0960");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.String str12 = metaphone0.metaphone("hi!");
        boolean boolean15 = metaphone0.isMetaphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        char[] charArray16 = null;
        org.apache.commons.codec.language.Soundex soundex17 = new org.apache.commons.codec.language.Soundex(charArray16);
        java.lang.String str19 = soundex17.soundex("");
        java.lang.String str21 = soundex17.encode("");
        soundex17.setMaxLength(0);
        java.lang.String str25 = soundex17.soundex("");
        java.lang.String str27 = soundex17.soundex("");
        java.lang.Object obj28 = metaphone0.encode((java.lang.Object) "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "" + "'", obj28, "");
    }

    @Test
    public void test0961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0961");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        java.lang.String str10 = metaphone0.encode("O0");
        boolean boolean13 = metaphone0.isMetaphoneEqual("AK11111111", "A621");
        int int14 = metaphone0.getMaxCodeLen();
        int int15 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "O" + "'", str10, "O");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test0962() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0962");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(0);
        java.lang.String str4 = metaphone0.metaphone("A0");
        java.lang.String str6 = metaphone0.encode("H");
        org.apache.commons.codec.language.Metaphone metaphone7 = new org.apache.commons.codec.language.Metaphone();
        metaphone7.setMaxCodeLen(3);
        java.lang.String str11 = metaphone7.encode("");
        java.lang.String str13 = metaphone7.encode("");
        metaphone7.setMaxCodeLen((int) (short) 10);
        int int16 = metaphone7.getMaxCodeLen();
        java.lang.String str18 = metaphone7.encode("ORKP");
        java.lang.String str20 = metaphone7.encode("hi!");
        int int21 = metaphone7.getMaxCodeLen();
        int int24 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone7, "ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP", "AKPKMNSKT");
        java.lang.String str26 = metaphone7.metaphone("A#");
        java.lang.Object obj27 = metaphone0.encode((java.lang.Object) "A#");
        boolean boolean30 = metaphone0.isMetaphoneEqual("", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONA");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "H" + "'", str6, "H");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ORKP" + "'", str18, "ORKP");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "H" + "'", str20, "H");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "A" + "'", str26, "A");
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + "" + "'", obj27, "");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test0963() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0963");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray0);
        soundex4.setMaxLength(0);
        int int7 = soundex4.getMaxLength();
        java.lang.String str9 = soundex4.soundex("ORKPXKMNSKTKNKTRKSSPXNRKPKSKMNSKTKNKTRKSPKSN");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O621" + "'", str9, "O621");
    }

    @Test
    public void test0964() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0964");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        java.lang.String str6 = metaphone0.encode("A0");
        java.lang.String str8 = metaphone0.encode("ARKP");
        boolean boolean11 = metaphone0.isMetaphoneEqual("H0", "AKPKMNSKT");
        java.lang.String str13 = metaphone0.metaphone("");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A" + "'", str6, "A");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "ARKP" + "'", str8, "ARKP");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
    }

    @Test
    public void test0965() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0965");
        char[] charArray0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        int int2 = soundex1.getMaxLength();
        int int3 = soundex1.getMaxLength();
        int int6 = soundex1.difference("ORKP", "O0");
        int int7 = soundex1.getMaxLength();
        int int8 = soundex1.getMaxLength();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test0966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0966");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        metaphone0.setMaxCodeLen((int) '0');
        metaphone0.setMaxCodeLen(0);
        boolean boolean19 = metaphone0.isMetaphoneEqual("O621", "AKP1111111");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone20 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone20.maxCodeLen = 0;
        char char25 = doubleMetaphone20.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        java.lang.String str27 = doubleMetaphone20.encode("A");
        java.lang.Object obj29 = doubleMetaphone20.encode((java.lang.Object) "org.apache.commons.codec.EncoderException: ORKP");
        int int30 = doubleMetaphone20.getMaxCodeLen();
        java.lang.String str33 = doubleMetaphone20.doubleMetaphone("A", false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = metaphone0.encode((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '\000' + "'", char25 == '\000');
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "" + "'", obj29, "");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
    }

    @Test
    public void test0967() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0967");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.caverphone("hi!");
        java.lang.String str6 = caverphone0.caverphone("");
        java.lang.String str8 = caverphone0.caverphone("HI");
        boolean boolean11 = caverphone0.isCaverphoneEqual("A111111111", "HI");
        boolean boolean14 = caverphone0.isCaverphoneEqual(" org.apache.commons.codec.EncoderException: ORGAP", "A1");
        org.apache.commons.codec.language.Metaphone metaphone15 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str17 = metaphone15.encode("org.apache.commons.codec.EncoderException: HI");
        metaphone15.setMaxCodeLen((int) (byte) 100);
        org.apache.commons.codec.language.Caverphone caverphone20 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str22 = caverphone20.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str24 = caverphone20.caverphone("hi!");
        java.lang.Object obj25 = metaphone15.encode((java.lang.Object) "hi!");
        java.lang.String str27 = metaphone15.encode("");
        java.lang.Object obj28 = caverphone0.encode((java.lang.Object) "");
        java.lang.String str30 = caverphone0.caverphone("AO");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AA11111111" + "'", str4, "AA11111111");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "AA11111111" + "'", str8, "AA11111111");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ORKP" + "'", str17, "ORKP");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "AKPKKMNSKT" + "'", str22, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "AA11111111" + "'", str24, "AA11111111");
        org.junit.Assert.assertEquals("'" + obj25 + "' != '" + "H" + "'", obj25, "H");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + "1111111111" + "'", obj28, "1111111111");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "AA11111111" + "'", str30, "AA11111111");
    }

    @Test
    public void test0968() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0968");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int10 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test0969() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0969");
        char[] charArray0 = null;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        java.lang.String str3 = soundex1.soundex("");
        java.lang.String str5 = soundex1.encode("");
        soundex1.setMaxLength(0);
        soundex1.setMaxLength((int) (byte) -1);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone10 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone10.maxCodeLen = 0;
        char char15 = doubleMetaphone10.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult17 = doubleMetaphone10.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult17.append(' ');
        doubleMetaphoneResult17.appendPrimary("A621");
        doubleMetaphoneResult17.append("O621", "AA11111111");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = soundex1.encode((java.lang.Object) "O621");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + char15 + "' != '" + '\000' + "'", char15 == '\000');
    }

    @Test
    public void test0970() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0970");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ORKPXKMNSKTKNKTRKSK");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORKPXKMNSKTKNKTRKSK" + "'", str1, "ORKPXKMNSKTKNKTRKSK");
    }

    @Test
    public void test0971() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0971");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        int int12 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) metaphone0, "01230120022455012623010202", "");
        java.lang.String str14 = metaphone0.encode("HI");
        java.lang.String str16 = metaphone0.encode("A212");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "H" + "'", str14, "H");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "A" + "'", str16, "A");
    }

    @Test
    public void test0972() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0972");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("O621");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "O" + "'", str1, "O");
    }

    @Test
    public void test0973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0973");
        char[] charArray0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_MAPPING;
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray0);
        java.lang.String str6 = refinedSoundex4.encode("");
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test0974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0974");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("O621");
        boolean boolean7 = caverphone0.isCaverphoneEqual("org.apache.commons.codec.EncoderException: HI", "A621");
        java.lang.String str9 = caverphone0.encode("A1");
        java.lang.Class<?> wildcardClass10 = caverphone0.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A111111111" + "'", str4, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A111111111" + "'", str9, "A111111111");
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test0975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0975");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        boolean boolean6 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean9 = metaphone0.isMetaphoneEqual("01230120022455012623010202", "");
        metaphone0.setMaxCodeLen(0);
        int int12 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (short) 100);
        int int15 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) '4');
        boolean boolean20 = metaphone0.isMetaphoneEqual("ARKPKSKMNSKTKNKTRKSPKSNRKPKSKMNSK", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone21 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone21.maxCodeLen = 0;
        char char26 = doubleMetaphone21.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        boolean boolean30 = doubleMetaphone21.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: HI", "hi!", false);
        char char33 = doubleMetaphone21.charAt("01230120022455012623010202", (int) (short) 1);
        char char36 = doubleMetaphone21.charAt("O0940103030808306030830609053016080931", 0);
        doubleMetaphone21.maxCodeLen = (byte) 10;
        boolean boolean41 = doubleMetaphone21.isDoubleMetaphoneEqual("org.apache.commons.codec.EncoderException: org.apache.commons.codec.EncoderException: A0", "O0940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult43 = doubleMetaphone21.new DoubleMetaphoneResult(0);
        doubleMetaphoneResult43.appendPrimary('i');
        doubleMetaphoneResult43.append('.');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj48 = metaphone0.encode((java.lang.Object) '.');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + char26 + "' != '" + '\000' + "'", char26 == '\000');
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + char33 + "' != '" + '1' + "'", char33 == '1');
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + 'O' + "'", char36 == 'O');
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test0976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0976");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        int int14 = metaphone0.getMaxCodeLen();
        boolean boolean17 = metaphone0.isMetaphoneEqual("AKPKMNSKT", "AKPKMNSKT");
        metaphone0.setMaxCodeLen(0);
        boolean boolean22 = metaphone0.isMetaphoneEqual("AKPK", "");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex23 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char25 = refinedSoundex23.getMappingCode('a');
        int int28 = refinedSoundex23.difference("", "hi!");
        char char30 = refinedSoundex23.getMappingCode('0');
        char char32 = refinedSoundex23.getMappingCode('a');
        java.lang.String str34 = refinedSoundex23.soundex("1111111111");
        char char36 = refinedSoundex23.getMappingCode('0');
        java.lang.String str38 = refinedSoundex23.encode("O");
        org.apache.commons.codec.language.Caverphone caverphone39 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str41 = caverphone39.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str43 = caverphone39.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str45 = caverphone39.encode("");
        java.lang.String str47 = caverphone39.encode("1111111111");
        java.lang.Object obj48 = refinedSoundex23.encode((java.lang.Object) "1111111111");
        java.lang.String str50 = refinedSoundex23.encode("ORK");
        java.lang.Object obj51 = metaphone0.encode((java.lang.Object) str50);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(refinedSoundex23);
        org.junit.Assert.assertTrue("'" + char25 + "' != '" + '0' + "'", char25 == '0');
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + char30 + "' != '" + '\000' + "'", char30 == '\000');
        org.junit.Assert.assertTrue("'" + char32 + "' != '" + '0' + "'", char32 == '0');
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + '\000' + "'", char36 == '\000');
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "O0" + "'", str38, "O0");
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "AKPKKMNSKT" + "'", str41, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "AKPKKMNSKT" + "'", str43, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "1111111111" + "'", str45, "1111111111");
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "1111111111" + "'", str47, "1111111111");
        org.junit.Assert.assertEquals("'" + obj48 + "' != '" + "" + "'", obj48, "");
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "O093" + "'", str50, "O093");
        org.junit.Assert.assertEquals("'" + obj51 + "' != '" + "" + "'", obj51, "");
    }

    @Test
    public void test0977() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0977");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A000");
        boolean boolean9 = caverphone0.isCaverphoneEqual("A111111111O000", "A1");
        org.apache.commons.codec.language.Metaphone metaphone10 = new org.apache.commons.codec.language.Metaphone();
        metaphone10.setMaxCodeLen(3);
        int int13 = metaphone10.getMaxCodeLen();
        java.lang.String str15 = metaphone10.encode("hi!");
        java.lang.String str17 = metaphone10.encode("O621");
        java.lang.String str19 = metaphone10.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str21 = metaphone10.encode("");
        java.lang.Class<?> wildcardClass22 = metaphone10.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = caverphone0.encode((java.lang.Object) metaphone10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "H" + "'", str15, "H");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "O" + "'", str17, "O");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "O" + "'", str19, "O");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test0978() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0978");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        java.lang.String str10 = caverphone0.encode("org.apache.commons.codec.EncoderException: A0");
        java.lang.String str12 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: A000");
        java.lang.String str14 = caverphone0.encode("ORKPXKMNSKTKNKTRKSK");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKKMNSKT" + "'", str10, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "AKPKKMNSKT" + "'", str12, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "AKPKMNSKTK" + "'", str14, "AKPKMNSKTK");
    }

    @Test
    public void test0979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0979");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP" + "'", str1, "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
    }

    @Test
    public void test0980() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0980");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        java.lang.String str4 = metaphone0.encode("");
        java.lang.String str6 = metaphone0.encode("");
        metaphone0.setMaxCodeLen((int) (short) 10);
        int int9 = metaphone0.getMaxCodeLen();
        java.lang.String str11 = metaphone0.encode("ORKP");
        int int12 = metaphone0.getMaxCodeLen();
        int int13 = metaphone0.getMaxCodeLen();
        java.lang.Object obj14 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj15 = metaphone0.encode(obj14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "ORKP" + "'", str11, "ORKP");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test0981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0981");
        char[] charArray1 = new char[] { 'a' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex2 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex3 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        org.apache.commons.codec.language.Soundex soundex4 = new org.apache.commons.codec.language.Soundex(charArray1);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = refinedSoundex5.soundex("K");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertArrayEquals(charArray1, new char[] { 'a' });
    }

    @Test
    public void test0982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0982");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("");
        java.lang.String str8 = caverphone0.encode("01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone9 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone9.maxCodeLen = 0;
        char char14 = doubleMetaphone9.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult16 = doubleMetaphone9.new DoubleMetaphoneResult((int) (byte) -1);
        doubleMetaphoneResult16.appendAlternate('\000');
        java.lang.String str19 = doubleMetaphoneResult16.getAlternate();
        java.lang.String str20 = doubleMetaphoneResult16.getPrimary();
        java.lang.Object obj21 = caverphone0.encode((java.lang.Object) str20);
        java.lang.String str23 = caverphone0.caverphone("");
        java.lang.String str25 = caverphone0.caverphone("01230120022455012623010202");
        java.lang.String str27 = caverphone0.caverphone("O941");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "1111111111" + "'", str6, "1111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "1111111111" + "'", str8, "1111111111");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + '\000' + "'", char14 == '\000');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + "1111111111" + "'", obj21, "1111111111");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "1111111111" + "'", str23, "1111111111");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "1111111111" + "'", str25, "1111111111");
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "A111111111" + "'", str27, "A111111111");
    }

    @Test
    public void test0983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0983");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str2 = doubleMetaphone0.doubleMetaphone("H");
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("");
        java.lang.String str7 = doubleMetaphone0.doubleMetaphone("ORKP", true);
        int int10 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone0, "O621", "A111111111");
        int int11 = doubleMetaphone0.getMaxCodeLen();
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult13 = doubleMetaphone0.new DoubleMetaphoneResult(38);
        doubleMetaphoneResult13.appendPrimary('A');
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "ARKP" + "'", str7, "ARKP");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test0984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0984");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("");
        boolean boolean10 = metaphone0.isMetaphoneEqual("", "H");
        java.lang.String str12 = metaphone0.encode("O0940103030808306030830609053016080940103030808306030830609053016080");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone13 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str15 = doubleMetaphone13.doubleMetaphone("H");
        doubleMetaphone13.setMaxCodeLen((int) (byte) 0);
        java.lang.String str20 = doubleMetaphone13.doubleMetaphone("", false);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult22 = doubleMetaphone13.new DoubleMetaphoneResult(0);
        int int23 = doubleMetaphone13.maxCodeLen;
        java.lang.String str25 = doubleMetaphone13.encode("O941");
        int int26 = doubleMetaphone13.maxCodeLen;
        java.lang.String str28 = doubleMetaphone13.encode("org.apache.commons.codec.EncoderException: org.ap");
        java.lang.Object obj29 = metaphone0.encode((java.lang.Object) str28);
        java.lang.String str31 = metaphone0.encode("K");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "O" + "'", str12, "O");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + obj29 + "' != '" + "" + "'", obj29, "");
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "K" + "'", str31, "K");
    }

    @Test
    public void test0985() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0985");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        java.lang.String str9 = metaphone0.metaphone("O0940103030808306030830609053016080940103030808306030830609053016080");
        java.lang.String str11 = metaphone0.encode("");
        java.lang.String str13 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "O" + "'", str9, "O");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "ORK" + "'", str13, "ORK");
    }

    @Test
    public void test0986() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0986");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        char char13 = refinedSoundex0.getMappingCode('4');
        java.lang.String str15 = refinedSoundex0.encode("org.apache.commons.codec.EncoderException: ORKPXKMNSKTKNKTRKSSPXNRKPXKMNSKTSNKTRKSSPXNRKP");
        char char17 = refinedSoundex0.getMappingCode('1');
        java.lang.Object obj19 = refinedSoundex0.encode((java.lang.Object) "A ");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '\000' + "'", char13 == '\000');
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "O09401030308083060308306090530160809315383638369315893153836383693158931" + "'", str15, "O09401030308083060308306090530160809315383638369315893153836383693158931");
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + '\000' + "'", char17 == '\000');
        org.junit.Assert.assertEquals("'" + obj19 + "' != '" + "A0" + "'", obj19, "A0");
    }

    @Test
    public void test0987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0987");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        metaphone0.setMaxCodeLen(3);
        int int3 = metaphone0.getMaxCodeLen();
        java.lang.String str5 = metaphone0.encode("hi!");
        java.lang.String str7 = metaphone0.encode("O621");
        boolean boolean10 = metaphone0.isMetaphoneEqual("A", "A");
        metaphone0.setMaxCodeLen(0);
        java.lang.String str14 = metaphone0.encode("A1");
        int int15 = metaphone0.getMaxCodeLen();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "H" + "'", str5, "H");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "O" + "'", str7, "O");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test0988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0988");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = new org.apache.commons.codec.language.RefinedSoundex();
        char char2 = refinedSoundex0.getMappingCode('0');
        int int5 = refinedSoundex0.difference("O0", "O0");
        char char7 = refinedSoundex0.getMappingCode(' ');
        java.lang.String str9 = refinedSoundex0.soundex("A09315383");
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '\000' + "'", char2 == '\000');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A0" + "'", str9, "A0");
    }

    @Test
    public void test0989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0989");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        int int8 = refinedSoundex0.difference("hi!", "");
        int int11 = refinedSoundex0.difference("hi!", "");
        java.lang.String str13 = refinedSoundex0.encode("AKPKMNSKT");
        int int16 = refinedSoundex0.difference("AA11111111", "01230120022455012623010202");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone17 = new org.apache.commons.codec.language.DoubleMetaphone();
        java.lang.String str19 = doubleMetaphone17.doubleMetaphone("H");
        doubleMetaphone17.setMaxCodeLen((int) (byte) 0);
        java.lang.String str23 = doubleMetaphone17.encode("H");
        boolean boolean27 = doubleMetaphone17.isDoubleMetaphoneEqual("ORKP", "O0", true);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult29 = doubleMetaphone17.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult29.appendAlternate('O');
        doubleMetaphoneResult29.appendPrimary('O');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj34 = refinedSoundex0.encode((java.lang.Object) 'O');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to RefinedSoundex encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0313836" + "'", str13, "A0313836");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test0990() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0990");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.metaphone("A");
        int int5 = metaphone0.getMaxCodeLen();
        java.lang.String str7 = metaphone0.encode("A062125232523621256212523252362125");
        java.lang.String str9 = metaphone0.encode("ORKPXKMNSK");
        metaphone0.setMaxCodeLen(79);
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone12 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone12.maxCodeLen = '\000';
        boolean boolean17 = doubleMetaphone12.isDoubleMetaphoneEqual("ORKP", "H");
        doubleMetaphone12.maxCodeLen = 0;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj20 = metaphone0.encode((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "A" + "'", str4, "A");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "A" + "'", str7, "A");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "ORKP" + "'", str9, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test0991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0991");
        char[] charArray4 = new char[] { ' ', '#', '#', '0' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex6 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex7 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        org.apache.commons.codec.language.Metaphone metaphone8 = new org.apache.commons.codec.language.Metaphone();
        metaphone8.setMaxCodeLen(3);
        int int11 = metaphone8.getMaxCodeLen();
        boolean boolean14 = metaphone8.isMetaphoneEqual("", "");
        boolean boolean17 = metaphone8.isMetaphoneEqual("01230120022455012623010202", "");
        boolean boolean20 = metaphone8.isMetaphoneEqual("A621", "");
        boolean boolean23 = metaphone8.isMetaphoneEqual("AKPKKMNSKT", "A111111111");
        java.lang.String str25 = metaphone8.metaphone("");
        java.lang.Object obj26 = refinedSoundex7.encode((java.lang.Object) str25);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertArrayEquals(charArray4, new char[] { ' ', '#', '#', '0' });
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertEquals("'" + obj26 + "' != '" + "" + "'", obj26, "");
    }

    @Test
    public void test0992() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0992");
        int int2 = org.apache.commons.codec.language.SoundexUtils.differenceEncoded("ORKPXKMNSKTKNKTRKSSPXNH", "AK11111111");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test0993() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0993");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH;
        soundex0.setMaxLength((int) (byte) -1);
        int int3 = soundex0.getMaxLength();
        soundex0.setMaxLength((int) (short) -1);
        int int8 = soundex0.difference("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKPXKMNSK", "ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        org.junit.Assert.assertNotNull(soundex0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test0994() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0994");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        boolean boolean5 = metaphone0.isMetaphoneEqual("hi!", "");
        java.lang.String str7 = metaphone0.encode("H000");
        java.lang.String str9 = metaphone0.metaphone("A111111111");
        java.lang.String str11 = metaphone0.metaphone("r");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "A" + "'", str9, "A");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "R" + "'", str11, "R");
    }

    @Test
    public void test0995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0995");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("org.apache.commons.codec.EncoderException: ORKP");
        boolean boolean7 = metaphone0.isMetaphoneEqual("", "");
        boolean boolean10 = metaphone0.isMetaphoneEqual("org.apache.commons.codec.EncoderException: ORKP", "");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone11 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone11.maxCodeLen = 0;
        char char16 = doubleMetaphone11.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult18 = doubleMetaphone11.new DoubleMetaphoneResult((int) '#');
        int int19 = doubleMetaphone11.maxCodeLen;
        java.lang.String str21 = doubleMetaphone11.encode("O");
        int int24 = org.apache.commons.codec.language.SoundexUtils.difference((org.apache.commons.codec.StringEncoder) doubleMetaphone11, "A031383", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = metaphone0.encode((java.lang.Object) doubleMetaphone11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + char16 + "' != '" + '\000' + "'", char16 == '\000');
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test0996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0996");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("");
        int int3 = metaphone0.getMaxCodeLen();
        metaphone0.setMaxCodeLen((int) (byte) 10);
        boolean boolean8 = metaphone0.isMetaphoneEqual("A111111111", "org.apache.commons.codec.EncoderException: HI");
        metaphone0.setMaxCodeLen((int) (byte) 0);
        java.lang.Object obj11 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = metaphone0.encode(obj11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test0997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0997");
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH;
        char char2 = refinedSoundex0.getMappingCode('a');
        int int5 = refinedSoundex0.difference("", "hi!");
        char char7 = refinedSoundex0.getMappingCode('0');
        char char9 = refinedSoundex0.getMappingCode('a');
        java.lang.String str11 = refinedSoundex0.soundex("1111111111");
        java.lang.String str13 = refinedSoundex0.encode("A1");
        java.lang.String str15 = refinedSoundex0.soundex("AKPKMNSKTK");
        org.junit.Assert.assertNotNull(refinedSoundex0);
        org.junit.Assert.assertTrue("'" + char2 + "' != '" + '0' + "'", char2 == '0');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\000' + "'", char7 == '\000');
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + '0' + "'", char9 == '0');
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "A0" + "'", str13, "A0");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "A03138363" + "'", str15, "A03138363");
    }

    @Test
    public void test0998() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0998");
        org.apache.commons.codec.language.Caverphone caverphone0 = new org.apache.commons.codec.language.Caverphone();
        java.lang.String str2 = caverphone0.caverphone("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = caverphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str6 = caverphone0.encode("A");
        java.lang.String str8 = caverphone0.caverphone("O0931");
        java.lang.String str10 = caverphone0.encode("AKPKMNSKT1");
        java.lang.String str12 = caverphone0.encode("H000");
        java.lang.String str14 = caverphone0.caverphone("#");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone15 = new org.apache.commons.codec.language.DoubleMetaphone();
        doubleMetaphone15.maxCodeLen = 0;
        char char20 = doubleMetaphone15.charAt("org.apache.commons.codec.EncoderException: HI", (int) (short) 100);
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult22 = doubleMetaphone15.new DoubleMetaphoneResult((int) '#');
        doubleMetaphoneResult22.appendAlternate("A111111111");
        java.lang.String str25 = doubleMetaphoneResult22.getAlternate();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj26 = caverphone0.encode((java.lang.Object) doubleMetaphoneResult22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Caverphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "AKPKKMNSKT" + "'", str2, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AKPKKMNSKT" + "'", str4, "AKPKKMNSKT");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "A111111111" + "'", str6, "A111111111");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "A111111111" + "'", str8, "A111111111");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "AKPKMNSKT1" + "'", str10, "AKPKMNSKT1");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "A111111111" + "'", str12, "A111111111");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "1111111111" + "'", str14, "1111111111");
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + '\000' + "'", char20 == '\000');
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "A111111111" + "'", str25, "A111111111");
    }

    @Test
    public void test0999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0999");
        org.apache.commons.codec.language.Metaphone metaphone0 = new org.apache.commons.codec.language.Metaphone();
        java.lang.String str2 = metaphone0.encode("org.apache.commons.codec.EncoderException: HI");
        java.lang.String str4 = metaphone0.encode("ORGAPACHECOMMONSCODECENCODEREXCEPTIONHI");
        org.apache.commons.codec.EncoderException encoderException6 = new org.apache.commons.codec.EncoderException("hi!");
        org.apache.commons.codec.EncoderException encoderException8 = new org.apache.commons.codec.EncoderException("HI");
        org.apache.commons.codec.EncoderException encoderException10 = new org.apache.commons.codec.EncoderException("");
        java.lang.Throwable[] throwableArray11 = encoderException10.getSuppressed();
        org.apache.commons.codec.EncoderException encoderException13 = new org.apache.commons.codec.EncoderException("ORGAPACHECOMMONSCODECENCODEREXCEPTIONORKP");
        encoderException10.addSuppressed((java.lang.Throwable) encoderException13);
        encoderException8.addSuppressed((java.lang.Throwable) encoderException13);
        org.apache.commons.codec.EncoderException encoderException17 = new org.apache.commons.codec.EncoderException("");
        org.apache.commons.codec.EncoderException encoderException19 = new org.apache.commons.codec.EncoderException("HI");
        java.lang.Throwable[] throwableArray20 = encoderException19.getSuppressed();
        encoderException17.addSuppressed((java.lang.Throwable) encoderException19);
        org.apache.commons.codec.EncoderException encoderException23 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.EncoderException: A0");
        encoderException19.addSuppressed((java.lang.Throwable) encoderException23);
        java.lang.Throwable[] throwableArray25 = encoderException19.getSuppressed();
        encoderException8.addSuppressed((java.lang.Throwable) encoderException19);
        encoderException6.addSuppressed((java.lang.Throwable) encoderException8);
        java.lang.Throwable[] throwableArray28 = encoderException8.getSuppressed();
        java.lang.Throwable[] throwableArray29 = encoderException8.getSuppressed();
        java.lang.Throwable[] throwableArray30 = encoderException8.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj31 = metaphone0.encode((java.lang.Object) encoderException8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Metaphone encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ORKP" + "'", str2, "ORKP");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "ORKP" + "'", str4, "ORKP");
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertArrayEquals(throwableArray11, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertArrayEquals(throwableArray20, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray30);
    }

    @Test
    public void test1000() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test1000");
        java.lang.String str1 = org.apache.commons.codec.language.SoundexUtils.clean("A09315383");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "A" + "'", str1, "A");
    }
}
