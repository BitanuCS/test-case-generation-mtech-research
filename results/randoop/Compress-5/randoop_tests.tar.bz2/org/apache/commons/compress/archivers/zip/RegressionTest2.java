package org.apache.commons.compress.archivers.zip;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1001");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField6 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int7 = asiExtraField6.getGroupId();
        asiExtraField6.setDirectory(true);
        byte[] byteArray10 = asiExtraField6.getCentralDirectoryData();
        java.io.InputStream inputStream11 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream12 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream11);
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        byte[] byteArray15 = inputStream13.readNBytes((int) (short) 100);
        int int18 = zipArchiveInputStream12.read(byteArray15, (int) ' ', 40960);
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry0, byteArray10, byteArray15);
        zipArchiveEntry0.setInternalAttributes(16384);
        long long22 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setTime(420L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] {});
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test1002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1002");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        boolean boolean8 = zipArchiveEntry0.isDirectory();
        zipArchiveEntry0.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        byte[] byteArray12 = zipArchiveEntry0.getLocalFileDataExtra();
        long long13 = zipArchiveEntry0.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry14 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        java.io.InputStream inputStream15 = java.io.InputStream.nullInputStream();
        byte[] byteArray17 = inputStream15.readNBytes((int) (short) 100);
        boolean boolean18 = inputStream15.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream21 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream15, "UTF8", true);
        zipArchiveInputStream21.close();
        boolean boolean23 = zipArchiveEntry14.equals((java.lang.Object) zipArchiveInputStream21);
        long long24 = zipArchiveEntry14.getSize();
        zipArchiveEntry14.setExtra();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] {});
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5L + "'", long13 == 5L);
        org.junit.Assert.assertNotNull(inputStream15);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5L + "'", long24 == 5L);
    }

    @Test
    public void test1003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1003");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes(0L);
        int int13 = zipArchiveInputStream8.read(byteArray10, 36863, (int) (byte) 10);
        long long15 = zipArchiveInputStream8.skip(4294967295L);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test1004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1004");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        zipArchiveInputStream1.mark(5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = zipArchiveInputStream1.getNextZipEntry();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry9 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry10 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry11 = zipArchiveInputStream1.getNextEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(zipArchiveEntry8);
        org.junit.Assert.assertNull(archiveEntry9);
        org.junit.Assert.assertNull(archiveEntry10);
        org.junit.Assert.assertNull(archiveEntry11);
    }

    @Test
    public void test1005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1005");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry6 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        int int8 = zipArchiveInputStream1.available();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry10 = zipArchiveInputStream1.getNextEntry();
        // The following exception was thrown during execution in test generation
        try {
            long long12 = zipArchiveInputStream1.skip((long) 65281);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(archiveEntry6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(archiveEntry10);
    }

    @Test
    public void test1006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1006");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding0 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean2 = fallbackZipEncoding0.canEncode("hi!");
        boolean boolean4 = fallbackZipEncoding0.canEncode("hi!");
        boolean boolean6 = fallbackZipEncoding0.canEncode("hi!");
        byte[] byteArray8 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        java.lang.String str9 = fallbackZipEncoding0.decode(byteArray8);
        java.nio.ByteBuffer byteBuffer11 = fallbackZipEncoding0.encode("\000\ufffd");
        boolean boolean13 = fallbackZipEncoding0.canEncode("a\000");
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        byte[] byteArray16 = inputStream14.readNBytes((int) (short) 100);
        boolean boolean17 = inputStream14.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream20 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14, "UTF8", true);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream21 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream20);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream22 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream20);
        byte[] byteArray24 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes(0L);
        int int27 = zipArchiveInputStream22.read(byteArray24, 36863, (int) (byte) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime29 = zipArchiveEntry28.getCreationTime();
        long long30 = zipArchiveEntry28.getSize();
        byte[] byteArray31 = zipArchiveEntry28.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField32 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int34 = asiExtraField32.getMode(100);
        boolean boolean35 = asiExtraField32.isDirectory();
        zipArchiveEntry28.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField32);
        byte[] byteArray37 = asiExtraField32.getCentralDirectoryData();
        boolean boolean38 = asiExtraField32.isLink();
        int int39 = asiExtraField32.getMode();
        java.lang.Object obj40 = asiExtraField32.clone();
        byte[] byteArray41 = asiExtraField32.getLocalFileDataData();
        int int42 = zipArchiveInputStream22.read(byteArray41);
        boolean boolean43 = zipArchiveInputStream22.markSupported();
        byte[] byteArray45 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes(3133547845L);
        int int46 = zipArchiveInputStream22.read(byteArray45);
        java.lang.String str47 = fallbackZipEncoding0.decode(byteArray45);
        boolean boolean49 = fallbackZipEncoding0.canEncode("\u07c5\000\ufffd\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "\000\ufffd\000\000" + "'", str9, "\000\ufffd\000\000");
        org.junit.Assert.assertNotNull(byteBuffer11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] { (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(fileTime29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNull(byteArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 32868 + "'", int34 == 32868);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertArrayEquals(byteArray41, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] { (byte) 69, (byte) 37, (byte) -58, (byte) -70 });
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
// flaky "1) test1006(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str47 + "' != '" + "\u01ba" + "'", str47, "\u01ba");
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test1007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1007");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = zipArchiveInputStream6.getNextZipEntry();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry8 = zipArchiveInputStream6.getNextEntry();
        long long10 = zipArchiveInputStream6.skip(2023346199L);
        boolean boolean11 = zipArchiveInputStream6.markSupported();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(zipArchiveEntry7);
        org.junit.Assert.assertNull(archiveEntry8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test1008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1008");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes(0L);
        int int13 = zipArchiveInputStream8.read(byteArray10, 36863, (int) (byte) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry14 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime15 = zipArchiveEntry14.getCreationTime();
        long long16 = zipArchiveEntry14.getSize();
        byte[] byteArray17 = zipArchiveEntry14.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField18 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int20 = asiExtraField18.getMode(100);
        boolean boolean21 = asiExtraField18.isDirectory();
        zipArchiveEntry14.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField18);
        byte[] byteArray23 = asiExtraField18.getCentralDirectoryData();
        boolean boolean24 = asiExtraField18.isLink();
        int int25 = asiExtraField18.getMode();
        java.lang.Object obj26 = asiExtraField18.clone();
        byte[] byteArray27 = asiExtraField18.getLocalFileDataData();
        int int28 = zipArchiveInputStream8.read(byteArray27);
        boolean boolean29 = zipArchiveInputStream8.markSupported();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry30 = zipArchiveInputStream8.getNextEntry();
        int int31 = zipArchiveInputStream8.available();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(fileTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNull(byteArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 32868 + "'", int20 == 32868);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(archiveEntry30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test1009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1009");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker2 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField9 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray8);
        int int10 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray8);
        jarMarker2.parseFromLocalFileData(byteArray8, 511, 0);
        boolean boolean15 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray8, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField16 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray8);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort17 = unicodePathExtraField16.getCentralDirectoryLength();
        byte[] byteArray18 = unicodePathExtraField16.getLocalFileDataData();
        byte[] byteArray19 = unicodePathExtraField16.getUnicodeName();
        byte[] byteArray20 = unicodePathExtraField16.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort21 = unicodePathExtraField16.getCentralDirectoryLength();
        byte[] byteArray23 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes(100L);
        int int24 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray23);
        org.apache.commons.compress.archivers.zip.ZipLong zipLong25 = new org.apache.commons.compress.archivers.zip.ZipLong(byteArray23);
        unicodePathExtraField16.setUnicodeName(byteArray23);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField29 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("4\000\000\000", byteArray23, (int) (short) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 65281 + "'", int10 == 65281);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(zipShort17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(zipShort21);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] { (byte) 100, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
    }

    @Test
    public void test1010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1010");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker1 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray7 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField8 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        int int9 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray7);
        jarMarker1.parseFromLocalFileData(byteArray7, 511, 0);
        boolean boolean14 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray7, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField15 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = unicodePathExtraField15.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField17 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int18 = asiExtraField17.getGroupId();
        asiExtraField17.setDirectory(true);
        byte[] byteArray21 = asiExtraField17.getCentralDirectoryData();
        long long22 = org.apache.commons.compress.archivers.zip.ZipLong.getValue(byteArray21);
        unicodePathExtraField15.setUnicodeName(byteArray21);
        long long25 = org.apache.commons.compress.archivers.zip.ZipLong.getValue(byteArray21, 0);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 65281 + "'", int9 == 65281);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1025010545L + "'", long22 == 1025010545L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1025010545L + "'", long25 == 1025010545L);
    }

    @Test
    public void test1011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1011");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        zipArchiveInputStream1.mark(5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = zipArchiveInputStream1.getNextZipEntry();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry9 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry10 = zipArchiveInputStream1.getNextZipEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(zipArchiveEntry8);
        org.junit.Assert.assertNull(archiveEntry9);
        org.junit.Assert.assertNull(zipArchiveEntry10);
    }

    @Test
    public void test1012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1012");
        byte[] byteArray1 = org.apache.commons.compress.archivers.zip.ZipUtil.toDosTime((long) 511);
        boolean boolean3 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray1, 51966);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertArrayEquals(byteArray1, new byte[] { (byte) 0, (byte) 33, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test1013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1013");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream5);
        int int7 = zipArchiveInputStream6.getCount();
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding8 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean10 = fallbackZipEncoding8.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime12 = zipArchiveEntry11.getCreationTime();
        long long13 = zipArchiveEntry11.getSize();
        byte[] byteArray14 = zipArchiveEntry11.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField15 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int17 = asiExtraField15.getMode(100);
        boolean boolean18 = asiExtraField15.isDirectory();
        zipArchiveEntry11.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField15);
        byte[] byteArray20 = asiExtraField15.getCentralDirectoryData();
        int int22 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray20, 3);
        int int23 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray20);
        java.lang.String str24 = fallbackZipEncoding8.decode(byteArray20);
        boolean boolean26 = fallbackZipEncoding8.canEncode("UTF8");
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField33 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray32);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort34 = unicodePathExtraField33.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = unicodePathExtraField33.getHeaderId();
        byte[] byteArray36 = unicodePathExtraField33.getUnicodeName();
        java.lang.String str37 = fallbackZipEncoding8.decode(byteArray36);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry38 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long39 = zipArchiveEntry38.getExternalAttributes();
        java.io.InputStream inputStream40 = java.io.InputStream.nullInputStream();
        byte[] byteArray42 = inputStream40.readNBytes((int) (short) 100);
        zipArchiveEntry38.setCentralDirectoryExtra(byteArray42);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry44 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry38);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry45 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry44);
        java.util.Date date46 = zipArchiveEntry44.getLastModifiedDate();
        zipArchiveEntry44.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker49 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry44.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker49);
        java.io.InputStream inputStream51 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream52 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream51);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry53 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime54 = zipArchiveEntry53.getCreationTime();
        long long55 = zipArchiveEntry53.getSize();
        byte[] byteArray56 = zipArchiveEntry53.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField57 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int59 = asiExtraField57.getMode(100);
        boolean boolean60 = asiExtraField57.isDirectory();
        zipArchiveEntry53.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField57);
        asiExtraField57.setGroupId(10);
        byte[] byteArray64 = asiExtraField57.getCentralDirectoryData();
        int int65 = inputStream51.read(byteArray64);
        inputStream51.mark(227);
        byte[] byteArray69 = inputStream51.readNBytes((int) (short) 1);
        jarMarker49.parseFromCentralDirectoryData(byteArray69, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort73 = jarMarker49.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry74 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long75 = zipArchiveEntry74.getExternalAttributes();
        java.io.InputStream inputStream76 = java.io.InputStream.nullInputStream();
        byte[] byteArray78 = inputStream76.readNBytes((int) (short) 100);
        zipArchiveEntry74.setCentralDirectoryExtra(byteArray78);
        jarMarker49.parseFromCentralDirectoryData(byteArray78, 33279, 0);
        java.lang.String str83 = fallbackZipEncoding8.decode(byteArray78);
        int int86 = zipArchiveInputStream6.read(byteArray78, 0, 65281);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream89 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6, "\ufffd\ufffd\tS\000\ufffd\000\000\000\000\000\000\000\ufffd", false);
            org.junit.Assert.fail("Expected exception of type java.nio.charset.IllegalCharsetNameException; message: ???S??????????");
        } catch (java.nio.charset.IllegalCharsetNameException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(fileTime12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 32868 + "'", int17 == 32868);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 227 + "'", int22 == 227);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 26742 + "'", int23 == 26742);
// flaky "2) test1013(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str24 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str24, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertNotNull(zipShort34);
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(inputStream40);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] {});
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertEquals(date46.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream51);
        org.junit.Assert.assertNull(fileTime54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-1L) + "'", long55 == (-1L));
        org.junit.Assert.assertNull(byteArray56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 32868 + "'", int59 == 32868);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(byteArray64);
        org.junit.Assert.assertArrayEquals(byteArray64, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(byteArray69);
        org.junit.Assert.assertArrayEquals(byteArray69, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
        org.junit.Assert.assertNotNull(inputStream76);
        org.junit.Assert.assertNotNull(byteArray78);
        org.junit.Assert.assertArrayEquals(byteArray78, new byte[] {});
        org.junit.Assert.assertEquals("'" + str83 + "' != '" + "" + "'", str83, "");
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
    }

    @Test
    public void test1014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1014");
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField1 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int2 = asiExtraField1.getGroupId();
        asiExtraField1.setDirectory(true);
        byte[] byteArray5 = asiExtraField1.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField6 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("UTF8", byteArray5);
        byte[] byteArray7 = unicodeCommentExtraField6.getCentralDirectoryData();
        java.io.InputStream inputStream8 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream9 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream8);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker10 = org.apache.commons.compress.archivers.zip.JarMarker.getInstance();
        byte[] byteArray11 = jarMarker10.getCentralDirectoryData();
        int int14 = zipArchiveInputStream9.read(byteArray11, (int) (short) 0, (int) '#');
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long16 = zipArchiveEntry15.getExternalAttributes();
        zipArchiveEntry15.setSize((long) 28789);
        zipArchiveEntry15.setCrc(10L);
        zipArchiveEntry15.setPlatform(4095);
        java.lang.String str23 = zipArchiveEntry15.getName();
        byte[] byteArray25 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        zipArchiveEntry15.setCentralDirectoryExtra(byteArray25);
        long long27 = zipArchiveEntry15.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long29 = zipArchiveEntry28.getExternalAttributes();
        java.lang.Object obj30 = zipArchiveEntry28.clone();
        java.nio.file.attribute.FileTime fileTime31 = zipArchiveEntry28.getLastAccessTime();
        byte[] byteArray33 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        zipArchiveEntry28.setExtra(byteArray33);
        zipArchiveEntry15.setExtra(byteArray33);
        int int38 = zipArchiveInputStream9.read(byteArray33, (int) (short) 10, 0);
        long long40 = zipArchiveInputStream9.skip(312912242339L);
        byte[] byteArray42 = zipArchiveInputStream9.readNBytes((int) (byte) 10);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray44 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray42, true);
        byte[] byteArray45 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeLocalFileDataData(zipExtraFieldArray44);
        // The following exception was thrown during execution in test generation
        try {
            unicodeCommentExtraField6.parseFromCentralDirectoryData(byteArray45, (int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: UniCode path extra data must have at least 5 bytes.");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 1, (byte) 23, (byte) -48, (byte) -103, (byte) 120, (byte) 85, (byte) 84, (byte) 70, (byte) 56 });
        org.junit.Assert.assertNotNull(jarMarker10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28789L + "'", long27 == 28789L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertEquals(obj30.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj30), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj30), "");
        org.junit.Assert.assertNull(fileTime31);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray44);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray44, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
    }

    @Test
    public void test1015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1015");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        byte[] byteArray5 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray6 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray5);
        int int9 = zipArchiveInputStream1.read(byteArray5, (int) ' ', 40960);
        boolean boolean10 = zipArchiveInputStream1.markSupported();
        long long12 = zipArchiveInputStream1.skip(0L);
        long long14 = zipArchiveInputStream1.skip(0L);
        long long16 = zipArchiveInputStream1.skip(2246010937L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray6);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray6, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test1016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1016");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort13 = jarMarker11.getCentralDirectoryLength();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        byte[] byteArray17 = zipArchiveInputStream15.readNBytes(8);
        jarMarker11.parseFromCentralDirectoryData(byteArray17, 10, 0);
        byte[] byteArray21 = jarMarker11.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort22 = jarMarker11.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort23 = jarMarker11.getCentralDirectoryLength();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(zipShort13);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort22);
        org.junit.Assert.assertNotNull(zipShort23);
    }

    @Test
    public void test1017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1017");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.close();
        boolean boolean3 = zipArchiveInputStream1.markSupported();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = zipArchiveInputStream1.getNextZipEntry();
        // The following exception was thrown during execution in test generation
        try {
            long long8 = zipArchiveInputStream1.skip(16419L);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(zipArchiveEntry6);
    }

    @Test
    public void test1018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1018");
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream3 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream2);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry4 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime5 = zipArchiveEntry4.getCreationTime();
        long long6 = zipArchiveEntry4.getSize();
        byte[] byteArray7 = zipArchiveEntry4.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField8 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int10 = asiExtraField8.getMode(100);
        boolean boolean11 = asiExtraField8.isDirectory();
        zipArchiveEntry4.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField8);
        asiExtraField8.setGroupId(10);
        byte[] byteArray15 = asiExtraField8.getCentralDirectoryData();
        int int16 = inputStream2.read(byteArray15);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField17 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("\ufffd\ufffdi\000\ufffd\000\000\000\000\000\000\ufffd", byteArray15);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField18 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("\ufffd\ufffdi\000\ufffd\000\000\000\000\000\000\ufffd", byteArray15);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort19 = unicodeCommentExtraField18.getCentralDirectoryLength();
        byte[] byteArray20 = unicodeCommentExtraField18.getCentralDirectoryData();
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNull(fileTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32868 + "'", int10 == 32868);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(zipShort19);
        org.junit.Assert.assertNotNull(byteArray20);
    }

    @Test
    public void test1019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1019");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.lang.Object obj2 = zipArchiveEntry0.clone();
        java.nio.file.attribute.FileTime fileTime3 = zipArchiveEntry0.getLastAccessTime();
        zipArchiveEntry0.setUnixMode((-1));
        java.nio.file.attribute.FileTime fileTime6 = zipArchiveEntry0.getCreationTime();
        zipArchiveEntry0.setName("\ufffd\ufffd");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry10 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long11 = zipArchiveEntry10.getExternalAttributes();
        java.io.InputStream inputStream12 = java.io.InputStream.nullInputStream();
        byte[] byteArray14 = inputStream12.readNBytes((int) (short) 100);
        zipArchiveEntry10.setCentralDirectoryExtra(byteArray14);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry16 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry10);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry16);
        int int18 = zipArchiveEntry16.getInternalAttributes();
        long long19 = zipArchiveEntry16.getCrc();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long21 = zipArchiveEntry20.getExternalAttributes();
        zipArchiveEntry20.setSize((long) 28789);
        zipArchiveEntry20.setCrc(10L);
        zipArchiveEntry20.setPlatform(4095);
        byte[] byteArray28 = zipArchiveEntry20.getCentralDirectoryExtra();
        byte[] byteArray29 = zipArchiveEntry20.getLocalFileDataExtra();
        java.lang.String str30 = zipArchiveEntry20.getName();
        byte[] byteArray33 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean35 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray33, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField36 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray33);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort37 = unicodeCommentExtraField36.getHeaderId();
        zipArchiveEntry20.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField36);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry39 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime40 = zipArchiveEntry39.getCreationTime();
        byte[] byteArray42 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray43 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray42);
        zipArchiveEntry39.setExtraFields(zipExtraFieldArray43);
        zipArchiveEntry39.setTime((long) 32868);
        int int47 = zipArchiveEntry39.getPlatform();
        zipArchiveEntry39.setMethod(0);
        java.nio.file.attribute.FileTime fileTime50 = zipArchiveEntry39.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry51 = zipArchiveEntry20.setLastModifiedTime(fileTime50);
        java.util.zip.ZipEntry zipEntry52 = zipArchiveEntry16.setCreationTime(fileTime50);
        java.util.zip.ZipEntry zipEntry53 = zipArchiveEntry9.setCreationTime(fileTime50);
        java.lang.String str54 = zipEntry53.getComment();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "");
        org.junit.Assert.assertNull(fileTime3);
        org.junit.Assert.assertNull(fileTime6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(inputStream12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] {});
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertArrayEquals(byteArray29, new byte[] {});
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(zipShort37);
        org.junit.Assert.assertNull(fileTime40);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray43);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray43, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(fileTime50);
        org.junit.Assert.assertNotNull(zipEntry51);
        org.junit.Assert.assertEquals(zipEntry51.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry52);
        org.junit.Assert.assertEquals(zipEntry52.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry53);
        org.junit.Assert.assertEquals(zipEntry53.toString(), "\ufffd\ufffd");
        org.junit.Assert.assertNull(str54);
    }

    @Test
    public void test1020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1020");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int13 = zipArchiveInputStream1.read(byteArray10, (-1), 100);
        zipArchiveInputStream1.mark((int) (short) 1);
        zipArchiveInputStream1.mark(0);
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry19 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = zipArchiveInputStream1.getNextZipEntry();
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(archiveEntry19);
        org.junit.Assert.assertNull(zipArchiveEntry20);
    }

    @Test
    public void test1021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1021");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        byte[] byteArray5 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray6 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray5);
        int int9 = zipArchiveInputStream1.read(byteArray5, (int) ' ', 40960);
        boolean boolean10 = zipArchiveInputStream1.markSupported();
        int int11 = zipArchiveInputStream1.available();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream13 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray6);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray6, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test1022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1022");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry6 = zipArchiveInputStream1.getNextEntry();
        int int7 = zipArchiveInputStream1.available();
        long long9 = zipArchiveInputStream1.skip((long) 14);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker10 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort11 = jarMarker10.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort12 = jarMarker10.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort13 = jarMarker10.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort14 = jarMarker10.getLocalFileDataLength();
        byte[] byteArray15 = jarMarker10.getLocalFileDataData();
        int int16 = zipArchiveInputStream1.read(byteArray15);
        java.io.OutputStream outputStream17 = null;
        // The following exception was thrown during execution in test generation
        try {
            long long18 = zipArchiveInputStream1.transferTo(outputStream17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(archiveEntry6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(zipShort11);
        org.junit.Assert.assertNotNull(zipShort12);
        org.junit.Assert.assertNotNull(zipShort13);
        org.junit.Assert.assertNotNull(zipShort14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] {});
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test1023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1023");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        int int9 = zipArchiveInputStream6.read();
        int int10 = zipArchiveInputStream6.available();
        long long12 = zipArchiveInputStream6.skip(35L);
        byte[] byteArray14 = zipArchiveInputStream6.readNBytes(4095);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] {});
    }

    @Test
    public void test1024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1024");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        zipArchiveInputStream1.mark(5);
        long long9 = zipArchiveInputStream1.skip((long) 33279);
        int int10 = zipArchiveInputStream1.getCount();
        byte[] byteArray11 = zipArchiveInputStream1.readAllBytes();
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveInputStream1.reset();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: mark/reset not supported");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
    }

    @Test
    public void test1025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1025");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        long long7 = zipArchiveInputStream1.skip(0L);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = zipArchiveInputStream1.getNextZipEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNull(zipArchiveEntry8);
    }

    @Test
    public void test1026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1026");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker0 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort1 = jarMarker0.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort2 = jarMarker0.getLocalFileDataLength();
        byte[] byteArray3 = jarMarker0.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort4 = jarMarker0.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort5 = jarMarker0.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort6 = jarMarker0.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = jarMarker0.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort8 = jarMarker0.getCentralDirectoryLength();
        byte[] byteArray9 = jarMarker0.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding10 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean12 = fallbackZipEncoding10.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry13 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime14 = zipArchiveEntry13.getCreationTime();
        long long15 = zipArchiveEntry13.getSize();
        byte[] byteArray16 = zipArchiveEntry13.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField17 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int19 = asiExtraField17.getMode(100);
        boolean boolean20 = asiExtraField17.isDirectory();
        zipArchiveEntry13.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField17);
        byte[] byteArray22 = asiExtraField17.getCentralDirectoryData();
        int int24 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray22, 3);
        int int25 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray22);
        java.lang.String str26 = fallbackZipEncoding10.decode(byteArray22);
        java.nio.ByteBuffer byteBuffer28 = fallbackZipEncoding10.encode("\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry29 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long30 = zipArchiveEntry29.getExternalAttributes();
        java.io.InputStream inputStream31 = java.io.InputStream.nullInputStream();
        byte[] byteArray33 = inputStream31.readNBytes((int) (short) 100);
        zipArchiveEntry29.setCentralDirectoryExtra(byteArray33);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField35 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int36 = asiExtraField35.getGroupId();
        asiExtraField35.setDirectory(true);
        byte[] byteArray39 = asiExtraField35.getCentralDirectoryData();
        java.io.InputStream inputStream40 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream41 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream40);
        java.io.InputStream inputStream42 = java.io.InputStream.nullInputStream();
        byte[] byteArray44 = inputStream42.readNBytes((int) (short) 100);
        int int47 = zipArchiveInputStream41.read(byteArray44, (int) ' ', 40960);
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry29, byteArray39, byteArray44);
        java.lang.String str49 = fallbackZipEncoding10.decode(byteArray39);
        // The following exception was thrown during execution in test generation
        try {
            jarMarker0.parseFromLocalFileData(byteArray39, 420, 34158);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: JarMarker doesn't expect any data");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(zipShort1);
        org.junit.Assert.assertNotNull(zipShort2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertArrayEquals(byteArray3, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort4);
        org.junit.Assert.assertNotNull(zipShort5);
        org.junit.Assert.assertNotNull(zipShort6);
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(zipShort8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(fileTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNull(byteArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32868 + "'", int19 == 32868);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 227 + "'", int24 == 227);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 26742 + "'", int25 == 26742);
// flaky "3) test1026(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str26 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str26, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertNotNull(byteBuffer28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(inputStream31);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] {});
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertArrayEquals(byteArray39, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(inputStream42);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertArrayEquals(byteArray44, new byte[] {});
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "qk\030=\000@\000\000\000\000\000\000\000\000" + "'", str49, "qk\030=\000@\000\000\000\000\000\000\000\000");
    }

    @Test
    public void test1027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1027");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        byte[] byteArray4 = zipArchiveEntry0.getExtra();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry5 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        zipArchiveEntry5.setCrc(33639248L);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long9 = zipArchiveEntry8.getExternalAttributes();
        java.io.InputStream inputStream10 = java.io.InputStream.nullInputStream();
        byte[] byteArray12 = inputStream10.readNBytes((int) (short) 100);
        zipArchiveEntry8.setCentralDirectoryExtra(byteArray12);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry14 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry8);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry14);
        java.util.Date date16 = zipArchiveEntry14.getLastModifiedDate();
        zipArchiveEntry14.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker19 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry14.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker19);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort21 = jarMarker19.getCentralDirectoryLength();
        java.io.InputStream inputStream22 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream23 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream22);
        byte[] byteArray25 = zipArchiveInputStream23.readNBytes(8);
        jarMarker19.parseFromCentralDirectoryData(byteArray25, 10, 0);
        java.io.InputStream inputStream29 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream30 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream29);
        byte[] byteArray32 = zipArchiveInputStream30.readNBytes(8);
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry5, byteArray25, byteArray32);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker34 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = jarMarker34.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort36 = jarMarker34.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort37 = jarMarker34.getCentralDirectoryLength();
        zipArchiveEntry5.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker34);
        zipArchiveEntry5.setCompressedSize(312796802981L);
        zipArchiveEntry5.setExtra();
        long long42 = zipArchiveEntry5.getTime();
        zipArchiveEntry5.setCrc((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNull(byteArray4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(inputStream10);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] {});
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertEquals(date16.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(zipShort21);
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertNotNull(inputStream29);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(zipShort36);
        org.junit.Assert.assertNotNull(zipShort37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
    }

    @Test
    public void test1028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1028");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry1 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long2 = zipArchiveEntry1.getExternalAttributes();
        java.io.InputStream inputStream3 = java.io.InputStream.nullInputStream();
        byte[] byteArray5 = inputStream3.readNBytes((int) (short) 100);
        zipArchiveEntry1.setCentralDirectoryExtra(byteArray5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry7);
        java.util.Date date9 = zipArchiveEntry7.getLastModifiedDate();
        zipArchiveEntry7.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker12 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry7.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker12);
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry16 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime17 = zipArchiveEntry16.getCreationTime();
        long long18 = zipArchiveEntry16.getSize();
        byte[] byteArray19 = zipArchiveEntry16.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField20 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int22 = asiExtraField20.getMode(100);
        boolean boolean23 = asiExtraField20.isDirectory();
        zipArchiveEntry16.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField20);
        asiExtraField20.setGroupId(10);
        byte[] byteArray27 = asiExtraField20.getCentralDirectoryData();
        int int28 = inputStream14.read(byteArray27);
        inputStream14.mark(227);
        byte[] byteArray32 = inputStream14.readNBytes((int) (short) 1);
        jarMarker12.parseFromCentralDirectoryData(byteArray32, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort36 = jarMarker12.getLocalFileDataLength();
        byte[] byteArray37 = jarMarker12.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort38 = jarMarker12.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField39 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort38);
        byte[] byteArray40 = zipShort38.getBytes();
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField41 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray40);
        byte[] byteArray42 = unicodeCommentExtraField41.getUnicodeName();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(inputStream3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] {});
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertEquals(date9.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNull(fileTime17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertNull(byteArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 32868 + "'", int22 == 32868);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort36);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort38);
        org.junit.Assert.assertNotNull(zipExtraField39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertArrayEquals(byteArray40, new byte[] { (byte) -2, (byte) -54 });
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] {});
    }

    @Test
    public void test1029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1029");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        boolean boolean1 = inputStream0.markSupported();
        int int2 = inputStream0.available();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream3 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry4 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long5 = zipArchiveEntry4.getExternalAttributes();
        java.lang.Object obj6 = zipArchiveEntry4.clone();
        java.nio.file.attribute.FileTime fileTime7 = zipArchiveEntry4.getLastAccessTime();
        byte[] byteArray9 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        zipArchiveEntry4.setExtra(byteArray9);
        long long11 = zipArchiveEntry4.getExternalAttributes();
        byte[] byteArray17 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField18 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray17);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort19 = unicodePathExtraField18.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort20 = unicodePathExtraField18.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort21 = unicodePathExtraField18.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort22 = unicodePathExtraField18.getHeaderId();
        byte[] byteArray23 = unicodePathExtraField18.getCentralDirectoryData();
        zipArchiveEntry4.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodePathExtraField18);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort25 = unicodePathExtraField18.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort26 = unicodePathExtraField18.getLocalFileDataLength();
        byte[] byteArray27 = unicodePathExtraField18.getLocalFileDataData();
        // The following exception was thrown during execution in test generation
        try {
            int int30 = zipArchiveInputStream3.readNBytes(byteArray27, 32820, 17774);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Range [32820, 32820 + 17774) out of bounds for length 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertEquals(obj6.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj6), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj6), "");
        org.junit.Assert.assertNull(fileTime7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertNotNull(zipShort19);
        org.junit.Assert.assertNotNull(zipShort20);
        org.junit.Assert.assertNotNull(zipShort21);
        org.junit.Assert.assertNotNull(zipShort22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(zipShort25);
        org.junit.Assert.assertNotNull(zipShort26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
    }

    @Test
    public void test1030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1030");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = zipArchiveInputStream1.getNextZipEntry();
        int int8 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField9 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int10 = asiExtraField9.getGroupId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort11 = asiExtraField9.getCentralDirectoryLength();
        int int12 = asiExtraField9.getUserId();
        java.lang.Object obj13 = asiExtraField9.clone();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort14 = asiExtraField9.getLocalFileDataLength();
        byte[] byteArray15 = zipShort14.getBytes();
        // The following exception was thrown during execution in test generation
        try {
            int int18 = zipArchiveInputStream1.readNBytes(byteArray15, 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Range [10, 10 + 1) out of bounds for length 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertNull(zipArchiveEntry7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(zipShort11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(zipShort14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] { (byte) 14, (byte) 0 });
    }

    @Test
    public void test1031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1031");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort13 = jarMarker11.getCentralDirectoryLength();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        byte[] byteArray17 = zipArchiveInputStream15.readNBytes(8);
        jarMarker11.parseFromCentralDirectoryData(byteArray17, 10, 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort21 = jarMarker11.getCentralDirectoryLength();
        java.io.InputStream inputStream23 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream24 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream23);
        java.io.InputStream inputStream25 = java.io.InputStream.nullInputStream();
        byte[] byteArray27 = inputStream25.readNBytes((int) (short) 100);
        int int30 = zipArchiveInputStream24.read(byteArray27, (int) ' ', 40960);
        byte[] byteArray31 = zipArchiveInputStream24.readAllBytes();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker32 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort33 = jarMarker32.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort34 = jarMarker32.getLocalFileDataLength();
        byte[] byteArray35 = jarMarker32.getCentralDirectoryData();
        int int38 = zipArchiveInputStream24.read(byteArray35, 100, (int) (short) -1);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField39 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray35);
        // The following exception was thrown during execution in test generation
        try {
            jarMarker11.parseFromLocalFileData(byteArray35, 19280, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: JarMarker doesn't expect any data");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(zipShort13);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort21);
        org.junit.Assert.assertNotNull(inputStream25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] {});
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort33);
        org.junit.Assert.assertNotNull(zipShort34);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] {});
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test1032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1032");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.lang.Object obj2 = zipArchiveEntry0.clone();
        java.nio.file.attribute.FileTime fileTime3 = zipArchiveEntry0.getLastAccessTime();
        zipArchiveEntry0.setUnixMode((-1));
        java.nio.file.attribute.FileTime fileTime6 = zipArchiveEntry0.getCreationTime();
        java.lang.String str7 = zipArchiveEntry0.getName();
        int int8 = zipArchiveEntry0.getUnixMode();
        long long9 = zipArchiveEntry0.getSize();
        byte[] byteArray10 = zipArchiveEntry0.getLocalFileDataExtra();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long12 = zipArchiveEntry11.getExternalAttributes();
        zipArchiveEntry11.setSize((long) 28789);
        zipArchiveEntry11.setCrc(10L);
        zipArchiveEntry11.setPlatform(4095);
        int int19 = zipArchiveEntry11.getInternalAttributes();
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray20 = zipArchiveEntry11.getExtraFields();
        boolean boolean21 = zipArchiveEntry11.isDirectory();
        java.nio.file.attribute.FileTime fileTime22 = zipArchiveEntry11.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry23 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime24 = zipArchiveEntry23.getCreationTime();
        long long25 = zipArchiveEntry23.getSize();
        byte[] byteArray26 = zipArchiveEntry23.getExtra();
        int int27 = zipArchiveEntry23.getMethod();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong28 = org.apache.commons.compress.archivers.zip.ZipLong.LFH_SIG;
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry29 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime30 = zipArchiveEntry29.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry31 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry29);
        boolean boolean32 = zipLong28.equals((java.lang.Object) zipArchiveEntry31);
        java.lang.String str33 = zipArchiveEntry31.getComment();
        zipArchiveEntry31.setTime(0L);
        java.util.Date date36 = zipArchiveEntry31.getLastModifiedDate();
        java.time.LocalDateTime localDateTime37 = zipArchiveEntry31.getTimeLocal();
        zipArchiveEntry23.setTimeLocal(localDateTime37);
        zipArchiveEntry11.setTimeLocal(localDateTime37);
        zipArchiveEntry0.setTimeLocal(localDateTime37);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry41 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long42 = zipArchiveEntry41.getExternalAttributes();
        java.lang.Object obj43 = zipArchiveEntry41.clone();
        java.nio.file.attribute.FileTime fileTime44 = zipArchiveEntry41.getLastAccessTime();
        byte[] byteArray45 = zipArchiveEntry41.getCentralDirectoryExtra();
        java.io.InputStream inputStream46 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream47 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream46);
        byte[] byteArray48 = new byte[] {};
        int int51 = zipArchiveInputStream47.read(byteArray48, 420, 1);
        java.io.InputStream inputStream52 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream53 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream52);
        java.io.InputStream inputStream54 = java.io.InputStream.nullInputStream();
        byte[] byteArray56 = inputStream54.readNBytes((int) (short) 100);
        int int59 = zipArchiveInputStream53.read(byteArray56, (int) ' ', 40960);
        byte[] byteArray60 = zipArchiveInputStream53.readAllBytes();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry41, byteArray48, byteArray60);
        zipArchiveEntry41.setPlatform(420);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry64 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry41);
        boolean boolean65 = zipArchiveEntry0.equals((java.lang.Object) zipArchiveEntry41);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "");
        org.junit.Assert.assertNull(fileTime3);
        org.junit.Assert.assertNull(fileTime6);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 65535 + "'", int8 == 65535);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(zipExtraFieldArray20);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray20, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(fileTime22);
        org.junit.Assert.assertNull(fileTime24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNull(byteArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(zipLong28);
        org.junit.Assert.assertNull(fileTime30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertEquals(date36.toString(), "Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNotNull(localDateTime37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertEquals(obj43.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj43), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj43), "");
        org.junit.Assert.assertNull(fileTime44);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
        org.junit.Assert.assertNotNull(inputStream46);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertArrayEquals(byteArray48, new byte[] {});
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(inputStream54);
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertArrayEquals(byteArray56, new byte[] {});
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(byteArray60);
        org.junit.Assert.assertArrayEquals(byteArray60, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test1033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1033");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        zipArchiveInputStream1.close();
        int int5 = zipArchiveInputStream1.available();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry6 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.mark(33188);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(archiveEntry6);
    }

    @Test
    public void test1034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1034");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry1 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long2 = zipArchiveEntry1.getExternalAttributes();
        java.io.InputStream inputStream3 = java.io.InputStream.nullInputStream();
        byte[] byteArray5 = inputStream3.readNBytes((int) (short) 100);
        zipArchiveEntry1.setCentralDirectoryExtra(byteArray5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry7);
        java.util.Date date9 = zipArchiveEntry7.getLastModifiedDate();
        byte[] byteArray10 = zipArchiveEntry7.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField11 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray10);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker12 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort13 = jarMarker12.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort14 = jarMarker12.getLocalFileDataLength();
        byte[] byteArray15 = jarMarker12.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = jarMarker12.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort17 = jarMarker12.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort18 = jarMarker12.getCentralDirectoryLength();
        byte[] byteArray21 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean23 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray21, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField24 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray21);
        byte[] byteArray25 = unicodeCommentExtraField24.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort26 = unicodeCommentExtraField24.getLocalFileDataLength();
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField33 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray32);
        boolean boolean34 = zipShort26.equals((java.lang.Object) unicodePathExtraField33);
        long long35 = unicodePathExtraField33.getNameCRC32();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort36 = unicodePathExtraField33.getLocalFileDataLength();
        byte[] byteArray37 = unicodePathExtraField33.getLocalFileDataData();
        jarMarker12.parseFromCentralDirectoryData(byteArray37, 51966, 0);
        // The following exception was thrown during execution in test generation
        try {
            unicodePathExtraField11.parseFromCentralDirectoryData(byteArray37, 32768, 32776);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 32768 out of bounds for length 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(inputStream3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] {});
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertEquals(date9.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort13);
        org.junit.Assert.assertNotNull(zipShort14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertNotNull(zipShort17);
        org.junit.Assert.assertNotNull(zipShort18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort26);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 4035808147L + "'", long35 == 4035808147L);
        org.junit.Assert.assertNotNull(zipShort36);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
    }

    @Test
    public void test1035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1035");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime16 = zipArchiveEntry15.getCreationTime();
        long long17 = zipArchiveEntry15.getSize();
        byte[] byteArray18 = zipArchiveEntry15.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField19 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int21 = asiExtraField19.getMode(100);
        boolean boolean22 = asiExtraField19.isDirectory();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField19);
        asiExtraField19.setGroupId(10);
        byte[] byteArray26 = asiExtraField19.getCentralDirectoryData();
        int int27 = inputStream13.read(byteArray26);
        inputStream13.mark(227);
        byte[] byteArray31 = inputStream13.readNBytes((int) (short) 1);
        jarMarker11.parseFromCentralDirectoryData(byteArray31, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = jarMarker11.getLocalFileDataLength();
        byte[] byteArray36 = jarMarker11.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort37 = jarMarker11.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort38 = jarMarker11.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort39 = jarMarker11.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort40 = jarMarker11.getHeaderId();
        byte[] byteArray41 = jarMarker11.getLocalFileDataData();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(fileTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32868 + "'", int21 == 32868);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort37);
        org.junit.Assert.assertNotNull(zipShort38);
        org.junit.Assert.assertNotNull(zipShort39);
        org.junit.Assert.assertNotNull(zipShort40);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertArrayEquals(byteArray41, new byte[] {});
    }

    @Test
    public void test1036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1036");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        zipArchiveEntry6.setUnixMode(0);
        byte[] byteArray17 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean19 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray17, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField20 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray17);
        byte[] byteArray21 = unicodeCommentExtraField20.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort22 = unicodeCommentExtraField20.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort23 = unicodeCommentExtraField20.getCentralDirectoryLength();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField20);
        zipArchiveEntry6.setSize(3133547845L);
        zipArchiveEntry6.setComment("\000\ufffd");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort22);
        org.junit.Assert.assertNotNull(zipShort23);
    }

    @Test
    public void test1037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1037");
        org.apache.commons.compress.archivers.zip.ZipLong zipLong0 = org.apache.commons.compress.archivers.zip.ZipLong.CFH_SIG;
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker1 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort2 = jarMarker1.getLocalFileDataLength();
        boolean boolean3 = zipLong0.equals((java.lang.Object) jarMarker1);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort4 = jarMarker1.getCentralDirectoryLength();
        java.io.InputStream inputStream5 = java.io.InputStream.nullInputStream();
        byte[] byteArray7 = inputStream5.readNBytes((int) (short) 100);
        boolean boolean8 = inputStream5.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream11 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream5, "UTF8", true);
        long long13 = zipArchiveInputStream11.skip((long) 65281);
        byte[] byteArray15 = zipArchiveInputStream11.readNBytes(32868);
        zipArchiveInputStream11.mark(21589);
        byte[] byteArray18 = zipArchiveInputStream11.readAllBytes();
        // The following exception was thrown during execution in test generation
        try {
            jarMarker1.parseFromCentralDirectoryData(byteArray18, (int) '4', 26984);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: JarMarker doesn't expect any data");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(zipLong0);
        org.junit.Assert.assertNotNull(zipShort2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(zipShort4);
        org.junit.Assert.assertNotNull(inputStream5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
    }

    @Test
    public void test1038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1038");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int13 = zipArchiveInputStream1.read(byteArray10, (-1), 100);
        zipArchiveInputStream1.mark((int) (short) 1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream16 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long18 = zipArchiveEntry17.getExternalAttributes();
        zipArchiveEntry17.setSize((long) 28789);
        zipArchiveEntry17.setCrc(10L);
        zipArchiveEntry17.setPlatform(4095);
        java.lang.String str25 = zipArchiveEntry17.getName();
        byte[] byteArray27 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        zipArchiveEntry17.setCentralDirectoryExtra(byteArray27);
        long long29 = zipArchiveEntry17.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry30 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long31 = zipArchiveEntry30.getExternalAttributes();
        java.lang.Object obj32 = zipArchiveEntry30.clone();
        java.nio.file.attribute.FileTime fileTime33 = zipArchiveEntry30.getLastAccessTime();
        byte[] byteArray35 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        zipArchiveEntry30.setExtra(byteArray35);
        zipArchiveEntry17.setExtra(byteArray35);
        int int38 = zipArchiveInputStream1.read(byteArray35);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28789L + "'", long29 == 28789L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertEquals(obj32.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj32), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj32), "");
        org.junit.Assert.assertNull(fileTime33);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test1039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1039");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        java.lang.String str8 = zipArchiveEntry0.getName();
        java.nio.file.attribute.FileTime fileTime9 = zipArchiveEntry0.getCreationTime();
        byte[] byteArray10 = zipArchiveEntry0.getExtra();
        zipArchiveEntry0.setComment("a\000");
        zipArchiveEntry0.setUnixMode(40960);
        java.nio.file.attribute.FileTime fileTime15 = zipArchiveEntry0.getLastModifiedTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry16 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long17 = zipArchiveEntry16.getExternalAttributes();
        java.io.InputStream inputStream18 = java.io.InputStream.nullInputStream();
        byte[] byteArray20 = inputStream18.readNBytes((int) (short) 100);
        zipArchiveEntry16.setCentralDirectoryExtra(byteArray20);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry22 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry16);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry23 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry22);
        java.util.Date date24 = zipArchiveEntry22.getLastModifiedDate();
        zipArchiveEntry22.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker27 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry22.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker27);
        java.io.InputStream inputStream29 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream30 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream29);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry31 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime32 = zipArchiveEntry31.getCreationTime();
        long long33 = zipArchiveEntry31.getSize();
        byte[] byteArray34 = zipArchiveEntry31.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField35 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int37 = asiExtraField35.getMode(100);
        boolean boolean38 = asiExtraField35.isDirectory();
        zipArchiveEntry31.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField35);
        asiExtraField35.setGroupId(10);
        byte[] byteArray42 = asiExtraField35.getCentralDirectoryData();
        int int43 = inputStream29.read(byteArray42);
        inputStream29.mark(227);
        byte[] byteArray47 = inputStream29.readNBytes((int) (short) 1);
        jarMarker27.parseFromCentralDirectoryData(byteArray47, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort51 = jarMarker27.getLocalFileDataLength();
        byte[] byteArray52 = jarMarker27.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry54 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long55 = zipArchiveEntry54.getExternalAttributes();
        zipArchiveEntry54.setSize((long) 28789);
        boolean boolean58 = zipArchiveEntry54.isDirectory();
        java.lang.Object obj59 = zipArchiveEntry54.clone();
        java.lang.String str60 = zipArchiveEntry54.getComment();
        byte[] byteArray61 = zipArchiveEntry54.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField62 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("UTF8", byteArray61);
        jarMarker27.parseFromCentralDirectoryData(byteArray61, (int) (byte) 100, 0);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray61);
        java.util.Date date67 = zipArchiveEntry0.getLastModifiedDate();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(fileTime9);
        org.junit.Assert.assertNull(byteArray10);
        org.junit.Assert.assertNull(fileTime15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(inputStream18);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] {});
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertEquals(date24.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream29);
        org.junit.Assert.assertNull(fileTime32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNull(byteArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 32868 + "'", int37 == 32868);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertArrayEquals(byteArray47, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort51);
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertArrayEquals(byteArray52, new byte[] {});
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertEquals(obj59.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj59), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj59), "");
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] {});
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertEquals(date67.toString(), "Wed Dec 31 15:59:59 PST 1969");
    }

    @Test
    public void test1040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1040");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        java.lang.String str7 = zipArchiveEntry6.getComment();
        zipArchiveEntry6.setMethod((int) (byte) 0);
        java.lang.String str10 = zipArchiveEntry6.getName();
        long long11 = zipArchiveEntry6.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long13 = zipArchiveEntry12.getExternalAttributes();
        zipArchiveEntry12.setSize((long) 28789);
        zipArchiveEntry12.setCrc(10L);
        zipArchiveEntry12.setPlatform(4095);
        java.lang.String str20 = zipArchiveEntry12.getName();
        java.nio.file.attribute.FileTime fileTime21 = zipArchiveEntry12.getCreationTime();
        byte[] byteArray22 = zipArchiveEntry12.getExtra();
        zipArchiveEntry12.setComment("a\000");
        zipArchiveEntry12.setUnixMode(40960);
        java.nio.file.attribute.FileTime fileTime27 = zipArchiveEntry12.getLastModifiedTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long29 = zipArchiveEntry28.getExternalAttributes();
        java.io.InputStream inputStream30 = java.io.InputStream.nullInputStream();
        byte[] byteArray32 = inputStream30.readNBytes((int) (short) 100);
        zipArchiveEntry28.setCentralDirectoryExtra(byteArray32);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry34 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry28);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry35 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry34);
        java.util.Date date36 = zipArchiveEntry34.getLastModifiedDate();
        zipArchiveEntry34.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker39 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry34.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker39);
        java.io.InputStream inputStream41 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream42 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream41);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry43 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime44 = zipArchiveEntry43.getCreationTime();
        long long45 = zipArchiveEntry43.getSize();
        byte[] byteArray46 = zipArchiveEntry43.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField47 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int49 = asiExtraField47.getMode(100);
        boolean boolean50 = asiExtraField47.isDirectory();
        zipArchiveEntry43.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField47);
        asiExtraField47.setGroupId(10);
        byte[] byteArray54 = asiExtraField47.getCentralDirectoryData();
        int int55 = inputStream41.read(byteArray54);
        inputStream41.mark(227);
        byte[] byteArray59 = inputStream41.readNBytes((int) (short) 1);
        jarMarker39.parseFromCentralDirectoryData(byteArray59, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort63 = jarMarker39.getLocalFileDataLength();
        byte[] byteArray64 = jarMarker39.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry66 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long67 = zipArchiveEntry66.getExternalAttributes();
        zipArchiveEntry66.setSize((long) 28789);
        boolean boolean70 = zipArchiveEntry66.isDirectory();
        java.lang.Object obj71 = zipArchiveEntry66.clone();
        java.lang.String str72 = zipArchiveEntry66.getComment();
        byte[] byteArray73 = zipArchiveEntry66.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField74 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("UTF8", byteArray73);
        jarMarker39.parseFromCentralDirectoryData(byteArray73, (int) (byte) 100, 0);
        zipArchiveEntry12.setCentralDirectoryExtra(byteArray73);
        zipArchiveEntry6.setExtra(byteArray73);
        int int80 = zipArchiveEntry6.getUnixMode();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker81 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort82 = jarMarker81.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort83 = jarMarker81.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort84 = jarMarker81.getHeaderId();
        byte[] byteArray85 = null;
        jarMarker81.parseFromLocalFileData(byteArray85, 10, 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort89 = jarMarker81.getCentralDirectoryLength();
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveEntry6.removeExtraField(zipShort89);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertNull(fileTime21);
        org.junit.Assert.assertNull(byteArray22);
        org.junit.Assert.assertNull(fileTime27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(inputStream30);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertEquals(date36.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream41);
        org.junit.Assert.assertNull(fileTime44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1L) + "'", long45 == (-1L));
        org.junit.Assert.assertNull(byteArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 32868 + "'", int49 == 32868);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertArrayEquals(byteArray54, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertArrayEquals(byteArray59, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort63);
        org.junit.Assert.assertNotNull(byteArray64);
        org.junit.Assert.assertArrayEquals(byteArray64, new byte[] {});
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertEquals(obj71.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj71), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj71), "");
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(byteArray73);
        org.junit.Assert.assertArrayEquals(byteArray73, new byte[] {});
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(zipShort82);
        org.junit.Assert.assertNotNull(zipShort83);
        org.junit.Assert.assertNotNull(zipShort84);
        org.junit.Assert.assertNotNull(zipShort89);
    }

    @Test
    public void test1041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1041");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry4 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        long long5 = zipArchiveEntry4.getTime();
        zipArchiveEntry4.setName("\ufffd\ufffd");
        java.lang.String str8 = zipArchiveEntry4.getName();
        long long9 = zipArchiveEntry4.getSize();
        java.lang.String str10 = zipArchiveEntry4.getName();
        java.io.InputStream inputStream11 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream12 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream11);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker13 = org.apache.commons.compress.archivers.zip.JarMarker.getInstance();
        byte[] byteArray14 = jarMarker13.getCentralDirectoryData();
        int int17 = zipArchiveInputStream12.read(byteArray14, (int) (short) 0, (int) '#');
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry18 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long19 = zipArchiveEntry18.getExternalAttributes();
        zipArchiveEntry18.setSize((long) 28789);
        zipArchiveEntry18.setCrc(10L);
        zipArchiveEntry18.setPlatform(4095);
        java.lang.String str26 = zipArchiveEntry18.getName();
        byte[] byteArray28 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        zipArchiveEntry18.setCentralDirectoryExtra(byteArray28);
        long long30 = zipArchiveEntry18.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry31 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long32 = zipArchiveEntry31.getExternalAttributes();
        java.lang.Object obj33 = zipArchiveEntry31.clone();
        java.nio.file.attribute.FileTime fileTime34 = zipArchiveEntry31.getLastAccessTime();
        byte[] byteArray36 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        zipArchiveEntry31.setExtra(byteArray36);
        zipArchiveEntry18.setExtra(byteArray36);
        int int41 = zipArchiveInputStream12.read(byteArray36, (int) (short) 10, 0);
        long long43 = zipArchiveInputStream12.skip(312912242339L);
        byte[] byteArray45 = zipArchiveInputStream12.readNBytes((int) (byte) 10);
        byte[] byteArray46 = zipArchiveInputStream12.readAllBytes();
        zipArchiveEntry4.setCentralDirectoryExtra(byteArray46);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "\ufffd\ufffd" + "'", str8, "\ufffd\ufffd");
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28789L + "'", long9 == 28789L);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "\ufffd\ufffd" + "'", str10, "\ufffd\ufffd");
        org.junit.Assert.assertNotNull(jarMarker13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] {});
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28789L + "'", long30 == 28789L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertEquals(obj33.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj33), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj33), "");
        org.junit.Assert.assertNull(fileTime34);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertArrayEquals(byteArray46, new byte[] {});
    }

    @Test
    public void test1042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1042");
        java.io.InputStream inputStream1 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream2 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream1);
        java.io.InputStream inputStream3 = java.io.InputStream.nullInputStream();
        byte[] byteArray5 = inputStream3.readNBytes((int) (short) 100);
        int int8 = zipArchiveInputStream2.read(byteArray5, (int) ' ', 40960);
        byte[] byteArray9 = zipArchiveInputStream2.readAllBytes();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker10 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort11 = jarMarker10.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort12 = jarMarker10.getLocalFileDataLength();
        byte[] byteArray13 = jarMarker10.getCentralDirectoryData();
        int int16 = zipArchiveInputStream2.read(byteArray13, 100, (int) (short) -1);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField17 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry18 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long19 = zipArchiveEntry18.getExternalAttributes();
        java.io.InputStream inputStream20 = java.io.InputStream.nullInputStream();
        byte[] byteArray22 = inputStream20.readNBytes((int) (short) 100);
        zipArchiveEntry18.setCentralDirectoryExtra(byteArray22);
        int int24 = zipArchiveEntry18.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry25 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry18);
        byte[] byteArray26 = zipArchiveEntry18.getLocalFileDataExtra();
        unicodePathExtraField17.setUnicodeName(byteArray26);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort28 = unicodePathExtraField17.getLocalFileDataLength();
        byte[] byteArray29 = unicodePathExtraField17.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort30 = unicodePathExtraField17.getHeaderId();
        org.junit.Assert.assertNotNull(inputStream3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] {});
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort11);
        org.junit.Assert.assertNotNull(zipShort12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] {});
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] {});
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertArrayEquals(byteArray29, new byte[] { (byte) 1, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipShort30);
    }

    @Test
    public void test1043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1043");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort13 = jarMarker11.getCentralDirectoryLength();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        byte[] byteArray17 = zipArchiveInputStream15.readNBytes(8);
        jarMarker11.parseFromCentralDirectoryData(byteArray17, 10, 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort21 = jarMarker11.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort22 = jarMarker11.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort23 = jarMarker11.getLocalFileDataLength();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(zipShort13);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort21);
        org.junit.Assert.assertNotNull(zipShort22);
        org.junit.Assert.assertNotNull(zipShort23);
    }

    @Test
    public void test1044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1044");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream5);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry7 = zipArchiveInputStream6.getNextEntry();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry8 = zipArchiveInputStream6.getNextEntry();
        long long10 = zipArchiveInputStream6.skip(51966L);
        zipArchiveInputStream6.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertNull(archiveEntry7);
        org.junit.Assert.assertNull(archiveEntry8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test1045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1045");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        int int7 = zipArchiveInputStream6.read();
        int int8 = zipArchiveInputStream6.available();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream9 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry10 = zipArchiveInputStream9.getNextEntry();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry11 = zipArchiveInputStream9.getNextEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(archiveEntry10);
        org.junit.Assert.assertNull(archiveEntry11);
    }

    @Test
    public void test1046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1046");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getLocalFileDataLength();
        int int8 = zipShort7.getValue();
        java.lang.Object obj9 = zipShort7.clone();
        int int10 = zipShort7.getValue();
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField11 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort7);
        byte[] byteArray12 = zipShort7.getBytes();
        boolean boolean14 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray12, 26742);
        java.lang.Class<?> wildcardClass15 = byteArray12.getClass();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(zipExtraField11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 5, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test1047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1047");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        long long9 = zipArchiveInputStream1.skip((long) 28789);
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry11 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        zipArchiveInputStream1.mark(10);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = zipArchiveInputStream1.getNextZipEntry();
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNull(archiveEntry11);
        org.junit.Assert.assertNull(zipArchiveEntry15);
    }

    @Test
    public void test1048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1048");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        zipArchiveInputStream6.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry8 = zipArchiveInputStream6.getNextEntry();
        int int9 = zipArchiveInputStream6.available();
        zipArchiveInputStream6.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(archiveEntry8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test1049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1049");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        boolean boolean1 = inputStream0.markSupported();
        boolean boolean2 = inputStream0.markSupported();
        byte[] byteArray4 = inputStream0.readNBytes(0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry5 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long6 = zipArchiveEntry5.getExternalAttributes();
        java.io.InputStream inputStream7 = java.io.InputStream.nullInputStream();
        byte[] byteArray9 = inputStream7.readNBytes((int) (short) 100);
        zipArchiveEntry5.setCentralDirectoryExtra(byteArray9);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry11);
        java.util.Date date13 = zipArchiveEntry11.getLastModifiedDate();
        zipArchiveEntry11.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker16 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry11.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker16);
        java.io.InputStream inputStream18 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream19 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream18);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime21 = zipArchiveEntry20.getCreationTime();
        long long22 = zipArchiveEntry20.getSize();
        byte[] byteArray23 = zipArchiveEntry20.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField24 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int26 = asiExtraField24.getMode(100);
        boolean boolean27 = asiExtraField24.isDirectory();
        zipArchiveEntry20.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField24);
        asiExtraField24.setGroupId(10);
        byte[] byteArray31 = asiExtraField24.getCentralDirectoryData();
        int int32 = inputStream18.read(byteArray31);
        inputStream18.mark(227);
        byte[] byteArray36 = inputStream18.readNBytes((int) (short) 1);
        jarMarker16.parseFromCentralDirectoryData(byteArray36, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort40 = jarMarker16.getLocalFileDataLength();
        byte[] byteArray41 = jarMarker16.getLocalFileDataData();
        int int42 = inputStream0.read(byteArray41);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertEquals(date13.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream18);
        org.junit.Assert.assertNull(fileTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNull(byteArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32868 + "'", int26 == 32868);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort40);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertArrayEquals(byteArray41, new byte[] {});
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test1050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1050");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream4 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry5 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long6 = zipArchiveEntry5.getExternalAttributes();
        java.io.InputStream inputStream7 = java.io.InputStream.nullInputStream();
        byte[] byteArray9 = inputStream7.readNBytes((int) (short) 100);
        zipArchiveEntry5.setCentralDirectoryExtra(byteArray9);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry11);
        java.util.Date date13 = zipArchiveEntry11.getLastModifiedDate();
        zipArchiveEntry11.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker16 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry11.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker16);
        java.io.InputStream inputStream18 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream19 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream18);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime21 = zipArchiveEntry20.getCreationTime();
        long long22 = zipArchiveEntry20.getSize();
        byte[] byteArray23 = zipArchiveEntry20.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField24 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int26 = asiExtraField24.getMode(100);
        boolean boolean27 = asiExtraField24.isDirectory();
        zipArchiveEntry20.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField24);
        asiExtraField24.setGroupId(10);
        byte[] byteArray31 = asiExtraField24.getCentralDirectoryData();
        int int32 = inputStream18.read(byteArray31);
        inputStream18.mark(227);
        byte[] byteArray36 = inputStream18.readNBytes((int) (short) 1);
        jarMarker16.parseFromCentralDirectoryData(byteArray36, 4095, (int) (short) 0);
        int int40 = zipArchiveInputStream4.read(byteArray36);
        byte[] byteArray41 = zipArchiveInputStream4.readAllBytes();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertEquals(date13.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream18);
        org.junit.Assert.assertNull(fileTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNull(byteArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32868 + "'", int26 == 32868);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertArrayEquals(byteArray41, new byte[] {});
    }

    @Test
    public void test1051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1051");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort8 = unicodeCommentExtraField5.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort9 = unicodeCommentExtraField5.getHeaderId();
        byte[] byteArray10 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime12 = zipArchiveEntry11.getCreationTime();
        byte[] byteArray14 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray15 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray14);
        zipArchiveEntry11.setExtraFields(zipExtraFieldArray15);
        zipArchiveEntry11.setTime((long) 32868);
        java.io.InputStream inputStream19 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream20 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream19);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry21 = zipArchiveInputStream20.getNextEntry();
        long long23 = zipArchiveInputStream20.skip((long) (byte) 0);
        byte[] byteArray24 = zipArchiveInputStream20.readAllBytes();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry25 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long26 = zipArchiveEntry25.getExternalAttributes();
        java.io.InputStream inputStream27 = java.io.InputStream.nullInputStream();
        byte[] byteArray29 = inputStream27.readNBytes((int) (short) 100);
        zipArchiveEntry25.setCentralDirectoryExtra(byteArray29);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry31 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry25);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry32 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry31);
        java.util.Date date33 = zipArchiveEntry31.getLastModifiedDate();
        zipArchiveEntry31.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker36 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry31.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker36);
        java.io.InputStream inputStream38 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream39 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream38);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry40 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime41 = zipArchiveEntry40.getCreationTime();
        long long42 = zipArchiveEntry40.getSize();
        byte[] byteArray43 = zipArchiveEntry40.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField44 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int46 = asiExtraField44.getMode(100);
        boolean boolean47 = asiExtraField44.isDirectory();
        zipArchiveEntry40.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField44);
        asiExtraField44.setGroupId(10);
        byte[] byteArray51 = asiExtraField44.getCentralDirectoryData();
        int int52 = inputStream38.read(byteArray51);
        inputStream38.mark(227);
        byte[] byteArray56 = inputStream38.readNBytes((int) (short) 1);
        jarMarker36.parseFromCentralDirectoryData(byteArray56, 4095, (int) (short) 0);
        byte[] byteArray60 = jarMarker36.getCentralDirectoryData();
        byte[] byteArray61 = jarMarker36.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort62 = jarMarker36.getLocalFileDataLength();
        byte[] byteArray63 = jarMarker36.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry11, byteArray24, byteArray63);
        // The following exception was thrown during execution in test generation
        try {
            unicodeCommentExtraField5.parseFromLocalFileData(byteArray24, 4095, 16419);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 4095 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(zipShort8);
        org.junit.Assert.assertNotNull(zipShort9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNull(fileTime12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray15);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray15, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(inputStream19);
        org.junit.Assert.assertNull(archiveEntry21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] {});
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(inputStream27);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertArrayEquals(byteArray29, new byte[] {});
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertEquals(date33.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream38);
        org.junit.Assert.assertNull(fileTime41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNull(byteArray43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 32868 + "'", int46 == 32868);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(byteArray51);
        org.junit.Assert.assertArrayEquals(byteArray51, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertArrayEquals(byteArray56, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray60);
        org.junit.Assert.assertArrayEquals(byteArray60, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort62);
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] {});
    }

    @Test
    public void test1052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1052");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        java.lang.String str7 = zipArchiveEntry6.getComment();
        java.nio.file.attribute.FileTime fileTime8 = zipArchiveEntry6.getLastModifiedTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long10 = zipArchiveEntry9.getExternalAttributes();
        java.lang.Object obj11 = zipArchiveEntry9.clone();
        java.nio.file.attribute.FileTime fileTime12 = zipArchiveEntry9.getLastAccessTime();
        byte[] byteArray13 = zipArchiveEntry9.getCentralDirectoryExtra();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        byte[] byteArray16 = new byte[] {};
        int int19 = zipArchiveInputStream15.read(byteArray16, 420, 1);
        java.io.InputStream inputStream20 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream21 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream20);
        java.io.InputStream inputStream22 = java.io.InputStream.nullInputStream();
        byte[] byteArray24 = inputStream22.readNBytes((int) (short) 100);
        int int27 = zipArchiveInputStream21.read(byteArray24, (int) ' ', 40960);
        byte[] byteArray28 = zipArchiveInputStream21.readAllBytes();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry9, byteArray16, byteArray28);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry30 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime31 = zipArchiveEntry30.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry32 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry30);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField33 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        zipArchiveEntry30.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField33);
        zipArchiveEntry30.setSize(0L);
        byte[] byteArray37 = zipArchiveEntry30.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry6, byteArray28, byteArray37);
        int int39 = zipArchiveEntry6.getUnixMode();
        byte[] byteArray41 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) (byte) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort43 = new org.apache.commons.compress.archivers.zip.ZipShort(byteArray41, (int) (byte) 0);
        zipArchiveEntry6.setExtra(byteArray41);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort45 = null;
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField46 = zipArchiveEntry6.getExtraField(zipShort45);
        int int47 = zipArchiveEntry6.getMethod();
        java.util.Date date48 = zipArchiveEntry6.getLastModifiedDate();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(fileTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertEquals(obj11.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj11), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj11), "");
        org.junit.Assert.assertNull(fileTime12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] {});
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] {});
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] {});
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] {});
        org.junit.Assert.assertNull(fileTime31);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] { (byte) 110, (byte) 117, (byte) 14, (byte) 0, (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertArrayEquals(byteArray41, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNull(zipExtraField46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertEquals(date48.toString(), "Wed Dec 31 15:59:59 PST 1969");
    }

    @Test
    public void test1053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1053");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        long long8 = zipArchiveInputStream6.skip((long) 65281);
        byte[] byteArray10 = zipArchiveInputStream6.readNBytes(32868);
        long long12 = zipArchiveInputStream6.skip((long) 227);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry13 = zipArchiveInputStream6.getNextEntry();
        zipArchiveInputStream6.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNull(archiveEntry13);
    }

    @Test
    public void test1054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1054");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry6 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        int int8 = zipArchiveInputStream1.available();
        zipArchiveInputStream1.close();
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveInputStream1.reset();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: mark/reset not supported");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(archiveEntry6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test1055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1055");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.mark((int) (byte) 0);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream4 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        int int5 = zipArchiveInputStream1.available();
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveInputStream1.reset();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: mark/reset not supported");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test1056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1056");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        java.lang.String str7 = zipArchiveEntry6.getComment();
        zipArchiveEntry6.setMethod((int) (byte) 0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry10 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long11 = zipArchiveEntry10.getExternalAttributes();
        java.io.InputStream inputStream12 = java.io.InputStream.nullInputStream();
        byte[] byteArray14 = inputStream12.readNBytes((int) (short) 100);
        zipArchiveEntry10.setCentralDirectoryExtra(byteArray14);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray16 = new org.apache.commons.compress.archivers.zip.ZipExtraField[] {};
        zipArchiveEntry10.setExtraFields(zipExtraFieldArray16);
        byte[] byteArray18 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray16);
        zipArchiveEntry6.setExtraFields(zipExtraFieldArray16);
        byte[] byteArray20 = zipArchiveEntry6.getLocalFileDataExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField21 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        asiExtraField21.setGroupId(40960);
        asiExtraField21.setDirectory(true);
        asiExtraField21.setDirectory(false);
        byte[] byteArray28 = asiExtraField21.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField30 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int32 = asiExtraField30.getMode(100);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort33 = asiExtraField30.getCentralDirectoryLength();
        byte[] byteArray34 = asiExtraField30.getLocalFileDataData();
        int int35 = asiExtraField30.getGroupId();
        asiExtraField30.setMode((int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort38 = asiExtraField30.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort39 = asiExtraField30.getHeaderId();
        byte[] byteArray40 = asiExtraField30.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField41 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("\ufffd\ufffd", byteArray40);
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry6, byteArray28, byteArray40);
        byte[] byteArray43 = zipArchiveEntry6.getExtra();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean45 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray43, 32885);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 0 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(inputStream12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray16);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray16, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] { (byte) -47, (byte) -53, (byte) 9, (byte) 83, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) -96 });
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 32868 + "'", int32 == 32868);
        org.junit.Assert.assertNotNull(zipShort33);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertArrayEquals(byteArray34, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(zipShort38);
        org.junit.Assert.assertNotNull(zipShort39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertArrayEquals(byteArray40, new byte[] { (byte) 57, (byte) 104, (byte) -33, (byte) -123, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] {});
    }

    @Test
    public void test1057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1057");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        int int6 = zipArchiveInputStream1.getCount();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        // The following exception was thrown during execution in test generation
        try {
            int int9 = zipArchiveInputStream1.read();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test1058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1058");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        int int8 = zipArchiveInputStream1.available();
        int int9 = zipArchiveInputStream1.getCount();
        java.io.OutputStream outputStream10 = null;
        // The following exception was thrown during execution in test generation
        try {
            long long11 = zipArchiveInputStream1.transferTo(outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test1059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1059");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry7 = zipArchiveInputStream6.getNextEntry();
        zipArchiveInputStream6.close();
        // The following exception was thrown during execution in test generation
        try {
            long long10 = zipArchiveInputStream6.skip((long) 32885);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(archiveEntry7);
    }

    @Test
    public void test1060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1060");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry7 = zipArchiveInputStream6.getNextEntry();
        zipArchiveInputStream6.close();
        zipArchiveInputStream6.close();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(archiveEntry7);
    }

    @Test
    public void test1061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1061");
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField1 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int3 = asiExtraField1.getMode(100);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort4 = asiExtraField1.getCentralDirectoryLength();
        byte[] byteArray5 = asiExtraField1.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField6 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray5);
        byte[] byteArray7 = unicodePathExtraField6.getUnicodeName();
        unicodePathExtraField6.setNameCRC32((long) 28789);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort10 = unicodePathExtraField6.getCentralDirectoryLength();
        java.io.InputStream inputStream11 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream12 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream11);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry13 = zipArchiveInputStream12.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream16 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream12, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream17 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream16);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry18 = zipArchiveInputStream17.getNextEntry();
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding19 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean21 = fallbackZipEncoding19.canEncode("hi!");
        boolean boolean23 = fallbackZipEncoding19.canEncode("hi!");
        java.nio.ByteBuffer byteBuffer25 = fallbackZipEncoding19.encode("UTF8");
        byte[] byteArray27 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray28 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray27);
        byte[] byteArray29 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray28);
        java.lang.String str30 = fallbackZipEncoding19.decode(byteArray29);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry31 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long32 = zipArchiveEntry31.getExternalAttributes();
        zipArchiveEntry31.setSize((long) 28789);
        zipArchiveEntry31.setCrc(10L);
        zipArchiveEntry31.setPlatform(4095);
        java.lang.String str39 = zipArchiveEntry31.getName();
        java.nio.file.attribute.FileTime fileTime40 = zipArchiveEntry31.getCreationTime();
        byte[] byteArray41 = zipArchiveEntry31.getExtra();
        byte[] byteArray43 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((-1));
        zipArchiveEntry31.setExtra(byteArray43);
        java.lang.String str45 = fallbackZipEncoding19.decode(byteArray43);
        boolean boolean47 = fallbackZipEncoding19.canEncode("\000!\000\000");
        java.nio.ByteBuffer byteBuffer49 = fallbackZipEncoding19.encode("nu\016\000\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000up\005\000\001\ufffd\001\000\000nu\016\000\ufffd\ufffd\017\000\000\000\000\000\000\000\000\ufffduc\b\000\001\ufffd\007\ufffd&hi!nu\016\000qk\030=\000@\000\000\000\000\000\000\000\000up\005\000\001\ufffd\ufffd\ufffd\ufffd");
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField51 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int52 = asiExtraField51.getGroupId();
        asiExtraField51.setDirectory(true);
        byte[] byteArray55 = asiExtraField51.getCentralDirectoryData();
        long long56 = org.apache.commons.compress.archivers.zip.ZipLong.getValue(byteArray55);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField57 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("\001\u01bahi!", byteArray55);
        java.lang.String str58 = fallbackZipEncoding19.decode(byteArray55);
        int int59 = zipArchiveInputStream17.read(byteArray55);
        long long61 = org.apache.commons.compress.archivers.zip.ZipLong.getValue(byteArray55, 0);
        unicodePathExtraField6.setUnicodeName(byteArray55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32868 + "'", int3 == 32868);
        org.junit.Assert.assertNotNull(zipShort4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort10);
        org.junit.Assert.assertNotNull(inputStream11);
        org.junit.Assert.assertNull(archiveEntry13);
        org.junit.Assert.assertNull(archiveEntry18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(byteBuffer25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray28);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray28, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertArrayEquals(byteArray29, new byte[] {});
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "" + "'", str39, "");
        org.junit.Assert.assertNull(fileTime40);
        org.junit.Assert.assertNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) -1, (byte) -1 });
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "\ufffd\ufffd" + "'", str45, "\ufffd\ufffd");
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(byteBuffer49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertArrayEquals(byteArray55, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1025010545L + "'", long56 == 1025010545L);
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "qk\030=\000@\000\000\000\000\000\000\000\000" + "'", str58, "qk\030=\000@\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1025010545L + "'", long61 == 1025010545L);
    }

    @Test
    public void test1062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1062");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes(0L);
        int int13 = zipArchiveInputStream8.read(byteArray10, 36863, (int) (byte) 10);
        byte[] byteArray16 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) (byte) -1);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField17 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray16);
        int int20 = zipArchiveInputStream8.read(byteArray16, 51966, (int) (byte) 10);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] { (byte) -1, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test1063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1063");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int13 = zipArchiveInputStream1.read(byteArray10, (-1), 100);
        int int14 = zipArchiveInputStream1.read();
        java.io.InputStream inputStream15 = java.io.InputStream.nullInputStream();
        byte[] byteArray17 = inputStream15.readNBytes((int) (short) 100);
        int int20 = zipArchiveInputStream1.read(byteArray17, 32865, 26742);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(inputStream15);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test1064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1064");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        java.lang.Object obj8 = zipArchiveEntry0.clone();
        zipArchiveEntry0.setSize(312854400666L);
        byte[] byteArray13 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean15 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray13, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField16 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray13);
        byte[] byteArray17 = unicodeCommentExtraField16.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort18 = unicodeCommentExtraField16.getLocalFileDataLength();
        boolean boolean19 = zipArchiveEntry0.equals((java.lang.Object) unicodeCommentExtraField16);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertEquals(obj8.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj8), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj8), "");
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test1065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1065");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int13 = zipArchiveInputStream1.read(byteArray10, (-1), 100);
        zipArchiveInputStream1.mark((int) (short) 1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream16 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        long long18 = zipArchiveInputStream16.skip((long) 55041);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test1066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1066");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime1 = zipArchiveEntry0.getCreationTime();
        byte[] byteArray3 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray4 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray3);
        zipArchiveEntry0.setExtraFields(zipExtraFieldArray4);
        zipArchiveEntry0.setUnixMode((int) 'a');
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker8 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort9 = jarMarker8.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort10 = jarMarker8.getLocalFileDataLength();
        byte[] byteArray11 = jarMarker8.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray13 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray11, true);
        zipArchiveEntry0.setExtraFields(zipExtraFieldArray13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long16 = zipArchiveEntry15.getExternalAttributes();
        zipArchiveEntry15.setSize((long) 28789);
        zipArchiveEntry15.setCrc(10L);
        zipArchiveEntry15.setPlatform(4095);
        byte[] byteArray23 = zipArchiveEntry15.getCentralDirectoryExtra();
        java.nio.file.attribute.FileTime fileTime24 = zipArchiveEntry15.getLastAccessTime();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField25 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int26 = asiExtraField25.getGroupId();
        asiExtraField25.setDirectory(true);
        byte[] byteArray29 = asiExtraField25.getCentralDirectoryData();
        byte[] byteArray30 = asiExtraField25.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker32 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray38 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField39 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray38);
        int int40 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray38);
        jarMarker32.parseFromLocalFileData(byteArray38, 511, 0);
        boolean boolean45 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray38, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField46 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray38);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort47 = unicodePathExtraField46.getCentralDirectoryLength();
        byte[] byteArray48 = unicodePathExtraField46.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry15, byteArray30, byteArray48);
        org.apache.commons.compress.archivers.zip.ZipLong zipLong51 = org.apache.commons.compress.archivers.zip.ZipLong.LFH_SIG;
        org.apache.commons.compress.archivers.zip.ZipShort zipShort53 = new org.apache.commons.compress.archivers.zip.ZipShort((int) (byte) 1);
        boolean boolean54 = zipLong51.equals((java.lang.Object) (byte) 1);
        byte[] byteArray55 = zipLong51.getBytes();
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField56 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("hi!", byteArray55);
        byte[] byteArray57 = unicodeCommentExtraField56.getLocalFileDataData();
        byte[] byteArray58 = unicodeCommentExtraField56.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort59 = unicodeCommentExtraField56.getLocalFileDataLength();
        byte[] byteArray60 = unicodeCommentExtraField56.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry0, byteArray48, byteArray60);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipLong zipLong63 = new org.apache.commons.compress.archivers.zip.ZipLong(byteArray60, 32769);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 32772 out of bounds for length 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNull(fileTime1);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertArrayEquals(byteArray3, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray4);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray4, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(zipShort9);
        org.junit.Assert.assertNotNull(zipShort10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray13);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray13, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] {});
        org.junit.Assert.assertNull(fileTime24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertArrayEquals(byteArray29, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertArrayEquals(byteArray30, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertArrayEquals(byteArray38, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 65281 + "'", int40 == 65281);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(zipShort47);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertArrayEquals(byteArray48, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(zipLong51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertArrayEquals(byteArray55, new byte[] { (byte) 80, (byte) 75, (byte) 3, (byte) 4 });
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertArrayEquals(byteArray57, new byte[] { (byte) 1, (byte) 69, (byte) 37, (byte) -58, (byte) -70, (byte) 104, (byte) 105, (byte) 33 });
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertArrayEquals(byteArray58, new byte[] { (byte) 1, (byte) 69, (byte) 37, (byte) -58, (byte) -70, (byte) 104, (byte) 105, (byte) 33 });
        org.junit.Assert.assertNotNull(zipShort59);
        org.junit.Assert.assertNotNull(byteArray60);
        org.junit.Assert.assertArrayEquals(byteArray60, new byte[] { (byte) 1, (byte) 69, (byte) 37, (byte) -58, (byte) -70, (byte) 104, (byte) 105, (byte) 33 });
    }

    @Test
    public void test1067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1067");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.close();
        boolean boolean3 = zipArchiveInputStream1.markSupported();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry5 = zipArchiveInputStream1.getNextZipEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        int int8 = zipArchiveInputStream6.read();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(zipArchiveEntry5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test1068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1068");
        java.io.InputStream inputStream1 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream2 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream1);
        long long4 = zipArchiveInputStream2.skip((long) 'a');
        long long6 = zipArchiveInputStream2.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream2);
        byte[] byteArray9 = zipArchiveInputStream7.readNBytes(28789);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField10 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("\ufffd\ufffd", byteArray9);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort11 = unicodePathExtraField10.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort12 = unicodePathExtraField10.getLocalFileDataLength();
        int int13 = zipShort12.getValue();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort11);
        org.junit.Assert.assertNotNull(zipShort12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
    }

    @Test
    public void test1069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1069");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker1 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray7 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField8 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        int int9 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray7);
        jarMarker1.parseFromLocalFileData(byteArray7, 511, 0);
        boolean boolean14 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray7, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField15 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = unicodePathExtraField15.getCentralDirectoryLength();
        byte[] byteArray17 = unicodePathExtraField15.getLocalFileDataData();
        byte[] byteArray18 = unicodePathExtraField15.getUnicodeName();
        byte[] byteArray19 = unicodePathExtraField15.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort20 = unicodePathExtraField15.getHeaderId();
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 65281 + "'", int9 == 65281);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(zipShort20);
    }

    @Test
    public void test1070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1070");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        int int9 = zipArchiveInputStream6.read();
        int int10 = zipArchiveInputStream6.available();
        long long12 = zipArchiveInputStream6.skip(35L);
        int int13 = zipArchiveInputStream6.available();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1071");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip(3817498742L);
        zipArchiveInputStream1.mark((int) (short) 100);
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry7 = zipArchiveInputStream1.getNextEntry();
        // The following exception was thrown during execution in test generation
        try {
            long long9 = zipArchiveInputStream1.skip(4362735842250L);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNull(archiveEntry7);
    }

    @Test
    public void test1072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1072");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime16 = zipArchiveEntry15.getCreationTime();
        long long17 = zipArchiveEntry15.getSize();
        byte[] byteArray18 = zipArchiveEntry15.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField19 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int21 = asiExtraField19.getMode(100);
        boolean boolean22 = asiExtraField19.isDirectory();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField19);
        asiExtraField19.setGroupId(10);
        byte[] byteArray26 = asiExtraField19.getCentralDirectoryData();
        int int27 = inputStream13.read(byteArray26);
        inputStream13.mark(227);
        byte[] byteArray31 = inputStream13.readNBytes((int) (short) 1);
        jarMarker11.parseFromCentralDirectoryData(byteArray31, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = jarMarker11.getLocalFileDataLength();
        byte[] byteArray36 = jarMarker11.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort37 = jarMarker11.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort38 = jarMarker11.getCentralDirectoryLength();
        java.io.InputStream inputStream39 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream40 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream39);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry41 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime42 = zipArchiveEntry41.getCreationTime();
        long long43 = zipArchiveEntry41.getSize();
        byte[] byteArray44 = zipArchiveEntry41.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField45 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int47 = asiExtraField45.getMode(100);
        boolean boolean48 = asiExtraField45.isDirectory();
        zipArchiveEntry41.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField45);
        asiExtraField45.setGroupId(10);
        byte[] byteArray52 = asiExtraField45.getCentralDirectoryData();
        int int53 = inputStream39.read(byteArray52);
        inputStream39.mark(227);
        byte[] byteArray57 = inputStream39.readNBytes((int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            jarMarker11.parseFromLocalFileData(byteArray57, (int) (short) 1, 18550);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: JarMarker doesn't expect any data");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(fileTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32868 + "'", int21 == 32868);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort37);
        org.junit.Assert.assertNotNull(zipShort38);
        org.junit.Assert.assertNotNull(inputStream39);
        org.junit.Assert.assertNull(fileTime42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1L) + "'", long43 == (-1L));
        org.junit.Assert.assertNull(byteArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 32868 + "'", int47 == 32868);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertArrayEquals(byteArray52, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertArrayEquals(byteArray57, new byte[] {});
    }

    @Test
    public void test1073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1073");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipUtil.toDosTime((long) 16384);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField3 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray2);
        java.io.InputStream inputStream4 = java.io.InputStream.nullInputStream();
        byte[] byteArray6 = inputStream4.readNBytes((int) (short) 100);
        byte[] byteArray8 = inputStream4.readNBytes((int) (byte) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream9 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream4);
        inputStream4.mark(16384);
        byte[] byteArray12 = inputStream4.readAllBytes();
        unicodePathExtraField3.setUnicodeName(byteArray12);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 33, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(inputStream4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] {});
    }

    @Test
    public void test1074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1074");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort8 = unicodeCommentExtraField5.getCentralDirectoryLength();
        long long9 = unicodeCommentExtraField5.getNameCRC32();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort10 = unicodeCommentExtraField5.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = org.apache.commons.compress.archivers.zip.JarMarker.getInstance();
        byte[] byteArray12 = jarMarker11.getLocalFileDataData();
        // The following exception was thrown during execution in test generation
        try {
            unicodeCommentExtraField5.parseFromCentralDirectoryData(byteArray12, (int) (byte) 0, 3);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: UniCode path extra data must have at least 5 bytes.");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(zipShort8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1104745215L + "'", long9 == 1104745215L);
        org.junit.Assert.assertNotNull(zipShort10);
        org.junit.Assert.assertNotNull(jarMarker11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] {});
    }

    @Test
    public void test1075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1075");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip(3817498742L);
        java.io.InputStream inputStream4 = java.io.InputStream.nullInputStream();
        byte[] byteArray6 = inputStream4.readNBytes((int) (short) 100);
        byte[] byteArray7 = inputStream4.readAllBytes();
        int int10 = zipArchiveInputStream1.read(byteArray7, 0, 32768);
        byte[] byteArray11 = zipArchiveInputStream1.readAllBytes();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream12 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry13 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long14 = zipArchiveEntry13.getExternalAttributes();
        java.io.InputStream inputStream15 = java.io.InputStream.nullInputStream();
        byte[] byteArray17 = inputStream15.readNBytes((int) (short) 100);
        zipArchiveEntry13.setCentralDirectoryExtra(byteArray17);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry19 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry19);
        java.util.Date date21 = zipArchiveEntry19.getLastModifiedDate();
        zipArchiveEntry19.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker24 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry19.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker24);
        zipArchiveEntry19.setUnixMode(0);
        byte[] byteArray30 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean32 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray30, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField33 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray30);
        byte[] byteArray34 = unicodeCommentExtraField33.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = unicodeCommentExtraField33.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort36 = unicodeCommentExtraField33.getCentralDirectoryLength();
        zipArchiveEntry19.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField33);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding38 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean40 = fallbackZipEncoding38.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry41 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime42 = zipArchiveEntry41.getCreationTime();
        long long43 = zipArchiveEntry41.getSize();
        byte[] byteArray44 = zipArchiveEntry41.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField45 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int47 = asiExtraField45.getMode(100);
        boolean boolean48 = asiExtraField45.isDirectory();
        zipArchiveEntry41.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField45);
        byte[] byteArray50 = asiExtraField45.getCentralDirectoryData();
        int int52 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray50, 3);
        int int53 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray50);
        java.lang.String str54 = fallbackZipEncoding38.decode(byteArray50);
        java.io.InputStream inputStream55 = java.io.InputStream.nullInputStream();
        byte[] byteArray57 = inputStream55.readNBytes((int) (short) 100);
        java.lang.String str58 = fallbackZipEncoding38.decode(byteArray57);
        java.io.InputStream inputStream59 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream60 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream59);
        java.io.InputStream inputStream61 = java.io.InputStream.nullInputStream();
        byte[] byteArray63 = inputStream61.readNBytes((int) (short) 100);
        int int66 = zipArchiveInputStream60.read(byteArray63, (int) ' ', 40960);
        java.lang.String str67 = fallbackZipEncoding38.decode(byteArray63);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray69 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray63, true);
        unicodeCommentExtraField33.setUnicodeName(byteArray63);
        int int73 = zipArchiveInputStream12.read(byteArray63, (int) (byte) 100, (-1));
        byte[] byteArray74 = null;
        int int77 = zipArchiveInputStream12.read(byteArray74, (int) 'a', (int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream80 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream12, "\001\ufffd\007\ufffd&hi!", true);
            org.junit.Assert.fail("Expected exception of type java.nio.charset.IllegalCharsetNameException; message: ????&hi!");
        } catch (java.nio.charset.IllegalCharsetNameException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(inputStream4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(inputStream15);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertEquals(date21.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertArrayEquals(byteArray30, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertArrayEquals(byteArray34, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(zipShort36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(fileTime42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1L) + "'", long43 == (-1L));
        org.junit.Assert.assertNull(byteArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 32868 + "'", int47 == 32868);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertArrayEquals(byteArray50, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 227 + "'", int52 == 227);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 26742 + "'", int53 == 26742);
// flaky "4) test1075(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str54 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str54, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertNotNull(inputStream55);
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertArrayEquals(byteArray57, new byte[] {});
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "" + "'", str58, "");
        org.junit.Assert.assertNotNull(inputStream61);
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] {});
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertEquals("'" + str67 + "' != '" + "" + "'", str67, "");
        org.junit.Assert.assertNotNull(zipExtraFieldArray69);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray69, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
    }

    @Test
    public void test1076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1076");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        int int8 = zipArchiveEntry0.getInternalAttributes();
        int int9 = zipArchiveEntry0.getInternalAttributes();
        zipArchiveEntry0.setName("\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        java.util.Date date12 = zipArchiveEntry0.getLastModifiedDate();
        zipArchiveEntry0.setUnixMode((int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long16 = zipArchiveEntry15.getExternalAttributes();
        zipArchiveEntry15.setSize((long) 28789);
        zipArchiveEntry15.setCrc(10L);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry21 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long22 = zipArchiveEntry21.getExternalAttributes();
        java.io.InputStream inputStream23 = java.io.InputStream.nullInputStream();
        byte[] byteArray25 = inputStream23.readNBytes((int) (short) 100);
        zipArchiveEntry21.setCentralDirectoryExtra(byteArray25);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray27 = new org.apache.commons.compress.archivers.zip.ZipExtraField[] {};
        zipArchiveEntry21.setExtraFields(zipExtraFieldArray27);
        zipArchiveEntry15.setExtraFields(zipExtraFieldArray27);
        java.util.Date date30 = zipArchiveEntry15.getLastModifiedDate();
        int int31 = zipArchiveEntry15.getMethod();
        byte[] byteArray32 = zipArchiveEntry15.getLocalFileDataExtra();
        long long33 = zipArchiveEntry15.getTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry34 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long35 = zipArchiveEntry34.getExternalAttributes();
        zipArchiveEntry34.setSize((long) 28789);
        zipArchiveEntry34.setCrc(10L);
        zipArchiveEntry34.setPlatform(4095);
        byte[] byteArray42 = zipArchiveEntry34.getCentralDirectoryExtra();
        byte[] byteArray43 = zipArchiveEntry34.getLocalFileDataExtra();
        java.lang.String str44 = zipArchiveEntry34.getName();
        byte[] byteArray47 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean49 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray47, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField50 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray47);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort51 = unicodeCommentExtraField50.getHeaderId();
        zipArchiveEntry34.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField50);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry53 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime54 = zipArchiveEntry53.getCreationTime();
        byte[] byteArray56 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray57 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray56);
        zipArchiveEntry53.setExtraFields(zipExtraFieldArray57);
        zipArchiveEntry53.setTime((long) 32868);
        int int61 = zipArchiveEntry53.getPlatform();
        zipArchiveEntry53.setMethod(0);
        java.nio.file.attribute.FileTime fileTime64 = zipArchiveEntry53.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry65 = zipArchiveEntry34.setLastModifiedTime(fileTime64);
        java.util.zip.ZipEntry zipEntry66 = zipArchiveEntry15.setCreationTime(fileTime64);
        java.util.zip.ZipEntry zipEntry67 = zipArchiveEntry0.setLastModifiedTime(fileTime64);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertEquals(date12.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(inputStream23);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray27);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray27, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertEquals(date30.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] {});
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertArrayEquals(byteArray47, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(zipShort51);
        org.junit.Assert.assertNull(fileTime54);
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertArrayEquals(byteArray56, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray57);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray57, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(fileTime64);
        org.junit.Assert.assertNotNull(zipEntry65);
        org.junit.Assert.assertEquals(zipEntry65.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry66);
        org.junit.Assert.assertEquals(zipEntry66.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry67);
        org.junit.Assert.assertEquals(zipEntry67.toString(), "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
    }

    @Test
    public void test1077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1077");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        int int9 = zipArchiveInputStream8.read();
        long long11 = zipArchiveInputStream8.skip(58936144L);
        boolean boolean12 = zipArchiveInputStream8.markSupported();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test1078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1078");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.mark((int) (byte) 0);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "a\000", false);
            org.junit.Assert.fail("Expected exception of type java.nio.charset.IllegalCharsetNameException; message: a?");
        } catch (java.nio.charset.IllegalCharsetNameException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
    }

    @Test
    public void test1079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1079");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        long long8 = zipArchiveInputStream6.skip((long) 65281);
        byte[] byteArray10 = zipArchiveInputStream6.readNBytes(32868);
        zipArchiveInputStream6.mark(21589);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry13 = zipArchiveInputStream6.getNextZipEntry();
        boolean boolean14 = zipArchiveInputStream6.markSupported();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertNull(zipArchiveEntry13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test1080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1080");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        byte[] byteArray4 = inputStream0.readNBytes((int) (byte) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        inputStream0.mark(16384);
        byte[] byteArray8 = inputStream0.readAllBytes();
        // The following exception was thrown during execution in test generation
        try {
            inputStream0.reset();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: mark/reset not supported");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
    }

    @Test
    public void test1081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1081");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        zipArchiveEntry0.setSize(312796988911L);
        long long3 = zipArchiveEntry0.getExternalAttributes();
        int int4 = zipArchiveEntry0.getInternalAttributes();
        zipArchiveEntry0.setSize(312912242339L);
        long long7 = zipArchiveEntry0.getExternalAttributes();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long9 = zipArchiveEntry8.getExternalAttributes();
        zipArchiveEntry8.setSize((long) 28789);
        zipArchiveEntry8.setCrc(10L);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry14 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long15 = zipArchiveEntry14.getExternalAttributes();
        java.io.InputStream inputStream16 = java.io.InputStream.nullInputStream();
        byte[] byteArray18 = inputStream16.readNBytes((int) (short) 100);
        zipArchiveEntry14.setCentralDirectoryExtra(byteArray18);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray20 = new org.apache.commons.compress.archivers.zip.ZipExtraField[] {};
        zipArchiveEntry14.setExtraFields(zipExtraFieldArray20);
        zipArchiveEntry8.setExtraFields(zipExtraFieldArray20);
        java.util.Date date23 = zipArchiveEntry8.getLastModifiedDate();
        zipArchiveEntry8.setName("UTF8");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry26 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long27 = zipArchiveEntry26.getExternalAttributes();
        zipArchiveEntry26.setSize((long) 28789);
        zipArchiveEntry26.setCrc(10L);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry32 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long33 = zipArchiveEntry32.getExternalAttributes();
        java.io.InputStream inputStream34 = java.io.InputStream.nullInputStream();
        byte[] byteArray36 = inputStream34.readNBytes((int) (short) 100);
        zipArchiveEntry32.setCentralDirectoryExtra(byteArray36);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray38 = new org.apache.commons.compress.archivers.zip.ZipExtraField[] {};
        zipArchiveEntry32.setExtraFields(zipExtraFieldArray38);
        zipArchiveEntry26.setExtraFields(zipExtraFieldArray38);
        java.util.Date date41 = zipArchiveEntry26.getLastModifiedDate();
        int int42 = zipArchiveEntry26.getMethod();
        byte[] byteArray43 = zipArchiveEntry26.getLocalFileDataExtra();
        long long44 = zipArchiveEntry26.getTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry45 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long46 = zipArchiveEntry45.getExternalAttributes();
        zipArchiveEntry45.setSize((long) 28789);
        zipArchiveEntry45.setCrc(10L);
        zipArchiveEntry45.setPlatform(4095);
        byte[] byteArray53 = zipArchiveEntry45.getCentralDirectoryExtra();
        byte[] byteArray54 = zipArchiveEntry45.getLocalFileDataExtra();
        java.lang.String str55 = zipArchiveEntry45.getName();
        byte[] byteArray58 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean60 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray58, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField61 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray58);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort62 = unicodeCommentExtraField61.getHeaderId();
        zipArchiveEntry45.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField61);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry64 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime65 = zipArchiveEntry64.getCreationTime();
        byte[] byteArray67 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray68 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray67);
        zipArchiveEntry64.setExtraFields(zipExtraFieldArray68);
        zipArchiveEntry64.setTime((long) 32868);
        int int72 = zipArchiveEntry64.getPlatform();
        zipArchiveEntry64.setMethod(0);
        java.nio.file.attribute.FileTime fileTime75 = zipArchiveEntry64.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry76 = zipArchiveEntry45.setLastModifiedTime(fileTime75);
        java.util.zip.ZipEntry zipEntry77 = zipArchiveEntry26.setCreationTime(fileTime75);
        java.util.zip.ZipEntry zipEntry78 = zipArchiveEntry8.setLastAccessTime(fileTime75);
        java.util.zip.ZipEntry zipEntry79 = zipArchiveEntry0.setCreationTime(fileTime75);
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveEntry0.setMethod(32820);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: invalid compression method");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray20);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray20, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertEquals(date23.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(inputStream34);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray38);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray38, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertEquals(date41.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] {});
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertArrayEquals(byteArray53, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertArrayEquals(byteArray54, new byte[] {});
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "" + "'", str55, "");
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertArrayEquals(byteArray58, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(zipShort62);
        org.junit.Assert.assertNull(fileTime65);
        org.junit.Assert.assertNotNull(byteArray67);
        org.junit.Assert.assertArrayEquals(byteArray67, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray68);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray68, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(fileTime75);
        org.junit.Assert.assertNotNull(zipEntry76);
        org.junit.Assert.assertEquals(zipEntry76.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry77);
        org.junit.Assert.assertEquals(zipEntry77.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry78);
        org.junit.Assert.assertEquals(zipEntry78.toString(), "UTF8");
        org.junit.Assert.assertNotNull(zipEntry79);
        org.junit.Assert.assertEquals(zipEntry79.toString(), "");
    }

    @Test
    public void test1082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1082");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        byte[] byteArray8 = zipArchiveEntry0.getCentralDirectoryExtra();
        byte[] byteArray9 = zipArchiveEntry0.getLocalFileDataExtra();
        java.lang.String str10 = zipArchiveEntry0.getName();
        byte[] byteArray13 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean15 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray13, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField16 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray13);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort17 = unicodeCommentExtraField16.getHeaderId();
        zipArchiveEntry0.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField16);
        int int19 = zipArchiveEntry0.getInternalAttributes();
        int int20 = zipArchiveEntry0.getMethod();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(zipShort17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test1083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1083");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        unicodeCommentExtraField5.setNameCRC32(0L);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort9 = unicodeCommentExtraField5.getLocalFileDataLength();
        byte[] byteArray10 = unicodeCommentExtraField5.getLocalFileDataData();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 1, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
    }

    @Test
    public void test1084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1084");
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream3 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream2);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry4 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime5 = zipArchiveEntry4.getCreationTime();
        long long6 = zipArchiveEntry4.getSize();
        byte[] byteArray7 = zipArchiveEntry4.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField8 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int10 = asiExtraField8.getMode(100);
        boolean boolean11 = asiExtraField8.isDirectory();
        zipArchiveEntry4.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField8);
        asiExtraField8.setGroupId(10);
        byte[] byteArray15 = asiExtraField8.getCentralDirectoryData();
        int int16 = inputStream2.read(byteArray15);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField17 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("\ufffd\ufffdi\000\ufffd\000\000\000\000\000\000\ufffd", byteArray15);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField18 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("\ufffd\ufffdi\000\ufffd\000\000\000\000\000\000\ufffd", byteArray15);
        byte[] byteArray19 = unicodeCommentExtraField18.getLocalFileDataData();
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNull(fileTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32868 + "'", int10 == 32868);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(byteArray19);
    }

    @Test
    public void test1085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1085");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        zipArchiveEntry0.setCompressedSize((long) (short) 10);
        zipArchiveEntry0.setTime((long) (byte) 1);
        zipArchiveEntry0.setComment("UTF8");
        int int7 = zipArchiveEntry0.getPlatform();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long9 = zipArchiveEntry8.getExternalAttributes();
        java.lang.Object obj10 = zipArchiveEntry8.clone();
        java.nio.file.attribute.FileTime fileTime11 = zipArchiveEntry8.getLastAccessTime();
        byte[] byteArray13 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        zipArchiveEntry8.setExtra(byteArray13);
        long long15 = zipArchiveEntry8.getCrc();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField17 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int19 = asiExtraField17.getMode(100);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort20 = asiExtraField17.getCentralDirectoryLength();
        byte[] byteArray21 = asiExtraField17.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField22 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray21);
        byte[] byteArray23 = unicodePathExtraField22.getUnicodeName();
        zipArchiveEntry8.setCentralDirectoryExtra(byteArray23);
        org.apache.commons.compress.archivers.zip.ZipLong zipLong26 = org.apache.commons.compress.archivers.zip.ZipLong.LFH_SIG;
        org.apache.commons.compress.archivers.zip.ZipShort zipShort28 = new org.apache.commons.compress.archivers.zip.ZipShort((int) (byte) 1);
        boolean boolean29 = zipLong26.equals((java.lang.Object) (byte) 1);
        byte[] byteArray30 = zipLong26.getBytes();
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField31 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("hi!", byteArray30);
        byte[] byteArray32 = unicodeCommentExtraField31.getLocalFileDataData();
        zipArchiveEntry8.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField31);
        byte[] byteArray35 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        unicodeCommentExtraField31.setUnicodeName(byteArray35);
        int int37 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray35);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray38 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray35);
        boolean boolean40 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray35, 32769);
        zipArchiveEntry0.setExtra(byteArray35);
        long long42 = zipArchiveEntry0.getCompressedSize();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertEquals(obj10.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj10), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj10), "");
        org.junit.Assert.assertNull(fileTime11);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32868 + "'", int19 == 32868);
        org.junit.Assert.assertNotNull(zipShort20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] {});
        org.junit.Assert.assertNotNull(zipLong26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertArrayEquals(byteArray30, new byte[] { (byte) 80, (byte) 75, (byte) 3, (byte) 4 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 1, (byte) 69, (byte) 37, (byte) -58, (byte) -70, (byte) 104, (byte) 105, (byte) 33 });
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 40960 + "'", int37 == 40960);
        org.junit.Assert.assertNotNull(zipExtraFieldArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
    }

    @Test
    public void test1086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1086");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream4 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry5 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long6 = zipArchiveEntry5.getExternalAttributes();
        java.io.InputStream inputStream7 = java.io.InputStream.nullInputStream();
        byte[] byteArray9 = inputStream7.readNBytes((int) (short) 100);
        zipArchiveEntry5.setCentralDirectoryExtra(byteArray9);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry11);
        java.util.Date date13 = zipArchiveEntry11.getLastModifiedDate();
        zipArchiveEntry11.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker16 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry11.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker16);
        java.io.InputStream inputStream18 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream19 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream18);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime21 = zipArchiveEntry20.getCreationTime();
        long long22 = zipArchiveEntry20.getSize();
        byte[] byteArray23 = zipArchiveEntry20.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField24 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int26 = asiExtraField24.getMode(100);
        boolean boolean27 = asiExtraField24.isDirectory();
        zipArchiveEntry20.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField24);
        asiExtraField24.setGroupId(10);
        byte[] byteArray31 = asiExtraField24.getCentralDirectoryData();
        int int32 = inputStream18.read(byteArray31);
        inputStream18.mark(227);
        byte[] byteArray36 = inputStream18.readNBytes((int) (short) 1);
        jarMarker16.parseFromCentralDirectoryData(byteArray36, 4095, (int) (short) 0);
        int int40 = zipArchiveInputStream4.read(byteArray36);
        long long42 = zipArchiveInputStream4.skip(312857008603L);
        zipArchiveInputStream4.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertEquals(date13.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream18);
        org.junit.Assert.assertNull(fileTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNull(byteArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32868 + "'", int26 == 32868);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
    }

    @Test
    public void test1087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1087");
        java.io.InputStream inputStream1 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream2 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream1);
        java.io.InputStream inputStream3 = java.io.InputStream.nullInputStream();
        byte[] byteArray5 = inputStream3.readNBytes((int) (short) 100);
        int int8 = zipArchiveInputStream2.read(byteArray5, (int) ' ', 40960);
        byte[] byteArray9 = zipArchiveInputStream2.readAllBytes();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker10 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort11 = jarMarker10.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort12 = jarMarker10.getLocalFileDataLength();
        byte[] byteArray13 = jarMarker10.getCentralDirectoryData();
        int int16 = zipArchiveInputStream2.read(byteArray13, 100, (int) (short) -1);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField17 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray13);
        unicodePathExtraField17.setNameCRC32(10L);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort20 = unicodePathExtraField17.getCentralDirectoryLength();
        org.junit.Assert.assertNotNull(inputStream3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] {});
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort11);
        org.junit.Assert.assertNotNull(zipShort12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] {});
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(zipShort20);
    }

    @Test
    public void test1088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1088");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        long long8 = zipArchiveInputStream6.skip((long) 65281);
        long long10 = zipArchiveInputStream6.skip(312796988911L);
        byte[] byteArray11 = zipArchiveInputStream6.readAllBytes();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
    }

    @Test
    public void test1089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1089");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField7 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int9 = asiExtraField7.getMode(100);
        asiExtraField7.setGroupId(32868);
        byte[] byteArray12 = asiExtraField7.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort13 = asiExtraField7.getCentralDirectoryLength();
        asiExtraField7.setMode((int) (byte) 0);
        asiExtraField7.setUserId(16384);
        int int18 = asiExtraField7.getUserId();
        int int20 = asiExtraField7.getMode((int) (short) 0);
        byte[] byteArray21 = asiExtraField7.getCentralDirectoryData();
        zipArchiveEntry0.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField7);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry23 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long24 = zipArchiveEntry23.getExternalAttributes();
        java.io.InputStream inputStream25 = java.io.InputStream.nullInputStream();
        byte[] byteArray27 = inputStream25.readNBytes((int) (short) 100);
        zipArchiveEntry23.setCentralDirectoryExtra(byteArray27);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry29 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry23);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry30 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry29);
        java.util.Date date31 = zipArchiveEntry29.getLastModifiedDate();
        zipArchiveEntry29.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker34 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry29.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker34);
        zipArchiveEntry29.setUnixMode(0);
        boolean boolean38 = zipArchiveEntry29.isDirectory();
        int int39 = zipArchiveEntry29.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry40 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long41 = zipArchiveEntry40.getExternalAttributes();
        zipArchiveEntry40.setSize((long) 28789);
        zipArchiveEntry40.setCrc(10L);
        zipArchiveEntry40.setPlatform(4095);
        java.lang.String str48 = zipArchiveEntry40.getName();
        java.nio.file.attribute.FileTime fileTime49 = zipArchiveEntry40.getCreationTime();
        byte[] byteArray50 = zipArchiveEntry40.getExtra();
        zipArchiveEntry40.setComment("a\000");
        java.lang.String str53 = zipArchiveEntry40.getName();
        java.io.InputStream inputStream54 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream55 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream54);
        long long57 = zipArchiveInputStream55.skip((long) 'a');
        byte[] byteArray59 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray60 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray59);
        int int63 = zipArchiveInputStream55.read(byteArray59, (int) ' ', 40960);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray65 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray59, false);
        zipArchiveEntry40.setExtraFields(zipExtraFieldArray65);
        java.util.Date date67 = zipArchiveEntry40.getLastModifiedDate();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry68 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime69 = zipArchiveEntry68.getCreationTime();
        byte[] byteArray71 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray72 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray71);
        zipArchiveEntry68.setExtraFields(zipExtraFieldArray72);
        zipArchiveEntry68.setTime((long) 32868);
        int int76 = zipArchiveEntry68.getPlatform();
        zipArchiveEntry68.setMethod(0);
        java.nio.file.attribute.FileTime fileTime79 = zipArchiveEntry68.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry80 = zipArchiveEntry40.setLastModifiedTime(fileTime79);
        java.util.zip.ZipEntry zipEntry81 = zipArchiveEntry29.setLastAccessTime(fileTime79);
        java.util.zip.ZipEntry zipEntry82 = zipArchiveEntry0.setCreationTime(fileTime79);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32868 + "'", int9 == 32868);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) -11, (byte) 69, (byte) -93, (byte) 15, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 100, (byte) -128 });
        org.junit.Assert.assertNotNull(zipShort13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16384 + "'", int18 == 16384);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 32768 + "'", int20 == 32768);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 122, (byte) -56, (byte) 108, (byte) 25, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 64, (byte) 100, (byte) -128 });
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(inputStream25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] {});
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertEquals(date31.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "" + "'", str48, "");
        org.junit.Assert.assertNull(fileTime49);
        org.junit.Assert.assertNull(byteArray50);
        org.junit.Assert.assertEquals("'" + str53 + "' != '" + "" + "'", str53, "");
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertArrayEquals(byteArray59, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray60);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray60, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(zipExtraFieldArray65);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray65, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertEquals(date67.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNull(fileTime69);
        org.junit.Assert.assertNotNull(byteArray71);
        org.junit.Assert.assertArrayEquals(byteArray71, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray72);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray72, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(fileTime79);
        org.junit.Assert.assertNotNull(zipEntry80);
        org.junit.Assert.assertEquals(zipEntry80.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry81);
        org.junit.Assert.assertEquals(zipEntry81.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry82);
        org.junit.Assert.assertEquals(zipEntry82.toString(), "");
    }

    @Test
    public void test1090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1090");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort13 = jarMarker11.getCentralDirectoryLength();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        byte[] byteArray17 = zipArchiveInputStream15.readNBytes(8);
        jarMarker11.parseFromCentralDirectoryData(byteArray17, 10, 0);
        byte[] byteArray21 = jarMarker11.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort22 = jarMarker11.getLocalFileDataLength();
        byte[] byteArray23 = jarMarker11.getLocalFileDataData();
        byte[] byteArray25 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            jarMarker11.parseFromLocalFileData(byteArray25, 19280, 35582);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: JarMarker doesn't expect any data");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(zipShort13);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) 1, (byte) 0 });
    }

    @Test
    public void test1091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1091");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setUnixMode(0);
        zipArchiveEntry0.setCrc(0L);
        int int6 = zipArchiveEntry0.getPlatform();
        java.io.InputStream inputStream7 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream7);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime10 = zipArchiveEntry9.getCreationTime();
        long long11 = zipArchiveEntry9.getSize();
        byte[] byteArray12 = zipArchiveEntry9.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField13 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int15 = asiExtraField13.getMode(100);
        boolean boolean16 = asiExtraField13.isDirectory();
        zipArchiveEntry9.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField13);
        asiExtraField13.setGroupId(10);
        byte[] byteArray20 = asiExtraField13.getCentralDirectoryData();
        int int21 = inputStream7.read(byteArray20);
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveEntry0.setCentralDirectoryExtra(byteArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: data starting at 0 is in unknown format");
        } catch (java.lang.RuntimeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNull(fileTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 32868 + "'", int15 == 32868);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test1092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1092");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray3 = zipArchiveInputStream1.readNBytes(8);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        int int5 = zipArchiveInputStream1.read();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry6 = zipArchiveInputStream1.getNextEntry();
        long long8 = zipArchiveInputStream1.skip((long) 5);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertArrayEquals(byteArray3, new byte[] {});
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(archiveEntry6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test1093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1093");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker1 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray7 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField8 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        int int9 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray7);
        jarMarker1.parseFromLocalFileData(byteArray7, 511, 0);
        boolean boolean14 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray7, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField15 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = unicodePathExtraField15.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long18 = zipArchiveEntry17.getExternalAttributes();
        zipArchiveEntry17.setSize((long) 28789);
        zipArchiveEntry17.setCrc(10L);
        zipArchiveEntry17.setPlatform(4095);
        byte[] byteArray25 = zipArchiveEntry17.getCentralDirectoryExtra();
        byte[] byteArray26 = zipArchiveEntry17.getLocalFileDataExtra();
        java.lang.String str27 = zipArchiveEntry17.getName();
        byte[] byteArray30 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean32 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray30, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField33 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray30);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort34 = unicodeCommentExtraField33.getHeaderId();
        zipArchiveEntry17.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField33);
        byte[] byteArray36 = unicodeCommentExtraField33.getUnicodeName();
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray37 = new org.apache.commons.compress.archivers.zip.ZipExtraField[] { unicodePathExtraField15, unicodeCommentExtraField33 };
        byte[] byteArray38 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeLocalFileDataData(zipExtraFieldArray37);
        byte[] byteArray39 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeLocalFileDataData(zipExtraFieldArray37);
        byte[] byteArray40 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeLocalFileDataData(zipExtraFieldArray37);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray42 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray40, false);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 65281 + "'", int9 == 65281);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] {});
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertArrayEquals(byteArray30, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(zipShort34);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertArrayEquals(byteArray38, new byte[] { (byte) 117, (byte) 112, (byte) 5, (byte) 0, (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16, (byte) 117, (byte) 99, (byte) 5, (byte) 0, (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertArrayEquals(byteArray39, new byte[] { (byte) 117, (byte) 112, (byte) 5, (byte) 0, (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16, (byte) 117, (byte) 99, (byte) 5, (byte) 0, (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertArrayEquals(byteArray40, new byte[] { (byte) 117, (byte) 112, (byte) 5, (byte) 0, (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16, (byte) 117, (byte) 99, (byte) 5, (byte) 0, (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray42);
    }

    @Test
    public void test1094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1094");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray3 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray2);
        int int4 = inputStream0.read(byteArray2);
        inputStream0.close();
        boolean boolean6 = inputStream0.markSupported();
        inputStream0.mark(511);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream11 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "nu", true);
        long long13 = zipArchiveInputStream11.skip((long) 25461);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray3);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray3, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test1095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1095");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker1 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray7 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField8 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        int int9 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray7);
        jarMarker1.parseFromLocalFileData(byteArray7, 511, 0);
        boolean boolean14 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray7, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField15 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = unicodePathExtraField15.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long18 = zipArchiveEntry17.getExternalAttributes();
        zipArchiveEntry17.setSize((long) 28789);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry21 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry17);
        zipArchiveEntry17.setExtra();
        boolean boolean23 = zipShort16.equals((java.lang.Object) zipArchiveEntry17);
        long long24 = zipArchiveEntry17.getCompressedSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry25 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long26 = zipArchiveEntry25.getExternalAttributes();
        zipArchiveEntry25.setSize((long) 28789);
        byte[] byteArray29 = zipArchiveEntry25.getExtra();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry30 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry25);
        zipArchiveEntry30.setCrc(33639248L);
        zipArchiveEntry30.setExtra();
        boolean boolean34 = zipArchiveEntry17.equals((java.lang.Object) zipArchiveEntry30);
        java.lang.String str35 = zipArchiveEntry17.getComment();
        long long36 = zipArchiveEntry17.getCrc();
        int int37 = zipArchiveEntry17.getUnixMode();
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 65281 + "'", int9 == 65281);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test1096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1096");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        int int8 = zipArchiveInputStream1.available();
        int int9 = zipArchiveInputStream1.getCount();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.ArchiveEntry archiveEntry10 = zipArchiveInputStream1.getNextEntry();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Stream closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test1097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1097");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime1 = zipArchiveEntry0.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry2 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        boolean boolean4 = zipArchiveEntry0.equals((java.lang.Object) 28789);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker6 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField13 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray12);
        int int14 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray12);
        jarMarker6.parseFromLocalFileData(byteArray12, 511, 0);
        boolean boolean19 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray12, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField20 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray12);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort21 = unicodePathExtraField20.getCentralDirectoryLength();
        byte[] byteArray22 = unicodePathExtraField20.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort23 = unicodePathExtraField20.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry24 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long25 = zipArchiveEntry24.getExternalAttributes();
        zipArchiveEntry24.setSize((long) 28789);
        zipArchiveEntry24.setCrc(10L);
        zipArchiveEntry24.setPlatform(4095);
        java.lang.String str32 = zipArchiveEntry24.getName();
        byte[] byteArray34 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        zipArchiveEntry24.setCentralDirectoryExtra(byteArray34);
        unicodePathExtraField20.setUnicodeName(byteArray34);
        zipArchiveEntry0.setExtra(byteArray34);
        boolean boolean38 = zipArchiveEntry0.isDirectory();
        org.junit.Assert.assertNull(fileTime1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 65281 + "'", int14 == 65281);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(zipShort21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(zipShort23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertArrayEquals(byteArray34, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test1098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1098");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField7 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int8 = asiExtraField7.getGroupId();
        asiExtraField7.setDirectory(true);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort11 = asiExtraField7.getHeaderId();
        byte[] byteArray12 = asiExtraField7.getCentralDirectoryData();
        int int13 = zipArchiveInputStream1.read(byteArray12);
        int int14 = zipArchiveInputStream1.available();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker15 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = jarMarker15.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort17 = jarMarker15.getLocalFileDataLength();
        byte[] byteArray18 = jarMarker15.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort19 = jarMarker15.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort20 = jarMarker15.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort21 = jarMarker15.getCentralDirectoryLength();
        byte[] byteArray22 = jarMarker15.getLocalFileDataData();
        byte[] byteArray23 = jarMarker15.getLocalFileDataData();
        int int26 = zipArchiveInputStream1.read(byteArray23, 65535, 40960);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(zipShort11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertNotNull(zipShort17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort19);
        org.junit.Assert.assertNotNull(zipShort20);
        org.junit.Assert.assertNotNull(zipShort21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] {});
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test1099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1099");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding0 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean2 = fallbackZipEncoding0.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry3 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime4 = zipArchiveEntry3.getCreationTime();
        long long5 = zipArchiveEntry3.getSize();
        byte[] byteArray6 = zipArchiveEntry3.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField7 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int9 = asiExtraField7.getMode(100);
        boolean boolean10 = asiExtraField7.isDirectory();
        zipArchiveEntry3.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField7);
        byte[] byteArray12 = asiExtraField7.getCentralDirectoryData();
        int int14 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray12, 3);
        int int15 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray12);
        java.lang.String str16 = fallbackZipEncoding0.decode(byteArray12);
        java.io.InputStream inputStream17 = java.io.InputStream.nullInputStream();
        byte[] byteArray19 = inputStream17.readNBytes((int) (short) 100);
        java.lang.String str20 = fallbackZipEncoding0.decode(byteArray19);
        java.io.InputStream inputStream21 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream22 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream21);
        java.io.InputStream inputStream23 = java.io.InputStream.nullInputStream();
        byte[] byteArray25 = inputStream23.readNBytes((int) (short) 100);
        int int28 = zipArchiveInputStream22.read(byteArray25, (int) ' ', 40960);
        java.lang.String str29 = fallbackZipEncoding0.decode(byteArray25);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray31 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray25, true);
        byte[] byteArray32 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray31);
        byte[] byteArray33 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeLocalFileDataData(zipExtraFieldArray31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(fileTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32868 + "'", int9 == 32868);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 227 + "'", int14 == 227);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 26742 + "'", int15 == 26742);
// flaky "5) test1099(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str16, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertNotNull(inputStream17);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] {});
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertNotNull(inputStream23);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertNotNull(zipExtraFieldArray31);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray31, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] {});
    }

    @Test
    public void test1100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1100");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry2 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime3 = zipArchiveEntry2.getCreationTime();
        long long4 = zipArchiveEntry2.getSize();
        byte[] byteArray5 = zipArchiveEntry2.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField6 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int8 = asiExtraField6.getMode(100);
        boolean boolean9 = asiExtraField6.isDirectory();
        zipArchiveEntry2.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField6);
        asiExtraField6.setGroupId(10);
        byte[] byteArray13 = asiExtraField6.getCentralDirectoryData();
        int int14 = inputStream0.read(byteArray13);
        inputStream0.mark(227);
        byte[] byteArray18 = inputStream0.readNBytes((int) (short) 1);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray19 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray18);
        byte[] byteArray20 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray19);
        byte[] byteArray21 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray19);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(fileTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32868 + "'", int8 == 32868);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray19);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray19, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] {});
    }

    @Test
    public void test1101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1101");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.close();
        zipArchiveInputStream1.mark(28789);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry5 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long8 = zipArchiveEntry7.getExternalAttributes();
        java.lang.Object obj9 = zipArchiveEntry7.clone();
        java.nio.file.attribute.FileTime fileTime10 = zipArchiveEntry7.getLastAccessTime();
        byte[] byteArray11 = zipArchiveEntry7.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long13 = zipArchiveEntry12.getExternalAttributes();
        zipArchiveEntry12.setSize((long) 28789);
        zipArchiveEntry12.setCrc(10L);
        zipArchiveEntry12.setPlatform(4095);
        java.lang.String str20 = zipArchiveEntry12.getName();
        byte[] byteArray22 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        zipArchiveEntry12.setCentralDirectoryExtra(byteArray22);
        long long24 = zipArchiveEntry12.getSize();
        byte[] byteArray25 = zipArchiveEntry12.getCentralDirectoryExtra();
        java.io.InputStream inputStream26 = java.io.InputStream.nullInputStream();
        byte[] byteArray28 = inputStream26.readNBytes((int) (short) 100);
        byte[] byteArray30 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray31 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray30);
        int int32 = inputStream26.read(byteArray30);
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry7, byteArray25, byteArray30);
        // The following exception was thrown during execution in test generation
        try {
            int int36 = zipArchiveInputStream1.read(byteArray30, 55041, 21589);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertEquals(obj9.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj9), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj9), "");
        org.junit.Assert.assertNull(fileTime10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28789L + "'", long24 == 28789L);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(inputStream26);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertArrayEquals(byteArray30, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray31);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray31, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test1102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1102");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int13 = zipArchiveInputStream1.read(byteArray10, (-1), 100);
        int int14 = zipArchiveInputStream1.read();
        byte[] byteArray16 = zipArchiveInputStream1.readNBytes(64440);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] {});
    }

    @Test
    public void test1103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1103");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        int int7 = zipArchiveInputStream6.read();
        int int8 = zipArchiveInputStream6.available();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream9 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.ArchiveEntry archiveEntry10 = zipArchiveInputStream6.getNextEntry();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test1104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1104");
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField0 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int2 = asiExtraField0.getMode(100);
        boolean boolean3 = asiExtraField0.isLink();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort4 = asiExtraField0.getLocalFileDataLength();
        int int6 = asiExtraField0.getMode(0);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding7 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean9 = fallbackZipEncoding7.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry10 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime11 = zipArchiveEntry10.getCreationTime();
        long long12 = zipArchiveEntry10.getSize();
        byte[] byteArray13 = zipArchiveEntry10.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField14 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int16 = asiExtraField14.getMode(100);
        boolean boolean17 = asiExtraField14.isDirectory();
        zipArchiveEntry10.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField14);
        byte[] byteArray19 = asiExtraField14.getCentralDirectoryData();
        int int21 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray19, 3);
        int int22 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray19);
        java.lang.String str23 = fallbackZipEncoding7.decode(byteArray19);
        java.io.InputStream inputStream24 = java.io.InputStream.nullInputStream();
        byte[] byteArray26 = inputStream24.readNBytes((int) (short) 100);
        java.lang.String str27 = fallbackZipEncoding7.decode(byteArray26);
        boolean boolean29 = fallbackZipEncoding7.canEncode("\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        java.io.InputStream inputStream31 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream32 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream31);
        java.io.InputStream inputStream33 = java.io.InputStream.nullInputStream();
        byte[] byteArray35 = inputStream33.readNBytes((int) (short) 100);
        int int38 = zipArchiveInputStream32.read(byteArray35, (int) ' ', 40960);
        byte[] byteArray39 = zipArchiveInputStream32.readAllBytes();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker40 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort41 = jarMarker40.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort42 = jarMarker40.getLocalFileDataLength();
        byte[] byteArray43 = jarMarker40.getCentralDirectoryData();
        int int46 = zipArchiveInputStream32.read(byteArray43, 100, (int) (short) -1);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField47 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray43);
        java.lang.String str48 = fallbackZipEncoding7.decode(byteArray43);
        boolean boolean50 = fallbackZipEncoding7.canEncode("\000\ufffd\000\000");
        java.nio.ByteBuffer byteBuffer52 = fallbackZipEncoding7.encode("\000\000");
        org.apache.commons.compress.archivers.zip.ZipShort zipShort54 = new org.apache.commons.compress.archivers.zip.ZipShort((int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField55 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort54);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField56 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort54);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry57 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long58 = zipArchiveEntry57.getExternalAttributes();
        zipArchiveEntry57.setSize((long) 28789);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry61 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry57);
        java.lang.String str62 = zipArchiveEntry57.getComment();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField64 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int66 = asiExtraField64.getMode(100);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort67 = asiExtraField64.getCentralDirectoryLength();
        byte[] byteArray68 = asiExtraField64.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField69 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray68);
        byte[] byteArray70 = unicodePathExtraField69.getUnicodeName();
        zipArchiveEntry57.setCentralDirectoryExtra(byteArray70);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField72 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int74 = asiExtraField72.getMode(100);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort75 = asiExtraField72.getCentralDirectoryLength();
        byte[] byteArray76 = asiExtraField72.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort77 = asiExtraField72.getLocalFileDataLength();
        byte[] byteArray79 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray80 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray79);
        byte[] byteArray81 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray80);
        boolean boolean82 = zipShort77.equals((java.lang.Object) zipExtraFieldArray80);
        zipArchiveEntry57.setExtraFields(zipExtraFieldArray80);
        byte[] byteArray84 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeLocalFileDataData(zipExtraFieldArray80);
        boolean boolean85 = zipShort54.equals((java.lang.Object) zipExtraFieldArray80);
        byte[] byteArray86 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray80);
        java.lang.String str87 = fallbackZipEncoding7.decode(byteArray86);
        // The following exception was thrown during execution in test generation
        try {
            asiExtraField0.parseFromLocalFileData(byteArray86, 14, 64440);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 17 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32868 + "'", int2 == 32868);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(zipShort4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32768 + "'", int6 == 32768);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(fileTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32868 + "'", int16 == 32868);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 227 + "'", int21 == 227);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 26742 + "'", int22 == 26742);
// flaky "6) test1104(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str23 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str23, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertNotNull(inputStream24);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] {});
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(inputStream33);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] {});
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertArrayEquals(byteArray39, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort41);
        org.junit.Assert.assertNotNull(zipShort42);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] {});
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "" + "'", str48, "");
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(byteBuffer52);
        org.junit.Assert.assertNotNull(zipExtraField55);
        org.junit.Assert.assertNotNull(zipExtraField56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 32868 + "'", int66 == 32868);
        org.junit.Assert.assertNotNull(zipShort67);
        org.junit.Assert.assertNotNull(byteArray68);
        org.junit.Assert.assertArrayEquals(byteArray68, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertArrayEquals(byteArray70, new byte[] {});
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 32868 + "'", int74 == 32868);
        org.junit.Assert.assertNotNull(zipShort75);
        org.junit.Assert.assertNotNull(byteArray76);
        org.junit.Assert.assertArrayEquals(byteArray76, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipShort77);
        org.junit.Assert.assertNotNull(byteArray79);
        org.junit.Assert.assertArrayEquals(byteArray79, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray80);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray80, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertArrayEquals(byteArray81, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(byteArray84);
        org.junit.Assert.assertArrayEquals(byteArray84, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(byteArray86);
        org.junit.Assert.assertArrayEquals(byteArray86, new byte[] {});
        org.junit.Assert.assertEquals("'" + str87 + "' != '" + "" + "'", str87, "");
    }

    @Test
    public void test1105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1105");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime16 = zipArchiveEntry15.getCreationTime();
        long long17 = zipArchiveEntry15.getSize();
        byte[] byteArray18 = zipArchiveEntry15.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField19 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int21 = asiExtraField19.getMode(100);
        boolean boolean22 = asiExtraField19.isDirectory();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField19);
        asiExtraField19.setGroupId(10);
        byte[] byteArray26 = asiExtraField19.getCentralDirectoryData();
        int int27 = inputStream13.read(byteArray26);
        inputStream13.mark(227);
        byte[] byteArray31 = inputStream13.readNBytes((int) (short) 1);
        jarMarker11.parseFromCentralDirectoryData(byteArray31, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = jarMarker11.getLocalFileDataLength();
        byte[] byteArray36 = jarMarker11.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry38 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long39 = zipArchiveEntry38.getExternalAttributes();
        zipArchiveEntry38.setSize((long) 28789);
        boolean boolean42 = zipArchiveEntry38.isDirectory();
        java.lang.Object obj43 = zipArchiveEntry38.clone();
        java.lang.String str44 = zipArchiveEntry38.getComment();
        byte[] byteArray45 = zipArchiveEntry38.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField46 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("UTF8", byteArray45);
        jarMarker11.parseFromCentralDirectoryData(byteArray45, (int) (byte) 100, 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort50 = jarMarker11.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort51 = jarMarker11.getLocalFileDataLength();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(fileTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32868 + "'", int21 == 32868);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertEquals(obj43.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj43), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj43), "");
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort50);
        org.junit.Assert.assertNotNull(zipShort51);
    }

    @Test
    public void test1106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1106");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        byte[] byteArray7 = zipArchiveInputStream6.readAllBytes();
        zipArchiveInputStream6.mark(5);
        byte[] byteArray10 = zipArchiveInputStream6.readAllBytes();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
    }

    @Test
    public void test1107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1107");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime16 = zipArchiveEntry15.getCreationTime();
        long long17 = zipArchiveEntry15.getSize();
        byte[] byteArray18 = zipArchiveEntry15.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField19 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int21 = asiExtraField19.getMode(100);
        boolean boolean22 = asiExtraField19.isDirectory();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField19);
        asiExtraField19.setGroupId(10);
        byte[] byteArray26 = asiExtraField19.getCentralDirectoryData();
        int int27 = inputStream13.read(byteArray26);
        inputStream13.mark(227);
        byte[] byteArray31 = inputStream13.readNBytes((int) (short) 1);
        jarMarker11.parseFromCentralDirectoryData(byteArray31, 4095, (int) (short) 0);
        byte[] byteArray35 = jarMarker11.getCentralDirectoryData();
        byte[] byteArray36 = jarMarker11.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort37 = jarMarker11.getLocalFileDataLength();
        byte[] byteArray38 = jarMarker11.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort39 = jarMarker11.getHeaderId();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(fileTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32868 + "'", int21 == 32868);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertArrayEquals(byteArray38, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort39);
    }

    @Test
    public void test1108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1108");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        boolean boolean5 = zipArchiveInputStream1.markSupported();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField6 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int7 = asiExtraField6.getGroupId();
        asiExtraField6.setDirectory(true);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort10 = asiExtraField6.getHeaderId();
        byte[] byteArray11 = asiExtraField6.getCentralDirectoryData();
        int int14 = zipArchiveInputStream1.read(byteArray11, 0, 420);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime16 = zipArchiveEntry15.getCreationTime();
        long long17 = zipArchiveEntry15.getSize();
        byte[] byteArray18 = zipArchiveEntry15.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField19 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int21 = asiExtraField19.getMode(100);
        boolean boolean22 = asiExtraField19.isDirectory();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField19);
        byte[] byteArray24 = asiExtraField19.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong25 = new org.apache.commons.compress.archivers.zip.ZipLong(byteArray24);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField27 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int29 = asiExtraField27.getMode(100);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort30 = asiExtraField27.getCentralDirectoryLength();
        byte[] byteArray31 = asiExtraField27.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField32 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray31);
        byte[] byteArray33 = unicodePathExtraField32.getUnicodeName();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort34 = unicodePathExtraField32.getLocalFileDataLength();
        boolean boolean35 = zipLong25.equals((java.lang.Object) unicodePathExtraField32);
        byte[] byteArray36 = unicodePathExtraField32.getUnicodeName();
        int int39 = zipArchiveInputStream1.read(byteArray36, 32868, (int) (byte) 0);
        int int40 = zipArchiveInputStream1.available();
        byte[] byteArray43 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean45 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray43, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField46 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray43);
        byte[] byteArray47 = unicodeCommentExtraField46.getCentralDirectoryData();
        long long48 = unicodeCommentExtraField46.getNameCRC32();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong50 = new org.apache.commons.compress.archivers.zip.ZipLong((long) (short) -1);
        long long51 = zipLong50.getValue();
        java.util.Date date52 = org.apache.commons.compress.archivers.zip.ZipUtil.fromDosTime(zipLong50);
        org.apache.commons.compress.archivers.zip.ZipLong zipLong53 = org.apache.commons.compress.archivers.zip.ZipUtil.toDosTime(date52);
        byte[] byteArray54 = zipLong53.getBytes();
        unicodeCommentExtraField46.setUnicodeName(byteArray54);
        int int56 = zipArchiveInputStream1.read(byteArray54);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(zipShort10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(fileTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32868 + "'", int21 == 32868);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 32868 + "'", int29 == 32868);
        org.junit.Assert.assertNotNull(zipShort30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertArrayEquals(byteArray47, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1104745215L + "'", long48 == 1104745215L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertEquals(date52.toString(), "Sun Apr 01 08:04:02 PDT 2108");
        org.junit.Assert.assertNotNull(zipLong53);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertArrayEquals(byteArray54, new byte[] { (byte) -127, (byte) 64, (byte) -127, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
    }

    @Test
    public void test1109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1109");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        boolean boolean5 = zipArchiveInputStream1.markSupported();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField6 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int7 = asiExtraField6.getGroupId();
        asiExtraField6.setDirectory(true);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort10 = asiExtraField6.getHeaderId();
        byte[] byteArray11 = asiExtraField6.getCentralDirectoryData();
        int int14 = zipArchiveInputStream1.read(byteArray11, 0, 420);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime16 = zipArchiveEntry15.getCreationTime();
        long long17 = zipArchiveEntry15.getSize();
        byte[] byteArray18 = zipArchiveEntry15.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField19 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int21 = asiExtraField19.getMode(100);
        boolean boolean22 = asiExtraField19.isDirectory();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField19);
        byte[] byteArray24 = asiExtraField19.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong25 = new org.apache.commons.compress.archivers.zip.ZipLong(byteArray24);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField27 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int29 = asiExtraField27.getMode(100);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort30 = asiExtraField27.getCentralDirectoryLength();
        byte[] byteArray31 = asiExtraField27.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField32 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray31);
        byte[] byteArray33 = unicodePathExtraField32.getUnicodeName();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort34 = unicodePathExtraField32.getLocalFileDataLength();
        boolean boolean35 = zipLong25.equals((java.lang.Object) unicodePathExtraField32);
        byte[] byteArray36 = unicodePathExtraField32.getUnicodeName();
        int int39 = zipArchiveInputStream1.read(byteArray36, 32868, (int) (byte) 0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray40 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray36);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(zipShort10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(fileTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32868 + "'", int21 == 32868);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 32868 + "'", int29 == 32868);
        org.junit.Assert.assertNotNull(zipShort30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(zipExtraFieldArray40);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray40, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
    }

    @Test
    public void test1110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1110");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry6 = zipArchiveInputStream1.getNextEntry();
        byte[] byteArray7 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding9 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean11 = fallbackZipEncoding9.canEncode("hi!");
        boolean boolean13 = fallbackZipEncoding9.canEncode("hi!");
        boolean boolean15 = fallbackZipEncoding9.canEncode("hi!");
        byte[] byteArray17 = org.apache.commons.compress.archivers.zip.ZipUtil.toDosTime(1L);
        java.lang.String str18 = fallbackZipEncoding9.decode(byteArray17);
        int int21 = zipArchiveInputStream1.read(byteArray17, 26681, 16419);
        byte[] byteArray22 = null;
        int int25 = zipArchiveInputStream1.read(byteArray22, (int) (byte) 100, 26984);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(archiveEntry6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 0, (byte) 33, (byte) 0, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "\000!\000\000" + "'", str18, "\000!\000\000");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test1111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1111");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        zipArchiveInputStream1.mark(5);
        int int8 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry9 = zipArchiveInputStream1.getNextEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(archiveEntry9);
    }

    @Test
    public void test1112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1112");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry5 = zipArchiveInputStream1.getNextEntry();
        byte[] byteArray7 = zipArchiveInputStream1.readNBytes((int) (byte) 1);
        int int8 = zipArchiveInputStream1.available();
        java.io.OutputStream outputStream9 = null;
        // The following exception was thrown during execution in test generation
        try {
            long long10 = zipArchiveInputStream1.transferTo(outputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertNull(archiveEntry5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test1113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1113");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        java.lang.String str8 = zipArchiveEntry0.getName();
        java.nio.file.attribute.FileTime fileTime9 = zipArchiveEntry0.getCreationTime();
        byte[] byteArray10 = zipArchiveEntry0.getExtra();
        zipArchiveEntry0.setComment("a\000");
        java.lang.String str13 = zipArchiveEntry0.getName();
        java.io.InputStream inputStream14 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        long long17 = zipArchiveInputStream15.skip((long) 'a');
        byte[] byteArray19 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray20 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray19);
        int int23 = zipArchiveInputStream15.read(byteArray19, (int) ' ', 40960);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray25 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray19, false);
        zipArchiveEntry0.setExtraFields(zipExtraFieldArray25);
        java.util.Date date27 = zipArchiveEntry0.getLastModifiedDate();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong28 = org.apache.commons.compress.archivers.zip.ZipUtil.toDosTime(date27);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(fileTime9);
        org.junit.Assert.assertNull(byteArray10);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray20);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray20, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(zipExtraFieldArray25);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray25, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertEquals(date27.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(zipLong28);
    }

    @Test
    public void test1114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1114");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker0 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort1 = jarMarker0.getHeaderId();
        java.io.InputStream inputStream2 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream3 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream2);
        java.io.InputStream inputStream4 = java.io.InputStream.nullInputStream();
        byte[] byteArray6 = inputStream4.readNBytes((int) (short) 100);
        int int9 = zipArchiveInputStream3.read(byteArray6, (int) ' ', 40960);
        byte[] byteArray10 = zipArchiveInputStream3.readAllBytes();
        byte[] byteArray12 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int15 = zipArchiveInputStream3.read(byteArray12, (-1), 100);
        zipArchiveInputStream3.mark(16419);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding18 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean20 = fallbackZipEncoding18.canEncode("hi!");
        boolean boolean22 = fallbackZipEncoding18.canEncode("hi!");
        boolean boolean24 = fallbackZipEncoding18.canEncode("UTF8");
        boolean boolean26 = fallbackZipEncoding18.canEncode("\000\ufffd");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry27 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long28 = zipArchiveEntry27.getExternalAttributes();
        zipArchiveEntry27.setSize((long) 28789);
        zipArchiveEntry27.setCrc(10L);
        zipArchiveEntry27.setPlatform(4095);
        byte[] byteArray35 = zipArchiveEntry27.getCentralDirectoryExtra();
        boolean boolean37 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray35, (int) (byte) 0);
        java.lang.String str38 = fallbackZipEncoding18.decode(byteArray35);
        boolean boolean40 = fallbackZipEncoding18.canEncode("");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding41 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        byte[] byteArray43 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) 'a');
        java.lang.String str44 = fallbackZipEncoding41.decode(byteArray43);
        java.lang.String str45 = fallbackZipEncoding18.decode(byteArray43);
        int int48 = zipArchiveInputStream3.readNBytes(byteArray43, 0, 0);
        byte[] byteArray50 = zipArchiveInputStream3.readNBytes((int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            jarMarker0.parseFromLocalFileData(byteArray50, (int) (short) 1, 51966);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: JarMarker doesn't expect any data");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(zipShort1);
        org.junit.Assert.assertNotNull(inputStream4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] {});
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 97, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "a\000" + "'", str44, "a\000");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "a\000" + "'", str45, "a\000");
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertArrayEquals(byteArray50, new byte[] {});
    }

    @Test
    public void test1115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1115");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int13 = zipArchiveInputStream1.read(byteArray10, (-1), 100);
        zipArchiveInputStream1.mark((int) (short) 1);
        zipArchiveInputStream1.close();
        long long18 = zipArchiveInputStream1.skip(0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test1116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1116");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        byte[] byteArray7 = zipArchiveInputStream6.readAllBytes();
        zipArchiveInputStream6.mark(5);
        byte[] byteArray12 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField13 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("a\000", byteArray12);
        byte[] byteArray14 = unicodeCommentExtraField13.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort15 = unicodeCommentExtraField13.getHeaderId();
        byte[] byteArray16 = unicodeCommentExtraField13.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong17 = new org.apache.commons.compress.archivers.zip.ZipLong(byteArray16);
        int int18 = zipArchiveInputStream6.read(byteArray16);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream19 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] { (byte) 1, (byte) -22, (byte) -80, (byte) 13, (byte) 94, (byte) 97, (byte) 0 });
        org.junit.Assert.assertNotNull(zipShort15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] { (byte) 1, (byte) -22, (byte) -80, (byte) 13, (byte) 94, (byte) 97, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test1117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1117");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        int int7 = zipArchiveInputStream6.read();
        int int8 = zipArchiveInputStream6.available();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream9 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry10 = zipArchiveInputStream9.getNextEntry();
        long long12 = zipArchiveInputStream9.skip((long) 26742);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(archiveEntry10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test1118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1118");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        java.nio.file.attribute.FileTime fileTime9 = zipArchiveEntry6.getLastModifiedTime();
        java.nio.file.attribute.FileTime fileTime10 = zipArchiveEntry6.getLastModifiedTime();
        java.nio.file.attribute.FileTime fileTime11 = zipArchiveEntry6.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry13 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long14 = zipArchiveEntry13.getExternalAttributes();
        java.io.InputStream inputStream15 = java.io.InputStream.nullInputStream();
        byte[] byteArray17 = inputStream15.readNBytes((int) (short) 100);
        zipArchiveEntry13.setCentralDirectoryExtra(byteArray17);
        int int19 = zipArchiveEntry13.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry13);
        long long21 = zipArchiveEntry13.getCrc();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry22 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long23 = zipArchiveEntry22.getExternalAttributes();
        java.io.InputStream inputStream24 = java.io.InputStream.nullInputStream();
        byte[] byteArray26 = inputStream24.readNBytes((int) (short) 100);
        zipArchiveEntry22.setCentralDirectoryExtra(byteArray26);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry22);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry29 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry28);
        java.util.Date date30 = zipArchiveEntry28.getLastModifiedDate();
        zipArchiveEntry28.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker33 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry28.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker33);
        java.io.InputStream inputStream35 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream36 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream35);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry37 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime38 = zipArchiveEntry37.getCreationTime();
        long long39 = zipArchiveEntry37.getSize();
        byte[] byteArray40 = zipArchiveEntry37.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField41 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int43 = asiExtraField41.getMode(100);
        boolean boolean44 = asiExtraField41.isDirectory();
        zipArchiveEntry37.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField41);
        asiExtraField41.setGroupId(10);
        byte[] byteArray48 = asiExtraField41.getCentralDirectoryData();
        int int49 = inputStream35.read(byteArray48);
        inputStream35.mark(227);
        byte[] byteArray53 = inputStream35.readNBytes((int) (short) 1);
        jarMarker33.parseFromCentralDirectoryData(byteArray53, 4095, (int) (short) 0);
        byte[] byteArray57 = jarMarker33.getCentralDirectoryData();
        byte[] byteArray58 = jarMarker33.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray60 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray58, true);
        zipArchiveEntry13.setExtraFields(zipExtraFieldArray60);
        byte[] byteArray62 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray60);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField63 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("\001\u01bahi!", byteArray62);
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodePathExtraField63);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNull(fileTime9);
        org.junit.Assert.assertNull(fileTime10);
        org.junit.Assert.assertNull(fileTime11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(inputStream15);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(inputStream24);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] {});
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertEquals(date30.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream35);
        org.junit.Assert.assertNull(fileTime38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertNull(byteArray40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 32868 + "'", int43 == 32868);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertArrayEquals(byteArray48, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertArrayEquals(byteArray53, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertArrayEquals(byteArray57, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertArrayEquals(byteArray58, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray60);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray60, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertArrayEquals(byteArray62, new byte[] {});
    }

    @Test
    public void test1119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1119");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        int int6 = zipArchiveEntry0.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        long long8 = zipArchiveEntry0.getCrc();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long10 = zipArchiveEntry9.getExternalAttributes();
        java.io.InputStream inputStream11 = java.io.InputStream.nullInputStream();
        byte[] byteArray13 = inputStream11.readNBytes((int) (short) 100);
        zipArchiveEntry9.setCentralDirectoryExtra(byteArray13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry9);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry16 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry15);
        java.util.Date date17 = zipArchiveEntry15.getLastModifiedDate();
        zipArchiveEntry15.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker20 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker20);
        java.io.InputStream inputStream22 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream23 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream22);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry24 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime25 = zipArchiveEntry24.getCreationTime();
        long long26 = zipArchiveEntry24.getSize();
        byte[] byteArray27 = zipArchiveEntry24.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField28 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int30 = asiExtraField28.getMode(100);
        boolean boolean31 = asiExtraField28.isDirectory();
        zipArchiveEntry24.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField28);
        asiExtraField28.setGroupId(10);
        byte[] byteArray35 = asiExtraField28.getCentralDirectoryData();
        int int36 = inputStream22.read(byteArray35);
        inputStream22.mark(227);
        byte[] byteArray40 = inputStream22.readNBytes((int) (short) 1);
        jarMarker20.parseFromCentralDirectoryData(byteArray40, 4095, (int) (short) 0);
        byte[] byteArray44 = jarMarker20.getCentralDirectoryData();
        byte[] byteArray45 = jarMarker20.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray47 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray45, true);
        zipArchiveEntry0.setExtraFields(zipExtraFieldArray47);
        boolean boolean49 = zipArchiveEntry0.isDirectory();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(inputStream11);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] {});
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertEquals(date17.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNull(fileTime25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertNull(byteArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 32868 + "'", int30 == 32868);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertArrayEquals(byteArray40, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertArrayEquals(byteArray44, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray47);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray47, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test1120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1120");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream4 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry5 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long6 = zipArchiveEntry5.getExternalAttributes();
        java.io.InputStream inputStream7 = java.io.InputStream.nullInputStream();
        byte[] byteArray9 = inputStream7.readNBytes((int) (short) 100);
        zipArchiveEntry5.setCentralDirectoryExtra(byteArray9);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry11);
        java.util.Date date13 = zipArchiveEntry11.getLastModifiedDate();
        zipArchiveEntry11.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker16 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry11.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker16);
        java.io.InputStream inputStream18 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream19 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream18);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime21 = zipArchiveEntry20.getCreationTime();
        long long22 = zipArchiveEntry20.getSize();
        byte[] byteArray23 = zipArchiveEntry20.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField24 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int26 = asiExtraField24.getMode(100);
        boolean boolean27 = asiExtraField24.isDirectory();
        zipArchiveEntry20.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField24);
        asiExtraField24.setGroupId(10);
        byte[] byteArray31 = asiExtraField24.getCentralDirectoryData();
        int int32 = inputStream18.read(byteArray31);
        inputStream18.mark(227);
        byte[] byteArray36 = inputStream18.readNBytes((int) (short) 1);
        jarMarker16.parseFromCentralDirectoryData(byteArray36, 4095, (int) (short) 0);
        int int40 = zipArchiveInputStream4.read(byteArray36);
        int int41 = zipArchiveInputStream4.read();
        zipArchiveInputStream4.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertEquals(date13.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream18);
        org.junit.Assert.assertNull(fileTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNull(byteArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32868 + "'", int26 == 32868);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test1121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1121");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int13 = zipArchiveInputStream1.read(byteArray10, (-1), 100);
        zipArchiveInputStream1.mark(16419);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding16 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean18 = fallbackZipEncoding16.canEncode("hi!");
        boolean boolean20 = fallbackZipEncoding16.canEncode("hi!");
        boolean boolean22 = fallbackZipEncoding16.canEncode("UTF8");
        boolean boolean24 = fallbackZipEncoding16.canEncode("\000\ufffd");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry25 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long26 = zipArchiveEntry25.getExternalAttributes();
        zipArchiveEntry25.setSize((long) 28789);
        zipArchiveEntry25.setCrc(10L);
        zipArchiveEntry25.setPlatform(4095);
        byte[] byteArray33 = zipArchiveEntry25.getCentralDirectoryExtra();
        boolean boolean35 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray33, (int) (byte) 0);
        java.lang.String str36 = fallbackZipEncoding16.decode(byteArray33);
        boolean boolean38 = fallbackZipEncoding16.canEncode("");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding39 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        byte[] byteArray41 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) 'a');
        java.lang.String str42 = fallbackZipEncoding39.decode(byteArray41);
        java.lang.String str43 = fallbackZipEncoding16.decode(byteArray41);
        int int46 = zipArchiveInputStream1.readNBytes(byteArray41, 0, 0);
        zipArchiveInputStream1.close();
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveInputStream1.reset();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: mark/reset not supported");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertArrayEquals(byteArray41, new byte[] { (byte) 97, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "a\000" + "'", str42, "a\000");
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "a\000" + "'", str43, "a\000");
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test1122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1122");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        boolean boolean8 = zipArchiveEntry0.isDirectory();
        zipArchiveEntry0.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        byte[] byteArray12 = zipArchiveEntry0.getLocalFileDataExtra();
        long long13 = zipArchiveEntry0.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry14 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        java.io.InputStream inputStream15 = java.io.InputStream.nullInputStream();
        byte[] byteArray17 = inputStream15.readNBytes((int) (short) 100);
        boolean boolean18 = inputStream15.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream21 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream15, "UTF8", true);
        zipArchiveInputStream21.close();
        boolean boolean23 = zipArchiveEntry14.equals((java.lang.Object) zipArchiveInputStream21);
        long long24 = zipArchiveEntry14.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry25 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long26 = zipArchiveEntry25.getExternalAttributes();
        zipArchiveEntry25.setSize((long) 28789);
        zipArchiveEntry25.setCrc(10L);
        zipArchiveEntry25.setPlatform(4095);
        byte[] byteArray33 = zipArchiveEntry25.getCentralDirectoryExtra();
        byte[] byteArray35 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray36 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray35);
        byte[] byteArray37 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray36);
        zipArchiveEntry25.setExtraFields(zipExtraFieldArray36);
        zipArchiveEntry14.setExtraFields(zipExtraFieldArray36);
        java.lang.String str40 = zipArchiveEntry14.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] {});
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5L + "'", long13 == 5L);
        org.junit.Assert.assertNotNull(inputStream15);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5L + "'", long24 == 5L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray36);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "" + "'", str40, "");
    }

    @Test
    public void test1123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1123");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream5);
        int int7 = zipArchiveInputStream6.getCount();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = zipArchiveInputStream6.getNextZipEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(zipArchiveEntry8);
    }

    @Test
    public void test1124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1124");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime1 = zipArchiveEntry0.getCreationTime();
        long long2 = zipArchiveEntry0.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry3 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long4 = zipArchiveEntry3.getExternalAttributes();
        java.io.InputStream inputStream5 = java.io.InputStream.nullInputStream();
        byte[] byteArray7 = inputStream5.readNBytes((int) (short) 100);
        zipArchiveEntry3.setCentralDirectoryExtra(byteArray7);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry3);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry10 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry9);
        java.util.Date date11 = zipArchiveEntry9.getLastModifiedDate();
        zipArchiveEntry9.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker14 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry9.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker14);
        java.io.InputStream inputStream16 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream17 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream16);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry18 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime19 = zipArchiveEntry18.getCreationTime();
        long long20 = zipArchiveEntry18.getSize();
        byte[] byteArray21 = zipArchiveEntry18.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField22 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int24 = asiExtraField22.getMode(100);
        boolean boolean25 = asiExtraField22.isDirectory();
        zipArchiveEntry18.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField22);
        asiExtraField22.setGroupId(10);
        byte[] byteArray29 = asiExtraField22.getCentralDirectoryData();
        int int30 = inputStream16.read(byteArray29);
        inputStream16.mark(227);
        byte[] byteArray34 = inputStream16.readNBytes((int) (short) 1);
        jarMarker14.parseFromCentralDirectoryData(byteArray34, 4095, (int) (short) 0);
        byte[] byteArray38 = jarMarker14.getCentralDirectoryData();
        byte[] byteArray39 = jarMarker14.getLocalFileDataData();
        zipArchiveEntry0.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker14);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort41 = jarMarker14.getLocalFileDataLength();
        org.junit.Assert.assertNull(fileTime1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(inputStream5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertEquals(date11.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNull(fileTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNull(byteArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 32868 + "'", int24 == 32868);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertArrayEquals(byteArray29, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertArrayEquals(byteArray34, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertArrayEquals(byteArray38, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertArrayEquals(byteArray39, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort41);
    }

    @Test
    public void test1125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1125");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        zipArchiveInputStream1.close();
        long long6 = zipArchiveInputStream1.skip(0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test1126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1126");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker1 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray7 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField8 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        int int9 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray7);
        jarMarker1.parseFromLocalFileData(byteArray7, 511, 0);
        boolean boolean14 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray7, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField15 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = unicodePathExtraField15.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long18 = zipArchiveEntry17.getExternalAttributes();
        zipArchiveEntry17.setSize((long) 28789);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry21 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry17);
        zipArchiveEntry17.setExtra();
        boolean boolean23 = zipShort16.equals((java.lang.Object) zipArchiveEntry17);
        long long24 = zipArchiveEntry17.getCompressedSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry25 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long26 = zipArchiveEntry25.getExternalAttributes();
        zipArchiveEntry25.setSize((long) 28789);
        byte[] byteArray29 = zipArchiveEntry25.getExtra();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry30 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry25);
        zipArchiveEntry30.setCrc(33639248L);
        zipArchiveEntry30.setExtra();
        boolean boolean34 = zipArchiveEntry17.equals((java.lang.Object) zipArchiveEntry30);
        byte[] byteArray35 = zipArchiveEntry17.getCentralDirectoryExtra();
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 65281 + "'", int9 == 65281);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] {});
    }

    @Test
    public void test1127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1127");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        byte[] byteArray5 = zipArchiveInputStream1.readNBytes(30062);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipShort zipShort6 = new org.apache.commons.compress.archivers.zip.ZipShort(byteArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 1 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] {});
    }

    @Test
    public void test1128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1128");
        org.apache.commons.compress.archivers.zip.ZipShort zipShort1 = new org.apache.commons.compress.archivers.zip.ZipShort((int) (short) 10);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        boolean boolean5 = inputStream2.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream2, "UTF8", true);
        boolean boolean9 = zipShort1.equals((java.lang.Object) true);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding10 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean12 = fallbackZipEncoding10.canEncode("hi!");
        boolean boolean14 = fallbackZipEncoding10.canEncode("hi!");
        boolean boolean16 = fallbackZipEncoding10.canEncode("hi!");
        byte[] byteArray18 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        java.lang.String str19 = fallbackZipEncoding10.decode(byteArray18);
        java.nio.ByteBuffer byteBuffer21 = fallbackZipEncoding10.encode("\000\ufffd");
        byte[] byteArray23 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) 'a');
        java.lang.String str24 = fallbackZipEncoding10.decode(byteArray23);
        boolean boolean25 = zipShort1.equals((java.lang.Object) fallbackZipEncoding10);
        boolean boolean27 = fallbackZipEncoding10.canEncode("\000!\000\000");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long29 = zipArchiveEntry28.getExternalAttributes();
        java.io.InputStream inputStream30 = java.io.InputStream.nullInputStream();
        byte[] byteArray32 = inputStream30.readNBytes((int) (short) 100);
        zipArchiveEntry28.setCentralDirectoryExtra(byteArray32);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry34 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry28);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry35 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry34);
        java.util.Date date36 = zipArchiveEntry34.getLastModifiedDate();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry37 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry34);
        java.util.Date date38 = zipArchiveEntry37.getLastModifiedDate();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField40 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int42 = asiExtraField40.getMode(100);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort43 = asiExtraField40.getCentralDirectoryLength();
        byte[] byteArray44 = asiExtraField40.getLocalFileDataData();
        int int45 = asiExtraField40.getGroupId();
        asiExtraField40.setMode((int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort48 = asiExtraField40.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort49 = asiExtraField40.getHeaderId();
        byte[] byteArray50 = asiExtraField40.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField51 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("\ufffd\ufffd", byteArray50);
        long long52 = unicodeCommentExtraField51.getNameCRC32();
        zipArchiveEntry37.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField51);
        byte[] byteArray55 = org.apache.commons.compress.archivers.zip.ZipUtil.toDosTime((long) '4');
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray56 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray55);
        unicodeCommentExtraField51.setUnicodeName(byteArray55);
        byte[] byteArray59 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) ' ');
        unicodeCommentExtraField51.setUnicodeName(byteArray59);
        java.lang.String str61 = fallbackZipEncoding10.decode(byteArray59);
        java.nio.ByteBuffer byteBuffer63 = fallbackZipEncoding10.encode("\003\000\000\000");
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "\000\ufffd\000\000" + "'", str19, "\000\ufffd\000\000");
        org.junit.Assert.assertNotNull(byteBuffer21);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] { (byte) 97, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "a\000" + "'", str24, "a\000");
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(inputStream30);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertEquals(date36.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertEquals(date38.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 32868 + "'", int42 == 32868);
        org.junit.Assert.assertNotNull(zipShort43);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertArrayEquals(byteArray44, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(zipShort48);
        org.junit.Assert.assertNotNull(zipShort49);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertArrayEquals(byteArray50, new byte[] { (byte) 57, (byte) 104, (byte) -33, (byte) -123, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 3456169999L + "'", long52 == 3456169999L);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertArrayEquals(byteArray55, new byte[] { (byte) 0, (byte) 33, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray56);
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertArrayEquals(byteArray59, new byte[] { (byte) 32, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + " \000\000\000" + "'", str61, " \000\000\000");
        org.junit.Assert.assertNotNull(byteBuffer63);
    }

    @Test
    public void test1129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1129");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        long long9 = zipArchiveInputStream1.skip((long) 28789);
        zipArchiveInputStream1.close();
        int int11 = zipArchiveInputStream1.available();
        int int12 = zipArchiveInputStream1.getCount();
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test1130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1130");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        zipArchiveInputStream1.mark(5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = zipArchiveInputStream1.getNextZipEntry();
        byte[] byteArray10 = zipArchiveInputStream1.readNBytes(41797);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(zipArchiveEntry8);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
    }

    @Test
    public void test1131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1131");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray3 = zipArchiveInputStream1.readNBytes(8);
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry5 = zipArchiveInputStream1.getNextEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertArrayEquals(byteArray3, new byte[] {});
        org.junit.Assert.assertNull(archiveEntry5);
    }

    @Test
    public void test1132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1132");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray3 = zipArchiveInputStream1.readNBytes(8);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        int int5 = zipArchiveInputStream1.read();
        java.io.InputStream inputStream7 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream7);
        byte[] byteArray9 = new byte[] {};
        int int12 = zipArchiveInputStream8.read(byteArray9, 420, 1);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField13 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("UTF8", byteArray9);
        int int16 = zipArchiveInputStream1.read(byteArray9, 26681, (int) (short) -1);
        int int17 = zipArchiveInputStream1.available();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertArrayEquals(byteArray3, new byte[] {});
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test1133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1133");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        byte[] byteArray7 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray8 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray7);
        int int9 = zipArchiveInputStream1.read(byteArray7);
        byte[] byteArray10 = null;
        int int13 = zipArchiveInputStream1.read(byteArray10, (int) (short) 100, (int) (byte) 0);
        byte[] byteArray15 = zipArchiveInputStream1.readNBytes(100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] {});
    }

    @Test
    public void test1134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1134");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        byte[] byteArray8 = zipArchiveEntry0.getCentralDirectoryExtra();
        byte[] byteArray9 = zipArchiveEntry0.getLocalFileDataExtra();
        java.lang.String str10 = zipArchiveEntry0.getName();
        byte[] byteArray13 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean15 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray13, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField16 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray13);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort17 = unicodeCommentExtraField16.getHeaderId();
        zipArchiveEntry0.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField16);
        byte[] byteArray19 = unicodeCommentExtraField16.getUnicodeName();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong20 = org.apache.commons.compress.archivers.zip.ZipLong.CFH_SIG;
        java.lang.Object obj21 = zipLong20.clone();
        byte[] byteArray22 = zipLong20.getBytes();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong23 = org.apache.commons.compress.archivers.zip.ZipLong.CFH_SIG;
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker24 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort25 = jarMarker24.getLocalFileDataLength();
        boolean boolean26 = zipLong23.equals((java.lang.Object) jarMarker24);
        byte[] byteArray27 = jarMarker24.getCentralDirectoryData();
        boolean boolean28 = zipLong20.equals((java.lang.Object) jarMarker24);
        java.lang.Object obj29 = zipLong20.clone();
        byte[] byteArray30 = zipLong20.getBytes();
        unicodeCommentExtraField16.setUnicodeName(byteArray30);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort32 = unicodeCommentExtraField16.getHeaderId();
        long long33 = unicodeCommentExtraField16.getNameCRC32();
        byte[] byteArray34 = unicodeCommentExtraField16.getUnicodeName();
        byte[] byteArray35 = unicodeCommentExtraField16.getLocalFileDataData();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(zipShort17);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] {});
        org.junit.Assert.assertNotNull(zipLong20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 80, (byte) 75, (byte) 1, (byte) 2 });
        org.junit.Assert.assertNotNull(zipLong23);
        org.junit.Assert.assertNotNull(zipShort25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertArrayEquals(byteArray30, new byte[] { (byte) 80, (byte) 75, (byte) 1, (byte) 2 });
        org.junit.Assert.assertNotNull(zipShort32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1104745215L + "'", long33 == 1104745215L);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertArrayEquals(byteArray34, new byte[] { (byte) 80, (byte) 75, (byte) 1, (byte) 2 });
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65, (byte) 80, (byte) 75, (byte) 1, (byte) 2 });
    }

    @Test
    public void test1135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1135");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.close();
        zipArchiveInputStream1.mark(28789);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry5 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry7 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry5);
        org.junit.Assert.assertNull(archiveEntry7);
    }

    @Test
    public void test1136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1136");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        long long8 = zipArchiveInputStream6.skip((long) 65281);
        byte[] byteArray10 = zipArchiveInputStream6.readNBytes(32868);
        zipArchiveInputStream6.mark(21589);
        int int13 = zipArchiveInputStream6.getCount();
        zipArchiveInputStream6.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test1137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1137");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip(3817498742L);
        java.io.InputStream inputStream4 = java.io.InputStream.nullInputStream();
        byte[] byteArray6 = inputStream4.readNBytes((int) (short) 100);
        byte[] byteArray7 = inputStream4.readAllBytes();
        int int10 = zipArchiveInputStream1.read(byteArray7, 0, 32768);
        byte[] byteArray11 = zipArchiveInputStream1.readAllBytes();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream12 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry13 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long14 = zipArchiveEntry13.getExternalAttributes();
        java.io.InputStream inputStream15 = java.io.InputStream.nullInputStream();
        byte[] byteArray17 = inputStream15.readNBytes((int) (short) 100);
        zipArchiveEntry13.setCentralDirectoryExtra(byteArray17);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry19 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry19);
        java.util.Date date21 = zipArchiveEntry19.getLastModifiedDate();
        zipArchiveEntry19.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker24 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry19.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker24);
        zipArchiveEntry19.setUnixMode(0);
        byte[] byteArray30 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean32 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray30, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField33 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray30);
        byte[] byteArray34 = unicodeCommentExtraField33.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = unicodeCommentExtraField33.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort36 = unicodeCommentExtraField33.getCentralDirectoryLength();
        zipArchiveEntry19.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField33);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding38 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean40 = fallbackZipEncoding38.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry41 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime42 = zipArchiveEntry41.getCreationTime();
        long long43 = zipArchiveEntry41.getSize();
        byte[] byteArray44 = zipArchiveEntry41.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField45 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int47 = asiExtraField45.getMode(100);
        boolean boolean48 = asiExtraField45.isDirectory();
        zipArchiveEntry41.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField45);
        byte[] byteArray50 = asiExtraField45.getCentralDirectoryData();
        int int52 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray50, 3);
        int int53 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray50);
        java.lang.String str54 = fallbackZipEncoding38.decode(byteArray50);
        java.io.InputStream inputStream55 = java.io.InputStream.nullInputStream();
        byte[] byteArray57 = inputStream55.readNBytes((int) (short) 100);
        java.lang.String str58 = fallbackZipEncoding38.decode(byteArray57);
        java.io.InputStream inputStream59 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream60 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream59);
        java.io.InputStream inputStream61 = java.io.InputStream.nullInputStream();
        byte[] byteArray63 = inputStream61.readNBytes((int) (short) 100);
        int int66 = zipArchiveInputStream60.read(byteArray63, (int) ' ', 40960);
        java.lang.String str67 = fallbackZipEncoding38.decode(byteArray63);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray69 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray63, true);
        unicodeCommentExtraField33.setUnicodeName(byteArray63);
        int int73 = zipArchiveInputStream12.read(byteArray63, (int) (byte) 100, (-1));
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField74 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int75 = asiExtraField74.getGroupId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort76 = asiExtraField74.getCentralDirectoryLength();
        int int77 = asiExtraField74.getUserId();
        asiExtraField74.setMode(0);
        byte[] byteArray80 = asiExtraField74.getCentralDirectoryData();
        byte[] byteArray81 = asiExtraField74.getLocalFileDataData();
        int int82 = asiExtraField74.getUserId();
        byte[] byteArray83 = asiExtraField74.getLocalFileDataData();
        byte[] byteArray84 = asiExtraField74.getCentralDirectoryData();
        // The following exception was thrown during execution in test generation
        try {
            int int87 = zipArchiveInputStream12.readNBytes(byteArray84, 55041, 32865);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Range [55041, 55041 + 32865) out of bounds for length 14");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(inputStream4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(inputStream15);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertEquals(date21.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertArrayEquals(byteArray30, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertArrayEquals(byteArray34, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(zipShort36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(fileTime42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1L) + "'", long43 == (-1L));
        org.junit.Assert.assertNull(byteArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 32868 + "'", int47 == 32868);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertArrayEquals(byteArray50, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 227 + "'", int52 == 227);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 26742 + "'", int53 == 26742);
// flaky "7) test1137(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str54 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str54, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertNotNull(inputStream55);
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertArrayEquals(byteArray57, new byte[] {});
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "" + "'", str58, "");
        org.junit.Assert.assertNotNull(inputStream61);
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] {});
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertEquals("'" + str67 + "' != '" + "" + "'", str67, "");
        org.junit.Assert.assertNotNull(zipExtraFieldArray69);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray69, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(zipShort76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(byteArray80);
        org.junit.Assert.assertArrayEquals(byteArray80, new byte[] { (byte) 57, (byte) 104, (byte) -33, (byte) -123, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertArrayEquals(byteArray81, new byte[] { (byte) 57, (byte) 104, (byte) -33, (byte) -123, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(byteArray83);
        org.junit.Assert.assertArrayEquals(byteArray83, new byte[] { (byte) 57, (byte) 104, (byte) -33, (byte) -123, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray84);
        org.junit.Assert.assertArrayEquals(byteArray84, new byte[] { (byte) 57, (byte) 104, (byte) -33, (byte) -123, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
    }

    @Test
    public void test1138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1138");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime16 = zipArchiveEntry15.getCreationTime();
        long long17 = zipArchiveEntry15.getSize();
        byte[] byteArray18 = zipArchiveEntry15.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField19 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int21 = asiExtraField19.getMode(100);
        boolean boolean22 = asiExtraField19.isDirectory();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField19);
        asiExtraField19.setGroupId(10);
        byte[] byteArray26 = asiExtraField19.getCentralDirectoryData();
        int int27 = inputStream13.read(byteArray26);
        inputStream13.mark(227);
        byte[] byteArray31 = inputStream13.readNBytes((int) (short) 1);
        jarMarker11.parseFromCentralDirectoryData(byteArray31, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = jarMarker11.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort36 = jarMarker11.getHeaderId();
        byte[] byteArray37 = jarMarker11.getCentralDirectoryData();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(fileTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32868 + "'", int21 == 32868);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(zipShort36);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] {});
    }

    @Test
    public void test1139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1139");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort8 = unicodeCommentExtraField5.getCentralDirectoryLength();
        long long9 = unicodeCommentExtraField5.getNameCRC32();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort10 = unicodeCommentExtraField5.getCentralDirectoryLength();
        long long11 = unicodeCommentExtraField5.getNameCRC32();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long13 = zipArchiveEntry12.getExternalAttributes();
        zipArchiveEntry12.setSize((long) 28789);
        zipArchiveEntry12.setCrc(10L);
        zipArchiveEntry12.setPlatform(4095);
        java.lang.String str20 = zipArchiveEntry12.getName();
        byte[] byteArray22 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        zipArchiveEntry12.setCentralDirectoryExtra(byteArray22);
        long long24 = zipArchiveEntry12.getSize();
        byte[] byteArray25 = zipArchiveEntry12.getCentralDirectoryExtra();
        int int26 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray25);
        unicodeCommentExtraField5.setUnicodeName(byteArray25);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(zipShort8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1104745215L + "'", long9 == 1104745215L);
        org.junit.Assert.assertNotNull(zipShort10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1104745215L + "'", long11 == 1104745215L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28789L + "'", long24 == 28789L);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 40960 + "'", int26 == 40960);
    }

    @Test
    public void test1140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1140");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long7 = zipArchiveEntry6.getExternalAttributes();
        zipArchiveEntry6.setSize((long) 28789);
        zipArchiveEntry6.setCrc(10L);
        zipArchiveEntry6.setPlatform(4095);
        boolean boolean14 = zipArchiveEntry6.isDirectory();
        zipArchiveEntry6.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        byte[] byteArray18 = zipArchiveEntry6.getLocalFileDataExtra();
        int int21 = zipArchiveInputStream1.read(byteArray18, (int) '#', (int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream22 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        int int23 = zipArchiveInputStream1.read();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry25 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNull(archiveEntry25);
    }

    @Test
    public void test1141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1141");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getLocalFileDataLength();
        byte[] byteArray8 = unicodeCommentExtraField5.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort9 = unicodeCommentExtraField5.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding10 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean12 = fallbackZipEncoding10.canEncode("hi!");
        boolean boolean14 = fallbackZipEncoding10.canEncode("hi!");
        java.nio.ByteBuffer byteBuffer16 = fallbackZipEncoding10.encode("UTF8");
        byte[] byteArray18 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray19 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray18);
        byte[] byteArray20 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray19);
        java.lang.String str21 = fallbackZipEncoding10.decode(byteArray20);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry22 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long23 = zipArchiveEntry22.getExternalAttributes();
        zipArchiveEntry22.setSize((long) 28789);
        zipArchiveEntry22.setCrc(10L);
        zipArchiveEntry22.setPlatform(4095);
        java.lang.String str30 = zipArchiveEntry22.getName();
        java.nio.file.attribute.FileTime fileTime31 = zipArchiveEntry22.getCreationTime();
        byte[] byteArray32 = zipArchiveEntry22.getExtra();
        byte[] byteArray34 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((-1));
        zipArchiveEntry22.setExtra(byteArray34);
        java.lang.String str36 = fallbackZipEncoding10.decode(byteArray34);
        unicodeCommentExtraField5.setUnicodeName(byteArray34);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort38 = unicodeCommentExtraField5.getHeaderId();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(byteBuffer16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray19);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray19, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] {});
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertNull(fileTime31);
        org.junit.Assert.assertNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertArrayEquals(byteArray34, new byte[] { (byte) -1, (byte) -1 });
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "\ufffd\ufffd" + "'", str36, "\ufffd\ufffd");
        org.junit.Assert.assertNotNull(zipShort38);
    }

    @Test
    public void test1142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1142");
        byte[] byteArray7 = new byte[] { (byte) 10, (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField8 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("hi!", byteArray7);
        long long9 = unicodeCommentExtraField8.getNameCRC32();
        byte[] byteArray10 = unicodeCommentExtraField8.getCentralDirectoryData();
        byte[] byteArray11 = unicodeCommentExtraField8.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort12 = unicodeCommentExtraField8.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker15 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray21 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField22 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray21);
        int int23 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray21);
        jarMarker15.parseFromLocalFileData(byteArray21, 511, 0);
        boolean boolean28 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray21, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField29 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray21);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort30 = unicodePathExtraField29.getCentralDirectoryLength();
        byte[] byteArray31 = unicodePathExtraField29.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort32 = unicodePathExtraField29.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry33 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long34 = zipArchiveEntry33.getExternalAttributes();
        zipArchiveEntry33.setSize((long) 28789);
        zipArchiveEntry33.setCrc(10L);
        zipArchiveEntry33.setPlatform(4095);
        java.lang.String str41 = zipArchiveEntry33.getName();
        byte[] byteArray43 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        zipArchiveEntry33.setCentralDirectoryExtra(byteArray43);
        unicodePathExtraField29.setUnicodeName(byteArray43);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField46 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("\001\ufffd\ufffd\ufffd\ufffd", byteArray43);
        byte[] byteArray47 = unicodeCommentExtraField46.getLocalFileDataData();
        boolean boolean48 = zipShort12.equals((java.lang.Object) unicodeCommentExtraField46);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 10, (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 });
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 646776791L + "'", long9 == 646776791L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 1, (byte) -41, (byte) 7, (byte) -115, (byte) 38, (byte) 104, (byte) 105, (byte) 33 });
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] { (byte) 1, (byte) -41, (byte) 7, (byte) -115, (byte) 38, (byte) 104, (byte) 105, (byte) 33 });
        org.junit.Assert.assertNotNull(zipShort12);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 65281 + "'", int23 == 65281);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(zipShort30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(zipShort32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "" + "'", str41, "");
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertArrayEquals(byteArray47, new byte[] { (byte) 1, (byte) 124, (byte) -126, (byte) 60, (byte) -8, (byte) 1, (byte) -17, (byte) -65, (byte) -67, (byte) -17, (byte) -65, (byte) -67, (byte) -17, (byte) -65, (byte) -67, (byte) -17, (byte) -65, (byte) -67 });
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test1143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1143");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getLocalFileDataLength();
        byte[] byteArray8 = unicodeCommentExtraField5.getUnicodeName();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort9 = unicodeCommentExtraField5.getLocalFileDataLength();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort9);
    }

    @Test
    public void test1144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1144");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        int int7 = zipArchiveInputStream6.read();
        byte[] byteArray8 = zipArchiveInputStream6.readAllBytes();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(archiveEntry4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
    }

    @Test
    public void test1145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1145");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField6 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray5);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodePathExtraField6.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort8 = unicodePathExtraField6.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort9 = unicodePathExtraField6.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort10 = unicodePathExtraField6.getHeaderId();
        long long11 = unicodePathExtraField6.getNameCRC32();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long13 = zipArchiveEntry12.getExternalAttributes();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        byte[] byteArray16 = inputStream14.readNBytes((int) (short) 100);
        zipArchiveEntry12.setCentralDirectoryExtra(byteArray16);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry18 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry12);
        java.lang.String str19 = zipArchiveEntry18.getComment();
        java.nio.file.attribute.FileTime fileTime20 = zipArchiveEntry18.getLastModifiedTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry21 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long22 = zipArchiveEntry21.getExternalAttributes();
        java.lang.Object obj23 = zipArchiveEntry21.clone();
        java.nio.file.attribute.FileTime fileTime24 = zipArchiveEntry21.getLastAccessTime();
        byte[] byteArray25 = zipArchiveEntry21.getCentralDirectoryExtra();
        java.io.InputStream inputStream26 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream27 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream26);
        byte[] byteArray28 = new byte[] {};
        int int31 = zipArchiveInputStream27.read(byteArray28, 420, 1);
        java.io.InputStream inputStream32 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream33 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream32);
        java.io.InputStream inputStream34 = java.io.InputStream.nullInputStream();
        byte[] byteArray36 = inputStream34.readNBytes((int) (short) 100);
        int int39 = zipArchiveInputStream33.read(byteArray36, (int) ' ', 40960);
        byte[] byteArray40 = zipArchiveInputStream33.readAllBytes();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry21, byteArray28, byteArray40);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry42 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime43 = zipArchiveEntry42.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry44 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry42);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField45 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        zipArchiveEntry42.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField45);
        zipArchiveEntry42.setSize(0L);
        byte[] byteArray49 = zipArchiveEntry42.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry18, byteArray40, byteArray49);
        int int51 = zipArchiveEntry18.getUnixMode();
        byte[] byteArray52 = zipArchiveEntry18.getLocalFileDataExtra();
        // The following exception was thrown during execution in test generation
        try {
            unicodePathExtraField6.parseFromLocalFileData(byteArray52, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: UniCode path extra data must have at least 5 bytes.");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(zipShort8);
        org.junit.Assert.assertNotNull(zipShort9);
        org.junit.Assert.assertNotNull(zipShort10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4035808147L + "'", long11 == 4035808147L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] {});
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(fileTime20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertEquals(obj23.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj23), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj23), "");
        org.junit.Assert.assertNull(fileTime24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertNotNull(inputStream26);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] {});
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(inputStream34);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertArrayEquals(byteArray40, new byte[] {});
        org.junit.Assert.assertNull(fileTime43);
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertArrayEquals(byteArray49, new byte[] { (byte) 110, (byte) 117, (byte) 14, (byte) 0, (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertArrayEquals(byteArray52, new byte[] {});
    }

    @Test
    public void test1146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1146");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding0 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean2 = fallbackZipEncoding0.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry3 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime4 = zipArchiveEntry3.getCreationTime();
        long long5 = zipArchiveEntry3.getSize();
        byte[] byteArray6 = zipArchiveEntry3.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField7 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int9 = asiExtraField7.getMode(100);
        boolean boolean10 = asiExtraField7.isDirectory();
        zipArchiveEntry3.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField7);
        byte[] byteArray12 = asiExtraField7.getCentralDirectoryData();
        int int14 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray12, 3);
        int int15 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray12);
        java.lang.String str16 = fallbackZipEncoding0.decode(byteArray12);
        boolean boolean18 = fallbackZipEncoding0.canEncode("UTF8");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry19 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime20 = zipArchiveEntry19.getCreationTime();
        long long21 = zipArchiveEntry19.getSize();
        byte[] byteArray22 = zipArchiveEntry19.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField23 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int25 = asiExtraField23.getMode(100);
        boolean boolean26 = asiExtraField23.isDirectory();
        zipArchiveEntry19.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField23);
        byte[] byteArray28 = asiExtraField23.getCentralDirectoryData();
        java.lang.String str29 = fallbackZipEncoding0.decode(byteArray28);
        byte[] byteArray35 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField36 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray35);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort37 = unicodePathExtraField36.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort38 = unicodePathExtraField36.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort39 = unicodePathExtraField36.getHeaderId();
        byte[] byteArray40 = unicodePathExtraField36.getUnicodeName();
        java.lang.String str41 = fallbackZipEncoding0.decode(byteArray40);
        boolean boolean43 = fallbackZipEncoding0.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry44 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long45 = zipArchiveEntry44.getExternalAttributes();
        java.io.InputStream inputStream46 = java.io.InputStream.nullInputStream();
        byte[] byteArray48 = inputStream46.readNBytes((int) (short) 100);
        zipArchiveEntry44.setCentralDirectoryExtra(byteArray48);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry50 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry44);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry51 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry50);
        java.util.Date date52 = zipArchiveEntry50.getLastModifiedDate();
        zipArchiveEntry50.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker55 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry50.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker55);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort57 = jarMarker55.getCentralDirectoryLength();
        java.io.InputStream inputStream58 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream59 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream58);
        byte[] byteArray61 = zipArchiveInputStream59.readNBytes(8);
        jarMarker55.parseFromCentralDirectoryData(byteArray61, 10, 0);
        byte[] byteArray65 = jarMarker55.getLocalFileDataData();
        java.lang.String str66 = fallbackZipEncoding0.decode(byteArray65);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(fileTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32868 + "'", int9 == 32868);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 227 + "'", int14 == 227);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 26742 + "'", int15 == 26742);
// flaky "8) test1146(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str16, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(fileTime20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNull(byteArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 32868 + "'", int25 == 32868);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
// flaky "1) test1146(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str29 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str29, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertNotNull(zipShort37);
        org.junit.Assert.assertNotNull(zipShort38);
        org.junit.Assert.assertNotNull(zipShort39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertArrayEquals(byteArray40, new byte[] {});
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "" + "'", str41, "");
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(inputStream46);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertArrayEquals(byteArray48, new byte[] {});
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertEquals(date52.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(zipShort57);
        org.junit.Assert.assertNotNull(inputStream58);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray65);
        org.junit.Assert.assertArrayEquals(byteArray65, new byte[] {});
        org.junit.Assert.assertEquals("'" + str66 + "' != '" + "" + "'", str66, "");
    }

    @Test
    public void test1147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1147");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime1 = zipArchiveEntry0.getCreationTime();
        long long2 = zipArchiveEntry0.getSize();
        byte[] byteArray3 = zipArchiveEntry0.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField4 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int6 = asiExtraField4.getMode(100);
        boolean boolean7 = asiExtraField4.isDirectory();
        zipArchiveEntry0.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField4);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort9 = asiExtraField4.getCentralDirectoryLength();
        asiExtraField4.setGroupId(511);
        byte[] byteArray12 = asiExtraField4.getLocalFileDataData();
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream13);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry15 = zipArchiveInputStream14.getNextEntry();
        int int16 = zipArchiveInputStream14.getCount();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream17 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream14);
        int int18 = zipArchiveInputStream17.getCount();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry19 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long20 = zipArchiveEntry19.getExternalAttributes();
        java.io.InputStream inputStream21 = java.io.InputStream.nullInputStream();
        byte[] byteArray23 = inputStream21.readNBytes((int) (short) 100);
        zipArchiveEntry19.setCentralDirectoryExtra(byteArray23);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry25 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry19);
        java.lang.String str26 = zipArchiveEntry25.getComment();
        java.nio.file.attribute.FileTime fileTime27 = zipArchiveEntry25.getLastModifiedTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long29 = zipArchiveEntry28.getExternalAttributes();
        java.lang.Object obj30 = zipArchiveEntry28.clone();
        java.nio.file.attribute.FileTime fileTime31 = zipArchiveEntry28.getLastAccessTime();
        byte[] byteArray32 = zipArchiveEntry28.getCentralDirectoryExtra();
        java.io.InputStream inputStream33 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream34 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream33);
        byte[] byteArray35 = new byte[] {};
        int int38 = zipArchiveInputStream34.read(byteArray35, 420, 1);
        java.io.InputStream inputStream39 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream40 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream39);
        java.io.InputStream inputStream41 = java.io.InputStream.nullInputStream();
        byte[] byteArray43 = inputStream41.readNBytes((int) (short) 100);
        int int46 = zipArchiveInputStream40.read(byteArray43, (int) ' ', 40960);
        byte[] byteArray47 = zipArchiveInputStream40.readAllBytes();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry28, byteArray35, byteArray47);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry49 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime50 = zipArchiveEntry49.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry51 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry49);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField52 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        zipArchiveEntry49.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField52);
        zipArchiveEntry49.setSize(0L);
        byte[] byteArray56 = zipArchiveEntry49.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry25, byteArray47, byteArray56);
        int int60 = zipArchiveInputStream17.read(byteArray56, 28789, 26742);
        byte[] byteArray61 = zipArchiveInputStream17.readAllBytes();
        // The following exception was thrown during execution in test generation
        try {
            asiExtraField4.parseFromCentralDirectoryData(byteArray61, 41797, 8448);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 41800 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNull(fileTime1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNull(byteArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32868 + "'", int6 == 32868);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(zipShort9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) -110, (byte) -91, (byte) -87, (byte) 7, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) -1, (byte) 1 });
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(archiveEntry15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(inputStream21);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] {});
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(fileTime27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertEquals(obj30.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj30), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj30), "");
        org.junit.Assert.assertNull(fileTime31);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertNotNull(inputStream33);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] {});
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(inputStream41);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] {});
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertArrayEquals(byteArray47, new byte[] {});
        org.junit.Assert.assertNull(fileTime50);
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertArrayEquals(byteArray56, new byte[] { (byte) 110, (byte) 117, (byte) 14, (byte) 0, (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] {});
    }

    @Test
    public void test1148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1148");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        long long9 = zipArchiveInputStream1.skip((long) 28789);
        boolean boolean10 = zipArchiveInputStream1.markSupported();
        byte[] byteArray11 = zipArchiveInputStream1.readAllBytes();
        int int12 = zipArchiveInputStream1.getCount();
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test1149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1149");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding0 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean2 = fallbackZipEncoding0.canEncode("hi!");
        boolean boolean4 = fallbackZipEncoding0.canEncode("hi!");
        boolean boolean6 = fallbackZipEncoding0.canEncode("UTF8");
        boolean boolean8 = fallbackZipEncoding0.canEncode("\000\ufffd");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long10 = zipArchiveEntry9.getExternalAttributes();
        zipArchiveEntry9.setSize((long) 28789);
        zipArchiveEntry9.setCrc(10L);
        zipArchiveEntry9.setPlatform(4095);
        byte[] byteArray17 = zipArchiveEntry9.getCentralDirectoryExtra();
        boolean boolean19 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray17, (int) (byte) 0);
        java.lang.String str20 = fallbackZipEncoding0.decode(byteArray17);
        boolean boolean22 = fallbackZipEncoding0.canEncode("nu\016\000\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000up\005\000\001\ufffd\001\000\000nu\016\000\ufffd\ufffd\017\000\000\000\000\000\000\000\000\ufffduc\b\000\001\ufffd\007\ufffd&hi!nu\016\000qk\030=\000@\000\000\000\000\000\000\000\000up\005\000\001\ufffd\ufffd\ufffd\ufffd");
        boolean boolean24 = fallbackZipEncoding0.canEncode("nu");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test1150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1150");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField6 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int7 = asiExtraField6.getGroupId();
        asiExtraField6.setDirectory(true);
        byte[] byteArray10 = asiExtraField6.getCentralDirectoryData();
        java.io.InputStream inputStream11 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream12 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream11);
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        byte[] byteArray15 = inputStream13.readNBytes((int) (short) 100);
        int int18 = zipArchiveInputStream12.read(byteArray15, (int) ' ', 40960);
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry0, byteArray10, byteArray15);
        zipArchiveEntry0.setInternalAttributes(16384);
        long long22 = zipArchiveEntry0.getExternalAttributes();
        long long23 = zipArchiveEntry0.getCrc();
        long long24 = zipArchiveEntry0.getCrc();
        java.util.Date date25 = zipArchiveEntry0.getLastModifiedDate();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] {});
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertEquals(date25.toString(), "Wed Dec 31 15:59:59 PST 1969");
    }

    @Test
    public void test1151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1151");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        zipArchiveInputStream1.mark(5);
        long long9 = zipArchiveInputStream1.skip((long) 33279);
        int int10 = zipArchiveInputStream1.getCount();
        long long12 = zipArchiveInputStream1.skip(312912242339L);
        int int13 = zipArchiveInputStream1.read();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry14 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime15 = zipArchiveEntry14.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry16 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry14);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField17 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        zipArchiveEntry14.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField17);
        zipArchiveEntry14.setSize(0L);
        byte[] byteArray21 = zipArchiveEntry14.getCentralDirectoryExtra();
        boolean boolean23 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray21, 33188);
        int int24 = zipArchiveInputStream1.read(byteArray21);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(fileTime15);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 110, (byte) 117, (byte) 14, (byte) 0, (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test1152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1152");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        java.lang.String str8 = zipArchiveEntry0.getName();
        java.nio.file.attribute.FileTime fileTime9 = zipArchiveEntry0.getCreationTime();
        byte[] byteArray12 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean14 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray12, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField15 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray12);
        byte[] byteArray16 = unicodeCommentExtraField15.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort17 = unicodeCommentExtraField15.getHeaderId();
        java.lang.Object obj18 = zipShort17.clone();
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField19 = zipArchiveEntry0.getExtraField(zipShort17);
        java.io.InputStream inputStream20 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream21 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream20);
        java.io.InputStream inputStream22 = java.io.InputStream.nullInputStream();
        byte[] byteArray24 = inputStream22.readNBytes((int) (short) 100);
        int int27 = zipArchiveInputStream21.read(byteArray24, (int) ' ', 40960);
        byte[] byteArray28 = zipArchiveInputStream21.readAllBytes();
        byte[] byteArray30 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int33 = zipArchiveInputStream21.read(byteArray30, (-1), 100);
        zipArchiveInputStream21.mark(16419);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding36 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean38 = fallbackZipEncoding36.canEncode("hi!");
        boolean boolean40 = fallbackZipEncoding36.canEncode("hi!");
        boolean boolean42 = fallbackZipEncoding36.canEncode("UTF8");
        boolean boolean44 = fallbackZipEncoding36.canEncode("\000\ufffd");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry45 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long46 = zipArchiveEntry45.getExternalAttributes();
        zipArchiveEntry45.setSize((long) 28789);
        zipArchiveEntry45.setCrc(10L);
        zipArchiveEntry45.setPlatform(4095);
        byte[] byteArray53 = zipArchiveEntry45.getCentralDirectoryExtra();
        boolean boolean55 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray53, (int) (byte) 0);
        java.lang.String str56 = fallbackZipEncoding36.decode(byteArray53);
        boolean boolean58 = fallbackZipEncoding36.canEncode("");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding59 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        byte[] byteArray61 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) 'a');
        java.lang.String str62 = fallbackZipEncoding59.decode(byteArray61);
        java.lang.String str63 = fallbackZipEncoding36.decode(byteArray61);
        int int66 = zipArchiveInputStream21.readNBytes(byteArray61, 0, 0);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray61);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(fileTime9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(zipExtraField19);
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] {});
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertArrayEquals(byteArray30, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertArrayEquals(byteArray53, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertEquals("'" + str56 + "' != '" + "" + "'", str56, "");
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 97, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str62 + "' != '" + "a\000" + "'", str62, "a\000");
        org.junit.Assert.assertEquals("'" + str63 + "' != '" + "a\000" + "'", str63, "a\000");
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test1153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1153");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        long long8 = zipArchiveInputStream6.skip((long) 65281);
        byte[] byteArray10 = zipArchiveInputStream6.readNBytes(32868);
        zipArchiveInputStream6.mark(21589);
        int int13 = zipArchiveInputStream6.read();
        long long15 = zipArchiveInputStream6.skip(21589L);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test1154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1154");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        boolean boolean8 = zipArchiveInputStream1.markSupported();
        long long10 = zipArchiveInputStream1.skip(0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test1155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1155");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        int int6 = zipArchiveEntry0.getMethod();
        zipArchiveEntry0.setExtra();
        zipArchiveEntry0.setCompressedSize((long) (byte) 1);
        byte[] byteArray10 = zipArchiveEntry0.getCentralDirectoryExtra();
        long long11 = zipArchiveEntry0.getExternalAttributes();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long13 = zipArchiveEntry12.getExternalAttributes();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        byte[] byteArray16 = inputStream14.readNBytes((int) (short) 100);
        zipArchiveEntry12.setCentralDirectoryExtra(byteArray16);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry18 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry12);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry19 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry18);
        java.util.Date date20 = zipArchiveEntry18.getLastModifiedDate();
        zipArchiveEntry18.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker23 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry18.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker23);
        java.io.InputStream inputStream25 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream26 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream25);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry27 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime28 = zipArchiveEntry27.getCreationTime();
        long long29 = zipArchiveEntry27.getSize();
        byte[] byteArray30 = zipArchiveEntry27.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField31 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int33 = asiExtraField31.getMode(100);
        boolean boolean34 = asiExtraField31.isDirectory();
        zipArchiveEntry27.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField31);
        asiExtraField31.setGroupId(10);
        byte[] byteArray38 = asiExtraField31.getCentralDirectoryData();
        int int39 = inputStream25.read(byteArray38);
        inputStream25.mark(227);
        byte[] byteArray43 = inputStream25.readNBytes((int) (short) 1);
        jarMarker23.parseFromCentralDirectoryData(byteArray43, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort47 = jarMarker23.getLocalFileDataLength();
        byte[] byteArray48 = jarMarker23.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort49 = jarMarker23.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField50 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort49);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField51 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort49);
        byte[] byteArray52 = zipShort49.getBytes();
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveEntry0.removeExtraField(zipShort49);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] {});
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertEquals(date20.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream25);
        org.junit.Assert.assertNull(fileTime28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertNull(byteArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 32868 + "'", int33 == 32868);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertArrayEquals(byteArray38, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort47);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertArrayEquals(byteArray48, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort49);
        org.junit.Assert.assertNotNull(zipExtraField50);
        org.junit.Assert.assertNotNull(zipExtraField51);
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertArrayEquals(byteArray52, new byte[] { (byte) -2, (byte) -54 });
    }

    @Test
    public void test1156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1156");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry1 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long2 = zipArchiveEntry1.getExternalAttributes();
        java.io.InputStream inputStream3 = java.io.InputStream.nullInputStream();
        byte[] byteArray5 = inputStream3.readNBytes((int) (short) 100);
        zipArchiveEntry1.setCentralDirectoryExtra(byteArray5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry7);
        java.util.Date date9 = zipArchiveEntry7.getLastModifiedDate();
        zipArchiveEntry7.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker12 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry7.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker12);
        zipArchiveEntry7.setUnixMode(0);
        byte[] byteArray18 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean20 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray18, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField21 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray18);
        byte[] byteArray22 = unicodeCommentExtraField21.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort23 = unicodeCommentExtraField21.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort24 = unicodeCommentExtraField21.getCentralDirectoryLength();
        zipArchiveEntry7.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField21);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding26 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean28 = fallbackZipEncoding26.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry29 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime30 = zipArchiveEntry29.getCreationTime();
        long long31 = zipArchiveEntry29.getSize();
        byte[] byteArray32 = zipArchiveEntry29.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField33 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int35 = asiExtraField33.getMode(100);
        boolean boolean36 = asiExtraField33.isDirectory();
        zipArchiveEntry29.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField33);
        byte[] byteArray38 = asiExtraField33.getCentralDirectoryData();
        int int40 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray38, 3);
        int int41 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray38);
        java.lang.String str42 = fallbackZipEncoding26.decode(byteArray38);
        java.io.InputStream inputStream43 = java.io.InputStream.nullInputStream();
        byte[] byteArray45 = inputStream43.readNBytes((int) (short) 100);
        java.lang.String str46 = fallbackZipEncoding26.decode(byteArray45);
        java.io.InputStream inputStream47 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream48 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream47);
        java.io.InputStream inputStream49 = java.io.InputStream.nullInputStream();
        byte[] byteArray51 = inputStream49.readNBytes((int) (short) 100);
        int int54 = zipArchiveInputStream48.read(byteArray51, (int) ' ', 40960);
        java.lang.String str55 = fallbackZipEncoding26.decode(byteArray51);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray57 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray51, true);
        unicodeCommentExtraField21.setUnicodeName(byteArray51);
        byte[] byteArray59 = unicodeCommentExtraField21.getUnicodeName();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField62 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("\001\ufffd\ufffd\ufffd\ufffd", byteArray59, 17774, 19280);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(inputStream3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] {});
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertEquals(date9.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort23);
        org.junit.Assert.assertNotNull(zipShort24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(fileTime30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNull(byteArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 32868 + "'", int35 == 32868);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertArrayEquals(byteArray38, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 227 + "'", int40 == 227);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 26742 + "'", int41 == 26742);
// flaky "9) test1156(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str42 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str42, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertNotNull(inputStream43);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "" + "'", str46, "");
        org.junit.Assert.assertNotNull(inputStream49);
        org.junit.Assert.assertNotNull(byteArray51);
        org.junit.Assert.assertArrayEquals(byteArray51, new byte[] {});
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "" + "'", str55, "");
        org.junit.Assert.assertNotNull(zipExtraFieldArray57);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray57, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertArrayEquals(byteArray59, new byte[] {});
    }

    @Test
    public void test1157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1157");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        boolean boolean4 = zipArchiveEntry0.isDirectory();
        java.lang.Object obj5 = zipArchiveEntry0.clone();
        java.lang.String str6 = zipArchiveEntry0.getComment();
        byte[] byteArray7 = zipArchiveEntry0.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long9 = zipArchiveEntry8.getExternalAttributes();
        java.io.InputStream inputStream10 = java.io.InputStream.nullInputStream();
        byte[] byteArray12 = inputStream10.readNBytes((int) (short) 100);
        zipArchiveEntry8.setCentralDirectoryExtra(byteArray12);
        zipArchiveEntry8.setPlatform((int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray16 = zipArchiveEntry8.getExtraFields();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime18 = zipArchiveEntry17.getCreationTime();
        long long19 = zipArchiveEntry17.getSize();
        byte[] byteArray20 = zipArchiveEntry17.getExtra();
        int int21 = zipArchiveEntry17.getMethod();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong22 = org.apache.commons.compress.archivers.zip.ZipLong.LFH_SIG;
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry23 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime24 = zipArchiveEntry23.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry25 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry23);
        boolean boolean26 = zipLong22.equals((java.lang.Object) zipArchiveEntry25);
        java.lang.String str27 = zipArchiveEntry25.getComment();
        zipArchiveEntry25.setTime(0L);
        java.util.Date date30 = zipArchiveEntry25.getLastModifiedDate();
        java.time.LocalDateTime localDateTime31 = zipArchiveEntry25.getTimeLocal();
        zipArchiveEntry17.setTimeLocal(localDateTime31);
        zipArchiveEntry8.setTimeLocal(localDateTime31);
        zipArchiveEntry0.setTimeLocal(localDateTime31);
        long long35 = zipArchiveEntry0.getExternalAttributes();
        long long36 = zipArchiveEntry0.getCrc();
        byte[] byteArray39 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean41 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray39, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField42 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray39);
        byte[] byteArray43 = unicodeCommentExtraField42.getCentralDirectoryData();
        long long44 = unicodeCommentExtraField42.getNameCRC32();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong46 = new org.apache.commons.compress.archivers.zip.ZipLong((long) (short) -1);
        long long47 = zipLong46.getValue();
        java.util.Date date48 = org.apache.commons.compress.archivers.zip.ZipUtil.fromDosTime(zipLong46);
        org.apache.commons.compress.archivers.zip.ZipLong zipLong49 = org.apache.commons.compress.archivers.zip.ZipUtil.toDosTime(date48);
        byte[] byteArray50 = zipLong49.getBytes();
        unicodeCommentExtraField42.setUnicodeName(byteArray50);
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveEntry0.setExtra(byteArray50);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: data starting at 0 is in unknown format");
        } catch (java.lang.RuntimeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertEquals(obj5.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj5), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj5), "");
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(inputStream10);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray16);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray16, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNull(fileTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(zipLong22);
        org.junit.Assert.assertNull(fileTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertEquals(date30.toString(), "Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertArrayEquals(byteArray39, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1104745215L + "'", long44 == 1104745215L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1L) + "'", long47 == (-1L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertEquals(date48.toString(), "Sun Apr 01 08:04:02 PDT 2108");
        org.junit.Assert.assertNotNull(zipLong49);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertArrayEquals(byteArray50, new byte[] { (byte) -127, (byte) 64, (byte) -127, (byte) 0 });
    }

    @Test
    public void test1158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1158");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        java.lang.String str7 = zipArchiveEntry6.getComment();
        zipArchiveEntry6.setMethod((int) (byte) 0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry10 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long11 = zipArchiveEntry10.getExternalAttributes();
        java.io.InputStream inputStream12 = java.io.InputStream.nullInputStream();
        byte[] byteArray14 = inputStream12.readNBytes((int) (short) 100);
        zipArchiveEntry10.setCentralDirectoryExtra(byteArray14);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray16 = new org.apache.commons.compress.archivers.zip.ZipExtraField[] {};
        zipArchiveEntry10.setExtraFields(zipExtraFieldArray16);
        byte[] byteArray18 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray16);
        zipArchiveEntry6.setExtraFields(zipExtraFieldArray16);
        zipArchiveEntry6.setName("UTF8");
        java.lang.String str22 = zipArchiveEntry6.getName();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry23 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long24 = zipArchiveEntry23.getExternalAttributes();
        java.io.InputStream inputStream25 = java.io.InputStream.nullInputStream();
        byte[] byteArray27 = inputStream25.readNBytes((int) (short) 100);
        zipArchiveEntry23.setCentralDirectoryExtra(byteArray27);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry29 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry23);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry30 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry29);
        java.util.Date date31 = zipArchiveEntry29.getLastModifiedDate();
        zipArchiveEntry29.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker34 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry29.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker34);
        zipArchiveEntry29.setUnixMode(0);
        boolean boolean38 = zipArchiveEntry29.isDirectory();
        int int39 = zipArchiveEntry29.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry40 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long41 = zipArchiveEntry40.getExternalAttributes();
        zipArchiveEntry40.setSize((long) 28789);
        zipArchiveEntry40.setCrc(10L);
        zipArchiveEntry40.setPlatform(4095);
        java.lang.String str48 = zipArchiveEntry40.getName();
        java.nio.file.attribute.FileTime fileTime49 = zipArchiveEntry40.getCreationTime();
        byte[] byteArray50 = zipArchiveEntry40.getExtra();
        zipArchiveEntry40.setComment("a\000");
        java.lang.String str53 = zipArchiveEntry40.getName();
        java.io.InputStream inputStream54 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream55 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream54);
        long long57 = zipArchiveInputStream55.skip((long) 'a');
        byte[] byteArray59 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray60 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray59);
        int int63 = zipArchiveInputStream55.read(byteArray59, (int) ' ', 40960);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray65 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray59, false);
        zipArchiveEntry40.setExtraFields(zipExtraFieldArray65);
        java.util.Date date67 = zipArchiveEntry40.getLastModifiedDate();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry68 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime69 = zipArchiveEntry68.getCreationTime();
        byte[] byteArray71 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray72 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray71);
        zipArchiveEntry68.setExtraFields(zipExtraFieldArray72);
        zipArchiveEntry68.setTime((long) 32868);
        int int76 = zipArchiveEntry68.getPlatform();
        zipArchiveEntry68.setMethod(0);
        java.nio.file.attribute.FileTime fileTime79 = zipArchiveEntry68.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry80 = zipArchiveEntry40.setLastModifiedTime(fileTime79);
        java.util.zip.ZipEntry zipEntry81 = zipArchiveEntry29.setLastAccessTime(fileTime79);
        java.util.zip.ZipEntry zipEntry82 = zipArchiveEntry6.setLastAccessTime(fileTime79);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(inputStream12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray16);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray16, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "UTF8" + "'", str22, "UTF8");
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(inputStream25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] {});
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertEquals(date31.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "" + "'", str48, "");
        org.junit.Assert.assertNull(fileTime49);
        org.junit.Assert.assertNull(byteArray50);
        org.junit.Assert.assertEquals("'" + str53 + "' != '" + "" + "'", str53, "");
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertArrayEquals(byteArray59, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray60);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray60, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(zipExtraFieldArray65);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray65, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertEquals(date67.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNull(fileTime69);
        org.junit.Assert.assertNotNull(byteArray71);
        org.junit.Assert.assertArrayEquals(byteArray71, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray72);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray72, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(fileTime79);
        org.junit.Assert.assertNotNull(zipEntry80);
        org.junit.Assert.assertEquals(zipEntry80.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry81);
        org.junit.Assert.assertEquals(zipEntry81.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry82);
        org.junit.Assert.assertEquals(zipEntry82.toString(), "UTF8");
    }

    @Test
    public void test1159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1159");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding0 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean2 = fallbackZipEncoding0.canEncode("hi!");
        boolean boolean4 = fallbackZipEncoding0.canEncode("hi!");
        boolean boolean6 = fallbackZipEncoding0.canEncode("hi!");
        byte[] byteArray8 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        java.lang.String str9 = fallbackZipEncoding0.decode(byteArray8);
        java.nio.ByteBuffer byteBuffer11 = fallbackZipEncoding0.encode("\000\ufffd");
        java.nio.ByteBuffer byteBuffer13 = fallbackZipEncoding0.encode("hi!");
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry16 = zipArchiveInputStream15.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream19 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream15, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long21 = zipArchiveEntry20.getExternalAttributes();
        zipArchiveEntry20.setSize((long) 28789);
        zipArchiveEntry20.setCrc(10L);
        zipArchiveEntry20.setPlatform(4095);
        boolean boolean28 = zipArchiveEntry20.isDirectory();
        zipArchiveEntry20.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry31 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry20);
        byte[] byteArray32 = zipArchiveEntry20.getLocalFileDataExtra();
        int int35 = zipArchiveInputStream15.read(byteArray32, (int) '#', (int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream36 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream15);
        byte[] byteArray37 = zipArchiveInputStream15.readAllBytes();
        java.lang.String str38 = fallbackZipEncoding0.decode(byteArray37);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipShort zipShort40 = new org.apache.commons.compress.archivers.zip.ZipShort(byteArray37, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 0 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "\000\ufffd\000\000" + "'", str9, "\000\ufffd\000\000");
        org.junit.Assert.assertNotNull(byteBuffer11);
        org.junit.Assert.assertNotNull(byteBuffer13);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNull(archiveEntry16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] {});
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
    }

    @Test
    public void test1160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1160");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.lang.Object obj2 = zipArchiveEntry0.clone();
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray3 = zipArchiveEntry0.getExtraFields();
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker5 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField12 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray11);
        int int13 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray11);
        jarMarker5.parseFromLocalFileData(byteArray11, 511, 0);
        boolean boolean18 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray11, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField19 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray11);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort20 = unicodePathExtraField19.getCentralDirectoryLength();
        byte[] byteArray21 = unicodePathExtraField19.getLocalFileDataData();
        zipArchiveEntry0.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodePathExtraField19);
        java.util.Date date23 = zipArchiveEntry0.getLastModifiedDate();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "");
        org.junit.Assert.assertNotNull(zipExtraFieldArray3);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray3, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 65281 + "'", int13 == 65281);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(zipShort20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertEquals(date23.toString(), "Wed Dec 31 15:59:59 PST 1969");
    }

    @Test
    public void test1161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1161");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        int int8 = zipArchiveInputStream1.available();
        zipArchiveInputStream1.close();
        zipArchiveInputStream1.mark(33279);
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray13 = zipArchiveInputStream1.readNBytes((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test1162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1162");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.lang.Object obj2 = zipArchiveEntry0.clone();
        java.nio.file.attribute.FileTime fileTime3 = zipArchiveEntry0.getLastAccessTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry4 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long5 = zipArchiveEntry4.getExternalAttributes();
        java.io.InputStream inputStream6 = java.io.InputStream.nullInputStream();
        byte[] byteArray8 = inputStream6.readNBytes((int) (short) 100);
        zipArchiveEntry4.setCentralDirectoryExtra(byteArray8);
        int int10 = zipArchiveEntry4.getMethod();
        zipArchiveEntry4.setExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField12 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int13 = asiExtraField12.getGroupId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort14 = asiExtraField12.getCentralDirectoryLength();
        int int16 = asiExtraField12.getMode(40960);
        zipArchiveEntry4.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField12);
        zipArchiveEntry0.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField12);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry19 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime20 = zipArchiveEntry19.getCreationTime();
        byte[] byteArray22 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray23 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray22);
        zipArchiveEntry19.setExtraFields(zipExtraFieldArray23);
        zipArchiveEntry0.setExtraFields(zipExtraFieldArray23);
        zipArchiveEntry0.setTime((long) 33188);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long29 = zipArchiveEntry28.getExternalAttributes();
        java.lang.Object obj30 = zipArchiveEntry28.clone();
        java.nio.file.attribute.FileTime fileTime31 = zipArchiveEntry28.getLastAccessTime();
        zipArchiveEntry28.setUnixMode((-1));
        java.nio.file.attribute.FileTime fileTime34 = zipArchiveEntry28.getCreationTime();
        java.lang.String str35 = zipArchiveEntry28.getName();
        int int36 = zipArchiveEntry28.getUnixMode();
        zipArchiveEntry28.setSize(0L);
        java.lang.String str39 = zipArchiveEntry28.getName();
        java.nio.file.attribute.FileTime fileTime40 = zipArchiveEntry28.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry41 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long42 = zipArchiveEntry41.getExternalAttributes();
        zipArchiveEntry41.setSize((long) 28789);
        zipArchiveEntry41.setCrc(10L);
        zipArchiveEntry41.setPlatform(4095);
        java.lang.String str49 = zipArchiveEntry41.getName();
        java.nio.file.attribute.FileTime fileTime50 = zipArchiveEntry41.getCreationTime();
        byte[] byteArray51 = zipArchiveEntry41.getExtra();
        zipArchiveEntry41.setComment("a\000");
        java.lang.String str54 = zipArchiveEntry41.getName();
        java.io.InputStream inputStream55 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream56 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream55);
        long long58 = zipArchiveInputStream56.skip((long) 'a');
        byte[] byteArray60 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray61 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray60);
        int int64 = zipArchiveInputStream56.read(byteArray60, (int) ' ', 40960);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray66 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray60, false);
        zipArchiveEntry41.setExtraFields(zipExtraFieldArray66);
        java.util.Date date68 = zipArchiveEntry41.getLastModifiedDate();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry69 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime70 = zipArchiveEntry69.getCreationTime();
        byte[] byteArray72 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray73 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray72);
        zipArchiveEntry69.setExtraFields(zipExtraFieldArray73);
        zipArchiveEntry69.setTime((long) 32868);
        int int77 = zipArchiveEntry69.getPlatform();
        zipArchiveEntry69.setMethod(0);
        java.nio.file.attribute.FileTime fileTime80 = zipArchiveEntry69.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry81 = zipArchiveEntry41.setLastModifiedTime(fileTime80);
        java.util.zip.ZipEntry zipEntry82 = zipArchiveEntry28.setLastModifiedTime(fileTime80);
        java.util.zip.ZipEntry zipEntry83 = zipArchiveEntry0.setCreationTime(fileTime80);
        long long84 = zipArchiveEntry0.getExternalAttributes();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "");
        org.junit.Assert.assertNull(fileTime3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(inputStream6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(zipShort14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32768 + "'", int16 == 32768);
        org.junit.Assert.assertNull(fileTime20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray23);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray23, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertEquals(obj30.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj30), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj30), "");
        org.junit.Assert.assertNull(fileTime31);
        org.junit.Assert.assertNull(fileTime34);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 65535 + "'", int36 == 65535);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "" + "'", str39, "");
        org.junit.Assert.assertNull(fileTime40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "" + "'", str49, "");
        org.junit.Assert.assertNull(fileTime50);
        org.junit.Assert.assertNull(byteArray51);
        org.junit.Assert.assertEquals("'" + str54 + "' != '" + "" + "'", str54, "");
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertNotNull(byteArray60);
        org.junit.Assert.assertArrayEquals(byteArray60, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray61);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray61, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(zipExtraFieldArray66);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray66, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertEquals(date68.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNull(fileTime70);
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertArrayEquals(byteArray72, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray73);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray73, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(fileTime80);
        org.junit.Assert.assertNotNull(zipEntry81);
        org.junit.Assert.assertEquals(zipEntry81.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry82);
        org.junit.Assert.assertEquals(zipEntry82.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry83);
        org.junit.Assert.assertEquals(zipEntry83.toString(), "");
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
    }

    @Test
    public void test1163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1163");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort3 = new org.apache.commons.compress.archivers.zip.ZipShort((int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField4 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort3);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField5 = zipArchiveEntry0.getExtraField(zipShort3);
        int int6 = zipArchiveEntry0.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        zipArchiveEntry0.setTime((long) 5);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker10 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort11 = jarMarker10.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort12 = jarMarker10.getLocalFileDataLength();
        byte[] byteArray13 = jarMarker10.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort14 = jarMarker10.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort15 = jarMarker10.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = jarMarker10.getLocalFileDataLength();
        zipArchiveEntry0.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker10);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry18 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long19 = zipArchiveEntry18.getExternalAttributes();
        zipArchiveEntry18.setSize((long) 28789);
        zipArchiveEntry18.setCrc(10L);
        zipArchiveEntry18.setPlatform(4095);
        java.lang.Object obj26 = zipArchiveEntry18.clone();
        int int27 = zipArchiveEntry18.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long29 = zipArchiveEntry28.getExternalAttributes();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort31 = new org.apache.commons.compress.archivers.zip.ZipShort((int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField32 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort31);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField33 = zipArchiveEntry28.getExtraField(zipShort31);
        int int34 = zipArchiveEntry28.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry35 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry28);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray36 = zipArchiveEntry28.getExtraFields();
        byte[] byteArray37 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeLocalFileDataData(zipExtraFieldArray36);
        zipArchiveEntry18.setExtraFields(zipExtraFieldArray36);
        boolean boolean39 = zipArchiveEntry18.isDirectory();
        java.io.InputStream inputStream40 = java.io.InputStream.nullInputStream();
        byte[] byteArray42 = inputStream40.readNBytes((int) (short) 100);
        boolean boolean43 = inputStream40.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream46 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream40, "UTF8", true);
        long long48 = zipArchiveInputStream46.skip((long) 65281);
        byte[] byteArray50 = zipArchiveInputStream46.readNBytes(32868);
        zipArchiveInputStream46.mark(21589);
        byte[] byteArray53 = zipArchiveInputStream46.readAllBytes();
        boolean boolean54 = zipArchiveEntry18.equals((java.lang.Object) byteArray53);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry55 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long56 = zipArchiveEntry55.getExternalAttributes();
        zipArchiveEntry55.setSize((long) 28789);
        zipArchiveEntry55.setCrc(10L);
        zipArchiveEntry55.setPlatform(4095);
        boolean boolean63 = zipArchiveEntry55.isDirectory();
        zipArchiveEntry55.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry66 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry55);
        byte[] byteArray67 = zipArchiveEntry55.getLocalFileDataExtra();
        long long68 = zipArchiveEntry55.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry69 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry55);
        java.io.InputStream inputStream70 = java.io.InputStream.nullInputStream();
        byte[] byteArray72 = inputStream70.readNBytes((int) (short) 100);
        boolean boolean73 = inputStream70.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream76 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream70, "UTF8", true);
        zipArchiveInputStream76.close();
        boolean boolean78 = zipArchiveEntry69.equals((java.lang.Object) zipArchiveInputStream76);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry79 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime80 = zipArchiveEntry79.getCreationTime();
        byte[] byteArray82 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray83 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray82);
        zipArchiveEntry79.setExtraFields(zipExtraFieldArray83);
        zipArchiveEntry79.setTime((long) 32868);
        int int87 = zipArchiveEntry79.getPlatform();
        zipArchiveEntry79.setMethod(0);
        java.nio.file.attribute.FileTime fileTime90 = zipArchiveEntry79.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry91 = zipArchiveEntry69.setLastAccessTime(fileTime90);
        java.util.zip.ZipEntry zipEntry92 = zipArchiveEntry18.setLastAccessTime(fileTime90);
        java.util.zip.ZipEntry zipEntry93 = zipArchiveEntry0.setLastModifiedTime(fileTime90);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(zipExtraField4);
        org.junit.Assert.assertNull(zipExtraField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(zipShort11);
        org.junit.Assert.assertNotNull(zipShort12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort14);
        org.junit.Assert.assertNotNull(zipShort15);
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertEquals(obj26.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj26), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj26), "");
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(zipExtraField32);
        org.junit.Assert.assertNull(zipExtraField33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(zipExtraFieldArray36);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray36, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(inputStream40);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertArrayEquals(byteArray50, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertArrayEquals(byteArray53, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(byteArray67);
        org.junit.Assert.assertArrayEquals(byteArray67, new byte[] {});
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 5L + "'", long68 == 5L);
        org.junit.Assert.assertNotNull(inputStream70);
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertArrayEquals(byteArray72, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(fileTime80);
        org.junit.Assert.assertNotNull(byteArray82);
        org.junit.Assert.assertArrayEquals(byteArray82, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray83);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray83, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(fileTime90);
        org.junit.Assert.assertNotNull(zipEntry91);
        org.junit.Assert.assertEquals(zipEntry91.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry92);
        org.junit.Assert.assertEquals(zipEntry92.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry93);
        org.junit.Assert.assertEquals(zipEntry93.toString(), "");
    }

    @Test
    public void test1164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1164");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker1 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray7 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField8 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        int int9 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray7);
        jarMarker1.parseFromLocalFileData(byteArray7, 511, 0);
        boolean boolean14 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray7, (int) '#');
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField15 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray7);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = unicodePathExtraField15.getCentralDirectoryLength();
        byte[] byteArray17 = unicodePathExtraField15.getLocalFileDataData();
        byte[] byteArray18 = unicodePathExtraField15.getUnicodeName();
        byte[] byteArray19 = unicodePathExtraField15.getCentralDirectoryData();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipShort zipShort21 = new org.apache.commons.compress.archivers.zip.ZipShort(byteArray19, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 53 out of bounds for length 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 65281 + "'", int9 == 65281);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
    }

    @Test
    public void test1165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1165");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long7 = zipArchiveEntry6.getExternalAttributes();
        zipArchiveEntry6.setSize((long) 28789);
        zipArchiveEntry6.setCrc(10L);
        zipArchiveEntry6.setPlatform(4095);
        boolean boolean14 = zipArchiveEntry6.isDirectory();
        zipArchiveEntry6.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        byte[] byteArray18 = zipArchiveEntry6.getLocalFileDataExtra();
        int int21 = zipArchiveInputStream1.read(byteArray18, (int) '#', (int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream22 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        int int23 = zipArchiveInputStream1.read();
        int int24 = zipArchiveInputStream1.read();
        byte[] byteArray25 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray26 = zipArchiveInputStream1.readAllBytes();
        int int27 = zipArchiveInputStream1.getCount();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] {});
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test1166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1166");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.close();
        boolean boolean3 = zipArchiveInputStream1.markSupported();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry5 = zipArchiveInputStream1.getNextZipEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long8 = zipArchiveEntry7.getExternalAttributes();
        java.io.InputStream inputStream9 = java.io.InputStream.nullInputStream();
        byte[] byteArray11 = inputStream9.readNBytes((int) (short) 100);
        zipArchiveEntry7.setCentralDirectoryExtra(byteArray11);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry13 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry7);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry14 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry13);
        java.util.Date date15 = zipArchiveEntry13.getLastModifiedDate();
        zipArchiveEntry13.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker18 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry13.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker18);
        java.io.InputStream inputStream20 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream21 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream20);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry22 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime23 = zipArchiveEntry22.getCreationTime();
        long long24 = zipArchiveEntry22.getSize();
        byte[] byteArray25 = zipArchiveEntry22.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField26 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int28 = asiExtraField26.getMode(100);
        boolean boolean29 = asiExtraField26.isDirectory();
        zipArchiveEntry22.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField26);
        asiExtraField26.setGroupId(10);
        byte[] byteArray33 = asiExtraField26.getCentralDirectoryData();
        int int34 = inputStream20.read(byteArray33);
        inputStream20.mark(227);
        byte[] byteArray38 = inputStream20.readNBytes((int) (short) 1);
        jarMarker18.parseFromCentralDirectoryData(byteArray38, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort42 = jarMarker18.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort43 = jarMarker18.getHeaderId();
        byte[] byteArray44 = jarMarker18.getLocalFileDataData();
        byte[] byteArray45 = jarMarker18.getLocalFileDataData();
        // The following exception was thrown during execution in test generation
        try {
            int int48 = zipArchiveInputStream1.read(byteArray45, (int) '#', 25461);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(zipArchiveEntry5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(inputStream9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertEquals(date15.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream20);
        org.junit.Assert.assertNull(fileTime23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNull(byteArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 32868 + "'", int28 == 32868);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertArrayEquals(byteArray38, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort42);
        org.junit.Assert.assertNotNull(zipShort43);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertArrayEquals(byteArray44, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
    }

    @Test
    public void test1167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1167");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        zipArchiveInputStream1.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test1168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1168");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry3 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long4 = zipArchiveEntry3.getExternalAttributes();
        java.io.InputStream inputStream5 = java.io.InputStream.nullInputStream();
        byte[] byteArray7 = inputStream5.readNBytes((int) (short) 100);
        zipArchiveEntry3.setCentralDirectoryExtra(byteArray7);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry3);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry10 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry9);
        java.util.Date date11 = zipArchiveEntry9.getLastModifiedDate();
        zipArchiveEntry9.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker14 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry9.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker14);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField16 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int17 = asiExtraField16.getGroupId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort18 = asiExtraField16.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort19 = asiExtraField16.getLocalFileDataLength();
        asiExtraField16.setMode(16384);
        byte[] byteArray22 = asiExtraField16.getCentralDirectoryData();
        jarMarker14.parseFromLocalFileData(byteArray22, (int) (short) 1, (int) (byte) 0);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField26 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray22);
        int int27 = zipArchiveInputStream1.read(byteArray22);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort28 = new org.apache.commons.compress.archivers.zip.ZipShort(byteArray22);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(inputStream5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] {});
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertEquals(date11.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(zipShort18);
        org.junit.Assert.assertNotNull(zipShort19);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 57, (byte) 104, (byte) -33, (byte) -123, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test1169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1169");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        java.lang.String str7 = zipArchiveEntry6.getComment();
        java.nio.file.attribute.FileTime fileTime8 = zipArchiveEntry6.getLastModifiedTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long10 = zipArchiveEntry9.getExternalAttributes();
        java.lang.Object obj11 = zipArchiveEntry9.clone();
        java.nio.file.attribute.FileTime fileTime12 = zipArchiveEntry9.getLastAccessTime();
        byte[] byteArray13 = zipArchiveEntry9.getCentralDirectoryExtra();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        byte[] byteArray16 = new byte[] {};
        int int19 = zipArchiveInputStream15.read(byteArray16, 420, 1);
        java.io.InputStream inputStream20 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream21 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream20);
        java.io.InputStream inputStream22 = java.io.InputStream.nullInputStream();
        byte[] byteArray24 = inputStream22.readNBytes((int) (short) 100);
        int int27 = zipArchiveInputStream21.read(byteArray24, (int) ' ', 40960);
        byte[] byteArray28 = zipArchiveInputStream21.readAllBytes();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry9, byteArray16, byteArray28);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry30 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime31 = zipArchiveEntry30.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry32 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry30);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField33 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        zipArchiveEntry30.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField33);
        zipArchiveEntry30.setSize(0L);
        byte[] byteArray37 = zipArchiveEntry30.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry6, byteArray28, byteArray37);
        int int39 = zipArchiveEntry6.getUnixMode();
        zipArchiveEntry6.setComment("qk\030=\000@\000\000\000\000\000\000\000\000");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry42 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long43 = zipArchiveEntry42.getExternalAttributes();
        java.io.InputStream inputStream44 = java.io.InputStream.nullInputStream();
        byte[] byteArray46 = inputStream44.readNBytes((int) (short) 100);
        zipArchiveEntry42.setCentralDirectoryExtra(byteArray46);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField48 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int49 = asiExtraField48.getGroupId();
        asiExtraField48.setDirectory(true);
        byte[] byteArray52 = asiExtraField48.getCentralDirectoryData();
        java.io.InputStream inputStream53 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream54 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream53);
        java.io.InputStream inputStream55 = java.io.InputStream.nullInputStream();
        byte[] byteArray57 = inputStream55.readNBytes((int) (short) 100);
        int int60 = zipArchiveInputStream54.read(byteArray57, (int) ' ', 40960);
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry42, byteArray52, byteArray57);
        zipArchiveEntry6.setExtra(byteArray57);
        zipArchiveEntry6.setCompressedSize((long) 35697);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(fileTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertEquals(obj11.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj11), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj11), "");
        org.junit.Assert.assertNull(fileTime12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] {});
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] {});
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] {});
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] {});
        org.junit.Assert.assertNull(fileTime31);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] { (byte) 110, (byte) 117, (byte) 14, (byte) 0, (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(inputStream44);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertArrayEquals(byteArray46, new byte[] {});
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertArrayEquals(byteArray52, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(inputStream55);
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertArrayEquals(byteArray57, new byte[] {});
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
    }

    @Test
    public void test1170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1170");
        byte[] byteArray3 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean5 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray3, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField6 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray3);
        int int8 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray3, 0);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField9 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("\000\ufffd", byteArray3);
        java.io.InputStream inputStream10 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream11 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream10);
        long long13 = zipArchiveInputStream11.skip((long) 'a');
        long long15 = zipArchiveInputStream11.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream16 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream11);
        int int17 = zipArchiveInputStream11.available();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream18 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream11);
        byte[] byteArray20 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) ' ');
        int int21 = zipArchiveInputStream18.read(byteArray20);
        // The following exception was thrown during execution in test generation
        try {
            unicodeCommentExtraField9.parseFromLocalFileData(byteArray20, 0, 32776);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: Unsupported version [32] for UniCode path extra data.");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertArrayEquals(byteArray3, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] { (byte) 32, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test1171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1171");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort3 = new org.apache.commons.compress.archivers.zip.ZipShort((int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField4 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort3);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField5 = zipArchiveEntry0.getExtraField(zipShort3);
        int int6 = zipArchiveEntry0.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        byte[] byteArray13 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField14 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray13);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort15 = unicodePathExtraField14.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort16 = unicodePathExtraField14.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort17 = unicodePathExtraField14.getHeaderId();
        unicodePathExtraField14.setNameCRC32((long) 420);
        unicodePathExtraField14.setNameCRC32(3L);
        byte[] byteArray22 = unicodePathExtraField14.getCentralDirectoryData();
        unicodePathExtraField14.setNameCRC32((long) 34934);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort25 = unicodePathExtraField14.getHeaderId();
        long long26 = unicodePathExtraField14.getNameCRC32();
        zipArchiveEntry7.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodePathExtraField14);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long29 = zipArchiveEntry28.getExternalAttributes();
        zipArchiveEntry28.setSize((long) 28789);
        zipArchiveEntry28.setCrc(10L);
        zipArchiveEntry28.setPlatform(4095);
        boolean boolean36 = zipArchiveEntry28.isDirectory();
        zipArchiveEntry28.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry39 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry28);
        byte[] byteArray40 = zipArchiveEntry28.getLocalFileDataExtra();
        long long41 = zipArchiveEntry28.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry42 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry28);
        java.io.InputStream inputStream43 = java.io.InputStream.nullInputStream();
        byte[] byteArray45 = inputStream43.readNBytes((int) (short) 100);
        boolean boolean46 = inputStream43.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream49 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream43, "UTF8", true);
        zipArchiveInputStream49.close();
        boolean boolean51 = zipArchiveEntry42.equals((java.lang.Object) zipArchiveInputStream49);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry52 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime53 = zipArchiveEntry52.getCreationTime();
        byte[] byteArray55 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray56 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray55);
        zipArchiveEntry52.setExtraFields(zipExtraFieldArray56);
        zipArchiveEntry52.setTime((long) 32868);
        int int60 = zipArchiveEntry52.getPlatform();
        zipArchiveEntry52.setMethod(0);
        java.nio.file.attribute.FileTime fileTime63 = zipArchiveEntry52.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry64 = zipArchiveEntry42.setLastAccessTime(fileTime63);
        java.util.zip.ZipEntry zipEntry65 = zipArchiveEntry7.setLastAccessTime(fileTime63);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray66 = zipArchiveEntry7.getExtraFields();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(zipExtraField4);
        org.junit.Assert.assertNull(zipExtraField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertNotNull(zipShort15);
        org.junit.Assert.assertNotNull(zipShort16);
        org.junit.Assert.assertNotNull(zipShort17);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 1, (byte) 3, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipShort25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 34934L + "'", long26 == 34934L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertArrayEquals(byteArray40, new byte[] {});
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 5L + "'", long41 == 5L);
        org.junit.Assert.assertNotNull(inputStream43);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(fileTime53);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertArrayEquals(byteArray55, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray56);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray56, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(fileTime63);
        org.junit.Assert.assertNotNull(zipEntry64);
        org.junit.Assert.assertEquals(zipEntry64.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry65);
        org.junit.Assert.assertEquals(zipEntry65.toString(), "");
        org.junit.Assert.assertNotNull(zipExtraFieldArray66);
    }

    @Test
    public void test1172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1172");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getHeaderId();
        byte[] byteArray8 = unicodeCommentExtraField5.getCentralDirectoryData();
        unicodeCommentExtraField5.setNameCRC32((long) 26681);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
    }

    @Test
    public void test1173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1173");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        byte[] byteArray8 = zipArchiveInputStream6.readNBytes(28789);
        int int9 = zipArchiveInputStream6.read();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry10 = zipArchiveInputStream6.getNextZipEntry();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Class<?> wildcardClass11 = zipArchiveEntry10.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(zipArchiveEntry10);
    }

    @Test
    public void test1174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1174");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = zipArchiveInputStream6.getNextZipEntry();
        zipArchiveInputStream6.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = zipArchiveInputStream6.getNextZipEntry();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(zipArchiveEntry7);
        org.junit.Assert.assertNull(zipArchiveEntry9);
    }

    @Test
    public void test1175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1175");
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream3 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream2);
        byte[] byteArray4 = new byte[] {};
        int int7 = zipArchiveInputStream3.read(byteArray4, 420, 1);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField8 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("UTF8", byteArray4);
        byte[] byteArray9 = unicodeCommentExtraField8.getUnicodeName();
        long long11 = org.apache.commons.compress.archivers.zip.ZipLong.getValue(byteArray9, (int) (byte) 0);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField14 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray9, 51966, 32768);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] { (byte) 85, (byte) 84, (byte) 70, (byte) 56 });
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 944133205L + "'", long11 == 944133205L);
    }

    @Test
    public void test1176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1176");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        java.lang.String str7 = zipArchiveEntry6.getComment();
        java.nio.file.attribute.FileTime fileTime8 = zipArchiveEntry6.getLastModifiedTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long10 = zipArchiveEntry9.getExternalAttributes();
        java.lang.Object obj11 = zipArchiveEntry9.clone();
        java.nio.file.attribute.FileTime fileTime12 = zipArchiveEntry9.getLastAccessTime();
        byte[] byteArray13 = zipArchiveEntry9.getCentralDirectoryExtra();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        byte[] byteArray16 = new byte[] {};
        int int19 = zipArchiveInputStream15.read(byteArray16, 420, 1);
        java.io.InputStream inputStream20 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream21 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream20);
        java.io.InputStream inputStream22 = java.io.InputStream.nullInputStream();
        byte[] byteArray24 = inputStream22.readNBytes((int) (short) 100);
        int int27 = zipArchiveInputStream21.read(byteArray24, (int) ' ', 40960);
        byte[] byteArray28 = zipArchiveInputStream21.readAllBytes();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry9, byteArray16, byteArray28);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry30 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime31 = zipArchiveEntry30.getCreationTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry32 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry30);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField33 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        zipArchiveEntry30.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField33);
        zipArchiveEntry30.setSize(0L);
        byte[] byteArray37 = zipArchiveEntry30.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry6, byteArray28, byteArray37);
        int int39 = zipArchiveEntry6.getUnixMode();
        byte[] byteArray41 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) (byte) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort43 = new org.apache.commons.compress.archivers.zip.ZipShort(byteArray41, (int) (byte) 0);
        zipArchiveEntry6.setExtra(byteArray41);
        byte[] byteArray45 = zipArchiveEntry6.getCentralDirectoryExtra();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry46 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long47 = zipArchiveEntry46.getExternalAttributes();
        zipArchiveEntry46.setSize((long) 28789);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry50 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry46);
        java.lang.String str51 = zipArchiveEntry50.getName();
        boolean boolean52 = zipArchiveEntry6.equals((java.lang.Object) str51);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(fileTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertEquals(obj11.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj11), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj11), "");
        org.junit.Assert.assertNull(fileTime12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] {});
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] {});
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] {});
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] {});
        org.junit.Assert.assertNull(fileTime31);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertArrayEquals(byteArray37, new byte[] { (byte) 110, (byte) 117, (byte) 14, (byte) 0, (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertArrayEquals(byteArray41, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test1177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1177");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime16 = zipArchiveEntry15.getCreationTime();
        long long17 = zipArchiveEntry15.getSize();
        byte[] byteArray18 = zipArchiveEntry15.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField19 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int21 = asiExtraField19.getMode(100);
        boolean boolean22 = asiExtraField19.isDirectory();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField19);
        asiExtraField19.setGroupId(10);
        byte[] byteArray26 = asiExtraField19.getCentralDirectoryData();
        int int27 = inputStream13.read(byteArray26);
        inputStream13.mark(227);
        byte[] byteArray31 = inputStream13.readNBytes((int) (short) 1);
        jarMarker11.parseFromCentralDirectoryData(byteArray31, 4095, (int) (short) 0);
        byte[] byteArray35 = jarMarker11.getCentralDirectoryData();
        byte[] byteArray36 = jarMarker11.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort37 = jarMarker11.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort38 = jarMarker11.getHeaderId();
        java.io.InputStream inputStream39 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream40 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream39);
        java.io.InputStream inputStream41 = java.io.InputStream.nullInputStream();
        byte[] byteArray43 = inputStream41.readNBytes((int) (short) 100);
        int int46 = zipArchiveInputStream40.read(byteArray43, (int) ' ', 40960);
        byte[] byteArray47 = zipArchiveInputStream40.readAllBytes();
        byte[] byteArray49 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int52 = zipArchiveInputStream40.read(byteArray49, (-1), 100);
        zipArchiveInputStream40.mark(16419);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding55 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean57 = fallbackZipEncoding55.canEncode("hi!");
        boolean boolean59 = fallbackZipEncoding55.canEncode("hi!");
        boolean boolean61 = fallbackZipEncoding55.canEncode("UTF8");
        boolean boolean63 = fallbackZipEncoding55.canEncode("\000\ufffd");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry64 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long65 = zipArchiveEntry64.getExternalAttributes();
        zipArchiveEntry64.setSize((long) 28789);
        zipArchiveEntry64.setCrc(10L);
        zipArchiveEntry64.setPlatform(4095);
        byte[] byteArray72 = zipArchiveEntry64.getCentralDirectoryExtra();
        boolean boolean74 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray72, (int) (byte) 0);
        java.lang.String str75 = fallbackZipEncoding55.decode(byteArray72);
        boolean boolean77 = fallbackZipEncoding55.canEncode("");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding78 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        byte[] byteArray80 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) 'a');
        java.lang.String str81 = fallbackZipEncoding78.decode(byteArray80);
        java.lang.String str82 = fallbackZipEncoding55.decode(byteArray80);
        int int85 = zipArchiveInputStream40.readNBytes(byteArray80, 0, 0);
        // The following exception was thrown during execution in test generation
        try {
            jarMarker11.parseFromCentralDirectoryData(byteArray80, 35582, 34934);
            org.junit.Assert.fail("Expected exception of type java.util.zip.ZipException; message: JarMarker doesn't expect any data");
        } catch (java.util.zip.ZipException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(fileTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32868 + "'", int21 == 32868);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort37);
        org.junit.Assert.assertNotNull(zipShort38);
        org.junit.Assert.assertNotNull(inputStream41);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] {});
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertArrayEquals(byteArray47, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertArrayEquals(byteArray49, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertArrayEquals(byteArray72, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertEquals("'" + str75 + "' != '" + "" + "'", str75, "");
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(byteArray80);
        org.junit.Assert.assertArrayEquals(byteArray80, new byte[] { (byte) 97, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str81 + "' != '" + "a\000" + "'", str81, "a\000");
        org.junit.Assert.assertEquals("'" + str82 + "' != '" + "a\000" + "'", str82, "a\000");
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
    }

    @Test
    public void test1178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1178");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip(3817498742L);
        zipArchiveInputStream1.mark((int) (short) 100);
        java.io.InputStream inputStream6 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream6);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime9 = zipArchiveEntry8.getCreationTime();
        long long10 = zipArchiveEntry8.getSize();
        byte[] byteArray11 = zipArchiveEntry8.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField12 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int14 = asiExtraField12.getMode(100);
        boolean boolean15 = asiExtraField12.isDirectory();
        zipArchiveEntry8.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField12);
        asiExtraField12.setGroupId(10);
        byte[] byteArray19 = asiExtraField12.getCentralDirectoryData();
        int int20 = inputStream6.read(byteArray19);
        inputStream6.mark(227);
        byte[] byteArray24 = inputStream6.readNBytes((int) (short) 1);
        int int27 = zipArchiveInputStream1.read(byteArray24, (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(inputStream6);
        org.junit.Assert.assertNull(fileTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNull(byteArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 32868 + "'", int14 == 32868);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] {});
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test1179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1179");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        java.util.Date date8 = zipArchiveEntry6.getLastModifiedDate();
        zipArchiveEntry6.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker11 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry6.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker11);
        java.io.InputStream inputStream13 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream13);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime16 = zipArchiveEntry15.getCreationTime();
        long long17 = zipArchiveEntry15.getSize();
        byte[] byteArray18 = zipArchiveEntry15.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField19 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int21 = asiExtraField19.getMode(100);
        boolean boolean22 = asiExtraField19.isDirectory();
        zipArchiveEntry15.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField19);
        asiExtraField19.setGroupId(10);
        byte[] byteArray26 = asiExtraField19.getCentralDirectoryData();
        int int27 = inputStream13.read(byteArray26);
        inputStream13.mark(227);
        byte[] byteArray31 = inputStream13.readNBytes((int) (short) 1);
        jarMarker11.parseFromCentralDirectoryData(byteArray31, 4095, (int) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = jarMarker11.getLocalFileDataLength();
        byte[] byteArray36 = jarMarker11.getLocalFileDataData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort37 = jarMarker11.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort38 = jarMarker11.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort39 = jarMarker11.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort40 = jarMarker11.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort41 = jarMarker11.getHeaderId();
        byte[] byteArray42 = jarMarker11.getLocalFileDataData();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertEquals(date8.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream13);
        org.junit.Assert.assertNull(fileTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32868 + "'", int21 == 32868);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort37);
        org.junit.Assert.assertNotNull(zipShort38);
        org.junit.Assert.assertNotNull(zipShort39);
        org.junit.Assert.assertNotNull(zipShort40);
        org.junit.Assert.assertNotNull(zipShort41);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] {});
    }

    @Test
    public void test1180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1180");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding0 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean2 = fallbackZipEncoding0.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry3 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime4 = zipArchiveEntry3.getCreationTime();
        long long5 = zipArchiveEntry3.getSize();
        byte[] byteArray6 = zipArchiveEntry3.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField7 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int9 = asiExtraField7.getMode(100);
        boolean boolean10 = asiExtraField7.isDirectory();
        zipArchiveEntry3.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField7);
        byte[] byteArray12 = asiExtraField7.getCentralDirectoryData();
        int int14 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray12, 3);
        int int15 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray12);
        java.lang.String str16 = fallbackZipEncoding0.decode(byteArray12);
        byte[] byteArray22 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField23 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray22);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort24 = unicodePathExtraField23.getHeaderId();
        byte[] byteArray25 = unicodePathExtraField23.getCentralDirectoryData();
        java.lang.String str26 = fallbackZipEncoding0.decode(byteArray25);
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding27 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean29 = fallbackZipEncoding27.canEncode("hi!");
        boolean boolean31 = fallbackZipEncoding27.canEncode("hi!");
        java.nio.ByteBuffer byteBuffer33 = fallbackZipEncoding27.encode("UTF8");
        boolean boolean35 = fallbackZipEncoding27.canEncode("\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        boolean boolean37 = fallbackZipEncoding27.canEncode("\ufffd\ufffdi\000\ufffd\000\000\000\000\000\000\ufffd");
        byte[] byteArray45 = new byte[] { (byte) 10, (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField46 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("hi!", byteArray45);
        long long47 = unicodeCommentExtraField46.getNameCRC32();
        byte[] byteArray48 = unicodeCommentExtraField46.getCentralDirectoryData();
        java.lang.String str49 = fallbackZipEncoding27.decode(byteArray48);
        java.lang.String str50 = fallbackZipEncoding0.decode(byteArray48);
        boolean boolean52 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray48, 32803);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(fileTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32868 + "'", int9 == 32868);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 227 + "'", int14 == 227);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 26742 + "'", int15 == 26742);
// flaky "10) test1180(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str16, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertNotNull(zipShort24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "\001\ufffd\ufffd\ufffd\ufffd" + "'", str26, "\001\ufffd\ufffd\ufffd\ufffd");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(byteBuffer33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] { (byte) 10, (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 });
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 646776791L + "'", long47 == 646776791L);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertArrayEquals(byteArray48, new byte[] { (byte) 1, (byte) -41, (byte) 7, (byte) -115, (byte) 38, (byte) 104, (byte) 105, (byte) 33 });
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "\001\ufffd\007\ufffd&hi!" + "'", str49, "\001\ufffd\007\ufffd&hi!");
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "\001\ufffd\007\ufffd&hi!" + "'", str50, "\001\ufffd\007\ufffd&hi!");
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test1181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1181");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        zipArchiveInputStream6.mark(27505);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry9 = zipArchiveInputStream6.getNextEntry();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(archiveEntry9);
    }

    @Test
    public void test1182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1182");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long7 = zipArchiveEntry6.getExternalAttributes();
        zipArchiveEntry6.setSize((long) 28789);
        zipArchiveEntry6.setCrc(10L);
        zipArchiveEntry6.setPlatform(4095);
        boolean boolean14 = zipArchiveEntry6.isDirectory();
        zipArchiveEntry6.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        byte[] byteArray18 = zipArchiveEntry6.getLocalFileDataExtra();
        int int21 = zipArchiveInputStream1.read(byteArray18, (int) '#', (int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream22 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry23 = zipArchiveInputStream1.getNextEntry();
        int int24 = zipArchiveInputStream1.getCount();
        byte[] byteArray25 = zipArchiveInputStream1.readAllBytes();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(archiveEntry23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
    }

    @Test
    public void test1183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1183");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream4 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry5 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long6 = zipArchiveEntry5.getExternalAttributes();
        java.io.InputStream inputStream7 = java.io.InputStream.nullInputStream();
        byte[] byteArray9 = inputStream7.readNBytes((int) (short) 100);
        zipArchiveEntry5.setCentralDirectoryExtra(byteArray9);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry11 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry11);
        java.util.Date date13 = zipArchiveEntry11.getLastModifiedDate();
        zipArchiveEntry11.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker16 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry11.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker16);
        java.io.InputStream inputStream18 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream19 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream18);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime21 = zipArchiveEntry20.getCreationTime();
        long long22 = zipArchiveEntry20.getSize();
        byte[] byteArray23 = zipArchiveEntry20.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField24 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int26 = asiExtraField24.getMode(100);
        boolean boolean27 = asiExtraField24.isDirectory();
        zipArchiveEntry20.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField24);
        asiExtraField24.setGroupId(10);
        byte[] byteArray31 = asiExtraField24.getCentralDirectoryData();
        int int32 = inputStream18.read(byteArray31);
        inputStream18.mark(227);
        byte[] byteArray36 = inputStream18.readNBytes((int) (short) 1);
        jarMarker16.parseFromCentralDirectoryData(byteArray36, 4095, (int) (short) 0);
        int int40 = zipArchiveInputStream4.read(byteArray36);
        int int41 = zipArchiveInputStream4.read();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream42 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream4);
        zipArchiveInputStream4.close();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertEquals(date13.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(inputStream18);
        org.junit.Assert.assertNull(fileTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNull(byteArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32868 + "'", int26 == 32868);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) -4, (byte) -128, (byte) 101, (byte) 25, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 10, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test1184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1184");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        zipArchiveEntry0.setSize(312796988911L);
        long long3 = zipArchiveEntry0.getExternalAttributes();
        int int4 = zipArchiveEntry0.getInternalAttributes();
        zipArchiveEntry0.setSize(312912242339L);
        long long7 = zipArchiveEntry0.getExternalAttributes();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long9 = zipArchiveEntry8.getExternalAttributes();
        zipArchiveEntry8.setSize((long) 28789);
        zipArchiveEntry8.setCrc(10L);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry14 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long15 = zipArchiveEntry14.getExternalAttributes();
        java.io.InputStream inputStream16 = java.io.InputStream.nullInputStream();
        byte[] byteArray18 = inputStream16.readNBytes((int) (short) 100);
        zipArchiveEntry14.setCentralDirectoryExtra(byteArray18);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray20 = new org.apache.commons.compress.archivers.zip.ZipExtraField[] {};
        zipArchiveEntry14.setExtraFields(zipExtraFieldArray20);
        zipArchiveEntry8.setExtraFields(zipExtraFieldArray20);
        java.util.Date date23 = zipArchiveEntry8.getLastModifiedDate();
        zipArchiveEntry8.setName("UTF8");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry26 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long27 = zipArchiveEntry26.getExternalAttributes();
        zipArchiveEntry26.setSize((long) 28789);
        zipArchiveEntry26.setCrc(10L);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry32 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long33 = zipArchiveEntry32.getExternalAttributes();
        java.io.InputStream inputStream34 = java.io.InputStream.nullInputStream();
        byte[] byteArray36 = inputStream34.readNBytes((int) (short) 100);
        zipArchiveEntry32.setCentralDirectoryExtra(byteArray36);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray38 = new org.apache.commons.compress.archivers.zip.ZipExtraField[] {};
        zipArchiveEntry32.setExtraFields(zipExtraFieldArray38);
        zipArchiveEntry26.setExtraFields(zipExtraFieldArray38);
        java.util.Date date41 = zipArchiveEntry26.getLastModifiedDate();
        int int42 = zipArchiveEntry26.getMethod();
        byte[] byteArray43 = zipArchiveEntry26.getLocalFileDataExtra();
        long long44 = zipArchiveEntry26.getTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry45 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long46 = zipArchiveEntry45.getExternalAttributes();
        zipArchiveEntry45.setSize((long) 28789);
        zipArchiveEntry45.setCrc(10L);
        zipArchiveEntry45.setPlatform(4095);
        byte[] byteArray53 = zipArchiveEntry45.getCentralDirectoryExtra();
        byte[] byteArray54 = zipArchiveEntry45.getLocalFileDataExtra();
        java.lang.String str55 = zipArchiveEntry45.getName();
        byte[] byteArray58 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean60 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray58, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField61 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray58);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort62 = unicodeCommentExtraField61.getHeaderId();
        zipArchiveEntry45.addAsFirstExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) unicodeCommentExtraField61);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry64 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime65 = zipArchiveEntry64.getCreationTime();
        byte[] byteArray67 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray68 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray67);
        zipArchiveEntry64.setExtraFields(zipExtraFieldArray68);
        zipArchiveEntry64.setTime((long) 32868);
        int int72 = zipArchiveEntry64.getPlatform();
        zipArchiveEntry64.setMethod(0);
        java.nio.file.attribute.FileTime fileTime75 = zipArchiveEntry64.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry76 = zipArchiveEntry45.setLastModifiedTime(fileTime75);
        java.util.zip.ZipEntry zipEntry77 = zipArchiveEntry26.setCreationTime(fileTime75);
        java.util.zip.ZipEntry zipEntry78 = zipArchiveEntry8.setLastAccessTime(fileTime75);
        java.util.zip.ZipEntry zipEntry79 = zipArchiveEntry0.setCreationTime(fileTime75);
        zipArchiveEntry0.setExtra();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray20);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray20, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertEquals(date23.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(inputStream34);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray38);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray38, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertEquals(date41.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] {});
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertArrayEquals(byteArray53, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertArrayEquals(byteArray54, new byte[] {});
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "" + "'", str55, "");
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertArrayEquals(byteArray58, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(zipShort62);
        org.junit.Assert.assertNull(fileTime65);
        org.junit.Assert.assertNotNull(byteArray67);
        org.junit.Assert.assertArrayEquals(byteArray67, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray68);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray68, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(fileTime75);
        org.junit.Assert.assertNotNull(zipEntry76);
        org.junit.Assert.assertEquals(zipEntry76.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry77);
        org.junit.Assert.assertEquals(zipEntry77.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry78);
        org.junit.Assert.assertEquals(zipEntry78.toString(), "UTF8");
        org.junit.Assert.assertNotNull(zipEntry79);
        org.junit.Assert.assertEquals(zipEntry79.toString(), "");
    }

    @Test
    public void test1185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1185");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream5);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry7 = zipArchiveInputStream6.getNextEntry();
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding8 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean10 = fallbackZipEncoding8.canEncode("hi!");
        boolean boolean12 = fallbackZipEncoding8.canEncode("hi!");
        java.nio.ByteBuffer byteBuffer14 = fallbackZipEncoding8.encode("UTF8");
        byte[] byteArray16 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray17 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray16);
        byte[] byteArray18 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeCentralDirectoryData(zipExtraFieldArray17);
        java.lang.String str19 = fallbackZipEncoding8.decode(byteArray18);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long21 = zipArchiveEntry20.getExternalAttributes();
        zipArchiveEntry20.setSize((long) 28789);
        zipArchiveEntry20.setCrc(10L);
        zipArchiveEntry20.setPlatform(4095);
        java.lang.String str28 = zipArchiveEntry20.getName();
        java.nio.file.attribute.FileTime fileTime29 = zipArchiveEntry20.getCreationTime();
        byte[] byteArray30 = zipArchiveEntry20.getExtra();
        byte[] byteArray32 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((-1));
        zipArchiveEntry20.setExtra(byteArray32);
        java.lang.String str34 = fallbackZipEncoding8.decode(byteArray32);
        boolean boolean36 = fallbackZipEncoding8.canEncode("\000!\000\000");
        java.nio.ByteBuffer byteBuffer38 = fallbackZipEncoding8.encode("nu\016\000\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000up\005\000\001\ufffd\001\000\000nu\016\000\ufffd\ufffd\017\000\000\000\000\000\000\000\000\ufffduc\b\000\001\ufffd\007\ufffd&hi!nu\016\000qk\030=\000@\000\000\000\000\000\000\000\000up\005\000\001\ufffd\ufffd\ufffd\ufffd");
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField40 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int41 = asiExtraField40.getGroupId();
        asiExtraField40.setDirectory(true);
        byte[] byteArray44 = asiExtraField40.getCentralDirectoryData();
        long long45 = org.apache.commons.compress.archivers.zip.ZipLong.getValue(byteArray44);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField46 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("\001\u01bahi!", byteArray44);
        java.lang.String str47 = fallbackZipEncoding8.decode(byteArray44);
        int int48 = zipArchiveInputStream6.read(byteArray44);
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveInputStream6.reset();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: mark/reset not supported");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertNull(archiveEntry7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(byteBuffer14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray17);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray17, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertNull(fileTime29);
        org.junit.Assert.assertNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) -1, (byte) -1 });
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "\ufffd\ufffd" + "'", str34, "\ufffd\ufffd");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(byteBuffer38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertArrayEquals(byteArray44, new byte[] { (byte) 113, (byte) 107, (byte) 24, (byte) 61, (byte) 0, (byte) 64, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1025010545L + "'", long45 == 1025010545L);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "qk\030=\000@\000\000\000\000\000\000\000\000" + "'", str47, "qk\030=\000@\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test1186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1186");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry9 = zipArchiveInputStream8.getNextEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertNull(archiveEntry9);
    }

    @Test
    public void test1187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1187");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = zipArchiveInputStream6.getNextZipEntry();
        byte[] byteArray8 = zipArchiveInputStream6.readAllBytes();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(zipArchiveEntry7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
    }

    @Test
    public void test1188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1188");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry6 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long7 = zipArchiveEntry6.getExternalAttributes();
        zipArchiveEntry6.setSize((long) 28789);
        zipArchiveEntry6.setCrc(10L);
        zipArchiveEntry6.setPlatform(4095);
        boolean boolean14 = zipArchiveEntry6.isDirectory();
        zipArchiveEntry6.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry17 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry6);
        byte[] byteArray18 = zipArchiveEntry6.getLocalFileDataExtra();
        int int21 = zipArchiveInputStream1.read(byteArray18, (int) '#', (int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream22 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        boolean boolean23 = zipArchiveInputStream22.markSupported();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test1189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1189");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        long long9 = zipArchiveInputStream1.skip((long) 28789);
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry12 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long13 = zipArchiveEntry12.getExternalAttributes();
        java.io.InputStream inputStream14 = java.io.InputStream.nullInputStream();
        byte[] byteArray16 = inputStream14.readNBytes((int) (short) 100);
        zipArchiveEntry12.setCentralDirectoryExtra(byteArray16);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry18 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry12);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry19 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry18);
        java.util.Date date20 = zipArchiveEntry18.getLastModifiedDate();
        zipArchiveEntry18.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker23 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry18.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker23);
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField25 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int26 = asiExtraField25.getGroupId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort27 = asiExtraField25.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort28 = asiExtraField25.getLocalFileDataLength();
        asiExtraField25.setMode(16384);
        byte[] byteArray31 = asiExtraField25.getCentralDirectoryData();
        jarMarker23.parseFromLocalFileData(byteArray31, (int) (short) 1, (int) (byte) 0);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField35 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray31);
        byte[] byteArray36 = unicodeCommentExtraField35.getCentralDirectoryData();
        // The following exception was thrown during execution in test generation
        try {
            int int39 = zipArchiveInputStream1.readNBytes(byteArray36, 32995, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Range [32995, 32995 + 100) out of bounds for length 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(inputStream14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] {});
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertEquals(date20.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(zipShort27);
        org.junit.Assert.assertNotNull(zipShort28);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) 57, (byte) 104, (byte) -33, (byte) -123, (byte) 0, (byte) -128, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] { (byte) 1, (byte) 15, (byte) -8, (byte) 0, (byte) -50 });
    }

    @Test
    public void test1190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1190");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort3 = new org.apache.commons.compress.archivers.zip.ZipShort((int) (byte) 1);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField4 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort3);
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField5 = zipArchiveEntry0.getExtraField(zipShort3);
        int int6 = zipArchiveEntry0.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        java.nio.file.attribute.FileTime fileTime8 = zipArchiveEntry7.getLastModifiedTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long10 = zipArchiveEntry9.getExternalAttributes();
        zipArchiveEntry9.setSize((long) 28789);
        zipArchiveEntry9.setCrc(10L);
        zipArchiveEntry9.setPlatform(4095);
        boolean boolean17 = zipArchiveEntry9.isDirectory();
        zipArchiveEntry9.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry9);
        byte[] byteArray21 = zipArchiveEntry9.getLocalFileDataExtra();
        long long22 = zipArchiveEntry9.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry23 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry9);
        java.io.InputStream inputStream24 = java.io.InputStream.nullInputStream();
        byte[] byteArray26 = inputStream24.readNBytes((int) (short) 100);
        boolean boolean27 = inputStream24.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream30 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream24, "UTF8", true);
        zipArchiveInputStream30.close();
        boolean boolean32 = zipArchiveEntry23.equals((java.lang.Object) zipArchiveInputStream30);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry33 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime34 = zipArchiveEntry33.getCreationTime();
        byte[] byteArray36 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray37 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray36);
        zipArchiveEntry33.setExtraFields(zipExtraFieldArray37);
        zipArchiveEntry33.setTime((long) 32868);
        int int41 = zipArchiveEntry33.getPlatform();
        zipArchiveEntry33.setMethod(0);
        java.nio.file.attribute.FileTime fileTime44 = zipArchiveEntry33.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry45 = zipArchiveEntry23.setLastAccessTime(fileTime44);
        java.util.zip.ZipEntry zipEntry46 = zipArchiveEntry7.setLastAccessTime(fileTime44);
        zipArchiveEntry7.setComment("\016\000");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(zipExtraField4);
        org.junit.Assert.assertNull(zipExtraField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(fileTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] {});
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 5L + "'", long22 == 5L);
        org.junit.Assert.assertNotNull(inputStream24);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertArrayEquals(byteArray26, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(fileTime34);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray37);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray37, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(fileTime44);
        org.junit.Assert.assertNotNull(zipEntry45);
        org.junit.Assert.assertEquals(zipEntry45.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry46);
        org.junit.Assert.assertEquals(zipEntry46.toString(), "");
    }

    @Test
    public void test1191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1191");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField6 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray5);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodePathExtraField6.getLocalFileDataLength();
        java.io.InputStream inputStream8 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream9 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream8);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker10 = org.apache.commons.compress.archivers.zip.JarMarker.getInstance();
        byte[] byteArray11 = jarMarker10.getCentralDirectoryData();
        int int14 = zipArchiveInputStream9.read(byteArray11, (int) (short) 0, (int) '#');
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long16 = zipArchiveEntry15.getExternalAttributes();
        zipArchiveEntry15.setSize((long) 28789);
        zipArchiveEntry15.setCrc(10L);
        zipArchiveEntry15.setPlatform(4095);
        java.lang.String str23 = zipArchiveEntry15.getName();
        byte[] byteArray25 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        zipArchiveEntry15.setCentralDirectoryExtra(byteArray25);
        long long27 = zipArchiveEntry15.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long29 = zipArchiveEntry28.getExternalAttributes();
        java.lang.Object obj30 = zipArchiveEntry28.clone();
        java.nio.file.attribute.FileTime fileTime31 = zipArchiveEntry28.getLastAccessTime();
        byte[] byteArray33 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        zipArchiveEntry28.setExtra(byteArray33);
        zipArchiveEntry15.setExtra(byteArray33);
        int int38 = zipArchiveInputStream9.read(byteArray33, (int) (short) 10, 0);
        unicodePathExtraField6.setUnicodeName(byteArray33);
        byte[] byteArray40 = unicodePathExtraField6.getUnicodeName();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(jarMarker10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28789L + "'", long27 == 28789L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertEquals(obj30.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj30), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj30), "");
        org.junit.Assert.assertNull(fileTime31);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertArrayEquals(byteArray40, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
    }

    @Test
    public void test1192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1192");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        long long8 = zipArchiveInputStream6.skip((long) 65281);
        byte[] byteArray10 = zipArchiveInputStream6.readNBytes(32868);
        byte[] byteArray13 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) (byte) 100);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField14 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("\000\ufffd", byteArray13);
        int int17 = zipArchiveInputStream6.read(byteArray13, 28789, 32803);
        int int18 = zipArchiveInputStream6.available();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry19 = zipArchiveInputStream6.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = zipArchiveInputStream6.getNextZipEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 100, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(archiveEntry19);
        org.junit.Assert.assertNull(zipArchiveEntry20);
    }

    @Test
    public void test1193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1193");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        int int3 = zipArchiveInputStream1.getCount();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry4 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(archiveEntry4);
    }

    @Test
    public void test1194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1194");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.close();
        boolean boolean3 = zipArchiveInputStream1.markSupported();
        zipArchiveInputStream1.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        int int6 = zipArchiveInputStream1.available();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = zipArchiveInputStream1.getNextZipEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(zipArchiveEntry7);
    }

    @Test
    public void test1195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1195");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        byte[] byteArray8 = zipArchiveInputStream6.readNBytes(28789);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry9 = zipArchiveInputStream6.getNextEntry();
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding10 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean12 = fallbackZipEncoding10.canEncode("hi!");
        boolean boolean14 = fallbackZipEncoding10.canEncode("hi!");
        boolean boolean16 = fallbackZipEncoding10.canEncode("UTF8");
        boolean boolean18 = fallbackZipEncoding10.canEncode("\000\ufffd");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry19 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long20 = zipArchiveEntry19.getExternalAttributes();
        zipArchiveEntry19.setSize((long) 28789);
        zipArchiveEntry19.setCrc(10L);
        zipArchiveEntry19.setPlatform(4095);
        byte[] byteArray27 = zipArchiveEntry19.getCentralDirectoryExtra();
        boolean boolean29 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray27, (int) (byte) 0);
        java.lang.String str30 = fallbackZipEncoding10.decode(byteArray27);
        int int33 = zipArchiveInputStream6.read(byteArray27, 27505, 32803);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNull(archiveEntry9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test1196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1196");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField6 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray5);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodePathExtraField6.getLocalFileDataLength();
        java.io.InputStream inputStream8 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream9 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream8);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker10 = org.apache.commons.compress.archivers.zip.JarMarker.getInstance();
        byte[] byteArray11 = jarMarker10.getCentralDirectoryData();
        int int14 = zipArchiveInputStream9.read(byteArray11, (int) (short) 0, (int) '#');
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long16 = zipArchiveEntry15.getExternalAttributes();
        zipArchiveEntry15.setSize((long) 28789);
        zipArchiveEntry15.setCrc(10L);
        zipArchiveEntry15.setPlatform(4095);
        java.lang.String str23 = zipArchiveEntry15.getName();
        byte[] byteArray25 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 40960);
        zipArchiveEntry15.setCentralDirectoryExtra(byteArray25);
        long long27 = zipArchiveEntry15.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry28 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long29 = zipArchiveEntry28.getExternalAttributes();
        java.lang.Object obj30 = zipArchiveEntry28.clone();
        java.nio.file.attribute.FileTime fileTime31 = zipArchiveEntry28.getLastAccessTime();
        byte[] byteArray33 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        zipArchiveEntry28.setExtra(byteArray33);
        zipArchiveEntry15.setExtra(byteArray33);
        int int38 = zipArchiveInputStream9.read(byteArray33, (int) (short) 10, 0);
        unicodePathExtraField6.setUnicodeName(byteArray33);
        org.apache.commons.compress.archivers.zip.ZipLong zipLong40 = org.apache.commons.compress.archivers.zip.ZipLong.CFH_SIG;
        java.lang.Object obj41 = zipLong40.clone();
        byte[] byteArray42 = zipLong40.getBytes();
        org.apache.commons.compress.archivers.zip.ZipLong zipLong43 = org.apache.commons.compress.archivers.zip.ZipLong.CFH_SIG;
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker44 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort45 = jarMarker44.getLocalFileDataLength();
        boolean boolean46 = zipLong43.equals((java.lang.Object) jarMarker44);
        byte[] byteArray47 = jarMarker44.getCentralDirectoryData();
        boolean boolean48 = zipLong40.equals((java.lang.Object) jarMarker44);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort49 = jarMarker44.getCentralDirectoryLength();
        byte[] byteArray50 = jarMarker44.getLocalFileDataData();
        unicodePathExtraField6.setUnicodeName(byteArray50);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(jarMarker10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] {});
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) 0, (byte) -96, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28789L + "'", long27 == 28789L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertEquals(obj30.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj30), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj30), "");
        org.junit.Assert.assertNull(fileTime31);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(zipLong40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] { (byte) 80, (byte) 75, (byte) 1, (byte) 2 });
        org.junit.Assert.assertNotNull(zipLong43);
        org.junit.Assert.assertNotNull(zipShort45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertArrayEquals(byteArray47, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(zipShort49);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertArrayEquals(byteArray50, new byte[] {});
    }

    @Test
    public void test1197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1197");
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField0 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int1 = asiExtraField0.getGroupId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort2 = asiExtraField0.getCentralDirectoryLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort3 = asiExtraField0.getHeaderId();
        java.io.InputStream inputStream4 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream4);
        long long7 = zipArchiveInputStream5.skip((long) 'a');
        byte[] byteArray9 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray10 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray9);
        int int13 = zipArchiveInputStream5.read(byteArray9, (int) ' ', 40960);
        int int14 = zipArchiveInputStream5.read();
        int int15 = zipArchiveInputStream5.getCount();
        int int16 = zipArchiveInputStream5.getCount();
        byte[] byteArray17 = zipArchiveInputStream5.readAllBytes();
        // The following exception was thrown during execution in test generation
        try {
            asiExtraField0.parseFromCentralDirectoryData(byteArray17, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 2 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(zipShort2);
        org.junit.Assert.assertNotNull(zipShort3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray10);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray10, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
    }

    @Test
    public void test1198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1198");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        byte[] byteArray8 = zipArchiveInputStream1.readAllBytes();
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int13 = zipArchiveInputStream1.read(byteArray10, (-1), 100);
        zipArchiveInputStream1.mark(16419);
        boolean boolean16 = zipArchiveInputStream1.markSupported();
        long long18 = zipArchiveInputStream1.skip(5L);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream19 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry20 = zipArchiveInputStream19.getNextZipEntry();
        byte[] byteArray22 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) 65281);
        int int23 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray22);
        int int24 = zipArchiveInputStream19.read(byteArray22);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNull(zipArchiveEntry20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 1, (byte) -1, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 65281 + "'", int23 == 65281);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test1199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1199");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        zipArchiveEntry0.setCrc(10L);
        zipArchiveEntry0.setPlatform(4095);
        java.lang.String str8 = zipArchiveEntry0.getName();
        java.nio.file.attribute.FileTime fileTime9 = zipArchiveEntry0.getCreationTime();
        byte[] byteArray10 = zipArchiveEntry0.getExtra();
        zipArchiveEntry0.setComment("a\000");
        java.lang.String str13 = zipArchiveEntry0.getName();
        java.io.InputStream inputStream14 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream14);
        long long17 = zipArchiveInputStream15.skip((long) 'a');
        byte[] byteArray19 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray20 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray19);
        int int23 = zipArchiveInputStream15.read(byteArray19, (int) ' ', 40960);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray25 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray19, false);
        zipArchiveEntry0.setExtraFields(zipExtraFieldArray25);
        java.util.Date date27 = zipArchiveEntry0.getLastModifiedDate();
        zipArchiveEntry0.setUnixMode(32803);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNull(fileTime9);
        org.junit.Assert.assertNull(byteArray10);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray20);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray20, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(zipExtraFieldArray25);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray25, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertEquals(date27.toString(), "Wed Dec 31 15:59:59 PST 1969");
    }

    @Test
    public void test1200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1200");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry6 = zipArchiveInputStream1.getNextEntry();
        zipArchiveInputStream1.close();
        int int8 = zipArchiveInputStream1.available();
        int int9 = zipArchiveInputStream1.available();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry10 = zipArchiveInputStream1.getNextEntry();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(archiveEntry6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(archiveEntry10);
    }

    @Test
    public void test1201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1201");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.close();
        boolean boolean3 = zipArchiveInputStream1.markSupported();
        zipArchiveInputStream1.close();
        zipArchiveInputStream1.close();
        int int6 = zipArchiveInputStream1.available();
        boolean boolean7 = zipArchiveInputStream1.markSupported();
        boolean boolean8 = zipArchiveInputStream1.markSupported();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test1202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1202");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        zipArchiveInputStream6.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry8 = zipArchiveInputStream6.getNextEntry();
        int int9 = zipArchiveInputStream6.available();
        long long11 = zipArchiveInputStream6.skip((long) (short) 0);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream12 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(archiveEntry8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test1203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1203");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getLocalFileDataLength();
        byte[] byteArray8 = unicodeCommentExtraField5.getLocalFileDataData();
        byte[] byteArray9 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort10 = unicodeCommentExtraField5.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField11 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort10);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort10);
        org.junit.Assert.assertNotNull(zipExtraField11);
    }

    @Test
    public void test1204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1204");
        org.apache.commons.compress.archivers.zip.ZipLong zipLong1 = new org.apache.commons.compress.archivers.zip.ZipLong(1104745215L);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry2 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long3 = zipArchiveEntry2.getExternalAttributes();
        zipArchiveEntry2.setSize((long) 28789);
        boolean boolean6 = zipArchiveEntry2.isDirectory();
        zipArchiveEntry2.setSize(0L);
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray11 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray10);
        zipArchiveEntry2.setExtraFields(zipExtraFieldArray11);
        byte[] byteArray14 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        zipArchiveEntry2.setCentralDirectoryExtra(byteArray14);
        boolean boolean16 = zipLong1.equals((java.lang.Object) byteArray14);
        java.io.InputStream inputStream17 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream18 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream17);
        java.io.InputStream inputStream19 = java.io.InputStream.nullInputStream();
        byte[] byteArray21 = inputStream19.readNBytes((int) (short) 100);
        int int24 = zipArchiveInputStream18.read(byteArray21, (int) ' ', 40960);
        byte[] byteArray25 = zipArchiveInputStream18.readAllBytes();
        byte[] byteArray27 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int30 = zipArchiveInputStream18.read(byteArray27, (-1), 100);
        zipArchiveInputStream18.mark((int) (short) 1);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream33 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream18);
        boolean boolean34 = zipLong1.equals((java.lang.Object) zipArchiveInputStream33);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(inputStream19);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] {});
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test1205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1205");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry7 = zipArchiveInputStream6.getNextEntry();
        zipArchiveInputStream6.close();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry9 = zipArchiveInputStream6.getNextEntry();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(archiveEntry7);
        org.junit.Assert.assertNull(archiveEntry9);
    }

    @Test
    public void test1206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1206");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort8 = unicodeCommentExtraField5.getLocalFileDataLength();
        byte[] byteArray9 = unicodeCommentExtraField5.getLocalFileDataData();
        java.io.InputStream inputStream10 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream11 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream10);
        java.io.InputStream inputStream12 = java.io.InputStream.nullInputStream();
        byte[] byteArray14 = inputStream12.readNBytes((int) (short) 100);
        int int17 = zipArchiveInputStream11.read(byteArray14, (int) ' ', 40960);
        byte[] byteArray18 = zipArchiveInputStream11.readAllBytes();
        byte[] byteArray20 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(32768);
        int int23 = zipArchiveInputStream11.read(byteArray20, (-1), 100);
        zipArchiveInputStream11.mark(16419);
        boolean boolean26 = zipArchiveInputStream11.markSupported();
        byte[] byteArray28 = zipArchiveInputStream11.readNBytes(10);
        unicodeCommentExtraField5.setUnicodeName(byteArray28);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort30 = unicodeCommentExtraField5.getCentralDirectoryLength();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(zipShort8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(inputStream12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] {});
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] { (byte) 0, (byte) -128 });
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertArrayEquals(byteArray28, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort30);
    }

    @Test
    public void test1207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1207");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        byte[] byteArray7 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes((long) '4');
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray8 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray7);
        int int9 = zipArchiveInputStream1.read(byteArray7);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry10 = zipArchiveInputStream1.getNextZipEntry();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Stream closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) 52, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test1208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1208");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream5 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "UTF8", false);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream5);
        zipArchiveInputStream6.mark(32773);
        int int9 = zipArchiveInputStream6.read();
        byte[] byteArray10 = zipArchiveInputStream6.readAllBytes();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
    }

    @Test
    public void test1209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1209");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker0 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort1 = jarMarker0.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort2 = jarMarker0.getLocalFileDataLength();
        byte[] byteArray3 = jarMarker0.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort4 = jarMarker0.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort5 = jarMarker0.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort6 = jarMarker0.getCentralDirectoryLength();
        byte[] byteArray9 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean11 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray9, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField12 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray9);
        byte[] byteArray13 = unicodeCommentExtraField12.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort14 = unicodeCommentExtraField12.getLocalFileDataLength();
        byte[] byteArray20 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField21 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray20);
        boolean boolean22 = zipShort14.equals((java.lang.Object) unicodePathExtraField21);
        long long23 = unicodePathExtraField21.getNameCRC32();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort24 = unicodePathExtraField21.getLocalFileDataLength();
        byte[] byteArray25 = unicodePathExtraField21.getLocalFileDataData();
        jarMarker0.parseFromCentralDirectoryData(byteArray25, 51966, 0);
        byte[] byteArray29 = jarMarker0.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort30 = jarMarker0.getCentralDirectoryLength();
        org.junit.Assert.assertNotNull(zipShort1);
        org.junit.Assert.assertNotNull(zipShort2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertArrayEquals(byteArray3, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort4);
        org.junit.Assert.assertNotNull(zipShort5);
        org.junit.Assert.assertNotNull(zipShort6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort14);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 4035808147L + "'", long23 == 4035808147L);
        org.junit.Assert.assertNotNull(zipShort24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertArrayEquals(byteArray29, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort30);
    }

    @Test
    public void test1210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1210");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort7 = unicodeCommentExtraField5.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort8 = unicodeCommentExtraField5.getHeaderId();
        org.apache.commons.compress.archivers.zip.ZipExtraField zipExtraField9 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.createExtraField(zipShort8);
        int int10 = zipShort8.getValue();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort7);
        org.junit.Assert.assertNotNull(zipShort8);
        org.junit.Assert.assertNotNull(zipExtraField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25461 + "'", int10 == 25461);
    }

    @Test
    public void test1211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1211");
        byte[] byteArray2 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean4 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray2, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField5 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray2);
        byte[] byteArray6 = unicodeCommentExtraField5.getCentralDirectoryData();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipShort zipShort8 = new org.apache.commons.compress.archivers.zip.ZipShort(byteArray6, 64440);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 64441 out of bounds for length 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
    }

    @Test
    public void test1212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1212");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding0 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean2 = fallbackZipEncoding0.canEncode("");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry3 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime4 = zipArchiveEntry3.getCreationTime();
        long long5 = zipArchiveEntry3.getSize();
        byte[] byteArray6 = zipArchiveEntry3.getExtra();
        org.apache.commons.compress.archivers.zip.AsiExtraField asiExtraField7 = new org.apache.commons.compress.archivers.zip.AsiExtraField();
        int int9 = asiExtraField7.getMode(100);
        boolean boolean10 = asiExtraField7.isDirectory();
        zipArchiveEntry3.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) asiExtraField7);
        byte[] byteArray12 = asiExtraField7.getCentralDirectoryData();
        int int14 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray12, 3);
        int int15 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray12);
        java.lang.String str16 = fallbackZipEncoding0.decode(byteArray12);
        java.io.InputStream inputStream17 = java.io.InputStream.nullInputStream();
        byte[] byteArray19 = inputStream17.readNBytes((int) (short) 100);
        java.lang.String str20 = fallbackZipEncoding0.decode(byteArray19);
        java.io.InputStream inputStream21 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream22 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream21);
        java.io.InputStream inputStream23 = java.io.InputStream.nullInputStream();
        byte[] byteArray25 = inputStream23.readNBytes((int) (short) 100);
        int int28 = zipArchiveInputStream22.read(byteArray25, (int) ' ', 40960);
        java.lang.String str29 = fallbackZipEncoding0.decode(byteArray25);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray31 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray25, true);
        byte[] byteArray32 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.mergeLocalFileDataData(zipExtraFieldArray31);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray34 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray32, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(fileTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32868 + "'", int9 == 32868);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 118, (byte) 104, (byte) -118, (byte) -29, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 227 + "'", int14 == 227);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 26742 + "'", int15 == 26742);
// flaky "11) test1212(org.apache.commons.compress.archivers.zip.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000" + "'", str16, "\ufffd\ufffd\000\000\000\000\000\000\000\000\000\000");
        org.junit.Assert.assertNotNull(inputStream17);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] {});
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertNotNull(inputStream23);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertNotNull(zipExtraFieldArray31);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray31, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertNotNull(zipExtraFieldArray34);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray34, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
    }

    @Test
    public void test1213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1213");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        long long8 = zipArchiveInputStream6.skip((long) 65281);
        byte[] byteArray10 = zipArchiveInputStream6.readNBytes(32868);
        byte[] byteArray13 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) (byte) 100);
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField14 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("\000\ufffd", byteArray13);
        int int17 = zipArchiveInputStream6.read(byteArray13, 28789, 32803);
        int int18 = zipArchiveInputStream6.available();
        zipArchiveInputStream6.mark(100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream21 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveInputStream21.reset();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: mark/reset not supported");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 100, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test1214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1214");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        long long9 = zipArchiveInputStream1.skip((long) 28789);
        boolean boolean10 = zipArchiveInputStream1.markSupported();
        int int11 = zipArchiveInputStream1.available();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.ArchiveEntry archiveEntry12 = zipArchiveInputStream1.getNextEntry();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Stream closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test1215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1215");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        java.lang.String str6 = zipArchiveEntry0.getName();
        java.lang.String str7 = zipArchiveEntry0.getName();
        zipArchiveEntry0.setComment("UTF8");
        byte[] byteArray12 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        boolean boolean14 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray12, 4095);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField15 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("", byteArray12);
        byte[] byteArray16 = unicodeCommentExtraField15.getCentralDirectoryData();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort17 = unicodeCommentExtraField15.getHeaderId();
        int int18 = zipShort17.getValue();
        byte[] byteArray24 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField25 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray24);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort26 = unicodePathExtraField25.getHeaderId();
        byte[] byteArray27 = unicodePathExtraField25.getCentralDirectoryData();
        boolean boolean28 = zipShort17.equals((java.lang.Object) unicodePathExtraField25);
        // The following exception was thrown during execution in test generation
        try {
            zipArchiveEntry0.removeExtraField(zipShort17);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] { (byte) 1, (byte) -1, (byte) 18, (byte) -39, (byte) 65 });
        org.junit.Assert.assertNotNull(zipShort17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 25461 + "'", int18 == 25461);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertNotNull(zipShort26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] { (byte) 1, (byte) -109, (byte) -117, (byte) -115, (byte) -16 });
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test1216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1216");
        org.apache.commons.compress.archivers.zip.FallbackZipEncoding fallbackZipEncoding0 = new org.apache.commons.compress.archivers.zip.FallbackZipEncoding();
        boolean boolean2 = fallbackZipEncoding0.canEncode("hi!");
        boolean boolean4 = fallbackZipEncoding0.canEncode("hi!");
        boolean boolean6 = fallbackZipEncoding0.canEncode("UTF8");
        boolean boolean8 = fallbackZipEncoding0.canEncode("\000\ufffd");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry9 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long10 = zipArchiveEntry9.getExternalAttributes();
        zipArchiveEntry9.setSize((long) 28789);
        zipArchiveEntry9.setCrc(10L);
        zipArchiveEntry9.setPlatform(4095);
        byte[] byteArray17 = zipArchiveEntry9.getCentralDirectoryExtra();
        boolean boolean19 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray17, (int) (byte) 0);
        java.lang.String str20 = fallbackZipEncoding0.decode(byteArray17);
        java.nio.ByteBuffer byteBuffer22 = fallbackZipEncoding0.encode("a\000");
        byte[] byteArray24 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes((int) (short) 1);
        java.lang.String str25 = fallbackZipEncoding0.decode(byteArray24);
        // The following exception was thrown during execution in test generation
        try {
            long long27 = org.apache.commons.compress.archivers.zip.ZipLong.getValue(byteArray24, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 13 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertNotNull(byteBuffer22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] { (byte) 1, (byte) 0 });
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "\001\000" + "'", str25, "\001\000");
    }

    @Test
    public void test1217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1217");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        long long3 = zipArchiveInputStream1.skip((long) 'a');
        long long5 = zipArchiveInputStream1.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        byte[] byteArray8 = zipArchiveInputStream6.readNBytes((int) (byte) 100);
        zipArchiveInputStream6.close();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream10 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
    }

    @Test
    public void test1218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1218");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        byte[] byteArray2 = inputStream0.readNBytes((int) (short) 100);
        boolean boolean3 = inputStream0.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream6 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0, "UTF8", true);
        long long8 = zipArchiveInputStream6.skip((long) 65281);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry9 = zipArchiveInputStream6.getNextEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream10 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream6);
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNull(archiveEntry9);
    }

    @Test
    public void test1219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1219");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        byte[] byteArray2 = new byte[] {};
        int int5 = zipArchiveInputStream1.read(byteArray2, 420, 1);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry6 = zipArchiveInputStream1.getNextEntry();
        int int7 = zipArchiveInputStream1.read();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1);
        byte[] byteArray10 = org.apache.commons.compress.archivers.zip.ZipLong.getBytes(32L);
        int int13 = zipArchiveInputStream1.read(byteArray10, 32995, 51966);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipLong zipLong15 = new org.apache.commons.compress.archivers.zip.ZipLong(byteArray10, 32885);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 32888 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(archiveEntry6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 32, (byte) 0, (byte) 0, (byte) 0 });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test1220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1220");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        zipArchiveEntry0.setSize((long) 28789);
        byte[] byteArray4 = zipArchiveEntry0.getExtra();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry5 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry0);
        zipArchiveEntry5.setCrc(33639248L);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry8 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long9 = zipArchiveEntry8.getExternalAttributes();
        java.io.InputStream inputStream10 = java.io.InputStream.nullInputStream();
        byte[] byteArray12 = inputStream10.readNBytes((int) (short) 100);
        zipArchiveEntry8.setCentralDirectoryExtra(byteArray12);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry14 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry8);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry14);
        java.util.Date date16 = zipArchiveEntry14.getLastModifiedDate();
        zipArchiveEntry14.setUnixMode(0);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker19 = new org.apache.commons.compress.archivers.zip.JarMarker();
        zipArchiveEntry14.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker19);
        org.apache.commons.compress.archivers.zip.ZipShort zipShort21 = jarMarker19.getCentralDirectoryLength();
        java.io.InputStream inputStream22 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream23 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream22);
        byte[] byteArray25 = zipArchiveInputStream23.readNBytes(8);
        jarMarker19.parseFromCentralDirectoryData(byteArray25, 10, 0);
        java.io.InputStream inputStream29 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream30 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream29);
        byte[] byteArray32 = zipArchiveInputStream30.readNBytes(8);
        org.apache.commons.compress.archivers.zip.ZipUtil.setNameAndCommentFromExtraFields(zipArchiveEntry5, byteArray25, byteArray32);
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker34 = new org.apache.commons.compress.archivers.zip.JarMarker();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort35 = jarMarker34.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort36 = jarMarker34.getLocalFileDataLength();
        org.apache.commons.compress.archivers.zip.ZipShort zipShort37 = jarMarker34.getCentralDirectoryLength();
        zipArchiveEntry5.addExtraField((org.apache.commons.compress.archivers.zip.ZipExtraField) jarMarker34);
        zipArchiveEntry5.setCompressedSize(312796802981L);
        zipArchiveEntry5.setExtra();
        java.lang.String str42 = zipArchiveEntry5.getName();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry43 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long44 = zipArchiveEntry43.getExternalAttributes();
        zipArchiveEntry43.setSize((long) 28789);
        boolean boolean47 = zipArchiveEntry43.isDirectory();
        java.lang.Object obj48 = zipArchiveEntry43.clone();
        java.lang.String str49 = zipArchiveEntry43.getComment();
        byte[] byteArray50 = zipArchiveEntry43.getCentralDirectoryExtra();
        java.lang.String str51 = zipArchiveEntry43.getName();
        boolean boolean52 = zipArchiveEntry43.isDirectory();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry53 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long54 = zipArchiveEntry53.getExternalAttributes();
        zipArchiveEntry53.setSize((long) 28789);
        zipArchiveEntry53.setCrc(10L);
        zipArchiveEntry53.setPlatform(4095);
        boolean boolean61 = zipArchiveEntry53.isDirectory();
        zipArchiveEntry53.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry64 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry53);
        byte[] byteArray65 = zipArchiveEntry53.getLocalFileDataExtra();
        long long66 = zipArchiveEntry53.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry67 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry53);
        java.io.InputStream inputStream68 = java.io.InputStream.nullInputStream();
        byte[] byteArray70 = inputStream68.readNBytes((int) (short) 100);
        boolean boolean71 = inputStream68.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream74 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream68, "UTF8", true);
        zipArchiveInputStream74.close();
        boolean boolean76 = zipArchiveEntry67.equals((java.lang.Object) zipArchiveInputStream74);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry77 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime78 = zipArchiveEntry77.getCreationTime();
        byte[] byteArray80 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray81 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray80);
        zipArchiveEntry77.setExtraFields(zipExtraFieldArray81);
        zipArchiveEntry77.setTime((long) 32868);
        int int85 = zipArchiveEntry77.getPlatform();
        zipArchiveEntry77.setMethod(0);
        java.nio.file.attribute.FileTime fileTime88 = zipArchiveEntry77.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry89 = zipArchiveEntry67.setLastAccessTime(fileTime88);
        java.util.zip.ZipEntry zipEntry90 = zipArchiveEntry43.setLastModifiedTime(fileTime88);
        java.util.zip.ZipEntry zipEntry91 = zipArchiveEntry5.setLastModifiedTime(fileTime88);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNull(byteArray4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(inputStream10);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] {});
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertEquals(date16.toString(), "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(zipShort21);
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertNotNull(inputStream29);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertNotNull(zipShort35);
        org.junit.Assert.assertNotNull(zipShort36);
        org.junit.Assert.assertNotNull(zipShort37);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertEquals(obj48.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj48), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj48), "");
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertArrayEquals(byteArray50, new byte[] {});
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(byteArray65);
        org.junit.Assert.assertArrayEquals(byteArray65, new byte[] {});
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 5L + "'", long66 == 5L);
        org.junit.Assert.assertNotNull(inputStream68);
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertArrayEquals(byteArray70, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(fileTime78);
        org.junit.Assert.assertNotNull(byteArray80);
        org.junit.Assert.assertArrayEquals(byteArray80, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray81);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray81, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(fileTime88);
        org.junit.Assert.assertNotNull(zipEntry89);
        org.junit.Assert.assertEquals(zipEntry89.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry90);
        org.junit.Assert.assertEquals(zipEntry90.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry91);
        org.junit.Assert.assertEquals(zipEntry91.toString(), "");
    }

    @Test
    public void test1221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1221");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry2 = zipArchiveInputStream1.getNextEntry();
        long long4 = zipArchiveInputStream1.skip((long) (byte) 0);
        zipArchiveInputStream1.close();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream8 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) zipArchiveInputStream1, "a\000", true);
            org.junit.Assert.fail("Expected exception of type java.nio.charset.IllegalCharsetNameException; message: a?");
        } catch (java.nio.charset.IllegalCharsetNameException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNull(archiveEntry2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test1222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1222");
        org.apache.commons.compress.archivers.zip.JarMarker jarMarker0 = new org.apache.commons.compress.archivers.zip.JarMarker();
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 };
        org.apache.commons.compress.archivers.zip.UnicodePathExtraField unicodePathExtraField7 = new org.apache.commons.compress.archivers.zip.UnicodePathExtraField("", byteArray6);
        int int8 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray6);
        jarMarker0.parseFromLocalFileData(byteArray6, 511, 0);
        boolean boolean13 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray6, (int) '#');
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipLong zipLong15 = new org.apache.commons.compress.archivers.zip.ZipLong(byteArray6, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 103 out of bounds for length 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 65281 + "'", int8 == 65281);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test1223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1223");
        java.io.InputStream inputStream1 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream2 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream1);
        byte[] byteArray3 = new byte[] {};
        int int6 = zipArchiveInputStream2.read(byteArray3, 420, 1);
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField7 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("UTF8", byteArray3);
        org.apache.commons.compress.archivers.zip.ZipLong zipLong9 = org.apache.commons.compress.archivers.zip.ZipLong.LFH_SIG;
        org.apache.commons.compress.archivers.zip.ZipShort zipShort11 = new org.apache.commons.compress.archivers.zip.ZipShort((int) (byte) 1);
        boolean boolean12 = zipLong9.equals((java.lang.Object) (byte) 1);
        byte[] byteArray13 = zipLong9.getBytes();
        org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField unicodeCommentExtraField14 = new org.apache.commons.compress.archivers.zip.UnicodeCommentExtraField("hi!", byteArray13);
        org.apache.commons.compress.archivers.zip.ZipLong zipLong16 = new org.apache.commons.compress.archivers.zip.ZipLong(byteArray13, 0);
        byte[] byteArray17 = zipLong16.getBytes();
        int int18 = org.apache.commons.compress.archivers.zip.ZipShort.getValue(byteArray17);
        unicodeCommentExtraField7.setUnicodeName(byteArray17);
        long long20 = unicodeCommentExtraField7.getNameCRC32();
        org.junit.Assert.assertNotNull(inputStream1);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertArrayEquals(byteArray3, new byte[] {});
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(zipLong9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 80, (byte) 75, (byte) 3, (byte) 4 });
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 80, (byte) 75, (byte) 3, (byte) 4 });
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19280 + "'", int18 == 19280);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test1224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1224");
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        zipArchiveInputStream1.close();
        boolean boolean3 = zipArchiveInputStream1.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry4 = zipArchiveInputStream1.getNextZipEntry();
        // The following exception was thrown during execution in test generation
        try {
            int int5 = zipArchiveInputStream1.read();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: The stream is closed");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(zipArchiveEntry4);
    }

    @Test
    public void test1225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1225");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream1 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream0);
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        int int7 = zipArchiveInputStream1.read(byteArray4, (int) ' ', 40960);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.compress.archivers.zip.ZipShort zipShort9 = new org.apache.commons.compress.archivers.zip.ZipShort(byteArray4, 16419);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 16420 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test1226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1226");
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry0 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long1 = zipArchiveEntry0.getExternalAttributes();
        java.io.InputStream inputStream2 = java.io.InputStream.nullInputStream();
        byte[] byteArray4 = inputStream2.readNBytes((int) (short) 100);
        zipArchiveEntry0.setCentralDirectoryExtra(byteArray4);
        int int6 = zipArchiveEntry0.getMethod();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry7 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry((java.util.zip.ZipEntry) zipArchiveEntry0);
        zipArchiveEntry7.setCompressedSize(227L);
        zipArchiveEntry7.setPlatform((int) (short) 1);
        int int12 = zipArchiveEntry7.getInternalAttributes();
        java.lang.String str13 = zipArchiveEntry7.getComment();
        long long14 = zipArchiveEntry7.getTime();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry15 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        long long16 = zipArchiveEntry15.getExternalAttributes();
        zipArchiveEntry15.setSize((long) 28789);
        zipArchiveEntry15.setCrc(10L);
        zipArchiveEntry15.setPlatform(4095);
        boolean boolean23 = zipArchiveEntry15.isDirectory();
        zipArchiveEntry15.setSize((long) 5);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry26 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry15);
        byte[] byteArray27 = zipArchiveEntry15.getLocalFileDataExtra();
        long long28 = zipArchiveEntry15.getSize();
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry29 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry(zipArchiveEntry15);
        java.io.InputStream inputStream30 = java.io.InputStream.nullInputStream();
        byte[] byteArray32 = inputStream30.readNBytes((int) (short) 100);
        boolean boolean33 = inputStream30.markSupported();
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream36 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream(inputStream30, "UTF8", true);
        zipArchiveInputStream36.close();
        boolean boolean38 = zipArchiveEntry29.equals((java.lang.Object) zipArchiveInputStream36);
        org.apache.commons.compress.archivers.zip.ZipArchiveEntry zipArchiveEntry39 = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry();
        java.nio.file.attribute.FileTime fileTime40 = zipArchiveEntry39.getCreationTime();
        byte[] byteArray42 = org.apache.commons.compress.archivers.zip.ZipShort.getBytes(0);
        org.apache.commons.compress.archivers.zip.ZipExtraField[] zipExtraFieldArray43 = org.apache.commons.compress.archivers.zip.ExtraFieldUtils.parse(byteArray42);
        zipArchiveEntry39.setExtraFields(zipExtraFieldArray43);
        zipArchiveEntry39.setTime((long) 32868);
        int int47 = zipArchiveEntry39.getPlatform();
        zipArchiveEntry39.setMethod(0);
        java.nio.file.attribute.FileTime fileTime50 = zipArchiveEntry39.getLastModifiedTime();
        java.util.zip.ZipEntry zipEntry51 = zipArchiveEntry29.setLastAccessTime(fileTime50);
        java.util.zip.ZipEntry zipEntry52 = zipArchiveEntry7.setLastAccessTime(fileTime50);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(inputStream2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertArrayEquals(byteArray4, new byte[] {});
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] {});
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 5L + "'", long28 == 5L);
        org.junit.Assert.assertNotNull(inputStream30);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(fileTime40);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(zipExtraFieldArray43);
        org.junit.Assert.assertArrayEquals(zipExtraFieldArray43, new org.apache.commons.compress.archivers.zip.ZipExtraField[] {});
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(fileTime50);
        org.junit.Assert.assertNotNull(zipEntry51);
        org.junit.Assert.assertEquals(zipEntry51.toString(), "");
        org.junit.Assert.assertNotNull(zipEntry52);
        org.junit.Assert.assertEquals(zipEntry52.toString(), "");
    }
}
