package org.apache.commons.compress.archivers.zip;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ RegressionTest0.class, RegressionTest1.class, RegressionTest2.class })
public class RegressionTest {
}

