package org.apache.commons.math3.distribution;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.String str2 = randomDataGenerator0.nextSecureHexString((int) '4');
        randomDataGenerator0.reSeedSecure();
        double double6 = randomDataGenerator0.nextBeta((double) 1350221770, 10.0d);
        int int9 = randomDataGenerator0.nextSecureInt((int) (short) 10, (int) (short) 100);
        // The following exception was thrown during execution in test generation
        try {
            int int13 = randomDataGenerator0.nextHypergeometric(1, (-127), 66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-127)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "1) test001(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str2 + "' != '" + "f10fd396a0cfe3b9cee0b4c850b8e0baf39ecb3ccabf30220b3d" + "'", str2, "f10fd396a0cfe3b9cee0b4c850b8e0baf39ecb3ccabf30220b3d");
// flaky "1) test001(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.999999991766099d + "'", double6 == 0.999999991766099d);
// flaky "1) test001(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int9 + "' != '" + 30 + "'", int9 == 30);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution11 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (int) (short) 1, (int) '#', 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (35) must be less than or equal to population size (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        // The following exception was thrown during execution in test generation
        try {
            double double23 = hypergeometricDistribution20.cumulativeProbability(1350221770, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1,350,221,770) must be less than or equal to upper endpoint (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl14.reSeedSecure((-1L));
        // The following exception was thrown during execution in test generation
        try {
            int int20 = randomDataImpl14.nextHypergeometric((-1), (int) ' ', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        // The following exception was thrown during execution in test generation
        try {
            int int22 = hypergeometricDistribution20.inverseCumulativeProbability(38.97254737005956d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 38.973 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 1, (-43), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-43)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        // The following exception was thrown during execution in test generation
        try {
            int int27 = hypergeometricDistribution20.inverseCumulativeProbability((double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 100 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        double double26 = hypergeometricDistribution20.getNumericalVariance();
        // The following exception was thrown during execution in test generation
        try {
            int int28 = hypergeometricDistribution20.inverseCumulativeProbability((double) 33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 33 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution4 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c0, (int) (short) -1, (int) ' ', 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.String str2 = randomDataGenerator0.nextSecureHexString((int) '4');
        double double4 = randomDataGenerator0.nextChiSquare(2.718281828459045d);
        // The following exception was thrown during execution in test generation
        try {
            int int8 = randomDataGenerator0.nextHypergeometric(18, 100, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (100) must be less than or equal to population size (18)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "2) test010(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str2 + "' != '" + "668f60148dbbab1092270f28581fc2a4ca41a2ee87a19825115a" + "'", str2, "668f60148dbbab1092270f28581fc2a4ca41a2ee87a19825115a");
// flaky "2) test010(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.8705760065699244d + "'", double4 == 3.8705760065699244d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        // The following exception was thrown during execution in test generation
        try {
            int int24 = hypergeometricDistribution20.inverseCumulativeProbability((-0.4671086505232536d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -0.467 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray22 = hypergeometricDistribution20.sample((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int28 = hypergeometricDistribution20.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        double double29 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-42) + "'", int28 == (-42));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 27.876288659793815d + "'", double29 == 27.876288659793815d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int[] intArray23 = hypergeometricDistribution20.sample(35);
        // The following exception was thrown during execution in test generation
        try {
            int int25 = hypergeometricDistribution20.inverseCumulativeProbability((double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.random.RandomGenerator randomGenerator0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution4 = new org.apache.commons.math3.distribution.HypergeometricDistribution(randomGenerator0, 66, (-42), (-43));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-42)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        // The following exception was thrown during execution in test generation
        try {
            double double51 = randomDataImpl14.nextCauchy(6.062015091933255d, (-0.1973790993092482d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0.197)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "3) test016(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 77L + "'", long17 == 77L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double33 = randomDataGenerator31.nextT(14.82903486167303d);
        // The following exception was thrown during execution in test generation
        try {
            int int36 = randomDataGenerator31.nextBinomial(4, (-0.9999999999999999d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -1 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-0.6893451132187746d) + "'", double33 == (-0.6893451132187746d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray25 = hypergeometricDistribution20.sample((-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (-1,023)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(109576327, 1187994814, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (1,187,994,814) must be less than or equal to population size (109,576,327)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int[] intArray23 = hypergeometricDistribution20.sample(35);
        int int24 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        double double31 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2506256061061618d + "'", double31 == 0.2506256061061618d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray28 = hypergeometricDistribution20.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray28 = hypergeometricDistribution20.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl14.reSeed();
        randomDataImpl14.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            int int20 = randomDataImpl14.nextHypergeometric((-43), 35, 58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-43)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int28 = hypergeometricDistribution20.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int32 = hypergeometricDistribution20.solveInverseCumulativeProbability(0.9999999969663829d, (int) (byte) 100, (-42));
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-42) + "'", int28 == (-42));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-42) + "'", int32 == (-42));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c1.setSeed((long) (byte) 100);
        boolean boolean4 = well19937c1.nextBoolean();
        double double5 = well19937c1.nextDouble();
        int[] intArray6 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c7 = new org.apache.commons.math3.random.Well19937c(intArray6);
        int[] intArray12 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c7.setSeed(intArray12);
        byte[] byteArray18 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c7.nextBytes(byteArray18);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c7);
        long long22 = well19937c7.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution26 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c7, 97, 52, (int) '4');
        int[] intArray28 = hypergeometricDistribution26.sample(66);
        double double30 = hypergeometricDistribution26.probability((-1));
        int int31 = hypergeometricDistribution26.sample();
        int[] intArray33 = hypergeometricDistribution26.sample(35);
        well19937c1.setSeed(intArray33);
        // The following exception was thrown during execution in test generation
        try {
            int int36 = well19937c1.nextInt((-42));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -42 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.04677838737026563d + "'", double5 == 0.04677838737026563d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] {});
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertArrayEquals(intArray12, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 30 + "'", int31 == 30);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int int49 = hypergeometricDistribution40.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "4) test027(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 65L + "'", long17 == 65L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 30 + "'", int49 == 30);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        boolean boolean28 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl29 = hypergeometricDistribution20.randomData;
        // The following exception was thrown during execution in test generation
        try {
            int int32 = randomDataImpl29.nextInt(26, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (26) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(randomDataImpl29);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        // The following exception was thrown during execution in test generation
        try {
            double double30 = hypergeometricDistribution20.cumulativeProbability(2147483647, 33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (2,147,483,647) must be less than or equal to upper endpoint (33)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int int25 = hypergeometricDistribution20.inverseCumulativeProbability(0.4484753762842155d);
        // The following exception was thrown during execution in test generation
        try {
            int int27 = hypergeometricDistribution20.inverseCumulativeProbability((double) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 2,147,483,647 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 28 + "'", int25 == 28);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        double double30 = randomDataImpl27.nextGamma((double) 20L, 8.28208162640566d);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str32 = randomDataImpl27.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
// flaky "5) test031(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double30 + "' != '" + 159.79362824978827d + "'", double30 == 159.79362824978827d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        // The following exception was thrown during execution in test generation
        try {
            double double29 = hypergeometricDistribution20.cumulativeProbability((int) '#', 27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (35) must be less than or equal to upper endpoint (27)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl14.setSecureAlgorithm("8eac2757863b40b5d9773a377635968dea8f1c9fe1100c3b505f", "4e7a4f6a71e3a5c9ed387245096207c20daf08bbba5c421caa7c");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 4e7a4f6a71e3a5c9ed387245096207c20daf08bbba5c421caa7c");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "6) test033(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 63L + "'", long17 == 63L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.upperCumulativeProbability(1273120795);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray81 = randomDataImpl14.nextPermutation(0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "7) test035(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 21L + "'", long17 == 21L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl14.reSeedSecure(2L);
        java.lang.String str18 = randomDataImpl14.nextHexString((int) (byte) 100);
        int[] intArray19 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c20 = new org.apache.commons.math3.random.Well19937c(intArray19);
        int[] intArray25 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c20.setSeed(intArray25);
        byte[] byteArray31 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c20.nextBytes(byteArray31);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl33 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c20);
        long long36 = randomDataImpl33.nextSecureLong((long) 0, (long) (short) 100);
        long long38 = randomDataImpl33.nextPoisson((double) 51L);
        int[] intArray39 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c40 = new org.apache.commons.math3.random.Well19937c(intArray39);
        int[] intArray45 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c40.setSeed(intArray45);
        byte[] byteArray51 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c40.nextBytes(byteArray51);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl53 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c40);
        long long55 = well19937c40.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution59 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c40, 97, 52, (int) '4');
        int[] intArray61 = hypergeometricDistribution59.sample(66);
        double double63 = hypergeometricDistribution59.probability((-1));
        double double66 = hypergeometricDistribution59.cumulativeProbability(0, 97);
        int int67 = randomDataImpl33.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution59);
        int[] intArray68 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c69 = new org.apache.commons.math3.random.Well19937c(intArray68);
        int[] intArray74 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c69.setSeed(intArray74);
        byte[] byteArray80 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c69.nextBytes(byteArray80);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl82 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c69);
        long long84 = well19937c69.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution88 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c69, 97, 52, (int) '4');
        int[] intArray90 = hypergeometricDistribution88.sample(66);
        double double92 = hypergeometricDistribution88.probability((-1));
        int int96 = hypergeometricDistribution88.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int97 = randomDataImpl33.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution88);
        int int98 = hypergeometricDistribution88.sample();
        int int99 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution88);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "5841b993ad922732779ed9524b1035cac792a394ae5a295d86346e9eb6910aafdc72386e58d7489296bda8b49275f1488d38" + "'", str18, "5841b993ad922732779ed9524b1035cac792a394ae5a295d86346e9eb6910aafdc72386e58d7489296bda8b49275f1488d38");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertArrayEquals(intArray19, new int[] {});
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "8) test036(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long36 + "' != '" + 78L + "'", long36 == 78L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 59L + "'", long38 == 59L);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertArrayEquals(intArray39, new int[] {});
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertArrayEquals(intArray45, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray51);
        org.junit.Assert.assertArrayEquals(byteArray51, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 27 + "'", int67 == 27);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertArrayEquals(intArray68, new int[] {});
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertArrayEquals(intArray74, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray80);
        org.junit.Assert.assertArrayEquals(byteArray80, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1L + "'", long84 == 1L);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + (-42) + "'", int96 == (-42));
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 29 + "'", int97 == 29);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 30 + "'", int98 == 30);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 28 + "'", int99 == 28);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            double double34 = randomDataGenerator31.nextGamma(0.0d, 0.11170958385601967d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double50 = randomDataImpl14.nextExponential(59.0d);
        int int53 = randomDataImpl14.nextSecureInt(6, 1350221770);
        // The following exception was thrown during execution in test generation
        try {
            double double56 = randomDataImpl14.nextGamma((double) 68L, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "9) test038(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 25L + "'", long17 == 25L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 14.82903486167303d + "'", double50 == 14.82903486167303d);
// flaky "3) test038(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int53 + "' != '" + 554383922 + "'", int53 == 554383922);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (byte) 0);
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeed();
        double double6 = randomDataGenerator0.nextChiSquare(0.08106146679532726d);
        int int9 = randomDataGenerator0.nextInt((int) (byte) 0, 1);
        // The following exception was thrown during execution in test generation
        try {
            int int13 = randomDataGenerator0.nextHypergeometric((int) 'a', 1187994814, 1019069405);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (1,187,994,814) must be less than or equal to population size (97)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "10) test039(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
// flaky "1) test039(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        boolean boolean80 = hypergeometricDistribution69.isSupportConnected();
        // The following exception was thrown during execution in test generation
        try {
            int int82 = hypergeometricDistribution69.inverseCumulativeProbability(88.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 88 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "11) test041(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(0, (int) (byte) 10, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability((int) (short) 0);
        int int29 = hypergeometricDistribution20.solveInverseCumulativeProbability(3.322672978862459E20d, 28, (int) (byte) 1);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((int) '#', (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (52) must be less than or equal to population size (35)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double22 = randomDataImpl14.nextBeta((double) 97, 1.7167355775177289d);
        randomDataImpl14.reSeedSecure((long) (short) 10);
        long long27 = randomDataImpl14.nextSecureLong((long) (-127), (long) 33);
        double double30 = randomDataImpl14.nextGamma(84.29631315677912d, (double) 51L);
        int[] intArray31 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c32 = new org.apache.commons.math3.random.Well19937c(intArray31);
        int[] intArray37 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c32.setSeed(intArray37);
        byte[] byteArray43 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c32.nextBytes(byteArray43);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c32);
        long long48 = randomDataImpl45.nextSecureLong((long) 0, (long) (short) 100);
        long long50 = randomDataImpl45.nextPoisson((double) 51L);
        int[] intArray51 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c52 = new org.apache.commons.math3.random.Well19937c(intArray51);
        int[] intArray57 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c52.setSeed(intArray57);
        byte[] byteArray63 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c52.nextBytes(byteArray63);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c52);
        long long67 = well19937c52.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution71 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c52, 97, 52, (int) '4');
        int[] intArray73 = hypergeometricDistribution71.sample(66);
        double double75 = hypergeometricDistribution71.probability((-1));
        double double78 = hypergeometricDistribution71.cumulativeProbability(0, 97);
        int int79 = randomDataImpl45.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int80 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        hypergeometricDistribution71.reseedRandomGenerator(0L);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "12) test045(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 74L + "'", long17 == 74L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9838194766581275d + "'", double22 == 0.9838194766581275d);
// flaky "4) test045(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-34L) + "'", long27 == (-34L));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3401.6932281888926d + "'", double30 == 3401.6932281888926d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertArrayEquals(intArray31, new int[] {});
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertArrayEquals(intArray37, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "2) test045(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long48 + "' != '" + 42L + "'", long48 == 42L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 59L + "'", long50 == 59L);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertArrayEquals(intArray51, new int[] {});
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertArrayEquals(intArray57, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1L + "'", long67 == 1L);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 27 + "'", int79 == 27);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 29 + "'", int80 == 29);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl22 = hypergeometricDistribution20.randomData;
        double double23 = hypergeometricDistribution20.calculateNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 6.062015091933255d + "'", double23 == 6.062015091933255d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        int int28 = hypergeometricDistribution20.getNumberOfSuccesses();
        int int29 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((int) (byte) 1, (-43), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-43)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.cumulativeProbability((-1), (int) '#');
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl32 = hypergeometricDistribution20.randomData;
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.9991379129498539d + "'", double31 == 0.9991379129498539d);
        org.junit.Assert.assertNotNull(randomDataImpl32);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.getSampleSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        // The following exception was thrown during execution in test generation
        try {
            double double30 = randomDataImpl27.nextUniform(2.6881171418161356E43d, (double) 75L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000) must be strictly less than upper bound (75)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataGenerator31.reSeedSecure();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        float float31 = well19937c1.nextFloat();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.2506255f + "'", float31 == 0.2506255f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        boolean boolean28 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl29 = hypergeometricDistribution20.randomData;
        hypergeometricDistribution20.reseedRandomGenerator(100L);
        boolean boolean32 = hypergeometricDistribution20.isSupportConnected();
        double double33 = hypergeometricDistribution20.calculateNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(randomDataImpl29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 6.062015091933255d + "'", double33 == 6.062015091933255d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double33 = randomDataGenerator31.nextT(14.82903486167303d);
        double double35 = randomDataGenerator31.nextExponential(97.00161479327137d);
        // The following exception was thrown during execution in test generation
        try {
            int int38 = randomDataGenerator31.nextInt(1034899390, 109576327);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,034,899,390) must be strictly less than upper bound (109,576,327)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-0.6893451132187746d) + "'", double33 == (-0.6893451132187746d));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 28.233648676717284d + "'", double35 == 28.233648676717284d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.cumulativeProbability((-1), (int) '#');
        int int32 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.9991379129498539d + "'", double31 == 0.9991379129498539d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.sample();
        int int28 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        float float21 = well19937c1.nextFloat();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.8216723f + "'", float21 == 0.8216723f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl22 = hypergeometricDistribution20.randomData;
        // The following exception was thrown during execution in test generation
        try {
            double double25 = randomDataImpl22.nextCauchy(0.36787944117144233d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl22);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl22 = hypergeometricDistribution20.randomData;
        // The following exception was thrown during execution in test generation
        try {
            int int25 = randomDataImpl22.nextInt(30, (-77));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (30) must be strictly less than upper bound (-77)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl22);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray21 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c22 = new org.apache.commons.math3.random.Well19937c(intArray21);
        int[] intArray27 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c22.setSeed(intArray27);
        byte[] byteArray33 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c22.nextBytes(byteArray33);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl35 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c22);
        int[] intArray36 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c(intArray36);
        well19937c22.setSeed(intArray36);
        well19937c1.setSeed(intArray36);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertArrayEquals(intArray21, new int[] {});
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertArrayEquals(intArray27, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertArrayEquals(intArray36, new int[] {});
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double22 = randomDataImpl14.nextBeta((double) 97, 1.7167355775177289d);
        randomDataImpl14.reSeedSecure((long) (short) 10);
        long long27 = randomDataImpl14.nextSecureLong((long) (-127), (long) 33);
        double double30 = randomDataImpl14.nextGamma(84.29631315677912d, (double) 51L);
        int[] intArray31 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c32 = new org.apache.commons.math3.random.Well19937c(intArray31);
        int[] intArray37 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c32.setSeed(intArray37);
        byte[] byteArray43 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c32.nextBytes(byteArray43);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c32);
        long long48 = randomDataImpl45.nextSecureLong((long) 0, (long) (short) 100);
        long long50 = randomDataImpl45.nextPoisson((double) 51L);
        int[] intArray51 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c52 = new org.apache.commons.math3.random.Well19937c(intArray51);
        int[] intArray57 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c52.setSeed(intArray57);
        byte[] byteArray63 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c52.nextBytes(byteArray63);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c52);
        long long67 = well19937c52.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution71 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c52, 97, 52, (int) '4');
        int[] intArray73 = hypergeometricDistribution71.sample(66);
        double double75 = hypergeometricDistribution71.probability((-1));
        double double78 = hypergeometricDistribution71.cumulativeProbability(0, 97);
        int int79 = randomDataImpl45.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int80 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int81 = hypergeometricDistribution71.getPopulationSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "13) test062(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 73L + "'", long17 == 73L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9838194766581275d + "'", double22 == 0.9838194766581275d);
// flaky "5) test062(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-108L) + "'", long27 == (-108L));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3401.6932281888926d + "'", double30 == 3401.6932281888926d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertArrayEquals(intArray31, new int[] {});
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertArrayEquals(intArray37, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "3) test062(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long48 + "' != '" + 70L + "'", long48 == 70L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 59L + "'", long50 == 59L);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertArrayEquals(intArray51, new int[] {});
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertArrayEquals(intArray57, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1L + "'", long67 == 1L);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 27 + "'", int79 == 27);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 29 + "'", int80 == 29);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 97 + "'", int81 == 97);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.cumulativeProbability(52);
        hypergeometricDistribution20.reseedRandomGenerator((long) (-229));
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl14.reSeedSecure(2L);
        double double20 = randomDataImpl14.nextUniform(2.270615534593869d, (double) (byte) 10, false);
        double double22 = randomDataImpl14.nextExponential(0.9838194766581275d);
        java.lang.String str24 = randomDataImpl14.nextHexString(66);
        // The following exception was thrown during execution in test generation
        try {
            int int28 = randomDataImpl14.nextHypergeometric(1312542635, 2147483647, 13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (2,147,483,647) must be less than or equal to population size (1,312,542,635)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.851092769973217d + "'", double20 == 2.851092769973217d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.6329350842724709d + "'", double22 == 0.6329350842724709d);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "c792a394ae5a295d86346e9eb6910aafdc72386e58d7489296bda8b49275f1488d" + "'", str24, "c792a394ae5a295d86346e9eb6910aafdc72386e58d7489296bda8b49275f1488d");
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl22 = hypergeometricDistribution20.randomData;
        double double25 = randomDataImpl22.nextF(27.876288659793815d, (double) 35L);
        // The following exception was thrown during execution in test generation
        try {
            double double28 = randomDataImpl22.nextF((double) (byte) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl22);
// flaky "14) test065(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.1115416352726482d + "'", double25 == 1.1115416352726482d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.sample();
        // The following exception was thrown during execution in test generation
        try {
            int int29 = hypergeometricDistribution20.inverseCumulativeProbability((double) 84L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 84 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        double double28 = hypergeometricDistribution20.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 6.062015091933255d + "'", double28 == 6.062015091933255d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        long long28 = randomDataImpl26.nextPoisson(0.9999999943667335d);
        // The following exception was thrown during execution in test generation
        try {
            double double31 = randomDataImpl26.nextCauchy(0.9991379129498539d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
// flaky "6) test068(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c1.setSeed((long) (byte) 100);
        boolean boolean4 = well19937c1.nextBoolean();
        double double5 = well19937c1.nextDouble();
        boolean boolean6 = well19937c1.nextBoolean();
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(1L);
        long long10 = well19937c8.nextLong(10L);
        int[] intArray11 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c12 = new org.apache.commons.math3.random.Well19937c(intArray11);
        well19937c8.setSeed(intArray11);
        double double14 = well19937c8.nextGaussian();
        int[] intArray15 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c16 = new org.apache.commons.math3.random.Well19937c(intArray15);
        int[] intArray21 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c16.setSeed(intArray21);
        byte[] byteArray27 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c16.nextBytes(byteArray27);
        well19937c8.nextBytes(byteArray27);
        well19937c1.nextBytes(byteArray27);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution34 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 1019069405, (int) (byte) -1, 28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.04677838737026563d + "'", double5 == 0.04677838737026563d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] {});
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.1973790993092482d) + "'", double14 == (-0.1973790993092482d));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertArrayEquals(intArray15, new int[] {});
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertArrayEquals(intArray21, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] { (byte) -39, (byte) -71, (byte) 55, (byte) -63 });
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        well19937c1.setSeed((long) 1350221770);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution26 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (int) (byte) 0, 1350221770, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.sample();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        int int23 = hypergeometricDistribution20.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 7 + "'", int23 == 7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl22 = hypergeometricDistribution20.randomData;
        double double25 = randomDataImpl22.nextF(27.876288659793815d, (double) 35L);
        // The following exception was thrown during execution in test generation
        try {
            double double28 = randomDataImpl22.nextF((double) (-13.0f), (double) 77L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-13)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl22);
// flaky "15) test072(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.7449408715309632d + "'", double25 == 0.7449408715309632d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.Well19937c well19937c31 = new org.apache.commons.math3.random.Well19937c(intArray29);
        // The following exception was thrown during execution in test generation
        try {
            long long33 = well19937c31.nextLong((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.probability(0);
        boolean boolean24 = hypergeometricDistribution20.isSupportConnected();
        // The following exception was thrown during execution in test generation
        try {
            int int26 = hypergeometricDistribution20.inverseCumulativeProbability(42.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 42 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        boolean boolean28 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl29 = hypergeometricDistribution20.randomData;
        hypergeometricDistribution20.reseedRandomGenerator(100L);
        double double33 = hypergeometricDistribution20.probability(0);
        int int34 = hypergeometricDistribution20.getSupportUpperBound();
        double double36 = hypergeometricDistribution20.probability(14);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(randomDataImpl29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 8.05189854526946E-9d + "'", double36 == 8.05189854526946E-9d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.cumulativeProbability((-1), (int) '#');
        int int32 = hypergeometricDistribution20.getPopulationSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.9991379129498539d + "'", double31 == 0.9991379129498539d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomGenerator randomGenerator5 = randomDataGenerator4.getRandomGenerator();
        // The following exception was thrown during execution in test generation
        try {
            int int9 = randomDataGenerator4.nextHypergeometric(26, (int) (byte) 100, 26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (100) must be less than or equal to population size (26)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(randomGenerator5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        hypergeometricDistribution20.reseedRandomGenerator(0L);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl24 = hypergeometricDistribution20.randomData;
        // The following exception was thrown during execution in test generation
        try {
            int int27 = randomDataImpl24.nextInt(33, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (33) must be strictly less than upper bound (-127)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl24);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure();
        double double4 = randomDataGenerator0.nextGaussian(20.01207441500431d, (double) 98L);
        long long7 = randomDataGenerator0.nextSecureLong(77L, 88L);
        java.lang.String str9 = randomDataGenerator0.nextHexString((int) (byte) 1);
        int int13 = randomDataGenerator0.nextHypergeometric(1092921087, 0, 51);
        // The following exception was thrown during execution in test generation
        try {
            long long15 = randomDataGenerator0.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "16) test079(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 81.84320936802337d + "'", double4 == 81.84320936802337d);
// flaky "7) test079(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long7 + "' != '" + 87L + "'", long7 == 87L);
// flaky "4) test079(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str9 + "' != '" + "d" + "'", str9, "d");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        well19937c1.setSeed((int) (byte) 100);
        // The following exception was thrown during execution in test generation
        try {
            int int24 = well19937c1.nextInt((-10));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -10 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.sample();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        int int23 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double33 = randomDataGenerator31.nextT(14.82903486167303d);
        // The following exception was thrown during execution in test generation
        try {
            double double36 = randomDataGenerator31.nextUniform(100.0d, 82.8316440748891d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (82.832)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-0.6893451132187746d) + "'", double33 == (-0.6893451132187746d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        boolean boolean29 = hypergeometricDistribution20.isSupportConnected();
        hypergeometricDistribution20.reseedRandomGenerator((-13L));
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int32 = well19937c1.nextInt();
        well19937c1.setSeed(19L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1076428756 + "'", int32 == 1076428756);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int22 = hypergeometricDistribution20.inverseCumulativeProbability(1.0030391140407694E-28d);
        double double25 = hypergeometricDistribution20.cumulativeProbability(7, (int) (short) 10);
        hypergeometricDistribution20.reseedRandomGenerator(5L);
        double double30 = hypergeometricDistribution20.cumulativeProbability((-120), 5);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.2885570377139202E-14d + "'", double25 == 2.2885570377139202E-14d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        double double41 = hypergeometricDistribution40.getNumericalMean();
        boolean boolean42 = hypergeometricDistribution40.isSupportConnected();
        int int43 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        long long46 = randomDataImpl14.nextLong((long) (byte) -1, 13L);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "17) test086(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 87L + "'", long17 == 87L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 27.876288659793815d + "'", double41 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 27 + "'", int43 == 27);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c1.setSeed((long) (byte) 100);
        double double4 = well19937c1.nextDouble();
        int[] intArray5 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        int[] intArray11 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c6.setSeed(intArray11);
        byte[] byteArray17 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c6.nextBytes(byteArray17);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        long long21 = well19937c6.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution25 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 97, 52, (int) '4');
        int[] intArray27 = hypergeometricDistribution25.sample(66);
        double double29 = hypergeometricDistribution25.probability((-1));
        int int30 = hypergeometricDistribution25.sample();
        int[] intArray32 = hypergeometricDistribution25.sample(35);
        well19937c1.setSeed(intArray32);
        org.apache.commons.math3.random.Well19937c well19937c34 = new org.apache.commons.math3.random.Well19937c(intArray32);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.1904834217843172d + "'", double4 == 0.1904834217843172d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertArrayEquals(intArray5, new int[] {});
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 30 + "'", int30 == 30);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl79 = hypergeometricDistribution69.randomData;
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "18) test088(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 71L + "'", long17 == 71L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertNotNull(randomDataImpl79);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double22 = hypergeometricDistribution20.getNumericalMean();
        double double24 = hypergeometricDistribution20.cumulativeProbability(26);
        int int25 = hypergeometricDistribution20.getSupportUpperBound();
        hypergeometricDistribution20.reseedRandomGenerator((long) 1);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 27.876288659793815d + "'", double22 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2873108246908985d + "'", double24 == 0.2873108246908985d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((-60), 109576327, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-60)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int26 = hypergeometricDistribution20.inverseCumulativeProbability(0.005695974142669164d);
        double double27 = hypergeometricDistribution20.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 22 + "'", int26 == 22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        long long28 = randomDataImpl26.nextPoisson(0.9999999943667335d);
        // The following exception was thrown during execution in test generation
        try {
            long long31 = randomDataImpl26.nextSecureLong(1385351496847528493L, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,385,351,496,847,528,493) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
// flaky "8) test092(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl22 = hypergeometricDistribution20.randomData;
        double double24 = hypergeometricDistribution20.probability(281511641);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double16 = randomDataImpl14.nextT(97.00161479327137d);
        // The following exception was thrown during execution in test generation
        try {
            int int20 = randomDataImpl14.nextHypergeometric(6, 1, (-46));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-46)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.4503023057474025d) + "'", double16 == (-1.4503023057474025d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        boolean boolean25 = hypergeometricDistribution20.isSupportConnected();
        hypergeometricDistribution20.reseedRandomGenerator((long) 51);
        int int28 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        boolean boolean23 = hypergeometricDistribution20.isSupportConnected();
        int int24 = hypergeometricDistribution20.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 7 + "'", int24 == 7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double33 = randomDataGenerator31.nextT(14.82903486167303d);
        // The following exception was thrown during execution in test generation
        try {
            double double36 = randomDataGenerator31.nextF((-43.0d), (double) 1755678109);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-43)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-0.6893451132187746d) + "'", double33 == (-0.6893451132187746d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomGenerator randomGenerator22 = hypergeometricDistribution20.random;
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
        org.junit.Assert.assertNotNull(randomGenerator22);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        double double29 = hypergeometricDistribution20.upperCumulativeProbability(1);
        int int30 = hypergeometricDistribution20.getSupportLowerBound();
        int[] intArray32 = hypergeometricDistribution20.sample(26);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        boolean boolean80 = hypergeometricDistribution69.isSupportConnected();
        double double81 = hypergeometricDistribution69.calculateNumericalVariance();
        double double84 = hypergeometricDistribution69.cumulativeProbability(30, 97);
        int int85 = hypergeometricDistribution69.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "19) test100(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4L + "'", long17 == 4L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 6.062015091933255d + "'", double81 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.142041812913815d + "'", double84 == 0.142041812913815d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 7 + "'", int85 == 7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.sample();
        // The following exception was thrown during execution in test generation
        try {
            int int24 = hypergeometricDistribution20.inverseCumulativeProbability(1.03489939E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 1,034,899,390 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        boolean boolean79 = hypergeometricDistribution69.isSupportConnected();
        int int80 = hypergeometricDistribution69.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "20) test102(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4L + "'", long17 == 4L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 7 + "'", int80 == 7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.cumulativeProbability((-127), 0);
        double double33 = hypergeometricDistribution20.cumulativeProbability(1273120795);
        hypergeometricDistribution20.reseedRandomGenerator(40L);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        org.apache.commons.math3.random.Well19937c well19937c26 = new org.apache.commons.math3.random.Well19937c(intArray25);
        well19937c26.clear();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double33 = randomDataGenerator31.nextT(14.82903486167303d);
        double double35 = randomDataGenerator31.nextExponential(97.00161479327137d);
        double double37 = randomDataGenerator31.nextExponential((double) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-0.6893451132187746d) + "'", double33 == (-0.6893451132187746d));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 28.233648676717284d + "'", double35 == 28.233648676717284d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.743358337186857d + "'", double37 == 2.743358337186857d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeedSecure((long) 'a');
        randomDataGenerator0.reSeed();
        double double7 = randomDataGenerator0.nextGaussian(9.509743227972956d, (double) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            int int11 = randomDataGenerator0.nextHypergeometric(322552280, 97, (-634352184));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-634,352,184)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "21) test106(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 12.78010265396737d + "'", double7 == 12.78010265396737d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int int24 = hypergeometricDistribution20.getSampleSize();
        int int25 = hypergeometricDistribution20.getSampleSize();
        double double27 = hypergeometricDistribution20.probability(100);
        double double28 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 27.876288659793815d + "'", double28 == 27.876288659793815d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int int25 = hypergeometricDistribution20.inverseCumulativeProbability(0.4484753762842155d);
        org.apache.commons.math3.random.RandomGenerator randomGenerator26 = hypergeometricDistribution20.random;
        double double27 = randomGenerator26.nextGaussian();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 28 + "'", int25 == 28);
        org.junit.Assert.assertNotNull(randomGenerator26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.9815393340827823d + "'", double27 == 0.9815393340827823d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double23 = hypergeometricDistribution20.getNumericalVariance();
        double double24 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 6.062015091933255d + "'", double23 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 27.876288659793815d + "'", double24 == 27.876288659793815d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        double double29 = hypergeometricDistribution20.upperCumulativeProbability(1);
        int int30 = hypergeometricDistribution20.getSupportLowerBound();
        int int31 = hypergeometricDistribution20.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 30 + "'", int31 == 30);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double21 = randomDataImpl14.nextT(5.298342365610589d);
        double double24 = randomDataImpl14.nextGamma((double) 40L, 0.9999999921684962d);
        long long26 = randomDataImpl14.nextPoisson((double) 97);
        // The following exception was thrown during execution in test generation
        try {
            int int30 = randomDataImpl14.nextHypergeometric((-39215830), 1317283884, 22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-39,215,830)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "22) test111(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 69L + "'", long17 == 69L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.16553447164781487d) + "'", double21 == (-0.16553447164781487d));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 28.204731814949124d + "'", double24 == 28.204731814949124d);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 113L + "'", long26 == 113L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        boolean boolean23 = hypergeometricDistribution20.isSupportConnected();
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        int int25 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c1.setSeed((long) (byte) 100);
        double double4 = well19937c1.nextDouble();
        double double5 = well19937c1.nextDouble();
        long long6 = well19937c1.nextLong();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (int) 'a', 97, (-634352184));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-634,352,184)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.1904834217843172d + "'", double4 == 0.1904834217843172d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.436170481055685d + "'", double5 == 0.436170481055685d);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4523942956662907304L) + "'", long6 == (-4523942956662907304L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl23 = hypergeometricDistribution20.randomData;
        double double26 = randomDataImpl23.nextGaussian(0.6178455839687462d, 0.2710505799226186d);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(randomDataImpl23);
// flaky "23) test114(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.5164491263242642d + "'", double26 == 0.5164491263242642d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        hypergeometricDistribution20.reseedRandomGenerator((long) (-43));
        double double30 = hypergeometricDistribution20.cumulativeProbability(0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double50 = randomDataImpl14.nextExponential(59.0d);
        int int53 = randomDataImpl14.nextSecureInt(6, 1350221770);
        randomDataImpl14.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            double double57 = randomDataImpl14.nextWeibull(0.43914843384337193d, (double) (-120));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-120)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "24) test116(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 58L + "'", long17 == 58L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 14.82903486167303d + "'", double50 == 14.82903486167303d);
// flaky "9) test116(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int53 + "' != '" + 548372286 + "'", int53 == 548372286);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.cumulativeProbability((-127), 0);
        double double33 = hypergeometricDistribution20.cumulativeProbability(1273120795);
        int int34 = hypergeometricDistribution20.getSupportUpperBound();
        double double35 = hypergeometricDistribution20.calculateNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 6.062015091933255d + "'", double35 == 6.062015091933255d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c1.setSeed((long) (byte) 100);
        boolean boolean4 = well19937c1.nextBoolean();
        double double5 = well19937c1.nextDouble();
        int[] intArray6 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c7 = new org.apache.commons.math3.random.Well19937c(intArray6);
        int[] intArray12 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c7.setSeed(intArray12);
        byte[] byteArray18 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c7.nextBytes(byteArray18);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c7);
        long long22 = well19937c7.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution26 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c7, 97, 52, (int) '4');
        int[] intArray28 = hypergeometricDistribution26.sample(66);
        double double30 = hypergeometricDistribution26.probability((-1));
        int int31 = hypergeometricDistribution26.sample();
        int[] intArray33 = hypergeometricDistribution26.sample(35);
        well19937c1.setSeed(intArray33);
        int int35 = well19937c1.nextInt();
        well19937c1.clear();
        well19937c1.setSeed(19L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.04677838737026563d + "'", double5 == 0.04677838737026563d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] {});
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertArrayEquals(intArray12, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 30 + "'", int31 == 30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1019069405 + "'", int35 == 1019069405);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.sample();
        int int28 = hypergeometricDistribution20.getSupportUpperBound();
        hypergeometricDistribution20.reseedRandomGenerator(87L);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        double double29 = hypergeometricDistribution20.probability((-1053312551));
        double double32 = hypergeometricDistribution20.cumulativeProbability(0, 1350221770);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        java.lang.String str2 = randomDataGenerator0.nextSecureHexString((int) '4');
        int int5 = randomDataGenerator0.nextInt((-79), 7);
        // The following exception was thrown during execution in test generation
        try {
            int int9 = randomDataGenerator0.nextHypergeometric(44, (-79), 1092921087);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-79)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "25) test121(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str2 + "' != '" + "091c462aa5b67d1b4253a1842f03622e0fc55bd10a133f887f59" + "'", str2, "091c462aa5b67d1b4253a1842f03622e0fc55bd10a133f887f59");
// flaky "10) test121(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-35) + "'", int5 == (-35));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int int49 = hypergeometricDistribution40.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "26) test122(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31L + "'", long17 == 31L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 7 + "'", int49 == 7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        double double30 = randomDataImpl27.nextGamma((double) 20L, 8.28208162640566d);
        double double34 = randomDataImpl27.nextUniform(0.0d, 0.9999999921382929d, true);
        java.lang.Class<?> wildcardClass35 = randomDataImpl27.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
// flaky "27) test123(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double30 + "' != '" + 174.2159292524341d + "'", double30 == 174.2159292524341d);
// flaky "11) test123(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05191917605939325d + "'", double34 == 0.05191917605939325d);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.cumulativeProbability(807774113);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl14.reSeedSecure(2L);
        double double20 = randomDataImpl14.nextUniform(2.270615534593869d, (double) (byte) 10, false);
        int int23 = randomDataImpl14.nextInt((int) (short) 10, (int) (byte) 100);
        double double25 = randomDataImpl14.nextExponential(0.06370136842548652d);
        double double27 = randomDataImpl14.nextChiSquare(0.9999999986588735d);
        // The following exception was thrown during execution in test generation
        try {
            int int31 = randomDataImpl14.nextHypergeometric(18, 0, (-39215830));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-39,215,830)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.851092769973217d + "'", double20 == 2.851092769973217d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 58 + "'", int23 == 58);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05481369359920802d + "'", double25 == 0.05481369359920802d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.2440758560670706d + "'", double27 == 2.2440758560670706d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray2 = new int[] {};
        well19937c1.setSeed(intArray2);
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c(intArray2);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution8 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c4, (-127), 12, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-127)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertArrayEquals(intArray2, new int[] {});
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.sample();
        int int23 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.getNumericalMean();
        double double26 = hypergeometricDistribution20.probability(97);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 27.876288659793815d + "'", double24 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        int int27 = hypergeometricDistribution20.getSupportUpperBound();
        // The following exception was thrown during execution in test generation
        try {
            int int29 = hypergeometricDistribution20.inverseCumulativeProbability(3.514159089720459E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 3,514,159,089.72 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        double double29 = hypergeometricDistribution20.cumulativeProbability(7, 1343615654);
        double double32 = hypergeometricDistribution20.cumulativeProbability((-39215830), 0);
        int int33 = hypergeometricDistribution20.getPopulationSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        boolean boolean5 = well19937c1.nextBoolean();
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution9 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 28, (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        hypergeometricDistribution20.reseedRandomGenerator(0L);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl24 = hypergeometricDistribution20.randomData;
        double double25 = hypergeometricDistribution20.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 6.062015091933255d + "'", double25 == 6.062015091933255d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(1312542635);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        int int27 = hypergeometricDistribution20.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(randomDataImpl26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure();
        double double4 = randomDataGenerator0.nextGaussian(20.01207441500431d, (double) 98L);
        long long7 = randomDataGenerator0.nextSecureLong(77L, 88L);
        double double9 = randomDataGenerator0.nextChiSquare(84.29631315677912d);
        // The following exception was thrown during execution in test generation
        try {
            int int13 = randomDataGenerator0.nextHypergeometric(0, (int) '#', 44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "28) test133(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-176.15762323016943d) + "'", double4 == (-176.15762323016943d));
// flaky "12) test133(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long7 + "' != '" + 84L + "'", long7 == 84L);
// flaky "5) test133(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 76.72561221377914d + "'", double9 == 76.72561221377914d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int int49 = hypergeometricDistribution40.sample();
        double double50 = hypergeometricDistribution40.getNumericalMean();
        double double52 = hypergeometricDistribution40.upperCumulativeProbability(2147483647);
        double double53 = hypergeometricDistribution40.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "29) test134(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 19L + "'", long17 == 19L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 30 + "'", int49 == 30);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 27.876288659793815d + "'", double50 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 6.062015091933255d + "'", double53 == 6.062015091933255d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (byte) 0);
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            int int8 = randomDataGenerator0.nextHypergeometric((-10), (-12), (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-10)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c1.setSeed((long) (byte) 100);
        boolean boolean4 = well19937c1.nextBoolean();
        double double5 = well19937c1.nextDouble();
        int[] intArray6 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c7 = new org.apache.commons.math3.random.Well19937c(intArray6);
        int[] intArray12 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c7.setSeed(intArray12);
        byte[] byteArray18 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c7.nextBytes(byteArray18);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c7);
        long long22 = well19937c7.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution26 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c7, 97, 52, (int) '4');
        int[] intArray28 = hypergeometricDistribution26.sample(66);
        double double30 = hypergeometricDistribution26.probability((-1));
        int int31 = hypergeometricDistribution26.sample();
        int[] intArray33 = hypergeometricDistribution26.sample(35);
        well19937c1.setSeed(intArray33);
        double double35 = well19937c1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.04677838737026563d + "'", double5 == 0.04677838737026563d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] {});
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertArrayEquals(intArray12, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 30 + "'", int31 == 30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.08969165521980581d + "'", double35 == 0.08969165521980581d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = randomDataImpl14.nextPoisson(100.0d);
        double double18 = randomDataImpl14.nextChiSquare(66.0d);
        double double21 = randomDataImpl14.nextGaussian(36745.3646600493d, 0.8824135674751239d);
        // The following exception was thrown during execution in test generation
        try {
            int int25 = randomDataImpl14.nextHypergeometric((-35), (-2), 109576327);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-35)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 110L + "'", long16 == 110L);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 63.54939791639947d + "'", double18 == 63.54939791639947d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 36743.57316109849d + "'", double21 == 36743.57316109849d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (byte) 0);
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeed();
        double double6 = randomDataGenerator0.nextChiSquare(0.08106146679532726d);
        randomDataGenerator0.reSeed(88L);
        int int12 = randomDataGenerator0.nextHypergeometric(1019069405, 1, (int) '#');
        // The following exception was thrown during execution in test generation
        try {
            int int15 = randomDataGenerator0.nextPascal(11, 1.24818131348945d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 1.248 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
// flaky "30) test138(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.659024270804333E-7d + "'", double6 == 5.659024270804333E-7d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        boolean boolean25 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomGenerator randomGenerator26 = hypergeometricDistribution20.random;
        double double27 = hypergeometricDistribution20.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(randomGenerator26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        double double30 = randomDataImpl27.nextGamma((double) 20L, 8.28208162640566d);
        double double34 = randomDataImpl27.nextUniform(0.0d, 0.9999999921382929d, true);
        double double36 = randomDataImpl27.nextChiSquare(4.189654742026425d);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
// flaky "31) test140(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double30 + "' != '" + 198.69356056315854d + "'", double30 == 198.69356056315854d);
// flaky "13) test140(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.5565880870041627d + "'", double34 == 0.5565880870041627d);
// flaky "6) test140(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double36 + "' != '" + 8.562079423011589d + "'", double36 == 8.562079423011589d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability((int) (short) 0);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        java.lang.Class<?> wildcardClass27 = hypergeometricDistribution20.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        // The following exception was thrown during execution in test generation
        try {
            int int27 = hypergeometricDistribution20.inverseCumulativeProbability((double) 59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 59 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double22 = randomDataImpl14.nextBeta((double) 97, 1.7167355775177289d);
        randomDataImpl14.reSeedSecure((long) (short) 10);
        long long27 = randomDataImpl14.nextSecureLong((long) (-127), (long) 33);
        double double30 = randomDataImpl14.nextGamma(84.29631315677912d, (double) 51L);
        int[] intArray31 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c32 = new org.apache.commons.math3.random.Well19937c(intArray31);
        int[] intArray37 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c32.setSeed(intArray37);
        byte[] byteArray43 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c32.nextBytes(byteArray43);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c32);
        long long47 = well19937c32.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution51 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c32, 97, 52, (int) '4');
        double double52 = hypergeometricDistribution51.getNumericalMean();
        int int53 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution51);
        double double55 = hypergeometricDistribution51.cumulativeProbability((int) (byte) -1);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "32) test143(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 67L + "'", long17 == 67L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9838194766581275d + "'", double22 == 0.9838194766581275d);
// flaky "14) test143(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-71L) + "'", long27 == (-71L));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3401.6932281888926d + "'", double30 == 3401.6932281888926d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertArrayEquals(intArray31, new int[] {});
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertArrayEquals(intArray37, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 27.876288659793815d + "'", double52 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 29 + "'", int53 == 29);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c1.setSeed((long) (byte) 100);
        double double4 = well19937c1.nextDouble();
        int[] intArray5 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c(intArray5);
        int[] intArray11 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c6.setSeed(intArray11);
        byte[] byteArray17 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c6.nextBytes(byteArray17);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c6);
        long long21 = well19937c6.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution25 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c6, 97, 52, (int) '4');
        int[] intArray27 = hypergeometricDistribution25.sample(66);
        double double29 = hypergeometricDistribution25.probability((-1));
        int int30 = hypergeometricDistribution25.sample();
        int[] intArray32 = hypergeometricDistribution25.sample(35);
        well19937c1.setSeed(intArray32);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution37 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-633008008), (-2), (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-633,008,008)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.1904834217843172d + "'", double4 == 0.1904834217843172d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertArrayEquals(intArray5, new int[] {});
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 30 + "'", int30 == 30);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int82 = randomDataImpl14.nextHypergeometric(1019069405, 29, 0);
        // The following exception was thrown during execution in test generation
        try {
            int int85 = randomDataImpl14.nextSecureInt(66, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (66) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "33) test145(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 29L + "'", long17 == 29L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        int int27 = hypergeometricDistribution20.getPopulationSize();
        int[] intArray29 = hypergeometricDistribution20.sample(13);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertArrayEquals(intArray29, new int[] { 27, 26, 25, 25, 29, 25, 26, 31, 25, 27, 26, 22, 28 });
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        int int27 = hypergeometricDistribution20.sample();
        double double28 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 28 + "'", int27 == 28);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 27.876288659793815d + "'", double28 == 27.876288659793815d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        int int28 = hypergeometricDistribution20.solveInverseCumulativeProbability((double) (-13L), (int) '#', 0);
        double double29 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 27.876288659793815d + "'", double29 == 27.876288659793815d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        int int27 = hypergeometricDistribution20.getPopulationSize();
        int int28 = hypergeometricDistribution20.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 27 + "'", int28 == 27);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        well19937c1.setSeed((int) (short) 100);
        int[] intArray10 = null;
        well19937c1.setSeed(intArray10);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution15 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, (-127), (-5));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-127)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        double double80 = hypergeometricDistribution69.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "34) test151(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 37L + "'", long17 == 37L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 6.062015091933255d + "'", double80 == 6.062015091933255d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        boolean boolean29 = hypergeometricDistribution20.isSupportConnected();
        int int33 = hypergeometricDistribution20.solveInverseCumulativeProbability(4.607186634331292E28d, 11, 1596099378);
        double double35 = hypergeometricDistribution20.cumulativeProbability((-664715511));
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1596099378 + "'", int33 == 1596099378);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl14.setSecureAlgorithm("3", "d44358299b2036ac67ec2b6b5b801dbb8aeec2ae7d25756035b8");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: d44358299b2036ac67ec2b6b5b801dbb8aeec2ae7d25756035b8");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "35) test153(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28L + "'", long17 == 28L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        boolean boolean28 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl29 = hypergeometricDistribution20.randomData;
        hypergeometricDistribution20.reseedRandomGenerator(100L);
        double double33 = hypergeometricDistribution20.probability(0);
        int int34 = hypergeometricDistribution20.getSupportUpperBound();
        double double35 = hypergeometricDistribution20.getNumericalVariance();
        int int36 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(randomDataImpl29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 6.062015091933255d + "'", double35 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 52 + "'", int36 == 52);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        double double27 = hypergeometricDistribution20.cumulativeProbability(0, 97);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl28 = hypergeometricDistribution20.randomData;
        // The following exception was thrown during execution in test generation
        try {
            long long31 = randomDataImpl28.nextSecureLong((long) 1755678109, 4L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,755,678,109) must be strictly less than upper bound (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(randomDataImpl28);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        hypergeometricDistribution69.reseedRandomGenerator(35L);
        // The following exception was thrown during execution in test generation
        try {
            double double84 = hypergeometricDistribution69.cumulativeProbability(0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0) must be less than or equal to upper endpoint (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "36) test156(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 54L + "'", long17 == 54L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((int) (short) 1, 0, 281511641);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: sample size (281,511,641) must be less than or equal to population size (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        // The following exception was thrown during execution in test generation
        try {
            double double27 = hypergeometricDistribution20.cumulativeProbability(807774113, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (807,774,113) must be less than or equal to upper endpoint (52)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        double double30 = randomDataImpl27.nextGamma((double) 20L, 8.28208162640566d);
        double double34 = randomDataImpl27.nextUniform(0.0d, 0.9999999921382929d, true);
        randomDataImpl27.reSeedSecure();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
// flaky "37) test159(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double30 + "' != '" + 167.55687467639908d + "'", double30 == 167.55687467639908d);
// flaky "15) test159(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.38369934983355525d + "'", double34 == 0.38369934983355525d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double22 = randomDataImpl14.nextBeta((double) 97, 1.7167355775177289d);
        randomDataImpl14.reSeedSecure((long) (short) 10);
        long long27 = randomDataImpl14.nextSecureLong((long) (-127), (long) 33);
        double double30 = randomDataImpl14.nextGamma(84.29631315677912d, (double) 51L);
        int[] intArray31 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c32 = new org.apache.commons.math3.random.Well19937c(intArray31);
        int[] intArray37 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c32.setSeed(intArray37);
        byte[] byteArray43 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c32.nextBytes(byteArray43);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c32);
        long long48 = randomDataImpl45.nextSecureLong((long) 0, (long) (short) 100);
        long long50 = randomDataImpl45.nextPoisson((double) 51L);
        int[] intArray51 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c52 = new org.apache.commons.math3.random.Well19937c(intArray51);
        int[] intArray57 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c52.setSeed(intArray57);
        byte[] byteArray63 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c52.nextBytes(byteArray63);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c52);
        long long67 = well19937c52.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution71 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c52, 97, 52, (int) '4');
        int[] intArray73 = hypergeometricDistribution71.sample(66);
        double double75 = hypergeometricDistribution71.probability((-1));
        double double78 = hypergeometricDistribution71.cumulativeProbability(0, 97);
        int int79 = randomDataImpl45.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int80 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int81 = hypergeometricDistribution71.getNumberOfSuccesses();
        int int82 = hypergeometricDistribution71.getSupportUpperBound();
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray84 = hypergeometricDistribution71.sample((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "38) test160(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 46L + "'", long17 == 46L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9838194766581275d + "'", double22 == 0.9838194766581275d);
// flaky "16) test160(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-22L) + "'", long27 == (-22L));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3401.6932281888926d + "'", double30 == 3401.6932281888926d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertArrayEquals(intArray31, new int[] {});
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertArrayEquals(intArray37, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "7) test160(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long48 + "' != '" + 77L + "'", long48 == 77L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 59L + "'", long50 == 59L);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertArrayEquals(intArray51, new int[] {});
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertArrayEquals(intArray57, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1L + "'", long67 == 1L);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 27 + "'", int79 == 27);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 29 + "'", int80 == 29);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 52 + "'", int81 == 52);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 52 + "'", int82 == 52);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.sample();
        int int28 = hypergeometricDistribution20.getSupportUpperBound();
        int int29 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int30 = hypergeometricDistribution20.solveInverseCumulativeProbability((double) 36L, 997715607, 1187994814);
        double double31 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1187994814 + "'", int30 == 1187994814);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 27.876288659793815d + "'", double31 == 27.876288659793815d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        double double29 = hypergeometricDistribution20.upperCumulativeProbability(1);
        boolean boolean30 = hypergeometricDistribution20.isSupportConnected();
        double double31 = hypergeometricDistribution20.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 6.062015091933255d + "'", double31 == 6.062015091933255d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double23 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.cumulativeProbability(1350221770);
        int int26 = hypergeometricDistribution20.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 6.062015091933255d + "'", double23 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 30 + "'", int26 == 30);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        int int28 = hypergeometricDistribution20.getNumberOfSuccesses();
        int int29 = hypergeometricDistribution20.getPopulationSize();
        int int30 = hypergeometricDistribution20.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 24 + "'", int30 == 24);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        long long28 = randomDataImpl26.nextPoisson(0.9999999943667335d);
        double double31 = randomDataImpl26.nextBeta(96.70639570057162d, 0.2506256061061618d);
        int int34 = randomDataImpl26.nextInt((-77), (int) (byte) 100);
        long long36 = randomDataImpl26.nextPoisson(124.53997546121035d);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl26.setSecureAlgorithm("29cac3d1a8accda72063386ce17b51ce15b1172259b92f83a10b", "fd062121adc9391fddd1381bbdb3f680d2dbee2aa308d83cb5b7");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: fd062121adc9391fddd1381bbdb3f680d2dbee2aa308d83cb5b7");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
// flaky "17) test166(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
// flaky "39) test166(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.9974539314700079d + "'", double31 == 0.9974539314700079d);
// flaky "8) test166(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int34 + "' != '" + 23 + "'", int34 == 23);
// flaky "2) test166(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long36 + "' != '" + 129L + "'", long36 == 129L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double50 = randomDataImpl14.nextExponential(59.0d);
        // The following exception was thrown during execution in test generation
        try {
            int int53 = randomDataImpl14.nextZipf(0, (double) Float.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: dimension (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "40) test167(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 90L + "'", long17 == 90L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 14.82903486167303d + "'", double50 == 14.82903486167303d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math3.random.RandomGenerator randomGenerator0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution4 = new org.apache.commons.math3.distribution.HypergeometricDistribution(randomGenerator0, (-60), 97, 58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-60)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        double double26 = hypergeometricDistribution20.getNumericalVariance();
        double double28 = hypergeometricDistribution20.upperCumulativeProbability(52);
        hypergeometricDistribution20.reseedRandomGenerator(30L);
        boolean boolean31 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0030391140407694E-28d + "'", double28 == 1.0030391140407694E-28d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        int[] intArray27 = hypergeometricDistribution20.sample(35);
        double double29 = hypergeometricDistribution20.cumulativeProbability(12);
        hypergeometricDistribution20.reseedRandomGenerator(20L);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.621682588941363E-11d + "'", double29 == 2.621682588941363E-11d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        double double7 = well19937c1.nextGaussian();
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c(1L);
        long long11 = well19937c9.nextLong(10L);
        int[] intArray12 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c13 = new org.apache.commons.math3.random.Well19937c(intArray12);
        well19937c9.setSeed(intArray12);
        well19937c1.setSeed(intArray12);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution19 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-61), (-120), 59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-61)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.1973790993092482d) + "'", double7 == (-0.1973790993092482d));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertArrayEquals(intArray12, new int[] {});
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        boolean boolean25 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomGenerator randomGenerator26 = hypergeometricDistribution20.random;
        double double27 = randomGenerator26.nextDouble();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(randomGenerator26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.8216723694180394d + "'", double27 == 0.8216723694180394d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        hypergeometricDistribution20.reseedRandomGenerator(0L);
        int int24 = hypergeometricDistribution20.getSampleSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        double double29 = hypergeometricDistribution20.upperCumulativeProbability(1);
        int int30 = hypergeometricDistribution20.getSupportLowerBound();
        int int31 = hypergeometricDistribution20.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 7 + "'", int31 == 7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        well19937c1.setSeed((int) (byte) 100);
        double double23 = well19937c1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-0.3674175180023106d) + "'", double23 == (-0.3674175180023106d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.sample();
        double double28 = hypergeometricDistribution20.calculateNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 6.062015091933255d + "'", double28 == 6.062015091933255d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        int int23 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.getNumericalMean();
        double double27 = hypergeometricDistribution20.cumulativeProbability((int) (byte) 1, 1076428756);
        boolean boolean28 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 27.876288659793815d + "'", double24 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        boolean boolean22 = hypergeometricDistribution20.isSupportConnected();
        int int23 = hypergeometricDistribution20.getSupportUpperBound();
        double double25 = hypergeometricDistribution20.probability(22);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.009358188068150605d + "'", double25 == 0.009358188068150605d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        double double41 = hypergeometricDistribution40.getNumericalMean();
        boolean boolean42 = hypergeometricDistribution40.isSupportConnected();
        int int43 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        long long45 = randomDataImpl14.nextPoisson((double) 12);
        // The following exception was thrown during execution in test generation
        try {
            int int48 = randomDataImpl14.nextSecureInt((int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "41) test179(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 26L + "'", long17 == 26L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 27.876288659793815d + "'", double41 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 27 + "'", int43 == 27);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 16L + "'", long45 == 16L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        int int23 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        int int25 = hypergeometricDistribution20.getSupportLowerBound();
        double double26 = hypergeometricDistribution20.getNumericalMean();
        int int27 = hypergeometricDistribution20.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 27.876288659793815d + "'", double26 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure();
        double double4 = randomDataGenerator0.nextBeta((double) 52, 1.2722218725854067E-14d);
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            int int10 = randomDataGenerator0.nextHypergeometric(26, (-39215830), 1019069405);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-39,215,830)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "18) test181(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double23 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.cumulativeProbability(1350221770);
        double double27 = hypergeometricDistribution20.probability(0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 6.062015091933255d + "'", double23 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str33 = randomDataGenerator31.nextHexString((-55));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-55)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure();
        double double4 = randomDataGenerator0.nextGaussian(20.01207441500431d, (double) 98L);
        long long7 = randomDataGenerator0.nextSecureLong(77L, 88L);
        java.lang.String str9 = randomDataGenerator0.nextHexString((int) (byte) 1);
        int int13 = randomDataGenerator0.nextHypergeometric(1092921087, 0, 51);
        long long15 = randomDataGenerator0.nextPoisson(1.5430806348152437d);
        // The following exception was thrown during execution in test generation
        try {
            double double18 = randomDataGenerator0.nextCauchy(113.43475232862113d, (-0.0019503157456160264d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0.002)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "42) test184(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-49.20716757135928d) + "'", double4 == (-49.20716757135928d));
// flaky "19) test184(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long7 + "' != '" + 79L + "'", long7 == 79L);
// flaky "3) test184(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str9 + "' != '" + "f" + "'", str9, "f");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
// flaky "9) test184(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2L + "'", long15 == 2L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        boolean boolean32 = well19937c1.nextBoolean();
        int[] intArray33 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c34 = new org.apache.commons.math3.random.Well19937c(intArray33);
        int[] intArray39 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c34.setSeed(intArray39);
        well19937c34.setSeed((long) 10);
        byte[] byteArray48 = new byte[] { (byte) 10, (byte) 100, (byte) 1, (byte) 0, (byte) 100 };
        well19937c34.nextBytes(byteArray48);
        well19937c1.nextBytes(byteArray48);
        boolean boolean51 = well19937c1.nextBoolean();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertArrayEquals(intArray33, new int[] {});
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertArrayEquals(intArray39, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertArrayEquals(byteArray48, new byte[] { (byte) -50, (byte) -121, (byte) 16, (byte) -73, (byte) 121 });
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        hypergeometricDistribution20.reseedRandomGenerator((long) (-43));
        int int29 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl30 = hypergeometricDistribution20.randomData;
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 30 + "'", int29 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl30);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        double double27 = hypergeometricDistribution20.getNumericalVariance();
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        int int29 = hypergeometricDistribution20.getPopulationSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        boolean boolean22 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomGenerator randomGenerator23 = hypergeometricDistribution20.random;
        int int24 = hypergeometricDistribution20.sample();
        // The following exception was thrown during execution in test generation
        try {
            double double27 = hypergeometricDistribution20.cumulativeProbability(1402845057, (-1053312551));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1,402,845,057) must be less than or equal to upper endpoint (-1,053,312,551)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(randomGenerator23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 30 + "'", int24 == 30);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (byte) 0);
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeed();
        double double7 = randomDataGenerator0.nextGamma((double) 18, 7.255201989815092d);
        randomDataGenerator0.reSeedSecure((long) (-1));
        double double11 = randomDataGenerator0.nextChiSquare(9.999999999999998d);
        // The following exception was thrown during execution in test generation
        try {
            int int15 = randomDataGenerator0.nextHypergeometric((int) ' ', 109576327, (-77));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-77)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "43) test189(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 142.63429667631075d + "'", double7 == 142.63429667631075d);
// flaky "20) test189(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.957013492513667d + "'", double11 == 10.957013492513667d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        double double23 = hypergeometricDistribution20.getNumericalVariance();
        int int24 = hypergeometricDistribution20.getSupportUpperBound();
        boolean boolean25 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 6.062015091933255d + "'", double23 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (byte) 0);
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeed();
        long long7 = randomDataGenerator0.nextLong((long) (short) 0, (long) 30);
        double double10 = randomDataGenerator0.nextBeta((double) 1350221770, (double) 79L);
        int int13 = randomDataGenerator0.nextSecureInt((-120), 5);
        double double15 = randomDataGenerator0.nextExponential((double) 81L);
        randomDataGenerator0.reSeed();
        double double19 = randomDataGenerator0.nextGamma(0.5768342436830945d, 8.28208162640566d);
        int int23 = randomDataGenerator0.nextHypergeometric(669070016, 5, 28);
// flaky "44) test191(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9L + "'", long7 == 9L);
// flaky "21) test191(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9999999326845026d + "'", double10 == 0.9999999326845026d);
// flaky "10) test191(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-51) + "'", int13 == (-51));
// flaky "4) test191(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 56.99813124299447d + "'", double15 == 56.99813124299447d);
// flaky "1) test191(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.4320099292786626d + "'", double19 == 0.4320099292786626d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        double double27 = hypergeometricDistribution20.getNumericalVariance();
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        // The following exception was thrown during execution in test generation
        try {
            double double31 = hypergeometricDistribution20.cumulativeProbability(1350221770, (-120));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1,350,221,770) must be less than or equal to upper endpoint (-120)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.sample();
        int[] intArray23 = hypergeometricDistribution20.sample(27);
        int int27 = hypergeometricDistribution20.solveInverseCumulativeProbability((double) (-1), (-3), 1092921087);
        java.lang.Class<?> wildcardClass28 = hypergeometricDistribution20.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-2) + "'", int27 == (-2));
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        boolean boolean28 = hypergeometricDistribution20.isSupportConnected();
        double double29 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 27.876288659793815d + "'", double29 == 27.876288659793815d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int30 = hypergeometricDistribution20.solveInverseCumulativeProbability((double) 36L, 997715607, 1187994814);
        int int32 = hypergeometricDistribution20.inverseCumulativeProbability(0.9999999443643905d);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1187994814 + "'", int30 == 1187994814);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 41 + "'", int32 == 41);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double50 = randomDataImpl14.nextExponential(59.0d);
        int int53 = randomDataImpl14.nextSecureInt(6, 1350221770);
        randomDataImpl14.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl14.setSecureAlgorithm("org.apache.commons.math3.exception.NotFiniteNumberException: 0 is not a finite number", "9a1910fb2c343f569d6cb67c625bad86bcd79ec0305fddee9de89b524f7b4cc35df8adf784babea6a0d457680a5058531");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 9a1910fb2c343f569d6cb67c625bad86bcd79ec0305fddee9de89b524f7b4cc35df8adf784babea6a0d457680a5058531");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "45) test196(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 72L + "'", long17 == 72L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 14.82903486167303d + "'", double50 == 14.82903486167303d);
// flaky "22) test196(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int53 + "' != '" + 924992844 + "'", int53 == 924992844);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double28 = hypergeometricDistribution20.cumulativeProbability((int) (byte) 1, (int) (short) 1);
        int int30 = hypergeometricDistribution20.inverseCumulativeProbability(0.0d);
        double double31 = hypergeometricDistribution20.getNumericalVariance();
        double double32 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 6.062015091933255d + "'", double31 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 27.876288659793815d + "'", double32 == 27.876288659793815d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        double double27 = hypergeometricDistribution20.cumulativeProbability(0, 97);
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        int int29 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        // The following exception was thrown during execution in test generation
        try {
            double double52 = randomDataImpl14.nextUniform(5.237036340979439d, 0.47419678090191336d, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (5.237) must be strictly less than upper bound (0.474)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "46) test199(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 69L + "'", long17 == 69L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        double double23 = hypergeometricDistribution20.getNumericalVariance();
        int int24 = hypergeometricDistribution20.getSupportUpperBound();
        double double26 = hypergeometricDistribution20.cumulativeProbability((int) '4');
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 6.062015091933255d + "'", double23 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(randomGenerator27);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int[] intArray1 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c2 = new org.apache.commons.math3.random.Well19937c(intArray1);
        int[] intArray7 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c2.setSeed(intArray7);
        byte[] byteArray13 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c2.nextBytes(byteArray13);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c2);
        long long17 = well19937c2.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution21 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c2, 97, 52, (int) '4');
        double double22 = hypergeometricDistribution21.getNumericalMean();
        double double24 = hypergeometricDistribution21.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution21.getNumericalVariance();
        double double26 = hypergeometricDistribution21.getNumericalMean();
        hypergeometricDistribution21.reseedRandomGenerator(1385351496847528493L);
        boolean boolean29 = hypergeometricDistribution21.isSupportConnected();
        double double30 = hypergeometricDistribution21.getNumericalMean();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-2), (java.lang.Number) (-43), false);
        int[] intArray35 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c36 = new org.apache.commons.math3.random.Well19937c(intArray35);
        int[] intArray41 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c36.setSeed(intArray41);
        byte[] byteArray47 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c36.nextBytes(byteArray47);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl49 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c36);
        long long51 = well19937c36.nextLong(2L);
        java.lang.Object[] objArray52 = new java.lang.Object[] { double30, (-2), well19937c36 };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException53 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 85L, objArray52);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertArrayEquals(intArray1, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertArrayEquals(byteArray13, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 27.876288659793815d + "'", double22 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 6.062015091933255d + "'", double25 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 27.876288659793815d + "'", double26 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 27.876288659793815d + "'", double30 == 27.876288659793815d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertArrayEquals(intArray35, new int[] {});
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertArrayEquals(intArray41, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertArrayEquals(byteArray47, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1L + "'", long51 == 1L);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        double double27 = hypergeometricDistribution20.getNumericalVariance();
        double double28 = hypergeometricDistribution20.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 6.062015091933255d + "'", double28 == 6.062015091933255d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        double double27 = hypergeometricDistribution20.cumulativeProbability(0, 97);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl28 = hypergeometricDistribution20.randomData;
        double double29 = hypergeometricDistribution20.getNumericalVariance();
        int int30 = hypergeometricDistribution20.getSampleSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(randomDataImpl28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 6.062015091933255d + "'", double29 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 52 + "'", int30 == 52);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.cumulativeProbability((-127), 0);
        double double33 = hypergeometricDistribution20.cumulativeProbability(1273120795);
        double double35 = hypergeometricDistribution20.probability((-23));
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        hypergeometricDistribution20.reseedRandomGenerator((long) 1019069405);
        int int27 = hypergeometricDistribution20.getSampleSize();
        // The following exception was thrown during execution in test generation
        try {
            int int29 = hypergeometricDistribution20.inverseCumulativeProbability(75.01393855339691d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 75.014 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.cumulativeProbability(52);
        int int25 = hypergeometricDistribution20.getSupportLowerBound();
        int int29 = hypergeometricDistribution20.solveInverseCumulativeProbability((double) 0.6862626f, (-23), (-79));
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-79) + "'", int29 == (-79));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.probability(0);
        boolean boolean24 = hypergeometricDistribution20.isSupportConnected();
        boolean boolean25 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        int int27 = hypergeometricDistribution20.getPopulationSize();
        int int28 = hypergeometricDistribution20.getSampleSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        double double30 = hypergeometricDistribution20.cumulativeProbability(4, 27);
        org.apache.commons.math3.random.RandomGenerator randomGenerator31 = hypergeometricDistribution20.random;
        boolean boolean32 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.43914843384337193d + "'", double30 == 0.43914843384337193d);
        org.junit.Assert.assertNotNull(randomGenerator31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        boolean boolean22 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomGenerator randomGenerator23 = hypergeometricDistribution20.random;
        // The following exception was thrown during execution in test generation
        try {
            double double26 = hypergeometricDistribution20.cumulativeProbability((int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (52) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(randomGenerator23);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.probability(0);
        double double25 = hypergeometricDistribution20.cumulativeProbability(1);
        double double26 = hypergeometricDistribution20.getNumericalMean();
        // The following exception was thrown during execution in test generation
        try {
            int int28 = hypergeometricDistribution20.inverseCumulativeProbability((double) 58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 58 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 27.876288659793815d + "'", double26 == 27.876288659793815d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        int int25 = hypergeometricDistribution20.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(1312542635);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        double double28 = hypergeometricDistribution20.cumulativeProbability(35);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(randomDataImpl26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.9991379129498539d + "'", double28 == 0.9991379129498539d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        long long31 = well19937c1.nextLong();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 4623226306565277646L + "'", long31 == 4623226306565277646L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        int int1 = well19937c0.nextInt();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c0, 0, (-1023), 1755678109);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "47) test215(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1723119098) + "'", int1 == (-1723119098));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        boolean boolean26 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        hypergeometricDistribution20.reseedRandomGenerator((long) 1019069405);
        int int27 = hypergeometricDistribution20.getSampleSize();
        double double28 = hypergeometricDistribution20.getNumericalMean();
        int int29 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 27.876288659793815d + "'", double28 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(281511641, 0, 1019069405);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: sample size (1,019,069,405) must be less than or equal to population size (281,511,641)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        boolean boolean29 = hypergeometricDistribution20.isSupportConnected();
        int int33 = hypergeometricDistribution20.solveInverseCumulativeProbability(4.607186634331292E28d, 11, 1596099378);
        double double35 = hypergeometricDistribution20.upperCumulativeProbability(79);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1596099378 + "'", int33 == 1596099378);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        boolean boolean80 = hypergeometricDistribution69.isSupportConnected();
        double double81 = hypergeometricDistribution69.calculateNumericalVariance();
        int int82 = hypergeometricDistribution69.sample();
        int int83 = hypergeometricDistribution69.getSupportLowerBound();
        double double85 = hypergeometricDistribution69.upperCumulativeProbability(997715607);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "48) test222(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24L + "'", long17 == 24L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 6.062015091933255d + "'", double81 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 27 + "'", int82 == 27);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 7 + "'", int83 == 7);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.cumulativeProbability((-127), 0);
        boolean boolean32 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        int int28 = hypergeometricDistribution20.getNumberOfSuccesses();
        hypergeometricDistribution20.reseedRandomGenerator(19L);
        int int31 = hypergeometricDistribution20.getPopulationSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 97 + "'", int31 == 97);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        long long28 = randomDataImpl26.nextPoisson(0.9999999943667335d);
        double double31 = randomDataImpl26.nextBeta(96.70639570057162d, 0.2506256061061618d);
        int int34 = randomDataImpl26.nextInt((-77), (int) (byte) 100);
        long long36 = randomDataImpl26.nextPoisson(124.53997546121035d);
        java.lang.String str38 = randomDataImpl26.nextHexString((int) 'a');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
// flaky "49) test225(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
// flaky "23) test225(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.99999999812593d + "'", double31 == 0.99999999812593d);
// flaky "11) test225(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
// flaky "5) test225(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long36 + "' != '" + 104L + "'", long36 == 104L);
// flaky "2) test225(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str38 + "' != '" + "bef259a188472453d41ae69118fa40d97757298a5d7efbdf9e43ca0c7c4e5d7d29552aeff10c4683117ad324152b1756f" + "'", str38, "bef259a188472453d41ae69118fa40d97757298a5d7efbdf9e43ca0c7c4e5d7d29552aeff10c4683117ad324152b1756f");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double26 = hypergeometricDistribution20.getNumericalMean();
        double double28 = hypergeometricDistribution20.upperCumulativeProbability(29);
        int int29 = hypergeometricDistribution20.getPopulationSize();
        int int33 = hypergeometricDistribution20.solveInverseCumulativeProbability(87.41599680859316d, 337842759, 44);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 27.876288659793815d + "'", double26 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.39945954962551267d + "'", double28 == 0.39945954962551267d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 44 + "'", int33 == 44);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.cumulativeProbability(52);
        int int25 = hypergeometricDistribution20.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        double double41 = hypergeometricDistribution40.getNumericalMean();
        boolean boolean42 = hypergeometricDistribution40.isSupportConnected();
        int int43 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int int46 = randomDataImpl14.nextSecureInt(97, 912281074);
        double double48 = randomDataImpl14.nextExponential((double) 807774113);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "50) test228(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 77L + "'", long17 == 77L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 27.876288659793815d + "'", double41 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 27 + "'", int43 == 27);
// flaky "24) test228(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int46 + "' != '" + 890769048 + "'", int46 == 890769048);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0302560139040694E8d + "'", double48 == 2.0302560139040694E8d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        org.apache.commons.math3.random.Well19937c well19937c2 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c2.setSeed((long) (byte) 100);
        boolean boolean5 = well19937c2.nextBoolean();
        double double6 = well19937c2.nextDouble();
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        double double31 = hypergeometricDistribution27.probability((-1));
        int int32 = hypergeometricDistribution27.sample();
        int[] intArray34 = hypergeometricDistribution27.sample(35);
        well19937c2.setSeed(intArray34);
        well19937c0.setSeed(intArray34);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.04677838737026563d + "'", double6 == 0.04677838737026563d);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 30 + "'", int32 == 30);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        org.apache.commons.math3.random.Well19937c well19937c29 = new org.apache.commons.math3.random.Well19937c(1L);
        long long31 = well19937c29.nextLong(10L);
        int[] intArray32 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c33 = new org.apache.commons.math3.random.Well19937c(intArray32);
        well19937c29.setSeed(intArray32);
        double double35 = well19937c29.nextGaussian();
        org.apache.commons.math3.random.Well19937c well19937c37 = new org.apache.commons.math3.random.Well19937c(1L);
        long long39 = well19937c37.nextLong(10L);
        int[] intArray40 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c41 = new org.apache.commons.math3.random.Well19937c(intArray40);
        well19937c37.setSeed(intArray40);
        well19937c29.setSeed(intArray40);
        randomGenerator27.setSeed(intArray40);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertArrayEquals(intArray32, new int[] {});
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-0.1973790993092482d) + "'", double35 == (-0.1973790993092482d));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2L + "'", long39 == 2L);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertArrayEquals(intArray40, new int[] {});
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        int int27 = hypergeometricDistribution20.sample();
        int int28 = hypergeometricDistribution20.getSampleSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 28 + "'", int27 == 28);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure();
        double double4 = randomDataGenerator0.nextGaussian(20.01207441500431d, (double) 98L);
        long long7 = randomDataGenerator0.nextSecureLong(77L, 88L);
        java.lang.String str9 = randomDataGenerator0.nextHexString((int) (byte) 1);
        int int13 = randomDataGenerator0.nextHypergeometric(1092921087, 0, 51);
        long long15 = randomDataGenerator0.nextPoisson(1.5430806348152437d);
        int int19 = randomDataGenerator0.nextHypergeometric(1265935785, 912281074, 0);
// flaky "51) test232(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 33.524404136676324d + "'", double4 == 33.524404136676324d);
// flaky "25) test232(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long7 + "' != '" + 88L + "'", long7 == 88L);
// flaky "12) test232(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str9 + "' != '" + "b" + "'", str9, "b");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
// flaky "6) test232(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double50 = randomDataImpl14.nextExponential(59.0d);
        int int53 = randomDataImpl14.nextSecureInt(6, 1350221770);
        randomDataImpl14.reSeedSecure();
        double double57 = randomDataImpl14.nextCauchy(0.0d, 6.750283437866453d);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "52) test233(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 72L + "'", long17 == 72L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 14.82903486167303d + "'", double50 == 14.82903486167303d);
// flaky "26) test233(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int53 + "' != '" + 849176735 + "'", int53 == 849176735);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 3.526729833686446d + "'", double57 == 3.526729833686446d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int int49 = hypergeometricDistribution40.sample();
        double double50 = hypergeometricDistribution40.getNumericalMean();
        org.apache.commons.math3.random.RandomGenerator randomGenerator51 = hypergeometricDistribution40.random;
        double double53 = hypergeometricDistribution40.probability(1596099378);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "53) test234(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 98L + "'", long17 == 98L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 30 + "'", int49 == 30);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 27.876288659793815d + "'", double50 == 27.876288659793815d);
        org.junit.Assert.assertNotNull(randomGenerator51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        hypergeometricDistribution20.reseedRandomGenerator((long) (-43));
        double double31 = hypergeometricDistribution20.cumulativeProbability((int) (byte) 10, 30);
        org.apache.commons.math3.random.RandomGenerator randomGenerator32 = hypergeometricDistribution20.random;
        boolean boolean33 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.8579581870861621d + "'", double31 == 0.8579581870861621d);
        org.junit.Assert.assertNotNull(randomGenerator32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        long long28 = randomDataImpl26.nextPoisson(0.9999999943667335d);
        double double31 = randomDataImpl26.nextBeta(96.70639570057162d, 0.2506256061061618d);
        // The following exception was thrown during execution in test generation
        try {
            double double34 = randomDataImpl26.nextUniform(548.3170351552121d, (double) 18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (548.317) must be strictly less than upper bound (18)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
// flaky "27) test236(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
// flaky "54) test236(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.9999999988583883d + "'", double31 == 0.9999999988583883d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double22 = randomDataImpl14.nextBeta((double) 97, 1.7167355775177289d);
        randomDataImpl14.reSeedSecure((long) (short) 10);
        long long27 = randomDataImpl14.nextSecureLong((long) (-127), (long) 33);
        double double30 = randomDataImpl14.nextGamma(84.29631315677912d, (double) 51L);
        int[] intArray31 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c32 = new org.apache.commons.math3.random.Well19937c(intArray31);
        int[] intArray37 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c32.setSeed(intArray37);
        byte[] byteArray43 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c32.nextBytes(byteArray43);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c32);
        long long48 = randomDataImpl45.nextSecureLong((long) 0, (long) (short) 100);
        long long50 = randomDataImpl45.nextPoisson((double) 51L);
        int[] intArray51 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c52 = new org.apache.commons.math3.random.Well19937c(intArray51);
        int[] intArray57 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c52.setSeed(intArray57);
        byte[] byteArray63 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c52.nextBytes(byteArray63);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c52);
        long long67 = well19937c52.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution71 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c52, 97, 52, (int) '4');
        int[] intArray73 = hypergeometricDistribution71.sample(66);
        double double75 = hypergeometricDistribution71.probability((-1));
        double double78 = hypergeometricDistribution71.cumulativeProbability(0, 97);
        int int79 = randomDataImpl45.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int80 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        // The following exception was thrown during execution in test generation
        try {
            int int83 = randomDataImpl14.nextBinomial((int) (byte) -1, (double) (-3.4359738E10f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of trials (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "55) test237(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 59L + "'", long17 == 59L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9838194766581275d + "'", double22 == 0.9838194766581275d);
// flaky "28) test237(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-97L) + "'", long27 == (-97L));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3401.6932281888926d + "'", double30 == 3401.6932281888926d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertArrayEquals(intArray31, new int[] {});
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertArrayEquals(intArray37, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "13) test237(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long48 + "' != '" + 93L + "'", long48 == 93L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 59L + "'", long50 == 59L);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertArrayEquals(intArray51, new int[] {});
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertArrayEquals(intArray57, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1L + "'", long67 == 1L);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 27 + "'", int79 == 27);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 29 + "'", int80 == 29);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double51 = randomDataImpl14.nextGamma(0.9893697548062742d, 210.36682286041457d);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "56) test238(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 14L + "'", long17 == 14L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 951.8528395682124d + "'", double51 == 951.8528395682124d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double51 = randomDataImpl14.nextGaussian(0.8758405348702564d, (double) (byte) 100);
        // The following exception was thrown during execution in test generation
        try {
            double double54 = randomDataImpl14.nextUniform(1.03489939E9d, (double) (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,034,899,390) must be strictly less than upper bound (-1,023)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "57) test239(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 90L + "'", long17 == 90L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-202.1467575811614d) + "'", double51 == (-202.1467575811614d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        long long28 = randomDataImpl26.nextPoisson(0.9999999943667335d);
        double double31 = randomDataImpl26.nextBeta(96.70639570057162d, 0.2506256061061618d);
        int int34 = randomDataImpl26.nextInt((-77), (int) (byte) 100);
        // The following exception was thrown during execution in test generation
        try {
            int int37 = randomDataImpl26.nextPascal((int) (byte) 100, 2.718281828459045d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 2.718 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
// flaky "58) test240(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
// flaky "29) test240(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.9805070768728162d + "'", double31 == 0.9805070768728162d);
// flaky "14) test240(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int34 + "' != '" + 77 + "'", int34 == 77);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.sample();
        int[] intArray23 = hypergeometricDistribution20.sample(27);
        int int25 = hypergeometricDistribution20.inverseCumulativeProbability(0.3557325281436989d);
        double double28 = hypergeometricDistribution20.cumulativeProbability((-1), 0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 27 + "'", int25 == 27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.setSeed(2147483647);
        long long34 = well19937c1.nextLong();
        double double35 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 593588180895003629L + "'", long34 == 593588180895003629L);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.3797087211741881d + "'", double35 == 0.3797087211741881d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        hypergeometricDistribution20.reseedRandomGenerator((long) (-43));
        int int29 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        int int25 = hypergeometricDistribution20.solveInverseCumulativeProbability(0.0d, 1317283884, (int) (short) 0);
        hypergeometricDistribution20.reseedRandomGenerator((long) 51);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        double double27 = hypergeometricDistribution20.getNumericalVariance();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl28 = hypergeometricDistribution20.randomData;
        int int29 = hypergeometricDistribution20.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
        org.junit.Assert.assertNotNull(randomDataImpl28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 30 + "'", int29 == 30);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        boolean boolean80 = hypergeometricDistribution69.isSupportConnected();
        double double81 = hypergeometricDistribution69.calculateNumericalVariance();
        double double84 = hypergeometricDistribution69.cumulativeProbability(30, 97);
        double double85 = hypergeometricDistribution69.calculateNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "59) test246(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 16L + "'", long17 == 16L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 6.062015091933255d + "'", double81 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.142041812913815d + "'", double84 == 0.142041812913815d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 6.062015091933255d + "'", double85 == 6.062015091933255d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double28 = hypergeometricDistribution20.cumulativeProbability((int) (byte) 1, (int) (short) 1);
        org.apache.commons.math3.random.RandomGenerator randomGenerator29 = hypergeometricDistribution20.random;
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(randomGenerator29);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        hypergeometricDistribution20.reseedRandomGenerator((long) 1019069405);
        int int27 = hypergeometricDistribution20.getSampleSize();
        double double28 = hypergeometricDistribution20.getNumericalMean();
        double double29 = hypergeometricDistribution20.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 27.876288659793815d + "'", double28 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 6.062015091933255d + "'", double29 == 6.062015091933255d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.cumulativeProbability((-127), 0);
        int int32 = hypergeometricDistribution20.getSupportUpperBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution3 = new org.apache.commons.math3.distribution.HypergeometricDistribution(398788800, (-120), (-108));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-120)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        boolean boolean22 = hypergeometricDistribution20.isSupportConnected();
        int int23 = hypergeometricDistribution20.getSupportUpperBound();
        boolean boolean24 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.sample();
        int int28 = hypergeometricDistribution20.getSupportUpperBound();
        double double30 = hypergeometricDistribution20.cumulativeProbability(0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (byte) 0);
        randomDataGenerator0.reSeed();
        double double6 = randomDataGenerator0.nextWeibull((double) 1.1920929E-7f, (double) 1L);
        double double9 = randomDataGenerator0.nextCauchy((-0.9999999999999999d), (double) 10L);
        double double12 = randomDataGenerator0.nextGaussian(0.41011164190606875d, (double) 0.33499444f);
        double double15 = randomDataGenerator0.nextWeibull((double) '4', 20.01207441500431d);
        int int19 = randomDataGenerator0.nextHypergeometric(79, 39, 33);
// flaky "60) test253(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
// flaky "30) test253(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 12.464171326619237d + "'", double9 == 12.464171326619237d);
// flaky "15) test253(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.13867822640184335d) + "'", double12 == (-0.13867822640184335d));
// flaky "7) test253(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 20.026239160989633d + "'", double15 == 20.026239160989633d);
// flaky "3) test253(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int19 + "' != '" + 14 + "'", int19 == 14);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        double double41 = hypergeometricDistribution40.getNumericalMean();
        boolean boolean42 = hypergeometricDistribution40.isSupportConnected();
        int int43 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        long long45 = randomDataImpl14.nextPoisson((double) 12);
        randomDataImpl14.reSeedSecure(78L);
        long long49 = randomDataImpl14.nextPoisson(2.3565815518605597E7d);
        // The following exception was thrown during execution in test generation
        try {
            double double53 = randomDataImpl14.nextUniform((double) 100, 0.5164491263242642d, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (0.516)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "61) test254(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 7L + "'", long17 == 7L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 27.876288659793815d + "'", double41 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 27 + "'", int43 == 27);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 16L + "'", long45 == 16L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 23555956L + "'", long49 == 23555956L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        hypergeometricDistribution20.reseedRandomGenerator((long) 1019069405);
        double double27 = hypergeometricDistribution20.calculateNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        double double81 = randomDataImpl14.nextUniform(1.5836414305180074E-7d, 6.0d);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "62) test256(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 63L + "'", long17 == 63L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 3.9195037976065965d + "'", double81 == 3.9195037976065965d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl22 = hypergeometricDistribution20.randomData;
        randomDataImpl22.reSeedSecure(27L);
        int int27 = randomDataImpl22.nextZipf(24, 84.29631315677912d);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl22.setSecureAlgorithm("bef259a188472453d41ae69118fa40d97757298a5d7efbdf9e43ca0c7c4e5d7d29552aeff10c4683117ad324152b1756f", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.apache.commons.math3.random.RandomGenerator randomGenerator27 = hypergeometricDistribution20.random;
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.cumulativeProbability((-127), 0);
        double double33 = hypergeometricDistribution20.cumulativeProbability(1273120795);
        int int34 = hypergeometricDistribution20.getSupportUpperBound();
        int int38 = hypergeometricDistribution20.solveInverseCumulativeProbability((double) 0.76195765f, 322552280, 109576327);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertNotNull(randomGenerator27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 109576327 + "'", int38 == 109576327);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        boolean boolean22 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomGenerator randomGenerator23 = hypergeometricDistribution20.random;
        int int24 = hypergeometricDistribution20.sample();
        int[] intArray26 = hypergeometricDistribution20.sample(51);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(randomGenerator23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 30 + "'", int24 == 30);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(randomDataImpl27);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        java.lang.Class<?> wildcardClass26 = hypergeometricDistribution20.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int[] intArray25 = hypergeometricDistribution20.sample(18);
        double double26 = hypergeometricDistribution20.getNumericalVariance();
        boolean boolean27 = hypergeometricDistribution20.isSupportConnected();
        double double29 = hypergeometricDistribution20.cumulativeProbability(33);
        org.apache.commons.math3.random.RandomGenerator randomGenerator30 = hypergeometricDistribution20.random;
        double double31 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.9893655361852781d + "'", double29 == 0.9893655361852781d);
        org.junit.Assert.assertNotNull(randomGenerator30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 27.876288659793815d + "'", double31 == 27.876288659793815d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataGenerator31.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            double double35 = randomDataGenerator31.nextUniform((double) 1024.0f, (double) 8L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,024) must be strictly less than upper bound (8)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        // The following exception was thrown during execution in test generation
        try {
            double double27 = hypergeometricDistribution20.cumulativeProbability((int) (short) 100, (-634352184));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (100) must be less than or equal to upper endpoint (-634,352,184)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        boolean boolean26 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution3 = new org.apache.commons.math3.distribution.HypergeometricDistribution((int) (byte) -1, 386382693, 1019069405);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        double double27 = hypergeometricDistribution20.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double28 = hypergeometricDistribution20.cumulativeProbability((int) (byte) 1, (int) (short) 1);
        int int30 = hypergeometricDistribution20.inverseCumulativeProbability(0.0d);
        double double31 = hypergeometricDistribution20.getNumericalVariance();
        org.apache.commons.math3.random.RandomGenerator randomGenerator32 = hypergeometricDistribution20.random;
        double double35 = hypergeometricDistribution20.cumulativeProbability((-65), 84);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray37 = hypergeometricDistribution20.sample((-5));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (-5)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 6.062015091933255d + "'", double31 == 6.062015091933255d);
        org.junit.Assert.assertNotNull(randomGenerator32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl23 = hypergeometricDistribution20.randomData;
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray26 = randomDataImpl23.nextPermutation(46, 669070016);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (669,070,016) exceeds permuation domain (46)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(randomDataImpl23);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.probability(0);
        double double25 = hypergeometricDistribution20.cumulativeProbability(1);
        double double26 = hypergeometricDistribution20.getNumericalMean();
        double double29 = hypergeometricDistribution20.cumulativeProbability(11, 192843090);
        org.apache.commons.math3.random.RandomGenerator randomGenerator30 = hypergeometricDistribution20.random;
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 27.876288659793815d + "'", double26 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.9999999999990744d + "'", double29 == 0.9999999999990744d);
        org.junit.Assert.assertNotNull(randomGenerator30);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c1.setSeed((long) (byte) 100);
        boolean boolean4 = well19937c1.nextBoolean();
        double double5 = well19937c1.nextDouble();
        int[] intArray6 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c7 = new org.apache.commons.math3.random.Well19937c(intArray6);
        int[] intArray12 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c7.setSeed(intArray12);
        byte[] byteArray18 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c7.nextBytes(byteArray18);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c7);
        long long22 = well19937c7.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution26 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c7, 97, 52, (int) '4');
        int[] intArray28 = hypergeometricDistribution26.sample(66);
        double double30 = hypergeometricDistribution26.probability((-1));
        int int31 = hypergeometricDistribution26.sample();
        int[] intArray33 = hypergeometricDistribution26.sample(35);
        well19937c1.setSeed(intArray33);
        int int35 = well19937c1.nextInt();
        well19937c1.setSeed((-634352184));
        well19937c1.setSeed(573263424);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.04677838737026563d + "'", double5 == 0.04677838737026563d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] {});
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertArrayEquals(intArray12, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 30 + "'", int31 == 30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1019069405 + "'", int35 == 1019069405);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        boolean boolean80 = hypergeometricDistribution69.isSupportConnected();
        double double81 = hypergeometricDistribution69.calculateNumericalVariance();
        double double84 = hypergeometricDistribution69.cumulativeProbability(30, 97);
        double double86 = hypergeometricDistribution69.cumulativeProbability(1019069405);
        int int87 = hypergeometricDistribution69.getSupportUpperBound();
        double double88 = hypergeometricDistribution69.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "63) test271(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 62L + "'", long17 == 62L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 6.062015091933255d + "'", double81 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.142041812913815d + "'", double84 == 0.142041812913815d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.0d + "'", double86 == 1.0d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 52 + "'", int87 == 52);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 27.876288659793815d + "'", double88 == 27.876288659793815d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        int int24 = hypergeometricDistribution20.getSampleSize();
        int int25 = hypergeometricDistribution20.getSampleSize();
        double double27 = hypergeometricDistribution20.probability(100);
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        int int29 = hypergeometricDistribution20.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        double double27 = hypergeometricDistribution20.getNumericalVariance();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl28 = hypergeometricDistribution20.randomData;
        // The following exception was thrown during execution in test generation
        try {
            double double31 = randomDataImpl28.nextUniform((double) 36425668L, (double) (-1042126906620457968L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (36,425,668) must be strictly less than upper bound (-1,042,126,906,620,457,980)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
        org.junit.Assert.assertNotNull(randomDataImpl28);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        int int23 = hypergeometricDistribution20.getSupportUpperBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl24 = hypergeometricDistribution20.randomData;
        int int25 = hypergeometricDistribution20.getPopulationSize();
        hypergeometricDistribution20.reseedRandomGenerator(37L);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        long long28 = randomDataImpl26.nextPoisson(0.9999999943667335d);
        double double31 = randomDataImpl26.nextGaussian(0.0d, (double) 24.0f);
        double double34 = randomDataImpl26.nextWeibull((double) 51L, 4.641588833612779d);
        // The following exception was thrown during execution in test generation
        try {
            long long37 = randomDataImpl26.nextLong((long) 1076428756, 94L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,076,428,756) must be strictly less than upper bound (94)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
// flaky "31) test275(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2L + "'", long28 == 2L);
// flaky "64) test275(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.7740807429724659d) + "'", double31 == (-1.7740807429724659d));
// flaky "16) test275(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.69018978010339d + "'", double34 == 4.69018978010339d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(1755678109);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        boolean boolean80 = hypergeometricDistribution69.isSupportConnected();
        double double81 = hypergeometricDistribution69.calculateNumericalVariance();
        int int82 = hypergeometricDistribution69.getPopulationSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "65) test277(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 71L + "'", long17 == 71L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 6.062015091933255d + "'", double81 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 97 + "'", int82 == 97);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        double double27 = hypergeometricDistribution20.getNumericalVariance();
        int[] intArray29 = hypergeometricDistribution20.sample(84);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 6.062015091933255d + "'", double27 == 6.062015091933255d);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int int49 = hypergeometricDistribution40.sample();
        double double50 = hypergeometricDistribution40.getNumericalMean();
        double double52 = hypergeometricDistribution40.upperCumulativeProbability(2147483647);
        hypergeometricDistribution40.reseedRandomGenerator((long) 59);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "66) test279(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 30 + "'", int49 == 30);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 27.876288659793815d + "'", double50 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        double double30 = randomDataImpl27.nextGamma((double) 20L, 8.28208162640566d);
        double double34 = randomDataImpl27.nextUniform(0.0d, 0.9999999921382929d, true);
        long long37 = randomDataImpl27.nextSecureLong((long) 13, (long) 100);
        double double41 = randomDataImpl27.nextUniform(0.0d, 0.8682594960950892d, false);
        // The following exception was thrown during execution in test generation
        try {
            long long44 = randomDataImpl27.nextLong(90L, 89L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (90) must be strictly less than upper bound (89)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
// flaky "67) test280(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double30 + "' != '" + 145.49606212183267d + "'", double30 == 145.49606212183267d);
// flaky "32) test280(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.3480070498922989d + "'", double34 == 0.3480070498922989d);
// flaky "17) test280(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long37 + "' != '" + 46L + "'", long37 == 46L);
// flaky "8) test280(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.3881295803395193d + "'", double41 == 0.3881295803395193d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        well19937c1.setSeed((long) (byte) 100);
        double double4 = well19937c1.nextDouble();
        double double5 = well19937c1.nextDouble();
        long long6 = well19937c1.nextLong();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution10 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-12), 31, 669070016);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-12)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.1904834217843172d + "'", double4 == 0.1904834217843172d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.436170481055685d + "'", double5 == 0.436170481055685d);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4523942956662907304L) + "'", long6 == (-4523942956662907304L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.probability(0);
        double double25 = hypergeometricDistribution20.cumulativeProbability(1);
        double double26 = hypergeometricDistribution20.getNumericalMean();
        int int27 = hypergeometricDistribution20.getSupportLowerBound();
        int int28 = hypergeometricDistribution20.getSupportLowerBound();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 27.876288659793815d + "'", double26 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.cumulativeProbability(52);
        double double26 = hypergeometricDistribution20.probability(0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        boolean boolean80 = hypergeometricDistribution69.isSupportConnected();
        double double81 = hypergeometricDistribution69.calculateNumericalVariance();
        int int82 = hypergeometricDistribution69.getSupportLowerBound();
        int int86 = hypergeometricDistribution69.solveInverseCumulativeProbability(0.44756637790472364d, 765592357, 23);
        // The following exception was thrown during execution in test generation
        try {
            int int88 = hypergeometricDistribution69.inverseCumulativeProbability(1.8909716782511083d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 1.891 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "68) test284(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 30L + "'", long17 == 30L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 6.062015091933255d + "'", double81 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 7 + "'", int82 == 7);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 23 + "'", int86 == 23);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl23 = hypergeometricDistribution20.randomData;
        hypergeometricDistribution20.reseedRandomGenerator((long) 1);
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(randomDataImpl23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl14.reSeed();
        randomDataImpl14.reSeedSecure();
        int int19 = randomDataImpl14.nextInt((int) ' ', 100);
        // The following exception was thrown during execution in test generation
        try {
            int int23 = randomDataImpl14.nextHypergeometric(1596099378, 1034899390, (-65));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-65)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "69) test286(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int19 + "' != '" + 98 + "'", int19 == 98);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        double double27 = hypergeometricDistribution20.cumulativeProbability(0, 97);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl28 = hypergeometricDistribution20.randomData;
        double double29 = hypergeometricDistribution20.getNumericalVariance();
        int int30 = hypergeometricDistribution20.getSupportLowerBound();
        double double31 = hypergeometricDistribution20.calculateNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(randomDataImpl28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 6.062015091933255d + "'", double29 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 6.062015091933255d + "'", double31 == 6.062015091933255d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        long long28 = randomDataImpl26.nextPoisson(0.9999999943667335d);
        double double31 = randomDataImpl26.nextCauchy(1.521114715252356d, 2.2885570377139202E-14d);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
// flaky "70) test288(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
// flaky "33) test288(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.521114715252294d + "'", double31 == 1.521114715252294d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double22 = hypergeometricDistribution20.getNumericalMean();
        double double24 = hypergeometricDistribution20.cumulativeProbability(26);
        double double27 = hypergeometricDistribution20.cumulativeProbability(28, 23892394);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 27.876288659793815d + "'", double22 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2873108246908985d + "'", double24 == 0.2873108246908985d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.39945954962551267d + "'", double27 == 0.39945954962551267d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double33 = randomDataGenerator31.nextExponential(2.7182818256512777d);
        // The following exception was thrown during execution in test generation
        try {
            int int36 = randomDataGenerator31.nextZipf((-1023), 1.5922320536470858E7d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: dimension (-1,023)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.8909716782511083d + "'", double33 == 1.8909716782511083d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double50 = randomDataImpl14.nextExponential(59.0d);
        int int53 = randomDataImpl14.nextSecureInt(6, 1350221770);
        randomDataImpl14.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            double double57 = randomDataImpl14.nextF(8.545063372445695E-12d, (double) (-75));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-75)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "71) test291(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 73L + "'", long17 == 73L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 14.82903486167303d + "'", double50 == 14.82903486167303d);
// flaky "34) test291(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1027256983 + "'", int53 == 1027256983);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int[] intArray23 = hypergeometricDistribution20.sample(35);
        // The following exception was thrown during execution in test generation
        try {
            int int25 = hypergeometricDistribution20.inverseCumulativeProbability(5.3936482068690905d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 5.394 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(52);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution5 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 818120085, (-103), (-8));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-103)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        int int22 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.cumulativeProbability(52);
        int int25 = hypergeometricDistribution20.getSupportLowerBound();
        int int26 = hypergeometricDistribution20.getNumberOfSuccesses();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 109576327);
        long long22 = randomDataImpl14.nextSecureLong(0L, 7540580061456263210L);
        // The following exception was thrown during execution in test generation
        try {
            int int26 = randomDataImpl14.nextHypergeometric((-46), (-26), 281511641);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-46)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "72) test295(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 11L + "'", long17 == 11L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 109586603L + "'", long19 == 109586603L);
// flaky "35) test295(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1504091143022023346L + "'", long22 == 1504091143022023346L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int22 = hypergeometricDistribution20.inverseCumulativeProbability(1.0030391140407694E-28d);
        int int23 = hypergeometricDistribution20.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (byte) 0);
        randomDataGenerator0.reSeed();
        double double6 = randomDataGenerator0.nextWeibull((double) 1.1920929E-7f, (double) 1L);
        double double9 = randomDataGenerator0.nextCauchy((-0.9999999999999999d), (double) 10L);
        double double12 = randomDataGenerator0.nextGaussian(0.41011164190606875d, (double) 0.33499444f);
        java.lang.String str14 = randomDataGenerator0.nextSecureHexString((int) (short) 10);
        long long16 = randomDataGenerator0.nextPoisson((double) 26);
        java.lang.String str18 = randomDataGenerator0.nextHexString(14);
        // The following exception was thrown during execution in test generation
        try {
            int int22 = randomDataGenerator0.nextHypergeometric(582264363, 1312542635, (-23));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-23)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "18) test297(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
// flaky "73) test297(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-3.9175692462036613d) + "'", double9 == (-3.9175692462036613d));
// flaky "36) test297(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.8285429817638025d + "'", double12 == 0.8285429817638025d);
// flaky "9) test297(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str14 + "' != '" + "519fe15c75" + "'", str14, "519fe15c75");
// flaky "4) test297(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long16 + "' != '" + 21L + "'", long16 == 21L);
// flaky "1) test297(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str18 + "' != '" + "ed70fdc5ccbef5" + "'", str18, "ed70fdc5ccbef5");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure();
        double double4 = randomDataGenerator0.nextGaussian(20.01207441500431d, (double) 98L);
        long long7 = randomDataGenerator0.nextSecureLong(77L, 88L);
        java.lang.String str9 = randomDataGenerator0.nextHexString((int) (byte) 1);
        int int13 = randomDataGenerator0.nextHypergeometric(1092921087, 0, 51);
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("e24d4d98cfb80025d6fdafdbc46cda9e4a35ba5b0af4a2d3ac6f0c20c5eafd4d34143eb2cac5e35463dbe08ad1cb5d290", "29cac3d1a8accda72063386ce17b51ce15b1172259b92f83a10b");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 29cac3d1a8accda72063386ce17b51ce15b1172259b92f83a10b");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
// flaky "74) test298(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 139.6229352882961d + "'", double4 == 139.6229352882961d);
// flaky "19) test298(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long7 + "' != '" + 78L + "'", long7 == 78L);
// flaky "37) test298(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str9 + "' != '" + "2" + "'", str9, "2");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.calculateNumericalVariance();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 6.062015091933255d + "'", double25 == 6.062015091933255d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int79 = hypergeometricDistribution69.sample();
        boolean boolean80 = hypergeometricDistribution69.isSupportConnected();
        double double81 = hypergeometricDistribution69.calculateNumericalVariance();
        int int82 = hypergeometricDistribution69.sample();
        int int83 = hypergeometricDistribution69.getSupportLowerBound();
        int int84 = hypergeometricDistribution69.sample();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "75) test300(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 84L + "'", long17 == 84L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 30 + "'", int79 == 30);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 6.062015091933255d + "'", double81 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 27 + "'", int82 == 27);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 7 + "'", int83 == 7);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 26 + "'", int84 == 26);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray49 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c50 = new org.apache.commons.math3.random.Well19937c(intArray49);
        int[] intArray55 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c50.setSeed(intArray55);
        byte[] byteArray61 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c50.nextBytes(byteArray61);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl63 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c50);
        long long65 = well19937c50.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution69 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c50, 97, 52, (int) '4');
        int[] intArray71 = hypergeometricDistribution69.sample(66);
        double double73 = hypergeometricDistribution69.probability((-1));
        int int77 = hypergeometricDistribution69.solveInverseCumulativeProbability((-1.1326292721122528d), (-43), 0);
        int int78 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution69);
        int int81 = randomDataImpl14.nextBinomial(58, 0.16418991386706785d);
        // The following exception was thrown during execution in test generation
        try {
            long long84 = randomDataImpl14.nextLong(80L, 8L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (80) must be strictly less than upper bound (8)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "76) test301(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 16L + "'", long17 == 16L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertArrayEquals(intArray49, new int[] {});
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertArrayEquals(intArray55, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-42) + "'", int77 == (-42));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 29 + "'", int78 == 29);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 11 + "'", int81 == 11);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int21 = hypergeometricDistribution20.getSupportUpperBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl22 = hypergeometricDistribution20.randomData;
        hypergeometricDistribution20.reseedRandomGenerator(73L);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertNotNull(randomDataImpl22);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        well19937c1.setSeed((long) (-127));
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double22 = randomDataImpl14.nextBeta((double) 97, 1.7167355775177289d);
        randomDataImpl14.reSeedSecure((long) (short) 10);
        long long27 = randomDataImpl14.nextSecureLong((long) (-127), (long) 33);
        double double30 = randomDataImpl14.nextGamma(84.29631315677912d, (double) 51L);
        int[] intArray31 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c32 = new org.apache.commons.math3.random.Well19937c(intArray31);
        int[] intArray37 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c32.setSeed(intArray37);
        byte[] byteArray43 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c32.nextBytes(byteArray43);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c32);
        long long48 = randomDataImpl45.nextSecureLong((long) 0, (long) (short) 100);
        long long50 = randomDataImpl45.nextPoisson((double) 51L);
        int[] intArray51 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c52 = new org.apache.commons.math3.random.Well19937c(intArray51);
        int[] intArray57 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c52.setSeed(intArray57);
        byte[] byteArray63 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c52.nextBytes(byteArray63);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c52);
        long long67 = well19937c52.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution71 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c52, 97, 52, (int) '4');
        int[] intArray73 = hypergeometricDistribution71.sample(66);
        double double75 = hypergeometricDistribution71.probability((-1));
        double double78 = hypergeometricDistribution71.cumulativeProbability(0, 97);
        int int79 = randomDataImpl45.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int80 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int81 = hypergeometricDistribution71.getNumberOfSuccesses();
        int int85 = hypergeometricDistribution71.solveInverseCumulativeProbability((-202.1467575811614d), 1317283884, (-120));
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "77) test304(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 88L + "'", long17 == 88L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9838194766581275d + "'", double22 == 0.9838194766581275d);
// flaky "38) test304(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-17L) + "'", long27 == (-17L));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3401.6932281888926d + "'", double30 == 3401.6932281888926d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertArrayEquals(intArray31, new int[] {});
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertArrayEquals(intArray37, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "20) test304(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long48 + "' != '" + 7L + "'", long48 == 7L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 59L + "'", long50 == 59L);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertArrayEquals(intArray51, new int[] {});
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertArrayEquals(intArray57, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1L + "'", long67 == 1L);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 27 + "'", int79 == 27);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 29 + "'", int80 == 29);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 52 + "'", int81 == 52);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-120) + "'", int85 == (-120));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        int int23 = hypergeometricDistribution20.getSupportUpperBound();
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        boolean boolean25 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        double double26 = hypergeometricDistribution20.calculateNumericalVariance();
        hypergeometricDistribution20.reseedRandomGenerator((long) (-43));
        double double31 = hypergeometricDistribution20.cumulativeProbability((int) (byte) 10, 30);
        double double32 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 6.062015091933255d + "'", double26 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.8579581870861621d + "'", double31 == 0.8579581870861621d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 27.876288659793815d + "'", double32 == 27.876288659793815d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double21 = randomDataImpl14.nextT(5.298342365610589d);
        randomDataImpl14.reSeed((long) (short) 100);
        int[] intArray24 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c25 = new org.apache.commons.math3.random.Well19937c(intArray24);
        int[] intArray30 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c25.setSeed(intArray30);
        byte[] byteArray36 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c25.nextBytes(byteArray36);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl38 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c25);
        long long40 = well19937c25.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution44 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c25, 97, 52, (int) '4');
        int[] intArray46 = hypergeometricDistribution44.sample(66);
        double double48 = hypergeometricDistribution44.probability((-1));
        double double51 = hypergeometricDistribution44.cumulativeProbability(0, 97);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl52 = hypergeometricDistribution44.randomData;
        int int53 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution44);
        boolean boolean54 = hypergeometricDistribution44.isSupportConnected();
        int int55 = hypergeometricDistribution44.getNumberOfSuccesses();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "78) test307(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 54L + "'", long17 == 54L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.16553447164781487d) + "'", double21 == (-0.16553447164781487d));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertArrayEquals(intArray24, new int[] {});
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertArrayEquals(intArray30, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(randomDataImpl52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 26 + "'", int53 == 26);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        int int31 = randomDataImpl27.nextHypergeometric(100, 35, 18);
        randomDataImpl27.reSeed();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
// flaky "79) test308(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int31 + "' != '" + 7 + "'", int31 == 7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        org.apache.commons.math3.random.Well19937c well19937c23 = new org.apache.commons.math3.random.Well19937c(intArray22);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double51 = randomDataImpl14.nextGaussian(0.8758405348702564d, (double) (byte) 100);
        double double53 = randomDataImpl14.nextExponential(113.05550465257059d);
        int int56 = randomDataImpl14.nextPascal(66, 0.9840816620715105d);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "80) test310(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 56L + "'", long17 == 56L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-202.1467575811614d) + "'", double51 == (-202.1467575811614d));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 28.41532236944079d + "'", double53 == 28.41532236944079d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        double double41 = hypergeometricDistribution40.getNumericalMean();
        boolean boolean42 = hypergeometricDistribution40.isSupportConnected();
        int int43 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        int[] intArray44 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c45 = new org.apache.commons.math3.random.Well19937c(intArray44);
        int[] intArray50 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c45.setSeed(intArray50);
        byte[] byteArray56 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c45.nextBytes(byteArray56);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl58 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c45);
        long long60 = well19937c45.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution64 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c45, 97, 52, (int) '4');
        double double65 = hypergeometricDistribution64.getNumericalMean();
        double double67 = hypergeometricDistribution64.cumulativeProbability(2147483647);
        int[] intArray69 = hypergeometricDistribution64.sample(18);
        double double70 = hypergeometricDistribution64.calculateNumericalVariance();
        int int71 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution64);
        randomDataImpl14.reSeed();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "81) test311(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 74L + "'", long17 == 74L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 27.876288659793815d + "'", double41 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 27 + "'", int43 == 27);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertArrayEquals(intArray44, new int[] {});
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertArrayEquals(intArray50, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertArrayEquals(byteArray56, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1L + "'", long60 == 1L);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 27.876288659793815d + "'", double65 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertArrayEquals(intArray69, new int[] { 30, 24, 25, 32, 26, 27, 29, 29, 34, 27, 28, 28, 34, 28, 32, 30, 30, 25 });
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 6.062015091933255d + "'", double70 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 29 + "'", int71 == 29);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double22 = randomDataImpl14.nextBeta((double) 97, 1.7167355775177289d);
        randomDataImpl14.reSeedSecure((long) (short) 10);
        long long27 = randomDataImpl14.nextSecureLong((long) (-127), (long) 33);
        double double30 = randomDataImpl14.nextGamma(84.29631315677912d, (double) 51L);
        int[] intArray31 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c32 = new org.apache.commons.math3.random.Well19937c(intArray31);
        int[] intArray37 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c32.setSeed(intArray37);
        byte[] byteArray43 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c32.nextBytes(byteArray43);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c32);
        long long48 = randomDataImpl45.nextSecureLong((long) 0, (long) (short) 100);
        long long50 = randomDataImpl45.nextPoisson((double) 51L);
        int[] intArray51 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c52 = new org.apache.commons.math3.random.Well19937c(intArray51);
        int[] intArray57 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c52.setSeed(intArray57);
        byte[] byteArray63 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c52.nextBytes(byteArray63);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c52);
        long long67 = well19937c52.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution71 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c52, 97, 52, (int) '4');
        int[] intArray73 = hypergeometricDistribution71.sample(66);
        double double75 = hypergeometricDistribution71.probability((-1));
        double double78 = hypergeometricDistribution71.cumulativeProbability(0, 97);
        int int79 = randomDataImpl45.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int80 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution71);
        int int81 = hypergeometricDistribution71.getSampleSize();
        double double83 = hypergeometricDistribution71.cumulativeProbability(890769048);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "82) test312(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 8L + "'", long17 == 8L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9838194766581275d + "'", double22 == 0.9838194766581275d);
// flaky "39) test312(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-47L) + "'", long27 == (-47L));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3401.6932281888926d + "'", double30 == 3401.6932281888926d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertArrayEquals(intArray31, new int[] {});
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertArrayEquals(intArray37, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "21) test312(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long48 + "' != '" + 34L + "'", long48 == 34L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 59L + "'", long50 == 59L);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertArrayEquals(intArray51, new int[] {});
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertArrayEquals(intArray57, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1L + "'", long67 == 1L);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 27 + "'", int79 == 27);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 29 + "'", int80 == 29);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 52 + "'", int81 == 52);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.0d + "'", double83 == 1.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.probability(30);
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        int int27 = hypergeometricDistribution20.sample();
        int int28 = hypergeometricDistribution20.getSupportUpperBound();
        double double29 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.11170958385601967d + "'", double25 == 0.11170958385601967d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 30 + "'", int27 == 30);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 27.876288659793815d + "'", double29 == 27.876288659793815d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        hypergeometricDistribution20.reseedRandomGenerator(1385351496847528493L);
        boolean boolean28 = hypergeometricDistribution20.isSupportConnected();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl29 = hypergeometricDistribution20.randomData;
        hypergeometricDistribution20.reseedRandomGenerator(100L);
        double double33 = hypergeometricDistribution20.probability(0);
        double double35 = hypergeometricDistribution20.upperCumulativeProbability((-43));
        double double37 = hypergeometricDistribution20.probability((int) (short) -1);
        boolean boolean38 = hypergeometricDistribution20.isSupportConnected();
        int int39 = hypergeometricDistribution20.getSampleSize();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(randomDataImpl29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 52 + "'", int39 == 52);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double25 = hypergeometricDistribution20.cumulativeProbability(52);
        double double26 = hypergeometricDistribution20.getNumericalMean();
        double double28 = hypergeometricDistribution20.upperCumulativeProbability(29);
        org.apache.commons.math3.random.RandomGenerator randomGenerator29 = hypergeometricDistribution20.random;
        double double30 = hypergeometricDistribution20.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 27.876288659793815d + "'", double26 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.39945954962551267d + "'", double28 == 0.39945954962551267d);
        org.junit.Assert.assertNotNull(randomGenerator29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 27.876288659793815d + "'", double30 == 27.876288659793815d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int[] intArray22 = hypergeometricDistribution20.sample(66);
        double double24 = hypergeometricDistribution20.probability((-1));
        int int25 = hypergeometricDistribution20.sample();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl26 = hypergeometricDistribution20.randomData;
        long long28 = randomDataImpl26.nextPoisson(0.9999999943667335d);
        double double30 = randomDataImpl26.nextChiSquare(73.9900659457277d);
        int int33 = randomDataImpl26.nextBinomial(294342336, (double) (short) 1);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 30 + "'", int25 == 30);
        org.junit.Assert.assertNotNull(randomDataImpl26);
// flaky "83) test316(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
// flaky "40) test316(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double30 + "' != '" + 69.93689338758702d + "'", double30 == 69.93689338758702d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 294342336 + "'", int33 == 294342336);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeed((long) (byte) 0);
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeed();
        double double6 = randomDataGenerator0.nextChiSquare(0.08106146679532726d);
        randomDataGenerator0.reSeed(88L);
        int int12 = randomDataGenerator0.nextHypergeometric(1019069405, 1, (int) '#');
        double double15 = randomDataGenerator0.nextWeibull(0.2976801165557608d, 1.5836414305180074E-7d);
        double double19 = randomDataGenerator0.nextUniform(0.19532389929851823d, (double) 142995184, false);
// flaky "84) test317(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2724493430704897d + "'", double6 == 0.2724493430704897d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 9.012847790866286E-11d + "'", double15 == 9.012847790866286E-11d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 9.712771980818546E7d + "'", double19 == 9.712771980818546E7d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        int int22 = hypergeometricDistribution20.inverseCumulativeProbability(1.0030391140407694E-28d);
        double double23 = hypergeometricDistribution20.getNumericalMean();
        boolean boolean24 = hypergeometricDistribution20.isSupportConnected();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 7 + "'", int22 == 7);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 27.876288659793815d + "'", double23 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        int[] intArray20 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c(intArray20);
        int[] intArray26 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c21.setSeed(intArray26);
        byte[] byteArray32 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c21.nextBytes(byteArray32);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl34 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c21);
        long long36 = well19937c21.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution40 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c21, 97, 52, (int) '4');
        int[] intArray42 = hypergeometricDistribution40.sample(66);
        double double44 = hypergeometricDistribution40.probability((-1));
        double double47 = hypergeometricDistribution40.cumulativeProbability(0, 97);
        int int48 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution40);
        double double49 = hypergeometricDistribution40.getNumericalMean();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "85) test319(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 65L + "'", long17 == 65L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertArrayEquals(intArray20, new int[] {});
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertArrayEquals(intArray26, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 27 + "'", int48 == 27);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 27.876288659793815d + "'", double49 == 27.876288659793815d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long16 = well19937c1.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution20 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 97, 52, (int) '4');
        double double21 = hypergeometricDistribution20.getNumericalMean();
        double double23 = hypergeometricDistribution20.cumulativeProbability(2147483647);
        double double24 = hypergeometricDistribution20.getNumericalVariance();
        double double25 = hypergeometricDistribution20.getNumericalMean();
        int int26 = hypergeometricDistribution20.getSupportLowerBound();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl27 = hypergeometricDistribution20.randomData;
        // The following exception was thrown during execution in test generation
        try {
            double double30 = randomDataImpl27.nextCauchy(0.43100630820303915d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 27.876288659793815d + "'", double21 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 6.062015091933255d + "'", double24 == 6.062015091933255d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 27.876288659793815d + "'", double25 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertNotNull(randomDataImpl27);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int[] intArray0 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(intArray0);
        int[] intArray6 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c1.setSeed(intArray6);
        byte[] byteArray12 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c1.nextBytes(byteArray12);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long17 = randomDataImpl14.nextSecureLong((long) 0, (long) (short) 100);
        long long19 = randomDataImpl14.nextPoisson((double) 51L);
        double double22 = randomDataImpl14.nextBeta((double) 97, 1.7167355775177289d);
        randomDataImpl14.reSeedSecure((long) (short) 10);
        long long27 = randomDataImpl14.nextSecureLong((long) (-127), (long) 33);
        double double30 = randomDataImpl14.nextGamma(84.29631315677912d, (double) 51L);
        int[] intArray31 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c32 = new org.apache.commons.math3.random.Well19937c(intArray31);
        int[] intArray37 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c32.setSeed(intArray37);
        byte[] byteArray43 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c32.nextBytes(byteArray43);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl45 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c32);
        long long47 = well19937c32.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution51 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c32, 97, 52, (int) '4');
        double double52 = hypergeometricDistribution51.getNumericalMean();
        int int53 = randomDataImpl14.nextInversionDeviate((org.apache.commons.math3.distribution.IntegerDistribution) hypergeometricDistribution51);
        double double55 = hypergeometricDistribution51.probability(3);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertArrayEquals(intArray0, new int[] {});
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
// flaky "86) test321(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 59L + "'", long19 == 59L);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9838194766581275d + "'", double22 == 0.9838194766581275d);
// flaky "41) test321(org.apache.commons.math3.distribution.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-44L) + "'", long27 == (-44L));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3401.6932281888926d + "'", double30 == 3401.6932281888926d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertArrayEquals(intArray31, new int[] {});
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertArrayEquals(intArray37, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 27.876288659793815d + "'", double52 == 27.876288659793815d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 29 + "'", int53 == 29);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1L);
        long long3 = well19937c1.nextLong(10L);
        int[] intArray4 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c(intArray4);
        well19937c1.setSeed(intArray4);
        int[] intArray7 = new int[] {};
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int[] intArray13 = new int[] { ' ', (short) 0, 'a', (byte) 10 };
        well19937c8.setSeed(intArray13);
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        well19937c8.nextBytes(byteArray19);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c8);
        long long23 = well19937c8.nextLong(2L);
        org.apache.commons.math3.distribution.HypergeometricDistribution hypergeometricDistribution27 = new org.apache.commons.math3.distribution.HypergeometricDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c8, 97, 52, (int) '4');
        int[] intArray29 = hypergeometricDistribution27.sample(66);
        well19937c1.setSeed(intArray29);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator31 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataGenerator31.reSeed();
        randomDataGenerator31.reSeed();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertArrayEquals(intArray4, new int[] {});
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] {});
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertArrayEquals(intArray13, new int[] { 32, 0, 97, 10 });
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 74, (byte) -5, (byte) -45, (byte) -30 });
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(intArray29);
    }
}
