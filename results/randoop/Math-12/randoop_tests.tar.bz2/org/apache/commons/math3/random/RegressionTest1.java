package org.apache.commons.math3.random;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test501");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) (-1L), (double) 1.0f, (double) 1342499381265206610L);
        double double4 = logNormalDistribution3.getScale();
        double double5 = logNormalDistribution3.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test502");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double13 = randomDataGenerator10.nextBeta(3.7959526833814112d, 0.04232968535189235d);
        // The following exception was thrown during execution in test generation
        try {
            double double16 = randomDataGenerator10.nextBeta((double) (-356740149L), (-0.7615941559557649d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.166, 0.834]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9999813803112833d + "'", double13 == 0.9999813803112833d);
    }

    @Test
    public void test503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test503");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i2;
        boolean boolean8 = well19937c1.nextBoolean();
        long long9 = well19937c1.nextLong();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7258068567783673378L + "'", long9 == 7258068567783673378L);
    }

    @Test
    public void test504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test504");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double1 = normalDistribution0.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test505");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long5 = well19937c4.nextLong();
        double double6 = well19937c4.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray14 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c8.setSeed(intArray14);
        well19937c4.setSeed(intArray14);
        well19937c1.setSeed(intArray14);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double22 = randomDataGenerator18.nextUniform(0.36787944117144233d, (double) 1L, true);
        int[] intArray25 = randomDataGenerator18.nextPermutation((int) (short) 100, (int) 'a');
        well19937c1.setSeed(intArray25);
        double double27 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4418713979230659041L + "'", long5 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3934606808571868d + "'", double6 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertArrayEquals(intArray14, new int[] { 35, 0, 100, 10, 0 });
// flaky "1) test505(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.942126269795254d + "'", double22 == 0.942126269795254d);
        org.junit.Assert.assertNotNull(intArray25);
// flaky "1) test505(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.11315708163516702d + "'", double27 == 0.11315708163516702d);
    }

    @Test
    public void test506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test506");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double4 = gammaDistribution3.sample();
        double double5 = gammaDistribution3.getSupportLowerBound();
        // The following exception was thrown during execution in test generation
        try {
            double[] doubleArray7 = gammaDistribution3.sample((-1638252717));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (-1,638,252,717)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "2) test506(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.3462711697449485d + "'", double4 == 7.3462711697449485d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test507");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGaussian(1.5707963267948966d, 2.9496875887749894E19d);
        double double22 = randomDataImpl8.nextCauchy(0.08484461357703173d, 0.12578010714897697d);
        long long25 = randomDataImpl8.nextSecureLong((long) 45, 113L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0185362398551933E19d) + "'", double19 == (-3.0185362398551933E19d));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.09568586753240192d + "'", double22 == 0.09568586753240192d);
// flaky "3) test507(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long25 + "' != '" + 103L + "'", long25 == 103L);
    }

    @Test
    public void test508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test508");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(78);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution5 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 1260996712L, 0.14218002608626515d, (double) 45);
    }

    @Test
    public void test509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test509");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextBeta(97.0d, (double) (byte) 1);
        long long15 = randomDataGenerator0.nextLong(0L, (long) 61);
// flaky "4) test509(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.07281458741452862d + "'", double3 == 0.07281458741452862d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9830505425759046d + "'", double12 == 0.9830505425759046d);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 27L + "'", long15 == 27L);
    }

    @Test
    public void test510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test510");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        int[] intArray9 = well19937c1.i2;
        double double10 = well19937c1.nextDouble();
        double double11 = well19937c1.nextGaussian();
        well19937c1.setSeed((-67868903));
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5871973525778662d + "'", double10 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.5752922499850703d) + "'", double11 == (-1.5752922499850703d));
    }

    @Test
    public void test511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test511");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(0.2814278033199356d, 0.11570983766281182d, 0.5000000019399116d);
        boolean boolean4 = logNormalDistribution3.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test512");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        int int13 = randomDataImpl8.nextBinomial(0, 0.14218002608626515d);
        double double16 = randomDataImpl8.nextF(1.1102230246251565E-16d, 1.2487305599455705d);
        // The following exception was thrown during execution in test generation
        try {
            int int19 = randomDataImpl8.nextPascal(78, (double) 32.000004f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 32 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
// flaky "1) test512(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test513");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double2 = normalDistribution0.cumulativeProbability(5.1481760329336096E17d);
        double double3 = normalDistribution0.sample();
        double double4 = normalDistribution0.getSupportUpperBound();
        double double5 = normalDistribution0.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
// flaky "5) test513(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.7231947824497731d) + "'", double3 == (-0.7231947824497731d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test514");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        well19937c1.setSeed((long) 1);
        int[] intArray5 = well19937c1.iRm2;
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test515");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 99L, (double) 2940458407815999488L);
        double double3 = logNormalDistribution2.getNumericalMean();
        double double6 = logNormalDistribution2.cumulativeProbability((-2.7899699621137186d), 6.27147468593853E-47d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.49999999999999994d + "'", double6 == 0.49999999999999994d);
    }

    @Test
    public void test516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test516");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((-47));
        float float2 = well19937c1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.9967526f + "'", float2 == 0.9967526f);
    }

    @Test
    public void test517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test517");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = randomDataImpl8.nextSecureHexString((-53));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-53)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertNotNull(randomDataGenerator14);
    }

    @Test
    public void test518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test518");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        float float2 = well19937c1.nextFloat();
        int[] intArray3 = well19937c1.i3;
        long long4 = well19937c1.nextLong();
        int int5 = well19937c1.nextInt();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.7685776f + "'", float2 == 0.7685776f);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-5237091724125068965L) + "'", long4 == (-5237091724125068965L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 203303726 + "'", int5 == 203303726);
    }

    @Test
    public void test519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test519");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray9 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c3.setSeed(intArray9);
        well19937c1.setSeed(intArray9);
        org.apache.commons.math3.random.Well19937c well19937c12 = new org.apache.commons.math3.random.Well19937c(intArray9);
        java.lang.Class<?> wildcardClass13 = well19937c12.getClass();
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertArrayEquals(intArray9, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test520");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        well19937c1.setSeed((long) 1);
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        int[] intArray7 = well19937c6.i3;
        well19937c1.setSeed(intArray7);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c(intArray7);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution13 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c9, (double) (-356740149L), 0.14218002608626515d, (double) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test521");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double25 = logNormalDistribution17.probability((double) (-387737817), 0.0d);
        double double26 = logNormalDistribution17.getSupportLowerBound();
        double double28 = logNormalDistribution17.cumulativeProbability(0.0d);
        double double29 = logNormalDistribution17.getShape();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + Double.POSITIVE_INFINITY + "'", double29 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test522");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        int int15 = randomDataGenerator0.nextPascal((int) (byte) 1, 0.3934606808571868d);
        // The following exception was thrown during execution in test generation
        try {
            double double19 = randomDataGenerator0.nextUniform((double) 1378651682, (double) 646549088L, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,378,651,682) must be strictly less than upper bound (646,549,088)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "6) test522(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2240561716678755d + "'", double3 == 3.2240561716678755d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test523");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c8.nextBytes(byteArray12);
        int[] intArray14 = well19937c8.i3;
        double double15 = well19937c8.nextDouble();
        well19937c8.setSeed(32L);
        float float18 = well19937c8.nextFloat();
        org.apache.commons.math3.random.Well19937c well19937c20 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray24 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c20.nextBytes(byteArray24);
        int[] intArray26 = well19937c20.i3;
        double double27 = well19937c20.nextDouble();
        well19937c20.setSeed((long) (short) 1);
        long long30 = well19937c20.nextLong();
        byte[] byteArray31 = new byte[] {};
        well19937c20.nextBytes(byteArray31);
        well19937c8.nextBytes(byteArray31);
        well19937c1.nextBytes(byteArray31);
        int int35 = well19937c1.nextInt();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9066258578518134d + "'", double15 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.7685776f + "'", float18 == 0.7685776f);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.9066258578518134d + "'", double27 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1342499381265206610L + "'", long30 == 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1689900776 + "'", int35 == 1689900776);
    }

    @Test
    public void test524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test524");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextGamma((double) 6, (double) 646549088L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.538665724985926E9d + "'", double15 == 4.538665724985926E9d);
    }

    @Test
    public void test525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test525");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        java.lang.String str15 = randomDataImpl8.nextSecureHexString((int) '4');
        // The following exception was thrown during execution in test generation
        try {
            double double18 = randomDataImpl8.nextGaussian(0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
// flaky "7) test525(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str15 + "' != '" + "91c34d9ef0dc8c41a7436a47a09a7a07f595b2dd6599e078382c" + "'", str15, "91c34d9ef0dc8c41a7436a47a09a7a07f595b2dd6599e078382c");
    }

    @Test
    public void test526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test526");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double23 = logNormalDistribution17.cumulativeProbability(0.0d, (double) 1342499381265206610L);
        double double24 = logNormalDistribution17.getSupportLowerBound();
        boolean boolean25 = logNormalDistribution17.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test527");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        double double13 = randomDataImpl8.nextUniform(0.5176464628744074d, 1.0847303959306388E27d);
        double double15 = randomDataImpl8.nextExponential((double) 127.0f);
        long long17 = randomDataImpl8.nextPoisson(0.9345329978999833d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
// flaky "8) test527(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0080855956935976E27d + "'", double13 == 1.0080855956935976E27d);
// flaky "2) test527(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 46.316417028472706d + "'", double15 == 46.316417028472706d);
// flaky "1) test527(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test528");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        double double20 = randomDataImpl8.nextUniform(0.0d, 0.5000000013965371d);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str22 = randomDataImpl8.nextSecureHexString((-42005975));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-42,005,975)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.27433221325624985d + "'", double20 == 0.27433221325624985d);
    }

    @Test
    public void test529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test529");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            int int7 = randomDataGenerator0.nextSecureInt(1689900776, 564472600);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,689,900,776) must be strictly less than upper bound (564,472,600)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "9) test529(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.03659339659649939d + "'", double3 == 0.03659339659649939d);
    }

    @Test
    public void test530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test530");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        int int12 = randomDataGenerator9.nextInt(6, 92410965);
        // The following exception was thrown during execution in test generation
        try {
            int int15 = randomDataGenerator9.nextBinomial(1219788447, (double) 4986124084203277738L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 4,986,124,084,203,277,300 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 83782171 + "'", int12 == 83782171);
    }

    @Test
    public void test531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test531");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test532");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        java.lang.String str11 = randomDataGenerator9.nextHexString((int) (short) 10);
        int[] intArray14 = randomDataGenerator9.nextPermutation((int) '#', 2);
        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c(intArray14);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "6121986868" + "'", str11, "6121986868");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertArrayEquals(intArray14, new int[] { 11, 5 });
    }

    @Test
    public void test533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test533");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        double double18 = randomDataImpl8.nextCauchy(0.2170872048711684d, 4.644339562383774d);
        int int21 = randomDataImpl8.nextInt((-2147483648), (-1219355438));
        double double23 = randomDataImpl8.nextChiSquare(0.12578010714897697d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.3686073898357964d + "'", double18 == 1.3686073898357964d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1638252717) + "'", int21 == (-1638252717));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0772493686785972E-6d + "'", double23 == 1.0772493686785972E-6d);
    }

    @Test
    public void test534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test534");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        double double8 = gammaDistribution3.getShape();
        boolean boolean9 = gammaDistribution3.isSupportConnected();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6233479763570439d + "'", double8 == 0.6233479763570439d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test535");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        // The following exception was thrown during execution in test generation
        try {
            double double13 = randomDataImpl8.nextUniform(0.4909240332679956d, (-0.14476482730108392d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0.491) must be strictly less than upper bound (-0.145)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
    }

    @Test
    public void test536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test536");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        double double13 = randomDataImpl8.nextUniform(0.5176464628744074d, 1.0847303959306388E27d);
        randomDataImpl8.reSeedSecure((-102499044L));
        // The following exception was thrown during execution in test generation
        try {
            double double18 = randomDataImpl8.nextWeibull(0.0d, (double) 127.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
// flaky "10) test536(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.747573938536377E26d + "'", double13 == 4.747573938536377E26d);
    }

    @Test
    public void test537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test537");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getNumericalVariance();
        double[] doubleArray8 = gammaDistribution3.sample(61);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5865.081109543426d + "'", double6 == 5865.081109543426d);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test538");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long5 = well19937c4.nextLong();
        double double6 = well19937c4.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray14 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c8.setSeed(intArray14);
        well19937c4.setSeed(intArray14);
        well19937c1.setSeed(intArray14);
        org.apache.commons.math3.random.Well19937c well19937c19 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray23 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c19.nextBytes(byteArray23);
        well19937c1.nextBytes(byteArray23);
        int[] intArray26 = well19937c1.iRm1;
        well19937c1.setSeed((long) 2);
        well19937c1.setSeed((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4418713979230659041L + "'", long5 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3934606808571868d + "'", double6 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertArrayEquals(intArray14, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] { (byte) -35, (byte) -112, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test539");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        boolean boolean5 = normalDistribution2.isSupportConnected();
        double double7 = normalDistribution2.probability((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test540");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        java.lang.String str10 = randomDataGenerator0.nextSecureHexString((int) '4');
        double double13 = randomDataGenerator0.nextGamma((double) 100.00001f, (double) 2147483647);
        double double15 = randomDataGenerator0.nextExponential(0.5113968871894786d);
        // The following exception was thrown during execution in test generation
        try {
            double double17 = randomDataGenerator0.nextChiSquare((-0.9999999999999999d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.5)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "11) test540(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000016593535d + "'", double5 == 0.5000000016593535d);
// flaky "3) test540(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-44172188L) + "'", long8 == (-44172188L));
// flaky "2) test540(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str10 + "' != '" + "aa94e4728a905399fd24f953baaf89fa173331984e2e29e9a611" + "'", str10, "aa94e4728a905399fd24f953baaf89fa173331984e2e29e9a611");
// flaky "2) test540(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.267334821470258E11d + "'", double13 == 2.267334821470258E11d);
// flaky "1) test540(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.028153744581638676d + "'", double15 == 0.028153744581638676d);
    }

    @Test
    public void test541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test541");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long5 = well19937c4.nextLong();
        double double6 = well19937c4.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray14 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c8.setSeed(intArray14);
        well19937c4.setSeed(intArray14);
        well19937c1.setSeed(intArray14);
        org.apache.commons.math3.random.Well19937c well19937c19 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray23 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c19.nextBytes(byteArray23);
        well19937c1.nextBytes(byteArray23);
        double double26 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution30 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-1.796321317031409d), 2.1289324036886282E7d, 1.0165636493959576d);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4418713979230659041L + "'", long5 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3934606808571868d + "'", double6 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertArrayEquals(intArray14, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] { (byte) -35, (byte) -112, (byte) 82 });
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.27530807973333826d + "'", double26 == 0.27530807973333826d);
    }

    @Test
    public void test542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test542");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(0.22969314751614026d, 6.459010142387964E26d);
        double double4 = normalDistribution2.cumulativeProbability(0.3510058119179424d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

    @Test
    public void test543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test543");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        double double9 = randomDataGenerator0.nextUniform((double) (short) -1, (-0.8177111776375223d));
        long long12 = randomDataGenerator0.nextSecureLong(0L, (long) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = randomDataGenerator0.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "12) test543(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7287674006914642d + "'", double3 == 0.7287674006914642d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
// flaky "4) test543(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8322190683044411d) + "'", double9 == (-0.8322190683044411d));
// flaky "2) test543(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test544");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        well19937c1.setSeed((long) 1);
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        int[] intArray7 = well19937c6.i3;
        well19937c1.setSeed(intArray7);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c(intArray7);
        byte[] byteArray10 = new byte[] {};
        well19937c9.nextBytes(byteArray10);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution15 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c9, (double) 3, 0.6233479763570439d, (double) 4986124084203277738L);
        double double16 = gammaDistribution15.getNumericalMean();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.8700439290711315d + "'", double16 == 1.8700439290711315d);
    }

    @Test
    public void test545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test545");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        boolean boolean8 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double9 = gammaDistribution3.getAlpha();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.6233479763570439d + "'", double9 == 0.6233479763570439d);
    }

    @Test
    public void test546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test546");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        float float11 = well19937c1.nextFloat();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution15 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 3.79226455416768d, (double) 4418713979230659041L, 10.302538425400456d);
        double double16 = gammaDistribution15.getSupportUpperBound();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.7685776f + "'", float11 == 0.7685776f);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + Double.POSITIVE_INFINITY + "'", double16 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test547");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        double double17 = randomDataImpl8.nextT(1.5287994033960568d);
        int int20 = randomDataImpl8.nextPascal((int) 'a', 0.021696876432501823d);
        int int23 = randomDataImpl8.nextInt(601, 251174);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.22969314751614026d + "'", double17 == 0.22969314751614026d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4414 + "'", int20 == 4414);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 105094 + "'", int23 == 105094);
    }

    @Test
    public void test548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test548");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("3b81bf4ab79777fa9edcaf3aba2df537def7baad9bd0410bae279c467393ed469975b2dd95de16eece09f8d5124b90241", "25ac176c2cd11f249ece744374d53160dc5ff0e2a7fa06de7fec");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 25ac176c2cd11f249ece744374d53160dc5ff0e2a7fa06de7fec");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
// flaky "13) test548(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.59712538389806d + "'", double3 == 10.59712538389806d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
    }

    @Test
    public void test549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test549");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.sample();
        double double7 = normalDistribution2.probability(6.27147468593853E-47d);
        double double9 = normalDistribution2.probability((double) (-85092646L));
        double double11 = normalDistribution2.density((-0.07783207834478786d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
// flaky "14) test549(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-6.167681897831368d) + "'", double5 == (-6.167681897831368d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0396631697437961d + "'", double11 == 0.0396631697437961d);
    }

    @Test
    public void test550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test550");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        int int4 = well19937c1.next((int) '4');
        well19937c1.setSeed((long) 326573780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 251174 + "'", int4 == 251174);
    }

    @Test
    public void test551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test551");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 10.0f, 5.16069461171411d, (double) 45.000004f);
    }

    @Test
    public void test552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test552");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double4 = randomDataGenerator0.nextUniform(0.36787944117144233d, (double) 1L, true);
        int[] intArray7 = randomDataGenerator0.nextPermutation((int) (short) 100, (int) 'a');
        int int11 = randomDataGenerator0.nextHypergeometric(40334114, 86, (int) (short) 10);
// flaky "15) test552(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7878000471516149d + "'", double4 == 0.7878000471516149d);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test553");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long5 = well19937c4.nextLong();
        double double6 = well19937c4.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray14 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c8.setSeed(intArray14);
        well19937c4.setSeed(intArray14);
        well19937c1.setSeed(intArray14);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double22 = randomDataGenerator18.nextUniform(0.36787944117144233d, (double) 1L, true);
        int[] intArray25 = randomDataGenerator18.nextPermutation((int) (short) 100, (int) 'a');
        well19937c1.setSeed(intArray25);
        float float27 = well19937c1.nextFloat();
        int int28 = well19937c1.nextInt();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4418713979230659041L + "'", long5 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3934606808571868d + "'", double6 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertArrayEquals(intArray14, new int[] { 35, 0, 100, 10, 0 });
// flaky "16) test553(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5013075180596978d + "'", double22 == 0.5013075180596978d);
        org.junit.Assert.assertNotNull(intArray25);
// flaky "5) test553(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.72421145f + "'", float27 == 0.72421145f);
// flaky "3) test553(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int28 + "' != '" + 436519583 + "'", int28 == 436519583);
    }

    @Test
    public void test554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test554");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        boolean boolean6 = gammaDistribution3.isSupportUpperBoundInclusive();
        double[] doubleArray8 = gammaDistribution3.sample(78);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test555");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double9 = gammaDistribution3.density(1.5223961928507554d);
        boolean boolean10 = gammaDistribution3.isSupportUpperBoundInclusive();
        boolean boolean11 = gammaDistribution3.isSupportUpperBoundInclusive();
        // The following exception was thrown during execution in test generation
        try {
            double double14 = gammaDistribution3.cumulativeProbability((double) 94.0f, 1.1023228955491779E-4d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (94) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.03374688752732189d + "'", double9 == 0.03374688752732189d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test556");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getScale();
        double[] doubleArray23 = logNormalDistribution17.sample((int) '4');
        boolean boolean24 = logNormalDistribution17.isSupportConnected();
        double double25 = logNormalDistribution17.sample();
        // The following exception was thrown during execution in test generation
        try {
            double double28 = logNormalDistribution17.probability(0.17844868096790079d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.178) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test557");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution16 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 100.0f, 1.0219671297446623E-9d, 0.0d);
        well19937c1.setSeed((-372572774L));
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution22 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.942126269795254d, 0.04163004976210974d, 16.39959540883049d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
    }

    @Test
    public void test558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test558");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double19 = logNormalDistribution17.cumulativeProbability((double) (-93467950L));
        double double22 = logNormalDistribution17.cumulativeProbability(3.29929710651543E-7d, 7.672868603936274d);
        double double23 = logNormalDistribution17.getNumericalVariance();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test559");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(7.105427357601002E-15d, (double) 111L);
    }

    @Test
    public void test560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test560");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(0.0d, (double) (-372572774L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-372,572,774)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test561");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        int int3 = well19937c1.nextInt();
        well19937c1.index = (-401038879);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = well19937c1.nextInt();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index -401038879 out of bounds for length 624");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-401038879) + "'", int3 == (-401038879));
    }

    @Test
    public void test562() {}
// Defects4J: flaky method
//     @Test
//     public void test562() throws Throwable {
//         if (debug)
//             System.out.format("%n%s%n", "RegressionTest1.test562");
//         org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//         randomDataGenerator0.reSeedSecure((long) (short) 1);
//         double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
//         long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
//         java.lang.String str10 = randomDataGenerator0.nextSecureHexString((int) '4');
//         double double13 = randomDataGenerator0.nextGamma((double) 100.00001f, (double) 2147483647);
//         double double15 = randomDataGenerator0.nextExponential(0.5113968871894786d);
//         java.lang.String str17 = randomDataGenerator0.nextSecureHexString(6);
//         int int20 = randomDataGenerator0.nextZipf((int) (byte) 100, 4.7421875d);
// // flaky "17) test562(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.500000001509443d + "'", double5 == 0.500000001509443d);
// // flaky "6) test562(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-198193290L) + "'", long8 == (-198193290L));
// // flaky "4) test562(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str10 + "' != '" + "a933ea6a49cbdf7d4c9dcb28f5c83a4bd6cd54b5cc437ea0ef66" + "'", str10, "a933ea6a49cbdf7d4c9dcb28f5c83a4bd6cd54b5cc437ea0ef66");
// // flaky "3) test562(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6783594707990063E11d + "'", double13 == 2.6783594707990063E11d);
// // flaky "3) test562(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.16568798406504834d + "'", double15 == 0.16568798406504834d);
// // flaky "1) test562(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str17 + "' != '" + "0cf80e" + "'", str17, "0cf80e");
//         org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//     }

    @Test
    public void test563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test563");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 10);
        double double15 = randomDataImpl8.nextWeibull(0.8260983859017907d, 11.292664999650361d);
        double double18 = randomDataImpl8.nextWeibull(21.23248944257666d, 1.0080855956935976E27d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.216112110971814d + "'", double15 == 52.216112110971814d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.00508378145291E27d + "'", double18 == 1.00508378145291E27d);
    }

    @Test
    public void test564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test564");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double13 = randomDataGenerator10.nextBeta(3.7959526833814112d, 0.04232968535189235d);
        // The following exception was thrown during execution in test generation
        try {
            double double16 = randomDataGenerator10.nextCauchy(4.89392748244002d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9999813803112833d + "'", double13 == 0.9999813803112833d);
    }

    @Test
    public void test565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test565");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeedSecure(0L);
        double double14 = randomDataGenerator0.nextUniform(1.9283289552270317d, 4.7421875d);
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            long long18 = randomDataGenerator0.nextSecureLong(4L, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (4) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "18) test565(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000015154837d + "'", double5 == 0.5000000015154837d);
// flaky "7) test565(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-294661972L) + "'", long8 == (-294661972L));
// flaky "5) test565(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.8129098456690427d + "'", double14 == 3.8129098456690427d);
    }

    @Test
    public void test566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test566");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.sample();
        double double7 = normalDistribution2.probability(6.27147468593853E-47d);
        double double8 = normalDistribution2.getMean();
        double double10 = normalDistribution2.density(2.8957779288675325d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
// flaky "19) test566(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.221339702703528d + "'", double5 == 7.221339702703528d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.03918373679395073d + "'", double10 == 0.03918373679395073d);
    }

    @Test
    public void test567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test567");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            double double16 = randomDataImpl8.nextWeibull((double) (-127.0f), 16.39959540883049d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-127)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test568");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 4);
    }

    @Test
    public void test569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test569");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator22 = randomDataImpl8.getDelegate();
        int int25 = randomDataGenerator22.nextPascal(1117624816, 0.9420150969290588d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertNotNull(randomDataGenerator22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 68793477 + "'", int25 == 68793477);
    }

    @Test
    public void test570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test570");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        java.lang.String str17 = randomDataImpl8.nextSecureHexString((int) '4');
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution20 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        boolean boolean21 = normalDistribution20.isSupportLowerBoundInclusive();
        double double24 = normalDistribution20.cumulativeProbability(1.7453292519943298E-11d, 1.0E-6d);
        double double25 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution20);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
// flaky "20) test570(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str17 + "' != '" + "54ede6b94d998274495d554f176eb41d1c2e7a7e851fc526f854" + "'", str17, "54ede6b94d998274495d554f176eb41d1c2e7a7e851fc526f854");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.96945621303213E-8d + "'", double24 == 3.96945621303213E-8d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.9514901780620963d + "'", double25 == 2.9514901780620963d);
    }

    @Test
    public void test571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test571");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        double double8 = gammaDistribution3.getSupportUpperBound();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test572");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            double double13 = randomDataGenerator10.nextUniform(5.2034133211676d, (double) 7.6293945E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (5.203) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
    }

    @Test
    public void test573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test573");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextF(0.22497942976198554d, 0.3934606808571868d);
        double double15 = randomDataImpl8.nextCauchy((double) 0.0f, 0.08484461357703173d);
        randomDataImpl8.reSeedSecure();
        int int19 = randomDataImpl8.nextSecureInt((int) (short) 100, 614504715);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str21 = randomDataImpl8.nextSecureHexString((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2044.5491797688765d + "'", double12 == 2044.5491797688765d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.053473722883958005d) + "'", double15 == (-0.053473722883958005d));
// flaky "21) test573(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int19 + "' != '" + 304547454 + "'", int19 == 304547454);
    }

    @Test
    public void test574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test574");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 99L, (double) 2940458407815999488L);
        double double3 = logNormalDistribution2.sample();
        boolean boolean4 = logNormalDistribution2.isSupportUpperBoundInclusive();
// flaky "8) test574(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test575");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        double double6 = randomDataGenerator0.nextGaussian(0.7801559393041577d, 1.0E-6d);
        double double9 = randomDataGenerator0.nextCauchy((double) 0.32099235f, 0.16676169823315717d);
// flaky "22) test575(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.830448546126596d + "'", double3 == 0.830448546126596d);
// flaky "9) test575(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7801551907132278d + "'", double6 == 0.7801551907132278d);
// flaky "6) test575(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2386872780585933d + "'", double9 == 0.2386872780585933d);
    }

    @Test
    public void test576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test576");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        double double13 = randomDataImpl8.nextUniform(0.5176464628744074d, 1.0847303959306388E27d);
        double double15 = randomDataImpl8.nextExponential((double) 127.0f);
        long long18 = randomDataImpl8.nextLong((long) 105094, 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
// flaky "23) test576(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.1911281597073676E26d + "'", double13 == 3.1911281597073676E26d);
// flaky "10) test576(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 21.069856428597582d + "'", double15 == 21.069856428597582d);
// flaky "7) test576(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1248430658986503424L + "'", long18 == 1248430658986503424L);
    }

    @Test
    public void test577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test577");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getScale();
        double[] doubleArray23 = logNormalDistribution17.sample((int) '4');
        boolean boolean24 = logNormalDistribution17.isSupportConnected();
        double double27 = logNormalDistribution17.cumulativeProbability((double) 3.8146973E-6f, 2.444636125884939d);
        double double28 = logNormalDistribution17.getNumericalVariance();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + Double.POSITIVE_INFINITY + "'", double28 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test578");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double18 = logNormalDistribution17.getSupportLowerBound();
        double double19 = logNormalDistribution17.getSupportLowerBound();
        double double20 = logNormalDistribution17.getSupportUpperBound();
        logNormalDistribution17.reseedRandomGenerator((-333573471L));
        double double23 = logNormalDistribution17.getShape();
        double double24 = logNormalDistribution17.getNumericalVariance();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test579");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        double double16 = randomDataImpl8.nextCauchy((-0.22956741260942515d), 0.42237388970532813d);
        // The following exception was thrown during execution in test generation
        try {
            long long19 = randomDataImpl8.nextSecureLong((long) 564472576, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (564,472,576) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.431831491070752d) + "'", double16 == (-0.431831491070752d));
    }

    @Test
    public void test580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test580");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        int int5 = well19937c1.next((int) ' ');
        well19937c1.setSeed((int) (short) 10);
        well19937c1.setSeed((-86338835L));
        int int10 = well19937c1.nextInt();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 646549088 + "'", int5 == 646549088);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1829961344 + "'", int10 == 1829961344);
    }

    @Test
    public void test581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test581");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        double double11 = well19937c1.nextDouble();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray13 = well19937c1.i1;
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.3934606808571868d, 81.87241173283697d, 0.0d);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution21 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (short) 10, 0.5992615271016185d, 0.0d);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test582");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        double double3 = logNormalDistribution2.getScale();
        boolean boolean4 = logNormalDistribution2.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 205.35258171903948d + "'", double3 == 205.35258171903948d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test583");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution14 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8822285080719574d, 0.5456928232039928d, (double) 32L);
        double double15 = gammaDistribution14.getNumericalMean();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.48142576528083303d + "'", double15 == 0.48142576528083303d);
    }

    @Test
    public void test584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test584");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator22 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            int int25 = randomDataGenerator22.nextSecureInt(779560061, (-53));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (779,560,061) must be strictly less than upper bound (-53)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertNotNull(randomDataGenerator22);
    }

    @Test
    public void test585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test585");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        well19937c1.setSeed((long) 1);
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        int[] intArray7 = well19937c6.i3;
        well19937c1.setSeed(intArray7);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c(intArray7);
        byte[] byteArray10 = new byte[] {};
        well19937c9.nextBytes(byteArray10);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution15 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c9, (double) 3, 0.6233479763570439d, (double) 4986124084203277738L);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c9);
        well19937c9.setSeed(149435855);
        long long19 = well19937c9.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-8895791743399485995L) + "'", long19 == (-8895791743399485995L));
    }

    @Test
    public void test586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test586");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        double double15 = randomDataImpl8.nextT(2.0d);
        randomDataImpl8.reSeedSecure(1L);
        double double20 = randomDataImpl8.nextUniform(0.011393699429840523d, 2.985601297522666E25d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "24) test586(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7874548671504324d + "'", double15 == 0.7874548671504324d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.7669280302913183E25d + "'", double20 == 1.7669280302913183E25d);
    }

    @Test
    public void test587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test587");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        java.lang.String str15 = randomDataImpl8.nextHexString(6);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "d1fc1b" + "'", str15, "d1fc1b");
    }

    @Test
    public void test588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test588");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        long long3 = well19937c1.nextLong();
        well19937c1.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1722448868039600408L) + "'", long3 == (-1722448868039600408L));
    }

    @Test
    public void test589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test589");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(46.81107899629717d, 0.0d, 0.956261572867373d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test590");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        java.lang.String str10 = randomDataGenerator0.nextSecureHexString((int) '4');
        int int13 = randomDataGenerator0.nextInt(0, 31);
        // The following exception was thrown during execution in test generation
        try {
            double double15 = randomDataGenerator0.nextExponential((double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "25) test590(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "11) test590(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-133285341L) + "'", long8 == (-133285341L));
// flaky "8) test590(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str10 + "' != '" + "7e6a4270cbec34dac36c886b3c29e5bb1a12bbbe56bb63341314" + "'", str10, "7e6a4270cbec34dac36c886b3c29e5bb1a12bbbe56bb63341314");
// flaky "4) test590(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test591");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeed();
        double double6 = randomDataGenerator0.nextT((double) 2);
        randomDataGenerator0.reSeedSecure();
// flaky "26) test591(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2557907418765898d + "'", double3 == 0.2557907418765898d);
// flaky "12) test591(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.6242394719109301d) + "'", double6 == (-0.6242394719109301d));
    }

    @Test
    public void test592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test592");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray9 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c3.setSeed(intArray9);
        well19937c1.setSeed(intArray9);
        org.apache.commons.math3.random.Well19937c well19937c12 = new org.apache.commons.math3.random.Well19937c(intArray9);
        double double13 = well19937c12.nextDouble();
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertArrayEquals(intArray9, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5871973525778662d + "'", double13 == 0.5871973525778662d);
    }

    @Test
    public void test593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test593");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getScale();
        boolean boolean7 = gammaDistribution3.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test594");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        int int2 = well19937c0.next((int) (byte) 100);
        well19937c0.setSeed((-401038879));
        int[] intArray5 = well19937c0.i3;
        org.apache.commons.math3.random.Well19937c well19937c7 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c7.nextBytes(byteArray11);
        int[] intArray13 = well19937c7.i3;
        org.apache.commons.math3.random.Well19937c well19937c14 = new org.apache.commons.math3.random.Well19937c(intArray13);
        well19937c0.setSeed(intArray13);
        org.apache.commons.math3.random.Well19937c well19937c16 = new org.apache.commons.math3.random.Well19937c(intArray13);
// flaky "13) test594(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test595");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(4);
    }

    @Test
    public void test596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test596");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        // The following exception was thrown during execution in test generation
        try {
            double double19 = randomDataImpl8.nextChiSquare((-1.4165028871298073d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.708)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
    }

    @Test
    public void test597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test597");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        boolean boolean3 = well19937c1.nextBoolean();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int6 = well19937c1.next((-42005975));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
    }

    @Test
    public void test598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test598");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray9 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c3.setSeed(intArray9);
        well19937c1.setSeed(intArray9);
        org.apache.commons.math3.random.Well19937c well19937c13 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray21 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c15.setSeed(intArray21);
        well19937c13.setSeed(intArray21);
        well19937c1.setSeed(intArray21);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertArrayEquals(intArray9, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertArrayEquals(intArray21, new int[] { 35, 0, 100, 10, 0 });
    }

    @Test
    public void test599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test599");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextUniform(0.0d, 3.310625339433012d);
        double double9 = randomDataGenerator0.nextUniform(0.0d, (double) 10.0f, true);
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("a20eacd2e00e09a64d73f8aa3868e7f7", "32fbf");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 32fbf");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
// flaky "27) test599(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.903862242358846d + "'", double5 == 2.903862242358846d);
// flaky "14) test599(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.401946509926914d + "'", double9 == 8.401946509926914d);
    }

    @Test
    public void test600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test600");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(1689900776);
    }

    @Test
    public void test601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test601");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        float float2 = well19937c1.nextFloat();
        int[] intArray3 = well19937c1.iRm1;
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.7685776f + "'", float2 == 0.7685776f);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test602");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double2 = normalDistribution0.inverseCumulativeProbability((double) 0);
        double double3 = normalDistribution0.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test603");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(32.00000381469727d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test604");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        gammaDistribution3.reseedRandomGenerator((long) 4);
        double[] doubleArray11 = gammaDistribution3.sample(61);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test605");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeedSecure((long) (byte) 0);
        double double7 = randomDataGenerator0.nextExponential(Double.POSITIVE_INFINITY);
        double double10 = randomDataGenerator0.nextWeibull(2.4241533998767024d, 1.3499054764695417d);
// flaky "28) test605(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.3824544814736583d + "'", double3 == 2.3824544814736583d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
// flaky "15) test605(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.7123953577670994d + "'", double10 == 1.7123953577670994d);
    }

    @Test
    public void test606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test606");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = randomDataImpl8.getDelegate();
        long long16 = randomDataGenerator14.nextPoisson(81.87241173283697d);
        // The following exception was thrown during execution in test generation
        try {
            int int19 = randomDataGenerator14.nextPascal((-3), 1.1990168853066976d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of successes (-3)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertNotNull(randomDataGenerator14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 70L + "'", long16 == 70L);
    }

    @Test
    public void test607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test607");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long5 = well19937c4.nextLong();
        double double6 = well19937c4.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray14 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c8.setSeed(intArray14);
        well19937c4.setSeed(intArray14);
        well19937c1.setSeed(intArray14);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double22 = randomDataGenerator18.nextUniform(0.36787944117144233d, (double) 1L, true);
        int[] intArray25 = randomDataGenerator18.nextPermutation((int) (short) 100, (int) 'a');
        well19937c1.setSeed(intArray25);
        float float27 = well19937c1.nextFloat();
        long long28 = well19937c1.nextLong();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl29 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4418713979230659041L + "'", long5 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3934606808571868d + "'", double6 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertArrayEquals(intArray14, new int[] { 35, 0, 100, 10, 0 });
// flaky "29) test607(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9016541606579543d + "'", double22 == 0.9016541606579543d);
        org.junit.Assert.assertNotNull(intArray25);
// flaky "16) test607(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5453615f + "'", float27 == 0.5453615f);
// flaky "9) test607(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long28 + "' != '" + 7411010141427053904L + "'", long28 == 7411010141427053904L);
    }

    @Test
    public void test608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test608");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        boolean boolean3 = well19937c1.nextBoolean();
        int int5 = well19937c1.next((int) (byte) 0);
        int int7 = well19937c1.next(13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-401038879) + "'", int5 == (-401038879));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3223 + "'", int7 == 3223);
    }

    @Test
    public void test609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test609");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double24 = logNormalDistribution17.getSupportUpperBound();
        boolean boolean25 = logNormalDistribution17.isSupportConnected();
        boolean boolean26 = logNormalDistribution17.isSupportConnected();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test610");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(0.0d, (double) 32);
    }

    @Test
    public void test611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test611");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        double double7 = randomDataGenerator0.nextChiSquare(0.19335986621811754d);
        double double10 = randomDataGenerator0.nextUniform((-0.11563859552454996d), 0.1752614876109332d);
        int int13 = randomDataGenerator0.nextSecureInt(0, 8);
// flaky "30) test611(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "17) test611(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.308574685270866E-5d + "'", double7 == 1.308574685270866E-5d);
// flaky "10) test611(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.06446553757309392d + "'", double10 == 0.06446553757309392d);
// flaky "5) test611(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
    }

    @Test
    public void test612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test612");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        randomDataGenerator0.reSeedSecure();
        java.lang.String str8 = randomDataGenerator0.nextSecureHexString((int) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            double double10 = randomDataGenerator0.nextChiSquare(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "31) test612(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.025375983036818095d) + "'", double3 == (-0.025375983036818095d));
// flaky "18) test612(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str8 + "' != '" + "7" + "'", str8, "7");
    }

    @Test
    public void test613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test613");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        // The following exception was thrown during execution in test generation
        try {
            int int16 = randomDataImpl8.nextHypergeometric(436519583, 564472576, 78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (564,472,576) must be less than or equal to population size (436,519,583)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test614");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) (-1L), (double) 1.0f, (double) 1342499381265206610L);
        double double4 = logNormalDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6065306597126334d + "'", double4 == 0.6065306597126334d);
    }

    @Test
    public void test615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test615");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        int[] intArray14 = well19937c1.iRm1;
        org.apache.commons.math3.random.Well19937c well19937c16 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray20 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c16.nextBytes(byteArray20);
        int[] intArray22 = well19937c16.i3;
        double double23 = well19937c16.nextDouble();
        well19937c16.setSeed((long) (short) 1);
        long long26 = well19937c16.nextLong();
        byte[] byteArray27 = new byte[] {};
        well19937c16.nextBytes(byteArray27);
        well19937c1.nextBytes(byteArray27);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl30 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.9066258578518134d + "'", double23 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1342499381265206610L + "'", long26 == 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] {});
    }

    @Test
    public void test616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test616");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        int[] intArray7 = new int[] { (short) -1, 646549088, 6, (-401038879) };
        well19937c1.setSeed(intArray7);
        well19937c1.setSeed((long) 'a');
        org.apache.commons.math3.random.Well19937c well19937c12 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int13 = well19937c12.index;
        boolean boolean14 = well19937c12.nextBoolean();
        int[] intArray15 = well19937c12.iRm1;
        well19937c1.setSeed(intArray15);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution20 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 7.221339702703528d, (-0.2234590896900435d), 0.009524136469412987d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.223)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { (-1), 646549088, 6, (-401038879) });
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test617");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution16 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 100.0f, 1.0219671297446623E-9d, 0.0d);
        double double17 = logNormalDistribution16.getNumericalVariance();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test618");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getBeta();
        double double9 = gammaDistribution3.getSupportUpperBound();
        double double10 = gammaDistribution3.getNumericalVariance();
        double double12 = gammaDistribution3.cumulativeProbability(4.7421875d);
        double double13 = gammaDistribution3.getSupportUpperBound();
        double double15 = gammaDistribution3.density(0.16568798406504834d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5865.081109543426d + "'", double10 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.1668524405453939d + "'", double12 == 0.1668524405453939d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.07890655923424245d + "'", double15 == 0.07890655923424245d);
    }

    @Test
    public void test619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test619");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextDouble();
        well19937c1.setSeed((long) (short) 0);
        int int12 = well19937c1.index;
        int int13 = well19937c1.nextInt();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32099235282147576d + "'", double9 == 0.32099235282147576d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1102768644) + "'", int13 == (-1102768644));
    }

    @Test
    public void test620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test620");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution(1.3686073898357964d, 0.06417289357865119d, 1.6784377280749583E-9d);
    }

    @Test
    public void test621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test621");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        boolean boolean3 = logNormalDistribution2.isSupportUpperBoundInclusive();
        boolean boolean4 = logNormalDistribution2.isSupportLowerBoundInclusive();
        double double6 = logNormalDistribution2.density(0.7801559393041577d);
        boolean boolean7 = logNormalDistribution2.isSupportUpperBoundInclusive();
        double double10 = logNormalDistribution2.probability(8.568214410979046E-178d, 19.194552074112874d);
        boolean boolean11 = logNormalDistribution2.isSupportConnected();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.90565059165379E-4d + "'", double6 == 9.90565059165379E-4d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.046572709682650634d + "'", double10 == 0.046572709682650634d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test622");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        int int12 = well19937c1.nextInt((int) (byte) 1);
        float float13 = well19937c1.nextFloat();
        well19937c1.clear();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.28365302f + "'", float13 == 0.28365302f);
    }

    @Test
    public void test623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test623");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeed();
        double double6 = randomDataGenerator0.nextT((double) 2);
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("fbcc4", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
// flaky "32) test623(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.002594613204864211d + "'", double3 == 0.002594613204864211d);
// flaky "19) test623(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-3.734832634535231d) + "'", double6 == (-3.734832634535231d));
    }

    @Test
    public void test624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test624");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        java.lang.String str10 = randomDataGenerator0.nextSecureHexString((int) '4');
        double double13 = randomDataGenerator0.nextGamma((double) 100.00001f, (double) 2147483647);
        double double15 = randomDataGenerator0.nextExponential(0.5113968871894786d);
        double double18 = randomDataGenerator0.nextGamma(34.96483723426265d, 0.9999999993571499d);
// flaky "33) test624(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000011938496d + "'", double5 == 0.5000000011938496d);
// flaky "20) test624(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-233196225L) + "'", long8 == (-233196225L));
// flaky "11) test624(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str10 + "' != '" + "009110779125ad8e497cab40cf2d062fc503097fbbf2d50ca825" + "'", str10, "009110779125ad8e497cab40cf2d062fc503097fbbf2d50ca825");
// flaky "6) test624(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0323625571279074E11d + "'", double13 == 2.0323625571279074E11d);
// flaky "4) test624(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.27628624677715813d + "'", double15 == 0.27628624677715813d);
// flaky "2) test624(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double18 + "' != '" + 33.56355757191965d + "'", double18 == 33.56355757191965d);
    }

    @Test
    public void test625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test625");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
    }

    @Test
    public void test626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test626");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        int int13 = randomDataImpl8.nextBinomial(0, 0.14218002608626515d);
        double double16 = randomDataImpl8.nextF(1.1102230246251565E-16d, 1.2487305599455705d);
        randomDataImpl8.reSeedSecure(69L);
        randomDataImpl8.reSeed();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
// flaky "34) test626(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test627");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            int int7 = randomDataGenerator0.nextSecureInt(2, (-1219355438));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (2) must be strictly less than upper bound (-1,219,355,438)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "35) test627(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5093720786221269d + "'", double3 == 0.5093720786221269d);
    }

    @Test
    public void test628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test628");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeed();
        int int7 = randomDataGenerator0.nextSecureInt((int) '4', (int) (byte) 100);
        int int10 = randomDataGenerator0.nextPascal(149435855, 0.7874548671504324d);
        double double13 = randomDataGenerator0.nextGaussian(0.0d, (double) 9L);
// flaky "36) test628(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.675463120791188d + "'", double3 == 7.675463120791188d);
// flaky "21) test628(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int7 + "' != '" + 91 + "'", int7 == 91);
// flaky "12) test628(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int10 + "' != '" + 40340351 + "'", int10 == 40340351);
// flaky "7) test628(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-7.526600902910161d) + "'", double13 == (-7.526600902910161d));
    }

    @Test
    public void test629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test629");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((-93467950L));
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution5 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.021696876432501823d, 3.054607039620292E-4d, 0.0d);
        double double6 = normalDistribution5.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021696876432501823d + "'", double6 == 0.021696876432501823d);
    }

    @Test
    public void test630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test630");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(8.655017360140812d, (double) 4L, (double) 'a');
        double double4 = gammaDistribution3.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test631");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray9 = well19937c1.iRm2;
        boolean boolean10 = well19937c1.nextBoolean();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test632");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((-93467950L));
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution5 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.021696876432501823d, 3.054607039620292E-4d, 0.0d);
        long long6 = well19937c1.nextLong();
        float float7 = well19937c1.nextFloat();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2744074793510803016L + "'", long6 == 2744074793510803016L);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5931101f + "'", float7 == 0.5931101f);
    }

    @Test
    public void test633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test633");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        int[] intArray6 = new int[] { 0, 6, 0, 4 };
        well19937c1.setSeed(intArray6);
        boolean boolean8 = well19937c1.nextBoolean();
        well19937c1.clear();
        well19937c1.setSeed(1829961344);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertArrayEquals(intArray6, new int[] { 0, 6, 0, 4 });
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test634");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double24 = logNormalDistribution17.getNumericalVariance();
        boolean boolean25 = logNormalDistribution17.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test635");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        int int17 = randomDataImpl8.nextInt((-1), (int) '#');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
    }

    @Test
    public void test636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test636");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT(0.9999999993571499d);
        long long22 = randomDataImpl8.nextSecureLong((-8895791743399485995L), 4204440560618976768L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.22345908971987016d) + "'", double19 == (-0.22345908971987016d));
// flaky "37) test636(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-3105742522093189120L) + "'", long22 == (-3105742522093189120L));
    }

    @Test
    public void test637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test637");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        long long20 = randomDataImpl8.nextPoisson(3.141592653589793d);
        int int23 = randomDataImpl8.nextPascal(63, 1.374222606613847E-16d);
        randomDataImpl8.reSeedSecure((long) 'a');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 4L + "'", long20 == 4L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test638");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        gammaDistribution3.reseedRandomGenerator((long) 4);
        double double10 = gammaDistribution3.getSupportLowerBound();
        double double12 = gammaDistribution3.cumulativeProbability(5.943637410738046d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.1911734590632184d + "'", double12 == 0.1911734590632184d);
    }

    @Test
    public void test639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test639");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeed();
        long long7 = randomDataGenerator0.nextSecureLong((long) 1, 4418713979230659041L);
        int int10 = randomDataGenerator0.nextPascal(149435855, 0.3510058119179424d);
        double double13 = randomDataGenerator0.nextCauchy(5.02453019765138d, 4.130035205980525d);
// flaky "38) test639(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5598819397728105d + "'", double3 == 0.5598819397728105d);
// flaky "22) test639(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long7 + "' != '" + 125542416210588928L + "'", long7 == 125542416210588928L);
// flaky "13) test639(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int10 + "' != '" + 276313584 + "'", int10 == 276313584);
// flaky "8) test639(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 13.917255783428004d + "'", double13 == 13.917255783428004d);
    }

    @Test
    public void test640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test640");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        long long13 = well19937c1.nextLong();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 5121252613937015666L + "'", long13 == 5121252613937015666L);
    }

    @Test
    public void test641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test641");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        well19937c1.setSeed(73);
        well19937c1.setSeed(82);
    }

    @Test
    public void test642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test642");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        well19937c1.setSeed((long) 1);
        int int5 = well19937c1.index;
        java.lang.Class<?> wildcardClass6 = well19937c1.getClass();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test643");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray9 = well19937c1.iRm2;
        well19937c1.setSeed((-3));
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test644");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        java.lang.String str16 = randomDataImpl8.nextSecureHexString(5);
        randomDataImpl8.reSeedSecure(4418713979230659041L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator19 = randomDataImpl8.getDelegate();
        long long22 = randomDataImpl8.nextLong((long) 28, 111L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
// flaky "39) test644(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "7a00a" + "'", str16, "7a00a");
        org.junit.Assert.assertNotNull(randomDataGenerator19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 41L + "'", long22 == 41L);
    }

    @Test
    public void test645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test645");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextF(0.22497942976198554d, 0.3934606808571868d);
        double double15 = randomDataImpl8.nextCauchy((double) 0.0f, 0.08484461357703173d);
        randomDataImpl8.reSeedSecure();
        int int19 = randomDataImpl8.nextSecureInt((int) (short) 100, 614504715);
        // The following exception was thrown during execution in test generation
        try {
            long long22 = randomDataImpl8.nextLong((long) 646549088, (-15655326L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (646,549,088) must be strictly less than upper bound (-15,655,326)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2044.5491797688765d + "'", double12 == 2044.5491797688765d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.053473722883958005d) + "'", double15 == (-0.053473722883958005d));
// flaky "40) test645(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20194712 + "'", int19 == 20194712);
    }

    @Test
    public void test646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test646");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextBeta(97.0d, (double) (byte) 1);
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            int int16 = randomDataGenerator0.nextInt(91, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (91) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "41) test646(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.011514311707417426d + "'", double3 == 0.011514311707417426d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9830505425759046d + "'", double12 == 0.9830505425759046d);
    }

    @Test
    public void test647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test647");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(182.3918103676576d, 6.27147468593853E-47d, 190.06556510850848d);
        double double4 = logNormalDistribution3.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test648");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        boolean boolean3 = logNormalDistribution2.isSupportUpperBoundInclusive();
        boolean boolean4 = logNormalDistribution2.isSupportLowerBoundInclusive();
        double double6 = logNormalDistribution2.density(0.7801559393041577d);
        double double7 = logNormalDistribution2.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.90565059165379E-4d + "'", double6 == 9.90565059165379E-4d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test649");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        float float11 = well19937c1.nextFloat();
        int int12 = well19937c1.nextInt();
        well19937c1.setSeed((int) (short) -1);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.NormalDistribution normalDistribution18 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 2.37843771503522E-19d, (-20.318520882465364d), 2.8957779288675325d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-20.319)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.7685776f + "'", float11 == 0.7685776f);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1219355438) + "'", int12 == (-1219355438));
    }

    @Test
    public void test650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test650");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        int[] intArray9 = well19937c1.i2;
        double double10 = well19937c1.nextDouble();
        double double11 = well19937c1.nextDouble();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5871973525778662d + "'", double10 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
    }

    @Test
    public void test651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test651");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        randomDataImpl8.reSeed((long) (byte) 1);
        randomDataImpl8.reSeed();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
    }

    @Test
    public void test652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test652");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        double double11 = well19937c1.nextDouble();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray13 = well19937c1.i1;
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.3934606808571868d, 81.87241173283697d, 0.0d);
        org.apache.commons.math3.random.Well19937c well19937c19 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray23 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c19.nextBytes(byteArray23);
        int[] intArray25 = well19937c19.i3;
        double double26 = well19937c19.nextDouble();
        well19937c19.setSeed(32L);
        float float29 = well19937c19.nextFloat();
        org.apache.commons.math3.random.Well19937c well19937c31 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray35 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c31.nextBytes(byteArray35);
        int[] intArray37 = well19937c31.i3;
        double double38 = well19937c31.nextDouble();
        well19937c31.setSeed((long) (short) 1);
        long long41 = well19937c31.nextLong();
        byte[] byteArray42 = new byte[] {};
        well19937c31.nextBytes(byteArray42);
        well19937c19.nextBytes(byteArray42);
        well19937c1.nextBytes(byteArray42);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.9066258578518134d + "'", double26 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.7685776f + "'", float29 == 0.7685776f);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.9066258578518134d + "'", double38 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1342499381265206610L + "'", long41 == 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] {});
    }

    @Test
    public void test653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test653");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        double double7 = randomDataGenerator0.nextChiSquare(0.19335986621811754d);
        double double10 = randomDataGenerator0.nextUniform((-0.11563859552454996d), 0.1752614876109332d);
        // The following exception was thrown during execution in test generation
        try {
            double double12 = randomDataGenerator0.nextChiSquare((-1.5752922499850703d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.788)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "42) test653(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000016074122d + "'", double5 == 0.5000000016074122d);
// flaky "23) test653(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.19773782227886036d + "'", double7 == 0.19773782227886036d);
// flaky "14) test653(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.04317115572002764d + "'", double10 == 0.04317115572002764d);
    }

    @Test
    public void test654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test654");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.setSeed((int) '4');
        well19937c1.clear();
    }

    @Test
    public void test655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test655");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double9 = well19937c1.nextDouble();
        well19937c1.setSeed(3513799009476651814L);
        int int13 = well19937c1.next(31);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9066258578518134d + "'", double9 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 716814572 + "'", int13 == 716814572);
    }

    @Test
    public void test656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test656");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        int int3 = well19937c1.nextInt();
        float float4 = well19937c1.nextFloat();
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long7 = well19937c6.nextLong();
        double double8 = well19937c6.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c10 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray16 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c10.setSeed(intArray16);
        well19937c6.setSeed(intArray16);
        int[] intArray19 = well19937c6.iRm1;
        org.apache.commons.math3.random.Well19937c well19937c21 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray25 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c21.nextBytes(byteArray25);
        int[] intArray27 = well19937c21.i3;
        double double28 = well19937c21.nextDouble();
        well19937c21.setSeed((long) (short) 1);
        long long31 = well19937c21.nextLong();
        byte[] byteArray32 = new byte[] {};
        well19937c21.nextBytes(byteArray32);
        well19937c6.nextBytes(byteArray32);
        well19937c1.nextBytes(byteArray32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-401038879) + "'", int3 == (-401038879));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.39346063f + "'", float4 == 0.39346063f);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4418713979230659041L + "'", long7 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.3934606808571868d + "'", double8 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertArrayEquals(intArray16, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.9066258578518134d + "'", double28 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1342499381265206610L + "'", long31 == 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
    }

    @Test
    public void test657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test657");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        double double11 = well19937c1.nextDouble();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        java.lang.String str14 = randomDataImpl12.nextHexString(73);
        double double17 = randomDataImpl12.nextBeta((double) 0.28365302f, 0.021696876432501823d);
        double double19 = randomDataImpl12.nextT(0.44942288081866993d);
        // The following exception was thrown during execution in test generation
        try {
            int int22 = randomDataImpl12.nextBinomial(0, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 100 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "1ffe34c8d1dc65542db75d233832d568d74d2cb80f52d83edc118fe454ae772ad536b0320" + "'", str14, "1ffe34c8d1dc65542db75d233832d568d74d2cb80f52d83edc118fe454ae772ad536b0320");
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9750144731440554d + "'", double17 == 0.9750144731440554d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.2212503069189684d) + "'", double19 == (-1.2212503069189684d));
    }

    @Test
    public void test658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test658");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        boolean boolean3 = logNormalDistribution2.isSupportUpperBoundInclusive();
        double double4 = logNormalDistribution2.sample();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
// flaky "43) test658(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.7008172171649404E64d + "'", double4 == 2.7008172171649404E64d);
    }

    @Test
    public void test659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test659");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        randomDataGenerator0.reSeedSecure();
        java.lang.String str8 = randomDataGenerator0.nextSecureHexString((int) (byte) 1);
        randomDataGenerator0.reSeed();
// flaky "44) test659(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5259414458751331d + "'", double3 == 0.5259414458751331d);
// flaky "24) test659(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str8 + "' != '" + "3" + "'", str8, "3");
    }

    @Test
    public void test660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test660");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.sample();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test661");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        int[] intArray2 = well19937c1.i3;
        int int3 = well19937c1.index;
        well19937c1.setSeed((long) 2147483647);
        int int7 = well19937c1.nextInt(73);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test662");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(81.87241173283697d, (double) 68793477, 6.399835471825113E26d);
    }

    @Test
    public void test663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test663");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        double double7 = randomDataGenerator0.nextChiSquare(0.19335986621811754d);
        int int10 = randomDataGenerator0.nextZipf(251174, 1.5287994033960568d);
        // The following exception was thrown during execution in test generation
        try {
            double double14 = randomDataGenerator0.nextUniform(105.0d, (double) (-47.0f), false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (105) must be strictly less than upper bound (-47)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "45) test663(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000014127826d + "'", double5 == 0.5000000014127826d);
// flaky "25) test663(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.27738926445690865d + "'", double7 == 0.27738926445690865d);
// flaky "15) test663(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test664");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getSupportUpperBound();
        double double9 = gammaDistribution3.sample();
        double double12 = gammaDistribution3.cumulativeProbability(0.6483608274590866d, (double) 1152985812);
        double double14 = gammaDistribution3.density(2.993222846126381d);
        double double15 = gammaDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
// flaky "46) test664(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.045972499259186d + "'", double9 == 6.045972499259186d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9509486094206112d + "'", double12 == 0.9509486094206112d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.025766719698081936d + "'", double14 == 0.025766719698081936d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 60.46475370663325d + "'", double15 == 60.46475370663325d);
    }

    @Test
    public void test665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test665");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.random.RandomGenerator randomGenerator7 = null;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution11 = new org.apache.commons.math3.distribution.NormalDistribution(randomGenerator7, (double) (-1), (double) '#', 100.0d);
        double double13 = normalDistribution11.cumulativeProbability(0.0d);
        double double14 = normalDistribution11.getNumericalVariance();
        org.apache.commons.math3.random.RandomGenerator randomGenerator15 = null;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution19 = new org.apache.commons.math3.distribution.NormalDistribution(randomGenerator15, (double) (-1), (double) '#', 100.0d);
        java.lang.Object[] objArray20 = new java.lang.Object[] { '4', 0, normalDistribution11, (-1) };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable4, objArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable3, objArray20);
        org.apache.commons.math3.random.RandomGenerator randomGenerator23 = null;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution27 = new org.apache.commons.math3.distribution.NormalDistribution(randomGenerator23, (double) (-1), (double) '#', 100.0d);
        double double29 = normalDistribution27.cumulativeProbability(0.0d);
        double double30 = normalDistribution27.getNumericalVariance();
        double double32 = normalDistribution27.probability(0.5486644903859356d);
        org.apache.commons.math3.random.Well19937c well19937c35 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray39 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c35.nextBytes(byteArray39);
        int[] intArray41 = well19937c35.i3;
        org.apache.commons.math3.random.Well19937c well19937c42 = new org.apache.commons.math3.random.Well19937c(intArray41);
        int int44 = well19937c42.nextInt(251174);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution47 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        double double50 = logNormalDistribution47.cumulativeProbability(4.0533378281932396E-46d, (double) 35L);
        java.lang.Object[] objArray51 = new java.lang.Object[] { objArray20, normalDistribution27, 2.993222846126381d, 251174, double50 };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException52 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (-401038879), objArray51);
        org.apache.commons.math3.exception.MathInternalError mathInternalError53 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray51);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException54 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray51);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5113968002624507d + "'", double13 == 0.5113968002624507d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1225.0d + "'", double14 == 1225.0d);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.5113968002624507d + "'", double29 == 0.5113968002624507d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1225.0d + "'", double30 == 1225.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertArrayEquals(byteArray39, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 96691 + "'", int44 == 96691);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.041984444374669055d + "'", double50 == 0.041984444374669055d);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test666");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        int[] intArray9 = well19937c1.iRm1;
        int[] intArray10 = well19937c1.iRm2;
        int int12 = well19937c1.next(409060042);
        org.apache.commons.math3.random.Well19937c well19937c14 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray18 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c14.nextBytes(byteArray18);
        int[] intArray20 = well19937c14.i3;
        double double21 = well19937c14.nextDouble();
        well19937c14.setSeed((long) (short) 1);
        long long24 = well19937c14.nextLong();
        byte[] byteArray25 = new byte[] {};
        well19937c14.nextBytes(byteArray25);
        org.apache.commons.math3.random.Well19937c well19937c28 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray32 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c28.nextBytes(byteArray32);
        int[] intArray34 = well19937c28.i3;
        double double35 = well19937c28.nextDouble();
        well19937c28.setSeed((long) (short) 1);
        long long38 = well19937c28.nextLong();
        byte[] byteArray39 = new byte[] {};
        well19937c28.nextBytes(byteArray39);
        well19937c14.nextBytes(byteArray39);
        well19937c1.nextBytes(byteArray39);
        int[] intArray43 = well19937c1.v;
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 601 + "'", int12 == 601);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertArrayEquals(byteArray18, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.9066258578518134d + "'", double21 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1342499381265206610L + "'", long24 == 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertArrayEquals(byteArray25, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.9066258578518134d + "'", double35 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1342499381265206610L + "'", long38 == 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertArrayEquals(byteArray39, new byte[] {});
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test667");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int12 = well19937c1.next(0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1378651682 + "'", int12 == 1378651682);
    }

    @Test
    public void test668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test668");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        int int13 = randomDataImpl8.nextBinomial(0, 0.14218002608626515d);
        double double16 = randomDataImpl8.nextF(1.1102230246251565E-16d, 1.2487305599455705d);
        randomDataImpl8.reSeedSecure(69L);
        double double21 = randomDataImpl8.nextCauchy((double) 31, 2.384185791015625E-7d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
// flaky "16) test668(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
// flaky "47) test668(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double21 + "' != '" + 31.000004124857004d + "'", double21 == 31.000004124857004d);
    }

    @Test
    public void test669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test669");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.sample();
        double double7 = normalDistribution2.probability(6.27147468593853E-47d);
        double double8 = normalDistribution2.getMean();
        // The following exception was thrown during execution in test generation
        try {
            double double11 = normalDistribution2.cumulativeProbability(2.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (2) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
// flaky "48) test669(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.3479008018628045d + "'", double5 == 1.3479008018628045d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test670");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double4 = randomDataGenerator0.nextUniform(0.36787944117144233d, (double) 1L, true);
        java.lang.String str6 = randomDataGenerator0.nextSecureHexString(1);
        double double9 = randomDataGenerator0.nextWeibull(6.123748134567917d, 2.9496875887749894E19d);
        int int12 = randomDataGenerator0.nextSecureInt(4414, 40340351);
// flaky "49) test670(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7606337381504544d + "'", double4 == 0.7606337381504544d);
// flaky "26) test670(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str6 + "' != '" + "8" + "'", str6, "8");
// flaky "17) test670(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0594902447228953E19d + "'", double9 == 3.0594902447228953E19d);
// flaky "9) test670(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22542540 + "'", int12 == 22542540);
    }

    @Test
    public void test671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test671");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        double double12 = randomDataImpl8.nextExponential(0.7516838871580566d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
// flaky "50) test671(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.7927074596810884d + "'", double12 == 2.7927074596810884d);
    }

    @Test
    public void test672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test672");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long5 = well19937c4.nextLong();
        double double6 = well19937c4.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray14 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c8.setSeed(intArray14);
        well19937c4.setSeed(intArray14);
        well19937c1.setSeed(intArray14);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double22 = randomDataGenerator18.nextUniform(0.36787944117144233d, (double) 1L, true);
        int[] intArray25 = randomDataGenerator18.nextPermutation((int) (short) 100, (int) 'a');
        well19937c1.setSeed(intArray25);
        float float27 = well19937c1.nextFloat();
        double double28 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4418713979230659041L + "'", long5 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3934606808571868d + "'", double6 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertArrayEquals(intArray14, new int[] { 35, 0, 100, 10, 0 });
// flaky "51) test672(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.4729737087467743d + "'", double22 == 0.4729737087467743d);
        org.junit.Assert.assertNotNull(intArray25);
// flaky "27) test672(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.8165767f + "'", float27 == 0.8165767f);
// flaky "18) test672(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.7961375918827511d + "'", double28 == 0.7961375918827511d);
    }

    @Test
    public void test673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test673");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((-47));
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c3.nextBytes(byteArray7);
        int[] intArray9 = well19937c3.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c3);
        int[] intArray11 = well19937c3.iRm2;
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.random.Well19937c well19937c13 = new org.apache.commons.math3.random.Well19937c(intArray11);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test674");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double19 = logNormalDistribution17.cumulativeProbability((double) (-93467950L));
        double double22 = logNormalDistribution17.cumulativeProbability(3.29929710651543E-7d, 7.672868603936274d);
        double double24 = logNormalDistribution17.cumulativeProbability((double) 5121252613937015666L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.5d + "'", double24 == 0.5d);
    }

    @Test
    public void test675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test675");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            int int11 = randomDataGenerator0.nextHypergeometric(251174, 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: sample size (2,147,483,647) must be less than or equal to population size (251,174)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "52) test675(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.360661504875913d + "'", double3 == 5.360661504875913d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
    }

    @Test
    public void test676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test676");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        double double8 = randomDataGenerator0.nextUniform(21.23248944257666d, (double) '#');
        double double10 = randomDataGenerator0.nextChiSquare(4.644339562383774d);
        long long12 = randomDataGenerator0.nextPoisson(7.095868130534999d);
// flaky "53) test676(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5129280828315285d + "'", double3 == 0.5129280828315285d);
// flaky "28) test676(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double8 + "' != '" + 31.40830110797338d + "'", double8 == 31.40830110797338d);
// flaky "19) test676(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.417961736394276d + "'", double10 == 4.417961736394276d);
// flaky "10) test676(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long12 + "' != '" + 8L + "'", long12 == 8L);
    }

    @Test
    public void test677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test677");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution13 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.25725306008387744d, 0.661011522946662d, 120.54442181558605d);
        boolean boolean14 = gammaDistribution13.isSupportConnected();
        double double15 = gammaDistribution13.getNumericalMean();
        double double16 = gammaDistribution13.sample();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32099235282147576d + "'", double9 == 0.32099235282147576d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.17004723702873298d + "'", double15 == 0.17004723702873298d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.715930542993903E-4d + "'", double16 == 8.715930542993903E-4d);
    }

    @Test
    public void test678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test678");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        randomDataImpl8.reSeedSecure((long) (-1));
        double double22 = randomDataImpl8.nextUniform(1.059529144682836d, 3.3663081124299024d, false);
        randomDataImpl8.reSeed(0L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.276050933369993d + "'", double22 == 2.276050933369993d);
    }

    @Test
    public void test679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test679");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = randomDataImpl8.getDelegate();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertNotNull(randomDataGenerator18);
    }

    @Test
    public void test680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test680");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        boolean boolean3 = well19937c1.nextBoolean();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double5 = well19937c1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.1367215706086458d + "'", double5 == 1.1367215706086458d);
    }

    @Test
    public void test681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test681");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.setSeed((int) '4');
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c6.nextBytes(byteArray10);
        int[] intArray12 = well19937c6.i3;
        double double13 = well19937c6.nextDouble();
        well19937c6.setSeed((long) (short) 1);
        long long16 = well19937c6.nextLong();
        double double17 = well19937c6.nextGaussian();
        int[] intArray18 = well19937c6.i2;
        well19937c1.setSeed(intArray18);
        double double20 = well19937c1.nextDouble();
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9066258578518134d + "'", double13 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1342499381265206610L + "'", long16 == 1342499381265206610L);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.13866332061552417d) + "'", double17 == (-0.13866332061552417d));
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.41812274171499686d + "'", double20 == 0.41812274171499686d);
    }

    @Test
    public void test682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test682");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double18 = logNormalDistribution17.getSupportLowerBound();
        double double19 = logNormalDistribution17.getSupportLowerBound();
        boolean boolean20 = logNormalDistribution17.isSupportConnected();
        double double21 = logNormalDistribution17.getScale();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test683");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        java.lang.String str17 = randomDataImpl8.nextSecureHexString((int) '4');
        // The following exception was thrown during execution in test generation
        try {
            int int20 = randomDataImpl8.nextZipf(92410965, (-6.167681897831368d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (-6.168)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
// flaky "54) test683(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str17 + "' != '" + "1c739e358e380310b6bebf866b423d9402f806c246fa3ca93091" + "'", str17, "1c739e358e380310b6bebf866b423d9402f806c246fa3ca93091");
    }

    @Test
    public void test684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test684");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double23 = logNormalDistribution17.cumulativeProbability(0.0d, (double) 1342499381265206610L);
        double double26 = logNormalDistribution17.cumulativeProbability((-0.9999999999999999d), (double) 3.8146973E-6f);
        double double28 = logNormalDistribution17.cumulativeProbability(0.5217413751230109d);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.5d + "'", double26 == 0.5d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.5d + "'", double28 == 0.5d);
    }

    @Test
    public void test685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test685");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        long long3 = well19937c1.nextLong();
        int[] intArray4 = well19937c1.i2;
        well19937c1.setSeed((long) 135154658);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4418713979230659041L + "'", long3 == 4418713979230659041L);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test686");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGaussian(1.5707963267948966d, 2.9496875887749894E19d);
        double double22 = randomDataImpl8.nextGaussian((double) 100, 0.010499156611600656d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0185362398551933E19d) + "'", double19 == (-3.0185362398551933E19d));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.99402284785383d + "'", double22 == 99.99402284785383d);
    }

    @Test
    public void test687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test687");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) (byte) -1, (double) 4418713979230659041L, 1225.0d);
        boolean boolean4 = logNormalDistribution3.isSupportConnected();
        boolean boolean5 = logNormalDistribution3.isSupportConnected();
        double double7 = logNormalDistribution3.cumulativeProbability(173.48300619963672d);
        double double8 = logNormalDistribution3.sample();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
// flaky "55) test687(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test688");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextBeta(97.0d, (double) (byte) 1);
        double double14 = randomDataGenerator0.nextChiSquare(0.17844868096790079d);
        long long17 = randomDataGenerator0.nextLong((long) 409060042, 2744074793510803016L);
        double double19 = randomDataGenerator0.nextT((double) 0.5453615f);
// flaky "56) test688(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.530441664862889d + "'", double3 == 2.530441664862889d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9830505425759046d + "'", double12 == 0.9830505425759046d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.1023228977815945E-4d + "'", double14 == 1.1023228977815945E-4d);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2071108460164406272L + "'", long17 == 2071108460164406272L);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0902050730879638d) + "'", double19 == (-1.0902050730879638d));
    }

    @Test
    public void test689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test689");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double24 = logNormalDistribution17.getSupportUpperBound();
        double double27 = logNormalDistribution17.probability(0.3934606808571868d, 4.0d);
        double double28 = logNormalDistribution17.sample();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test690");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        // The following exception was thrown during execution in test generation
        try {
            double double16 = randomDataImpl8.nextF(0.0d, 1.77248108481435E-4d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
    }

    @Test
    public void test691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test691");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            long long11 = randomDataImpl8.nextLong((long) 1152985812, 5L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,152,985,812) must be strictly less than upper bound (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test692");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        boolean boolean23 = logNormalDistribution17.isSupportLowerBoundInclusive();
        double double25 = logNormalDistribution17.density((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test693");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getSupportUpperBound();
        double double9 = gammaDistribution3.sample();
        double double12 = gammaDistribution3.cumulativeProbability(0.0d, 2044.5491797688765d);
        double double14 = gammaDistribution3.probability(20.84454958240623d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
// flaky "57) test693(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 5.177047245622149d + "'", double9 == 5.177047245622149d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9999999998478477d + "'", double12 == 0.9999999998478477d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test694");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        boolean boolean3 = logNormalDistribution2.isSupportUpperBoundInclusive();
        double double4 = logNormalDistribution2.getNumericalVariance();
        double double5 = logNormalDistribution2.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test695");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = randomDataImpl8.getDelegate();
        double double20 = randomDataGenerator18.nextT(4.7421875d);
        randomDataGenerator18.reSeedSecure();
        double double23 = randomDataGenerator18.nextExponential((double) 60);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
        org.junit.Assert.assertNotNull(randomDataGenerator18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.206086869959821d + "'", double20 == 0.206086869959821d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 5.839730997604704d + "'", double23 == 5.839730997604704d);
    }

    @Test
    public void test696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test696");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        randomDataImpl8.reSeedSecure((long) (-1));
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray20 = randomDataImpl8.nextPermutation((-387737817), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (32) exceeds permuation domain (-387,737,817)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
    }

    @Test
    public void test697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test697");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        well19937c1.setSeed((long) 1);
        int int5 = well19937c1.index;
        well19937c1.setSeed((long) 2);
        int int8 = well19937c1.nextInt();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-358148614) + "'", int8 == (-358148614));
    }

    @Test
    public void test698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test698");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextBeta(97.0d, (double) (byte) 1);
        double double14 = randomDataGenerator0.nextChiSquare(0.17844868096790079d);
        long long17 = randomDataGenerator0.nextLong((long) 409060042, 2744074793510803016L);
        double double19 = randomDataGenerator0.nextExponential(0.5013075180596978d);
// flaky "58) test698(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8659347722100086d + "'", double3 == 2.8659347722100086d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9830505425759046d + "'", double12 == 0.9830505425759046d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.1023228977815945E-4d + "'", double14 == 1.1023228977815945E-4d);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2071108460164406272L + "'", long17 == 2071108460164406272L);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.41492684105596644d + "'", double19 == 0.41492684105596644d);
    }

    @Test
    public void test699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test699");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((double) 5L, (double) (short) 1, 2.766458368800151d);
        double double5 = normalDistribution3.density((-1.4165028871298073d));
        double double7 = normalDistribution3.inverseCumulativeProbability(0.7874548671504324d);
        double double9 = normalDistribution3.cumulativeProbability(0.004093928401859652d);
        double double10 = normalDistribution3.sample();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.577521738126163E-10d + "'", double5 == 4.577521738126163E-10d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.702637376954931d + "'", double7 == 5.702637376954931d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.928007995506299E-7d + "'", double9 == 2.928007995506299E-7d);
// flaky "59) test699(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5.906657214914172d + "'", double10 == 5.906657214914172d);
    }

    @Test
    public void test700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test700");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGaussian(1.5707963267948966d, 2.9496875887749894E19d);
        randomDataImpl8.reSeedSecure((long) 'a');
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator22 = randomDataImpl8.getDelegate();
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution25 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double27 = normalDistribution25.probability(1.0E-9d);
        double double28 = normalDistribution25.sample();
        double double30 = normalDistribution25.probability(6.27147468593853E-47d);
        double double31 = normalDistribution25.getSupportLowerBound();
        double double32 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution25);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0185362398551933E19d) + "'", double19 == (-3.0185362398551933E19d));
        org.junit.Assert.assertNotNull(randomDataGenerator22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
// flaky "60) test700(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.7024443382195167d + "'", double28 == 3.7024443382195167d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.NEGATIVE_INFINITY + "'", double31 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.6865571127670551d + "'", double32 == 1.6865571127670551d);
    }

    @Test
    public void test701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test701");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeed();
        int int7 = randomDataGenerator0.nextSecureInt((int) '4', (int) (byte) 100);
        double double9 = randomDataGenerator0.nextExponential(6.546942328861153E10d);
// flaky "61) test701(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.36354042310643d + "'", double3 == 0.36354042310643d);
// flaky "29) test701(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int7 + "' != '" + 76 + "'", int7 == 76);
// flaky "20) test701(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 7.036769758011797E10d + "'", double9 == 7.036769758011797E10d);
    }

    @Test
    public void test702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test702");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        double double18 = normalDistribution16.getSupportLowerBound();
        double double19 = normalDistribution16.getMean();
        double double21 = normalDistribution16.cumulativeProbability((-0.9995560569658268d));
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.NEGATIVE_INFINITY + "'", double18 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.15876269899353096d + "'", double21 == 0.15876269899353096d);
    }

    @Test
    public void test703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test703");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double12 = randomDataImpl9.nextBeta(0.3572390056774897d, (double) 60);
        java.lang.String str14 = randomDataImpl9.nextHexString((int) ' ');
        // The following exception was thrown during execution in test generation
        try {
            long long17 = randomDataImpl9.nextLong((long) (-53), (-4736355256857903122L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (-53) must be strictly less than upper bound (-4,736,355,256,857,903,122)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.01788824499366423d + "'", double12 == 0.01788824499366423d);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "a20eacd2e00e09a64d73f8aa3868e7f7" + "'", str14, "a20eacd2e00e09a64d73f8aa3868e7f7");
    }

    @Test
    public void test704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test704");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeedSecure((long) (byte) 0);
        long long8 = randomDataGenerator0.nextLong(0L, (long) 10);
        double double11 = randomDataGenerator0.nextF((double) 27L, 198.11163911901005d);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray14 = randomDataGenerator0.nextPermutation((-42005975), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (35) exceeds permuation domain (-42,005,975)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "62) test704(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.008163264994181496d + "'", double3 == 0.008163264994181496d);
// flaky "30) test704(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
// flaky "21) test704(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9803017952837076d + "'", double11 == 0.9803017952837076d);
    }

    @Test
    public void test705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test705");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution13 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.25725306008387744d, 0.661011522946662d, 120.54442181558605d);
        double double14 = well19937c1.nextDouble();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution18 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.0d, 5.1481760329336096E17d, 0.6483608274590866d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32099235282147576d + "'", double9 == 0.32099235282147576d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.16590809027000164d + "'", double14 == 0.16590809027000164d);
    }

    @Test
    public void test706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test706");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution2 = new org.apache.commons.math3.distribution.GammaDistribution(2.985601297522666E25d, 6.285121086618636d);
        double double3 = gammaDistribution2.sample();
// flaky "63) test706(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.8764865671294617E26d + "'", double3 == 1.8764865671294617E26d);
    }

    @Test
    public void test707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test707");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        boolean boolean8 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double9 = gammaDistribution3.getSupportLowerBound();
        double double11 = gammaDistribution3.density(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.POSITIVE_INFINITY + "'", double11 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test708");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (-1));
        int int3 = well19937c1.next((-1));
        boolean boolean4 = well19937c1.nextBoolean();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 514406009 + "'", int3 == 514406009);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test709");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        double double20 = randomDataImpl8.nextUniform(0.0d, 0.5000000013965371d);
        double double23 = randomDataImpl8.nextGamma(9.90565059165379E-4d, (double) 14);
        double double25 = randomDataImpl8.nextExponential((double) 4.2949673E9f);
        // The following exception was thrown during execution in test generation
        try {
            int int28 = randomDataImpl8.nextInt(1829961344, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,829,961,344) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.27433221325624985d + "'", double20 == 0.27433221325624985d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.1814756693825865E9d + "'", double25 == 1.1814756693825865E9d);
    }

    @Test
    public void test710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test710");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        long long3 = well19937c1.nextLong();
        int[] intArray4 = well19937c1.i2;
        well19937c1.setSeed(4);
        double double7 = well19937c1.nextGaussian();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4418713979230659041L + "'", long3 == 4418713979230659041L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.9179016973631402d + "'", double7 == 1.9179016973631402d);
    }

    @Test
    public void test711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test711");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextExponential((double) 96691);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 26598.121958848013d + "'", double21 == 26598.121958848013d);
    }

    @Test
    public void test712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test712");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGaussian(1.5707963267948966d, 2.9496875887749894E19d);
        randomDataImpl8.reSeedSecure((long) 'a');
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator22 = randomDataImpl8.getDelegate();
        int int25 = randomDataImpl8.nextInt(23, 409060042);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0185362398551933E19d) + "'", double19 == (-3.0185362398551933E19d));
        org.junit.Assert.assertNotNull(randomDataGenerator22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 215725254 + "'", int25 == 215725254);
    }

    @Test
    public void test713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test713");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure();
// flaky "64) test713(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8862992737857648d + "'", double3 == 0.8862992737857648d);
    }

    @Test
    public void test714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test714");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((double) 326573780, 0.0d, 0.16676169823315717d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test715");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian(0.44942288081866993d, 1.000000000000002E-288d);
        int int9 = randomDataGenerator0.nextZipf(2, 0.32099235282147576d);
// flaky "65) test715(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.15881256198226526d + "'", double3 == 0.15881256198226526d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.44942288081866993d + "'", double6 == 0.44942288081866993d);
// flaky "31) test715(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test716");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution13 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.25725306008387744d, 0.661011522946662d, 120.54442181558605d);
        int[] intArray14 = well19937c1.i1;
        well19937c1.setSeed((-53));
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32099235282147576d + "'", double9 == 0.32099235282147576d);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test717");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double4 = gammaDistribution3.sample();
        double double6 = gammaDistribution3.probability(0.11563859552454996d);
// flaky "66) test717(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.455196710673294d + "'", double4 == 5.455196710673294d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test718");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        double double21 = randomDataImpl8.nextBeta((double) 69L, 0.6294995602790446d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.9959243161196223d + "'", double21 == 0.9959243161196223d);
    }

    @Test
    public void test719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test719");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 5);
    }

    @Test
    public void test720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test720");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double4 = gammaDistribution3.sample();
        double double5 = gammaDistribution3.sample();
        boolean boolean6 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double8 = gammaDistribution3.density(3.5568934049972536d);
// flaky "67) test720(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 48.34559358459477d + "'", double4 == 48.34559358459477d);
// flaky "32) test720(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 38.590096109722076d + "'", double5 == 38.590096109722076d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.024005580815954396d + "'", double8 == 0.024005580815954396d);
    }

    @Test
    public void test721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test721");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(1.772453845669073d, (double) 5);
    }

    @Test
    public void test722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test722");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        well19937c1.setSeed((long) 1);
        org.apache.commons.math3.random.Well19937c well19937c6 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        int[] intArray7 = well19937c6.i3;
        well19937c1.setSeed(intArray7);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c(intArray7);
        byte[] byteArray10 = new byte[] {};
        well19937c9.nextBytes(byteArray10);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution15 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c9, (double) 3, 0.6233479763570439d, (double) 4986124084203277738L);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c9);
        well19937c9.index = 601;
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] {});
    }

    @Test
    public void test723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test723");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        long long3 = well19937c1.nextLong();
        int[] intArray4 = well19937c1.i2;
        float float5 = well19937c1.nextFloat();
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution9 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 657086092, 0.5992615271016185d, 13.917255783428004d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4418713979230659041L + "'", long3 == 4418713979230659041L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.39346063f + "'", float5 == 0.39346063f);
    }

    @Test
    public void test724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test724");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        boolean boolean3 = normalDistribution2.isSupportLowerBoundInclusive();
        double double6 = normalDistribution2.cumulativeProbability(1.7453292519943298E-11d, 1.0E-6d);
        double double7 = normalDistribution2.getNumericalVariance();
        normalDistribution2.reseedRandomGenerator(2744074793510803016L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.96945621303213E-8d + "'", double6 == 3.96945621303213E-8d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test725");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        int int17 = randomDataImpl8.nextBinomial(4, (double) 1.4E-45f);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl8.setSecureAlgorithm("d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91", "6121986868");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 6121986868");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test726");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        int[] intArray15 = randomDataImpl8.nextPermutation(215725254, (int) (byte) 100);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test727");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(92410965);
        int int3 = well19937c1.next(614504704);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 658698948 + "'", int3 == 658698948);
    }

    @Test
    public void test728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test728");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        int[] intArray7 = new int[] { (short) -1, 646549088, 6, (-401038879) };
        well19937c1.setSeed(intArray7);
        org.apache.commons.math3.random.Well19937c well19937c10 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int11 = well19937c10.nextInt();
        int[] intArray16 = new int[] { (short) -1, 646549088, 6, (-401038879) };
        well19937c10.setSeed(intArray16);
        well19937c10.setSeed((long) 'a');
        int[] intArray20 = well19937c10.v;
        int[] intArray21 = well19937c10.i3;
        well19937c1.setSeed(intArray21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { (-1), 646549088, 6, (-401038879) });
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1028812019 + "'", int11 == 1028812019);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertArrayEquals(intArray16, new int[] { (-1), 646549088, 6, (-401038879) });
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test729");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 7.6293945E-6f, 10.919399310827936d, (double) 0L);
        double double4 = logNormalDistribution3.getNumericalMean();
        double double6 = logNormalDistribution3.density((double) 4986124084203277738L);
        double double7 = logNormalDistribution3.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.783615591316188E25d + "'", double4 == 7.783615591316188E25d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.084757259846199E-24d + "'", double6 == 3.084757259846199E-24d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test730");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        java.lang.String str16 = randomDataImpl8.nextSecureHexString(5);
        randomDataImpl8.reSeed((long) 1689900776);
        double double20 = randomDataImpl8.nextExponential(0.03918373679395073d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
// flaky "68) test730(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "865ab" + "'", str16, "865ab");
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.01863706026034726d + "'", double20 == 0.01863706026034726d);
    }

    @Test
    public void test731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test731");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextF(0.22497942976198554d, 0.3934606808571868d);
        double double15 = randomDataImpl8.nextCauchy((double) 0.0f, 0.08484461357703173d);
        // The following exception was thrown during execution in test generation
        try {
            double double18 = randomDataImpl8.nextUniform(2.4241533998767024d, (double) (-6.7868904E7f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (2.424) must be strictly less than upper bound (-67,868,904)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2044.5491797688765d + "'", double12 == 2044.5491797688765d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.053473722883958005d) + "'", double15 == (-0.053473722883958005d));
    }

    @Test
    public void test732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test732");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(32L);
        well19937c1.clear();
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution6 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 82, 0.3572390056774897d, 0.0d);
    }

    @Test
    public void test733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test733");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        well19937c1.setSeed(73);
        long long4 = well19937c1.nextLong();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1913212662277660697L + "'", long4 == 1913212662277660697L);
    }

    @Test
    public void test734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test734");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getScale();
        double[] doubleArray23 = logNormalDistribution17.sample((int) '4');
        double double25 = logNormalDistribution17.probability(0.36787944117144233d);
        double double27 = logNormalDistribution17.probability((double) 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test735");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        int int13 = randomDataImpl8.nextBinomial(0, 0.14218002608626515d);
        double double16 = randomDataImpl8.nextF(1.1102230246251565E-16d, 1.2487305599455705d);
        org.apache.commons.math3.random.RandomGenerator randomGenerator17 = null;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution21 = new org.apache.commons.math3.distribution.NormalDistribution(randomGenerator17, (double) (-1), (double) '#', 100.0d);
        double double23 = normalDistribution21.cumulativeProbability(0.0d);
        boolean boolean24 = normalDistribution21.isSupportConnected();
        double double25 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution21);
        double double27 = normalDistribution21.inverseCumulativeProbability(0.9345329978999835d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
// flaky "69) test735(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.6494958079604364E-9d + "'", double16 == 1.6494958079604364E-9d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5113968002624507d + "'", double23 == 0.5113968002624507d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
// flaky "33) test735(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double25 + "' != '" + 24.48252032804121d + "'", double25 == 24.48252032804121d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 60.48685203136141d + "'", double27 == 60.48685203136141d);
    }

    @Test
    public void test736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test736");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        boolean boolean3 = logNormalDistribution2.isSupportUpperBoundInclusive();
        double double4 = logNormalDistribution2.getNumericalVariance();
        double double5 = logNormalDistribution2.getScale();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 205.35258171903948d + "'", double5 == 205.35258171903948d);
    }

    @Test
    public void test737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test737");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(9.90565059165379E-4d, 0.07666142781209974d);
    }

    @Test
    public void test738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test738");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        int[] intArray9 = well19937c1.i2;
        double double10 = well19937c1.nextDouble();
        well19937c1.clear();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5871973525778662d + "'", double10 == 0.5871973525778662d);
    }

    @Test
    public void test739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test739");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution13 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.25725306008387744d, 0.661011522946662d, 120.54442181558605d);
        double double14 = gammaDistribution13.getShape();
        double double15 = gammaDistribution13.getSupportUpperBound();
        boolean boolean16 = gammaDistribution13.isSupportUpperBoundInclusive();
        double double17 = gammaDistribution13.getNumericalVariance();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32099235282147576d + "'", double9 == 0.32099235282147576d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.25725306008387744d + "'", double14 == 0.25725306008387744d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1124031831212348d + "'", double17 == 0.1124031831212348d);
    }

    @Test
    public void test740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test740");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(3.628829966193325d, 0.9345329978999833d);
        double double3 = logNormalDistribution2.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test741");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int4 = well19937c1.nextInt((int) ' ');
        boolean boolean5 = well19937c1.nextBoolean();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            double double10 = randomDataImpl6.nextUniform(144.0d, 0.009034635138461d, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (144) must be strictly less than upper bound (0.009)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test742");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        long long19 = randomDataImpl8.nextLong(1L, (long) 96691);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str21 = randomDataImpl8.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 50992L + "'", long19 == 50992L);
    }

    @Test
    public void test743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test743");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        boolean boolean8 = gammaDistribution3.isSupportLowerBoundInclusive();
        double double9 = gammaDistribution3.getNumericalMean();
        double double10 = gammaDistribution3.getBeta();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 60.46475370663325d + "'", double9 == 60.46475370663325d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
    }

    @Test
    public void test744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test744");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double9 = gammaDistribution3.density(1.772453845669073d);
        boolean boolean10 = gammaDistribution3.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.031786105569848185d + "'", double9 == 0.031786105569848185d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test745");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        double double11 = well19937c1.nextDouble();
        double double12 = well19937c1.nextGaussian();
        well19937c1.setSeed(92410965);
        org.apache.commons.math3.random.Well19937c well19937c16 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray20 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c16.nextBytes(byteArray20);
        int[] intArray22 = well19937c16.i3;
        double double23 = well19937c16.nextDouble();
        double double24 = well19937c16.nextDouble();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution28 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c16, 0.25725306008387744d, 0.661011522946662d, 120.54442181558605d);
        int[] intArray29 = well19937c16.i1;
        well19937c1.setSeed(intArray29);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.20028707385920028d) + "'", double12 == (-0.20028707385920028d));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.9066258578518134d + "'", double23 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.32099235282147576d + "'", double24 == 0.32099235282147576d);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test746");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution16 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (-93467950L), 1.5223961928507554d, (double) 1028812019);
        int[] intArray17 = well19937c1.i1;
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test747");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double9 = gammaDistribution3.cumulativeProbability((double) 646549088);
        double double10 = gammaDistribution3.getAlpha();
        gammaDistribution3.reseedRandomGenerator((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6233479763570439d + "'", double10 == 0.6233479763570439d);
    }

    @Test
    public void test748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test748");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        int int15 = randomDataGenerator0.nextPascal((int) (byte) 1, 0.3934606808571868d);
        int int18 = randomDataGenerator0.nextInt((-47), 96691);
// flaky "70) test748(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.012707007282448326d + "'", double3 == 0.012707007282448326d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 63329 + "'", int18 == 63329);
    }

    @Test
    public void test749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test749");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.sample();
        double double7 = normalDistribution2.probability(6.27147468593853E-47d);
        double double8 = normalDistribution2.getSupportLowerBound();
        double double9 = normalDistribution2.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
// flaky "71) test749(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0217949971065226d + "'", double5 == 3.0217949971065226d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test750");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        int int12 = randomDataGenerator9.nextInt(6, 92410965);
        // The following exception was thrown during execution in test generation
        try {
            double double14 = randomDataGenerator9.nextExponential((-6.7868904E7d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-67,868,904)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 83782171 + "'", int12 == 83782171);
    }

    @Test
    public void test751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test751");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        randomDataImpl8.reSeedSecure((long) (-1));
        double double19 = randomDataImpl8.nextExponential(1.2066935116126527d);
        // The following exception was thrown during execution in test generation
        try {
            int int22 = randomDataImpl8.nextBinomial((-1), 93.99999999999999d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of trials (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.18670409752493586d + "'", double19 == 0.18670409752493586d);
    }

    @Test
    public void test752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test752");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        double double8 = randomDataGenerator0.nextT(5.16069461171411d);
        int int11 = randomDataGenerator0.nextSecureInt((int) (short) 1, 78);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = randomDataGenerator0.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "72) test752(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9855182489168383d + "'", double3 == 0.9855182489168383d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
// flaky "34) test752(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.5963839424813815d) + "'", double8 == (-0.5963839424813815d));
// flaky "22) test752(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + int11 + "' != '" + 25 + "'", int11 == 25);
    }

    @Test
    public void test753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test753");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        int int13 = randomDataImpl8.nextBinomial(0, 0.14218002608626515d);
        double double16 = randomDataImpl8.nextF(1.1102230246251565E-16d, 1.2487305599455705d);
        org.apache.commons.math3.random.RandomGenerator randomGenerator17 = null;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution21 = new org.apache.commons.math3.distribution.NormalDistribution(randomGenerator17, (double) (-1), (double) '#', 100.0d);
        double double23 = normalDistribution21.cumulativeProbability(0.0d);
        boolean boolean24 = normalDistribution21.isSupportConnected();
        double double25 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution21);
        randomDataImpl8.reSeedSecure((long) 13);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
// flaky "73) test753(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.6142565440837167E-9d + "'", double16 == 1.6142565440837167E-9d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5113968002624507d + "'", double23 == 0.5113968002624507d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
// flaky "35) test753(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double25 + "' != '" + 195.8363579761364d + "'", double25 == 195.8363579761364d);
    }

    @Test
    public void test754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test754");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        long long3 = well19937c1.nextLong();
        int[] intArray4 = well19937c1.i2;
        int int5 = well19937c1.nextInt();
        long long6 = well19937c1.nextLong();
        int int8 = well19937c1.next(622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4418713979230659041L + "'", long3 == 4418713979230659041L);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1689900776 + "'", int5 == 1689900776);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5921263887411940960L + "'", long6 == 5921263887411940960L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2718 + "'", int8 == 2718);
    }

    @Test
    public void test755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test755");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        double double20 = randomDataImpl8.nextUniform(0.0d, 0.5000000013965371d);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution21 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int22 = randomDataImpl8.nextInversionDeviate(integerDistribution21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.27433221325624985d + "'", double20 == 0.27433221325624985d);
    }

    @Test
    public void test756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test756");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        boolean boolean6 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double7 = gammaDistribution3.getAlpha();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6233479763570439d + "'", double7 == 0.6233479763570439d);
    }

    @Test
    public void test757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test757");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        boolean boolean3 = logNormalDistribution2.isSupportUpperBoundInclusive();
        double double4 = logNormalDistribution2.getNumericalVariance();
        boolean boolean5 = logNormalDistribution2.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test758");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getScale();
        double[] doubleArray23 = logNormalDistribution17.sample((int) '4');
        double double25 = logNormalDistribution17.probability(0.36787944117144233d);
        double double26 = logNormalDistribution17.getNumericalVariance();
        double double27 = logNormalDistribution17.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test759");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 22542540);
    }

    @Test
    public void test760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test760");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        java.lang.String str16 = randomDataImpl8.nextSecureHexString(5);
        double double18 = randomDataImpl8.nextExponential((double) 32);
        long long21 = randomDataImpl8.nextLong(0L, (long) ' ');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
// flaky "74) test760(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "05229" + "'", str16, "05229");
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 54.83389066495692d + "'", double18 == 54.83389066495692d);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 19L + "'", long21 == 19L);
    }

    @Test
    public void test761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test761");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        double double11 = randomDataGenerator0.nextChiSquare((double) 4L);
        randomDataGenerator0.reSeedSecure(5921263887411940960L);
// flaky "75) test761(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000019142476d + "'", double5 == 0.5000000019142476d);
// flaky "36) test761(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-179003915L) + "'", long8 == (-179003915L));
// flaky "23) test761(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.3609583074144664d + "'", double11 == 2.3609583074144664d);
    }

    @Test
    public void test762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test762");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(0L);
        float float2 = well19937c1.nextFloat();
        int int4 = well19937c1.next(716814572);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.74324155f + "'", float2 == 0.74324155f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3982 + "'", int4 == 3982);
    }

    @Test
    public void test763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test763");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution((double) 52L, 1.5223961928507554d, (double) 41L);
        double double4 = gammaDistribution3.getSupportUpperBound();
        double double5 = gammaDistribution3.getScale();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.5223961928507554d + "'", double5 == 1.5223961928507554d);
    }

    @Test
    public void test764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test764");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getNumericalVariance();
        double double7 = gammaDistribution3.getSupportLowerBound();
        double double8 = gammaDistribution3.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5865.081109543426d + "'", double6 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test765");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        double double11 = randomDataGenerator0.nextChiSquare((double) 4L);
        // The following exception was thrown during execution in test generation
        try {
            int int14 = randomDataGenerator0.nextPascal((-401038879), 0.7874548671504324d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of successes (-401,038,879)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "37) test765(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "76) test765(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-260876356L) + "'", long8 == (-260876356L));
// flaky "24) test765(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.491969441489395d + "'", double11 == 5.491969441489395d);
    }

    @Test
    public void test766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test766");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(4.577521738126163E-10d, 0.1668524405453939d);
    }

    @Test
    public void test767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test767");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextF(0.22497942976198554d, 0.3934606808571868d);
        double double15 = randomDataImpl8.nextCauchy((double) 0.0f, 0.08484461357703173d);
        randomDataImpl8.reSeedSecure((long) 1689900776);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2044.5491797688765d + "'", double12 == 2044.5491797688765d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.053473722883958005d) + "'", double15 == (-0.053473722883958005d));
    }

    @Test
    public void test768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test768");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        float float11 = well19937c1.nextFloat();
        org.apache.commons.math3.random.Well19937c well19937c13 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray17 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c13.nextBytes(byteArray17);
        int[] intArray19 = well19937c13.i3;
        double double20 = well19937c13.nextDouble();
        well19937c13.setSeed((long) (short) 1);
        long long23 = well19937c13.nextLong();
        byte[] byteArray24 = new byte[] {};
        well19937c13.nextBytes(byteArray24);
        well19937c1.nextBytes(byteArray24);
        well19937c1.setSeed((long) 276287946);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.7685776f + "'", float11 == 0.7685776f);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.9066258578518134d + "'", double20 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1342499381265206610L + "'", long23 == 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] {});
    }

    @Test
    public void test769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test769");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (-1));
        int int3 = well19937c1.next((-1));
        int int5 = well19937c1.nextInt(40340351);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 514406009 + "'", int3 == 514406009);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10627360 + "'", int5 == 10627360);
    }

    @Test
    public void test770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test770");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 99L, (double) 2940458407815999488L);
        double double3 = logNormalDistribution2.getNumericalMean();
        boolean boolean4 = logNormalDistribution2.isSupportLowerBoundInclusive();
        double double5 = logNormalDistribution2.sample();
        double[] doubleArray7 = logNormalDistribution2.sample((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
// flaky "77) test770(org.apache.commons.math3.random.RegressionTest1)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test771");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            double double4 = randomDataGenerator0.nextExponential(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test772");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        int int12 = well19937c1.nextInt((int) (byte) 1);
        float float13 = well19937c1.nextFloat();
        well19937c1.index = 326573780;
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.28365302f + "'", float13 == 0.28365302f);
    }
}
