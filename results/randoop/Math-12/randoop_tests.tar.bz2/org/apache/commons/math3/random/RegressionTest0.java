package org.apache.commons.math3.random;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution2 = new org.apache.commons.math3.distribution.GammaDistribution((double) 4418713979230659041L, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            int int5 = randomDataGenerator0.nextPascal((int) (byte) 0, (double) 4418713979230659041L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of successes (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double4 = randomDataGenerator0.nextUniform(0.36787944117144233d, (double) 1L, true);
        // The following exception was thrown during execution in test generation
        try {
            double double7 = randomDataGenerator0.nextGaussian(1.0E-9d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "1) test003(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9192858798725589d + "'", double4 == 0.9192858798725589d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            double double5 = randomDataGenerator0.nextWeibull((double) 0L, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double4 = randomDataGenerator0.nextUniform(0.36787944117144233d, (double) 1L, true);
        int[] intArray7 = randomDataGenerator0.nextPermutation((int) (short) 100, (int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            long long10 = randomDataGenerator0.nextSecureLong(0L, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "2) test005(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9066072641705629d + "'", double4 == 0.9066072641705629d);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        // The following exception was thrown during execution in test generation
        try {
            double double13 = randomDataImpl8.nextUniform(0.0d, (-0.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (-0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution9 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int10 = randomDataImpl8.nextInversionDeviate(integerDistribution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray13 = randomDataImpl8.nextPermutation((int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (0) exceeds permuation domain (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(5865.081109543426d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            int int11 = randomDataImpl8.nextZipf((int) (byte) -1, 0.6483608274590866d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: dimension (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(22.845767186571127d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution11 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int12 = randomDataImpl8.nextInversionDeviate(integerDistribution11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray6 = randomDataGenerator0.nextPermutation(1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (100) exceeds permuation domain (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "3) test013(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.001328986454106026d + "'", double3 == 0.001328986454106026d);
    }

    @Test
    public void test014() {}
// Defects4J: flaky method
//     @Test
//     public void test014() throws Throwable {
//         if (debug)
//             System.out.format("%n%s%n", "RegressionTest0.test014");
//         org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
//         randomDataGenerator0.reSeedSecure((long) (short) 1);
//         double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
//         // The following exception was thrown during execution in test generation
//         try {
//             randomDataGenerator0.setSecureAlgorithm("org.apache.commons.math3.exception.MathIllegalStateException: illegal state", "org.apache.commons.math3.exception.MathIllegalStateException: illegal state");
//             org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.MathIllegalStateException: illegal state");
//         } catch (java.security.NoSuchProviderException e) {
//             // Expected exception.
//         }
//         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
//     }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        // The following exception was thrown during execution in test generation
        try {
            double double23 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (10.919) must be less than or equal to upper endpoint (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            long long12 = randomDataImpl8.nextLong(100L, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        int int3 = well19937c1.nextInt();
        int int5 = well19937c1.next(100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-401038879) + "'", int3 == (-401038879));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double4 = randomDataGenerator0.nextUniform(0.36787944117144233d, (double) 1L, true);
        int[] intArray7 = randomDataGenerator0.nextPermutation((int) (short) 100, (int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray10 = randomDataGenerator0.nextPermutation(251174, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "4) test018(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.36798838438234793d + "'", double4 == 0.36798838438234793d);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        // The following exception was thrown during execution in test generation
        try {
            double double8 = gammaDistribution3.cumulativeProbability(32.00000381469727d, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (32) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double3 = normalDistribution2.sample();
// flaky "5) test020(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-12.056189154025242d) + "'", double3 == (-12.056189154025242d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double23 = logNormalDistribution17.cumulativeProbability(0.0d, (double) 1342499381265206610L);
        // The following exception was thrown during execution in test generation
        try {
            double double26 = logNormalDistribution17.cumulativeProbability((double) 1L, (-12.056189154025242d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1) must be less than or equal to upper endpoint (-12.056)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) (-1L), (double) 1.0f, (double) 1342499381265206610L);
        // The following exception was thrown during execution in test generation
        try {
            double double6 = logNormalDistribution3.probability((double) (byte) 100, (-0.9999999999999999d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (100) must be less than or equal to upper endpoint (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        // The following exception was thrown during execution in test generation
        try {
            long long15 = randomDataImpl8.nextLong(10L, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        // The following exception was thrown during execution in test generation
        try {
            int int20 = randomDataImpl8.nextSecureInt(251174, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (251,174) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(1.5223961928507554d, (-0.14476482730108392d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-0.145)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            int int12 = randomDataImpl8.nextSecureInt((int) 'a', 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (97) must be strictly less than upper bound (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
// flaky "1) test027(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "6) test027(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-258960070L) + "'", long8 == (-258960070L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray20 = randomDataImpl8.nextPermutation((int) '#', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getShape();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getSupportLowerBound();
        double double22 = logNormalDistribution17.getScale();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        // The following exception was thrown during execution in test generation
        try {
            int int12 = randomDataGenerator0.nextHypergeometric((-387737817), 32, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (-387,737,817)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "7) test031(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000014299902d + "'", double5 == 0.5000000014299902d);
// flaky "2) test031(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-320907744L) + "'", long8 == (-320907744L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        // The following exception was thrown during execution in test generation
        try {
            long long7 = randomDataGenerator0.nextPoisson((-0.14476482730108392d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-0.145)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "8) test032(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.49021552115320444d + "'", double3 == 0.49021552115320444d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(0.8822285080719574d, 0.7801559393041577d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        // The following exception was thrown during execution in test generation
        try {
            double double23 = logNormalDistribution17.probability(0.7801553784038603d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.78) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        well19937c1.setSeed(3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        double double6 = randomDataGenerator0.nextGaussian(0.7801559393041577d, 1.0E-6d);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = randomDataGenerator0.nextHypergeometric((int) (byte) 10, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: sample size (52) must be less than or equal to population size (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "9) test036(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1674706703914244d + "'", double3 == 1.1674706703914244d);
// flaky "3) test036(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7801560055594164d + "'", double6 == 0.7801560055594164d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i2;
        double double8 = well19937c1.nextDouble();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = randomDataImpl8.nextHexString((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = randomDataGenerator0.nextInt((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (32) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "10) test039(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.23698780517704d + "'", double3 == 34.23698780517704d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray12 = randomDataGenerator9.nextPermutation(0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (1) exceeds permuation domain (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        double double6 = randomDataGenerator0.nextGaussian(0.7801559393041577d, 1.0E-6d);
        // The following exception was thrown during execution in test generation
        try {
            long long8 = randomDataGenerator0.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "11) test041(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8675484092665204d + "'", double3 == 0.8675484092665204d);
// flaky "4) test041(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.780155979499808d + "'", double6 == 0.780155979499808d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        double double20 = randomDataImpl8.nextUniform(0.0d, 0.5000000013965371d);
        // The following exception was thrown during execution in test generation
        try {
            int int23 = randomDataImpl8.nextInt(646549088, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (646,549,088) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.27433221325624985d + "'", double20 == 0.27433221325624985d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        // The following exception was thrown during execution in test generation
        try {
            long long20 = randomDataImpl8.nextLong((long) 32, (long) (-401038879));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (32) must be strictly less than upper bound (-401,038,879)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        // The following exception was thrown during execution in test generation
        try {
            double double20 = randomDataImpl8.nextUniform(2.0d, 1.2066935116126527d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (2) must be strictly less than upper bound (1.207)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            long long12 = randomDataGenerator0.nextSecureLong((long) '4', (long) 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (52) must be strictly less than upper bound (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "12) test045(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "5) test045(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-331332635L) + "'", long8 == (-331332635L));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 251174);
        int[] intArray2 = well19937c1.iRm2;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.NormalDistribution normalDistribution6 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-0.0d), 0.0d, 0.10899587506437315d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        int[] intArray7 = new int[] { (short) -1, 646549088, 6, (-401038879) };
        well19937c1.setSeed(intArray7);
        well19937c1.setSeed((int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { (-1), 646549088, 6, (-401038879) });
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray9 = randomDataGenerator0.nextPermutation(0, 646549088);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (646,549,088) exceeds permuation domain (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "13) test048(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4031618891237856d + "'", double3 == 1.4031618891237856d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        // The following exception was thrown during execution in test generation
        try {
            double[] doubleArray4 = logNormalDistribution2.sample((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.0d, 0.6874872252363187d, 102400.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        well19937c1.clear();
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = randomDataGenerator0.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "14) test052(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5719046071532417d + "'", double3 == 0.5719046071532417d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        long long9 = randomDataGenerator0.nextPoisson((double) 100L);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray12 = randomDataGenerator0.nextPermutation(0, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (6) exceeds permuation domain (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "15) test053(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.023767526205583887d + "'", double3 == 0.023767526205583887d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
// flaky "6) test053(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long9 + "' != '" + 101L + "'", long9 == 101L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        // The following exception was thrown during execution in test generation
        try {
            long long15 = randomDataImpl8.nextSecureLong((long) ' ', (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (32) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        // The following exception was thrown during execution in test generation
        try {
            int int8 = randomDataGenerator0.nextSecureInt(10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "16) test055(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6271857529675268d + "'", double3 == 0.6271857529675268d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        double double9 = randomDataGenerator0.nextUniform((double) (short) -1, (-0.8177111776375223d));
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray12 = randomDataGenerator0.nextPermutation((int) (byte) 100, 1028812019);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (1,028,812,019) exceeds permuation domain (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "17) test056(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.25358525585303093d) + "'", double3 == (-0.25358525585303093d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
// flaky "7) test056(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8947001627892754d) + "'", double9 == (-0.8947001627892754d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        double double9 = randomDataGenerator0.nextUniform((double) (short) -1, (-0.8177111776375223d));
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = randomDataGenerator0.nextHexString((-401038879));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-401,038,879)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "18) test057(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2164564087145406d + "'", double3 == 1.2164564087145406d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
// flaky "8) test057(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.9435686944579796d) + "'", double9 == (-0.9435686944579796d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        well19937c1.clear();
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        double double6 = randomDataGenerator0.nextGaussian(0.7801559393041577d, 1.0E-6d);
        // The following exception was thrown during execution in test generation
        try {
            long long9 = randomDataGenerator0.nextLong((long) 251174, (long) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (251,174) must be strictly less than upper bound (32)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "19) test059(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8909214008086933d + "'", double3 == 0.8909214008086933d);
// flaky "9) test059(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7801548990106372d + "'", double6 == 0.7801548990106372d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(2.718281828459045d, (double) (-1L), 1.059529144682836d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            int int9 = randomDataGenerator0.nextZipf(10, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: exponent (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "20) test061(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1381357859903087d + "'", double3 == 1.1381357859903087d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        double double9 = randomDataGenerator0.nextUniform((double) (short) -1, (-0.8177111776375223d));
        double double11 = randomDataGenerator0.nextExponential(0.1951490178062096d);
// flaky "21) test062(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8461265194818387d + "'", double3 == 0.8461265194818387d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
// flaky "10) test062(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.9153251930827615d) + "'", double9 == (-0.9153251930827615d));
// flaky "1) test062(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.17844868096790079d + "'", double11 == 0.17844868096790079d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            double double21 = randomDataImpl8.nextGaussian((-0.9153251930827615d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        // The following exception was thrown during execution in test generation
        try {
            long long22 = randomDataImpl8.nextLong((long) 622, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (622) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double25 = logNormalDistribution17.cumulativeProbability(Double.NEGATIVE_INFINITY);
        // The following exception was thrown during execution in test generation
        try {
            double double28 = logNormalDistribution17.probability(0.22969314751614026d, 0.20676466469650645d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.23) must be less than or equal to upper endpoint (0.207)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = randomDataImpl8.nextHexString((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        int int15 = randomDataImpl8.nextZipf((int) ' ', (double) (short) 100);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        randomDataImpl8.reSeedSecure((long) (-1));
        // The following exception was thrown during execution in test generation
        try {
            double double20 = randomDataImpl8.nextF(0.0d, 0.6566380334237375d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            double double12 = randomDataGenerator0.nextBeta(1.34249938126520653E18d, 9.332621544394412E155d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ConvergenceException; message: illegal state: Continued fraction diverged to NaN for value 0.5");
        } catch (org.apache.commons.math3.exception.ConvergenceException e) {
            // Expected exception.
        }
// flaky "2) test069(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "22) test069(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-311771554L) + "'", long8 == (-311771554L));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) (short) 100, (double) (-105L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-105)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        // The following exception was thrown during execution in test generation
        try {
            double double16 = randomDataImpl8.nextGamma((double) (-47.0f), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-47)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "11) test071(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("hi!", "cc70d81dc4983483dacce54d227fe7f0bbb2b7ff9129807a958b");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: cc70d81dc4983483dacce54d227fe7f0bbb2b7ff9129807a958b");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
// flaky "23) test072(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8772557353506683d + "'", double3 == 2.8772557353506683d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(1.000000000000002E-288d, (-9.115337148800332d), 0.04624245251182229d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-9.115)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(182.3918103676576d, 6.27147468593853E-47d, 190.06556510850848d);
        double double5 = logNormalDistribution3.density(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        // The following exception was thrown during execution in test generation
        try {
            int int21 = randomDataImpl8.nextHypergeometric((int) (byte) 1, (int) (byte) -1, (-401038879));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        double double9 = randomDataGenerator0.nextUniform((double) (short) -1, (-0.8177111776375223d));
        // The following exception was thrown during execution in test generation
        try {
            double double11 = randomDataGenerator0.nextT(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "24) test076(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8750746304309536d + "'", double3 == 0.8750746304309536d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
// flaky "12) test076(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8660440891924965d) + "'", double9 == (-0.8660440891924965d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator22 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            int int26 = randomDataImpl8.nextHypergeometric((int) ' ', (int) (short) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertNotNull(randomDataGenerator22);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        int int15 = randomDataGenerator0.nextPascal((int) (byte) 1, 0.3934606808571868d);
        // The following exception was thrown during execution in test generation
        try {
            int int19 = randomDataGenerator0.nextHypergeometric(4, (int) (byte) 1, 1028812019);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: sample size (1,028,812,019) must be less than or equal to population size (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "25) test078(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3622091520580193d + "'", double3 == 1.3622091520580193d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed((long) (short) 1);
        long long11 = well19937c1.nextLong();
        well19937c1.setSeed(1L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1342499381265206610L + "'", long11 == 1342499381265206610L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        randomDataGenerator0.reSeedSecure();
        double double9 = randomDataGenerator0.nextBeta((double) 35L, 32.00000381469727d);
// flaky "26) test080(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.018010145599590466d) + "'", double3 == (-0.018010145599590466d));
// flaky "13) test080(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5431525999609425d + "'", double9 == 0.5431525999609425d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double6 = gammaDistribution3.getScale();
        boolean boolean7 = gammaDistribution3.isSupportUpperBoundInclusive();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            int int22 = randomDataImpl8.nextInt(100, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
// flaky "27) test082(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "2a6e8cd5a40c1f05e599f4d3f10a24e0441a278b315551b9aab91cd6848843a8d881a6212f8b18ca4817e79f2a8ad67f3" + "'", str19, "2a6e8cd5a40c1f05e599f4d3f10a24e0441a278b315551b9aab91cd6848843a8d881a6212f8b18ca4817e79f2a8ad67f3");
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        double double23 = randomDataImpl8.nextExponential((double) 1342499381265206610L);
        // The following exception was thrown during execution in test generation
        try {
            int int26 = randomDataImpl8.nextSecureInt((int) (short) 100, (-47));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (100) must be strictly less than upper bound (-47)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.07450506512479923E18d + "'", double23 == 1.07450506512479923E18d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) (-1L), (double) 1.0f, (double) 1342499381265206610L);
        double double4 = logNormalDistribution3.sample();
// flaky "28) test085(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3510058119179424d + "'", double4 == 0.3510058119179424d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        int int15 = randomDataGenerator0.nextPascal((int) (byte) 1, 0.3934606808571868d);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = randomDataGenerator0.nextHexString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "29) test086(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.40826872680993953d + "'", double3 == 0.40826872680993953d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) (byte) -1, (double) 4418713979230659041L, 1225.0d);
        boolean boolean4 = logNormalDistribution3.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        java.lang.String str11 = randomDataGenerator9.nextHexString((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            double double13 = randomDataGenerator9.nextExponential((-0.1954362155315824d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-0.195)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "6121986868" + "'", str11, "6121986868");
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double9 = well19937c1.nextDouble();
        float float10 = well19937c1.nextFloat();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9066258578518134d + "'", double9 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.32099235f + "'", float10 == 0.32099235f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        double double23 = randomDataImpl8.nextExponential((double) 1342499381265206610L);
        // The following exception was thrown during execution in test generation
        try {
            int int27 = randomDataImpl8.nextHypergeometric(0, (int) (short) 10, 1028812019);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.07450506512479923E18d + "'", double23 == 1.07450506512479923E18d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextUniform(0.0d, 3.310625339433012d);
        double double7 = randomDataGenerator0.nextT(0.5000000015046252d);
        // The following exception was thrown during execution in test generation
        try {
            double double10 = randomDataGenerator0.nextGamma((-0.7615941559557649d), 7.896296018268069E13d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.762)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "30) test091(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.589530774119059d + "'", double5 == 1.589530774119059d);
// flaky "14) test091(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.226859001500772d + "'", double7 == 4.226859001500772d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i2;
        boolean boolean8 = well19937c1.nextBoolean();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution12 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 622, 0.0d, 0.9344990255569874d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString((int) 'a');
        int int22 = randomDataImpl8.nextSecureInt((-387737817), (int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            double double25 = randomDataImpl8.nextGamma(0.4909240332679956d, (-4.945707578252165E-178d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
// flaky "31) test093(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "e1662543201298a68d6662d522e10f2c2b802eb4da765d1abedae2ebd0bcc3966c196ceae1dd869dd6eaa1b8e20d9dbde" + "'", str19, "e1662543201298a68d6662d522e10f2c2b802eb4da765d1abedae2ebd0bcc3966c196ceae1dd869dd6eaa1b8e20d9dbde");
// flaky "15) test093(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-72480109) + "'", int22 == (-72480109));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        int int18 = randomDataImpl8.nextSecureInt((int) (byte) 10, 2147483647);
        // The following exception was thrown during execution in test generation
        try {
            int int21 = randomDataImpl8.nextInt(2147483647, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (2,147,483,647) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
// flaky "32) test094(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1782824350 + "'", int18 == 1782824350);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        java.lang.String str15 = randomDataImpl8.nextSecureHexString((int) '4');
        // The following exception was thrown during execution in test generation
        try {
            double double17 = randomDataImpl8.nextT((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
// flaky "33) test095(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str15 + "' != '" + "bbb7c49e391b8a3c70b8f90034ad01e42d94c70ad3eecad026c8" + "'", str15, "bbb7c49e391b8a3c70b8f90034ad01e42d94c70ad3eecad026c8");
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGaussian(1.5707963267948966d, 2.9496875887749894E19d);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution20 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int21 = randomDataImpl8.nextInversionDeviate(integerDistribution20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0185362398551933E19d) + "'", double19 == (-3.0185362398551933E19d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        int int4 = well19937c1.next(2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 409060042 + "'", int4 == 409060042);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.sample();
        double double7 = normalDistribution2.cumulativeProbability(190.06556510850848d);
        boolean boolean8 = normalDistribution2.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
// flaky "34) test098(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.672868603936274d + "'", double5 == 7.672868603936274d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator22 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            int int26 = randomDataGenerator22.nextHypergeometric((int) '4', (int) (short) 100, 1152985812);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (100) must be less than or equal to population size (52)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertNotNull(randomDataGenerator22);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        int int9 = randomDataGenerator0.nextSecureInt(0, 646549088);
        // The following exception was thrown during execution in test generation
        try {
            int int12 = randomDataGenerator0.nextBinomial((-127), 0.5871973525778662d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of trials (-127)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "35) test100(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.00830583538762594d + "'", double3 == 0.00830583538762594d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
// flaky "16) test100(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int9 + "' != '" + 363227522 + "'", int9 == 363227522);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray7 = randomDataGenerator0.nextPermutation(1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (-1");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "36) test101(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8720093171034127d + "'", double3 == 0.8720093171034127d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        float float14 = well19937c1.nextFloat();
        well19937c1.setSeed(1L);
        boolean boolean17 = well19937c1.nextBoolean();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5871973f + "'", float14 == 0.5871973f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        double double17 = randomDataImpl8.nextT(1.5287994033960568d);
        double double20 = randomDataImpl8.nextBeta(0.7801553784038603d, (double) 2940458407815999488L);
        // The following exception was thrown during execution in test generation
        try {
            long long23 = randomDataImpl8.nextSecureLong(4L, (-106654808L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (4) must be strictly less than upper bound (-106,654,808)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.22969314751614026d + "'", double17 == 0.22969314751614026d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0219671297446623E-9d + "'", double20 == 1.0219671297446623E-9d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        java.lang.String str11 = randomDataGenerator9.nextHexString((int) (short) 10);
        double double13 = randomDataGenerator9.nextChiSquare(1.0885361397061086E-13d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "6121986868" + "'", str11, "6121986868");
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextBeta((double) 32L, 1.34249938126520653E18d);
        // The following exception was thrown during execution in test generation
        try {
            double double21 = randomDataImpl8.nextUniform(19.194552074112874d, 0.5456928232039928d, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (19.195) must be strictly less than upper bound (0.546)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0754202590107506E-9d + "'", double17 == 1.0754202590107506E-9d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double9 = gammaDistribution3.cumulativeProbability((double) 646549088);
        double double10 = gammaDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 60.46475370663325d + "'", double10 == 60.46475370663325d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 32L, 0.14218002608626515d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl8.setSecureAlgorithm("", "org.apache.commons.math3.exception.NotANumberException: NaN is not allowed");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.NotANumberException: NaN is not allowed");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
// flaky "37) test108(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "3ebd4dd96baa5b0c2925aeeed948c80433609dccf9584442c36dafbf210dcf08e67bc8e0765fa41b2cc13d07c83bf956c" + "'", str19, "3ebd4dd96baa5b0c2925aeeed948c80433609dccf9584442c36dafbf210dcf08e67bc8e0765fa41b2cc13d07c83bf956c");
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        // The following exception was thrown during execution in test generation
        try {
            double double23 = logNormalDistribution17.cumulativeProbability((double) 3.8146973E-6f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        double double23 = randomDataImpl8.nextExponential((double) 1342499381265206610L);
        // The following exception was thrown during execution in test generation
        try {
            double double27 = randomDataImpl8.nextUniform(22.845767186571127d, (double) (-42005975), false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (22.846) must be strictly less than upper bound (-42,005,975)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.07450506512479923E18d + "'", double23 == 1.07450506512479923E18d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        double double6 = randomDataGenerator0.nextGaussian(0.7801559393041577d, 1.0E-6d);
        double double9 = randomDataGenerator0.nextUniform(0.0d, (double) 10.0f);
// flaky "38) test111(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3195844453126278d + "'", double3 == 1.3195844453126278d);
// flaky "17) test111(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7801561409794002d + "'", double6 == 0.7801561409794002d);
// flaky "3) test111(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 6.3460305736404194d + "'", double9 == 6.3460305736404194d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeed();
        long long7 = randomDataGenerator0.nextSecureLong((long) 1, 4418713979230659041L);
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("", "3b81bf4ab79777fa9edcaf3aba2df537def7baad9bd0410bae279c467393ed469975b2dd95de16eece09f8d5124b90241");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 3b81bf4ab79777fa9edcaf3aba2df537def7baad9bd0410bae279c467393ed469975b2dd95de16eece09f8d5124b90241");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
// flaky "39) test112(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.44168412101060117d + "'", double3 == 0.44168412101060117d);
// flaky "18) test112(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3409484885712499712L + "'", long7 == 3409484885712499712L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray17 = randomDataImpl8.nextPermutation(0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (100) exceeds permuation domain (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        double double23 = randomDataImpl8.nextExponential((double) 1342499381265206610L);
        // The following exception was thrown during execution in test generation
        try {
            int int26 = randomDataImpl8.nextBinomial((int) (short) 10, 19.194552074112874d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 19.195 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.07450506512479923E18d + "'", double23 == 1.07450506512479923E18d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c(intArray7);
        int int10 = well19937c8.nextInt(251174);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 96691 + "'", int10 == 96691);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 10);
        // The following exception was thrown during execution in test generation
        try {
            double double15 = randomDataImpl8.nextUniform(0.8822285080719574d, 0.04232968535189235d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0.882) must be strictly less than upper bound (0.042)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        boolean boolean3 = well19937c1.nextBoolean();
        int int4 = well19937c1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-401038879) + "'", int4 == (-401038879));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        long long2 = well19937c1.nextLong();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator3 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3513799009476651814L + "'", long2 == 3513799009476651814L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        double double15 = randomDataImpl8.nextT(2.0d);
        // The following exception was thrown during execution in test generation
        try {
            double double18 = randomDataImpl8.nextUniform((double) 32.000004f, 0.08208508388365023d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (32) must be strictly less than upper bound (0.082)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "19) test119(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7874548671504324d + "'", double15 == 0.7874548671504324d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        boolean boolean3 = well19937c1.nextBoolean();
        double double4 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.04677838737026563d + "'", double4 == 0.04677838737026563d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            double double11 = randomDataImpl8.nextGamma(0.0d, (double) 7.6293945E-6f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextBeta(97.0d, (double) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            long long14 = randomDataGenerator0.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "40) test122(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.28508827417685295d + "'", double3 == 0.28508827417685295d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9830505425759046d + "'", double12 == 0.9830505425759046d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(0.3678794411714422d, (-0.0460158355740473d), (double) (-93467950L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.046)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        randomDataImpl8.reSeedSecure((long) (-1));
        double double19 = randomDataImpl8.nextExponential(1.2066935116126527d);
        java.lang.Class<?> wildcardClass20 = randomDataImpl8.getClass();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.18670409752493586d + "'", double19 == 0.18670409752493586d);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = randomDataGenerator0.nextSecureHexString((-387737817));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-387,737,817)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "41) test125(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.316776638870833d + "'", double3 == 1.316776638870833d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        boolean boolean3 = normalDistribution2.isSupportLowerBoundInclusive();
        boolean boolean4 = normalDistribution2.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("6121986868", "org.apache.commons.math3.exception.MathIllegalStateException: illegal state");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.MathIllegalStateException: illegal state");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
// flaky "42) test127(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5475055126666463d + "'", double3 == 0.5475055126666463d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getSupportLowerBound();
        double double7 = gammaDistribution3.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            int int10 = randomDataGenerator0.nextPascal((int) '#', (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 52 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
// flaky "43) test129(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.011356135465865823d + "'", double3 == 0.011356135465865823d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.random.Well19937c well19937c12 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray16 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c12.nextBytes(byteArray16);
        int[] intArray18 = well19937c12.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c12);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator20 = randomDataImpl19.getDelegate();
        java.lang.String str22 = randomDataGenerator20.nextHexString((int) (short) 10);
        int[] intArray25 = randomDataGenerator20.nextPermutation((int) '#', 2);
        well19937c1.setSeed(intArray25);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertArrayEquals(byteArray16, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(randomDataGenerator20);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "6121986868" + "'", str22, "6121986868");
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertArrayEquals(intArray25, new int[] { 11, 5 });
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString((int) 'a');
        int int22 = randomDataImpl8.nextSecureInt((-387737817), (int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            long long25 = randomDataImpl8.nextSecureLong((long) (byte) 0, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
// flaky "44) test131(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "545f86a320231644a3ac6e7f900867c69c91fdf934d3353d5adf8150c969b2734d2852a35a1a342e2f91bb5831d64f9cc" + "'", str19, "545f86a320231644a3ac6e7f900867c69c91fdf934d3353d5adf8150c969b2734d2852a35a1a342e2f91bb5831d64f9cc");
// flaky "20) test131(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-127697869) + "'", int22 == (-127697869));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((double) 6L, (double) 0.5871973f, 0.16590809027000164d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        double double23 = randomDataImpl8.nextExponential((double) 1342499381265206610L);
        int int26 = randomDataImpl8.nextInt(92410965, 1028812019);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution27 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int28 = randomDataImpl8.nextInversionDeviate(integerDistribution27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.07450506512479923E18d + "'", double23 == 1.07450506512479923E18d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 614504715 + "'", int26 == 614504715);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray9 = well19937c1.iRm2;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution13 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.0d, 0.0d, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl8.setSecureAlgorithm("cc70d81dc4983483dacce54d227fe7f0bbb2b7ff9129807a958b", "org.apache.commons.math3.exception.OutOfRangeException: 32 out of [0.717, 10] range");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.OutOfRangeException: 32 out of [0.717, 10] range");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        boolean boolean9 = well19937c1.nextBoolean();
        double double10 = well19937c1.nextGaussian();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.5260712867320414d) + "'", double10 == (-1.5260712867320414d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        double double1 = well19937c0.nextGaussian();
        well19937c0.index = (short) 10;
// flaky "45) test137(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.177832417027476d + "'", double1 == 1.177832417027476d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution((-0.7615941559557649d), 0.4995186051605274d, 0.2170872048711684d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.762)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) '#');
        well19937c1.setSeed((-105L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        // The following exception was thrown during execution in test generation
        try {
            double double23 = logNormalDistribution17.cumulativeProbability(0.49668503032772426d, 0.004093928401859652d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.497) must be less than or equal to upper endpoint (0.004)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double24 = logNormalDistribution17.sample();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        // The following exception was thrown during execution in test generation
        try {
            double double15 = randomDataGenerator0.nextGaussian(1.0219671297446623E-9d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "46) test142(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.05793058178872d + "'", double3 == 2.05793058178872d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        boolean boolean3 = normalDistribution2.isSupportLowerBoundInclusive();
        double double6 = normalDistribution2.cumulativeProbability(1.7453292519943298E-11d, 1.0E-6d);
        // The following exception was thrown during execution in test generation
        try {
            double double9 = normalDistribution2.cumulativeProbability(0.09568586753240192d, (double) (-7796297722204279230L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.096) must be less than or equal to upper endpoint (-7,796,297,722,204,278,800)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.96945621303213E-8d + "'", double6 == 3.96945621303213E-8d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeedSecure((long) (byte) 0);
        // The following exception was thrown during execution in test generation
        try {
            int int9 = randomDataGenerator0.nextHypergeometric(0, (int) '4', 622);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "47) test144(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.117131888931092d + "'", double3 == 7.117131888931092d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getScale();
        boolean boolean22 = logNormalDistribution17.isSupportConnected();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray21 = randomDataImpl8.nextPermutation((int) (byte) 100, 83782171);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (83,782,171) exceeds permuation domain (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
        org.junit.Assert.assertNotNull(randomDataGenerator18);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getScale();
        double double22 = logNormalDistribution17.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.POSITIVE_INFINITY + "'", double22 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double11 = randomDataGenerator0.nextExponential(0.6874872252363187d);
        double double14 = randomDataGenerator0.nextGamma((double) (short) 1, 41.74106476041107d);
        int int17 = randomDataGenerator0.nextInt((int) '#', (int) (short) 100);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str19 = randomDataGenerator0.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "48) test148(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1284143742303219d + "'", double3 == 1.1284143742303219d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.3132117912189065d + "'", double11 == 1.3132117912189065d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.302538425400456d + "'", double14 == 10.302538425400456d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 78 + "'", int17 == 78);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 83782171);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double4 = gammaDistribution3.sample();
        double double5 = gammaDistribution3.sample();
        double double6 = gammaDistribution3.getSupportLowerBound();
// flaky "49) test150(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2101007051928083d + "'", double4 == 1.2101007051928083d);
// flaky "21) test150(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4709806590055938d + "'", double5 == 0.4709806590055938d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((double) (-47), (double) 9.2410968E7f, 0.011393699429840523d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution14 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8822285080719574d, 0.5456928232039928d, (double) 32L);
        double double15 = gammaDistribution14.getSupportUpperBound();
        double double16 = gammaDistribution14.getNumericalVariance();
        double double17 = gammaDistribution14.getScale();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.26271058501924055d + "'", double16 == 0.26271058501924055d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5456928232039928d + "'", double17 == 0.5456928232039928d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.sample();
        double double7 = normalDistribution2.probability(6.27147468593853E-47d);
        boolean boolean8 = normalDistribution2.isSupportUpperBoundInclusive();
        double double11 = normalDistribution2.cumulativeProbability((double) (-105L), 3.795976917120154d);
        double double12 = normalDistribution2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
// flaky "50) test153(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.68317934810376d + "'", double5 == 7.68317934810376d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6101069108767376d + "'", double11 == 0.6101069108767376d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeed();
        int int7 = randomDataGenerator0.nextSecureInt((int) '4', (int) (byte) 100);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = randomDataGenerator0.nextSecureInt((int) '4', 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (52) must be strictly less than upper bound (4)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "51) test154(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9958729096164871d + "'", double3 == 0.9958729096164871d);
// flaky "22) test154(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int7 + "' != '" + 63 + "'", int7 == 63);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        double double10 = randomDataGenerator0.nextGaussian(0.6670445231839455d, 35.0d);
        // The following exception was thrown during execution in test generation
        try {
            int int13 = randomDataGenerator0.nextSecureInt((int) (byte) 0, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (-127)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "52) test155(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0116990532744268d + "'", double3 == 3.0116990532744268d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
// flaky "23) test155(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-7.401781798140568d) + "'", double10 == (-7.401781798140568d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        boolean boolean3 = normalDistribution2.isSupportLowerBoundInclusive();
        double double6 = normalDistribution2.cumulativeProbability(1.7453292519943298E-11d, 1.0E-6d);
        double double7 = normalDistribution2.getNumericalVariance();
        double double8 = normalDistribution2.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.96945621303213E-8d + "'", double6 == 3.96945621303213E-8d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 251174);
        int int3 = well19937c1.next(646549088);
        boolean boolean4 = well19937c1.nextBoolean();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-387737817) + "'", int3 == (-387737817));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        boolean boolean3 = well19937c1.nextBoolean();
        well19937c1.index = (-47);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        // The following exception was thrown during execution in test generation
        try {
            double double12 = randomDataGenerator0.nextF((double) 4, (-0.07783207834478786d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-0.078)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "53) test159(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.19934354833196707d + "'", double3 == 0.19934354833196707d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        double double23 = randomDataImpl8.nextExponential((double) 1342499381265206610L);
        // The following exception was thrown during execution in test generation
        try {
            double double26 = randomDataImpl8.nextUniform(6.3460305736404194d, 1.772453845669073d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (6.346) must be strictly less than upper bound (1.772)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.07450506512479923E18d + "'", double23 == 1.07450506512479923E18d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        // The following exception was thrown during execution in test generation
        try {
            double double19 = randomDataImpl8.nextUniform(1.3132117912189065d, 1.2101007051928083d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1.313) must be strictly less than upper bound (1.21)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        // The following exception was thrown during execution in test generation
        try {
            long long9 = randomDataGenerator0.nextSecureLong((long) 10, 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "54) test162(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6886289997275183d + "'", double3 == 0.6886289997275183d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        boolean boolean10 = well19937c1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        double double15 = randomDataImpl8.nextT(2.0d);
        randomDataImpl8.reSeedSecure(1L);
        // The following exception was thrown during execution in test generation
        try {
            int int21 = randomDataImpl8.nextHypergeometric((int) (byte) 0, 0, 92410965);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: population size (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "4) test164(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7874548671504324d + "'", double15 == 0.7874548671504324d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.getNumericalVariance();
        double double6 = normalDistribution2.getNumericalVariance();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            long long21 = randomDataImpl8.nextSecureLong(35L, (-106654808L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (35) must be strictly less than upper bound (-106,654,808)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
        org.junit.Assert.assertNotNull(randomDataGenerator18);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double2 = normalDistribution0.inverseCumulativeProbability((double) 0);
        double double3 = normalDistribution0.sample();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
// flaky "55) test167(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.7899699621137186d) + "'", double3 == (-2.7899699621137186d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double4 = gammaDistribution3.sample();
        double double5 = gammaDistribution3.sample();
        boolean boolean6 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double7 = gammaDistribution3.getSupportUpperBound();
// flaky "56) test168(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 130.44171221209967d + "'", double4 == 130.44171221209967d);
// flaky "24) test168(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 51.110539882904995d + "'", double5 == 51.110539882904995d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double1 = normalDistribution0.getNumericalVariance();
        boolean boolean2 = normalDistribution0.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double23 = logNormalDistribution17.cumulativeProbability(0.0d, (double) 1342499381265206610L);
        double double24 = logNormalDistribution17.sample();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        java.lang.String str10 = randomDataGenerator0.nextSecureHexString((int) '4');
        double double13 = randomDataGenerator0.nextGamma((double) 100.00001f, (double) 2147483647);
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("org.apache.commons.math3.exception.NumberIsTooSmallException: 10 is smaller than, or equal to, the minimum (1)", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
// flaky "57) test171(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "25) test171(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-174209170L) + "'", long8 == (-174209170L));
// flaky "5) test171(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str10 + "' != '" + "4e2cef6960fc9dd98dc3a948daba8dd28da9854cf7226f45928e" + "'", str10, "4e2cef6960fc9dd98dc3a948daba8dd28da9854cf7226f45928e");
// flaky "1) test171(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.1525903560441193E11d + "'", double13 == 2.1525903560441193E11d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        // The following exception was thrown during execution in test generation
        try {
            double double12 = randomDataGenerator0.nextUniform(0.025766719698081936d, (-8.968421786443887d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0.026) must be strictly less than upper bound (-8.968)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "58) test172(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1895981658493382d + "'", double3 == 0.1895981658493382d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        boolean boolean21 = logNormalDistribution17.isSupportLowerBoundInclusive();
        // The following exception was thrown during execution in test generation
        try {
            double double23 = logNormalDistribution17.inverseCumulativeProbability(0.7165313105737893d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [?, ?]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double2 = normalDistribution0.inverseCumulativeProbability((double) 0);
        double double5 = normalDistribution0.cumulativeProbability((double) (byte) -1, (double) (-1L));
        double double6 = normalDistribution0.sample();
        double double7 = normalDistribution0.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
// flaky "59) test174(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.5101671050850538d + "'", double6 == 1.5101671050850538d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextBeta(97.0d, (double) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            double double14 = randomDataGenerator0.nextChiSquare((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.5)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "60) test175(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.659935469041857d + "'", double3 == 0.659935469041857d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9830505425759046d + "'", double12 == 0.9830505425759046d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        double double13 = randomDataImpl8.nextUniform(0.5176464628744074d, 1.0847303959306388E27d);
        double double15 = randomDataImpl8.nextExponential((double) 127.0f);
        double double19 = randomDataImpl8.nextUniform(0.48092575793941483d, 120.54442181558605d, true);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
// flaky "61) test176(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.399835471825113E26d + "'", double13 == 6.399835471825113E26d);
// flaky "26) test176(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 79.20824041041072d + "'", double15 == 79.20824041041072d);
// flaky "6) test176(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double19 + "' != '" + 53.27555914911568d + "'", double19 == 53.27555914911568d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double18 = logNormalDistribution17.getSupportLowerBound();
        double double19 = logNormalDistribution17.getSupportLowerBound();
        double double20 = logNormalDistribution17.getSupportUpperBound();
        double double21 = logNormalDistribution17.getShape();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.POSITIVE_INFINITY + "'", double21 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            int int22 = randomDataImpl8.nextBinomial((-1), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of trials (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
// flaky "62) test178(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "167e88f6c1a03fdb218215158c6ab88dc1544b9035f2b9f0d2ba0e7bf71c64f1de223ec7ffe1dbda9c2dcbe49e5b93b02" + "'", str19, "167e88f6c1a03fdb218215158c6ab88dc1544b9035f2b9f0d2ba0e7bf71c64f1de223ec7ffe1dbda9c2dcbe49e5b93b02");
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double11 = randomDataGenerator0.nextExponential(0.6874872252363187d);
        double double14 = randomDataGenerator0.nextGamma((double) (short) 1, 41.74106476041107d);
        int int17 = randomDataGenerator0.nextInt((int) '#', (int) (short) 100);
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator0.setSecureAlgorithm("org.apache.commons.math3.exception.MathIllegalStateException: illegal state", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
// flaky "63) test179(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.20839795861238036d + "'", double3 == 0.20839795861238036d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.3132117912189065d + "'", double11 == 1.3132117912189065d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.302538425400456d + "'", double14 == 10.302538425400456d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 78 + "'", int17 == 78);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        gammaDistribution3.reseedRandomGenerator((long) 4);
        // The following exception was thrown during execution in test generation
        try {
            double double11 = gammaDistribution3.inverseCumulativeProbability(190.06556510850848d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 190.066 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        boolean boolean3 = well19937c1.nextBoolean();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            double double7 = randomDataGenerator4.nextGamma(25.96497490563878d, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            long long22 = randomDataImpl8.nextLong((long) '#', (-93467950L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (35) must be strictly less than upper bound (-93,467,950)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
// flaky "64) test182(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "6e8b8d5dce0be72618b3e487b148233ad8bd93a3e8494370074e0dfc12342e3f6f3d3303946c826a5f47e86152b4d4f5e" + "'", str19, "6e8b8d5dce0be72618b3e487b148233ad8bd93a3e8494370074e0dfc12342e3f6f3d3303946c826a5f47e86152b4d4f5e");
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        long long20 = randomDataImpl8.nextPoisson(3.141592653589793d);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl8.setSecureAlgorithm("", "cc70d81dc4983483dacce54d227fe7f0bbb2b7ff9129807a958b");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: cc70d81dc4983483dacce54d227fe7f0bbb2b7ff9129807a958b");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 4L + "'", long20 == 4L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        boolean boolean23 = logNormalDistribution17.isSupportLowerBoundInclusive();
        double double24 = logNormalDistribution17.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextExponential(0.27433221325624985d);
        // The following exception was thrown during execution in test generation
        try {
            double double16 = randomDataImpl8.nextExponential((-1.2321432865208133d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-1.232)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.47008445586152653d + "'", double14 == 0.47008445586152653d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 2);
        int[] intArray2 = well19937c1.i1;
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            int int8 = randomDataGenerator0.nextHypergeometric(32, 622, (-47));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of samples (-47)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "65) test187(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7691634793254903d + "'", double3 == 0.7691634793254903d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        double double20 = randomDataImpl8.nextUniform(0.0d, 0.5000000013965371d);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl8.setSecureAlgorithm("org.apache.commons.math3.exception.OutOfRangeException: 32 out of [0.717, 10] range", "b");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: b");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.27433221325624985d + "'", double20 == 0.27433221325624985d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.0d, 0.8461265194818387d, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        randomDataImpl8.reSeedSecure((long) (-1));
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str19 = randomDataImpl8.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution16 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 100.0f, 1.0219671297446623E-9d, 0.0d);
        // The following exception was thrown during execution in test generation
        try {
            double double19 = logNormalDistribution16.cumulativeProbability(1.000000000000002E-288d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 99L, (double) 2940458407815999488L);
        double double3 = logNormalDistribution2.getNumericalMean();
        // The following exception was thrown during execution in test generation
        try {
            double double6 = logNormalDistribution2.cumulativeProbability(1.2358034437972132d, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1.236) must be less than or equal to upper endpoint (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeed();
        int int7 = randomDataGenerator0.nextSecureInt((int) '4', (int) (byte) 100);
        // The following exception was thrown during execution in test generation
        try {
            long long10 = randomDataGenerator0.nextLong(99L, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (99) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "66) test193(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7070.656661465448d + "'", double3 == 7070.656661465448d);
// flaky "27) test193(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int7 + "' != '" + 55 + "'", int7 == 55);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        int int17 = randomDataImpl8.nextZipf((int) 'a', 0.4995186051605274d);
        // The following exception was thrown during execution in test generation
        try {
            int int20 = randomDataImpl8.nextPascal(0, (double) 149435855);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of successes (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        java.lang.String str11 = randomDataGenerator9.nextHexString((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            double double15 = randomDataGenerator9.nextUniform((double) 1342499381265206610L, 1.2066935116126527d, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,342,499,381,265,206,530) must be strictly less than upper bound (1.207)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "6121986868" + "'", str11, "6121986868");
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.getNumericalVariance();
        double double6 = normalDistribution2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator22 = randomDataImpl8.getDelegate();
        randomDataGenerator22.reSeedSecure();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertNotNull(randomDataGenerator22);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextExponential(0.27433221325624985d);
        // The following exception was thrown during execution in test generation
        try {
            int int18 = randomDataImpl8.nextHypergeometric(3, 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: number of successes (10) must be less than or equal to population size (3)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.47008445586152653d + "'", double14 == 0.47008445586152653d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getSupportUpperBound();
        double double9 = gammaDistribution3.sample();
        double double12 = gammaDistribution3.cumulativeProbability(0.6483608274590866d, (double) 1152985812);
        double double14 = gammaDistribution3.density(2.993222846126381d);
        double double15 = gammaDistribution3.getBeta();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
// flaky "67) test199(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.11876155455066d + "'", double9 == 97.11876155455066d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9509486094206112d + "'", double12 == 0.9509486094206112d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.025766719698081936d + "'", double14 == 0.025766719698081936d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 97.0d + "'", double15 == 97.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getSupportLowerBound();
        double double7 = gammaDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 60.46475370663325d + "'", double7 == 60.46475370663325d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getAlpha();
        double double10 = gammaDistribution3.density(0.47971788545927857d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6233479763570439d + "'", double8 == 0.6233479763570439d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05269977907409859d + "'", double10 == 0.05269977907409859d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        long long3 = well19937c1.nextLong();
        well19937c1.setSeed(326573780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4418713979230659041L + "'", long3 == 4418713979230659041L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        // The following exception was thrown during execution in test generation
        try {
            double double9 = randomDataGenerator0.nextUniform(1.74532925199433E-11d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "68) test203(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.227194119329324d + "'", double3 == 1.227194119329324d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math3.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) (short) 0);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl0.setSecureAlgorithm("b", "605cb1345fe438bb79c2b14df964f013dfc1521161e57ca5b9e127ca5c9e8dfe909839c42ff7e3c9b0d74297913de3926");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 605cb1345fe438bb79c2b14df964f013dfc1521161e57ca5b9e127ca5c9e8dfe909839c42ff7e3c9b0d74297913de3926");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        double double8 = randomDataGenerator0.nextUniform(21.23248944257666d, (double) '#');
        // The following exception was thrown during execution in test generation
        try {
            long long11 = randomDataGenerator0.nextSecureLong((long) 149435855, 52L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (149,435,855) must be strictly less than upper bound (52)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "69) test205(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8365239331923235d + "'", double3 == 0.8365239331923235d);
// flaky "28) test205(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double8 + "' != '" + 33.820803708509516d + "'", double8 == 33.820803708509516d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double4 = gammaDistribution3.sample();
        double double5 = gammaDistribution3.sample();
        boolean boolean6 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double7 = gammaDistribution3.getShape();
// flaky "70) test206(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.433739408408243d + "'", double4 == 4.433739408408243d);
// flaky "29) test206(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.2487305599455707d + "'", double5 == 1.2487305599455707d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6233479763570439d + "'", double7 == 0.6233479763570439d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        float float11 = well19937c1.nextFloat();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution15 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 3.79226455416768d, (double) 4418713979230659041L, 10.302538425400456d);
        // The following exception was thrown during execution in test generation
        try {
            double double18 = gammaDistribution15.cumulativeProbability((double) 35L, 0.6101069108767376d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (35) must be less than or equal to upper endpoint (0.61)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.7685776f + "'", float11 == 0.7685776f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            double double9 = randomDataGenerator0.nextBeta((-4.9E-324d), (double) 73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.5, 0.5]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
            // Expected exception.
        }
// flaky "71) test208(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6787940522563759d + "'", double3 == 0.6787940522563759d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long9 = well19937c1.nextLong();
        org.apache.commons.math3.random.Well19937c well19937c11 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray15 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c11.nextBytes(byteArray15);
        int[] intArray17 = well19937c11.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c11);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator19 = randomDataImpl18.getDelegate();
        java.lang.String str21 = randomDataGenerator19.nextHexString((int) (short) 10);
        int[] intArray24 = randomDataGenerator19.nextPermutation((int) '#', 2);
        well19937c1.setSeed(intArray24);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution29 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.11563859552454996d, 1.029441665221968d, 81.87241173283697d);
        double double31 = normalDistribution29.inverseCumulativeProbability(1.662571845043729E-9d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1722448868039600408L) + "'", long9 == (-1722448868039600408L));
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(randomDataGenerator19);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "6121986868" + "'", str21, "6121986868");
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertArrayEquals(intArray24, new int[] { 11, 5 });
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-97.86618264012287d) + "'", double31 == (-97.86618264012287d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution14 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8822285080719574d, 0.5456928232039928d, (double) 32L);
        double double15 = gammaDistribution14.getAlpha();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.8822285080719574d + "'", double15 == 0.8822285080719574d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGaussian(1.5707963267948966d, 2.9496875887749894E19d);
        randomDataImpl8.reSeedSecure((long) 'a');
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray24 = randomDataImpl8.nextPermutation((int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0185362398551933E19d) + "'", double19 == (-3.0185362398551933E19d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getBeta();
        double double9 = gammaDistribution3.sample();
        double double11 = gammaDistribution3.probability((double) 251174);
        double double13 = gammaDistribution3.probability(0.11570983766281182d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
// flaky "72) test212(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 27.689415334792525d + "'", double9 == 27.689415334792525d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 10);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator13 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str15 = randomDataImpl8.nextHexString((-47));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-47)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(randomDataGenerator13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        int int2 = well19937c0.next((int) (byte) 100);
        well19937c0.setSeed((-401038879));
        double double5 = well19937c0.nextDouble();
// flaky "73) test214(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5538906161314416d + "'", double5 == 0.5538906161314416d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getNumericalVariance();
        double double7 = gammaDistribution3.getSupportLowerBound();
        double double8 = gammaDistribution3.getAlpha();
        gammaDistribution3.reseedRandomGenerator(6L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5865.081109543426d + "'", double6 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6233479763570439d + "'", double8 == 0.6233479763570439d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        randomDataImpl8.reSeedSecure((long) (-1));
        // The following exception was thrown during execution in test generation
        try {
            double double20 = randomDataImpl8.nextGamma(0.48142576528083303d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeedSecure((long) (byte) 0);
        // The following exception was thrown during execution in test generation
        try {
            double double8 = randomDataGenerator0.nextGamma((-0.9995560569658268d), 0.49668503032772426d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "74) test217(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.47229685230741d + "'", double3 == 5.47229685230741d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getSupportLowerBound();
        double double8 = gammaDistribution3.cumulativeProbability(1.4888735920506977d);
        double double9 = gammaDistribution3.getShape();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08208508388365023d + "'", double8 == 0.08208508388365023d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.6233479763570439d + "'", double9 == 0.6233479763570439d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        int int12 = randomDataGenerator9.nextInt(6, 92410965);
        // The following exception was thrown during execution in test generation
        try {
            double double16 = randomDataGenerator9.nextUniform(7.783615591316188E25d, (-4.945707578252165E-178d), false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (77,836,155,913,161,880,000,000,000) must be strictly less than upper bound (-0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 83782171 + "'", int12 == 83782171);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        int int3 = well19937c1.nextInt();
        int int5 = well19937c1.next(3);
        int[] intArray6 = well19937c1.i2;
        well19937c1.index = 0;
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-401038879) + "'", int3 == (-401038879));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGamma(0.5871973525778662d, 0.661011522946662d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05166269032009879d + "'", double19 == 0.05166269032009879d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            double double9 = randomDataGenerator0.nextBeta(9.578115290425256d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 1], values: [-0.968, 0.032]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
            // Expected exception.
        }
// flaky "75) test222(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8300013490752022d + "'", double3 == 0.8300013490752022d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double24 = logNormalDistribution17.getSupportUpperBound();
        double double27 = logNormalDistribution17.probability(0.3934606808571868d, 4.0d);
        double double29 = logNormalDistribution17.cumulativeProbability((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        int int12 = well19937c1.nextInt((int) (byte) 1);
        double double13 = well19937c1.nextDouble();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.283653114497723d + "'", double13 == 0.283653114497723d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        // The following exception was thrown during execution in test generation
        try {
            long long24 = randomDataImpl8.nextLong((long) 251174, (long) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (251,174) must be strictly less than upper bound (52)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        randomDataImpl8.reSeedSecure();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "30) test226(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextUniform(0.0d, 3.310625339433012d);
        double double7 = randomDataGenerator0.nextT(0.5000000015046252d);
        // The following exception was thrown during execution in test generation
        try {
            double double9 = randomDataGenerator0.nextChiSquare((-3.0185362398551933E19d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-15,092,681,199,275,966,000)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "76) test227(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0574033776743326d + "'", double5 == 3.0574033776743326d);
// flaky "31) test227(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-3.260383163536985d) + "'", double7 == (-3.260383163536985d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double18 = logNormalDistribution17.getSupportLowerBound();
        double double19 = logNormalDistribution17.getSupportLowerBound();
        double double20 = logNormalDistribution17.getSupportUpperBound();
        logNormalDistribution17.reseedRandomGenerator((-333573471L));
        double double25 = logNormalDistribution17.probability(0.0d, 0.9999999998478477d);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.5d + "'", double25 == 0.5d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator22 = randomDataImpl8.getDelegate();
        int int25 = randomDataGenerator22.nextBinomial(78, (double) 0.5871973f);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertNotNull(randomDataGenerator22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 45 + "'", int25 == 45);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            int int17 = randomDataImpl8.nextSecureInt(92410965, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (92,410,965) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertNotNull(randomDataGenerator14);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double25 = logNormalDistribution17.probability((double) (-387737817), 0.0d);
        double double26 = logNormalDistribution17.getSupportLowerBound();
        double double27 = logNormalDistribution17.getNumericalVariance();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        boolean boolean3 = well19937c1.nextBoolean();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        well19937c1.index = (short) 0;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((double) 5L, (double) (short) 1, 2.766458368800151d);
        double double5 = normalDistribution3.density((-1.4165028871298073d));
        double double7 = normalDistribution3.inverseCumulativeProbability(0.7874548671504324d);
        double double8 = normalDistribution3.sample();
        double double10 = normalDistribution3.cumulativeProbability((-97.86618264012287d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.577521738126163E-10d + "'", double5 == 4.577521738126163E-10d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.702637376954931d + "'", double7 == 5.702637376954931d);
// flaky "77) test233(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.533781650796681d + "'", double8 == 5.533781650796681d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int4 = well19937c1.next(4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double9 = gammaDistribution3.density(1.5223961928507554d);
        boolean boolean10 = gammaDistribution3.isSupportUpperBoundInclusive();
        boolean boolean11 = gammaDistribution3.isSupportUpperBoundInclusive();
        boolean boolean12 = gammaDistribution3.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.03374688752732189d + "'", double9 == 0.03374688752732189d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        int int18 = randomDataImpl8.nextSecureInt((int) (byte) 10, 2147483647);
        // The following exception was thrown during execution in test generation
        try {
            double double21 = randomDataImpl8.nextGamma(41.74106476041107d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
// flaky "78) test236(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int18 + "' != '" + 908632990 + "'", int18 == 908632990);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextBeta((double) 32L, 1.34249938126520653E18d);
        // The following exception was thrown during execution in test generation
        try {
            double double20 = randomDataImpl8.nextGaussian(Double.POSITIVE_INFINITY, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0754202590107506E-9d + "'", double17 == 1.0754202590107506E-9d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextF(0.22497942976198554d, 0.3934606808571868d);
        double double15 = randomDataImpl8.nextCauchy((double) 0.0f, 0.08484461357703173d);
        randomDataImpl8.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            double double19 = randomDataImpl8.nextGaussian((double) 0.7685776f, (-0.018010145599590466d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-0.018)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2044.5491797688765d + "'", double12 == 2044.5491797688765d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.053473722883958005d) + "'", double15 == (-0.053473722883958005d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.06205881951146367d, (-0.23121594723306654d), 3.3663081124299024d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0.231)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        int int15 = randomDataGenerator0.nextPascal((int) (byte) 1, 0.3934606808571868d);
        long long18 = randomDataGenerator0.nextLong((long) 32, (long) 45);
// flaky "79) test240(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.005255425566538802d + "'", double3 == 0.005255425566538802d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 41L + "'", long18 == 41L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double2 = normalDistribution0.cumulativeProbability(5.1481760329336096E17d);
        double double3 = normalDistribution0.sample();
        double double4 = normalDistribution0.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
// flaky "80) test241(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.33142423603160576d) + "'", double3 == (-0.33142423603160576d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getScale();
        // The following exception was thrown during execution in test generation
        try {
            double double8 = gammaDistribution3.inverseCumulativeProbability(4.89392748244002d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 4.894 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        int int16 = randomDataImpl8.nextPascal(92410965, 1.0E-6d);
        // The following exception was thrown during execution in test generation
        try {
            int int19 = randomDataImpl8.nextPascal((int) ' ', 21.23248944257666d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 21.232 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "81) test243(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        double double17 = randomDataImpl8.nextExponential(4.0533378281932396E-46d);
        // The following exception was thrown during execution in test generation
        try {
            double double20 = randomDataImpl8.nextUniform(4.6157368533398735d, (-0.34373453631013684d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (4.616) must be strictly less than upper bound (-0.344)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 6.27147468593853E-47d + "'", double17 == 6.27147468593853E-47d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution16 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (-93467950L), 1.5223961928507554d, (double) 1028812019);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution20 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (-9.115337148800332d), (-0.3906270427650007d), 0.4792657157117794d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-9.115)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        double double15 = randomDataImpl8.nextT(2.0d);
        int int18 = randomDataImpl8.nextPascal(32, (double) 0.7685776f);
        // The following exception was thrown during execution in test generation
        try {
            int int21 = randomDataImpl8.nextPascal(326573780, (double) 614504715);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 614,504,715 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "82) test246(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7874548671504324d + "'", double15 == 0.7874548671504324d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        int[] intArray7 = new int[] { (short) -1, 646549088, 6, (-401038879) };
        well19937c1.setSeed(intArray7);
        long long9 = well19937c1.nextLong();
        double double10 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { (-1), 646549088, 6, (-401038879) });
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4986124084203277738L + "'", long9 == 4986124084203277738L);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6330198793807371d + "'", double10 == 0.6330198793807371d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((-93467950L));
        well19937c1.setSeed(251174);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            double double12 = randomDataImpl8.nextWeibull((-0.23121594723306654d), (-0.84219107976884d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.231)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        int[] intArray14 = well19937c1.iRm1;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int int17 = well19937c1.next((-401038879));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        randomDataImpl8.reSeed((long) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            double double25 = randomDataImpl8.nextChiSquare((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator14 = randomDataImpl8.getDelegate();
        java.lang.String str16 = randomDataGenerator14.nextHexString((int) '4');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertNotNull(randomDataGenerator14);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91" + "'", str16, "d1fc1bdb7c811cb70e1981072104afe3e4772358229cc7e89a91");
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double6 = normalDistribution2.inverseCumulativeProbability((double) (byte) 1);
        double double7 = normalDistribution2.sample();
        double double8 = normalDistribution2.getStandardDeviation();
        boolean boolean9 = normalDistribution2.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
// flaky "83) test253(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.465342093660965d + "'", double7 == 8.465342093660965d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(0L);
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray9 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c3.setSeed(intArray9);
        double double11 = well19937c3.nextDouble();
        well19937c3.clear();
        double double13 = well19937c3.nextDouble();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c3);
        int[] intArray15 = well19937c3.i1;
        well19937c1.setSeed(intArray15);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertArrayEquals(intArray9, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5871973525778662d + "'", double11 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.48092575793941483d + "'", double13 == 0.48092575793941483d);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            int int12 = randomDataGenerator0.nextHypergeometric(14, (int) (short) -1, 73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of successes (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "84) test255(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.04698557190504459d + "'", double3 == 0.04698557190504459d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(0L);
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c3.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 99L, (double) 2940458407815999488L);
        double double3 = logNormalDistribution2.sample();
        // The following exception was thrown during execution in test generation
        try {
            double double6 = logNormalDistribution2.cumulativeProbability(1.34249938126520653E18d, 30.576799295286875d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1,342,499,381,265,206,530) must be less than or equal to upper endpoint (30.577)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "85) test257(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double4 = gammaDistribution3.sample();
        double double5 = gammaDistribution3.sample();
        double double7 = gammaDistribution3.cumulativeProbability(35.0d);
// flaky "86) test258(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 53.18589031539316d + "'", double4 == 53.18589031539316d);
// flaky "32) test258(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 220.7075318044711d + "'", double5 == 220.7075318044711d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5174817962729935d + "'", double7 == 0.5174817962729935d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        java.lang.String str7 = randomDataGenerator0.nextHexString((int) (byte) 10);
// flaky "87) test259(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3648860951196837d + "'", double3 == 0.3648860951196837d);
// flaky "33) test259(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str7 + "' != '" + "eb2dd09393" + "'", str7, "eb2dd09393");
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        boolean boolean3 = logNormalDistribution2.isSupportUpperBoundInclusive();
        boolean boolean4 = logNormalDistribution2.isSupportLowerBoundInclusive();
        boolean boolean5 = logNormalDistribution2.isSupportConnected();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution16 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 100.0f, 1.0219671297446623E-9d, 0.0d);
        well19937c1.setSeed((-372572774L));
        int int20 = well19937c1.nextInt(73);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 63 + "'", int20 == 63);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(45);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            double double20 = randomDataImpl8.nextChiSquare(3.513799009476652E18d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 3,513,799,012,575,092,700], values: [-0.577, -?]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
        org.junit.Assert.assertNotNull(randomDataGenerator18);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString((int) 'a');
        int int22 = randomDataImpl8.nextSecureInt((-387737817), (int) (short) 1);
        int int25 = randomDataImpl8.nextInt(100, 1028812019);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
// flaky "88) test264(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "86bc0405678c7424255a308e6b32f284178a24bc92ce739c0173a920f97e77b3f4ed678f5d93a070bbe0e9435c2762212" + "'", str19, "86bc0405678c7424255a308e6b32f284178a24bc92ce739c0173a920f97e77b3f4ed678f5d93a070bbe0e9435c2762212");
// flaky "34) test264(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-67868903) + "'", int22 == (-67868903));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 564472600 + "'", int25 == 564472600);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 99L, (double) 2940458407815999488L);
        double double3 = logNormalDistribution2.getNumericalMean();
        boolean boolean4 = logNormalDistribution2.isSupportLowerBoundInclusive();
        // The following exception was thrown during execution in test generation
        try {
            double double6 = logNormalDistribution2.inverseCumulativeProbability((double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed((long) (short) 1);
        long long11 = well19937c1.nextLong();
        byte[] byteArray12 = new byte[] {};
        well19937c1.nextBytes(byteArray12);
        double double14 = well19937c1.nextGaussian();
        int int16 = well19937c1.next((-387737817));
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1342499381265206610L + "'", long11 == 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] {});
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.4981981826015826d + "'", double14 == 0.4981981826015826d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        double double11 = well19937c1.nextDouble();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        java.lang.String str14 = randomDataImpl12.nextHexString(73);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution15 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int16 = randomDataImpl12.nextInversionDeviate(integerDistribution15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "1ffe34c8d1dc65542db75d233832d568d74d2cb80f52d83edc118fe454ae772ad536b0320" + "'", str14, "1ffe34c8d1dc65542db75d233832d568d74d2cb80f52d83edc118fe454ae772ad536b0320");
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        int int12 = randomDataGenerator9.nextInt(6, 92410965);
        // The following exception was thrown during execution in test generation
        try {
            int int15 = randomDataGenerator9.nextZipf((int) (byte) -1, 2.8957779288675325d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: dimension (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 83782171 + "'", int12 == 83782171);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextBeta(97.0d, (double) (byte) 1);
        int int16 = randomDataGenerator0.nextHypergeometric(646549088, 83782171, 61);
// flaky "89) test269(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.3107068008899296d + "'", double3 == 2.3107068008899296d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9830505425759046d + "'", double12 == 0.9830505425759046d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray16 = randomDataImpl8.nextPermutation(10, 92410965);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (92,410,965) exceeds permuation domain (10)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "1) test270(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        long long3 = well19937c1.nextLong();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        boolean boolean5 = well19937c1.nextBoolean();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4418713979230659041L + "'", long3 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        double double13 = randomDataImpl8.nextUniform(0.5176464628744074d, 1.0847303959306388E27d);
        double double15 = randomDataImpl8.nextExponential((double) 127.0f);
        double double18 = randomDataImpl8.nextCauchy(0.5d, 43.39637664550634d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
// flaky "90) test272(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 9.000684953742947E26d + "'", double13 == 9.000684953742947E26d);
// flaky "35) test272(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.13901826431262d + "'", double15 == 4.13901826431262d);
// flaky "7) test272(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double18 + "' != '" + 59.45292043834515d + "'", double18 == 59.45292043834515d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((double) 5L, (double) (short) 1, 2.766458368800151d);
        double double5 = normalDistribution3.density((-1.4165028871298073d));
        double double7 = normalDistribution3.inverseCumulativeProbability(0.7874548671504324d);
        // The following exception was thrown during execution in test generation
        try {
            double double10 = normalDistribution3.probability(0.9999999999999999d, 0.05269977907409859d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1) must be less than or equal to upper endpoint (0.053)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.577521738126163E-10d + "'", double5 == 4.577521738126163E-10d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.702637376954931d + "'", double7 == 5.702637376954931d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.sample();
        boolean boolean6 = normalDistribution2.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
// flaky "91) test274(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-11.25920381375979d) + "'", double5 == (-11.25920381375979d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int3 = well19937c1.next((-401038879));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double2 = normalDistribution0.inverseCumulativeProbability((double) 0);
        double double5 = normalDistribution0.cumulativeProbability((double) (byte) -1, (double) (-1L));
        double double6 = normalDistribution0.sample();
        double double9 = normalDistribution0.probability(0.0d, 0.19335986621811754d);
        // The following exception was thrown during execution in test generation
        try {
            double double12 = normalDistribution0.cumulativeProbability(0.0d, (double) (-93467950L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0) must be less than or equal to upper endpoint (-93,467,950)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
// flaky "92) test276(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.717708773033903d) + "'", double6 == (-1.717708773033903d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.07666142781209974d + "'", double9 == 0.07666142781209974d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeedSecure(0L);
        double double14 = randomDataGenerator0.nextUniform(1.9283289552270317d, 4.7421875d);
        // The following exception was thrown during execution in test generation
        try {
            int int17 = randomDataGenerator0.nextSecureInt(1152985812, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,152,985,812) must be strictly less than upper bound (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "93) test277(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000011156758d + "'", double5 == 0.5000000011156758d);
// flaky "36) test277(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-385028823L) + "'", long8 == (-385028823L));
// flaky "8) test277(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.9722486177382177d + "'", double14 == 1.9722486177382177d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getScale();
        double double22 = logNormalDistribution17.sample();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution16 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (-93467950L), 1.5223961928507554d, (double) 1028812019);
        double double17 = well19937c1.nextDouble();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2776236596259125d + "'", double17 == 0.2776236596259125d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution14 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8822285080719574d, 0.5456928232039928d, (double) 32L);
        double double15 = gammaDistribution14.getSupportUpperBound();
        double double16 = gammaDistribution14.getNumericalVariance();
        gammaDistribution14.reseedRandomGenerator((-360940845L));
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.26271058501924055d + "'", double16 == 0.26271058501924055d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getScale();
        double[] doubleArray23 = logNormalDistribution17.sample((int) '4');
        boolean boolean24 = logNormalDistribution17.isSupportConnected();
        double double25 = logNormalDistribution17.sample();
        // The following exception was thrown during execution in test generation
        try {
            double double28 = logNormalDistribution17.cumulativeProbability(0.07666142781209974d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.077) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + Double.POSITIVE_INFINITY + "'", double25 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        double double21 = randomDataImpl8.nextUniform(0.0d, (double) 1.0000001f);
        // The following exception was thrown during execution in test generation
        try {
            int int24 = randomDataImpl8.nextInt(1152985812, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,152,985,812) must be strictly less than upper bound (6)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5486644903859355d + "'", double21 == 0.5486644903859355d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 10);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator13 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            double double17 = randomDataImpl8.nextUniform(51.110539882904995d, 1.177832417027476d, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (51.111) must be strictly less than upper bound (1.178)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(randomDataGenerator13);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextF(0.22497942976198554d, 0.3934606808571868d);
        // The following exception was thrown during execution in test generation
        try {
            double double15 = randomDataImpl8.nextUniform(0.9999999993571499d, 1.77248108481435E-4d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2044.5491797688765d + "'", double12 == 2044.5491797688765d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(32L);
        well19937c1.setSeed(0L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        double double5 = logNormalDistribution2.cumulativeProbability(4.0533378281932396E-46d, (double) 35L);
        double double6 = logNormalDistribution2.sample();
        double double7 = logNormalDistribution2.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.041984444374669055d + "'", double5 == 0.041984444374669055d);
// flaky "94) test286(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.258166717395398E102d + "'", double6 == 6.258166717395398E102d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        double double20 = randomDataImpl8.nextT((double) (byte) 1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.15408618390509038d + "'", double20 == 0.15408618390509038d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double21 = logNormalDistribution17.getScale();
        // The following exception was thrown during execution in test generation
        try {
            double double24 = logNormalDistribution17.probability(0.4350449516314905d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (0.435) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) '4', 0.7762223750904278d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double18 = logNormalDistribution17.getSupportLowerBound();
        double double19 = logNormalDistribution17.getNumericalVariance();
        double double21 = logNormalDistribution17.density((-0.3906270427650007d));
        double double22 = logNormalDistribution17.sample();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + Double.POSITIVE_INFINITY + "'", double19 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(182.3918103676576d, 6.27147468593853E-47d, 190.06556510850848d);
        boolean boolean4 = logNormalDistribution3.isSupportUpperBoundInclusive();
        logNormalDistribution3.reseedRandomGenerator(35L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) (-1722448868039600408L), (double) (-2199947874156987901L), 12.780464539439134d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-2,199,947,874,156,987,900)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextF(0.22497942976198554d, 0.3934606808571868d);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution13 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int14 = randomDataImpl8.nextInversionDeviate(integerDistribution13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2044.5491797688765d + "'", double12 == 2044.5491797688765d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        int int6 = randomDataGenerator0.nextZipf((int) (byte) 1, 0.5772156649015329d);
        // The following exception was thrown during execution in test generation
        try {
            double double9 = randomDataGenerator0.nextGaussian((double) 5.0f, (-1.796321317031409d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-1.796)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "95) test294(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3977982240915679d + "'", double3 == 0.3977982240915679d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double18 = logNormalDistribution17.getSupportLowerBound();
        double double19 = logNormalDistribution17.getSupportLowerBound();
        double double20 = logNormalDistribution17.getSupportUpperBound();
        logNormalDistribution17.reseedRandomGenerator((-333573471L));
        double double23 = logNormalDistribution17.getShape();
        // The following exception was thrown during execution in test generation
        try {
            double double26 = logNormalDistribution17.probability((double) 1L, 0.9771040174634322d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1) must be less than or equal to upper endpoint (0.977)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT(0.9999999993571499d);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray22 = randomDataImpl8.nextPermutation(96691, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (-1");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.22345908971987016d) + "'", double19 == (-0.22345908971987016d));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 99L, (double) 2940458407815999488L);
        double double4 = logNormalDistribution2.cumulativeProbability(1.0076387104355826d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution14 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8822285080719574d, 0.5456928232039928d, (double) 32L);
        double double15 = gammaDistribution14.getSupportUpperBound();
        double double17 = gammaDistribution14.cumulativeProbability((-8.968421786443887d));
        double double18 = gammaDistribution14.getNumericalMean();
        boolean boolean19 = gammaDistribution14.isSupportLowerBoundInclusive();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.48142576528083303d + "'", double18 == 0.48142576528083303d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGaussian(1.5707963267948966d, 2.9496875887749894E19d);
        double double22 = randomDataImpl8.nextUniform(0.9830505425759046d, (double) 6L);
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution23 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int24 = randomDataImpl8.nextInversionDeviate(integerDistribution23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0185362398551933E19d) + "'", double19 == (-3.0185362398551933E19d));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.628829966193325d + "'", double22 == 3.628829966193325d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        float float11 = well19937c1.nextFloat();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution15 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 3.79226455416768d, (double) 4418713979230659041L, 10.302538425400456d);
        boolean boolean16 = gammaDistribution15.isSupportConnected();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.7685776f + "'", float11 == 0.7685776f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(2.814852629991113d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        boolean boolean8 = gammaDistribution3.isSupportUpperBoundInclusive();
        // The following exception was thrown during execution in test generation
        try {
            double double10 = gammaDistribution3.inverseCumulativeProbability(6.459010142387964E26d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 645,901,014,238,796,400,000,000,000 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        boolean boolean8 = gammaDistribution3.isSupportLowerBoundInclusive();
        boolean boolean9 = gammaDistribution3.isSupportConnected();
        double double10 = gammaDistribution3.getAlpha();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6233479763570439d + "'", double10 == 0.6233479763570439d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math3.random.Well19937c well19937c0 = new org.apache.commons.math3.random.Well19937c();
        well19937c0.setSeed((long) '#');
        well19937c0.setSeed(646549088L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        boolean boolean3 = well19937c1.nextBoolean();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        java.lang.String str6 = randomDataGenerator4.nextHexString((int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            randomDataGenerator4.setSecureAlgorithm("fbcc4", "org.apache.commons.math3.exception.MathIllegalStateException: illegal state");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.MathIllegalStateException: illegal state");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "a" + "'", str6, "a");
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.sample();
        double double7 = normalDistribution2.probability(6.27147468593853E-47d);
        double double9 = normalDistribution2.probability((double) (-85092646L));
        double double11 = normalDistribution2.density((double) 614504715);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
// flaky "96) test306(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-6.2228463234887155d) + "'", double5 == (-6.2228463234887155d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeedSecure(0L);
        double double14 = randomDataGenerator0.nextUniform(1.9283289552270317d, 4.7421875d);
        // The following exception was thrown during execution in test generation
        try {
            long long17 = randomDataGenerator0.nextSecureLong((long) 83782171, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (83,782,171) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "97) test307(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000016555459d + "'", double5 == 0.5000000016555459d);
// flaky "37) test307(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-91209668L) + "'", long8 == (-91209668L));
// flaky "9) test307(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.044538630591396d + "'", double14 == 4.044538630591396d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray9 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c3.setSeed(intArray9);
        well19937c1.setSeed(intArray9);
        org.apache.commons.math3.random.Well19937c well19937c13 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray21 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c15.setSeed(intArray21);
        well19937c13.setSeed(intArray21);
        well19937c1.setSeed(intArray21);
        float float25 = well19937c1.nextFloat();
        // The following exception was thrown during execution in test generation
        try {
            int int27 = well19937c1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertArrayEquals(intArray9, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertArrayEquals(intArray21, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5871973f + "'", float25 == 0.5871973f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        boolean boolean5 = normalDistribution2.isSupportConnected();
        double double6 = normalDistribution2.getNumericalMean();
        boolean boolean7 = normalDistribution2.isSupportConnected();
        double double9 = normalDistribution2.cumulativeProbability(0.025766719698081936d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.4611951098778435d + "'", double9 == 0.4611951098778435d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        double double16 = randomDataImpl8.nextWeibull(81.87241173283697d, 0.5871973525778662d);
        randomDataImpl8.reSeed();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5813855834128373d + "'", double16 == 0.5813855834128373d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) ' ');
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution5 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 3.7959526833814112d, (double) (short) 0, 3.513799009476652E18d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        randomDataImpl8.reSeed((long) (byte) 1);
        randomDataImpl8.reSeedSecure();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        double double11 = well19937c1.nextDouble();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray15 = randomDataImpl12.nextPermutation(3, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            double double21 = randomDataImpl8.nextWeibull(0.9345329978999835d, (-0.13866332061552417d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0.139)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString((int) 'a');
        int int22 = randomDataImpl8.nextSecureInt((-387737817), (int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            double double25 = randomDataImpl8.nextGamma(0.0d, (double) 1028812019);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
// flaky "98) test315(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "ecd71585a69bec750a2293edd4b71e21655e00700370a1903dc74d2e07dbedf91c77fb2359ce355ccebfc3394473201ca" + "'", str19, "ecd71585a69bec750a2293edd4b71e21655e00700370a1903dc74d2e07dbedf91c77fb2359ce355ccebfc3394473201ca");
// flaky "38) test315(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-11659426) + "'", int22 == (-11659426));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getScale();
        double double7 = gammaDistribution3.sample();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
// flaky "99) test316(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.911133564062771d + "'", double7 == 9.911133564062771d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed((long) (short) 1);
        long long11 = well19937c1.nextLong();
        double double12 = well19937c1.nextGaussian();
        well19937c1.setSeed((long) (byte) 10);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1342499381265206610L + "'", long11 == 1342499381265206610L);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.13866332061552417d) + "'", double12 == (-0.13866332061552417d));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        double double18 = randomDataImpl8.nextWeibull(1.0000000038798231d, 0.1668524405453939d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.1436998150734985d + "'", double18 == 0.1436998150734985d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double4 = randomDataGenerator0.nextUniform(0.36787944117144233d, (double) 1L, true);
        double double7 = randomDataGenerator0.nextWeibull(6.399835471825113E26d, (double) ' ');
// flaky "100) test319(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6843435312122039d + "'", double4 == 0.6843435312122039d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        boolean boolean3 = well19937c1.nextBoolean();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            double double7 = randomDataGenerator4.nextUniform((double) 251174, (-0.13866332061552417d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (251,174) must be strictly less than upper bound (-0.139)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double18 = logNormalDistribution17.getSupportLowerBound();
        double double19 = logNormalDistribution17.getSupportLowerBound();
        double double20 = logNormalDistribution17.getSupportUpperBound();
        logNormalDistribution17.reseedRandomGenerator((-333573471L));
        // The following exception was thrown during execution in test generation
        try {
            double double25 = logNormalDistribution17.cumulativeProbability((double) 82, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (82) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double11 = randomDataGenerator9.nextChiSquare((double) 10L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 16.224851562747435d + "'", double11 == 16.224851562747435d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        int[] intArray2 = well19937c1.i3;
        int int3 = well19937c1.index;
        long long4 = well19937c1.nextLong();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3513799009476651814L + "'", long4 == 3513799009476651814L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        java.lang.String str11 = randomDataGenerator9.nextHexString((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            long long13 = randomDataGenerator9.nextPoisson((double) (-333573471L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (-333,573,471)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "6121986868" + "'", str11, "6121986868");
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double25 = logNormalDistribution17.probability((double) (-387737817), 0.0d);
        double double26 = logNormalDistribution17.getSupportLowerBound();
        double double28 = logNormalDistribution17.cumulativeProbability(0.0d);
        double double29 = logNormalDistribution17.sample();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeedSecure((-1722448868039600408L));
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        double double7 = randomDataGenerator0.nextChiSquare(0.19335986621811754d);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = randomDataGenerator0.nextInt(2147483647, 614504715);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (2,147,483,647) must be strictly less than upper bound (614,504,715)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "101) test327(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000012346348d + "'", double5 == 0.5000000012346348d);
// flaky "39) test327(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.7451296457844606E-9d + "'", double7 == 4.7451296457844606E-9d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution13 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.25725306008387744d, 0.661011522946662d, 120.54442181558605d);
        double double14 = gammaDistribution13.getShape();
        double double15 = gammaDistribution13.getSupportUpperBound();
        boolean boolean16 = gammaDistribution13.isSupportUpperBoundInclusive();
        double double17 = gammaDistribution13.getSupportLowerBound();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32099235282147576d + "'", double9 == 0.32099235282147576d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.25725306008387744d + "'", double14 == 0.25725306008387744d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGaussian(1.5707963267948966d, 2.9496875887749894E19d);
        // The following exception was thrown during execution in test generation
        try {
            double double23 = randomDataImpl8.nextUniform(20.52251968574866d, 2.814852629991113d, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (20.523) must be strictly less than upper bound (2.815)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0185362398551933E19d) + "'", double19 == (-3.0185362398551933E19d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 99L, (double) 2940458407815999488L);
        double double3 = logNormalDistribution2.getNumericalMean();
        boolean boolean4 = logNormalDistribution2.isSupportLowerBoundInclusive();
        double double5 = logNormalDistribution2.sample();
        boolean boolean6 = logNormalDistribution2.isSupportUpperBoundInclusive();
        boolean boolean7 = logNormalDistribution2.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
// flaky "102) test330(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double2 = normalDistribution0.inverseCumulativeProbability((double) 0);
        double double3 = normalDistribution0.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        double double11 = well19937c1.nextDouble();
        double double12 = well19937c1.nextDouble();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2840041344109887d + "'", double12 == 0.2840041344109887d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        // The following exception was thrown during execution in test generation
        try {
            int int16 = randomDataImpl8.nextZipf(0, 0.5d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: dimension (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = randomDataGenerator0.nextSecureInt(61, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (61) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "103) test334(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4940925368447452d + "'", double3 == 0.4940925368447452d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((double) 5L, (double) (short) 1, 2.766458368800151d);
        double double4 = normalDistribution3.getNumericalVariance();
        double[] doubleArray6 = normalDistribution3.sample(78);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double6 = normalDistribution2.inverseCumulativeProbability((double) (byte) 1);
        double double7 = normalDistribution2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution14 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8822285080719574d, 0.5456928232039928d, (double) 32L);
        double double15 = gammaDistribution14.getSupportUpperBound();
        double double17 = gammaDistribution14.cumulativeProbability((-8.968421786443887d));
        double double19 = gammaDistribution14.cumulativeProbability(0.0d);
        // The following exception was thrown during execution in test generation
        try {
            double[] doubleArray21 = gammaDistribution14.sample((-42005975));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (-42,005,975)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution(9.90565059165379E-4d, 0.0d, (double) 4986124084203277738L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        long long3 = well19937c1.nextLong();
        int[] intArray4 = well19937c1.v;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution8 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 1.2332193503013296d, 0.0d, (double) (-401038879));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3513799009476651814L + "'", long3 == 3513799009476651814L);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (-1));
        int int2 = well19937c1.index;
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        java.lang.String str10 = randomDataGenerator0.nextSecureHexString((int) '4');
        long long13 = randomDataGenerator0.nextSecureLong(646549088L, 4986124084203277738L);
// flaky "104) test341(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000012836325d + "'", double5 == 0.5000000012836325d);
// flaky "40) test341(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-392573841L) + "'", long8 == (-392573841L));
// flaky "10) test341(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str10 + "' != '" + "db7b51966311c0f18407c8fdb057088a68a5884f85ba39da81de" + "'", str10, "db7b51966311c0f18407c8fdb057088a68a5884f85ba39da81de");
// flaky "2) test341(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 4204440560618976768L + "'", long13 == 4204440560618976768L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        long long3 = well19937c1.nextLong();
        int int4 = well19937c1.index;
        int[] intArray5 = well19937c1.i2;
        int int6 = well19937c1.nextInt();
        well19937c1.index = 1117624816;
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4418713979230659041L + "'", long3 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 622 + "'", int4 == 622);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1689900776 + "'", int6 == 1689900776);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getNumericalVariance();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5865.081109543426d + "'", double8 == 5865.081109543426d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeedSecure(0L);
        // The following exception was thrown during execution in test generation
        try {
            int int14 = randomDataGenerator0.nextInt(409060042, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (409,060,042) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "105) test344(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000019341458d + "'", double5 == 0.5000000019341458d);
// flaky "41) test344(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-219959683L) + "'", long8 == (-219959683L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        randomDataGenerator0.reSeedSecure();
        // The following exception was thrown during execution in test generation
        try {
            long long8 = randomDataGenerator0.nextPoisson(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: mean (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "106) test345(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6063161655940716d + "'", double3 == 0.6063161655940716d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution14 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8822285080719574d, 0.5456928232039928d, (double) 32L);
        double double15 = gammaDistribution14.getSupportUpperBound();
        double double17 = gammaDistribution14.cumulativeProbability((-8.968421786443887d));
        double double18 = gammaDistribution14.getNumericalMean();
        double double20 = gammaDistribution14.density((double) (-7796297722204279230L));
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.48142576528083303d + "'", double18 == 0.48142576528083303d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        java.lang.String str16 = randomDataImpl8.nextSecureHexString(5);
        randomDataImpl8.reSeedSecure(4418713979230659041L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator19 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            double double22 = randomDataImpl8.nextUniform(97.0d, (-0.0460158355740473d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (97) must be strictly less than upper bound (-0.046)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
// flaky "107) test347(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "b2fbb" + "'", str16, "b2fbb");
        org.junit.Assert.assertNotNull(randomDataGenerator19);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getSupportUpperBound();
        double double9 = gammaDistribution3.getBeta();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = randomDataImpl8.getDelegate();
        double double20 = randomDataGenerator18.nextExponential(8.881784197001252E-16d);
        double double22 = randomDataGenerator18.nextT(0.5431525999609425d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
        org.junit.Assert.assertNotNull(randomDataGenerator18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.374222606613847E-16d + "'", double20 == 1.374222606613847E-16d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.1789525284011038d + "'", double22 == 0.1789525284011038d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        java.lang.String str10 = randomDataGenerator0.nextSecureHexString((int) '4');
        double double13 = randomDataGenerator0.nextGamma((double) 100.00001f, (double) 2147483647);
        // The following exception was thrown during execution in test generation
        try {
            double double16 = randomDataGenerator0.nextF(88.58082754219768d, (double) (-1722448868039600408L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-1,722,448,868,039,600,380)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "108) test350(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000019942574d + "'", double5 == 0.5000000019942574d);
// flaky "42) test350(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-46264293L) + "'", long8 == (-46264293L));
// flaky "11) test350(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str10 + "' != '" + "953f307fe626cf5bbcaa29afa53f3b0bbaa72c7f2828ba5b96c4" + "'", str10, "953f307fe626cf5bbcaa29afa53f3b0bbaa72c7f2828ba5b96c4");
// flaky "3) test350(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.8123635939676288E11d + "'", double13 == 1.8123635939676288E11d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double9 = gammaDistribution3.cumulativeProbability((double) 646549088);
        double double10 = gammaDistribution3.getBeta();
        boolean boolean11 = gammaDistribution3.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextExponential(0.27433221325624985d);
        randomDataImpl8.reSeed((long) 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.47008445586152653d + "'", double14 == 0.47008445586152653d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution2 = new org.apache.commons.math3.distribution.GammaDistribution(81.87241173283697d, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        // The following exception was thrown during execution in test generation
        try {
            double double25 = randomDataImpl8.nextUniform(7.896296018268069E13d, 0.5000000010645599d, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (78,962,960,182,680.69) must be strictly less than upper bound (0.5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        double double11 = randomDataGenerator0.nextWeibull(3.79226455416768d, 0.3934606808571868d);
        double double15 = randomDataGenerator0.nextUniform(3.96945621303213E-8d, 3.8369482992805285E-6d, true);
// flaky "109) test355(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "43) test355(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-356740149L) + "'", long8 == (-356740149L));
// flaky "12) test355(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.1852668358164261d + "'", double11 == 0.1852668358164261d);
// flaky "4) test355(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.8250955534713279E-6d + "'", double15 == 1.8250955534713279E-6d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        int int18 = randomDataImpl8.nextSecureInt((int) (byte) 10, 2147483647);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl8.setSecureAlgorithm("", "86bc0405678c7424255a308e6b32f284178a24bc92ce739c0173a920f97e77b3f4ed678f5d93a070bbe0e9435c2762212");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 86bc0405678c7424255a308e6b32f284178a24bc92ce739c0173a920f97e77b3f4ed678f5d93a070bbe0e9435c2762212");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
// flaky "110) test356(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int18 + "' != '" + 220804388 + "'", int18 == 220804388);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        java.lang.String str16 = randomDataImpl8.nextSecureHexString(5);
        randomDataImpl8.reSeedSecure(4418713979230659041L);
        // The following exception was thrown during execution in test generation
        try {
            double double21 = randomDataImpl8.nextCauchy(0.0d, (double) (-387737817));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-387,737,817)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
// flaky "111) test357(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "83728" + "'", str16, "83728");
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double11 = randomDataGenerator0.nextExponential(0.6874872252363187d);
        double double14 = randomDataGenerator0.nextGamma((double) (short) 1, 41.74106476041107d);
        double double17 = randomDataGenerator0.nextBeta(0.1668524405453939d, 173.48300619963672d);
// flaky "112) test358(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7733028806291382d + "'", double3 == 0.7733028806291382d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.3132117912189065d + "'", double11 == 1.3132117912189065d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.302538425400456d + "'", double14 == 10.302538425400456d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.054607039620292E-4d + "'", double17 == 3.054607039620292E-4d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeedSecure(0L);
        double double14 = randomDataGenerator0.nextUniform(1.9283289552270317d, 4.7421875d);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = randomDataGenerator0.nextSecureHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "113) test359(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000013075792d + "'", double5 == 0.5000000013075792d);
// flaky "44) test359(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-238681466L) + "'", long8 == (-238681466L));
// flaky "13) test359(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.372581457957158d + "'", double14 == 2.372581457957158d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getNumericalVariance();
        double double7 = gammaDistribution3.getSupportUpperBound();
        double double8 = gammaDistribution3.getSupportLowerBound();
        double double9 = gammaDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5865.081109543426d + "'", double6 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 60.46475370663325d + "'", double9 == 60.46475370663325d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getSupportUpperBound();
        double double9 = gammaDistribution3.getSupportUpperBound();
        double double10 = gammaDistribution3.getAlpha();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6233479763570439d + "'", double10 == 0.6233479763570439d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        double double11 = well19937c1.nextDouble();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray13 = well19937c1.i1;
        int int14 = well19937c1.nextInt();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1219788447 + "'", int14 == 1219788447);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        boolean boolean5 = normalDistribution2.isSupportConnected();
        double double6 = normalDistribution2.getNumericalMean();
        boolean boolean7 = normalDistribution2.isSupportConnected();
        double double8 = normalDistribution2.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        boolean boolean6 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double7 = gammaDistribution3.getAlpha();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6233479763570439d + "'", double7 == 0.6233479763570439d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(0.0d, (-0.9998519970848267d), 3.79226455416768d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        long long19 = randomDataImpl8.nextLong(1L, (long) 96691);
        long long22 = randomDataImpl8.nextSecureLong(0L, 100L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 50992L + "'", long19 == 50992L);
// flaky "114) test366(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long22 + "' != '" + 69L + "'", long22 == 69L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        boolean boolean8 = gammaDistribution3.isSupportLowerBoundInclusive();
        boolean boolean9 = gammaDistribution3.isSupportLowerBoundInclusive();
        double double10 = gammaDistribution3.sample();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
// flaky "115) test367(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double10 + "' != '" + 46.81107899629717d + "'", double10 == 46.81107899629717d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double6 = normalDistribution2.inverseCumulativeProbability((double) (byte) 1);
        double double7 = normalDistribution2.sample();
        double double8 = normalDistribution2.getStandardDeviation();
        java.lang.Class<?> wildcardClass9 = normalDistribution2.getClass();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
// flaky "116) test368(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.729260093501591d + "'", double7 == 3.729260093501591d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            int int8 = randomDataGenerator0.nextBinomial((-1638252717), (-4.9E-324d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of trials (-1,638,252,717)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
            // Expected exception.
        }
// flaky "117) test369(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.01794240454265439d) + "'", double3 == (-0.01794240454265439d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        // The following exception was thrown during execution in test generation
        try {
            double double11 = randomDataGenerator0.nextF(0.22969314751614026d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "118) test370(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "45) test370(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-146807811L) + "'", long8 == (-146807811L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 4.7421875d);
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.random.RandomGenerator randomGenerator10 = null;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution14 = new org.apache.commons.math3.distribution.NormalDistribution(randomGenerator10, (double) (-1), (double) '#', 100.0d);
        double double16 = normalDistribution14.cumulativeProbability(0.0d);
        double double17 = normalDistribution14.getNumericalVariance();
        org.apache.commons.math3.random.RandomGenerator randomGenerator18 = null;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution22 = new org.apache.commons.math3.distribution.NormalDistribution(randomGenerator18, (double) (-1), (double) '#', 100.0d);
        java.lang.Object[] objArray23 = new java.lang.Object[] { '4', 0, normalDistribution14, (-1) };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable7, objArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable6, objArray23);
        org.apache.commons.math3.random.RandomGenerator randomGenerator26 = null;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution30 = new org.apache.commons.math3.distribution.NormalDistribution(randomGenerator26, (double) (-1), (double) '#', 100.0d);
        double double32 = normalDistribution30.cumulativeProbability(0.0d);
        double double33 = normalDistribution30.getNumericalVariance();
        double double35 = normalDistribution30.probability(0.5486644903859356d);
        org.apache.commons.math3.random.Well19937c well19937c38 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray42 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c38.nextBytes(byteArray42);
        int[] intArray44 = well19937c38.i3;
        org.apache.commons.math3.random.Well19937c well19937c45 = new org.apache.commons.math3.random.Well19937c(intArray44);
        int int47 = well19937c45.nextInt(251174);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution50 = new org.apache.commons.math3.distribution.LogNormalDistribution(205.35258171903948d, 120.54442181558605d);
        double double53 = logNormalDistribution50.cumulativeProbability(4.0533378281932396E-46d, (double) 35L);
        java.lang.Object[] objArray54 = new java.lang.Object[] { objArray23, normalDistribution30, 2.993222846126381d, 251174, double53 };
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException55 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (-401038879), objArray54);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable4, objArray54);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException57 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException2, localizable3, objArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5113968002624507d + "'", double16 == 0.5113968002624507d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1225.0d + "'", double17 == 1225.0d);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.5113968002624507d + "'", double32 == 0.5113968002624507d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1225.0d + "'", double33 == 1225.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 96691 + "'", int47 == 96691);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.041984444374669055d + "'", double53 == 0.041984444374669055d);
        org.junit.Assert.assertNotNull(objArray54);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        java.lang.String str11 = randomDataGenerator9.nextHexString((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            double double14 = randomDataGenerator9.nextUniform(0.19335986621811754d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0.193) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "6121986868" + "'", str11, "6121986868");
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeedSecure(0L);
        double double14 = randomDataGenerator0.nextUniform(1.9283289552270317d, 4.7421875d);
        double double17 = randomDataGenerator0.nextCauchy((-0.431831491070752d), 1.5192403181932469E-9d);
// flaky "119) test373(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000012927857d + "'", double5 == 0.5000000012927857d);
// flaky "46) test373(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-105544895L) + "'", long8 == (-105544895L));
// flaky "14) test373(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.4893063002699205d + "'", double14 == 3.4893063002699205d);
// flaky "5) test373(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.43183148963313805d) + "'", double17 == (-0.43183148963313805d));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double9 = gammaDistribution3.density(1.5223961928507554d);
        boolean boolean10 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double11 = gammaDistribution3.getNumericalVariance();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.03374688752732189d + "'", double9 == 0.03374688752732189d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5865.081109543426d + "'", double11 == 5865.081109543426d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getBeta();
        double double9 = gammaDistribution3.getSupportUpperBound();
        double double10 = gammaDistribution3.getNumericalVariance();
        double double12 = gammaDistribution3.cumulativeProbability(4.7421875d);
        double double14 = gammaDistribution3.cumulativeProbability((double) 69L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5865.081109543426d + "'", double10 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.1668524405453939d + "'", double12 == 0.1668524405453939d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7018676680796985d + "'", double14 == 0.7018676680796985d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextDouble();
        well19937c1.setSeed((long) (short) 0);
        int int12 = well19937c1.index;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8260983859017907d, 6.285121086618636d, 0.025766719698081936d);
        long long17 = well19937c1.nextLong();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32099235282147576d + "'", double9 == 0.32099235282147576d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-4736355256857903122L) + "'", long17 == (-4736355256857903122L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeedSecure((long) (byte) 0);
        // The following exception was thrown during execution in test generation
        try {
            long long8 = randomDataGenerator0.nextSecureLong((long) 135154658, (-102499044L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (135,154,658) must be strictly less than upper bound (-102,499,044)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "120) test377(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0011590694570656139d + "'", double3 == 0.0011590694570656139d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextDouble();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution13 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.25725306008387744d, 0.661011522946662d, 120.54442181558605d);
        double double15 = gammaDistribution13.inverseCumulativeProbability(0.5486644903859355d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32099235282147576d + "'", double9 == 0.32099235282147576d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.26984958432038086d + "'", double15 == 0.26984958432038086d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString((int) 'a');
        int int22 = randomDataImpl8.nextSecureInt((-387737817), (int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            randomDataImpl8.setSecureAlgorithm("3b81bf4ab79777fa9edcaf3aba2df537def7baad9bd0410bae279c467393ed469975b2dd95de16eece09f8d5124b90241", "org.apache.commons.math3.exception.OutOfRangeException: 2.191 out of [1.522, 0.142] range");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math3.exception.OutOfRangeException: 2.191 out of [1.522, 0.142] range");
        } catch (java.security.NoSuchProviderException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
// flaky "121) test379(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "001a70e2844891f6514c8ec7ef6fc069fdd8ebf2970fa55c3623e9d019749737d409515bc981b4a67fbeb7ef3359f883c" + "'", str19, "001a70e2844891f6514c8ec7ef6fc069fdd8ebf2970fa55c3623e9d019749737d409515bc981b4a67fbeb7ef3359f883c");
// flaky "47) test379(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-253071653) + "'", int22 == (-253071653));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double24 = logNormalDistribution17.getSupportUpperBound();
        double double25 = logNormalDistribution17.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(182.3918103676576d, 6.27147468593853E-47d, 190.06556510850848d);
        boolean boolean4 = logNormalDistribution3.isSupportUpperBoundInclusive();
        double double5 = logNormalDistribution3.sample();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.628383852021019E79d + "'", double5 == 1.628383852021019E79d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double6 = normalDistribution2.inverseCumulativeProbability((double) (byte) 1);
        double double7 = normalDistribution2.sample();
        boolean boolean8 = normalDistribution2.isSupportUpperBoundInclusive();
        boolean boolean9 = normalDistribution2.isSupportConnected();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
// flaky "122) test382(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-17.344523690652682d) + "'", double7 == (-17.344523690652682d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        int int3 = well19937c1.nextInt((int) (byte) 1);
        int int5 = well19937c1.next(6);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution9 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.0d, 8.32098711274139E81d, 1.0000000038798231d);
        // The following exception was thrown during execution in test generation
        try {
            double double12 = normalDistribution9.cumulativeProbability((double) (-1), (double) (-47.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (-1) must be less than or equal to upper endpoint (-47)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(0.19335986621811754d, 1225.0d);
        java.lang.Class<?> wildcardClass3 = logNormalDistribution2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        // The following exception was thrown during execution in test generation
        try {
            double double8 = gammaDistribution3.cumulativeProbability(1.4142135610547037d, (-0.8913978328003006d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1.414) must be less than or equal to upper endpoint (-0.891)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long9 = well19937c1.nextLong();
        org.apache.commons.math3.random.Well19937c well19937c11 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray15 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c11.nextBytes(byteArray15);
        int[] intArray17 = well19937c11.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl18 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c11);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator19 = randomDataImpl18.getDelegate();
        java.lang.String str21 = randomDataGenerator19.nextHexString((int) (short) 10);
        int[] intArray24 = randomDataGenerator19.nextPermutation((int) '#', 2);
        well19937c1.setSeed(intArray24);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution29 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.11563859552454996d, 1.029441665221968d, 81.87241173283697d);
        org.apache.commons.math3.random.Well19937c well19937c31 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c31.clear();
        org.apache.commons.math3.random.Well19937c well19937c34 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long35 = well19937c34.nextLong();
        double double36 = well19937c34.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c38 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray44 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c38.setSeed(intArray44);
        well19937c34.setSeed(intArray44);
        well19937c31.setSeed(intArray44);
        org.apache.commons.math3.random.Well19937c well19937c49 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray53 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c49.nextBytes(byteArray53);
        well19937c31.nextBytes(byteArray53);
        well19937c1.nextBytes(byteArray53);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1722448868039600408L) + "'", long9 == (-1722448868039600408L));
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(randomDataGenerator19);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "6121986868" + "'", str21, "6121986868");
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertArrayEquals(intArray24, new int[] { 11, 5 });
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 4418713979230659041L + "'", long35 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.3934606808571868d + "'", double36 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertArrayEquals(intArray44, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertArrayEquals(byteArray53, new byte[] { (byte) -26, (byte) -118, (byte) -30 });
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        randomDataGenerator0.reSeedSecure();
        randomDataGenerator0.reSeedSecure(0L);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray14 = randomDataGenerator0.nextPermutation(92410965, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "123) test387(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5000000018871654d + "'", double5 == 0.5000000018871654d);
// flaky "48) test387(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-3546298L) + "'", long8 == (-3546298L));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double2 = normalDistribution0.cumulativeProbability(5.1481760329336096E17d);
        double double3 = normalDistribution0.sample();
        double double4 = normalDistribution0.sample();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
// flaky "124) test388(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3058700220827867d + "'", double3 == 0.3058700220827867d);
// flaky "49) test388(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7490336749605075d + "'", double4 == 0.7490336749605075d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeed();
        long long7 = randomDataGenerator0.nextSecureLong((long) 1, 4418713979230659041L);
        // The following exception was thrown during execution in test generation
        try {
            double double11 = randomDataGenerator0.nextUniform((double) 1028812019, 32.00000381469727d, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,028,812,019) must be strictly less than upper bound (32)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "125) test389(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.42255022235298495d + "'", double3 == 0.42255022235298495d);
// flaky "50) test389(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2507569866025678848L + "'", long7 == 2507569866025678848L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((-47));
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c3.nextBytes(byteArray7);
        int[] intArray9 = well19937c3.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c3);
        int[] intArray11 = well19937c3.iRm2;
        well19937c1.setSeed(intArray11);
        int int13 = well19937c1.nextInt();
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 657086092 + "'", int13 == 657086092);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 96691, 14.593973645167228d, 0.14218002608626515d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray17 = randomDataImpl8.nextPermutation(14, 622);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (622) exceeds permuation domain (14)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((-47));
        int int3 = well19937c1.nextInt(1152985812);
        int[] intArray4 = well19937c1.i3;
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1117624816 + "'", int3 == 1117624816);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution16 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 100.0f, 1.0219671297446623E-9d, 0.0d);
        well19937c1.setSeed((-372572774L));
        int[] intArray19 = well19937c1.iRm2;
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        org.apache.commons.math3.random.Well19937c well19937c4 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long5 = well19937c4.nextLong();
        double double6 = well19937c4.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray14 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c8.setSeed(intArray14);
        well19937c4.setSeed(intArray14);
        well19937c1.setSeed(intArray14);
        org.apache.commons.math3.random.Well19937c well19937c19 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray23 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c19.nextBytes(byteArray23);
        well19937c1.nextBytes(byteArray23);
        well19937c1.setSeed(0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4418713979230659041L + "'", long5 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3934606808571868d + "'", double6 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertArrayEquals(intArray14, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertArrayEquals(byteArray23, new byte[] { (byte) -35, (byte) -112, (byte) 82 });
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution(143.721221537708d, 272.4725288790843d, 0.03374688752732189d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextDouble();
        int[] intArray10 = well19937c1.v;
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.32099235282147576d + "'", double9 == 0.32099235282147576d);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        double double14 = randomDataGenerator0.nextChiSquare((double) 10);
        // The following exception was thrown during execution in test generation
        try {
            double double17 = randomDataGenerator0.nextGaussian((double) 6L, (-17.344523690652682d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-17.345)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "126) test398(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.21015028845274036d + "'", double3 == 0.21015028845274036d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 7.095868130534999d + "'", double14 == 7.095868130534999d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getNumericalVariance();
        double double7 = gammaDistribution3.getSupportLowerBound();
        double double8 = gammaDistribution3.getAlpha();
        // The following exception was thrown during execution in test generation
        try {
            double[] doubleArray10 = gammaDistribution3.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: number of samples (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5865.081109543426d + "'", double6 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6233479763570439d + "'", double8 == 0.6233479763570439d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double23 = logNormalDistribution17.cumulativeProbability(0.0d, (double) 1342499381265206610L);
        double double26 = logNormalDistribution17.cumulativeProbability((-0.9999999999999999d), (double) 3.8146973E-6f);
        double double27 = logNormalDistribution17.getShape();
        double double28 = logNormalDistribution17.sample();
        double double31 = logNormalDistribution17.probability((-0.43183148963313805d), 102400.0d);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.5d + "'", double26 == 0.5d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.5d + "'", double31 == 0.5d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        long long11 = randomDataGenerator0.nextLong((-105L), (long) 1219788447);
// flaky "127) test401(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.500000001289333d + "'", double5 == 0.500000001289333d);
// flaky "51) test401(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-300262564L) + "'", long8 == (-300262564L));
// flaky "15) test401(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long11 + "' != '" + 64769137L + "'", long11 == 64769137L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        double double9 = well19937c1.nextDouble();
        well19937c1.clear();
        double double11 = well19937c1.nextDouble();
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        int[] intArray13 = well19937c1.i1;
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.3934606808571868d, 81.87241173283697d, 0.0d);
        double double18 = logNormalDistribution17.getNumericalVariance();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5871973525778662d + "'", double9 == 0.5871973525778662d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.48092575793941483d + "'", double11 == 0.48092575793941483d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + Double.POSITIVE_INFINITY + "'", double18 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        double double10 = randomDataGenerator0.nextGaussian(0.6670445231839455d, 35.0d);
        // The following exception was thrown during execution in test generation
        try {
            double double13 = randomDataGenerator0.nextUniform(0.9999813803112833d, 0.599147297672623d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1) must be strictly less than upper bound (0.599)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "128) test403(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6651311749361313d + "'", double3 == 1.6651311749361313d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
// flaky "52) test403(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-62.598185984949865d) + "'", double10 == (-62.598185984949865d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getNumericalVariance();
        double double7 = gammaDistribution3.getSupportLowerBound();
        boolean boolean8 = gammaDistribution3.isSupportLowerBoundInclusive();
        boolean boolean9 = gammaDistribution3.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5865.081109543426d + "'", double6 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution14 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8822285080719574d, 0.5456928232039928d, (double) 32L);
        int int16 = well19937c1.nextInt(3);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution20 = new org.apache.commons.math3.distribution.NormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.6857853477016901d, 9.911133564062771d, 4.89392748244002d);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextF(0.22497942976198554d, 0.3934606808571868d);
        double double15 = randomDataImpl8.nextCauchy((double) 0.0f, 0.08484461357703173d);
        // The following exception was thrown during execution in test generation
        try {
            int int18 = randomDataImpl8.nextSecureInt(657086092, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (657,086,092) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2044.5491797688765d + "'", double12 == 2044.5491797688765d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.053473722883958005d) + "'", double15 == (-0.053473722883958005d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        boolean boolean3 = well19937c1.nextBoolean();
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution7 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) 100.00001f, 40.53016121779178d, 0.36787944117144233d);
        double double8 = gammaDistribution7.getBeta();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 40.53016121779178d + "'", double8 == 40.53016121779178d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        java.lang.String str16 = randomDataImpl8.nextSecureHexString(5);
        randomDataImpl8.reSeedSecure(4418713979230659041L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator19 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            int int22 = randomDataImpl8.nextBinomial((int) '#', (-1.2430165885381521d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -1.243 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
// flaky "129) test408(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "d7a1d" + "'", str16, "d7a1d");
        org.junit.Assert.assertNotNull(randomDataGenerator19);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double25 = logNormalDistribution17.probability(5.2034133211676d);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double25 = logNormalDistribution17.probability((double) (-387737817), 0.0d);
        boolean boolean26 = logNormalDistribution17.isSupportUpperBoundInclusive();
        double double27 = logNormalDistribution17.getSupportUpperBound();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        gammaDistribution3.reseedRandomGenerator((long) 4);
        double double11 = gammaDistribution3.cumulativeProbability(1.0000000038798231d);
        // The following exception was thrown during execution in test generation
        try {
            double double13 = gammaDistribution3.inverseCumulativeProbability(7.783615591316188E25d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: 77,836,155,913,161,880,000,000,000 out of [0, 1] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.06417289357865119d + "'", double11 == 0.06417289357865119d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        double double19 = randomDataImpl8.nextGaussian(1.5707963267948966d, 2.9496875887749894E19d);
        randomDataImpl8.reSeedSecure((long) 'a');
        randomDataImpl8.reSeed();
        org.apache.commons.math3.distribution.IntegerDistribution integerDistribution23 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int24 = randomDataImpl8.nextInversionDeviate(integerDistribution23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-3.0185362398551933E19d) + "'", double19 == (-3.0185362398551933E19d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        int int16 = randomDataImpl8.nextPascal(92410965, 1.0E-6d);
        double double20 = randomDataImpl8.nextUniform((-1.6261509044766869d), 0.6233479763570439d, true);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "130) test413(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.29486041034670357d) + "'", double20 == (-0.29486041034670357d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        long long12 = randomDataGenerator0.nextLong((-106654808L), (long) 3);
        double double14 = randomDataGenerator0.nextT(0.7017143190385968d);
// flaky "131) test414(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7291776680642906d + "'", double3 == 0.7291776680642906d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-86338835L) + "'", long12 == (-86338835L));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.22069573437174494d) + "'", double14 == (-0.22069573437174494d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeedSecure();
        double double11 = randomDataGenerator0.nextGaussian((double) 1L, 0.4909240332679956d);
// flaky "132) test415(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.425778577047831d + "'", double3 == 5.425778577047831d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
// flaky "53) test415(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.985337810733054d + "'", double11 == 0.985337810733054d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataGenerator9.reSeedSecure();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double4 = gammaDistribution3.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        double double23 = randomDataImpl8.nextExponential((double) 1342499381265206610L);
        randomDataImpl8.reSeed();
        // The following exception was thrown during execution in test generation
        try {
            double double27 = randomDataImpl8.nextCauchy(3.6929031665627243d, (-0.6321205588285577d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: scale (-0.632)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.07450506512479923E18d + "'", double23 == 1.07450506512479923E18d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double24 = logNormalDistribution17.getSupportUpperBound();
        boolean boolean25 = logNormalDistribution17.isSupportConnected();
        double double26 = logNormalDistribution17.getNumericalMean();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + Double.POSITIVE_INFINITY + "'", double26 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.nextInt();
        well19937c1.setSeed(2940458407815999488L);
        double double5 = well19937c1.nextDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1028812019 + "'", int2 == 1028812019);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.6758244587124949d + "'", double5 == 0.6758244587124949d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray9 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c3.setSeed(intArray9);
        well19937c1.setSeed(intArray9);
        org.apache.commons.math3.random.Well19937c well19937c13 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray21 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c15.setSeed(intArray21);
        well19937c13.setSeed(intArray21);
        well19937c1.setSeed(intArray21);
        float float25 = well19937c1.nextFloat();
        well19937c1.setSeed(0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertArrayEquals(intArray9, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertArrayEquals(intArray21, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5871973f + "'", float25 == 0.5871973f);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution2 = new org.apache.commons.math3.distribution.LogNormalDistribution(0.005255425566538802d, 1265.1280235363338d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        double double23 = randomDataImpl8.nextExponential((double) 1342499381265206610L);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str25 = randomDataImpl8.nextSecureHexString((-2147483648));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (-2,147,483,648)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.07450506512479923E18d + "'", double23 == 1.07450506512479923E18d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        double double21 = randomDataImpl8.nextUniform(0.0d, (double) 1.0000001f);
        // The following exception was thrown during execution in test generation
        try {
            int int24 = randomDataImpl8.nextZipf((int) (short) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: dimension (-1)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5486644903859355d + "'", double21 == 0.5486644903859355d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution2 = new org.apache.commons.math3.distribution.GammaDistribution((double) '4', 0.09568586753240192d);
        boolean boolean3 = gammaDistribution2.isSupportConnected();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution2 = new org.apache.commons.math3.distribution.GammaDistribution(0.04624245251182229d, 0.5486644903859356d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        java.lang.String str16 = randomDataImpl8.nextSecureHexString(5);
        randomDataImpl8.reSeedSecure(4418713979230659041L);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator19 = randomDataImpl8.getDelegate();
        // The following exception was thrown during execution in test generation
        try {
            double double22 = randomDataGenerator19.nextGaussian(0.0d, (double) (-86338835L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (-86,338,835)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
// flaky "133) test427(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "fc6de" + "'", str16, "fc6de");
        org.junit.Assert.assertNotNull(randomDataGenerator19);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution17 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (byte) 0, Double.POSITIVE_INFINITY, (double) (byte) 0);
        double double20 = logNormalDistribution17.cumulativeProbability(10.919399310827936d, (double) 31.999998f);
        double double22 = logNormalDistribution17.density(8.568214410979046E-178d);
        double double23 = logNormalDistribution17.getSupportUpperBound();
        double double24 = logNormalDistribution17.getNumericalVariance();
        double double26 = logNormalDistribution17.density(0.47971788545927857d);
        // The following exception was thrown during execution in test generation
        try {
            double double29 = logNormalDistribution17.probability(5.943637410738046d, 2.814852629991113d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (5.944) must be less than or equal to upper endpoint (2.815)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.POSITIVE_INFINITY + "'", double24 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) 7.6293945E-6f, 10.919399310827936d, (double) 0L);
        double double4 = logNormalDistribution3.getNumericalMean();
        double double6 = logNormalDistribution3.probability((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.783615591316188E25d + "'", double4 == 7.783615591316188E25d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        java.lang.String str16 = randomDataImpl8.nextSecureHexString(5);
        randomDataImpl8.reSeedSecure(4418713979230659041L);
        // The following exception was thrown during execution in test generation
        try {
            double double20 = randomDataImpl8.nextT((double) Float.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [-1, 1], values: [NaN, NaN]");
        } catch (org.apache.commons.math3.exception.NoBracketingException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
// flaky "134) test430(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str16 + "' != '" + "dbb75" + "'", str16, "dbb75");
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        long long20 = randomDataImpl8.nextPoisson(3.141592653589793d);
        int int23 = randomDataImpl8.nextPascal(63, 1.374222606613847E-16d);
        // The following exception was thrown during execution in test generation
        try {
            int int26 = randomDataImpl8.nextSecureInt(1117624816, 601);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,117,624,816) must be strictly less than upper bound (601)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 4L + "'", long20 == 4L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        long long9 = randomDataGenerator0.nextPoisson((double) 100L);
        int int12 = randomDataGenerator0.nextInt(100, 1152985812);
        randomDataGenerator0.reSeedSecure();
// flaky "135) test432(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.035983006107436266d + "'", double3 == 0.035983006107436266d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
// flaky "54) test432(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long9 + "' != '" + 118L + "'", long9 == 118L);
// flaky "16) test432(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + int12 + "' != '" + 779560061 + "'", int12 == 779560061);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray8 = randomDataGenerator0.nextPermutation(135154658, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "136) test433(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextGaussian(0.6483608274590866d, 0.3934606808571868d);
        randomDataGenerator0.reSeedSecure(0L);
        double double8 = randomDataGenerator0.nextUniform(21.23248944257666d, (double) '#');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = randomDataGenerator0.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "137) test434(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9316962979557941d + "'", double3 == 0.9316962979557941d);
// flaky "55) test434(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double8 + "' != '" + 21.514947221980982d + "'", double8 == 21.514947221980982d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution6 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 120.54442181558605d, 0.0d, 0.22969314751614026d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double14 = randomDataImpl8.nextChiSquare(16.39959540883049d);
        double double17 = randomDataImpl8.nextGamma((double) 100L, 0.9066258578518134d);
        double double19 = randomDataImpl8.nextT((double) 1L);
        double double21 = randomDataImpl8.nextChiSquare((double) 100L);
        double double23 = randomDataImpl8.nextExponential((double) 1342499381265206610L);
        int int26 = randomDataImpl8.nextInt(92410965, 1028812019);
        randomDataImpl8.reSeedSecure();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.919399310827936d + "'", double14 == 10.919399310827936d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 81.87241173283697d + "'", double17 == 81.87241173283697d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2234590896900435d) + "'", double19 == (-0.2234590896900435d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 120.54442181558605d + "'", double21 == 120.54442181558605d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.07450506512479923E18d + "'", double23 == 1.07450506512479923E18d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 614504715 + "'", int26 == 614504715);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((double) 5L, (double) (short) 1, 2.766458368800151d);
        double double5 = normalDistribution3.density((-1.4165028871298073d));
        double double7 = normalDistribution3.inverseCumulativeProbability(0.7874548671504324d);
        double double9 = normalDistribution3.density(0.19335986621811754d);
        // The following exception was thrown during execution in test generation
        try {
            double double12 = normalDistribution3.probability((double) 94.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (94) must be less than or equal to upper endpoint (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.577521738126163E-10d + "'", double5 == 4.577521738126163E-10d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.702637376954931d + "'", double7 == 5.702637376954931d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.8369482992805285E-6d + "'", double9 == 3.8369482992805285E-6d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        double double8 = randomDataGenerator0.nextWeibull(79.20824041041072d, (double) 0.74324155f);
// flaky "138) test438(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "56) test438(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7487046166673371d + "'", double8 == 0.7487046166673371d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian(0.44942288081866993d, 1.000000000000002E-288d);
        // The following exception was thrown during execution in test generation
        try {
            double double10 = randomDataGenerator0.nextUniform(0.5000000017594117d, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0.5) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "139) test439(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.6119568752650872d + "'", double3 == 2.6119568752650872d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.44942288081866993d + "'", double6 == 0.44942288081866993d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        double double20 = randomDataImpl8.nextUniform(0.0d, 0.5000000013965371d);
        double double23 = randomDataImpl8.nextGamma(9.90565059165379E-4d, (double) 14);
        int int26 = randomDataImpl8.nextInt((-47), 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.27433221325624985d + "'", double20 == 0.27433221325624985d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-3) + "'", int26 == (-3));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getNumericalVariance();
        double double7 = gammaDistribution3.getBeta();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5865.081109543426d + "'", double6 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution14 = new org.apache.commons.math3.distribution.GammaDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, 0.8822285080719574d, 0.5456928232039928d, (double) 32L);
        double double15 = gammaDistribution14.getSupportUpperBound();
        double double16 = gammaDistribution14.getNumericalVariance();
        double double17 = gammaDistribution14.getSupportUpperBound();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.26271058501924055d + "'", double16 == 0.26271058501924055d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.POSITIVE_INFINITY + "'", double17 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = randomDataImpl8.getDelegate();
        double double20 = randomDataGenerator18.nextT(4.7421875d);
        // The following exception was thrown during execution in test generation
        try {
            double double23 = randomDataGenerator18.nextUniform(8.881784197001252E-16d, 8.881784197001252E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
        org.junit.Assert.assertNotNull(randomDataGenerator18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.206086869959821d + "'", double20 == 0.206086869959821d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        int[] intArray14 = well19937c1.iRm1;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long18 = randomDataImpl15.nextLong((long) (short) 0, (long) 2147483647);
        double double21 = randomDataImpl15.nextGaussian(0.0d, 0.8994647839664798d);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1260996712L + "'", long18 == 1260996712L);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.416919903316891d) + "'", double21 == (-1.416919903316891d));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getBeta();
        double double9 = gammaDistribution3.getSupportUpperBound();
        double double10 = gammaDistribution3.getNumericalVariance();
        double double12 = gammaDistribution3.cumulativeProbability(4.7421875d);
        double double14 = gammaDistribution3.density(2.1825029133687357d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5865.081109543426d + "'", double10 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.1668524405453939d + "'", double12 == 0.1668524405453939d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.029265749635600063d + "'", double14 == 0.029265749635600063d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        double double15 = randomDataImpl8.nextWeibull(81.87241173283697d, 4.7421875d);
        java.lang.String str17 = randomDataImpl8.nextSecureHexString((int) '4');
        // The following exception was thrown during execution in test generation
        try {
            double double20 = randomDataImpl8.nextGaussian(3.3663081124299024d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.644339562383774d + "'", double15 == 4.644339562383774d);
// flaky "140) test446(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str17 + "' != '" + "ff088c084dac2eda23f5a3bae25cb585789c082670044cacea1d" + "'", str17, "ff088c084dac2eda23f5a3bae25cb585789c082670044cacea1d");
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) 100);
        well19937c1.clear();
        boolean boolean3 = well19937c1.nextBoolean();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = well19937c1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        long long13 = randomDataImpl8.nextSecureLong(0L, 1L);
        double double15 = randomDataImpl8.nextT(2.0d);
        int int18 = randomDataImpl8.nextPascal(32, (double) 0.7685776f);
        // The following exception was thrown during execution in test generation
        try {
            int int21 = randomDataImpl8.nextSecureInt(1689900776, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,689,900,776) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "17) test448(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7874548671504324d + "'", double15 == 0.7874548671504324d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.clear();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator10 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray13 = randomDataGenerator10.nextPermutation((int) '4', 1378651682);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: permutation size (1,378,651,682) exceeds permuation domain (52)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        double double17 = randomDataImpl8.nextT(1.5287994033960568d);
        double double21 = randomDataImpl8.nextUniform((-0.7615941559557649d), 4.0533378281932396E-46d, false);
        // The following exception was thrown during execution in test generation
        try {
            long long24 = randomDataImpl8.nextSecureLong((long) 1689900776, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,689,900,776) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.22969314751614026d + "'", double17 == 0.22969314751614026d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.34373453631013684d) + "'", double21 == (-0.34373453631013684d));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        long long15 = randomDataImpl8.nextLong((long) (-127), (long) (short) 10);
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution16 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double17 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution16);
        randomDataImpl8.reSeedSecure();
        long long20 = randomDataImpl8.nextPoisson(3.141592653589793d);
        int int23 = randomDataImpl8.nextPascal(63, 1.374222606613847E-16d);
        java.lang.String str25 = randomDataImpl8.nextSecureHexString(6);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-105L) + "'", long15 == (-105L));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.1951490178062096d + "'", double17 == 0.1951490178062096d);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 4L + "'", long20 == 4L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
// flaky "141) test451(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str25 + "' != '" + "543036" + "'", str25, "543036");
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator15 = randomDataImpl8.getDelegate();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(randomDataGenerator15);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getBeta();
        double double9 = gammaDistribution3.getSupportUpperBound();
        double double10 = gammaDistribution3.getNumericalVariance();
        double double12 = gammaDistribution3.cumulativeProbability(4.7421875d);
        double double13 = gammaDistribution3.getSupportUpperBound();
        boolean boolean14 = gammaDistribution3.isSupportLowerBoundInclusive();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5865.081109543426d + "'", double10 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.1668524405453939d + "'", double12 == 0.1668524405453939d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextUniform(0.0d, 3.310625339433012d);
        double double9 = randomDataGenerator0.nextUniform(0.0d, (double) 10.0f, true);
        randomDataGenerator0.reSeed(1L);
        double double13 = randomDataGenerator0.nextT(1.0299996991327358d);
// flaky "142) test454(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.6294995602790446d + "'", double5 == 0.6294995602790446d);
// flaky "57) test454(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.483076792037938d + "'", double9 == 9.483076792037938d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-4.132451438783001d) + "'", double13 == (-4.132451438783001d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getAlpha();
        double double9 = gammaDistribution3.getBeta();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6233479763570439d + "'", double8 == 0.6233479763570439d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        boolean boolean6 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double7 = gammaDistribution3.getShape();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6233479763570439d + "'", double7 == 0.6233479763570439d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(82.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: standard deviation (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((double) 5L, (double) (short) 1, 2.766458368800151d);
        double double5 = normalDistribution3.density((-1.4165028871298073d));
        double double7 = normalDistribution3.inverseCumulativeProbability(0.7874548671504324d);
        double double8 = normalDistribution3.sample();
        double double9 = normalDistribution3.getSupportLowerBound();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.577521738126163E-10d + "'", double5 == 4.577521738126163E-10d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.702637376954931d + "'", double7 == 5.702637376954931d);
// flaky "143) test458(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.008854421023779d + "'", double8 == 5.008854421023779d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        int int2 = well19937c1.index;
        long long3 = well19937c1.nextLong();
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator4 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray7 = randomDataGenerator4.nextPermutation((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4418713979230659041L + "'", long3 == 4418713979230659041L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        long long12 = randomDataImpl9.nextSecureLong((long) (-1), (long) 4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
// flaky "144) test460(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        randomDataGenerator0.reSeedSecure((long) (short) 1);
        double double5 = randomDataGenerator0.nextBeta(1.000000000000002E-288d, 8.568214410979046E-178d);
        long long8 = randomDataGenerator0.nextLong((long) (-401038879), (long) ' ');
        double double11 = randomDataGenerator0.nextWeibull(3.79226455416768d, 0.3934606808571868d);
        // The following exception was thrown during execution in test generation
        try {
            double double14 = randomDataGenerator0.nextF(0.011387501180708769d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "145) test461(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
// flaky "58) test461(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-278908604L) + "'", long8 == (-278908604L));
// flaky "18) test461(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.34685841646067855d + "'", double11 == 0.34685841646067855d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.getNumericalVariance();
        double double8 = normalDistribution2.cumulativeProbability((-0.23121594723306654d), 0.5188758931495504d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.029807922050748913d + "'", double8 == 0.029807922050748913d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i2;
        boolean boolean8 = well19937c1.nextBoolean();
        double double9 = well19937c1.nextGaussian();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.5260712867320414d) + "'", double9 == (-1.5260712867320414d));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        int int16 = randomDataImpl8.nextBinomial(1, 0.3934606808571868d);
        randomDataImpl8.reSeedSecure((long) (-1));
        double double22 = randomDataImpl8.nextUniform(1.059529144682836d, 3.3663081124299024d, false);
        // The following exception was thrown during execution in test generation
        try {
            double double25 = randomDataImpl8.nextUniform((double) 10L, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (10) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.276050933369993d + "'", double22 == 2.276050933369993d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution3 = new org.apache.commons.math3.distribution.NormalDistribution((-0.9995560569658268d), 0.48092575793941483d, (-0.3906270427650007d));
        java.lang.Class<?> wildcardClass4 = normalDistribution3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        well19937c1.setSeed(32L);
        int[] intArray11 = well19937c1.v;
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        org.apache.commons.math3.random.Well19937c well19937c8 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c8.nextBytes(byteArray12);
        int[] intArray14 = well19937c8.i3;
        double double15 = well19937c8.nextDouble();
        well19937c8.setSeed(32L);
        float float18 = well19937c8.nextFloat();
        org.apache.commons.math3.random.Well19937c well19937c20 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray24 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c20.nextBytes(byteArray24);
        int[] intArray26 = well19937c20.i3;
        double double27 = well19937c20.nextDouble();
        well19937c20.setSeed((long) (short) 1);
        long long30 = well19937c20.nextLong();
        byte[] byteArray31 = new byte[] {};
        well19937c20.nextBytes(byteArray31);
        well19937c8.nextBytes(byteArray31);
        well19937c1.nextBytes(byteArray31);
        int[] intArray35 = null;
        well19937c1.setSeed(intArray35);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertArrayEquals(byteArray12, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9066258578518134d + "'", double15 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.7685776f + "'", float18 == 0.7685776f);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertArrayEquals(byteArray24, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.9066258578518134d + "'", double27 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1342499381265206610L + "'", long30 == 1342499381265206610L);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertArrayEquals(byteArray31, new byte[] {});
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution2 = new org.apache.commons.math3.distribution.GammaDistribution(5.02453019765138d, 0.27530807973333826d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        int int5 = well19937c1.next((int) ' ');
        well19937c1.clear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 646549088 + "'", int5 == 646549088);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution(0.5000000015046252d, 1.5223961928507554d);
        double double4 = normalDistribution2.density(0.6857853477016901d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2601048869004294d + "'", double4 == 0.2601048869004294d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray9 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c3.setSeed(intArray9);
        well19937c1.setSeed(intArray9);
        org.apache.commons.math3.random.Well19937c well19937c13 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        org.apache.commons.math3.random.Well19937c well19937c15 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray21 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c15.setSeed(intArray21);
        well19937c13.setSeed(intArray21);
        well19937c1.setSeed(intArray21);
        well19937c1.setSeed(73);
        org.apache.commons.math3.random.Well19937c well19937c28 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray32 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c28.nextBytes(byteArray32);
        int[] intArray34 = well19937c28.i2;
        well19937c1.setSeed(intArray34);
        well19937c1.index = 1689900776;
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertArrayEquals(intArray9, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertArrayEquals(intArray21, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((-47));
        org.apache.commons.math3.random.Well19937c well19937c3 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c3.nextBytes(byteArray7);
        int[] intArray9 = well19937c3.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c3);
        int[] intArray11 = well19937c3.iRm2;
        well19937c1.setSeed(intArray11);
        double double13 = well19937c1.nextDouble();
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertArrayEquals(byteArray7, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.15298978872558489d + "'", double13 == 0.15298978872558489d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution0 = new org.apache.commons.math3.distribution.NormalDistribution();
        double double2 = normalDistribution0.cumulativeProbability(5.1481760329336096E17d);
        double double4 = normalDistribution0.cumulativeProbability(8.799776278533304d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        double double8 = gammaDistribution3.getAlpha();
        double[] doubleArray10 = gammaDistribution3.sample((int) (byte) 1);
        double double12 = gammaDistribution3.density(102400.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6233479763570439d + "'", double8 == 0.6233479763570439d);
        org.junit.Assert.assertNotNull(doubleArray10);
// flaky "146) test474(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertArrayEquals(doubleArray10, new double[] { 210.0064538364819d }, 1.0E-15);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c(251174);
        float float2 = well19937c1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.2183845f + "'", float2 == 0.2183845f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double9 = well19937c1.nextDouble();
        int int10 = well19937c1.nextInt();
        int int12 = well19937c1.next(5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9066258578518134d + "'", double9 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1378651682 + "'", int10 == 1378651682);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution2 = new org.apache.commons.math3.distribution.GammaDistribution(0.0d, 0.07834226813242862d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        double double10 = randomDataImpl8.nextT((double) 1.0000001f);
        long long12 = randomDataImpl8.nextPoisson((double) 1L);
        randomDataImpl8.reSeedSecure((-1L));
        long long17 = randomDataImpl8.nextLong(0L, (long) '#');
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator18 = randomDataImpl8.getDelegate();
        double double20 = randomDataGenerator18.nextExponential(8.881784197001252E-16d);
        java.lang.String str22 = randomDataGenerator18.nextSecureHexString(4);
        // The following exception was thrown during execution in test generation
        try {
            long long25 = randomDataGenerator18.nextSecureLong(1L, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.310625339433012d + "'", double10 == 3.310625339433012d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
        org.junit.Assert.assertNotNull(randomDataGenerator18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.374222606613847E-16d + "'", double20 == 1.374222606613847E-16d);
// flaky "147) test478(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str22 + "' != '" + "6275" + "'", str22, "6275");
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double[] doubleArray5 = gammaDistribution3.sample((int) ' ');
        double double7 = gammaDistribution3.cumulativeProbability(1.5707963267948966d);
        boolean boolean8 = gammaDistribution3.isSupportUpperBoundInclusive();
        double double10 = gammaDistribution3.cumulativeProbability((double) 4418713979230659041L);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08484461357703173d + "'", double7 == 0.08484461357703173d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        long long2 = well19937c1.nextLong();
        double double3 = well19937c1.nextDouble();
        org.apache.commons.math3.random.Well19937c well19937c5 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray11 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c5.setSeed(intArray11);
        well19937c1.setSeed(intArray11);
        int[] intArray14 = well19937c1.iRm1;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl15.reSeed();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4418713979230659041L + "'", long2 == 4418713979230659041L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3934606808571868d + "'", double3 == 0.3934606808571868d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertArrayEquals(intArray11, new int[] { 35, 0, 100, 10, 0 });
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        java.lang.String str15 = randomDataImpl8.nextSecureHexString((int) '4');
        randomDataImpl8.reSeed();
        double double20 = randomDataImpl8.nextUniform(273.6639152106989d, 1.8665117618113098E11d, false);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
// flaky "148) test481(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str15 + "' != '" + "bbcf70122784a4b03e3fcb8a3205e5db9c69aa3c24c3328006af" + "'", str15, "bbcf70122784a4b03e3fcb8a3205e5db9c69aa3c24c3328006af");
// flaky "59) test481(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double20 + "' != '" + 6.546942328861153E10d + "'", double20 == 6.546942328861153E10d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        int int13 = randomDataImpl8.nextBinomial(0, 0.14218002608626515d);
        // The following exception was thrown during execution in test generation
        try {
            double double15 = randomDataImpl8.nextT((double) (-47.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (-47)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) 32.000004f);
        double double6 = gammaDistribution3.getNumericalVariance();
        double double7 = gammaDistribution3.getSupportUpperBound();
        boolean boolean8 = gammaDistribution3.isSupportUpperBoundInclusive();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.494749104184766d + "'", double5 == 0.494749104184766d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5865.081109543426d + "'", double6 == 5865.081109543426d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 1, (double) (short) 10);
        double double4 = normalDistribution2.probability(1.0E-9d);
        double double5 = normalDistribution2.getNumericalVariance();
        normalDistribution2.reseedRandomGenerator(94L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        int int15 = randomDataGenerator0.nextPascal((int) (byte) 1, 0.3934606808571868d);
        long long17 = randomDataGenerator0.nextPoisson((double) (byte) 100);
// flaky "149) test485(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.57056554921115d + "'", double3 == 34.57056554921115d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 113L + "'", long17 == 113L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextGaussian((double) (-7796297722204279230L), (double) 409060042);
        // The following exception was thrown during execution in test generation
        try {
            double double15 = randomDataImpl8.nextF(0.0d, 0.8841066214265343d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: degrees of freedom (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-7.7962977216907254E18d) + "'", double12 == (-7.7962977216907254E18d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution(0.6233479763570439d, (double) 'a', Double.NaN);
        double double5 = gammaDistribution3.cumulativeProbability((double) (-127));
        double double7 = gammaDistribution3.cumulativeProbability(0.5113968871894786d);
        double double8 = gammaDistribution3.getSupportUpperBound();
        double double9 = gammaDistribution3.sample();
        double double12 = gammaDistribution3.cumulativeProbability(0.0d, 2044.5491797688765d);
        double double13 = gammaDistribution3.getNumericalMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.04232968535189235d + "'", double7 == 0.04232968535189235d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
// flaky "150) test487(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double9 + "' != '" + 24.05285673647747d + "'", double9 == 24.05285673647747d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9999999998478477d + "'", double12 == 0.9999999998478477d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 60.46475370663325d + "'", double13 == 60.46475370663325d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = randomDataGenerator0.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: length (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "151) test488(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.594612770030915d + "'", double3 == 0.594612770030915d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double12 = randomDataGenerator0.nextGamma(3.79226455416768d, 0.6566380334237375d);
        double double14 = randomDataGenerator0.nextChiSquare((double) 10);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray17 = randomDataGenerator0.nextPermutation(4, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: permutation size (-1");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
// flaky "152) test489(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 50.299141337452234d + "'", double3 == 50.299141337452234d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.8957779288675325d + "'", double12 == 2.8957779288675325d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 7.095868130534999d + "'", double14 == 7.095868130534999d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        double double6 = randomDataGenerator0.nextGaussian((double) 1342499381265206610L, (double) 32);
        randomDataGenerator0.reSeed();
        randomDataGenerator0.reSeed(100L);
        double double11 = randomDataGenerator0.nextExponential(0.6874872252363187d);
        java.lang.String str13 = randomDataGenerator0.nextSecureHexString(82);
// flaky "153) test490(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.431316643800109d + "'", double3 == 6.431316643800109d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.34249938126520653E18d + "'", double6 == 1.34249938126520653E18d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.3132117912189065d + "'", double11 == 1.3132117912189065d);
// flaky "60) test490(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str13 + "' != '" + "85e2a5f4fc4b07ffbf270a40a2b67be35a3236235198d8557ebc8eec991f8dafe5ae681e4495c55679" + "'", str13, "85e2a5f4fc4b07ffbf270a40a2b67be35a3236235198d8557ebc8eec991f8dafe5ae681e4495c55679");
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        randomDataImpl8.reSeed();
        int int13 = randomDataImpl8.nextBinomial(0, 0.14218002608626515d);
        double double16 = randomDataImpl8.nextF(1.1102230246251565E-16d, 1.2487305599455705d);
        org.apache.commons.math3.random.RandomGenerator randomGenerator17 = null;
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution21 = new org.apache.commons.math3.distribution.NormalDistribution(randomGenerator17, (double) (-1), (double) '#', 100.0d);
        double double23 = normalDistribution21.cumulativeProbability(0.0d);
        boolean boolean24 = normalDistribution21.isSupportConnected();
        double double25 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math3.distribution.RealDistribution) normalDistribution21);
        long long27 = randomDataImpl8.nextPoisson((double) 99L);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
// flaky "154) test491(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.7725080126966867E-9d + "'", double16 == 1.7725080126966867E-9d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5113968002624507d + "'", double23 == 0.5113968002624507d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
// flaky "61) test491(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double25 + "' != '" + 34.96483723426265d + "'", double25 == 34.96483723426265d);
// flaky "19) test491(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + long27 + "' != '" + 111L + "'", long27 == 111L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math3.distribution.GammaDistribution gammaDistribution3 = new org.apache.commons.math3.distribution.GammaDistribution((-0.7615941559557649d), 0.0d, 0.7762223750904278d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: shape (-0.762)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
            // Expected exception.
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) 32);
        int[] intArray7 = new int[] { '#', (short) 0, 100, 10, (byte) 0 };
        well19937c1.setSeed(intArray7);
        org.apache.commons.math3.random.Well19937c well19937c9 = new org.apache.commons.math3.random.Well19937c(intArray7);
        well19937c9.clear();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertArrayEquals(intArray7, new int[] { 35, 0, 100, 10, 0 });
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution0 = new org.apache.commons.math3.distribution.LogNormalDistribution();
        double double2 = logNormalDistribution0.density(1.9283289552270317d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16676169823315717d + "'", double2 == 0.16676169823315717d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math3.distribution.NormalDistribution normalDistribution2 = new org.apache.commons.math3.distribution.NormalDistribution((double) 2147483647, 32.12303167685084d);
        // The following exception was thrown during execution in test generation
        try {
            double double5 = normalDistribution2.probability(21.23248944257666d, (double) (-392573841L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (21.232) must be less than or equal to upper endpoint (-392,573,841)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator0 = new org.apache.commons.math3.random.RandomDataGenerator();
        double double3 = randomDataGenerator0.nextF(1.0d, 1.0d);
        randomDataGenerator0.reSeedSecure((long) (byte) 0);
        double double7 = randomDataGenerator0.nextExponential(Double.POSITIVE_INFINITY);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = randomDataGenerator0.nextInt(1219788447, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (1,219,788,447) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
// flaky "155) test496(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0858373316591173d + "'", double3 == 0.0858373316591173d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution3 = new org.apache.commons.math3.distribution.LogNormalDistribution((double) (byte) -1, (double) 4418713979230659041L, 1225.0d);
        // The following exception was thrown during execution in test generation
        try {
            double double6 = logNormalDistribution3.probability(1.0847303959306388E27d, 9.578115290425256d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower endpoint (1,084,730,395,930,638,800,000,000,000) must be less than or equal to upper endpoint (9.578)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        randomDataImpl8.reSeed((long) 0);
        double double13 = randomDataImpl8.nextGaussian((double) 4418713979230659041L, 0.8822285080719574d);
        java.lang.String str15 = randomDataImpl8.nextSecureHexString((int) '4');
        long long17 = randomDataImpl8.nextPoisson(0.5970312061663692d);
        java.lang.String str19 = randomDataImpl8.nextSecureHexString(3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.4187139792306591E18d + "'", double13 == 4.4187139792306591E18d);
// flaky "156) test498(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str15 + "' != '" + "f6f1e065ceb22307af8952a68ea54cd0cfdbfd3fd99c4c790c2d" + "'", str15, "f6f1e065ceb22307af8952a68ea54cd0cfdbfd3fd99c4c790c2d");
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
// flaky "62) test498(org.apache.commons.math3.random.RegressionTest0)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "955" + "'", str19, "955");
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        double double8 = well19937c1.nextDouble();
        double double9 = well19937c1.nextGaussian();
        long long10 = well19937c1.nextLong();
        int int12 = well19937c1.nextInt(1028812019);
        org.apache.commons.math3.distribution.LogNormalDistribution logNormalDistribution16 = new org.apache.commons.math3.distribution.LogNormalDistribution((org.apache.commons.math3.random.RandomGenerator) well19937c1, (double) (-93467950L), 1.5223961928507554d, (double) 1028812019);
        double double17 = logNormalDistribution16.getSupportLowerBound();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9066258578518134d + "'", double8 == 0.9066258578518134d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.8177111776375223d) + "'", double9 == (-0.8177111776375223d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-7796297722204279230L) + "'", long10 == (-7796297722204279230L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 149435855 + "'", int12 == 149435855);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.random.Well19937c well19937c1 = new org.apache.commons.math3.random.Well19937c((long) (byte) -1);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1 };
        well19937c1.nextBytes(byteArray5);
        int[] intArray7 = well19937c1.i3;
        org.apache.commons.math3.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator) well19937c1);
        org.apache.commons.math3.random.RandomDataGenerator randomDataGenerator9 = randomDataImpl8.getDelegate();
        double double12 = randomDataImpl8.nextGaussian((double) (-7796297722204279230L), (double) 409060042);
        // The following exception was thrown during execution in test generation
        try {
            int int15 = randomDataImpl8.nextSecureInt(86, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: lower bound (86) must be strictly less than upper bound (3)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertArrayEquals(byteArray5, new byte[] { (byte) -13, (byte) 108, (byte) 82 });
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(randomDataGenerator9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-7.7962977216907254E18d) + "'", double12 == (-7.7962977216907254E18d));
    }
}
