package org.joda.time.field;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1001");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        java.lang.String str4 = dateTimeField3.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType5, 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str10 = dateTimeFieldType9.getName();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfWeek();
        org.joda.time.Partial partial15 = new org.joda.time.Partial(dateTimeFieldType9, (int) 'a', (org.joda.time.Chronology) gregorianChronology13);
        int[] intArray19 = new int[] { 1, 1, 3 };
        int int20 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) partial15, intArray19);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray21 = partial15.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.DateTime dateTime23 = partial15.toDateTime(readableInstant22);
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.ReadableInterval readableInterval25 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval24);
        java.lang.String str26 = readableInterval25.toString();
        org.joda.time.ReadableInterval readableInterval27 = null;
        org.joda.time.ReadableInterval readableInterval28 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval27);
        java.lang.String str29 = readableInterval28.toString();
        boolean boolean30 = readableInterval25.contains(readableInterval28);
        org.joda.time.Period period31 = readableInterval28.toPeriod();
        org.joda.time.Partial partial32 = partial15.plus((org.joda.time.ReadablePeriod) period31);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfWeek();
        org.joda.time.DurationField durationField36 = gregorianChronology34.days();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology34.getZone();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology34.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = org.joda.time.DateTimeFieldType.secondOfDay();
        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 0.0f, (java.lang.Number) 367, (java.lang.Number) (-30758399903L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, dateTimeFieldType40, (int) ' ', (int) (short) 10, 32);
        boolean boolean49 = partial32.isSupported(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "DateTimeField[dayOfYear]" + "'", str4, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "minuteOfDay" + "'", str10, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertArrayEquals(intArray19, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(readableInterval25);
// flaky "1) test1001(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str26 + "' != '" + "2026-11-18T03:19:55.251-08:00/2026-11-18T03:19:55.251-08:00" + "'", str26, "2026-11-18T03:19:55.251-08:00/2026-11-18T03:19:55.251-08:00");
        org.junit.Assert.assertNotNull(readableInterval28);
// flaky "1) test1001(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str29 + "' != '" + "2026-11-18T03:19:55.251-08:00/2026-11-18T03:19:55.251-08:00" + "'", str29, "2026-11-18T03:19:55.251-08:00/2026-11-18T03:19:55.251-08:00");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(partial32);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test1002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1002");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("[minuteOfDay=97]");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("[minuteOfDay=97]");
        java.lang.String str5 = jodaTimePermission4.getName();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("[minuteOfDay=97]");
        java.lang.String str9 = jodaTimePermission8.getName();
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("[minuteOfDay=97]");
        java.lang.String str12 = jodaTimePermission11.getName();
        boolean boolean13 = jodaTimePermission8.implies((java.security.Permission) jodaTimePermission11);
        java.lang.String str14 = jodaTimePermission8.getActions();
        java.lang.String str15 = jodaTimePermission8.toString();
        boolean boolean16 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission8);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[minuteOfDay=97]" + "'", str2, "[minuteOfDay=97]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[minuteOfDay=97]" + "'", str5, "[minuteOfDay=97]");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[minuteOfDay=97]" + "'", str9, "[minuteOfDay=97]");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[minuteOfDay=97]" + "'", str12, "[minuteOfDay=97]");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"[minuteOfDay=97]\")" + "'", str15, "(\"org.joda.time.JodaTimePermission\" \"[minuteOfDay=97]\")");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test1003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1003");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str2 = dateTimeFieldType1.getName();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfWeek();
        org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldType1, (int) 'a', (org.joda.time.Chronology) gregorianChronology5);
        int int9 = partial7.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str11 = dateTimeFieldType10.getName();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfWeek();
        org.joda.time.Partial partial16 = new org.joda.time.Partial(dateTimeFieldType10, (int) 'a', (org.joda.time.Chronology) gregorianChronology14);
        int int18 = partial16.getValue(0);
        boolean boolean19 = partial7.isEqual((org.joda.time.ReadablePartial) partial16);
        int[] intArray21 = gregorianChronology0.get((org.joda.time.ReadablePartial) partial16, (long) (byte) 100);
        org.joda.time.Chronology chronology22 = partial16.getChronology();
        org.joda.time.DurationField durationField23 = chronology22.seconds();
        org.joda.time.DurationField durationField24 = chronology22.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeFieldType1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "minuteOfDay" + "'", str2, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "minuteOfDay" + "'", str11, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertArrayEquals(intArray21, new int[] { 960 });
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test1004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1004");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        org.joda.time.DurationField durationField4 = dateTimeField3.getRangeDurationField();
        java.util.Locale locale5 = null;
        int int6 = dateTimeField3.getMaximumTextLength(locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str8 = dateTimeFieldType7.getName();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.Partial partial13 = new org.joda.time.Partial(dateTimeFieldType7, (int) 'a', (org.joda.time.Chronology) gregorianChronology11);
        int int15 = partial13.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str17 = dateTimeFieldType16.getName();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.dayOfWeek();
        org.joda.time.Partial partial22 = new org.joda.time.Partial(dateTimeFieldType16, (int) 'a', (org.joda.time.Chronology) gregorianChronology20);
        int int24 = partial22.getValue(0);
        boolean boolean25 = partial13.isEqual((org.joda.time.ReadablePartial) partial22);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeField3.getAsText((org.joda.time.ReadablePartial) partial22, (int) (short) 10, locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str30 = dateTimeFieldType29.getName();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.dayOfWeek();
        org.joda.time.Partial partial35 = new org.joda.time.Partial(dateTimeFieldType29, (int) 'a', (org.joda.time.Chronology) gregorianChronology33);
        int int37 = partial35.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str39 = dateTimeFieldType38.getName();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.dayOfWeek();
        org.joda.time.Partial partial44 = new org.joda.time.Partial(dateTimeFieldType38, (int) 'a', (org.joda.time.Chronology) gregorianChronology42);
        int int46 = partial44.getValue(0);
        boolean boolean47 = partial35.isEqual((org.joda.time.ReadablePartial) partial44);
        boolean boolean48 = partial22.isMatch((org.joda.time.ReadablePartial) partial35);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = org.joda.time.DateTimeFieldType.millisOfDay();
        // The following exception was thrown during execution in test generation
        try {
            int int50 = partial22.get(dateTimeFieldType49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "minuteOfDay" + "'", str8, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "minuteOfDay" + "'", str17, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 97 + "'", int24 == 97);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "10" + "'", str28, "10");
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "minuteOfDay" + "'", str30, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 97 + "'", int37 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "minuteOfDay" + "'", str39, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
    }

    @Test
    public void test1005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1005");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str1 = dateTimeFieldType0.getName();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfWeek();
        org.joda.time.Partial partial6 = new org.joda.time.Partial(dateTimeFieldType0, (int) 'a', (org.joda.time.Chronology) gregorianChronology4);
        int int8 = partial6.getValue(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str11 = dateTimeFieldType10.getName();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfWeek();
        org.joda.time.Partial partial16 = new org.joda.time.Partial(dateTimeFieldType10, (int) 'a', (org.joda.time.Chronology) gregorianChronology14);
        int int18 = partial16.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str20 = dateTimeFieldType19.getName();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.dayOfWeek();
        org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldType19, (int) 'a', (org.joda.time.Chronology) gregorianChronology23);
        int int27 = partial25.getValue(0);
        boolean boolean28 = partial16.isEqual((org.joda.time.ReadablePartial) partial25);
        int[] intArray30 = gregorianChronology9.get((org.joda.time.ReadablePartial) partial25, (long) (byte) 100);
        org.joda.time.Chronology chronology31 = partial25.getChronology();
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTimeField dateTimeField35 = chronology34.dayOfYear();
        java.lang.String str36 = dateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, dateTimeFieldType37, 1);
        int int40 = offsetDateTimeField39.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str42 = dateTimeFieldType41.getName();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.dayOfWeek();
        org.joda.time.Partial partial47 = new org.joda.time.Partial(dateTimeFieldType41, (int) 'a', (org.joda.time.Chronology) gregorianChronology45);
        int[] intArray51 = new int[] { 1, 1, 3 };
        int int52 = offsetDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) partial47, intArray51);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray53 = partial47.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.DateTime dateTime55 = partial47.toDateTime(readableInstant54);
        org.joda.time.DateTime dateTime56 = partial25.toDateTime(readableInstant54);
        int int57 = partial6.compareTo((org.joda.time.ReadablePartial) partial25);
        org.joda.time.Chronology chronology58 = partial25.getChronology();
        org.joda.time.DurationField durationField59 = chronology58.seconds();
        org.joda.time.DurationFieldType durationFieldType60 = org.joda.time.DurationFieldType.weekyears();
        java.lang.String str61 = durationFieldType60.toString();
        org.joda.time.field.ScaledDurationField scaledDurationField63 = new org.joda.time.field.ScaledDurationField(durationField59, durationFieldType60, 53);
        long long64 = scaledDurationField63.getUnitMillis();
        int int67 = scaledDurationField63.getValue(315569520000L, (long) 0);
        long long69 = scaledDurationField63.getMillis(0);
        long long72 = scaledDurationField63.getMillis(365, (-19968695568000000L));
        int int74 = scaledDurationField63.getValue((-102815999931L));
        org.junit.Assert.assertNotNull(dateTimeFieldType0);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "minuteOfDay" + "'", str1, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "minuteOfDay" + "'", str11, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "minuteOfDay" + "'", str20, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertArrayEquals(intArray30, new int[] { 960 });
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "DateTimeField[dayOfYear]" + "'", str36, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "minuteOfDay" + "'", str42, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertArrayEquals(intArray51, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + "weekyears" + "'", str61, "weekyears");
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 53000L + "'", long64 == 53000L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 5954141 + "'", int67 == 5954141);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 19345000L + "'", long72 == 19345000L);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1939924) + "'", int74 == (-1939924));
    }

    @Test
    public void test1006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1006");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology1.days();
        org.joda.time.DurationField durationField4 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField8 = gregorianChronology7.hours();
        org.joda.time.Partial partial9 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.year();
        org.joda.time.Chronology chronology11 = gregorianChronology7.withUTC();
        // The following exception was thrown during execution in test generation
        try {
            long long16 = gregorianChronology7.getDateTimeMillis((int) (byte) -1, (int) 'a', 0, (-18));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -18 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test1007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1007");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        java.lang.String str4 = dateTimeField3.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType5, 1);
        org.joda.time.DurationField durationField8 = offsetDateTimeField7.getDurationField();
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField7.convertText("32", locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str14 = dateTimeFieldType13.getName();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.dayOfWeek();
        org.joda.time.Partial partial19 = new org.joda.time.Partial(dateTimeFieldType13, (int) 'a', (org.joda.time.Chronology) gregorianChronology17);
        int int21 = partial19.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str23 = dateTimeFieldType22.getName();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.dayOfWeek();
        org.joda.time.Partial partial28 = new org.joda.time.Partial(dateTimeFieldType22, (int) 'a', (org.joda.time.Chronology) gregorianChronology26);
        int int30 = partial28.getValue(0);
        boolean boolean31 = partial19.isEqual((org.joda.time.ReadablePartial) partial28);
        int[] intArray33 = gregorianChronology12.get((org.joda.time.ReadablePartial) partial28, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.dayOfYear();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.hourOfDay();
        org.joda.time.Partial partial38 = partial28.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology35);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str41 = dateTimeFieldType40.getName();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.dayOfWeek();
        org.joda.time.Partial partial46 = new org.joda.time.Partial(dateTimeFieldType40, (int) 'a', (org.joda.time.Chronology) gregorianChronology44);
        int int48 = partial46.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str50 = dateTimeFieldType49.getName();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone52);
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology53.dayOfWeek();
        org.joda.time.Partial partial55 = new org.joda.time.Partial(dateTimeFieldType49, (int) 'a', (org.joda.time.Chronology) gregorianChronology53);
        int int57 = partial55.getValue(0);
        boolean boolean58 = partial46.isEqual((org.joda.time.ReadablePartial) partial55);
        int[] intArray60 = gregorianChronology39.get((org.joda.time.ReadablePartial) partial55, (long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone61);
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.dayOfYear();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology62.hourOfDay();
        org.joda.time.Partial partial65 = partial55.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology62);
        int int66 = partial38.compareTo((org.joda.time.ReadablePartial) partial65);
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str69 = dateTimeFieldType68.getName();
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone71);
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.dayOfWeek();
        org.joda.time.Partial partial74 = new org.joda.time.Partial(dateTimeFieldType68, (int) 'a', (org.joda.time.Chronology) gregorianChronology72);
        int int76 = partial74.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str78 = dateTimeFieldType77.getName();
        org.joda.time.DateTimeZone dateTimeZone80 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology81 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone80);
        org.joda.time.DateTimeField dateTimeField82 = gregorianChronology81.dayOfWeek();
        org.joda.time.Partial partial83 = new org.joda.time.Partial(dateTimeFieldType77, (int) 'a', (org.joda.time.Chronology) gregorianChronology81);
        int int85 = partial83.getValue(0);
        boolean boolean86 = partial74.isEqual((org.joda.time.ReadablePartial) partial83);
        int[] intArray88 = gregorianChronology67.get((org.joda.time.ReadablePartial) partial83, (long) (byte) 100);
        int int89 = partial65.compareTo((org.joda.time.ReadablePartial) partial83);
        int int90 = offsetDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) partial65);
        long long92 = offsetDateTimeField7.roundHalfFloor(31556952000L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "DateTimeField[dayOfYear]" + "'", str4, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "minuteOfDay" + "'", str14, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "minuteOfDay" + "'", str23, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 97 + "'", int30 == 97);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertArrayEquals(intArray33, new int[] { 960 });
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(partial38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "minuteOfDay" + "'", str41, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 97 + "'", int48 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "minuteOfDay" + "'", str50, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 97 + "'", int57 == 97);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertArrayEquals(intArray60, new int[] { 960 });
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(partial65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertEquals("'" + str69 + "' != '" + "minuteOfDay" + "'", str69, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 97 + "'", int76 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertEquals("'" + str78 + "' != '" + "minuteOfDay" + "'", str78, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology81);
        org.junit.Assert.assertNotNull(dateTimeField82);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 97 + "'", int85 == 97);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertArrayEquals(intArray88, new int[] { 960 });
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 367 + "'", int90 == 367);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 31564800000L + "'", long92 == 31564800000L);
    }

    @Test
    public void test1008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1008");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        java.lang.String str4 = dateTimeField3.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType5, 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long11 = offsetDateTimeField7.add((long) (short) 0, (int) (byte) 0);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTimeField dateTimeField15 = chronology14.dayOfYear();
        java.lang.String str16 = dateTimeField15.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType17, 1);
        int int20 = offsetDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str22 = dateTimeFieldType21.getName();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.dayOfWeek();
        org.joda.time.Partial partial27 = new org.joda.time.Partial(dateTimeFieldType21, (int) 'a', (org.joda.time.Chronology) gregorianChronology25);
        int[] intArray31 = new int[] { 1, 1, 3 };
        int int32 = offsetDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) partial27, intArray31);
        org.joda.time.DurationFieldType durationFieldType33 = org.joda.time.DurationFieldType.minutes();
        org.joda.time.Partial partial35 = partial27.withFieldAdded(durationFieldType33, (int) (byte) 10);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) partial27, (int) ' ', locale37);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        long long43 = iSOChronology39.add(readablePeriod40, 100L, 1);
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology39.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology39.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology39.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = dateTimeField46.getType();
        org.joda.time.Partial partial48 = partial27.without(dateTimeFieldType47);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray49 = partial48.getFieldTypes();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "DateTimeField[dayOfYear]" + "'", str4, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "DateTimeField[dayOfYear]" + "'", str16, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "minuteOfDay" + "'", str22, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertArrayEquals(intArray31, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(partial35);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "32" + "'", str38, "32");
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(partial48);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray49);
    }

    @Test
    public void test1009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1009");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = org.joda.time.DateTimeFieldType.weekyearOfCentury();
        org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-210866673600000L), "2");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfWeek();
        org.joda.time.DurationField durationField7 = gregorianChronology5.days();
        org.joda.time.DurationField durationField8 = gregorianChronology5.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.secondOfMinute();
        org.joda.time.DurationField durationField10 = gregorianChronology5.halfdays();
        org.joda.time.DurationField durationField11 = gregorianChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField11);
        java.lang.String str13 = unsupportedDateTimeField12.toString();
        java.lang.String str14 = unsupportedDateTimeField12.getName();
        long long17 = unsupportedDateTimeField12.add((long) (-1630), 960);
        org.joda.time.DurationField durationField18 = unsupportedDateTimeField12.getDurationField();
        long long21 = unsupportedDateTimeField12.add(0L, 30182400000L);
        // The following exception was thrown during execution in test generation
        try {
            int int23 = unsupportedDateTimeField12.get(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTimeFieldType0);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "UnsupportedDateTimeField" + "'", str13, "UnsupportedDateTimeField");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "weekyearOfCentury" + "'", str14, "weekyearOfCentury");
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 958370L + "'", long17 == 958370L);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 30182400000000L + "'", long21 == 30182400000000L);
    }

    @Test
    public void test1010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1010");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology1.days();
        org.joda.time.DurationField durationField4 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField6 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField9 = gregorianChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.DurationField durationField13 = gregorianChronology11.days();
        org.joda.time.DurationField durationField14 = gregorianChronology11.halfdays();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone15);
        long long23 = zonedChronology18.getDateTimeMillis(366, 3, (int) (byte) 10, 356);
        java.lang.String str24 = zonedChronology18.toString();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology18.year();
        // The following exception was thrown during execution in test generation
        try {
            long long33 = zonedChronology18.getDateTimeMillis(315621240, 0, 328, (-58686), (int) (short) 100, (int) (byte) 0, 5259463);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -58686 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-50611450021644L) + "'", long23 == (-50611450021644L));
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str24, "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test1011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1011");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        java.lang.String str4 = dateTimeField3.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType5, 1);
        java.lang.String str8 = offsetDateTimeField7.getName();
        boolean boolean10 = offsetDateTimeField7.isLeap((long) (byte) 0);
        long long12 = offsetDateTimeField7.roundHalfEven(10L);
        org.joda.time.Partial partial13 = new org.joda.time.Partial();
        org.joda.time.Chronology chronology14 = partial13.getChronology();
        int[] intArray15 = partial13.getValues();
        int int16 = offsetDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) partial13);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = org.joda.time.DateTimeFieldType.weekyearOfCentury();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) (-210866673600000L), "2");
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.dayOfWeek();
        org.joda.time.DurationField durationField24 = gregorianChronology22.days();
        org.joda.time.DurationField durationField25 = gregorianChronology22.halfdays();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.secondOfMinute();
        org.joda.time.DurationField durationField27 = gregorianChronology22.halfdays();
        org.joda.time.DurationField durationField28 = gregorianChronology22.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, durationField28);
        java.lang.String str30 = unsupportedDateTimeField29.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = unsupportedDateTimeField29.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = unsupportedDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType32, (-34));
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37);
        java.lang.String str39 = gregorianChronology38.toString();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.dayOfWeek();
        org.joda.time.DurationField durationField44 = gregorianChronology42.days();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology42.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology42.getZone();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology42.era();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology42.yearOfCentury();
        org.joda.time.ReadableInterval readableInterval49 = null;
        org.joda.time.ReadableInterval readableInterval50 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval49);
        java.lang.String str51 = readableInterval50.toString();
        org.joda.time.ReadableInterval readableInterval52 = null;
        org.joda.time.ReadableInterval readableInterval53 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval52);
        java.lang.String str54 = readableInterval53.toString();
        boolean boolean55 = readableInterval50.contains(readableInterval53);
        org.joda.time.Period period56 = readableInterval53.toPeriod();
        int[] intArray59 = gregorianChronology42.get((org.joda.time.ReadablePeriod) period56, 3023999999L, (long) (short) -1);
        int[] intArray61 = gregorianChronology38.get((org.joda.time.ReadablePeriod) period56, 2359L);
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray63 = offsetDateTimeField7.add(readablePartial35, 550, intArray61, 31453);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 550 out of bounds for length 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "DateTimeField[dayOfYear]" + "'", str4, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "dayOfYear" + "'", str8, "dayOfYear");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertArrayEquals(intArray15, new int[] {});
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 367 + "'", int16 == 367);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "UnsupportedDateTimeField" + "'", str30, "UnsupportedDateTimeField");
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str39, "GregorianChronology[America/Los_Angeles]");
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(readableInterval50);
// flaky "2) test1011(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str51 + "' != '" + "2026-11-18T03:19:55.939-08:00/2026-11-18T03:19:55.939-08:00" + "'", str51, "2026-11-18T03:19:55.939-08:00/2026-11-18T03:19:55.939-08:00");
        org.junit.Assert.assertNotNull(readableInterval53);
// flaky "2) test1011(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str54 + "' != '" + "2026-11-18T03:19:55.939-08:00/2026-11-18T03:19:55.939-08:00" + "'", str54, "2026-11-18T03:19:55.939-08:00/2026-11-18T03:19:55.939-08:00");
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertArrayEquals(intArray59, new int[] { 0, (-1), 0, (-4), 0, 0, 0, 0 });
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertArrayEquals(intArray61, new int[] { 0, 0, 0, 0, 0, 0, 2, 359 });
    }

    @Test
    public void test1012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1012");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str2 = dateTimeFieldType1.getName();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfWeek();
        org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldType1, (int) 'a', (org.joda.time.Chronology) gregorianChronology5);
        int int9 = partial7.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str11 = dateTimeFieldType10.getName();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfWeek();
        org.joda.time.Partial partial16 = new org.joda.time.Partial(dateTimeFieldType10, (int) 'a', (org.joda.time.Chronology) gregorianChronology14);
        int int18 = partial16.getValue(0);
        boolean boolean19 = partial7.isEqual((org.joda.time.ReadablePartial) partial16);
        int[] intArray21 = gregorianChronology0.get((org.joda.time.ReadablePartial) partial16, (long) (byte) 100);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeFieldType1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "minuteOfDay" + "'", str2, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "minuteOfDay" + "'", str11, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertArrayEquals(intArray21, new int[] { 960 });
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test1013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1013");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) -1, 0);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(17418208665600000L, locale6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7, "-00:00:00.001");
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
    }

    @Test
    public void test1014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1014");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        java.lang.String str4 = dateTimeField3.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType5, 1);
        java.lang.String str8 = offsetDateTimeField7.getName();
        int int9 = offsetDateTimeField7.getMinimumValue();
        long long11 = offsetDateTimeField7.roundHalfCeiling((-1L));
        org.joda.time.DurationField durationField12 = offsetDateTimeField7.getDurationField();
        long long14 = offsetDateTimeField7.roundHalfEven((long) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str16 = dateTimeFieldType15.getName();
        java.lang.String str17 = dateTimeFieldType15.toString();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType15, 32);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTimeField dateTimeField23 = chronology22.dayOfYear();
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant24, readableInstant25);
        org.joda.time.DateTimeField dateTimeField27 = chronology26.dayOfYear();
        org.joda.time.DurationField durationField28 = dateTimeField27.getRangeDurationField();
        java.util.Locale locale29 = null;
        int int30 = dateTimeField27.getMaximumTextLength(locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str32 = dateTimeFieldType31.getName();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.dayOfWeek();
        org.joda.time.Partial partial37 = new org.joda.time.Partial(dateTimeFieldType31, (int) 'a', (org.joda.time.Chronology) gregorianChronology35);
        int int39 = partial37.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str41 = dateTimeFieldType40.getName();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.dayOfWeek();
        org.joda.time.Partial partial46 = new org.joda.time.Partial(dateTimeFieldType40, (int) 'a', (org.joda.time.Chronology) gregorianChronology44);
        int int48 = partial46.getValue(0);
        boolean boolean49 = partial37.isEqual((org.joda.time.ReadablePartial) partial46);
        java.util.Locale locale51 = null;
        java.lang.String str52 = dateTimeField27.getAsText((org.joda.time.ReadablePartial) partial46, (int) (short) 10, locale51);
        int int53 = partial46.size();
        long long55 = chronology22.set((org.joda.time.ReadablePartial) partial46, 0L);
        org.joda.time.DateTimeField[] dateTimeFieldArray56 = partial46.getFields();
        java.util.Locale locale58 = null;
        java.lang.String str59 = remainderDateTimeField19.getAsText((org.joda.time.ReadablePartial) partial46, (int) (byte) 10, locale58);
        int int60 = remainderDateTimeField19.iDivisor;
        long long62 = remainderDateTimeField19.roundFloor(25162000L);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "DateTimeField[dayOfYear]" + "'", str4, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "dayOfYear" + "'", str8, "dayOfYear");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800000L + "'", long14 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "minuteOfDay" + "'", str16, "minuteOfDay");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "minuteOfDay" + "'", str17, "minuteOfDay");
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "minuteOfDay" + "'", str32, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 97 + "'", int39 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "minuteOfDay" + "'", str41, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 97 + "'", int48 == 97);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertEquals("'" + str52 + "' != '" + "10" + "'", str52, "10");
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-51780000L) + "'", long55 == (-51780000L));
        org.junit.Assert.assertNotNull(dateTimeFieldArray56);
        org.junit.Assert.assertEquals("'" + str59 + "' != '" + "10" + "'", str59, "10");
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 32 + "'", int60 == 32);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-57600000L) + "'", long62 == (-57600000L));
    }

    @Test
    public void test1015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1015");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str2 = dateTimeFieldType1.getName();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfWeek();
        org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldType1, (int) 'a', (org.joda.time.Chronology) gregorianChronology5);
        int int9 = partial7.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str11 = dateTimeFieldType10.getName();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfWeek();
        org.joda.time.Partial partial16 = new org.joda.time.Partial(dateTimeFieldType10, (int) 'a', (org.joda.time.Chronology) gregorianChronology14);
        int int18 = partial16.getValue(0);
        boolean boolean19 = partial7.isEqual((org.joda.time.ReadablePartial) partial16);
        int[] intArray21 = gregorianChronology0.get((org.joda.time.ReadablePartial) partial16, (long) (byte) 100);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeFieldType1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "minuteOfDay" + "'", str2, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "minuteOfDay" + "'", str11, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertArrayEquals(intArray21, new int[] { 960 });
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test1016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1016");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.DurationField durationField5 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone(dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DurationField durationField14 = gregorianChronology12.days();
        org.joda.time.DurationField durationField15 = gregorianChronology12.halfdays();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        long long20 = dateTimeZone6.getMillisKeepLocal(dateTimeZone16, (-86399900L));
        long long22 = dateTimeZone6.previousTransition(422000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-86399900L) + "'", long20 == (-86399900L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-5756400001L) + "'", long22 == (-5756400001L));
    }

    @Test
    public void test1017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1017");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        java.lang.String str4 = dateTimeField3.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType5, 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str10 = dateTimeFieldType9.getName();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfWeek();
        org.joda.time.Partial partial15 = new org.joda.time.Partial(dateTimeFieldType9, (int) 'a', (org.joda.time.Chronology) gregorianChronology13);
        int[] intArray19 = new int[] { 1, 1, 3 };
        int int20 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) partial15, intArray19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str22 = dateTimeFieldType21.getName();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.dayOfWeek();
        org.joda.time.Partial partial27 = new org.joda.time.Partial(dateTimeFieldType21, (int) 'a', (org.joda.time.Chronology) gregorianChronology25);
        int int29 = partial27.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str31 = dateTimeFieldType30.getName();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.dayOfWeek();
        org.joda.time.Partial partial36 = new org.joda.time.Partial(dateTimeFieldType30, (int) 'a', (org.joda.time.Chronology) gregorianChronology34);
        int int38 = partial36.getValue(0);
        boolean boolean39 = partial27.isEqual((org.joda.time.ReadablePartial) partial36);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant40, readableInstant41);
        org.joda.time.DateTimeField dateTimeField43 = chronology42.dayOfYear();
        java.lang.String str44 = dateTimeField43.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType45, 1);
        int int48 = offsetDateTimeField47.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str50 = dateTimeFieldType49.getName();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone52);
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology53.dayOfWeek();
        org.joda.time.Partial partial55 = new org.joda.time.Partial(dateTimeFieldType49, (int) 'a', (org.joda.time.Chronology) gregorianChronology53);
        int[] intArray59 = new int[] { 1, 1, 3 };
        int int60 = offsetDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) partial55, intArray59);
        int int61 = offsetDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) partial27, intArray59);
        int int62 = offsetDateTimeField7.getMinimumValue();
        int int63 = offsetDateTimeField7.getMinimumValue();
        java.lang.String str65 = offsetDateTimeField7.getAsText(57590000L);
        long long67 = offsetDateTimeField7.roundHalfFloor((long) 96);
        // The following exception was thrown during execution in test generation
        try {
            long long70 = offsetDateTimeField7.set((long) ' ', (-31692366));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -31692366 for dayOfYear must be in the range [2,367]");
        } catch (org.joda.time.IllegalFieldValueException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "DateTimeField[dayOfYear]" + "'", str4, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "minuteOfDay" + "'", str10, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertArrayEquals(intArray19, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "minuteOfDay" + "'", str22, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "minuteOfDay" + "'", str31, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 97 + "'", int38 == 97);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "DateTimeField[dayOfYear]" + "'", str44, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "minuteOfDay" + "'", str50, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertArrayEquals(intArray59, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertEquals("'" + str65 + "' != '" + "2" + "'", str65, "2");
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 28800000L + "'", long67 == 28800000L);
    }

    @Test
    public void test1018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1018");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        java.lang.String str2 = readableInterval1.toString();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        java.lang.String str5 = readableInterval4.toString();
        boolean boolean6 = readableInterval1.contains(readableInterval4);
        org.joda.time.Interval interval7 = readableInterval4.toInterval();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        java.lang.String str10 = readableInterval9.toString();
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval11);
        java.lang.String str13 = readableInterval12.toString();
        boolean boolean14 = readableInterval9.contains(readableInterval12);
        org.joda.time.Interval interval15 = readableInterval12.toInterval();
        boolean boolean16 = interval7.isAfter((org.joda.time.ReadableInterval) interval15);
        org.joda.time.ReadableInterval readableInterval17 = null;
        org.joda.time.ReadableInterval readableInterval18 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval17);
        java.lang.String str19 = readableInterval18.toString();
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.ReadableInterval readableInterval21 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval20);
        java.lang.String str22 = readableInterval21.toString();
        boolean boolean23 = readableInterval18.contains(readableInterval21);
        boolean boolean24 = interval15.isAfter(readableInterval21);
        org.joda.time.ReadableInterval readableInterval25 = null;
        org.joda.time.ReadableInterval readableInterval26 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str29 = dateTimeFieldType28.getName();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.dayOfWeek();
        org.joda.time.Partial partial34 = new org.joda.time.Partial(dateTimeFieldType28, (int) 'a', (org.joda.time.Chronology) gregorianChronology32);
        int int36 = partial34.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str38 = dateTimeFieldType37.getName();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.dayOfWeek();
        org.joda.time.Partial partial43 = new org.joda.time.Partial(dateTimeFieldType37, (int) 'a', (org.joda.time.Chronology) gregorianChronology41);
        int int45 = partial43.getValue(0);
        boolean boolean46 = partial34.isEqual((org.joda.time.ReadablePartial) partial43);
        int[] intArray48 = gregorianChronology27.get((org.joda.time.ReadablePartial) partial43, (long) (byte) 100);
        org.joda.time.Chronology chronology49 = partial43.getChronology();
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant50, readableInstant51);
        org.joda.time.DateTimeField dateTimeField53 = chronology52.dayOfYear();
        java.lang.String str54 = dateTimeField53.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, dateTimeFieldType55, 1);
        int int58 = offsetDateTimeField57.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str60 = dateTimeFieldType59.getName();
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.dayOfWeek();
        org.joda.time.Partial partial65 = new org.joda.time.Partial(dateTimeFieldType59, (int) 'a', (org.joda.time.Chronology) gregorianChronology63);
        int[] intArray69 = new int[] { 1, 1, 3 };
        int int70 = offsetDateTimeField57.getMinimumValue((org.joda.time.ReadablePartial) partial65, intArray69);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray71 = partial65.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant72 = null;
        org.joda.time.DateTime dateTime73 = partial65.toDateTime(readableInstant72);
        org.joda.time.DateTime dateTime74 = partial43.toDateTime(readableInstant72);
        boolean boolean75 = readableInterval26.isAfter(readableInstant72);
        org.joda.time.Period period76 = readableInterval26.toPeriod();
        org.joda.time.DateTime dateTime77 = readableInterval26.getEnd();
        boolean boolean78 = interval15.isBefore((org.joda.time.ReadableInstant) dateTime77);
        java.lang.String str79 = interval15.toString();
        org.junit.Assert.assertNotNull(readableInterval1);
// flaky "3) test1018(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str2 + "' != '" + "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00" + "'", str2, "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00");
        org.junit.Assert.assertNotNull(readableInterval4);
// flaky "3) test1018(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str5 + "' != '" + "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00" + "'", str5, "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(readableInterval9);
// flaky "1) test1018(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str10 + "' != '" + "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00" + "'", str10, "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00");
        org.junit.Assert.assertNotNull(readableInterval12);
// flaky "1) test1018(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str13 + "' != '" + "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00" + "'", str13, "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(interval15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(readableInterval18);
// flaky "1) test1018(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str19 + "' != '" + "2026-11-18T03:19:56.348-08:00/2026-11-18T03:19:56.348-08:00" + "'", str19, "2026-11-18T03:19:56.348-08:00/2026-11-18T03:19:56.348-08:00");
        org.junit.Assert.assertNotNull(readableInterval21);
// flaky "1) test1018(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str22 + "' != '" + "2026-11-18T03:19:56.348-08:00/2026-11-18T03:19:56.348-08:00" + "'", str22, "2026-11-18T03:19:56.348-08:00/2026-11-18T03:19:56.348-08:00");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
// flaky "1) test1018(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(readableInterval26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "minuteOfDay" + "'", str29, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 97 + "'", int36 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "minuteOfDay" + "'", str38, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 97 + "'", int45 == 97);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertArrayEquals(intArray48, new int[] { 960 });
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertEquals("'" + str54 + "' != '" + "DateTimeField[dayOfYear]" + "'", str54, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertEquals("'" + str60 + "' != '" + "minuteOfDay" + "'", str60, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertArrayEquals(intArray69, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2 + "'", int70 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
// flaky "1) test1018(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str79 + "' != '" + "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00" + "'", str79, "2026-11-18T03:19:56.347-08:00/2026-11-18T03:19:56.347-08:00");
    }

    @Test
    public void test1019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1019");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = org.joda.time.DateTimeFieldType.weekyearOfCentury();
        org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-210866673600000L), "2");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfWeek();
        org.joda.time.DurationField durationField7 = gregorianChronology5.days();
        org.joda.time.DurationField durationField8 = gregorianChronology5.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.secondOfMinute();
        org.joda.time.DurationField durationField10 = gregorianChronology5.halfdays();
        org.joda.time.DurationField durationField11 = gregorianChronology5.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = unsupportedDateTimeField12.getType();
        java.lang.String str14 = unsupportedDateTimeField12.getName();
        long long17 = unsupportedDateTimeField12.getDifferenceAsLong(35L, (-230400000L));
        long long20 = unsupportedDateTimeField12.add((-57914085L), 9964800000L);
        // The following exception was thrown during execution in test generation
        try {
            int int22 = unsupportedDateTimeField12.get((-30758399903L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTimeFieldType0);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "weekyearOfCentury" + "'", str14, "weekyearOfCentury");
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 230400L + "'", long17 == 230400L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9964742085915L + "'", long20 == 9964742085915L);
    }

    @Test
    public void test1020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1020");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.DurationField durationField5 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone(dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean11 = cachedDateTimeZone10.isFixed();
        boolean boolean12 = cachedDateTimeZone10.isFixed();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.ReadableInterval readableInterval14 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval13);
        java.lang.String str15 = readableInterval14.toString();
        org.joda.time.ReadableInterval readableInterval16 = null;
        org.joda.time.ReadableInterval readableInterval17 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval16);
        java.lang.String str18 = readableInterval17.toString();
        boolean boolean19 = readableInterval14.contains(readableInterval17);
        org.joda.time.Interval interval20 = readableInterval17.toInterval();
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.ReadableInterval readableInterval22 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval21);
        java.lang.String str23 = readableInterval22.toString();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.ReadableInterval readableInterval25 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval24);
        java.lang.String str26 = readableInterval25.toString();
        boolean boolean27 = readableInterval22.contains(readableInterval25);
        org.joda.time.Interval interval28 = readableInterval25.toInterval();
        boolean boolean29 = interval20.isAfter((org.joda.time.ReadableInterval) interval28);
        org.joda.time.ReadableInterval readableInterval30 = null;
        org.joda.time.ReadableInterval readableInterval31 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str34 = dateTimeFieldType33.getName();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.dayOfWeek();
        org.joda.time.Partial partial39 = new org.joda.time.Partial(dateTimeFieldType33, (int) 'a', (org.joda.time.Chronology) gregorianChronology37);
        int int41 = partial39.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str43 = dateTimeFieldType42.getName();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone45);
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.dayOfWeek();
        org.joda.time.Partial partial48 = new org.joda.time.Partial(dateTimeFieldType42, (int) 'a', (org.joda.time.Chronology) gregorianChronology46);
        int int50 = partial48.getValue(0);
        boolean boolean51 = partial39.isEqual((org.joda.time.ReadablePartial) partial48);
        int[] intArray53 = gregorianChronology32.get((org.joda.time.ReadablePartial) partial48, (long) (byte) 100);
        org.joda.time.Chronology chronology54 = partial48.getChronology();
        org.joda.time.ReadableInstant readableInstant55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.Chronology chronology57 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant55, readableInstant56);
        org.joda.time.DateTimeField dateTimeField58 = chronology57.dayOfYear();
        java.lang.String str59 = dateTimeField58.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, dateTimeFieldType60, 1);
        int int63 = offsetDateTimeField62.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str65 = dateTimeFieldType64.getName();
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone67);
        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology68.dayOfWeek();
        org.joda.time.Partial partial70 = new org.joda.time.Partial(dateTimeFieldType64, (int) 'a', (org.joda.time.Chronology) gregorianChronology68);
        int[] intArray74 = new int[] { 1, 1, 3 };
        int int75 = offsetDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) partial70, intArray74);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray76 = partial70.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.DateTime dateTime78 = partial70.toDateTime(readableInstant77);
        org.joda.time.DateTime dateTime79 = partial48.toDateTime(readableInstant77);
        boolean boolean80 = readableInterval31.isAfter(readableInstant77);
        org.joda.time.Period period81 = readableInterval31.toPeriod();
        org.joda.time.DateTime dateTime82 = readableInterval31.getEnd();
        boolean boolean83 = interval28.contains((org.joda.time.ReadableInstant) dateTime82);
        boolean boolean84 = cachedDateTimeZone10.equals((java.lang.Object) dateTime82);
        int int86 = cachedDateTimeZone10.getStandardOffset((-23241599997L));
        java.lang.String str87 = cachedDateTimeZone10.getID();
        long long89 = cachedDateTimeZone10.previousTransition(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(readableInterval14);
// flaky "4) test1020(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str15 + "' != '" + "2026-11-18T03:19:56.575-08:00/2026-11-18T03:19:56.575-08:00" + "'", str15, "2026-11-18T03:19:56.575-08:00/2026-11-18T03:19:56.575-08:00");
        org.junit.Assert.assertNotNull(readableInterval17);
// flaky "4) test1020(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str18 + "' != '" + "2026-11-18T03:19:56.575-08:00/2026-11-18T03:19:56.575-08:00" + "'", str18, "2026-11-18T03:19:56.575-08:00/2026-11-18T03:19:56.575-08:00");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(interval20);
        org.junit.Assert.assertNotNull(readableInterval22);
// flaky "2) test1020(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str23 + "' != '" + "2026-11-18T03:19:56.575-08:00/2026-11-18T03:19:56.575-08:00" + "'", str23, "2026-11-18T03:19:56.575-08:00/2026-11-18T03:19:56.575-08:00");
        org.junit.Assert.assertNotNull(readableInterval25);
// flaky "2) test1020(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str26 + "' != '" + "2026-11-18T03:19:56.575-08:00/2026-11-18T03:19:56.575-08:00" + "'", str26, "2026-11-18T03:19:56.575-08:00/2026-11-18T03:19:56.575-08:00");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(interval28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(readableInterval31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "minuteOfDay" + "'", str34, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 97 + "'", int41 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "minuteOfDay" + "'", str43, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 97 + "'", int50 == 97);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertArrayEquals(intArray53, new int[] { 960 });
        org.junit.Assert.assertNotNull(chronology54);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertEquals("'" + str59 + "' != '" + "DateTimeField[dayOfYear]" + "'", str59, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertEquals("'" + str65 + "' != '" + "minuteOfDay" + "'", str65, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertArrayEquals(intArray74, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2 + "'", int75 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray76);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(period81);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-28800000) + "'", int86 == (-28800000));
        org.junit.Assert.assertEquals("'" + str87 + "' != '" + "America/Los_Angeles" + "'", str87, "America/Los_Angeles");
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-5756400001L) + "'", long89 == (-5756400001L));
    }

    @Test
    public void test1021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1021");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("32", "years", 100, (-591758));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long7 = fixedDateTimeZone4.previousTransition((long) (byte) 0);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertEquals(timeZone5.getDisplayName(), "GMT+00:00");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test1022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1022");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str1 = dateTimeFieldType0.getName();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfWeek();
        org.joda.time.Partial partial6 = new org.joda.time.Partial(dateTimeFieldType0, (int) 'a', (org.joda.time.Chronology) gregorianChronology4);
        int int8 = partial6.getValue(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str11 = dateTimeFieldType10.getName();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfWeek();
        org.joda.time.Partial partial16 = new org.joda.time.Partial(dateTimeFieldType10, (int) 'a', (org.joda.time.Chronology) gregorianChronology14);
        int int18 = partial16.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str20 = dateTimeFieldType19.getName();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.dayOfWeek();
        org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldType19, (int) 'a', (org.joda.time.Chronology) gregorianChronology23);
        int int27 = partial25.getValue(0);
        boolean boolean28 = partial16.isEqual((org.joda.time.ReadablePartial) partial25);
        int[] intArray30 = gregorianChronology9.get((org.joda.time.ReadablePartial) partial25, (long) (byte) 100);
        org.joda.time.Chronology chronology31 = partial25.getChronology();
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTimeField dateTimeField35 = chronology34.dayOfYear();
        java.lang.String str36 = dateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, dateTimeFieldType37, 1);
        int int40 = offsetDateTimeField39.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str42 = dateTimeFieldType41.getName();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.dayOfWeek();
        org.joda.time.Partial partial47 = new org.joda.time.Partial(dateTimeFieldType41, (int) 'a', (org.joda.time.Chronology) gregorianChronology45);
        int[] intArray51 = new int[] { 1, 1, 3 };
        int int52 = offsetDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) partial47, intArray51);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray53 = partial47.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.DateTime dateTime55 = partial47.toDateTime(readableInstant54);
        org.joda.time.DateTime dateTime56 = partial25.toDateTime(readableInstant54);
        int int57 = partial6.compareTo((org.joda.time.ReadablePartial) partial25);
        org.joda.time.Chronology chronology58 = partial25.getChronology();
        org.joda.time.DurationField durationField59 = chronology58.seconds();
        org.joda.time.DurationFieldType durationFieldType60 = org.joda.time.DurationFieldType.weekyears();
        java.lang.String str61 = durationFieldType60.toString();
        org.joda.time.field.ScaledDurationField scaledDurationField63 = new org.joda.time.field.ScaledDurationField(durationField59, durationFieldType60, 53);
        long long65 = scaledDurationField63.getMillis(3);
        long long67 = scaledDurationField63.getMillis(0);
        long long70 = scaledDurationField63.add(2005796786760000L, 550);
        long long73 = scaledDurationField63.add((-210918355622000L), (long) 100);
        org.junit.Assert.assertNotNull(dateTimeFieldType0);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "minuteOfDay" + "'", str1, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "minuteOfDay" + "'", str11, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "minuteOfDay" + "'", str20, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertArrayEquals(intArray30, new int[] { 960 });
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "DateTimeField[dayOfYear]" + "'", str36, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "minuteOfDay" + "'", str42, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertArrayEquals(intArray51, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + "weekyears" + "'", str61, "weekyears");
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 159000L + "'", long65 == 159000L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2005796815910000L + "'", long70 == 2005796815910000L);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-210918350322000L) + "'", long73 == (-210918350322000L));
    }

    @Test
    public void test1023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1023");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        java.lang.String str4 = dateTimeField3.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType5, 1);
        java.lang.String str8 = offsetDateTimeField7.getName();
        boolean boolean10 = offsetDateTimeField7.isLeap((long) (byte) 0);
        long long12 = offsetDateTimeField7.roundHalfFloor(10L);
        java.lang.String str14 = offsetDateTimeField7.getAsText((long) (short) 1);
        boolean boolean16 = offsetDateTimeField7.isLeap((long) (short) 1);
        int int19 = offsetDateTimeField7.getDifference((long) 97, (-30758399903L));
        long long22 = offsetDateTimeField7.add((-10000L), (long) (short) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = org.joda.time.DateTimeFieldType.yearOfCentury();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType23, (int) 'a');
        long long28 = dividedDateTimeField25.getDifferenceAsLong((-57600L), 11234274912000L);
        int int29 = dividedDateTimeField25.getMaximumValue();
        long long32 = dividedDateTimeField25.addWrapField((-2488320000420560L), 11);
        java.lang.String str33 = dividedDateTimeField25.getName();
        java.util.Locale locale34 = null;
        int int35 = dividedDateTimeField25.getMaximumShortTextLength(locale34);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "DateTimeField[dayOfYear]" + "'", str4, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "dayOfYear" + "'", str8, "dayOfYear");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "366" + "'", str14, "366");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 356 + "'", int19 == 356);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-10000L) + "'", long22 == (-10000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1340L) + "'", long28 == (-1340L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2488328381220560L) + "'", long32 == (-2488328381220560L));
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "yearOfCentury" + "'", str33, "yearOfCentury");
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test1024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1024");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        java.lang.String str4 = dateTimeField3.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType5, 1);
        java.lang.String str8 = offsetDateTimeField7.getName();
        int int9 = offsetDateTimeField7.getMinimumValue();
        long long11 = offsetDateTimeField7.roundHalfCeiling((-1L));
        org.joda.time.DurationField durationField12 = offsetDateTimeField7.getDurationField();
        long long14 = offsetDateTimeField7.roundHalfEven((long) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str16 = dateTimeFieldType15.getName();
        java.lang.String str17 = dateTimeFieldType15.toString();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType15, 32);
        long long21 = remainderDateTimeField19.roundHalfFloor((-51780000L));
        org.joda.time.DurationField durationField22 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long24 = durationField22.getMillis((-210866760000000L));
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = org.joda.time.DateTimeFieldType.weekyearOfCentury();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (-210866673600000L), "2");
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.dayOfWeek();
        org.joda.time.DurationField durationField32 = gregorianChronology30.days();
        org.joda.time.DurationField durationField33 = gregorianChronology30.halfdays();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology30.secondOfMinute();
        org.joda.time.DurationField durationField35 = gregorianChronology30.halfdays();
        org.joda.time.DurationField durationField36 = gregorianChronology30.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField36);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, durationField22, dateTimeFieldType25);
        // The following exception was thrown during execution in test generation
        try {
            org.joda.time.Partial partial40 = new org.joda.time.Partial(dateTimeFieldType25, (-64081));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -64081 for weekyearOfCentury must not be smaller than 0");
        } catch (org.joda.time.IllegalFieldValueException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "DateTimeField[dayOfYear]" + "'", str4, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "dayOfYear" + "'", str8, "dayOfYear");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800000L + "'", long14 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "minuteOfDay" + "'", str16, "minuteOfDay");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "minuteOfDay" + "'", str17, "minuteOfDay");
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-57600000L) + "'", long21 == (-57600000L));
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-210866760000000L) + "'", long24 == (-210866760000000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
    }

    @Test
    public void test1025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1025");
        org.joda.time.DurationFieldType durationFieldType0 = org.joda.time.DurationFieldType.months();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.DurationField durationField5 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField7 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField10 = durationFieldType0.getField((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.field.PreciseDurationField preciseDurationField12 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 3023999999L);
        boolean boolean13 = preciseDurationField12.isPrecise();
        long long16 = preciseDurationField12.getMillis(96, (long) (-61));
        org.junit.Assert.assertNotNull(durationFieldType0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 290303999904L + "'", long16 == 290303999904L);
    }

    @Test
    public void test1026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1026");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology1.days();
        org.joda.time.DurationField durationField4 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField6 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField9 = gregorianChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.DurationField durationField13 = gregorianChronology11.days();
        org.joda.time.DurationField durationField14 = gregorianChronology11.halfdays();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone15);
        long long23 = zonedChronology18.getDateTimeMillis(366, 3, (int) (byte) 10, 356);
        java.lang.String str24 = zonedChronology18.toString();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology18.year();
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology18.halfdayOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str29 = dateTimeFieldType28.getName();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.dayOfWeek();
        org.joda.time.Partial partial34 = new org.joda.time.Partial(dateTimeFieldType28, (int) 'a', (org.joda.time.Chronology) gregorianChronology32);
        int int36 = partial34.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str38 = dateTimeFieldType37.getName();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.dayOfWeek();
        org.joda.time.Partial partial43 = new org.joda.time.Partial(dateTimeFieldType37, (int) 'a', (org.joda.time.Chronology) gregorianChronology41);
        int int45 = partial43.getValue(0);
        boolean boolean46 = partial34.isEqual((org.joda.time.ReadablePartial) partial43);
        int[] intArray48 = gregorianChronology27.get((org.joda.time.ReadablePartial) partial43, (long) (byte) 100);
        int[] intArray52 = new int[] { (-28378000), 24 };
        // The following exception was thrown during execution in test generation
        try {
            int[] intArray54 = dateTimeField26.addWrapField((org.joda.time.ReadablePartial) partial43, (-51720), intArray52, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index -51720 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-50611450021644L) + "'", long23 == (-50611450021644L));
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str24, "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "minuteOfDay" + "'", str29, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 97 + "'", int36 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "minuteOfDay" + "'", str38, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 97 + "'", int45 == 97);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertArrayEquals(intArray48, new int[] { 960 });
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertArrayEquals(intArray52, new int[] { (-28378000), 24 });
    }

    @Test
    public void test1027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology1.days();
        org.joda.time.DurationField durationField4 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField6 = gregorianChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.dayOfMonth();
        org.joda.time.DurationField durationField9 = gregorianChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.DurationField durationField13 = gregorianChronology11.days();
        org.joda.time.DurationField durationField14 = gregorianChronology11.halfdays();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone15);
        long long23 = zonedChronology18.getDateTimeMillis(366, 3, (int) (byte) 10, 356);
        org.joda.time.DateTimeZone dateTimeZone24 = zonedChronology18.getZone();
        org.joda.time.DurationField durationField25 = zonedChronology18.centuries();
        org.joda.time.DateTimeZone dateTimeZone26 = zonedChronology18.getZone();
        org.joda.time.DurationField durationField27 = zonedChronology18.halfdays();
        org.joda.time.DurationField durationField28 = zonedChronology18.hours();
        // The following exception was thrown during execution in test generation
        try {
            long long36 = zonedChronology18.getDateTimeMillis(1, (int) (short) 0, 5259463, 328, (-18), 107298, (-843524167));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 328 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-50611450021644L) + "'", long23 == (-50611450021644L));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test1028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1028");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = chronology2.dayOfYear();
        java.lang.String str4 = dateTimeField3.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType5, 1);
        java.lang.String str8 = offsetDateTimeField7.getName();
        boolean boolean10 = offsetDateTimeField7.isLeap((long) (byte) 0);
        long long12 = offsetDateTimeField7.roundHalfFloor(10L);
        java.lang.String str14 = offsetDateTimeField7.getAsText((long) (short) 1);
        boolean boolean16 = offsetDateTimeField7.isLeap((long) (short) 1);
        int int19 = offsetDateTimeField7.getDifference((long) 97, (-30758399903L));
        long long22 = offsetDateTimeField7.add((-10000L), (long) (short) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = org.joda.time.DateTimeFieldType.yearOfCentury();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType23, (int) 'a');
        long long28 = dividedDateTimeField25.getDifferenceAsLong((-57600L), 11234274912000L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25);
        long long31 = remainderDateTimeField29.remainder(1795115891845L);
        long long34 = remainderDateTimeField29.set((-51780000L), 0);
        long long37 = remainderDateTimeField29.set(7380338137200000L, (int) (byte) 10);
        int int39 = remainderDateTimeField29.getMaximumValue((long) 11);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "DateTimeField[dayOfYear]" + "'", str4, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "dayOfYear" + "'", str8, "dayOfYear");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "366" + "'", str14, "366");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 356 + "'", int19 == 356);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-10000L) + "'", long22 == (-10000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1340L) + "'", long28 == (-1340L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 40691845L + "'", long31 == 40691845L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-6535380000L) + "'", long34 == (-6535380000L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 7380336495600000L + "'", long37 == 7380336495600000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 96 + "'", int39 == 96);
    }

    @Test
    public void test1029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1029");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 100.0d, (java.lang.Number) 2, (java.lang.Number) 1.0d);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number9 = illegalFieldValueException4.getUpperBound();
        java.lang.String str10 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + number6 + "' != '" + 1.0d + "'", number6, 1.0d);
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertEquals("'" + number9 + "' != '" + 1.0d + "'", number9, 1.0d);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test1030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1030");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        java.lang.String str2 = readableInterval1.toString();
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        java.lang.String str5 = readableInterval4.toString();
        boolean boolean6 = readableInterval1.contains(readableInterval4);
        org.joda.time.Interval interval7 = readableInterval4.toInterval();
        org.joda.time.ReadableInterval readableInterval8 = null;
        boolean boolean9 = readableInterval4.isAfter(readableInterval8);
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        java.lang.String str12 = readableInterval11.toString();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.ReadableInterval readableInterval14 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval13);
        java.lang.String str15 = readableInterval14.toString();
        boolean boolean16 = readableInterval11.contains(readableInterval14);
        org.joda.time.Interval interval17 = readableInterval14.toInterval();
        org.joda.time.ReadableInterval readableInterval18 = null;
        boolean boolean19 = readableInterval14.isAfter(readableInterval18);
        org.joda.time.ReadableInterval readableInterval20 = null;
        org.joda.time.ReadableInterval readableInterval21 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval20);
        java.lang.String str22 = readableInterval21.toString();
        org.joda.time.ReadableInstant readableInstant23 = null;
        boolean boolean24 = readableInterval21.isBefore(readableInstant23);
        org.joda.time.PeriodType periodType25 = null;
        org.joda.time.PeriodType periodType26 = org.joda.time.DateTimeUtils.getPeriodType(periodType25);
        org.joda.time.Period period27 = readableInterval21.toPeriod(periodType25);
        boolean boolean28 = readableInterval14.isAfter(readableInterval21);
        boolean boolean29 = readableInterval4.isBefore(readableInterval21);
        org.junit.Assert.assertNotNull(readableInterval1);
// flaky "5) test1030(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str2 + "' != '" + "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00" + "'", str2, "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00");
        org.junit.Assert.assertNotNull(readableInterval4);
// flaky "5) test1030(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str5 + "' != '" + "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00" + "'", str5, "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(readableInterval11);
// flaky "3) test1030(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str12 + "' != '" + "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00" + "'", str12, "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00");
        org.junit.Assert.assertNotNull(readableInterval14);
// flaky "3) test1030(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str15 + "' != '" + "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00" + "'", str15, "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(interval17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(readableInterval21);
// flaky "2) test1030(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str22 + "' != '" + "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00" + "'", str22, "2026-11-18T03:19:57.122-08:00/2026-11-18T03:19:57.122-08:00");
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test1031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1031");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str4 = dateTimeFieldType3.getName();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.dayOfWeek();
        org.joda.time.Partial partial9 = new org.joda.time.Partial(dateTimeFieldType3, (int) 'a', (org.joda.time.Chronology) gregorianChronology7);
        int int11 = partial9.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str13 = dateTimeFieldType12.getName();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.dayOfWeek();
        org.joda.time.Partial partial18 = new org.joda.time.Partial(dateTimeFieldType12, (int) 'a', (org.joda.time.Chronology) gregorianChronology16);
        int int20 = partial18.getValue(0);
        boolean boolean21 = partial9.isEqual((org.joda.time.ReadablePartial) partial18);
        int[] intArray23 = gregorianChronology2.get((org.joda.time.ReadablePartial) partial18, (long) (byte) 100);
        org.joda.time.Chronology chronology24 = partial18.getChronology();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant25, readableInstant26);
        org.joda.time.DateTimeField dateTimeField28 = chronology27.dayOfYear();
        java.lang.String str29 = dateTimeField28.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType30, 1);
        int int33 = offsetDateTimeField32.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str35 = dateTimeFieldType34.getName();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.dayOfWeek();
        org.joda.time.Partial partial40 = new org.joda.time.Partial(dateTimeFieldType34, (int) 'a', (org.joda.time.Chronology) gregorianChronology38);
        int[] intArray44 = new int[] { 1, 1, 3 };
        int int45 = offsetDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) partial40, intArray44);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray46 = partial40.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.DateTime dateTime48 = partial40.toDateTime(readableInstant47);
        org.joda.time.DateTime dateTime49 = partial18.toDateTime(readableInstant47);
        boolean boolean50 = readableInterval1.isAfter(readableInstant47);
        org.joda.time.ReadableInterval readableInterval51 = null;
        org.joda.time.ReadableInterval readableInterval52 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval51);
        java.lang.String str53 = readableInterval52.toString();
        org.joda.time.ReadableInterval readableInterval54 = null;
        org.joda.time.ReadableInterval readableInterval55 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval54);
        java.lang.String str56 = readableInterval55.toString();
        boolean boolean57 = readableInterval52.contains(readableInterval55);
        org.joda.time.Interval interval58 = readableInterval55.toInterval();
        org.joda.time.ReadableInterval readableInterval59 = null;
        boolean boolean60 = readableInterval55.isAfter(readableInterval59);
        org.joda.time.ReadableInterval readableInterval61 = null;
        org.joda.time.ReadableInterval readableInterval62 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval61);
        java.lang.String str63 = readableInterval62.toString();
        org.joda.time.ReadableInstant readableInstant64 = null;
        boolean boolean65 = readableInterval62.isBefore(readableInstant64);
        org.joda.time.PeriodType periodType66 = null;
        org.joda.time.PeriodType periodType67 = org.joda.time.DateTimeUtils.getPeriodType(periodType66);
        org.joda.time.Period period68 = readableInterval62.toPeriod(periodType66);
        boolean boolean69 = readableInterval55.isAfter(readableInterval62);
        org.joda.time.DateTime dateTime70 = readableInterval62.getStart();
        boolean boolean71 = readableInterval1.isAfter((org.joda.time.ReadableInstant) dateTime70);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFieldType3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "minuteOfDay" + "'", str4, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "minuteOfDay" + "'", str13, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertArrayEquals(intArray23, new int[] { 960 });
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "DateTimeField[dayOfYear]" + "'", str29, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "minuteOfDay" + "'", str35, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertArrayEquals(intArray44, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(readableInterval52);
// flaky "6) test1031(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str53 + "' != '" + "2026-11-18T03:19:57.240-08:00/2026-11-18T03:19:57.240-08:00" + "'", str53, "2026-11-18T03:19:57.240-08:00/2026-11-18T03:19:57.240-08:00");
        org.junit.Assert.assertNotNull(readableInterval55);
// flaky "6) test1031(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str56 + "' != '" + "2026-11-18T03:19:57.240-08:00/2026-11-18T03:19:57.240-08:00" + "'", str56, "2026-11-18T03:19:57.240-08:00/2026-11-18T03:19:57.240-08:00");
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(interval58);
// flaky "2) test1031(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(readableInterval62);
// flaky "4) test1031(org.joda.time.field.RegressionTest2)":         org.junit.Assert.assertEquals("'" + str63 + "' != '" + "2026-11-18T03:19:57.240-08:00/2026-11-18T03:19:57.240-08:00" + "'", str63, "2026-11-18T03:19:57.240-08:00/2026-11-18T03:19:57.240-08:00");
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(periodType67);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test1032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1032");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (short) 0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = org.joda.time.DateTimeFieldType.weekyearOfCentury();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType4, (java.lang.Number) (-210866673600000L), "2");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DurationField durationField11 = gregorianChronology9.days();
        org.joda.time.DurationField durationField12 = gregorianChronology9.halfdays();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology9.secondOfMinute();
        org.joda.time.DurationField durationField14 = gregorianChronology9.halfdays();
        org.joda.time.DurationField durationField15 = gregorianChronology9.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField15);
        java.lang.String str17 = unsupportedDateTimeField16.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = unsupportedDateTimeField16.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType18);
        long long21 = zeroIsMaxDateTimeField19.roundHalfFloor(86400000L);
        int int23 = zeroIsMaxDateTimeField19.getLeapAmount(97L);
        boolean boolean25 = zeroIsMaxDateTimeField19.isLeap(101L);
        // The following exception was thrown during execution in test generation
        try {
            long long28 = zeroIsMaxDateTimeField19.set((-30758399999L), 25162);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 25162 for weekyearOfCentury must be in the range [1,1440]");
        } catch (org.joda.time.IllegalFieldValueException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "UnsupportedDateTimeField" + "'", str17, "UnsupportedDateTimeField");
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 86400000L + "'", long21 == 86400000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test1033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1033");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = org.joda.time.DateTimeFieldType.secondOfMinute();
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) 28900000L, number3);
        org.joda.time.DurationFieldType durationFieldType5 = org.joda.time.DurationFieldType.months();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.dayOfWeek();
        org.joda.time.DurationField durationField9 = gregorianChronology7.days();
        org.joda.time.DurationField durationField10 = gregorianChronology7.halfdays();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.secondOfMinute();
        org.joda.time.DurationField durationField12 = gregorianChronology7.halfdays();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology7.clockhourOfHalfday();
        org.joda.time.DurationField durationField15 = durationFieldType5.getField((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.field.PreciseDurationField preciseDurationField17 = new org.joda.time.field.PreciseDurationField(durationFieldType5, 3023999999L);
        long long19 = preciseDurationField17.getMillis((int) (byte) -1);
        boolean boolean20 = preciseDurationField17.isPrecise();
        long long23 = preciseDurationField17.add((long) 2, 2);
        int int26 = preciseDurationField17.getDifference((-23241599644L), 31536000001L);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, (org.joda.time.DurationField) preciseDurationField17);
        java.lang.String str28 = unsupportedDateTimeField27.toString();
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant29, readableInstant30);
        org.joda.time.DateTimeField dateTimeField32 = chronology31.dayOfYear();
        java.lang.String str33 = dateTimeField32.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, dateTimeFieldType34, 1);
        java.lang.String str37 = offsetDateTimeField36.getName();
        boolean boolean39 = offsetDateTimeField36.isLeap((long) (byte) 0);
        long long41 = offsetDateTimeField36.roundHalfFloor(10L);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.Chronology chronology44 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant42, readableInstant43);
        org.joda.time.DateTimeField dateTimeField45 = chronology44.dayOfYear();
        java.lang.String str46 = dateTimeField45.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, dateTimeFieldType47, 1);
        int int50 = offsetDateTimeField49.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str52 = dateTimeFieldType51.getName();
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone54);
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.dayOfWeek();
        org.joda.time.Partial partial57 = new org.joda.time.Partial(dateTimeFieldType51, (int) 'a', (org.joda.time.Chronology) gregorianChronology55);
        int[] intArray61 = new int[] { 1, 1, 3 };
        int int62 = offsetDateTimeField49.getMinimumValue((org.joda.time.ReadablePartial) partial57, intArray61);
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant63, readableInstant64);
        org.joda.time.DateTimeField dateTimeField66 = chronology65.dayOfYear();
        java.lang.String str67 = dateTimeField66.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType68, 1);
        int int71 = offsetDateTimeField70.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str73 = dateTimeFieldType72.getName();
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone75);
        org.joda.time.DateTimeField dateTimeField77 = gregorianChronology76.dayOfWeek();
        org.joda.time.Partial partial78 = new org.joda.time.Partial(dateTimeFieldType72, (int) 'a', (org.joda.time.Chronology) gregorianChronology76);
        int[] intArray82 = new int[] { 1, 1, 3 };
        int int83 = offsetDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) partial78, intArray82);
        int int84 = offsetDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) partial57, intArray82);
        // The following exception was thrown during execution in test generation
        try {
            int int85 = unsupportedDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) partial57);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfMinute field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTimeFieldType0);
        org.junit.Assert.assertNotNull(durationFieldType5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3023999999L) + "'", long19 == (-3023999999L));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 6048000000L + "'", long23 == 6048000000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-18) + "'", int26 == (-18));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "UnsupportedDateTimeField" + "'", str28, "UnsupportedDateTimeField");
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "DateTimeField[dayOfYear]" + "'", str33, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "dayOfYear" + "'", str37, "dayOfYear");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28800000L + "'", long41 == 28800000L);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "DateTimeField[dayOfYear]" + "'", str46, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertEquals("'" + str52 + "' != '" + "minuteOfDay" + "'", str52, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertArrayEquals(intArray61, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertEquals("'" + str67 + "' != '" + "DateTimeField[dayOfYear]" + "'", str67, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2 + "'", int71 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertEquals("'" + str73 + "' != '" + "minuteOfDay" + "'", str73, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertArrayEquals(intArray82, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 2 + "'", int83 == 2);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 367 + "'", int84 == 367);
    }

    @Test
    public void test1034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1034");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str1 = dateTimeFieldType0.getName();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.dayOfWeek();
        org.joda.time.Partial partial6 = new org.joda.time.Partial(dateTimeFieldType0, (int) 'a', (org.joda.time.Chronology) gregorianChronology4);
        int int8 = partial6.getValue(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str11 = dateTimeFieldType10.getName();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.dayOfWeek();
        org.joda.time.Partial partial16 = new org.joda.time.Partial(dateTimeFieldType10, (int) 'a', (org.joda.time.Chronology) gregorianChronology14);
        int int18 = partial16.getValue(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str20 = dateTimeFieldType19.getName();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.dayOfWeek();
        org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldType19, (int) 'a', (org.joda.time.Chronology) gregorianChronology23);
        int int27 = partial25.getValue(0);
        boolean boolean28 = partial16.isEqual((org.joda.time.ReadablePartial) partial25);
        int[] intArray30 = gregorianChronology9.get((org.joda.time.ReadablePartial) partial25, (long) (byte) 100);
        org.joda.time.Chronology chronology31 = partial25.getChronology();
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTimeField dateTimeField35 = chronology34.dayOfYear();
        java.lang.String str36 = dateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = org.joda.time.DateTimeFieldType.dayOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, dateTimeFieldType37, 1);
        int int40 = offsetDateTimeField39.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = org.joda.time.DateTimeFieldType.minuteOfDay();
        java.lang.String str42 = dateTimeFieldType41.getName();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.dayOfWeek();
        org.joda.time.Partial partial47 = new org.joda.time.Partial(dateTimeFieldType41, (int) 'a', (org.joda.time.Chronology) gregorianChronology45);
        int[] intArray51 = new int[] { 1, 1, 3 };
        int int52 = offsetDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) partial47, intArray51);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray53 = partial47.getFieldTypes();
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.DateTime dateTime55 = partial47.toDateTime(readableInstant54);
        org.joda.time.DateTime dateTime56 = partial25.toDateTime(readableInstant54);
        int int57 = partial6.compareTo((org.joda.time.ReadablePartial) partial25);
        org.joda.time.Chronology chronology58 = partial25.getChronology();
        org.joda.time.DurationField durationField59 = chronology58.seconds();
        org.joda.time.DurationFieldType durationFieldType60 = org.joda.time.DurationFieldType.weekyears();
        java.lang.String str61 = durationFieldType60.toString();
        org.joda.time.field.ScaledDurationField scaledDurationField63 = new org.joda.time.field.ScaledDurationField(durationField59, durationFieldType60, 53);
        long long64 = scaledDurationField63.getUnitMillis();
        int int66 = scaledDurationField63.getValue((-86399900L));
        long long68 = scaledDurationField63.getMillis((-51779997L));
        long long71 = scaledDurationField63.getMillis((-66), (long) (-51720));
        long long73 = scaledDurationField63.getValueAsLong((long) (-24));
        long long76 = scaledDurationField63.getMillis(0, (-2005338887290027000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType0);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "minuteOfDay" + "'", str1, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "minuteOfDay" + "'", str11, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "minuteOfDay" + "'", str20, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertArrayEquals(intArray30, new int[] { 960 });
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "DateTimeField[dayOfYear]" + "'", str36, "DateTimeField[dayOfYear]");
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "minuteOfDay" + "'", str42, "minuteOfDay");
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertArrayEquals(intArray51, new int[] { 1, 1, 3 });
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + "weekyears" + "'", str61, "weekyears");
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 53000L + "'", long64 == 53000L);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1630) + "'", int66 == (-1630));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-2744339841000L) + "'", long68 == (-2744339841000L));
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-3498000L) + "'", long71 == (-3498000L));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
    }

    @Test
    public void test1035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1035");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = org.joda.time.DateTimeFieldType.weekyear();
        org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldType0, 50897150);
        org.junit.Assert.assertNotNull(dateTimeFieldType0);
    }
}
