package com.fasterxml.jackson.core.json;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1501");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter1 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = defaultPrettyPrinter1.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter4 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter6 = lf2SpacesIndenter4.withLinefeed("");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter7 = defaultPrettyPrinter2.withObjectIndenter((com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter) lf2SpacesIndenter4);
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory8.copy();
        java.lang.String str10 = jsonFactory9.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler11 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext14 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler11, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream16 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer18 = null;
        byte[] byteArray19 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser23 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext14, (int) (short) -1, inputStream16, objectCodec17, bytesToNameCanonicalizer18, byteArray19, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version24 = uTF8StreamJsonParser23.version();
        com.fasterxml.jackson.core.JsonToken jsonToken25 = uTF8StreamJsonParser23.getLastClearedToken();
        java.io.Writer writer26 = java.io.Writer.nullWriter();
        int int27 = uTF8StreamJsonParser23.releaseBuffered(writer26);
        boolean boolean28 = uTF8StreamJsonParser23.hasCurrentToken();
        boolean boolean29 = uTF8StreamJsonParser23._tokenIncomplete;
        java.lang.String str30 = uTF8StreamJsonParser23.getCurrentName();
        int int32 = uTF8StreamJsonParser23._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder33 = uTF8StreamJsonParser23._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding34 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator35 = jsonFactory9.createJsonGenerator((java.io.OutputStream) byteArrayBuilder33, jsonEncoding34);
        jsonGenerator35.writeStringField("UTF-16LE", "/");
        jsonGenerator35.writeBooleanField("JSON", false);
        defaultPrettyPrinter7.writeObjectEntrySeparator(jsonGenerator35);
        java.math.BigDecimal bigDecimal44 = null;
        jsonGenerator35.writeNumberField("UTF-16LE", bigDecimal44);
        jsonGenerator35.writeRaw('#');
        com.fasterxml.jackson.core.JsonFactory jsonFactory48 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory.Feature feature49 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory51 = jsonFactory48.configure(feature49, true);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator52 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory53 = jsonFactory51.setInputDecorator(inputDecorator52);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature54 = com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET;
        int int55 = feature54.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory57 = jsonFactory51.configure(feature54, false);
        boolean boolean58 = jsonGenerator35.isEnabled(feature54);
        com.fasterxml.jackson.core.JsonParser jsonParser59 = null;
        // The following exception was thrown during execution in test generation
        try {
            jsonGenerator35.copyCurrentEvent(jsonParser59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(defaultPrettyPrinter2);
        org.junit.Assert.assertNotNull(lf2SpacesIndenter6);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter7);
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + " " + "'", str10, " ");
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version24);
        org.junit.Assert.assertNull(jsonToken25);
        org.junit.Assert.assertNotNull(writer26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder33);
        org.junit.Assert.assertTrue("'" + jsonEncoding34 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding34.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator35);
        org.junit.Assert.assertTrue("'" + feature49 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature49.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory51);
        org.junit.Assert.assertNotNull(jsonFactory53);
        org.junit.Assert.assertTrue("'" + feature54 + "' != '" + com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET + "'", feature54.equals(com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(jsonFactory57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test1502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1502");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding4 = iOContext3.getEncoding();
        java.lang.Object obj5 = iOContext3.getSourceReference();
        java.io.InputStream inputStream7 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec8 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer9 = null;
        byte[] byteArray10 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser14 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, 2000, inputStream7, objectCodec8, bytesToNameCanonicalizer9, byteArray10, 0, (int) ' ', false);
        java.lang.Object obj15 = iOContext3.getSourceReference();
        java.lang.Object obj16 = iOContext3.getSourceReference();
        java.lang.Object obj17 = iOContext3.getSourceReference();
        org.junit.Assert.assertNull(jsonEncoding4);
        org.junit.Assert.assertEquals("'" + obj5 + "' != '" + ' ' + "'", obj5, ' ');
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertEquals("'" + obj15 + "' != '" + ' ' + "'", obj15, ' ');
        org.junit.Assert.assertEquals("'" + obj16 + "' != '" + ' ' + "'", obj16, ' ');
        org.junit.Assert.assertEquals("'" + obj17 + "' != '" + ' ' + "'", obj17, ' ');
    }

    @Test
    public void test1503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1503");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter1 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = defaultPrettyPrinter1.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory5 = jsonFactory4.copy();
        java.lang.String str6 = jsonFactory5.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler7 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext10 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler7, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream12 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer14 = null;
        byte[] byteArray15 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser19 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext10, (int) (short) -1, inputStream12, objectCodec13, bytesToNameCanonicalizer14, byteArray15, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version20 = uTF8StreamJsonParser19.version();
        com.fasterxml.jackson.core.JsonToken jsonToken21 = uTF8StreamJsonParser19.getLastClearedToken();
        java.io.Writer writer22 = java.io.Writer.nullWriter();
        int int23 = uTF8StreamJsonParser19.releaseBuffered(writer22);
        boolean boolean24 = uTF8StreamJsonParser19.hasCurrentToken();
        boolean boolean25 = uTF8StreamJsonParser19._tokenIncomplete;
        java.lang.String str26 = uTF8StreamJsonParser19.getCurrentName();
        int int28 = uTF8StreamJsonParser19._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder29 = uTF8StreamJsonParser19._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding30 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator31 = jsonFactory5.createJsonGenerator((java.io.OutputStream) byteArrayBuilder29, jsonEncoding30);
        jsonGenerator31.writeNull();
        jsonGenerator31.writeFieldName("UTF-32BE");
        defaultPrettyPrinter2.writeStartObject(jsonGenerator31);
        com.fasterxml.jackson.core.JsonFactory jsonFactory36 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory37 = jsonFactory36.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler38 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext41 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler38, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream43 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec44 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer45 = null;
        byte[] byteArray46 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser50 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext41, (int) (short) -1, inputStream43, objectCodec44, bytesToNameCanonicalizer45, byteArray46, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version51 = uTF8StreamJsonParser50.version();
        com.fasterxml.jackson.core.JsonToken jsonToken52 = uTF8StreamJsonParser50.getLastClearedToken();
        java.io.Writer writer53 = java.io.Writer.nullWriter();
        int int54 = uTF8StreamJsonParser50.releaseBuffered(writer53);
        java.io.Writer writer56 = writer53.append((java.lang.CharSequence) "JSON");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator57 = jsonFactory36.createGenerator(writer56);
        com.fasterxml.jackson.core.JsonStreamContext jsonStreamContext58 = jsonGenerator57.getOutputContext();
        jsonGenerator57.writeStartObject();
        defaultPrettyPrinter2.writeArrayValueSeparator(jsonGenerator57);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler61 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext64 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler61, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream66 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec67 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer68 = null;
        byte[] byteArray69 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser73 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext64, (int) (short) -1, inputStream66, objectCodec67, bytesToNameCanonicalizer68, byteArray69, (int) (short) -1, (int) (byte) 0, false);
        boolean boolean74 = uTF8StreamJsonParser73.canReadTypeId();
        com.fasterxml.jackson.core.JsonParser.Feature feature75 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        com.fasterxml.jackson.core.JsonParser jsonParser76 = uTF8StreamJsonParser73.enable(feature75);
        // The following exception was thrown during execution in test generation
        try {
            jsonGenerator57.writeTypeId((java.lang.Object) feature75);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonGenerationException; message: No native support for writing Type Ids");
        } catch (com.fasterxml.jackson.core.JsonGenerationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(defaultPrettyPrinter2);
        org.junit.Assert.assertNotNull(jsonFactory5);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + " " + "'", str6, " ");
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertArrayEquals(byteArray15, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version20);
        org.junit.Assert.assertNull(jsonToken21);
        org.junit.Assert.assertNotNull(writer22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder29);
        org.junit.Assert.assertTrue("'" + jsonEncoding30 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding30.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator31);
        org.junit.Assert.assertNotNull(jsonFactory37);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertArrayEquals(byteArray46, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version51);
        org.junit.Assert.assertNull(jsonToken52);
        org.junit.Assert.assertNotNull(writer53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(writer56);
        org.junit.Assert.assertNotNull(jsonGenerator57);
        org.junit.Assert.assertNotNull(jsonStreamContext58);
        org.junit.Assert.assertNotNull(byteArray69);
        org.junit.Assert.assertArrayEquals(byteArray69, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + feature75 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature75.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertNotNull(jsonParser76);
    }

    @Test
    public void test1504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1504");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter1 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = defaultPrettyPrinter1.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        defaultPrettyPrinter3.spacesInObjectEntries(false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory7 = jsonFactory6.copy();
        java.lang.String str8 = jsonFactory7.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler9 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext12 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler9, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream14 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec15 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer16 = null;
        byte[] byteArray17 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser21 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext12, (int) (short) -1, inputStream14, objectCodec15, bytesToNameCanonicalizer16, byteArray17, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version22 = uTF8StreamJsonParser21.version();
        com.fasterxml.jackson.core.JsonToken jsonToken23 = uTF8StreamJsonParser21.getLastClearedToken();
        java.io.Writer writer24 = java.io.Writer.nullWriter();
        int int25 = uTF8StreamJsonParser21.releaseBuffered(writer24);
        boolean boolean26 = uTF8StreamJsonParser21.hasCurrentToken();
        boolean boolean27 = uTF8StreamJsonParser21._tokenIncomplete;
        java.lang.String str28 = uTF8StreamJsonParser21.getCurrentName();
        int int30 = uTF8StreamJsonParser21._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder31 = uTF8StreamJsonParser21._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding32 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator33 = jsonFactory7.createJsonGenerator((java.io.OutputStream) byteArrayBuilder31, jsonEncoding32);
        jsonGenerator33.writeStringField("UTF-16LE", "/");
        jsonGenerator33.writeNumber((double) (short) 10);
        defaultPrettyPrinter3.writeObjectFieldValueSeparator(jsonGenerator33);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator40 = jsonGenerator33.useDefaultPrettyPrinter();
        com.fasterxml.jackson.core.io.SerializedString serializedString42 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray43 = serializedString42.asUnquotedUTF8();
        com.fasterxml.jackson.core.JsonFactory jsonFactory44 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory45 = jsonFactory44.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler46 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext49 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler46, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding50 = iOContext49.getEncoding();
        java.lang.Object obj51 = iOContext49.getSourceReference();
        java.io.InputStream inputStream53 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec54 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer55 = null;
        byte[] byteArray56 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser60 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext49, 2000, inputStream53, objectCodec54, bytesToNameCanonicalizer55, byteArray56, 0, (int) ' ', false);
        com.fasterxml.jackson.core.JsonParser jsonParser61 = jsonFactory45.createParser(byteArray56);
        int int63 = serializedString42.appendQuotedUTF8(byteArray56, 97);
        char[] charArray64 = com.fasterxml.jackson.core.json.WriterBasedJsonGenerator.HEX_CHARS;
        int int66 = serializedString42.appendQuoted(charArray64, (int) (byte) 100);
        jsonGenerator40.writeFieldName((com.fasterxml.jackson.core.SerializableString) serializedString42);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter2);
        org.junit.Assert.assertNotNull(jsonFactory7);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + " " + "'", str8, " ");
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version22);
        org.junit.Assert.assertNull(jsonToken23);
        org.junit.Assert.assertNotNull(writer24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder31);
        org.junit.Assert.assertTrue("'" + jsonEncoding32 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding32.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator33);
        org.junit.Assert.assertNotNull(jsonGenerator40);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] {});
        org.junit.Assert.assertNotNull(jsonFactory45);
        org.junit.Assert.assertNull(jsonEncoding50);
        org.junit.Assert.assertEquals("'" + obj51 + "' != '" + ' ' + "'", obj51, ' ');
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertArrayEquals(byteArray56, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonParser61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(charArray64);
        org.junit.Assert.assertArrayEquals(charArray64, new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' });
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
    }

    @Test
    public void test1505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1505");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter1 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = defaultPrettyPrinter1.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter4 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.SerializableString serializableString5 = null;
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter6 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2, serializableString5);
        com.fasterxml.jackson.core.io.SerializedString serializedString8 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray9 = serializedString8.asUnquotedUTF8();
        com.fasterxml.jackson.core.JsonFactory jsonFactory10 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory10.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = jsonFactory11.setRootValueSeparator("ROOT");
        com.fasterxml.jackson.core.JsonParser.Feature feature14 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int15 = feature14.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory13.enable(feature14);
        com.fasterxml.jackson.core.JsonFactory.Feature feature17 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory16.disable(feature17);
        byte[] byteArray21 = new byte[] { (byte) 0, (byte) 0 };
        com.fasterxml.jackson.core.JsonParser jsonParser24 = jsonFactory16.createJsonParser(byteArray21, (int) (byte) -1, (int) (short) 0);
        int int26 = serializedString8.appendQuotedUTF8(byteArray21, 64);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter27 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2, (com.fasterxml.jackson.core.SerializableString) serializedString8);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler28 = null;
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter30 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter31 = defaultPrettyPrinter30.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter32 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter31);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter33 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter35 = lf2SpacesIndenter33.withLinefeed("");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter36 = defaultPrettyPrinter31.withObjectIndenter((com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter) lf2SpacesIndenter33);
        com.fasterxml.jackson.core.JsonFactory jsonFactory37 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory38 = jsonFactory37.copy();
        java.lang.String str39 = jsonFactory38.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler40 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext43 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler40, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream45 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec46 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer47 = null;
        byte[] byteArray48 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser52 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext43, (int) (short) -1, inputStream45, objectCodec46, bytesToNameCanonicalizer47, byteArray48, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version53 = uTF8StreamJsonParser52.version();
        com.fasterxml.jackson.core.JsonToken jsonToken54 = uTF8StreamJsonParser52.getLastClearedToken();
        java.io.Writer writer55 = java.io.Writer.nullWriter();
        int int56 = uTF8StreamJsonParser52.releaseBuffered(writer55);
        boolean boolean57 = uTF8StreamJsonParser52.hasCurrentToken();
        boolean boolean58 = uTF8StreamJsonParser52._tokenIncomplete;
        java.lang.String str59 = uTF8StreamJsonParser52.getCurrentName();
        int int61 = uTF8StreamJsonParser52._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder62 = uTF8StreamJsonParser52._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding63 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator64 = jsonFactory38.createJsonGenerator((java.io.OutputStream) byteArrayBuilder62, jsonEncoding63);
        jsonGenerator64.writeStringField("UTF-16LE", "/");
        com.fasterxml.jackson.core.io.SerializedString serializedString69 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray70 = serializedString69.asUnquotedUTF8();
        com.fasterxml.jackson.core.JsonFactory jsonFactory71 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory72 = jsonFactory71.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory74 = jsonFactory72.setRootValueSeparator("ROOT");
        com.fasterxml.jackson.core.JsonParser.Feature feature75 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int76 = feature75.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory77 = jsonFactory74.enable(feature75);
        com.fasterxml.jackson.core.JsonFactory.Feature feature78 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory79 = jsonFactory77.disable(feature78);
        byte[] byteArray82 = new byte[] { (byte) 0, (byte) 0 };
        com.fasterxml.jackson.core.JsonParser jsonParser85 = jsonFactory77.createJsonParser(byteArray82, (int) (byte) -1, (int) (short) 0);
        int int87 = serializedString69.appendQuotedUTF8(byteArray82, 64);
        java.lang.String str88 = serializedString69.getValue();
        jsonGenerator64.writeString((com.fasterxml.jackson.core.SerializableString) serializedString69);
        defaultPrettyPrinter36.writeStartObject(jsonGenerator64);
        com.fasterxml.jackson.core.io.IOContext iOContext92 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler28, (java.lang.Object) jsonGenerator64, true);
        jsonGenerator64.writeNumber(0.0d);
        jsonGenerator64.writeBooleanField("/", true);
        defaultPrettyPrinter2.writeObjectFieldValueSeparator(jsonGenerator64);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter2);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertNotNull(jsonFactory13);
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature14.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertTrue("'" + feature17 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature17.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(jsonParser24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(defaultPrettyPrinter31);
        org.junit.Assert.assertNotNull(lf2SpacesIndenter35);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter36);
        org.junit.Assert.assertNotNull(jsonFactory38);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + " " + "'", str39, " ");
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertArrayEquals(byteArray48, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version53);
        org.junit.Assert.assertNull(jsonToken54);
        org.junit.Assert.assertNotNull(writer55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder62);
        org.junit.Assert.assertTrue("'" + jsonEncoding63 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding63.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator64);
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertArrayEquals(byteArray70, new byte[] {});
        org.junit.Assert.assertNotNull(jsonFactory72);
        org.junit.Assert.assertNotNull(jsonFactory74);
        org.junit.Assert.assertTrue("'" + feature75 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature75.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 4 + "'", int76 == 4);
        org.junit.Assert.assertNotNull(jsonFactory77);
        org.junit.Assert.assertTrue("'" + feature78 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature78.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory79);
        org.junit.Assert.assertNotNull(byteArray82);
        org.junit.Assert.assertArrayEquals(byteArray82, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(jsonParser85);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertEquals("'" + str88 + "' != '" + "" + "'", str88, "");
    }

    @Test
    public void test1506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1506");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter1 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = defaultPrettyPrinter1.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter4 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter5 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.io.SerializedString serializedString7 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray8 = serializedString7.asUnquotedUTF8();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter9 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter5, (com.fasterxml.jackson.core.SerializableString) serializedString7);
        defaultPrettyPrinter9.spacesInObjectEntries(false);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter12 = defaultPrettyPrinter9.withSpacesInObjectEntries();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter13 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter15 = lf2SpacesIndenter13.withLinefeed("");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter16 = defaultPrettyPrinter9.withArrayIndenter((com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter) lf2SpacesIndenter15);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter18 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter19 = defaultPrettyPrinter18.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter20 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter19);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter indenter21 = null;
        defaultPrettyPrinter20.indentObjectsWith(indenter21);
        com.fasterxml.jackson.core.JsonFactory jsonFactory23 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory24 = jsonFactory23.copy();
        java.lang.String str25 = jsonFactory24.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler26 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext29 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler26, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream31 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec32 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer33 = null;
        byte[] byteArray34 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser38 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext29, (int) (short) -1, inputStream31, objectCodec32, bytesToNameCanonicalizer33, byteArray34, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version39 = uTF8StreamJsonParser38.version();
        com.fasterxml.jackson.core.JsonToken jsonToken40 = uTF8StreamJsonParser38.getLastClearedToken();
        java.io.Writer writer41 = java.io.Writer.nullWriter();
        int int42 = uTF8StreamJsonParser38.releaseBuffered(writer41);
        boolean boolean43 = uTF8StreamJsonParser38.hasCurrentToken();
        boolean boolean44 = uTF8StreamJsonParser38._tokenIncomplete;
        java.lang.String str45 = uTF8StreamJsonParser38.getCurrentName();
        int int47 = uTF8StreamJsonParser38._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder48 = uTF8StreamJsonParser38._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding49 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator50 = jsonFactory24.createJsonGenerator((java.io.OutputStream) byteArrayBuilder48, jsonEncoding49);
        jsonGenerator50.writeNullField("ROOT");
        defaultPrettyPrinter20.writeRootValueSeparator(jsonGenerator50);
        jsonGenerator50.writeNumber((long) (byte) -69);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature56 = com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT;
        boolean boolean57 = feature56.enabledByDefault();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator58 = jsonGenerator50.enable(feature56);
        defaultPrettyPrinter9.beforeArrayValues(jsonGenerator50);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter2);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] {});
        org.junit.Assert.assertNotNull(defaultPrettyPrinter12);
        org.junit.Assert.assertNotNull(lf2SpacesIndenter15);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter16);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter19);
        org.junit.Assert.assertNotNull(jsonFactory24);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + " " + "'", str25, " ");
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertArrayEquals(byteArray34, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version39);
        org.junit.Assert.assertNull(jsonToken40);
        org.junit.Assert.assertNotNull(writer41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder48);
        org.junit.Assert.assertTrue("'" + jsonEncoding49 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding49.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator50);
        org.junit.Assert.assertTrue("'" + feature56 + "' != '" + com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT + "'", feature56.equals(com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(jsonGenerator58);
    }

    @Test
    public void test1507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1507");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.JsonLocation jsonLocation13 = uTF8StreamJsonParser12.getTokenLocation();
        int[] intArray14 = uTF8StreamJsonParser12._quadBuffer;
        com.fasterxml.jackson.core.JsonLocation jsonLocation15 = uTF8StreamJsonParser12.getCurrentLocation();
        int int17 = uTF8StreamJsonParser12._decodeCharForError(2000);
        com.fasterxml.jackson.core.Version version18 = uTF8StreamJsonParser12.version();
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonLocation13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertArrayEquals(intArray14, new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 });
        org.junit.Assert.assertNotNull(jsonLocation15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2000 + "'", int17 == 2000);
        org.junit.Assert.assertNotNull(version18);
    }

    @Test
    public void test1508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1508");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.io.SerializedString serializedString5 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray6 = serializedString5.asUnquotedUTF8();
        com.fasterxml.jackson.core.JsonFactory jsonFactory7 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = jsonFactory7.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler9 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext12 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler9, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding13 = iOContext12.getEncoding();
        java.lang.Object obj14 = iOContext12.getSourceReference();
        java.io.InputStream inputStream16 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer18 = null;
        byte[] byteArray19 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser23 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext12, 2000, inputStream16, objectCodec17, bytesToNameCanonicalizer18, byteArray19, 0, (int) ' ', false);
        com.fasterxml.jackson.core.JsonParser jsonParser24 = jsonFactory8.createParser(byteArray19);
        int int26 = serializedString5.appendQuotedUTF8(byteArray19, 97);
        com.fasterxml.jackson.core.json.ByteSourceJsonBootstrapper byteSourceJsonBootstrapper29 = new com.fasterxml.jackson.core.json.ByteSourceJsonBootstrapper(iOContext3, byteArray19, (int) (short) 100, 100);
        boolean boolean31 = byteSourceJsonBootstrapper29.ensureLoaded((int) (byte) -69);
        byte[] byteArray32 = byteSourceJsonBootstrapper29._inputBuffer;
        int int33 = byteSourceJsonBootstrapper29._bytesPerChar;
        boolean boolean35 = byteSourceJsonBootstrapper29.ensureLoaded(78);
        boolean boolean36 = byteSourceJsonBootstrapper29._bigEndian;
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertArrayEquals(byteArray6, new byte[] {});
        org.junit.Assert.assertNotNull(jsonFactory8);
        org.junit.Assert.assertNull(jsonEncoding13);
        org.junit.Assert.assertEquals("'" + obj14 + "' != '" + ' ' + "'", obj14, ' ');
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertArrayEquals(byteArray19, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonParser24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test1509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1509");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version13 = uTF8StreamJsonParser12.version();
        com.fasterxml.jackson.core.JsonToken jsonToken14 = uTF8StreamJsonParser12.getLastClearedToken();
        java.io.Writer writer15 = java.io.Writer.nullWriter();
        int int16 = uTF8StreamJsonParser12.releaseBuffered(writer15);
        boolean boolean18 = uTF8StreamJsonParser12.getValueAsBoolean(false);
        java.lang.Object obj19 = uTF8StreamJsonParser12.getInputSource();
        int int20 = uTF8StreamJsonParser12.getTextOffset();
        int int21 = uTF8StreamJsonParser12.getTextOffset();
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version13);
        org.junit.Assert.assertNull(jsonToken14);
        org.junit.Assert.assertNotNull(writer15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test1510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1510");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding4 = iOContext3.getEncoding();
        java.lang.Object obj5 = iOContext3.getSourceReference();
        java.io.InputStream inputStream7 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec8 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer9 = null;
        byte[] byteArray10 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser14 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, 2000, inputStream7, objectCodec8, bytesToNameCanonicalizer9, byteArray10, 0, (int) ' ', false);
        java.lang.Object obj15 = iOContext3.getSourceReference();
        java.lang.Object obj16 = iOContext3.getSourceReference();
        byte[] byteArray17 = null;
        iOContext3.releaseReadIOBuffer(byteArray17);
        // The following exception was thrown during execution in test generation
        try {
            char[] charArray20 = iOContext3.allocNameCopyBuffer(100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNull(jsonEncoding4);
        org.junit.Assert.assertEquals("'" + obj5 + "' != '" + ' ' + "'", obj5, ' ');
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertEquals("'" + obj15 + "' != '" + ' ' + "'", obj15, ' ');
        org.junit.Assert.assertEquals("'" + obj16 + "' != '" + ' ' + "'", obj16, ' ');
    }

    @Test
    public void test1511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1511");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        boolean boolean13 = uTF8StreamJsonParser12._tokenIncomplete;
        java.lang.Object obj14 = uTF8StreamJsonParser12.getTypeId();
        long long15 = uTF8StreamJsonParser12.getTokenCharacterOffset();
        char[] charArray16 = uTF8StreamJsonParser12.getTextCharacters();
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNull(charArray16);
    }

    @Test
    public void test1512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1512");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter1 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = defaultPrettyPrinter1.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter4 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter6 = lf2SpacesIndenter4.withLinefeed("");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter7 = defaultPrettyPrinter2.withObjectIndenter((com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter) lf2SpacesIndenter4);
        defaultPrettyPrinter7.spacesInObjectEntries(true);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter10 = defaultPrettyPrinter7.withSpacesInObjectEntries();
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = jsonFactory11.copy();
        java.lang.String str13 = jsonFactory12.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler14 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext17 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler14, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream19 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer21 = null;
        byte[] byteArray22 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser26 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext17, (int) (short) -1, inputStream19, objectCodec20, bytesToNameCanonicalizer21, byteArray22, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version27 = uTF8StreamJsonParser26.version();
        com.fasterxml.jackson.core.JsonToken jsonToken28 = uTF8StreamJsonParser26.getLastClearedToken();
        java.io.Writer writer29 = java.io.Writer.nullWriter();
        int int30 = uTF8StreamJsonParser26.releaseBuffered(writer29);
        boolean boolean31 = uTF8StreamJsonParser26.hasCurrentToken();
        boolean boolean32 = uTF8StreamJsonParser26._tokenIncomplete;
        java.lang.String str33 = uTF8StreamJsonParser26.getCurrentName();
        int int35 = uTF8StreamJsonParser26._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder36 = uTF8StreamJsonParser26._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding37 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator38 = jsonFactory12.createJsonGenerator((java.io.OutputStream) byteArrayBuilder36, jsonEncoding37);
        jsonGenerator38.writeNullField("ROOT");
        com.fasterxml.jackson.core.SerializableString serializableString41 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator42 = jsonGenerator38.setRootValueSeparator(serializableString41);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes43 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator44 = jsonGenerator42.setCharacterEscapes(characterEscapes43);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature45 = com.fasterxml.jackson.core.JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS;
        boolean boolean46 = feature45.enabledByDefault();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator47 = jsonGenerator44.disable(feature45);
        jsonGenerator47.writeRawValue("[");
        defaultPrettyPrinter7.beforeArrayValues(jsonGenerator47);
        com.fasterxml.jackson.core.JsonFactory jsonFactory51 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory52 = jsonFactory51.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler53 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext56 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler53, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding57 = iOContext56.getEncoding();
        java.lang.Object obj58 = iOContext56.getSourceReference();
        java.io.InputStream inputStream60 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec61 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer62 = null;
        byte[] byteArray63 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser67 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext56, 2000, inputStream60, objectCodec61, bytesToNameCanonicalizer62, byteArray63, 0, (int) ' ', false);
        com.fasterxml.jackson.core.JsonParser jsonParser68 = jsonFactory52.createParser(byteArray63);
        jsonGenerator47.writeBinary(byteArray63);
        boolean boolean70 = jsonGenerator47.canWriteTypeId();
        org.junit.Assert.assertNotNull(defaultPrettyPrinter2);
        org.junit.Assert.assertNotNull(lf2SpacesIndenter6);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter7);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter10);
        org.junit.Assert.assertNotNull(jsonFactory12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + " " + "'", str13, " ");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version27);
        org.junit.Assert.assertNull(jsonToken28);
        org.junit.Assert.assertNotNull(writer29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder36);
        org.junit.Assert.assertTrue("'" + jsonEncoding37 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding37.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator38);
        org.junit.Assert.assertNotNull(jsonGenerator42);
        org.junit.Assert.assertNotNull(jsonGenerator44);
        org.junit.Assert.assertTrue("'" + feature45 + "' != '" + com.fasterxml.jackson.core.JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS + "'", feature45.equals(com.fasterxml.jackson.core.JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(jsonGenerator47);
        org.junit.Assert.assertNotNull(jsonFactory52);
        org.junit.Assert.assertNull(jsonEncoding57);
        org.junit.Assert.assertEquals("'" + obj58 + "' != '" + ' ' + "'", obj58, ' ');
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonParser68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test1513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1513");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version13 = uTF8StreamJsonParser12.version();
        int int14 = uTF8StreamJsonParser12.getTextOffset();
        java.lang.String str16 = uTF8StreamJsonParser12.getValueAsString("UTF-16LE");
        com.fasterxml.jackson.core.JsonStreamContext jsonStreamContext17 = uTF8StreamJsonParser12.getParsingContext();
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory19 = jsonFactory18.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory21 = jsonFactory19.setRootValueSeparator("ROOT");
        com.fasterxml.jackson.core.JsonParser.Feature feature22 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int23 = feature22.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory24 = jsonFactory21.enable(feature22);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler25 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext28 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler25, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding29 = iOContext28.getEncoding();
        java.lang.Object obj30 = iOContext28.getSourceReference();
        java.io.InputStream inputStream32 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec33 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer34 = null;
        byte[] byteArray35 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser39 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext28, 2000, inputStream32, objectCodec33, bytesToNameCanonicalizer34, byteArray35, 0, (int) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding40 = iOContext28.getEncoding();
        java.io.InputStream inputStream42 = java.io.InputStream.nullInputStream();
        com.fasterxml.jackson.core.ObjectCodec objectCodec43 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer44 = null;
        com.fasterxml.jackson.core.io.SerializedString serializedString46 = new com.fasterxml.jackson.core.io.SerializedString("");
        java.lang.Object obj47 = null;
        boolean boolean48 = serializedString46.equals(obj47);
        byte[] byteArray54 = new byte[] { (byte) -69, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        int int56 = serializedString46.appendQuotedUTF8(byteArray54, 0);
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser60 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext28, (int) (byte) 1, inputStream42, objectCodec43, bytesToNameCanonicalizer44, byteArray54, (int) (short) 1, 56320, false);
        com.fasterxml.jackson.core.JsonParser jsonParser61 = jsonFactory21.createParser(inputStream42);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature62 = com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET;
        int int63 = feature62.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory65 = jsonFactory21.configure(feature62, true);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes66 = jsonFactory65.getCharacterEscapes();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler67 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext70 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler67, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream72 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec73 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer74 = null;
        byte[] byteArray75 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser79 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext70, (int) (short) -1, inputStream72, objectCodec73, bytesToNameCanonicalizer74, byteArray75, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.JsonLocation jsonLocation80 = uTF8StreamJsonParser79.getTokenLocation();
        int[] intArray81 = uTF8StreamJsonParser79._quadBuffer;
        boolean boolean82 = uTF8StreamJsonParser79.canReadTypeId();
        com.fasterxml.jackson.core.ObjectCodec objectCodec83 = null;
        uTF8StreamJsonParser79._objectCodec = objectCodec83;
        java.lang.Object obj85 = uTF8StreamJsonParser79.getTypeId();
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder86 = uTF8StreamJsonParser79._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator87 = jsonFactory65.createJsonGenerator((java.io.OutputStream) byteArrayBuilder86);
        // The following exception was thrown during execution in test generation
        try {
            int int88 = uTF8StreamJsonParser12.readBinaryValue((java.io.OutputStream) byteArrayBuilder86);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonParseException; message: Current token (null) not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary? at [Source:  ; line: 1, column: 0]");
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "UTF-16LE" + "'", str16, "UTF-16LE");
        org.junit.Assert.assertNotNull(jsonStreamContext17);
        org.junit.Assert.assertNotNull(jsonFactory19);
        org.junit.Assert.assertNotNull(jsonFactory21);
        org.junit.Assert.assertTrue("'" + feature22 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature22.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(jsonFactory24);
        org.junit.Assert.assertNull(jsonEncoding29);
        org.junit.Assert.assertEquals("'" + obj30 + "' != '" + ' ' + "'", obj30, ' ');
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNull(jsonEncoding40);
        org.junit.Assert.assertNotNull(inputStream42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertArrayEquals(byteArray54, new byte[] { (byte) -69, (byte) -1, (byte) 10, (byte) 100, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(jsonParser61);
        org.junit.Assert.assertTrue("'" + feature62 + "' != '" + com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET + "'", feature62.equals(com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(jsonFactory65);
        org.junit.Assert.assertNull(characterEscapes66);
        org.junit.Assert.assertNotNull(byteArray75);
        org.junit.Assert.assertArrayEquals(byteArray75, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonLocation80);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertArrayEquals(intArray81, new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 });
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(obj85);
        org.junit.Assert.assertNotNull(byteArrayBuilder86);
        org.junit.Assert.assertNotNull(jsonGenerator87);
    }

    @Test
    public void test1514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1514");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        java.lang.String str13 = uTF8StreamJsonParser12.getCurrentName();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler14 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext17 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler14, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream19 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer21 = null;
        byte[] byteArray22 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser26 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext17, (int) (short) -1, inputStream19, objectCodec20, bytesToNameCanonicalizer21, byteArray22, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version27 = uTF8StreamJsonParser26.version();
        com.fasterxml.jackson.core.JsonToken jsonToken28 = uTF8StreamJsonParser26.getLastClearedToken();
        java.io.Writer writer29 = java.io.Writer.nullWriter();
        int int30 = uTF8StreamJsonParser26.releaseBuffered(writer29);
        java.io.Writer writer32 = writer29.append((java.lang.CharSequence) "JSON");
        int int33 = uTF8StreamJsonParser12.releaseBuffered(writer29);
        java.lang.Object obj34 = uTF8StreamJsonParser12.getEmbeddedObject();
        boolean boolean35 = uTF8StreamJsonParser12._tokenIncomplete;
        // The following exception was thrown during execution in test generation
        try {
            uTF8StreamJsonParser12.close();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertArrayEquals(byteArray22, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version27);
        org.junit.Assert.assertNull(jsonToken28);
        org.junit.Assert.assertNotNull(writer29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(writer32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test1515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1515");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = jsonFactory0.copy();
        boolean boolean2 = jsonFactory1.requiresCustomCodec();
        com.fasterxml.jackson.core.JsonFactory jsonFactory3 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory3.copy();
        java.lang.String str5 = jsonFactory4.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler6 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext9 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler6, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream11 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer13 = null;
        byte[] byteArray14 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser18 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext9, (int) (short) -1, inputStream11, objectCodec12, bytesToNameCanonicalizer13, byteArray14, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version19 = uTF8StreamJsonParser18.version();
        com.fasterxml.jackson.core.JsonToken jsonToken20 = uTF8StreamJsonParser18.getLastClearedToken();
        java.io.Writer writer21 = java.io.Writer.nullWriter();
        int int22 = uTF8StreamJsonParser18.releaseBuffered(writer21);
        boolean boolean23 = uTF8StreamJsonParser18.hasCurrentToken();
        boolean boolean24 = uTF8StreamJsonParser18._tokenIncomplete;
        java.lang.String str25 = uTF8StreamJsonParser18.getCurrentName();
        int int27 = uTF8StreamJsonParser18._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder28 = uTF8StreamJsonParser18._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding29 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator30 = jsonFactory4.createJsonGenerator((java.io.OutputStream) byteArrayBuilder28, jsonEncoding29);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding31 = com.fasterxml.jackson.core.JsonEncoding.UTF32_LE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator32 = jsonFactory1.createJsonGenerator((java.io.OutputStream) byteArrayBuilder28, jsonEncoding31);
        com.fasterxml.jackson.core.FormatSchema formatSchema33 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean34 = jsonFactory1.canUseSchema(formatSchema33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonFactory1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + " " + "'", str5, " ");
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version19);
        org.junit.Assert.assertNull(jsonToken20);
        org.junit.Assert.assertNotNull(writer21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder28);
        org.junit.Assert.assertTrue("'" + jsonEncoding29 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding29.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator30);
        org.junit.Assert.assertTrue("'" + jsonEncoding31 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_LE + "'", jsonEncoding31.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_LE));
        org.junit.Assert.assertNotNull(jsonGenerator32);
    }

    @Test
    public void test1516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1516");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = defaultPrettyPrinter2.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter4 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter3);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter5 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter7 = lf2SpacesIndenter5.withLinefeed("");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter8 = defaultPrettyPrinter3.withObjectIndenter((com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter) lf2SpacesIndenter5);
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory10 = jsonFactory9.copy();
        java.lang.String str11 = jsonFactory10.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler12 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext15 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler12, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream17 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer19 = null;
        byte[] byteArray20 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser24 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext15, (int) (short) -1, inputStream17, objectCodec18, bytesToNameCanonicalizer19, byteArray20, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version25 = uTF8StreamJsonParser24.version();
        com.fasterxml.jackson.core.JsonToken jsonToken26 = uTF8StreamJsonParser24.getLastClearedToken();
        java.io.Writer writer27 = java.io.Writer.nullWriter();
        int int28 = uTF8StreamJsonParser24.releaseBuffered(writer27);
        boolean boolean29 = uTF8StreamJsonParser24.hasCurrentToken();
        boolean boolean30 = uTF8StreamJsonParser24._tokenIncomplete;
        java.lang.String str31 = uTF8StreamJsonParser24.getCurrentName();
        int int33 = uTF8StreamJsonParser24._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder34 = uTF8StreamJsonParser24._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding35 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator36 = jsonFactory10.createJsonGenerator((java.io.OutputStream) byteArrayBuilder34, jsonEncoding35);
        jsonGenerator36.writeStringField("UTF-16LE", "/");
        com.fasterxml.jackson.core.io.SerializedString serializedString41 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray42 = serializedString41.asUnquotedUTF8();
        com.fasterxml.jackson.core.JsonFactory jsonFactory43 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory44 = jsonFactory43.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory46 = jsonFactory44.setRootValueSeparator("ROOT");
        com.fasterxml.jackson.core.JsonParser.Feature feature47 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int48 = feature47.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory49 = jsonFactory46.enable(feature47);
        com.fasterxml.jackson.core.JsonFactory.Feature feature50 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory51 = jsonFactory49.disable(feature50);
        byte[] byteArray54 = new byte[] { (byte) 0, (byte) 0 };
        com.fasterxml.jackson.core.JsonParser jsonParser57 = jsonFactory49.createJsonParser(byteArray54, (int) (byte) -1, (int) (short) 0);
        int int59 = serializedString41.appendQuotedUTF8(byteArray54, 64);
        java.lang.String str60 = serializedString41.getValue();
        jsonGenerator36.writeString((com.fasterxml.jackson.core.SerializableString) serializedString41);
        defaultPrettyPrinter8.writeStartObject(jsonGenerator36);
        com.fasterxml.jackson.core.io.IOContext iOContext64 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) jsonGenerator36, true);
        jsonGenerator36.writeNumber(0.0d);
        jsonGenerator36.writeBooleanField("/", true);
        jsonGenerator36.writeObjectFieldStart("hi!");
        jsonGenerator36.writeNumber((-179038973));
        org.junit.Assert.assertNotNull(defaultPrettyPrinter3);
        org.junit.Assert.assertNotNull(lf2SpacesIndenter7);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter8);
        org.junit.Assert.assertNotNull(jsonFactory10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + " " + "'", str11, " ");
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertArrayEquals(byteArray20, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version25);
        org.junit.Assert.assertNull(jsonToken26);
        org.junit.Assert.assertNotNull(writer27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder34);
        org.junit.Assert.assertTrue("'" + jsonEncoding35 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding35.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator36);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertArrayEquals(byteArray42, new byte[] {});
        org.junit.Assert.assertNotNull(jsonFactory44);
        org.junit.Assert.assertNotNull(jsonFactory46);
        org.junit.Assert.assertTrue("'" + feature47 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature47.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(jsonFactory49);
        org.junit.Assert.assertTrue("'" + feature50 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature50.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory51);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertArrayEquals(byteArray54, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(jsonParser57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertEquals("'" + str60 + "' != '" + "" + "'", str60, "");
    }

    @Test
    public void test1517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1517");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        boolean boolean13 = uTF8StreamJsonParser12._tokenIncomplete;
        java.lang.Object obj14 = uTF8StreamJsonParser12.getTypeId();
        double double16 = uTF8StreamJsonParser12.getValueAsDouble((double) ' ');
        com.fasterxml.jackson.core.JsonToken jsonToken17 = uTF8StreamJsonParser12.getCurrentToken();
        boolean boolean19 = uTF8StreamJsonParser12._loadToHaveAtLeast(33);
        int int20 = uTF8StreamJsonParser12.getTextOffset();
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonToken jsonToken22 = uTF8StreamJsonParser12._handleUnexpectedValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index -1 out of bounds for length 16");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertNull(jsonToken17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test1518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1518");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = jsonFactory0.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler2 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext5 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler2, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream7 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec8 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer9 = null;
        byte[] byteArray10 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser14 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext5, (int) (short) -1, inputStream7, objectCodec8, bytesToNameCanonicalizer9, byteArray10, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version15 = uTF8StreamJsonParser14.version();
        com.fasterxml.jackson.core.JsonToken jsonToken16 = uTF8StreamJsonParser14.getLastClearedToken();
        java.io.Writer writer17 = java.io.Writer.nullWriter();
        int int18 = uTF8StreamJsonParser14.releaseBuffered(writer17);
        java.io.Writer writer20 = writer17.append((java.lang.CharSequence) "JSON");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = jsonFactory0.createGenerator(writer20);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator22 = jsonFactory0.getInputDecorator();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes23 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory24 = jsonFactory0.setCharacterEscapes(characterEscapes23);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes25 = jsonFactory0.getCharacterEscapes();
        org.junit.Assert.assertNotNull(jsonFactory1);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNull(jsonToken16);
        org.junit.Assert.assertNotNull(writer17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(writer20);
        org.junit.Assert.assertNotNull(jsonGenerator21);
        org.junit.Assert.assertNull(inputDecorator22);
        org.junit.Assert.assertNotNull(jsonFactory24);
        org.junit.Assert.assertNull(characterEscapes25);
    }

    @Test
    public void test1519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1519");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding13 = null;
        iOContext3.setEncoding(jsonEncoding13);
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory16.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory19 = jsonFactory17.setRootValueSeparator("ROOT");
        com.fasterxml.jackson.core.JsonParser.Feature feature20 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int21 = feature20.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory19.enable(feature20);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler23 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext26 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler23, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding27 = iOContext26.getEncoding();
        java.lang.Object obj28 = iOContext26.getSourceReference();
        java.io.InputStream inputStream30 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec31 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer32 = null;
        byte[] byteArray33 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser37 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext26, 2000, inputStream30, objectCodec31, bytesToNameCanonicalizer32, byteArray33, 0, (int) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding38 = iOContext26.getEncoding();
        java.io.InputStream inputStream40 = java.io.InputStream.nullInputStream();
        com.fasterxml.jackson.core.ObjectCodec objectCodec41 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer42 = null;
        com.fasterxml.jackson.core.io.SerializedString serializedString44 = new com.fasterxml.jackson.core.io.SerializedString("");
        java.lang.Object obj45 = null;
        boolean boolean46 = serializedString44.equals(obj45);
        byte[] byteArray52 = new byte[] { (byte) -69, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        int int54 = serializedString44.appendQuotedUTF8(byteArray52, 0);
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser58 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext26, (int) (byte) 1, inputStream40, objectCodec41, bytesToNameCanonicalizer42, byteArray52, (int) (short) 1, 56320, false);
        com.fasterxml.jackson.core.JsonParser jsonParser59 = jsonFactory19.createParser(inputStream40);
        com.fasterxml.jackson.core.ObjectCodec objectCodec60 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer61 = null;
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler62 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext65 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler62, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream67 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec68 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer69 = null;
        byte[] byteArray70 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser74 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext65, (int) (short) -1, inputStream67, objectCodec68, bytesToNameCanonicalizer69, byteArray70, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.JsonLocation jsonLocation75 = uTF8StreamJsonParser74.getTokenLocation();
        int[] intArray76 = uTF8StreamJsonParser74._quadBuffer;
        boolean boolean77 = uTF8StreamJsonParser74.canReadTypeId();
        int int78 = uTF8StreamJsonParser74.getTokenLineNr();
        byte[] byteArray79 = uTF8StreamJsonParser74._inputBuffer;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser83 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (-179016949), inputStream40, objectCodec60, bytesToNameCanonicalizer61, byteArray79, 2000, (int) (byte) 1, true);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding84 = iOContext3.getEncoding();
        com.fasterxml.jackson.core.util.TextBuffer textBuffer85 = iOContext3.constructTextBuffer();
        // The following exception was thrown during execution in test generation
        try {
            java.math.BigDecimal bigDecimal86 = textBuffer85.contentsAsDecimal();
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Value \"\" can not be represented as BigDecimal");
        } catch (java.lang.NumberFormatException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory19);
        org.junit.Assert.assertTrue("'" + feature20 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature20.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(jsonFactory22);
        org.junit.Assert.assertNull(jsonEncoding27);
        org.junit.Assert.assertEquals("'" + obj28 + "' != '" + ' ' + "'", obj28, ' ');
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertArrayEquals(byteArray33, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNull(jsonEncoding38);
        org.junit.Assert.assertNotNull(inputStream40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertArrayEquals(byteArray52, new byte[] { (byte) -69, (byte) -1, (byte) 10, (byte) 100, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(jsonParser59);
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertArrayEquals(byteArray70, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonLocation75);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertArrayEquals(intArray76, new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 });
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(byteArray79);
        org.junit.Assert.assertArrayEquals(byteArray79, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNull(jsonEncoding84);
        org.junit.Assert.assertNotNull(textBuffer85);
    }

    @Test
    public void test1520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1520");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter1 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = defaultPrettyPrinter1.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter indenter4 = null;
        defaultPrettyPrinter3.indentObjectsWith(indenter4);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory7 = jsonFactory6.copy();
        java.lang.String str8 = jsonFactory7.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler9 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext12 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler9, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream14 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec15 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer16 = null;
        byte[] byteArray17 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser21 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext12, (int) (short) -1, inputStream14, objectCodec15, bytesToNameCanonicalizer16, byteArray17, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version22 = uTF8StreamJsonParser21.version();
        com.fasterxml.jackson.core.JsonToken jsonToken23 = uTF8StreamJsonParser21.getLastClearedToken();
        java.io.Writer writer24 = java.io.Writer.nullWriter();
        int int25 = uTF8StreamJsonParser21.releaseBuffered(writer24);
        boolean boolean26 = uTF8StreamJsonParser21.hasCurrentToken();
        boolean boolean27 = uTF8StreamJsonParser21._tokenIncomplete;
        java.lang.String str28 = uTF8StreamJsonParser21.getCurrentName();
        int int30 = uTF8StreamJsonParser21._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder31 = uTF8StreamJsonParser21._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding32 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator33 = jsonFactory7.createJsonGenerator((java.io.OutputStream) byteArrayBuilder31, jsonEncoding32);
        jsonGenerator33.writeNullField("ROOT");
        defaultPrettyPrinter3.writeRootValueSeparator(jsonGenerator33);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter38 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter39 = defaultPrettyPrinter38.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter40 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter39);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter41 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter39);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter42 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter39);
        com.fasterxml.jackson.core.io.SerializedString serializedString44 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray45 = serializedString44.asUnquotedUTF8();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter46 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter42, (com.fasterxml.jackson.core.SerializableString) serializedString44);
        com.fasterxml.jackson.core.JsonFactory jsonFactory47 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory48 = jsonFactory47.copy();
        java.lang.String str49 = jsonFactory48.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler50 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext53 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler50, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream55 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec56 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer57 = null;
        byte[] byteArray58 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser62 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext53, (int) (short) -1, inputStream55, objectCodec56, bytesToNameCanonicalizer57, byteArray58, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version63 = uTF8StreamJsonParser62.version();
        com.fasterxml.jackson.core.JsonToken jsonToken64 = uTF8StreamJsonParser62.getLastClearedToken();
        java.io.Writer writer65 = java.io.Writer.nullWriter();
        int int66 = uTF8StreamJsonParser62.releaseBuffered(writer65);
        boolean boolean67 = uTF8StreamJsonParser62.hasCurrentToken();
        boolean boolean68 = uTF8StreamJsonParser62._tokenIncomplete;
        java.lang.String str69 = uTF8StreamJsonParser62.getCurrentName();
        int int71 = uTF8StreamJsonParser62._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder72 = uTF8StreamJsonParser62._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding73 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator74 = jsonFactory48.createJsonGenerator((java.io.OutputStream) byteArrayBuilder72, jsonEncoding73);
        jsonGenerator74.writeNull();
        defaultPrettyPrinter46.writeEndArray(jsonGenerator74, 79);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter79 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter80 = defaultPrettyPrinter79.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter81 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter80);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter82 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter84 = lf2SpacesIndenter82.withLinefeed("");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter85 = defaultPrettyPrinter80.withObjectIndenter((com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter) lf2SpacesIndenter82);
        defaultPrettyPrinter46.indentArraysWith((com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter) lf2SpacesIndenter82);
        defaultPrettyPrinter3.indentArraysWith((com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter) lf2SpacesIndenter82);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter2);
        org.junit.Assert.assertNotNull(jsonFactory7);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + " " + "'", str8, " ");
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version22);
        org.junit.Assert.assertNull(jsonToken23);
        org.junit.Assert.assertNotNull(writer24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder31);
        org.junit.Assert.assertTrue("'" + jsonEncoding32 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding32.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator33);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter39);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertArrayEquals(byteArray45, new byte[] {});
        org.junit.Assert.assertNotNull(jsonFactory48);
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + " " + "'", str49, " ");
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertArrayEquals(byteArray58, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version63);
        org.junit.Assert.assertNull(jsonToken64);
        org.junit.Assert.assertNotNull(writer65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder72);
        org.junit.Assert.assertTrue("'" + jsonEncoding73 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding73.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator74);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter80);
        org.junit.Assert.assertNotNull(lf2SpacesIndenter84);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter85);
    }

    @Test
    public void test1521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1521");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = jsonFactory0.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory3 = jsonFactory1.setRootValueSeparator("ROOT");
        com.fasterxml.jackson.core.JsonParser.Feature feature4 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int5 = feature4.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory3.enable(feature4);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler7 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext10 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler7, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding11 = iOContext10.getEncoding();
        java.lang.Object obj12 = iOContext10.getSourceReference();
        java.io.InputStream inputStream14 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec15 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer16 = null;
        byte[] byteArray17 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser21 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext10, 2000, inputStream14, objectCodec15, bytesToNameCanonicalizer16, byteArray17, 0, (int) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding22 = iOContext10.getEncoding();
        java.io.InputStream inputStream24 = java.io.InputStream.nullInputStream();
        com.fasterxml.jackson.core.ObjectCodec objectCodec25 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer26 = null;
        com.fasterxml.jackson.core.io.SerializedString serializedString28 = new com.fasterxml.jackson.core.io.SerializedString("");
        java.lang.Object obj29 = null;
        boolean boolean30 = serializedString28.equals(obj29);
        byte[] byteArray36 = new byte[] { (byte) -69, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        int int38 = serializedString28.appendQuotedUTF8(byteArray36, 0);
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser42 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext10, (int) (byte) 1, inputStream24, objectCodec25, bytesToNameCanonicalizer26, byteArray36, (int) (short) 1, 56320, false);
        com.fasterxml.jackson.core.JsonParser jsonParser43 = jsonFactory3.createJsonParser(inputStream24);
        boolean boolean44 = jsonFactory3.requiresCustomCodec();
        com.fasterxml.jackson.core.JsonFactory jsonFactory45 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory46 = jsonFactory45.copy();
        java.lang.String str47 = jsonFactory46.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler48 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext51 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler48, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream53 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec54 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer55 = null;
        byte[] byteArray56 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser60 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext51, (int) (short) -1, inputStream53, objectCodec54, bytesToNameCanonicalizer55, byteArray56, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version61 = uTF8StreamJsonParser60.version();
        com.fasterxml.jackson.core.JsonToken jsonToken62 = uTF8StreamJsonParser60.getLastClearedToken();
        java.io.Writer writer63 = java.io.Writer.nullWriter();
        int int64 = uTF8StreamJsonParser60.releaseBuffered(writer63);
        boolean boolean65 = uTF8StreamJsonParser60.hasCurrentToken();
        boolean boolean66 = uTF8StreamJsonParser60._tokenIncomplete;
        java.lang.String str67 = uTF8StreamJsonParser60.getCurrentName();
        int int69 = uTF8StreamJsonParser60._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder70 = uTF8StreamJsonParser60._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding71 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator72 = jsonFactory46.createJsonGenerator((java.io.OutputStream) byteArrayBuilder70, jsonEncoding71);
        jsonGenerator72.writeStringField("UTF-16LE", "/");
        com.fasterxml.jackson.core.JsonFactory jsonFactory76 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonGenerator.Feature feature77 = com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET;
        boolean boolean78 = jsonFactory76.isEnabled(feature77);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator79 = jsonGenerator72.disable(feature77);
        com.fasterxml.jackson.core.io.SerializedString serializedString81 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray82 = serializedString81.asUnquotedUTF8();
        jsonGenerator72.writeFieldName((com.fasterxml.jackson.core.SerializableString) serializedString81);
        byte[] byteArray84 = serializedString81.asUnquotedUTF8();
        com.fasterxml.jackson.core.JsonParser jsonParser87 = jsonFactory3.createParser(byteArray84, (-181550001), (-181601343));
        org.junit.Assert.assertNotNull(jsonFactory1);
        org.junit.Assert.assertNotNull(jsonFactory3);
        org.junit.Assert.assertTrue("'" + feature4 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature4.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNull(jsonEncoding11);
        org.junit.Assert.assertEquals("'" + obj12 + "' != '" + ' ' + "'", obj12, ' ');
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertArrayEquals(byteArray17, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNull(jsonEncoding22);
        org.junit.Assert.assertNotNull(inputStream24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] { (byte) -69, (byte) -1, (byte) 10, (byte) 100, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(jsonParser43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonFactory46);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + " " + "'", str47, " ");
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertArrayEquals(byteArray56, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version61);
        org.junit.Assert.assertNull(jsonToken62);
        org.junit.Assert.assertNotNull(writer63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder70);
        org.junit.Assert.assertTrue("'" + jsonEncoding71 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding71.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator72);
        org.junit.Assert.assertTrue("'" + feature77 + "' != '" + com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET + "'", feature77.equals(com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(jsonGenerator79);
        org.junit.Assert.assertNotNull(byteArray82);
        org.junit.Assert.assertArrayEquals(byteArray82, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray84);
        org.junit.Assert.assertArrayEquals(byteArray84, new byte[] {});
        org.junit.Assert.assertNotNull(jsonParser87);
    }

    @Test
    public void test1522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1522");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding4 = iOContext3.getEncoding();
        java.lang.Object obj5 = iOContext3.getSourceReference();
        java.io.InputStream inputStream7 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec8 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer9 = null;
        byte[] byteArray10 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser14 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, 2000, inputStream7, objectCodec8, bytesToNameCanonicalizer9, byteArray10, 0, (int) ' ', false);
        com.fasterxml.jackson.core.util.TextBuffer textBuffer15 = iOContext3.constructTextBuffer();
        boolean boolean16 = textBuffer15.hasTextAsCharacters();
        textBuffer15.append('#');
        int int19 = textBuffer15.getCurrentSegmentSize();
        int int20 = textBuffer15.getTextOffset();
        int int21 = textBuffer15.size();
        textBuffer15.append('#');
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter25 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter26 = defaultPrettyPrinter25.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter27 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter26);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter28 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter26);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter29 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter26);
        com.fasterxml.jackson.core.io.SerializedString serializedString31 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray32 = serializedString31.asUnquotedUTF8();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter33 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter29, (com.fasterxml.jackson.core.SerializableString) serializedString31);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler35 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext38 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler35, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream40 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec41 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer42 = null;
        byte[] byteArray43 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser47 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext38, (int) (short) -1, inputStream40, objectCodec41, bytesToNameCanonicalizer42, byteArray43, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.JsonLocation jsonLocation48 = uTF8StreamJsonParser47.getTokenLocation();
        java.lang.Throwable throwable49 = null;
        com.fasterxml.jackson.core.JsonParseException jsonParseException50 = new com.fasterxml.jackson.core.JsonParseException("", jsonLocation48, throwable49);
        java.lang.String str51 = jsonParseException50.toString();
        com.fasterxml.jackson.core.JsonLocation jsonLocation52 = jsonParseException50.getLocation();
        com.fasterxml.jackson.core.io.SerializedString serializedString54 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray55 = serializedString54.asUnquotedUTF8();
        boolean boolean56 = jsonLocation52.equals((java.lang.Object) serializedString54);
        char[] charArray57 = com.fasterxml.jackson.core.io.CharTypes.copyHexChars();
        int int59 = serializedString54.appendUnquoted(charArray57, 1);
        int int61 = serializedString31.appendUnquoted(charArray57, (int) (byte) 10);
        // The following exception was thrown during execution in test generation
        try {
            textBuffer15.resetWithCopy(charArray57, 0, (-178958325));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: arraycopy: length -178958325 is negative");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNull(jsonEncoding4);
        org.junit.Assert.assertEquals("'" + obj5 + "' != '" + ' ' + "'", obj5, ' ');
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertArrayEquals(byteArray10, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(textBuffer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter26);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertArrayEquals(byteArray32, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertArrayEquals(byteArray43, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonLocation48);
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "com.fasterxml.jackson.core.JsonParseException: \n at [Source:  ; line: 1, column: 1]" + "'", str51, "com.fasterxml.jackson.core.JsonParseException: \n at [Source:  ; line: 1, column: 1]");
        org.junit.Assert.assertNotNull(jsonLocation52);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertArrayEquals(byteArray55, new byte[] {});
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(charArray57);
        org.junit.Assert.assertArrayEquals(charArray57, new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' });
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test1523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1523");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        boolean boolean13 = uTF8StreamJsonParser12._tokenIncomplete;
        java.lang.Object obj14 = uTF8StreamJsonParser12.getTypeId();
        java.lang.Object obj15 = uTF8StreamJsonParser12.getObjectId();
        int int16 = uTF8StreamJsonParser12.getTextLength();
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = uTF8StreamJsonParser12._objectCodec;
        uTF8StreamJsonParser12._tokenIncomplete = true;
        // The following exception was thrown during execution in test generation
        try {
            double double20 = uTF8StreamJsonParser12.getDoubleValue();
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonParseException; message: Current token (null) not numeric, can not use numeric value accessors? at [Source:  ; line: 1, column: 0]");
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(objectCodec17);
    }

    @Test
    public void test1524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1524");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = jsonFactory0.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory3 = jsonFactory1.setRootValueSeparator("ROOT");
        com.fasterxml.jackson.core.JsonParser.Feature feature4 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int5 = feature4.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory3.enable(feature4);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = jsonFactory6.disable(feature7);
        byte[] byteArray11 = new byte[] { (byte) 0, (byte) 0 };
        com.fasterxml.jackson.core.JsonParser jsonParser14 = jsonFactory6.createJsonParser(byteArray11, (int) (byte) -1, (int) (short) 0);
        com.fasterxml.jackson.core.ObjectCodec objectCodec15 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory6.setCodec(objectCodec15);
        java.io.InputStream inputStream17 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser18 = jsonFactory16.createParser(inputStream17);
        com.fasterxml.jackson.core.JsonFactory jsonFactory19 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory19.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory20.setRootValueSeparator("ROOT");
        com.fasterxml.jackson.core.JsonParser.Feature feature23 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int24 = feature23.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory25 = jsonFactory22.enable(feature23);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler26 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext29 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler26, (java.lang.Object) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding30 = iOContext29.getEncoding();
        java.lang.Object obj31 = iOContext29.getSourceReference();
        java.io.InputStream inputStream33 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec34 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer35 = null;
        byte[] byteArray36 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser40 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext29, 2000, inputStream33, objectCodec34, bytesToNameCanonicalizer35, byteArray36, 0, (int) ' ', false);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding41 = iOContext29.getEncoding();
        java.io.InputStream inputStream43 = java.io.InputStream.nullInputStream();
        com.fasterxml.jackson.core.ObjectCodec objectCodec44 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer45 = null;
        com.fasterxml.jackson.core.io.SerializedString serializedString47 = new com.fasterxml.jackson.core.io.SerializedString("");
        java.lang.Object obj48 = null;
        boolean boolean49 = serializedString47.equals(obj48);
        byte[] byteArray55 = new byte[] { (byte) -69, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        int int57 = serializedString47.appendQuotedUTF8(byteArray55, 0);
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser61 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext29, (int) (byte) 1, inputStream43, objectCodec44, bytesToNameCanonicalizer45, byteArray55, (int) (short) 1, 56320, false);
        com.fasterxml.jackson.core.JsonParser jsonParser62 = jsonFactory22.createParser(inputStream43);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature63 = com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET;
        int int64 = feature63.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory66 = jsonFactory22.configure(feature63, true);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes67 = jsonFactory66.getCharacterEscapes();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler68 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext71 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler68, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream73 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec74 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer75 = null;
        byte[] byteArray76 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser80 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext71, (int) (short) -1, inputStream73, objectCodec74, bytesToNameCanonicalizer75, byteArray76, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.JsonLocation jsonLocation81 = uTF8StreamJsonParser80.getTokenLocation();
        int[] intArray82 = uTF8StreamJsonParser80._quadBuffer;
        boolean boolean83 = uTF8StreamJsonParser80.canReadTypeId();
        com.fasterxml.jackson.core.ObjectCodec objectCodec84 = null;
        uTF8StreamJsonParser80._objectCodec = objectCodec84;
        java.lang.Object obj86 = uTF8StreamJsonParser80.getTypeId();
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder87 = uTF8StreamJsonParser80._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator88 = jsonFactory66.createJsonGenerator((java.io.OutputStream) byteArrayBuilder87);
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding89 = com.fasterxml.jackson.core.JsonEncoding.UTF32_LE;
        java.lang.String str90 = jsonEncoding89.getJavaName();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator91 = jsonFactory16.createGenerator((java.io.OutputStream) byteArrayBuilder87, jsonEncoding89);
        org.junit.Assert.assertNotNull(jsonFactory1);
        org.junit.Assert.assertNotNull(jsonFactory3);
        org.junit.Assert.assertTrue("'" + feature4 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature4.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory8);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertArrayEquals(byteArray11, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(jsonParser14);
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertNotNull(jsonParser18);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNotNull(jsonFactory22);
        org.junit.Assert.assertTrue("'" + feature23 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature23.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(jsonFactory25);
        org.junit.Assert.assertNull(jsonEncoding30);
        org.junit.Assert.assertEquals("'" + obj31 + "' != '" + ' ' + "'", obj31, ' ');
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertArrayEquals(byteArray36, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNull(jsonEncoding41);
        org.junit.Assert.assertNotNull(inputStream43);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertArrayEquals(byteArray55, new byte[] { (byte) -69, (byte) -1, (byte) 10, (byte) 100, (byte) -1 });
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(jsonParser62);
        org.junit.Assert.assertTrue("'" + feature63 + "' != '" + com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET + "'", feature63.equals(com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(jsonFactory66);
        org.junit.Assert.assertNull(characterEscapes67);
        org.junit.Assert.assertNotNull(byteArray76);
        org.junit.Assert.assertArrayEquals(byteArray76, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonLocation81);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertArrayEquals(intArray82, new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 });
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(obj86);
        org.junit.Assert.assertNotNull(byteArrayBuilder87);
        org.junit.Assert.assertNotNull(jsonGenerator88);
        org.junit.Assert.assertTrue("'" + jsonEncoding89 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_LE + "'", jsonEncoding89.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_LE));
        org.junit.Assert.assertEquals("'" + str90 + "' != '" + "UTF-32LE" + "'", str90, "UTF-32LE");
        org.junit.Assert.assertNotNull(jsonGenerator91);
    }

    @Test
    public void test1525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1525");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter1 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = defaultPrettyPrinter1.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter4 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter5 = defaultPrettyPrinter4.withoutSpacesInObjectEntries();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter7 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter8 = defaultPrettyPrinter7.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter9 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter8);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter10 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter8);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter11 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter8);
        com.fasterxml.jackson.core.io.SerializedString serializedString13 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray14 = serializedString13.asUnquotedUTF8();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter15 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter11, (com.fasterxml.jackson.core.SerializableString) serializedString13);
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory16.copy();
        java.lang.String str18 = jsonFactory17.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler19 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext22 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler19, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream24 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec25 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer26 = null;
        byte[] byteArray27 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser31 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext22, (int) (short) -1, inputStream24, objectCodec25, bytesToNameCanonicalizer26, byteArray27, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version32 = uTF8StreamJsonParser31.version();
        com.fasterxml.jackson.core.JsonToken jsonToken33 = uTF8StreamJsonParser31.getLastClearedToken();
        java.io.Writer writer34 = java.io.Writer.nullWriter();
        int int35 = uTF8StreamJsonParser31.releaseBuffered(writer34);
        boolean boolean36 = uTF8StreamJsonParser31.hasCurrentToken();
        boolean boolean37 = uTF8StreamJsonParser31._tokenIncomplete;
        java.lang.String str38 = uTF8StreamJsonParser31.getCurrentName();
        int int40 = uTF8StreamJsonParser31._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder41 = uTF8StreamJsonParser31._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding42 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator43 = jsonFactory17.createJsonGenerator((java.io.OutputStream) byteArrayBuilder41, jsonEncoding42);
        jsonGenerator43.writeStringField("UTF-16LE", "/");
        com.fasterxml.jackson.core.JsonFactory jsonFactory47 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonGenerator.Feature feature48 = com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET;
        boolean boolean49 = jsonFactory47.isEnabled(feature48);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator50 = jsonGenerator43.disable(feature48);
        com.fasterxml.jackson.core.io.SerializedString serializedString52 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray53 = serializedString52.asUnquotedUTF8();
        jsonGenerator43.writeFieldName((com.fasterxml.jackson.core.SerializableString) serializedString52);
        char[] charArray55 = serializedString52.asQuotedChars();
        int int57 = serializedString13.appendUnquoted(charArray55, (int) '4');
        java.lang.String str58 = serializedString13.toString();
        com.fasterxml.jackson.core.io.SerializedString serializedString60 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray61 = serializedString60.asUnquotedUTF8();
        byte[] byteArray62 = serializedString60.asUnquotedUTF8();
        byte[] byteArray63 = serializedString60.asUnquotedUTF8();
        int int65 = serializedString13.appendQuotedUTF8(byteArray63, 0);
        java.lang.String str66 = serializedString13.toString();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter67 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter4, (com.fasterxml.jackson.core.SerializableString) serializedString13);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter2);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter5);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter8);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertArrayEquals(byteArray14, new byte[] {});
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + " " + "'", str18, " ");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertArrayEquals(byteArray27, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version32);
        org.junit.Assert.assertNull(jsonToken33);
        org.junit.Assert.assertNotNull(writer34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder41);
        org.junit.Assert.assertTrue("'" + jsonEncoding42 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding42.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator43);
        org.junit.Assert.assertTrue("'" + feature48 + "' != '" + com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET + "'", feature48.equals(com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_TARGET));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(jsonGenerator50);
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertArrayEquals(byteArray53, new byte[] {});
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertArrayEquals(charArray55, new char[] {});
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "" + "'", str58, "");
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertArrayEquals(byteArray61, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertArrayEquals(byteArray62, new byte[] {});
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertArrayEquals(byteArray63, new byte[] {});
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertEquals("'" + str66 + "' != '" + "" + "'", str66, "");
    }

    @Test
    public void test1526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1526");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version13 = uTF8StreamJsonParser12.version();
        com.fasterxml.jackson.core.JsonToken jsonToken14 = uTF8StreamJsonParser12.getLastClearedToken();
        java.io.Writer writer15 = java.io.Writer.nullWriter();
        int int16 = uTF8StreamJsonParser12.releaseBuffered(writer15);
        boolean boolean17 = uTF8StreamJsonParser12.hasCurrentToken();
        boolean boolean18 = uTF8StreamJsonParser12._tokenIncomplete;
        com.fasterxml.jackson.core.JsonToken jsonToken19 = com.fasterxml.jackson.core.JsonToken.VALUE_STRING;
        java.lang.String str20 = uTF8StreamJsonParser12._getText2(jsonToken19);
        boolean boolean21 = uTF8StreamJsonParser12.getValueAsBoolean();
        int int22 = uTF8StreamJsonParser12.getTextLength();
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version13);
        org.junit.Assert.assertNull(jsonToken14);
        org.junit.Assert.assertNotNull(writer15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + jsonToken19 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_STRING + "'", jsonToken19.equals(com.fasterxml.jackson.core.JsonToken.VALUE_STRING));
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test1527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1527");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer7 = null;
        byte[] byteArray8 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser12 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext3, (int) (short) -1, inputStream5, objectCodec6, bytesToNameCanonicalizer7, byteArray8, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.JsonLocation jsonLocation13 = uTF8StreamJsonParser12.getTokenLocation();
        char[] charArray14 = uTF8StreamJsonParser12.getTextCharacters();
        com.fasterxml.jackson.core.json.JsonReadContext jsonReadContext15 = null;
        com.fasterxml.jackson.core.json.JsonReadContext jsonReadContext19 = new com.fasterxml.jackson.core.json.JsonReadContext(jsonReadContext15, 0, (int) (short) 0, (int) ' ');
        jsonReadContext19.reset((int) (byte) 0, 0, (int) (short) 1);
        int int24 = jsonReadContext19.getCurrentIndex();
        jsonReadContext19._currentName = "ROOT";
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler27 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext30 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler27, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream32 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec33 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer34 = null;
        byte[] byteArray35 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser39 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext30, (int) (short) -1, inputStream32, objectCodec33, bytesToNameCanonicalizer34, byteArray35, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.JsonLocation jsonLocation40 = uTF8StreamJsonParser39.getTokenLocation();
        int[] intArray41 = uTF8StreamJsonParser39._quadBuffer;
        com.fasterxml.jackson.core.JsonLocation jsonLocation42 = jsonReadContext19.getStartLocation((java.lang.Object) uTF8StreamJsonParser39);
        com.fasterxml.jackson.core.JsonParser.Feature feature43 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int44 = feature43.getMask();
        com.fasterxml.jackson.core.JsonParser jsonParser45 = uTF8StreamJsonParser39.enable(feature43);
        com.fasterxml.jackson.core.JsonParser jsonParser46 = uTF8StreamJsonParser12.disable(feature43);
        uTF8StreamJsonParser12.clearCurrentToken();
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertArrayEquals(byteArray8, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonLocation13);
        org.junit.Assert.assertNull(charArray14);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertArrayEquals(byteArray35, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(jsonLocation40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertArrayEquals(intArray41, new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 });
        org.junit.Assert.assertNotNull(jsonLocation42);
        org.junit.Assert.assertTrue("'" + feature43 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature43.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(jsonParser45);
        org.junit.Assert.assertNotNull(jsonParser46);
    }

    @Test
    public void test1528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1528");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter1 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter2 = defaultPrettyPrinter1.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter3 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter4 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2);
        com.fasterxml.jackson.core.SerializableString serializableString5 = null;
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter6 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2, serializableString5);
        com.fasterxml.jackson.core.io.SerializedString serializedString8 = new com.fasterxml.jackson.core.io.SerializedString("");
        byte[] byteArray9 = serializedString8.asUnquotedUTF8();
        com.fasterxml.jackson.core.JsonFactory jsonFactory10 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory10.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = jsonFactory11.setRootValueSeparator("ROOT");
        com.fasterxml.jackson.core.JsonParser.Feature feature14 = com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS;
        int int15 = feature14.getMask();
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory13.enable(feature14);
        com.fasterxml.jackson.core.JsonFactory.Feature feature17 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory16.disable(feature17);
        byte[] byteArray21 = new byte[] { (byte) 0, (byte) 0 };
        com.fasterxml.jackson.core.JsonParser jsonParser24 = jsonFactory16.createJsonParser(byteArray21, (int) (byte) -1, (int) (short) 0);
        int int26 = serializedString8.appendQuotedUTF8(byteArray21, 64);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter27 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter2, (com.fasterxml.jackson.core.SerializableString) serializedString8);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter29 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter("hi!");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter30 = defaultPrettyPrinter29.createInstance();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter31 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter(defaultPrettyPrinter30);
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter32 = new com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter();
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter lf2SpacesIndenter34 = lf2SpacesIndenter32.withLinefeed("");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter defaultPrettyPrinter35 = defaultPrettyPrinter30.withObjectIndenter((com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Indenter) lf2SpacesIndenter32);
        com.fasterxml.jackson.core.JsonFactory jsonFactory36 = new com.fasterxml.jackson.core.JsonFactory();
        com.fasterxml.jackson.core.JsonFactory jsonFactory37 = jsonFactory36.copy();
        java.lang.String str38 = jsonFactory37.getRootValueSeparator();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler39 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext42 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler39, (java.lang.Object) ' ', false);
        java.io.InputStream inputStream44 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec45 = null;
        com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer bytesToNameCanonicalizer46 = null;
        byte[] byteArray47 = com.fasterxml.jackson.core.json.UTF8JsonGenerator.HEX_CHARS;
        com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser51 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(iOContext42, (int) (short) -1, inputStream44, objectCodec45, bytesToNameCanonicalizer46, byteArray47, (int) (short) -1, (int) (byte) 0, false);
        com.fasterxml.jackson.core.Version version52 = uTF8StreamJsonParser51.version();
        com.fasterxml.jackson.core.JsonToken jsonToken53 = uTF8StreamJsonParser51.getLastClearedToken();
        java.io.Writer writer54 = java.io.Writer.nullWriter();
        int int55 = uTF8StreamJsonParser51.releaseBuffered(writer54);
        boolean boolean56 = uTF8StreamJsonParser51.hasCurrentToken();
        boolean boolean57 = uTF8StreamJsonParser51._tokenIncomplete;
        java.lang.String str58 = uTF8StreamJsonParser51.getCurrentName();
        int int60 = uTF8StreamJsonParser51._decodeCharForError((int) (byte) 0);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder61 = uTF8StreamJsonParser51._getByteArrayBuilder();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding62 = com.fasterxml.jackson.core.JsonEncoding.UTF32_BE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator63 = jsonFactory37.createJsonGenerator((java.io.OutputStream) byteArrayBuilder61, jsonEncoding62);
        jsonGenerator63.writeStringField("UTF-16LE", "/");
        jsonGenerator63.writeBooleanField("JSON", false);
        defaultPrettyPrinter35.writeObjectEntrySeparator(jsonGenerator63);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator71 = jsonGenerator63.useDefaultPrettyPrinter();
        jsonGenerator71.writeRaw("com.fasterxml.jackson.core.JsonParseException: \n at [Source:  ; line: 1, column: 1]");
        defaultPrettyPrinter2.beforeObjectEntries(jsonGenerator71);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter2);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertArrayEquals(byteArray9, new byte[] {});
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertNotNull(jsonFactory13);
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS + "'", feature14.equals(com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_YAML_COMMENTS));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertTrue("'" + feature17 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature17.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertArrayEquals(byteArray21, new byte[] { (byte) 0, (byte) 0 });
        org.junit.Assert.assertNotNull(jsonParser24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(defaultPrettyPrinter30);
        org.junit.Assert.assertNotNull(lf2SpacesIndenter34);
        org.junit.Assert.assertNotNull(defaultPrettyPrinter35);
        org.junit.Assert.assertNotNull(jsonFactory37);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + " " + "'", str38, " ");
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertArrayEquals(byteArray47, new byte[] { (byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 65, (byte) 66, (byte) 67, (byte) 68, (byte) 69, (byte) 70 });
        org.junit.Assert.assertNotNull(version52);
        org.junit.Assert.assertNull(jsonToken53);
        org.junit.Assert.assertNotNull(writer54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(byteArrayBuilder61);
        org.junit.Assert.assertTrue("'" + jsonEncoding62 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF32_BE + "'", jsonEncoding62.equals(com.fasterxml.jackson.core.JsonEncoding.UTF32_BE));
        org.junit.Assert.assertNotNull(jsonGenerator63);
        org.junit.Assert.assertNotNull(jsonGenerator71);
    }
}

