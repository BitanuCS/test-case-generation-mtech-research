package com.google.javascript.jscomp;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test1");
        com.google.javascript.jscomp.ControlFlowGraph<com.google.javascript.rhino.Node> nodeControlFlowGraph0 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        java.lang.String str3 = node2.getSourceFileName();
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.jscomp.Scope scope5 = new com.google.javascript.jscomp.Scope(node2, objectType4);
        com.google.javascript.rhino.jstype.StaticSlot<com.google.javascript.rhino.jstype.JSType> jSTypeStaticSlot7 = scope5.getOwnSlot("hi!");
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.rhino.Node node10 = compiler9.externAndJsRoot;
        compiler9.reportCodeChange();
        com.google.javascript.rhino.Node node13 = compiler9.parseTestCode("(Proxy)");
        com.google.javascript.jscomp.ReverseAbstractInterpreter reverseAbstractInterpreter14 = compiler9.getReverseAbstractInterpreter();
        // The following exception was thrown during execution in test generation
        try {
            com.google.javascript.jscomp.LiveVariablesAnalysis liveVariablesAnalysis15 = new com.google.javascript.jscomp.LiveVariablesAnalysis(nodeControlFlowGraph0, scope5, (com.google.javascript.jscomp.AbstractCompiler) compiler9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(jSTypeStaticSlot7);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter14);
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test2");
        com.google.javascript.jscomp.ControlFlowGraph<com.google.javascript.rhino.Node> nodeControlFlowGraph0 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        java.lang.String str3 = node2.getSourceFileName();
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.jscomp.Scope scope5 = new com.google.javascript.jscomp.Scope(node2, objectType4);
        boolean boolean6 = scope5.isLocal();
        java.util.Iterator<com.google.javascript.jscomp.Scope.Var> varItor7 = scope5.getDeclarativelyUnboundVarsWithoutTypes();
        java.io.PrintStream printStream8 = null;
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler(printStream8);
        com.google.javascript.rhino.Node node10 = compiler9.externAndJsRoot;
        compiler9.reportCodeChange();
        compiler9.resetUniqueNameId();
        com.google.javascript.jscomp.AbstractCompiler.LifeCycleStage lifeCycleStage13 = compiler9.getLifeCycleStage();
        boolean boolean14 = compiler9.precheck();
        com.google.javascript.jscomp.CodingConvention codingConvention15 = compiler9.defaultCodingConvention;
        // The following exception was thrown during execution in test generation
        try {
            com.google.javascript.jscomp.LiveVariablesAnalysis liveVariablesAnalysis16 = new com.google.javascript.jscomp.LiveVariablesAnalysis(nodeControlFlowGraph0, scope5, (com.google.javascript.jscomp.AbstractCompiler) compiler9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(varItor7);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + lifeCycleStage13 + "' != '" + com.google.javascript.jscomp.AbstractCompiler.LifeCycleStage.RAW + "'", lifeCycleStage13.equals(com.google.javascript.jscomp.AbstractCompiler.LifeCycleStage.RAW));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(codingConvention15);
    }
}

