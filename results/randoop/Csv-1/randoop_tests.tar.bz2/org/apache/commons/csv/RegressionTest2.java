package org.apache.commons.csv;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1001");
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "hi!" };
        org.apache.commons.csv.CSVFormat cSVFormat11 = new org.apache.commons.csv.CSVFormat(' ', 'a', 'a', '#', true, false, "hi!", strArray10);
        boolean boolean12 = cSVFormat11.isSurroundingSpacesIgnored();
        org.apache.commons.csv.CSVFormat cSVFormat14 = cSVFormat11.withEscape('#');
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader15 = null;
        org.apache.commons.csv.CSVLexer cSVLexer16 = new org.apache.commons.csv.CSVLexer(cSVFormat11, extendedBufferedReader15);
        java.lang.String str17 = cSVFormat11.toString();
        char char18 = cSVFormat11.getCommentStart();
        java.lang.String str19 = cSVFormat11.toString();
        char char20 = cSVFormat11.getDelimiter();
        char char21 = cSVFormat11.getDelimiter();
        java.lang.String[] strArray46 = new java.lang.String[] { "hi!", "", "hi!" };
        org.apache.commons.csv.CSVFormat cSVFormat47 = new org.apache.commons.csv.CSVFormat(' ', 'a', 'a', '#', true, false, "hi!", strArray46);
        org.apache.commons.csv.CSVFormat cSVFormat48 = new org.apache.commons.csv.CSVFormat('a', '#', '#', 'a', false, true, "hi!", strArray46);
        org.apache.commons.csv.CSVFormat cSVFormat49 = new org.apache.commons.csv.CSVFormat('4', '#', ' ', 'a', false, true, "Delimiter=<a> Escape=<a> Encapsulator=<#> CommentStart=<a> EmptyLines:ignored", strArray46);
        java.util.Map<java.lang.String, java.lang.Integer> strMap50 = null;
        org.apache.commons.csv.CSVRecord cSVRecord51 = new org.apache.commons.csv.CSVRecord(strArray46, strMap50);
        java.util.Spliterator<java.lang.String> strSpliterator52 = cSVRecord51.spliterator();
        java.lang.String[] strArray53 = cSVRecord51.values();
        org.apache.commons.csv.CSVFormat cSVFormat54 = cSVFormat11.withHeader(strArray53);
        java.io.Reader reader55 = java.io.Reader.nullReader();
        java.io.Reader reader56 = java.io.Reader.nullReader();
        char[] charArray59 = new char[] { '4', ' ' };
        int int60 = reader56.read(charArray59);
        char[] charArray61 = new char[] {};
        int int62 = reader56.read(charArray61);
        int int63 = reader55.read(charArray61);
        org.apache.commons.csv.CSVParser cSVParser64 = new org.apache.commons.csv.CSVParser(reader55);
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader65 = new org.apache.commons.csv.ExtendedBufferedReader(reader55);
        int int66 = extendedBufferedReader65.readAgain();
        int int67 = extendedBufferedReader65.lookAhead();
        org.apache.commons.csv.CSVLexer cSVLexer68 = new org.apache.commons.csv.CSVLexer(cSVFormat54, extendedBufferedReader65);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertArrayEquals(strArray10, new java.lang.String[] { "hi!", "", "hi!" });
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cSVFormat14);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "Delimiter=< > Escape=<#> Encapsulator=<a> CommentStart=<a> SurroundingSpaces:ignored" + "'", str17, "Delimiter=< > Escape=<#> Encapsulator=<a> CommentStart=<a> SurroundingSpaces:ignored");
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + 'a' + "'", char18 == 'a');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "Delimiter=< > Escape=<#> Encapsulator=<a> CommentStart=<a> SurroundingSpaces:ignored" + "'", str19, "Delimiter=< > Escape=<#> Encapsulator=<a> CommentStart=<a> SurroundingSpaces:ignored");
        org.junit.Assert.assertTrue("'" + char20 + "' != '" + ' ' + "'", char20 == ' ');
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + ' ' + "'", char21 == ' ');
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertArrayEquals(strArray46, new java.lang.String[] { "hi!", "", "hi!" });
        org.junit.Assert.assertNotNull(strSpliterator52);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertArrayEquals(strArray53, new java.lang.String[] { "hi!", "", "hi!" });
        org.junit.Assert.assertNotNull(cSVFormat54);
        org.junit.Assert.assertNotNull(reader55);
        org.junit.Assert.assertNotNull(reader56);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertArrayEquals(charArray59, new char[] { '4', ' ' });
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(charArray61);
        org.junit.Assert.assertArrayEquals(charArray61, new char[] {});
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-2) + "'", int66 == (-2));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
    }

    @Test
    public void test1002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1002");
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "hi!" };
        org.apache.commons.csv.CSVFormat cSVFormat11 = new org.apache.commons.csv.CSVFormat(' ', 'a', 'a', '#', true, false, "hi!", strArray10);
        boolean boolean12 = cSVFormat11.isSurroundingSpacesIgnored();
        org.apache.commons.csv.CSVFormat cSVFormat14 = cSVFormat11.withEscape('#');
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader15 = null;
        org.apache.commons.csv.CSVLexer cSVLexer16 = new org.apache.commons.csv.CSVLexer(cSVFormat11, extendedBufferedReader15);
        java.lang.String str17 = cSVFormat11.toString();
        char char18 = cSVFormat11.getCommentStart();
        java.lang.String str19 = cSVFormat11.getLineSeparator();
        org.apache.commons.csv.CSVFormat cSVFormat21 = cSVFormat11.withEncapsulator('#');
        java.io.Reader reader22 = java.io.Reader.nullReader();
        java.io.Reader reader23 = java.io.Reader.nullReader();
        char[] charArray26 = new char[] { '4', ' ' };
        int int27 = reader23.read(charArray26);
        char[] charArray28 = new char[] {};
        int int29 = reader23.read(charArray28);
        int int30 = reader22.read(charArray28);
        org.apache.commons.csv.CSVParser cSVParser31 = new org.apache.commons.csv.CSVParser(reader22);
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader32 = new org.apache.commons.csv.ExtendedBufferedReader(reader22);
        boolean boolean33 = extendedBufferedReader32.markSupported();
        long long35 = extendedBufferedReader32.skip((long) (byte) 10);
        org.apache.commons.csv.CSVLexer cSVLexer36 = new org.apache.commons.csv.CSVLexer(cSVFormat11, extendedBufferedReader32);
        boolean boolean38 = cSVLexer36.isEndOfLine((int) '4');
        boolean boolean40 = cSVLexer36.isEndOfFile((int) '\ufffe');
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader41 = cSVLexer36.in;
        boolean boolean43 = cSVLexer36.isDelimiter(1);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertArrayEquals(strArray10, new java.lang.String[] { "hi!", "", "hi!" });
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cSVFormat14);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "Delimiter=< > Escape=<#> Encapsulator=<a> CommentStart=<a> SurroundingSpaces:ignored" + "'", str17, "Delimiter=< > Escape=<#> Encapsulator=<a> CommentStart=<a> SurroundingSpaces:ignored");
        org.junit.Assert.assertTrue("'" + char18 + "' != '" + 'a' + "'", char18 == 'a');
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "hi!" + "'", str19, "hi!");
        org.junit.Assert.assertNotNull(cSVFormat21);
        org.junit.Assert.assertNotNull(reader22);
        org.junit.Assert.assertNotNull(reader23);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertArrayEquals(charArray26, new char[] { '4', ' ' });
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertArrayEquals(charArray28, new char[] {});
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(extendedBufferedReader41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test1003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1003");
        org.apache.commons.csv.CSVFormat cSVFormat0 = org.apache.commons.csv.CSVFormat.DEFAULT;
        java.io.Reader reader1 = java.io.Reader.nullReader();
        java.io.Reader reader2 = java.io.Reader.nullReader();
        char[] charArray5 = new char[] { '4', ' ' };
        int int6 = reader2.read(charArray5);
        char[] charArray7 = new char[] {};
        int int8 = reader2.read(charArray7);
        int int9 = reader1.read(charArray7);
        org.apache.commons.csv.CSVParser cSVParser10 = new org.apache.commons.csv.CSVParser(reader1);
        java.lang.Iterable<org.apache.commons.csv.CSVRecord> cSVRecordIterable11 = cSVFormat0.parse(reader1);
        java.io.Reader reader12 = java.io.Reader.nullReader();
        java.io.Reader reader13 = java.io.Reader.nullReader();
        char[] charArray16 = new char[] { '4', ' ' };
        int int17 = reader13.read(charArray16);
        char[] charArray18 = new char[] {};
        int int19 = reader13.read(charArray18);
        int int20 = reader12.read(charArray18);
        org.apache.commons.csv.CSVParser cSVParser21 = new org.apache.commons.csv.CSVParser(reader12);
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader22 = new org.apache.commons.csv.ExtendedBufferedReader(reader12);
        boolean boolean23 = extendedBufferedReader22.markSupported();
        int int24 = extendedBufferedReader22.lookAhead();
        java.lang.String str25 = extendedBufferedReader22.readLine();
        extendedBufferedReader22.reset();
        boolean boolean27 = extendedBufferedReader22.markSupported();
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "hi!" };
        org.apache.commons.csv.CSVFormat cSVFormat39 = new org.apache.commons.csv.CSVFormat(' ', 'a', 'a', '#', true, false, "hi!", strArray38);
        boolean boolean40 = cSVFormat39.isSurroundingSpacesIgnored();
        org.apache.commons.csv.CSVFormat cSVFormat42 = cSVFormat39.withEscape('#');
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader43 = null;
        org.apache.commons.csv.CSVLexer cSVLexer44 = new org.apache.commons.csv.CSVLexer(cSVFormat39, extendedBufferedReader43);
        java.lang.String str45 = cSVFormat39.toString();
        org.apache.commons.csv.CSVFormat cSVFormat47 = cSVFormat39.withEncapsulator('4');
        org.apache.commons.csv.CSVParser cSVParser48 = new org.apache.commons.csv.CSVParser((java.io.Reader) extendedBufferedReader22, cSVFormat47);
        org.apache.commons.csv.CSVLexer cSVLexer49 = new org.apache.commons.csv.CSVLexer(cSVFormat0, extendedBufferedReader22);
        boolean boolean51 = cSVLexer49.isWhitespace((int) '#');
        boolean boolean53 = cSVLexer49.isEndOfFile(3);
        boolean boolean55 = cSVLexer49.isEscape((int) (short) 100);
        org.junit.Assert.assertNotNull(cSVFormat0);
        org.junit.Assert.assertNotNull(reader1);
        org.junit.Assert.assertNotNull(reader2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertArrayEquals(charArray5, new char[] { '4', ' ' });
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertArrayEquals(charArray7, new char[] {});
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(cSVRecordIterable11);
        org.junit.Assert.assertNotNull(reader12);
        org.junit.Assert.assertNotNull(reader13);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertArrayEquals(charArray16, new char[] { '4', ' ' });
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertArrayEquals(charArray18, new char[] {});
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertArrayEquals(strArray38, new java.lang.String[] { "hi!", "", "hi!" });
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(cSVFormat42);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "Delimiter=< > Escape=<#> Encapsulator=<a> CommentStart=<a> SurroundingSpaces:ignored" + "'", str45, "Delimiter=< > Escape=<#> Encapsulator=<a> CommentStart=<a> SurroundingSpaces:ignored");
        org.junit.Assert.assertNotNull(cSVFormat47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test1004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1004");
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "hi!" };
        org.apache.commons.csv.CSVFormat cSVFormat11 = new org.apache.commons.csv.CSVFormat(' ', 'a', 'a', '#', true, false, "hi!", strArray10);
        boolean boolean12 = cSVFormat11.isSurroundingSpacesIgnored();
        org.apache.commons.csv.CSVFormat cSVFormat14 = cSVFormat11.withDelimiter('4');
        org.apache.commons.csv.CSVFormat cSVFormat15 = org.apache.commons.csv.CSVFormat.EXCEL;
        java.io.Reader reader16 = java.io.Reader.nullReader();
        java.io.Reader reader17 = java.io.Reader.nullReader();
        char[] charArray20 = new char[] { '4', ' ' };
        int int21 = reader17.read(charArray20);
        char[] charArray22 = new char[] {};
        int int23 = reader17.read(charArray22);
        int int24 = reader16.read(charArray22);
        org.apache.commons.csv.CSVParser cSVParser25 = new org.apache.commons.csv.CSVParser(reader16);
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader26 = new org.apache.commons.csv.ExtendedBufferedReader(reader16);
        java.lang.Iterable<org.apache.commons.csv.CSVRecord> cSVRecordIterable27 = cSVFormat15.parse((java.io.Reader) extendedBufferedReader26);
        java.lang.String str28 = extendedBufferedReader26.readLine();
        boolean boolean29 = extendedBufferedReader26.markSupported();
        extendedBufferedReader26.close();
        org.apache.commons.csv.CSVLexer cSVLexer31 = new org.apache.commons.csv.CSVLexer(cSVFormat14, extendedBufferedReader26);
        boolean boolean32 = extendedBufferedReader26.markSupported();
        org.apache.commons.csv.CSVFormat cSVFormat33 = org.apache.commons.csv.CSVFormat.EXCEL;
        java.io.Reader reader34 = java.io.Reader.nullReader();
        java.io.Reader reader35 = java.io.Reader.nullReader();
        char[] charArray38 = new char[] { '4', ' ' };
        int int39 = reader35.read(charArray38);
        char[] charArray40 = new char[] {};
        int int41 = reader35.read(charArray40);
        int int42 = reader34.read(charArray40);
        org.apache.commons.csv.CSVParser cSVParser43 = new org.apache.commons.csv.CSVParser(reader34);
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader44 = new org.apache.commons.csv.ExtendedBufferedReader(reader34);
        java.lang.Iterable<org.apache.commons.csv.CSVRecord> cSVRecordIterable45 = cSVFormat33.parse((java.io.Reader) extendedBufferedReader44);
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader46 = new org.apache.commons.csv.ExtendedBufferedReader((java.io.Reader) extendedBufferedReader44);
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader47 = new org.apache.commons.csv.ExtendedBufferedReader((java.io.Reader) extendedBufferedReader44);
        java.io.Reader reader48 = java.io.Reader.nullReader();
        java.io.Reader reader49 = java.io.Reader.nullReader();
        char[] charArray52 = new char[] { '4', ' ' };
        int int53 = reader49.read(charArray52);
        char[] charArray54 = new char[] {};
        int int55 = reader49.read(charArray54);
        int int56 = reader48.read(charArray54);
        org.apache.commons.csv.CSVParser cSVParser57 = new org.apache.commons.csv.CSVParser(reader48);
        org.apache.commons.csv.ExtendedBufferedReader extendedBufferedReader58 = new org.apache.commons.csv.ExtendedBufferedReader(reader48);
        boolean boolean59 = extendedBufferedReader58.markSupported();
        int int60 = extendedBufferedReader58.lookAhead();
        org.apache.commons.csv.CSVParser cSVParser61 = new org.apache.commons.csv.CSVParser((java.io.Reader) extendedBufferedReader58);
        java.io.Reader reader62 = java.io.Reader.nullReader();
        java.io.Reader reader63 = java.io.Reader.nullReader();
        char[] charArray66 = new char[] { '4', ' ' };
        int int67 = reader63.read(charArray66);
        char[] charArray68 = new char[] {};
        int int69 = reader63.read(charArray68);
        int int70 = reader62.read(charArray68);
        org.apache.commons.csv.CSVParser cSVParser71 = new org.apache.commons.csv.CSVParser(reader62);
        java.io.Reader reader72 = java.io.Reader.nullReader();
        char[] charArray75 = new char[] { '4', ' ' };
        int int76 = reader72.read(charArray75);
        char[] charArray77 = new char[] {};
        int int78 = reader72.read(charArray77);
        int int79 = reader62.read(charArray77);
        int int80 = extendedBufferedReader58.read(charArray77);
        int int81 = extendedBufferedReader44.read(charArray77);
        int int82 = extendedBufferedReader26.read(charArray77);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertArrayEquals(strArray10, new java.lang.String[] { "hi!", "", "hi!" });
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cSVFormat14);
        org.junit.Assert.assertNotNull(cSVFormat15);
        org.junit.Assert.assertNotNull(reader16);
        org.junit.Assert.assertNotNull(reader17);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertArrayEquals(charArray20, new char[] { '4', ' ' });
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertArrayEquals(charArray22, new char[] {});
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(cSVRecordIterable27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(cSVFormat33);
        org.junit.Assert.assertNotNull(reader34);
        org.junit.Assert.assertNotNull(reader35);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertArrayEquals(charArray38, new char[] { '4', ' ' });
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertArrayEquals(charArray40, new char[] {});
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(cSVRecordIterable45);
        org.junit.Assert.assertNotNull(reader48);
        org.junit.Assert.assertNotNull(reader49);
        org.junit.Assert.assertNotNull(charArray52);
        org.junit.Assert.assertArrayEquals(charArray52, new char[] { '4', ' ' });
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertArrayEquals(charArray54, new char[] {});
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(reader62);
        org.junit.Assert.assertNotNull(reader63);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertArrayEquals(charArray66, new char[] { '4', ' ' });
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(charArray68);
        org.junit.Assert.assertArrayEquals(charArray68, new char[] {});
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(reader72);
        org.junit.Assert.assertNotNull(charArray75);
        org.junit.Assert.assertArrayEquals(charArray75, new char[] { '4', ' ' });
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(charArray77);
        org.junit.Assert.assertArrayEquals(charArray77, new char[] {});
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }
}

