package com.google.gson.internal.bind;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.gson.FieldNamingPolicy fieldNamingPolicy0 = com.google.gson.FieldNamingPolicy.IDENTITY;
        org.junit.Assert.assertNotNull(fieldNamingPolicy0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.io.Writer writer4 = null;
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter3.toJson(writer4, (java.lang.Object) dateTypeAdapter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.stream.JsonReader jsonReader4 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = typeAdapterFactoryArrayTypeAdapter3.read(jsonReader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.Object obj4 = null;
        java.lang.Appendable appendable5 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson(obj4, appendable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Number> numberTypeAdapter4 = com.google.gson.internal.bind.TypeAdapters.DOUBLE;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement5 = typeAdapterFactoryArrayTypeAdapter3.toJsonTree((java.lang.Object) numberTypeAdapter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(numberTypeAdapter4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonArray jsonArray5 = new com.google.gson.JsonArray();
        jsonArray5.add((java.lang.Boolean) false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = typeAdapterFactoryArrayTypeAdapter3.toJson((java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter4 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter4.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.UUID_FACTORY;
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter3.write(jsonWriter6, (java.lang.Object) typeAdapterFactory7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.stream.JsonWriter jsonWriter4 = null;
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter7 = dateTypeAdapter6.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter8 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter9 = sqlDateTypeAdapter8.nullSafe();
        com.google.gson.JsonNull jsonNull10 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date11 = dateTypeAdapter9.fromJsonTree((com.google.gson.JsonElement) jsonNull10);
        boolean boolean13 = jsonNull10.equals((java.lang.Object) 1L);
        java.sql.Date date14 = dateTypeAdapter6.fromJsonTree((com.google.gson.JsonElement) jsonNull10);
        java.sql.Date date15 = null;
        com.google.gson.JsonElement jsonElement16 = dateTypeAdapter6.toJsonTree(date15);
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter3.write(jsonWriter4, (java.lang.Object) dateTypeAdapter6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(dateTypeAdapter7);
        org.junit.Assert.assertNotNull(dateTypeAdapter9);
        org.junit.Assert.assertNotNull(jsonNull10);
        org.junit.Assert.assertNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(date14);
        org.junit.Assert.assertNotNull(jsonElement16);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.internal.LazilyParsedNumber lazilyParsedNumber5 = new com.google.gson.internal.LazilyParsedNumber("hi!");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str6 = sqlDateTypeAdapterArrayTypeAdapter3.toJson((java.lang.Object) lazilyParsedNumber5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = sqlDateTypeAdapterArrayTypeAdapter3.fromJson("? extends ? super com.google.gson.JsonIOException");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter8.value("");
        com.google.gson.internal.Excluder excluder13 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.internal.Excluder excluder14 = excluder13.disableInnerClassSerialization();
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter3.write(jsonWriter8, (java.lang.Object) excluder14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNotNull(excluder13);
        org.junit.Assert.assertNotNull(excluder14);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.io.Writer writer4 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter5 = gson0.newJsonWriter(writer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger8 = jsonPrimitive7.getAsBigInteger();
        java.lang.String str9 = gson0.toJson((java.lang.Object) bigInteger8);
        java.io.Writer writer10 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter11 = gson0.newJsonWriter(writer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "100" + "'", str9, "100");
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = objTypeAdapter4.fromJson("false");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.FieldNamingPolicy fieldNamingPolicy6 = com.google.gson.FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES;
        java.lang.Appendable appendable7 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) fieldNamingPolicy6, appendable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(fieldNamingPolicy6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.io.Writer writer4 = null;
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonTreeWriter5.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter5.value("com.google.gson.JsonIOException: ");
        // The following exception was thrown during execution in test generation
        try {
            sqlDateTypeAdapterArrayTypeAdapter3.toJson(writer4, (java.lang.Object) jsonTreeWriter5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonWriter7);
        org.junit.Assert.assertNotNull(jsonWriter9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement5 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy4);
        com.google.gson.JsonObject jsonObject6 = new com.google.gson.JsonObject();
        boolean boolean8 = jsonObject6.has("");
        java.lang.Object obj9 = null;
        boolean boolean10 = jsonObject6.equals(obj9);
        java.lang.Appendable appendable11 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonObject6, appendable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger8 = jsonPrimitive7.getAsBigInteger();
        java.lang.String str9 = gson0.toJson((java.lang.Object) bigInteger8);
        byte byte10 = bigInteger8.byteValue();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "100" + "'", str9, "100");
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.io.Reader reader4 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = sqlDateTypeAdapterArrayTypeAdapter3.fromJson(reader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonObject jsonObject5 = new com.google.gson.JsonObject();
        boolean boolean7 = jsonObject5.has("");
        com.google.gson.JsonPrimitive jsonPrimitive9 = jsonObject5.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader10 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject5);
        jsonTreeReader10.close();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JsonReader is closed");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jsonPrimitive9);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        java.io.Writer writer5 = null;
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter7 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson6, sqlDateTypeAdapterTypeAdapter7, sqlDateTypeAdapterClass8);
        // The following exception was thrown during execution in test generation
        try {
            sqlDateTypeAdapterArrayTypeAdapter3.toJson(writer5, (java.lang.Object) sqlDateTypeAdapterClass8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonTreeWriter5.endArray();
        jsonWriter7.setIndent("null");
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter3.write(jsonWriter7, (java.lang.Object) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonElement jsonElement4 = null;
        java.lang.Appendable appendable5 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson(jsonElement4, appendable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = typeAdapterFactoryArrayTypeAdapter3.fromJson("$");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        java.io.Writer writer10 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter11 = gson0.newJsonWriter(writer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = objTypeAdapter4.nullSafe();
        java.io.Writer writer6 = null;
        java.lang.Object obj7 = null;
        // The following exception was thrown during execution in test generation
        try {
            objTypeAdapter5.toJson(writer6, obj7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = objTypeAdapter4.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = objTypeAdapter5.fromJson("hi!");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonObject jsonObject4 = new com.google.gson.JsonObject();
        boolean boolean6 = jsonObject4.has("");
        jsonObject4.addProperty("", (java.lang.Number) (short) 10);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet10 = jsonObject4.entrySet();
        java.lang.Appendable appendable11 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) jsonObject4, appendable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strEntrySet10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean4 = jsonPrimitive2.equals((java.lang.Object) typeAdapterFactory3);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2, jsonWriter8);
        com.google.gson.JsonArray jsonArray12 = new com.google.gson.JsonArray();
        jsonArray12.add((java.lang.Number) 10);
        boolean boolean15 = jsonArray12.getAsBoolean();
        java.math.BigInteger bigInteger16 = jsonArray12.getAsBigInteger();
        java.lang.reflect.Type type17 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray12, type17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement5 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy4);
        boolean boolean6 = jsonElement5.isJsonObject();
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean4 = jsonPrimitive2.equals((java.lang.Object) typeAdapterFactory3);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2, jsonWriter8);
        com.google.gson.TypeAdapter<java.lang.StringBuffer> stringBufferTypeAdapter12 = com.google.gson.internal.bind.TypeAdapters.STRING_BUFFER;
        java.lang.Appendable appendable13 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) stringBufferTypeAdapter12, appendable13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(stringBufferTypeAdapter12);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        com.google.gson.stream.MalformedJsonException malformedJsonException5 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonIOException3);
        java.lang.String str6 = jsonIOException3.toString();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "com.google.gson.JsonIOException: " + "'", str6, "com.google.gson.JsonIOException: ");
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.io.Reader reader4 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = typeAdapterFactoryArrayTypeAdapter3.fromJson(reader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        java.lang.Throwable throwable9 = null;
        com.google.gson.JsonIOException jsonIOException10 = new com.google.gson.JsonIOException("", throwable9);
        com.google.gson.stream.MalformedJsonException malformedJsonException11 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException10);
        com.google.gson.JsonIOException jsonIOException12 = new com.google.gson.JsonIOException("false", (java.lang.Throwable) malformedJsonException11);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement13 = sqlDateTypeAdapterArrayTypeAdapter3.toJsonTree((java.lang.Object) malformedJsonException11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        jsonArray4.add((java.lang.Number) 10);
        boolean boolean7 = jsonArray4.getAsBoolean();
        java.math.BigInteger bigInteger8 = jsonArray4.getAsBigInteger();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive("null");
        boolean boolean11 = jsonArray4.contains((com.google.gson.JsonElement) jsonPrimitive10);
        com.google.gson.internal.LazilyParsedNumber lazilyParsedNumber13 = new com.google.gson.internal.LazilyParsedNumber("hi!");
        java.lang.Class<?> wildcardClass14 = lazilyParsedNumber13.getClass();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.internal.LazilyParsedNumber lazilyParsedNumber15 = gson0.fromJson((com.google.gson.JsonElement) jsonArray4, (java.lang.reflect.Type) wildcardClass14);
            org.junit.Assert.fail("Expected exception of type com.google.gson.JsonSyntaxException; message: java.lang.IllegalStateException: Expected BEGIN_OBJECT but was BEGIN_ARRAY");
        } catch (com.google.gson.JsonSyntaxException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonObject jsonObject4 = new com.google.gson.JsonObject();
        boolean boolean6 = jsonObject4.has("");
        com.google.gson.JsonPrimitive jsonPrimitive8 = jsonObject4.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader9 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject4);
        com.google.gson.stream.JsonToken jsonToken10 = jsonTreeReader9.peek();
        jsonTreeReader9.skipValue();
        com.google.gson.stream.JsonToken jsonToken12 = jsonTreeReader9.peek();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jsonPrimitive8);
        org.junit.Assert.assertTrue("'" + jsonToken10 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_OBJECT + "'", jsonToken10.equals(com.google.gson.stream.JsonToken.BEGIN_OBJECT));
        org.junit.Assert.assertTrue("'" + jsonToken12 + "' != '" + com.google.gson.stream.JsonToken.END_DOCUMENT + "'", jsonToken12.equals(com.google.gson.stream.JsonToken.END_DOCUMENT));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement5 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy4);
        com.google.gson.JsonObject jsonObject6 = new com.google.gson.JsonObject();
        boolean boolean8 = jsonObject6.has("");
        com.google.gson.JsonArray jsonArray10 = jsonObject6.getAsJsonArray("");
        java.lang.Appendable appendable11 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonObject6, appendable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(jsonArray10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean4 = jsonPrimitive2.equals((java.lang.Object) typeAdapterFactory3);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2, jsonWriter8);
        com.google.gson.JsonPrimitive jsonPrimitive13 = new com.google.gson.JsonPrimitive((java.lang.Character) ' ');
        boolean boolean14 = jsonPrimitive13.isString();
        java.lang.Appendable appendable15 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive13, appendable15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = charSequenceArrayTypeAdapter6.fromJson("{}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BEGIN_OBJECT at line 1 column 2 path $");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add("hi!");
        char char9 = jsonArray6.getAsCharacter();
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean13 = jsonPrimitive12.isBoolean();
        com.google.gson.JsonElement jsonElement14 = jsonArray6.set((int) (byte) 0, (com.google.gson.JsonElement) jsonPrimitive12);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter15 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter16 = sqlDateTypeAdapter15.nullSafe();
        java.sql.Date date17 = null;
        com.google.gson.JsonElement jsonElement18 = sqlDateTypeAdapter15.toJsonTree(date17);
        boolean boolean19 = jsonArray6.contains(jsonElement18);
        int int20 = jsonArray6.size();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = objTypeAdapter5.fromJsonTree((com.google.gson.JsonElement) jsonArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
        org.junit.Assert.assertTrue("'" + char9 + "' != '" + 'h' + "'", char9 == 'h');
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jsonElement14);
        org.junit.Assert.assertNotNull(dateTypeAdapter16);
        org.junit.Assert.assertNotNull(jsonElement18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray12 = jsonObject10.getAsJsonArray("com.google.gson.JsonIOException");
        java.lang.String str13 = gson0.toJson((com.google.gson.JsonElement) jsonObject10);
        java.io.Reader reader14 = null;
        java.lang.reflect.Type type15 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.math.BigInteger bigInteger16 = gson0.fromJson(reader14, type15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(jsonArray12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "{}" + "'", str13, "{}");
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        jsonArray4.add("hi!");
        char char7 = jsonArray4.getAsCharacter();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean11 = jsonPrimitive10.isBoolean();
        com.google.gson.JsonElement jsonElement12 = jsonArray4.set((int) (byte) 0, (com.google.gson.JsonElement) jsonPrimitive10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = typeAdapterFactoryArrayTypeAdapter3.toJson((java.lang.Object) jsonArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'h' + "'", char7 == 'h');
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jsonElement12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean4 = jsonPrimitive2.equals((java.lang.Object) typeAdapterFactory3);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2, jsonWriter8);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter12 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter12.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter15 = jsonTreeWriter12.value(true);
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter12.value(true);
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter12.value(false);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter12.value("10");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str22 = gson0.toJson((java.lang.Object) jsonTreeWriter12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: class com.google.gson.internal.bind.JsonTreeWriter declares multiple JSON fields named stack");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(jsonWriter15);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonObject jsonObject4 = new com.google.gson.JsonObject();
        boolean boolean6 = jsonObject4.has("");
        jsonObject4.addProperty("", (java.lang.Number) (short) 10);
        jsonObject4.addProperty("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>", "\"false\"");
        java.lang.Appendable appendable13 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonObject4, appendable13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonElement jsonElement1 = null;
        java.lang.Appendable appendable2 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson(jsonElement1, appendable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        java.io.Writer writer5 = null;
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        // The following exception was thrown during execution in test generation
        try {
            objTypeAdapter4.toJson(writer5, (java.lang.Object) jsonPrimitive7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.JsonPrimitive jsonPrimitive20 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str21 = jsonPrimitive20.getAsString();
        java.lang.Appendable appendable22 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive20, appendable22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "false" + "'", str21, "false");
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonObject jsonObject10 = jsonElement8.getAsJsonObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Not a JSON Object: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        java.io.Writer writer7 = null;
        com.google.gson.internal.LazilyParsedNumber lazilyParsedNumber9 = new com.google.gson.internal.LazilyParsedNumber("hi!");
        java.lang.String str10 = lazilyParsedNumber9.toString();
        java.lang.Object obj11 = null;
        boolean boolean12 = lazilyParsedNumber9.equals(obj11);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter13 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter14 = sqlDateTypeAdapter13.nullSafe();
        java.sql.Date date15 = null;
        com.google.gson.JsonElement jsonElement16 = sqlDateTypeAdapter13.toJsonTree(date15);
        boolean boolean17 = lazilyParsedNumber9.equals((java.lang.Object) jsonElement16);
        // The following exception was thrown during execution in test generation
        try {
            charSequenceArrayTypeAdapter6.toJson(writer7, (java.lang.Object) jsonElement16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "hi!" + "'", str10, "hi!");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTypeAdapter14);
        org.junit.Assert.assertNotNull(jsonElement16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement5 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy4);
        com.google.gson.JsonElement jsonElement7 = longSerializationPolicy4.serialize((java.lang.Long) 1L);
        boolean boolean8 = jsonElement7.isJsonObject();
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertNotNull(jsonElement7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonObject jsonObject4 = new com.google.gson.JsonObject();
        boolean boolean6 = jsonObject4.has("");
        java.lang.Object obj7 = null;
        boolean boolean8 = jsonObject4.equals(obj7);
        jsonObject4.addProperty("false", (java.lang.Number) 10.0f);
        java.lang.Appendable appendable12 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonObject4, appendable12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.Object obj6 = null;
        java.lang.reflect.Type type7 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree(obj6, type7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger10 = jsonPrimitive9.getAsBigInteger();
        float float11 = jsonPrimitive9.getAsFloat();
        java.math.BigDecimal bigDecimal12 = jsonPrimitive9.getAsBigDecimal();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = objTypeAdapter7.fromJsonTree((com.google.gson.JsonElement) jsonPrimitive9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was NUMBER");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertNotNull(bigDecimal12);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = charSequenceArrayTypeAdapter6.fromJson("com.google.gson.JsonSyntaxException: com.google.gson.JsonParseException: ? extends ? super com.google.gson.JsonIOException");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement5 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy4);
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory9 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean10 = jsonPrimitive8.equals((java.lang.Object) typeAdapterFactory9);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter11 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonTreeWriter11.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter11.value(true);
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonWriter14.value(true);
        gson6.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter14);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str18 = gson0.toJson((java.lang.Object) jsonWriter14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: class com.google.gson.internal.bind.JsonTreeWriter declares multiple JSON fields named stack");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertNotNull(typeAdapterFactory9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertNotNull(jsonWriter16);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter4 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        java.sql.Time time9 = null;
        timeTypeAdapter4.write(jsonWriter8, time9);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter11 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonTreeWriter11.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter11.value(true);
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter11.value(true);
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter11.value(false);
        java.sql.Time time19 = null;
        timeTypeAdapter4.write(jsonWriter18, time19);
        com.google.gson.JsonPrimitive jsonPrimitive22 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter3.write(jsonWriter18, (java.lang.Object) jsonPrimitive22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(jsonWriter18);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonObject jsonObject4 = new com.google.gson.JsonObject();
        boolean boolean6 = jsonObject4.has("");
        com.google.gson.JsonPrimitive jsonPrimitive8 = jsonObject4.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader9 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject4);
        com.google.gson.stream.JsonToken jsonToken10 = jsonTreeReader9.peek();
        jsonTreeReader9.skipValue();
        com.google.gson.stream.JsonToken jsonToken12 = jsonTreeReader9.peek();
        jsonTreeReader9.close();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JsonReader is closed");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jsonPrimitive8);
        org.junit.Assert.assertTrue("'" + jsonToken10 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_OBJECT + "'", jsonToken10.equals(com.google.gson.stream.JsonToken.BEGIN_OBJECT));
        org.junit.Assert.assertTrue("'" + jsonToken12 + "' != '" + com.google.gson.stream.JsonToken.END_DOCUMENT + "'", jsonToken12.equals(com.google.gson.stream.JsonToken.END_DOCUMENT));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterTypeAdapter19 = null;
        java.lang.Class<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter>(gson0, timeTypeAdapterTypeAdapter19, timeTypeAdapterClass20);
        java.io.Writer writer22 = null;
        com.google.gson.Gson gson23 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter24 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass25 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter26 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson23, typeAdapterFactoryTypeAdapter24, typeAdapterFactoryClass25);
        java.lang.String str27 = gson23.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter28 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter29 = sqlDateTypeAdapter28.nullSafe();
        java.sql.Date date30 = null;
        com.google.gson.JsonElement jsonElement31 = sqlDateTypeAdapter28.toJsonTree(date30);
        com.google.gson.JsonElement jsonElement32 = gson23.toJsonTree((java.lang.Object) jsonElement31);
        // The following exception was thrown during execution in test generation
        try {
            timeTypeAdapterArrayTypeAdapter21.toJson(writer22, (java.lang.Object) jsonElement31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertNotNull(dateTypeAdapter29);
        org.junit.Assert.assertNotNull(jsonElement31);
        org.junit.Assert.assertNotNull(jsonElement32);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean4 = jsonPrimitive2.equals((java.lang.Object) typeAdapterFactory3);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2, jsonWriter8);
        com.google.gson.JsonPrimitive jsonPrimitive13 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.Appendable appendable14 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive13, appendable14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        jsonArray4.add((java.lang.Number) 10);
        boolean boolean7 = jsonArray4.getAsBoolean();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = typeAdapterFactoryArrayTypeAdapter3.fromJsonTree((com.google.gson.JsonElement) jsonArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonObject jsonObject4 = new com.google.gson.JsonObject();
        boolean boolean6 = jsonObject4.has("");
        com.google.gson.JsonPrimitive jsonPrimitive8 = jsonObject4.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader9 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject4);
        com.google.gson.stream.JsonToken jsonToken10 = jsonTreeReader9.peek();
        java.lang.String str11 = jsonTreeReader9.toString();
        boolean boolean12 = jsonTreeReader9.hasNext();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jsonPrimitive8);
        org.junit.Assert.assertTrue("'" + jsonToken10 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_OBJECT + "'", jsonToken10.equals(com.google.gson.stream.JsonToken.BEGIN_OBJECT));
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "JsonTreeReader" + "'", str11, "JsonTreeReader");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        // The following exception was thrown during execution in test generation
        try {
            int int20 = jsonTreeReader19.nextInt();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NUMBER but was BEGIN_ARRAY");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        // The following exception was thrown during execution in test generation
        try {
            double double19 = jsonArray11.getAsDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.JsonElement jsonElement5 = null;
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter6 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter7 = sqlDateTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter8 = sqlDateTypeAdapter6.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter9 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonTreeWriter9.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter9.endArray();
        jsonTreeWriter9.flush();
        java.sql.Date date13 = null;
        sqlDateTypeAdapter6.write((com.google.gson.stream.JsonWriter) jsonTreeWriter9, date13);
        jsonTreeWriter9.flush();
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter9.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter9.name("[10,true]");
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter9.nullValue();
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson(jsonElement5, (com.google.gson.stream.JsonWriter) jsonTreeWriter9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter7);
        org.junit.Assert.assertNotNull(dateTypeAdapter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter19);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonObject jsonObject5 = new com.google.gson.JsonObject();
        boolean boolean7 = jsonObject5.has("");
        com.google.gson.JsonPrimitive jsonPrimitive9 = jsonObject5.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader10 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject5);
        jsonTreeReader10.skipValue();
        java.lang.String str12 = jsonTreeReader10.getPath();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jsonPrimitive9);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "$" + "'", str12, "$");
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.gson.Gson gson1 = new com.google.gson.Gson();
        java.lang.Throwable throwable3 = null;
        com.google.gson.JsonIOException jsonIOException4 = new com.google.gson.JsonIOException("", throwable3);
        java.lang.String str5 = gson1.toJson((java.lang.Object) jsonIOException4);
        com.google.gson.JsonIOException jsonIOException6 = new com.google.gson.JsonIOException("com.google.gson.JsonSyntaxException: hi!", (java.lang.Throwable) jsonIOException4);
        java.lang.String str7 = jsonIOException4.toString();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str5, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "com.google.gson.JsonIOException: " + "'", str7, "com.google.gson.JsonIOException: ");
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.stream.JsonWriter jsonWriter4 = null;
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonTreeWriter5.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter5.value("com.google.gson.JsonIOException: ");
        boolean boolean10 = jsonWriter9.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonWriter9.nullValue();
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter3.write(jsonWriter4, (java.lang.Object) jsonWriter11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonWriter7);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jsonWriter11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger8 = jsonPrimitive7.getAsBigInteger();
        java.lang.String str9 = gson0.toJson((java.lang.Object) bigInteger8);
        java.lang.String str10 = gson0.toString();
        com.google.gson.Gson gson11 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter12 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass13 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter14 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson11, sqlDateTypeAdapterTypeAdapter12, sqlDateTypeAdapterClass13);
        com.google.gson.JsonNull jsonNull15 = new com.google.gson.JsonNull();
        java.lang.String str16 = gson11.toJson((com.google.gson.JsonElement) jsonNull15);
        java.lang.String str17 = gson0.toJson((com.google.gson.JsonElement) jsonNull15);
        com.google.gson.JsonObject jsonObject18 = new com.google.gson.JsonObject();
        boolean boolean20 = jsonObject18.has("");
        java.lang.String str21 = gson0.toJson((java.lang.Object) boolean20);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "100" + "'", str9, "100");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "null" + "'", str17, "null");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "false" + "'", str21, "false");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        java.io.Writer writer8 = null;
        java.lang.Object obj9 = null;
        // The following exception was thrown during execution in test generation
        try {
            charSequenceArrayTypeAdapter6.toJson(writer8, obj9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = typeAdapterFactoryArrayTypeAdapter3.fromJson(" ");
            org.junit.Assert.fail("Expected exception of type java.io.EOFException; message: End of input at line 1 column 2");
        } catch (java.io.EOFException e) {
            // Expected exception.
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement5 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy4);
        com.google.gson.JsonObject jsonObject6 = new com.google.gson.JsonObject();
        boolean boolean8 = jsonObject6.has("");
        java.lang.Object obj9 = null;
        boolean boolean10 = jsonObject6.equals(obj9);
        jsonObject6.addProperty("false", (java.lang.Number) 10.0f);
        jsonObject6.addProperty("null", (java.lang.Boolean) false);
        java.lang.Appendable appendable17 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonObject6, appendable17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonObject jsonObject5 = new com.google.gson.JsonObject();
        boolean boolean7 = jsonObject5.has("");
        com.google.gson.JsonPrimitive jsonPrimitive9 = jsonObject5.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader10 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject5);
        jsonTreeReader10.skipValue();
        java.lang.String str12 = jsonTreeReader10.toString();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jsonPrimitive9);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "JsonTreeReader" + "'", str12, "JsonTreeReader");
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Number number19 = jsonArray11.getAsNumber();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        java.lang.Appendable appendable20 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) "#", appendable20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        java.io.Reader reader7 = null;
        java.lang.reflect.Type type8 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.math.BigDecimal bigDecimal9 = gson0.fromJson(reader7, type8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = sqlDateTypeAdapterArrayTypeAdapter3.fromJson("hi!");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        java.lang.Object obj19 = null;
        boolean boolean20 = jsonArray11.equals(obj19);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement22 = jsonArray11.get((int) '1');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index 49 out of bounds for length 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean8 = jsonPrimitive7.isBoolean();
        boolean boolean9 = jsonPrimitive7.isString();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = sqlDateTypeAdapterArrayTypeAdapter3.fromJsonTree((com.google.gson.JsonElement) jsonPrimitive7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was NUMBER");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Object obj1 = null;
        java.lang.Appendable appendable2 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson(obj1, appendable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.JsonElement jsonElement7 = null;
        java.lang.String str8 = gson0.toJson(jsonElement7);
        java.io.Writer writer9 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter10 = gson0.newJsonWriter(writer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "null" + "'", str8, "null");
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonPrimitive jsonPrimitive6 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 0);
        char char7 = jsonPrimitive6.getAsCharacter();
        long long8 = jsonPrimitive6.getAsLong();
        java.lang.String str9 = jsonPrimitive6.toString();
        boolean boolean10 = jsonPrimitive6.isBoolean();
        java.lang.Number number11 = jsonPrimitive6.getAsNumber();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement12 = typeAdapterFactoryArrayTypeAdapter3.toJsonTree((java.lang.Object) jsonPrimitive6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '0' + "'", char7 == '0');
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "0" + "'", str9, "0");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + number11 + "' != '" + (short) 0 + "'", number11, (short) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger8 = jsonPrimitive7.getAsBigInteger();
        java.lang.String str9 = gson0.toJson((java.lang.Object) bigInteger8);
        java.lang.String str10 = gson0.toString();
        com.google.gson.Gson gson11 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter12 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass13 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter14 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson11, sqlDateTypeAdapterTypeAdapter12, sqlDateTypeAdapterClass13);
        com.google.gson.JsonNull jsonNull15 = new com.google.gson.JsonNull();
        java.lang.String str16 = gson11.toJson((com.google.gson.JsonElement) jsonNull15);
        java.lang.String str17 = gson0.toJson((com.google.gson.JsonElement) jsonNull15);
        com.google.gson.JsonArray jsonArray18 = new com.google.gson.JsonArray();
        jsonArray18.add((java.lang.Boolean) false);
        com.google.gson.JsonArray jsonArray21 = new com.google.gson.JsonArray();
        jsonArray18.addAll(jsonArray21);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date24 = null;
        com.google.gson.JsonElement jsonElement25 = dateTypeAdapter23.toJsonTree(date24);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter26 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter26.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonWriter27.value((double) (byte) 1);
        java.util.Date date30 = null;
        dateTypeAdapter23.write(jsonWriter29, date30);
        jsonWriter29.setLenient(false);
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonWriter29.value("? extends ? super com.google.gson.JsonIOException");
        gson0.toJson((com.google.gson.JsonElement) jsonArray18, jsonWriter29);
        boolean boolean37 = jsonWriter29.getSerializeNulls();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "100" + "'", str9, "100");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "null" + "'", str17, "null");
        org.junit.Assert.assertNotNull(jsonElement25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.JsonElement jsonElement7 = null;
        java.lang.String str8 = gson0.toJson(jsonElement7);
        com.google.gson.JsonArray jsonArray9 = new com.google.gson.JsonArray();
        jsonArray9.add((java.lang.Number) 10);
        boolean boolean12 = jsonArray9.getAsBoolean();
        char char13 = jsonArray9.getAsCharacter();
        com.google.gson.Gson gson14 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter15 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass16 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter17 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson14, sqlDateTypeAdapterTypeAdapter15, sqlDateTypeAdapterClass16);
        com.google.gson.LongSerializationPolicy longSerializationPolicy18 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement19 = gson14.toJsonTree((java.lang.Object) longSerializationPolicy18);
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter20 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter21 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter21.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter21.value(true);
        java.sql.Time time25 = null;
        timeTypeAdapter20.write(jsonWriter24, time25);
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter27 = timeTypeAdapter20.nullSafe();
        java.sql.Time time28 = null;
        com.google.gson.JsonElement jsonElement29 = timeTypeAdapter27.toJsonTree(time28);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter30 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter31 = sqlDateTypeAdapter30.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter32 = dateTypeAdapter31.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter33 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter34 = sqlDateTypeAdapter33.nullSafe();
        com.google.gson.JsonNull jsonNull35 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date36 = dateTypeAdapter34.fromJsonTree((com.google.gson.JsonElement) jsonNull35);
        boolean boolean38 = jsonNull35.equals((java.lang.Object) 1L);
        java.sql.Date date39 = dateTypeAdapter31.fromJsonTree((com.google.gson.JsonElement) jsonNull35);
        java.lang.Class<?> wildcardClass40 = jsonNull35.getClass();
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken41 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass40);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter42 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date43 = null;
        com.google.gson.JsonElement jsonElement44 = dateTypeAdapter42.toJsonTree(date43);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter45 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter45.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter48 = jsonWriter46.value((double) (byte) 1);
        java.util.Date date49 = null;
        dateTypeAdapter42.write(jsonWriter48, date49);
        jsonWriter48.setLenient(false);
        com.google.gson.stream.JsonWriter jsonWriter54 = jsonWriter48.value("? extends ? super com.google.gson.JsonIOException");
        boolean boolean55 = jsonWriter48.isLenient();
        gson14.toJson((java.lang.Object) jsonElement29, (java.lang.reflect.Type) wildcardClass40, jsonWriter48);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Throwable throwable57 = gson0.fromJson((com.google.gson.JsonElement) jsonArray9, (java.lang.reflect.Type) wildcardClass40);
            org.junit.Assert.fail("Expected exception of type com.google.gson.JsonSyntaxException; message: Expected a com.google.gson.JsonNull but was com.google.gson.JsonArray");
        } catch (com.google.gson.JsonSyntaxException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "null" + "'", str8, "null");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + '1' + "'", char13 == '1');
        org.junit.Assert.assertNotNull(longSerializationPolicy18);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(timeTypeAdapter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(dateTypeAdapter31);
        org.junit.Assert.assertNotNull(dateTypeAdapter32);
        org.junit.Assert.assertNotNull(dateTypeAdapter34);
        org.junit.Assert.assertNotNull(jsonNull35);
        org.junit.Assert.assertNull(date36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(date39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(wildcardTypeToken41);
        org.junit.Assert.assertNotNull(jsonElement44);
        org.junit.Assert.assertNotNull(jsonWriter46);
        org.junit.Assert.assertNotNull(jsonWriter48);
        org.junit.Assert.assertNotNull(jsonWriter54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonArray jsonArray5 = new com.google.gson.JsonArray();
        jsonArray5.add("hi!");
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor8 = jsonArray5.iterator();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor9 = jsonArray5.iterator();
        com.google.gson.JsonArray jsonArray10 = new com.google.gson.JsonArray();
        jsonArray10.add((java.lang.Boolean) false);
        boolean boolean13 = jsonArray5.remove((com.google.gson.JsonElement) jsonArray10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = objTypeAdapter4.fromJsonTree((com.google.gson.JsonElement) jsonArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(jsonElementItor8);
        org.junit.Assert.assertNotNull(jsonElementItor9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean4 = jsonPrimitive2.equals((java.lang.Object) typeAdapterFactory3);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2, jsonWriter8);
        boolean boolean12 = jsonWriter8.isLenient();
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.JsonPrimitive jsonPrimitive20 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger21 = jsonPrimitive20.getAsBigInteger();
        short short22 = jsonPrimitive20.getAsShort();
        long long23 = jsonPrimitive20.getAsLong();
        double double24 = jsonPrimitive20.getAsDouble();
        com.google.gson.stream.JsonWriter jsonWriter25 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive20, jsonWriter25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 100 + "'", short22 == (short) 100);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        com.google.gson.JsonArray jsonArray8 = new com.google.gson.JsonArray();
        jsonArray8.add("hi!");
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor11 = jsonArray8.iterator();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter12 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter13 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter13.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter13.value(true);
        java.sql.Time time17 = null;
        timeTypeAdapter12.write(jsonWriter16, time17);
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter19 = timeTypeAdapter12.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter20 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter21 = sqlDateTypeAdapter20.nullSafe();
        java.sql.Date date22 = null;
        com.google.gson.JsonElement jsonElement23 = sqlDateTypeAdapter20.toJsonTree(date22);
        java.sql.Time time24 = timeTypeAdapter12.fromJsonTree(jsonElement23);
        jsonArray8.add(jsonElement23);
        com.google.gson.JsonPrimitive jsonPrimitive27 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 0);
        java.math.BigDecimal bigDecimal28 = jsonPrimitive27.getAsBigDecimal();
        char char29 = jsonPrimitive27.getAsCharacter();
        double double30 = jsonPrimitive27.getAsDouble();
        com.google.gson.JsonParseException jsonParseException32 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException33 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException32);
        com.google.gson.JsonParseException jsonParseException34 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException32);
        boolean boolean35 = jsonPrimitive27.equals((java.lang.Object) jsonParseException32);
        short short36 = jsonPrimitive27.getAsShort();
        java.math.BigInteger bigInteger37 = jsonPrimitive27.getAsBigInteger();
        com.google.gson.JsonPrimitive jsonPrimitive38 = new com.google.gson.JsonPrimitive((java.lang.Number) bigInteger37);
        jsonArray8.add((java.lang.Number) bigInteger37);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement40 = charSequenceArrayTypeAdapter6.toJsonTree((java.lang.Object) jsonArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonElementItor11);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(timeTypeAdapter19);
        org.junit.Assert.assertNotNull(dateTypeAdapter21);
        org.junit.Assert.assertNotNull(jsonElement23);
        org.junit.Assert.assertNull(time24);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertTrue("'" + char29 + "' != '" + '0' + "'", char29 == '0');
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + short36 + "' != '" + (short) 0 + "'", short36 == (short) 0);
        org.junit.Assert.assertNotNull(bigInteger37);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        jsonArray11.add((java.lang.Number) 10);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader21 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        // The following exception was thrown during execution in test generation
        try {
            long long22 = jsonTreeReader21.nextLong();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NUMBER but was BEGIN_ARRAY");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray12 = jsonObject10.getAsJsonArray("com.google.gson.JsonIOException");
        java.lang.String str13 = gson0.toJson((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.JsonObject jsonObject14 = new com.google.gson.JsonObject();
        boolean boolean16 = jsonObject14.has("");
        com.google.gson.JsonObject jsonObject18 = new com.google.gson.JsonObject();
        jsonObject14.add("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>", (com.google.gson.JsonElement) jsonObject18);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter20 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter20.beginArray();
        java.lang.Number number22 = null;
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter20.value(number22);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter20.endArray();
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter20.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter20.beginObject();
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonObject18, jsonWriter26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(jsonArray12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "{}" + "'", str13, "{}");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter26);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        java.lang.Object obj7 = null;
        com.google.gson.JsonElement jsonElement8 = charSequenceArrayTypeAdapter6.toJsonTree(obj7);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = jsonElement8.getAsString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: JsonNull");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElement8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = sqlDateTypeAdapterArrayTypeAdapter3.fromJson("");
            org.junit.Assert.fail("Expected exception of type java.io.EOFException; message: End of input at line 1 column 1");
        } catch (java.io.EOFException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.TypeAdapter<java.lang.Cloneable> cloneableTypeAdapter7 = null;
        java.lang.Class<java.lang.Cloneable> cloneableClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable> cloneableArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable>(gson0, cloneableTypeAdapter7, cloneableClass8);
        com.google.gson.JsonArray jsonArray10 = new com.google.gson.JsonArray();
        jsonArray10.add((java.lang.Number) 10);
        boolean boolean13 = jsonArray10.getAsBoolean();
        boolean boolean14 = jsonArray10.getAsBoolean();
        boolean boolean15 = jsonArray10.getAsBoolean();
        double double16 = jsonArray10.getAsDouble();
        int int17 = jsonArray10.getAsInt();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj18 = cloneableArrayTypeAdapter9.fromJsonTree((com.google.gson.JsonElement) jsonArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement5 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy4);
        com.google.gson.JsonElement jsonElement6 = null;
        java.lang.Appendable appendable7 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson(jsonElement6, appendable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(jsonElement5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray12 = jsonObject10.getAsJsonArray("com.google.gson.JsonIOException");
        java.lang.String str13 = gson0.toJson((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.JsonArray jsonArray14 = new com.google.gson.JsonArray();
        jsonArray14.add((java.lang.Number) 10);
        boolean boolean17 = jsonArray14.getAsBoolean();
        boolean boolean18 = jsonArray14.getAsBoolean();
        boolean boolean19 = jsonArray14.getAsBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive21 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str22 = jsonPrimitive21.getAsString();
        boolean boolean23 = jsonPrimitive21.isJsonArray();
        boolean boolean24 = jsonArray14.contains((com.google.gson.JsonElement) jsonPrimitive21);
        java.lang.String str25 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive21);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter26 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass27 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter28 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter26, typeAdapterFactoryClass27);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter29 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter29.beginArray();
        java.lang.Number number31 = null;
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter29.value(number31);
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter29.endArray();
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter29.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter29.nullValue();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter36 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter36.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter36.value(true);
        jsonWriter39.setIndent("null");
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter28.write((com.google.gson.stream.JsonWriter) jsonTreeWriter29, (java.lang.Object) jsonWriter39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(jsonArray12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "{}" + "'", str13, "{}");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "false" + "'", str22, "false");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "false" + "'", str25, "false");
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter37);
        org.junit.Assert.assertNotNull(jsonWriter39);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        java.lang.Object obj19 = null;
        boolean boolean20 = jsonArray11.equals(obj19);
        com.google.gson.JsonObject jsonObject21 = new com.google.gson.JsonObject();
        boolean boolean23 = jsonObject21.has("");
        com.google.gson.JsonArray jsonArray25 = jsonObject21.getAsJsonArray("");
        com.google.gson.JsonPrimitive jsonPrimitive27 = jsonObject21.getAsJsonPrimitive("false");
        jsonObject21.addProperty("0", "100");
        jsonArray11.add((com.google.gson.JsonElement) jsonObject21);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(jsonArray25);
        org.junit.Assert.assertNull(jsonPrimitive27);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        jsonArray11.add((java.lang.Number) 10);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader21 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        // The following exception was thrown during execution in test generation
        try {
            long long22 = jsonTreeReader21.nextLong();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NUMBER but was BEGIN_ARRAY");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray12 = jsonObject10.getAsJsonArray("com.google.gson.JsonIOException");
        java.lang.String str13 = gson0.toJson((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.JsonArray jsonArray14 = new com.google.gson.JsonArray();
        jsonArray14.add((java.lang.Number) 10);
        boolean boolean17 = jsonArray14.getAsBoolean();
        boolean boolean18 = jsonArray14.getAsBoolean();
        boolean boolean19 = jsonArray14.getAsBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive21 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str22 = jsonPrimitive21.getAsString();
        boolean boolean23 = jsonPrimitive21.isJsonArray();
        boolean boolean24 = jsonArray14.contains((com.google.gson.JsonElement) jsonPrimitive21);
        java.lang.String str25 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive21);
        com.google.gson.JsonObject jsonObject26 = new com.google.gson.JsonObject();
        boolean boolean28 = jsonObject26.has("");
        jsonObject26.addProperty("", (java.lang.Number) 100.0d);
        com.google.gson.JsonObject jsonObject33 = jsonObject26.getAsJsonObject("hi!");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter34 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter36 = jsonTreeWriter34.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter38 = jsonTreeWriter34.value("com.google.gson.JsonIOException: ");
        boolean boolean39 = jsonWriter38.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonWriter38.nullValue();
        boolean boolean41 = jsonObject26.equals((java.lang.Object) jsonWriter38);
        java.lang.Appendable appendable42 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonObject26, appendable42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(jsonArray12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "{}" + "'", str13, "{}");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "false" + "'", str22, "false");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "false" + "'", str25, "false");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(jsonObject33);
        org.junit.Assert.assertNotNull(jsonWriter36);
        org.junit.Assert.assertNotNull(jsonWriter38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        jsonArray11.add((java.lang.Number) 10);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader21 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        java.lang.Class<?> wildcardClass22 = jsonArray11.getClass();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter7 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson6, sqlDateTypeAdapterTypeAdapter7, sqlDateTypeAdapterClass8);
        com.google.gson.JsonNull jsonNull10 = new com.google.gson.JsonNull();
        java.lang.String str11 = gson6.toJson((com.google.gson.JsonElement) jsonNull10);
        java.lang.Appendable appendable12 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonNull10, appendable12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "null" + "'", str11, "null");
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        java.lang.String str5 = gson0.toString();
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger8 = jsonPrimitive7.getAsBigInteger();
        java.lang.String str9 = gson0.toJson((java.lang.Object) bigInteger8);
        java.lang.String str10 = gson0.toString();
        com.google.gson.Gson gson11 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter12 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass13 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter14 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson11, sqlDateTypeAdapterTypeAdapter12, sqlDateTypeAdapterClass13);
        com.google.gson.JsonNull jsonNull15 = new com.google.gson.JsonNull();
        java.lang.String str16 = gson11.toJson((com.google.gson.JsonElement) jsonNull15);
        java.lang.String str17 = gson0.toJson((com.google.gson.JsonElement) jsonNull15);
        java.lang.String str18 = gson0.toString();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "100" + "'", str9, "100");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "null" + "'", str17, "null");
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonArray jsonArray5 = new com.google.gson.JsonArray();
        jsonArray5.add((java.lang.Number) 10);
        int int8 = jsonArray5.size();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor9 = jsonArray5.iterator();
        com.google.gson.Gson gson10 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter11 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass12 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter13 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson10, sqlDateTypeAdapterTypeAdapter11, sqlDateTypeAdapterClass12);
        java.lang.String str15 = gson10.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive17 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger18 = jsonPrimitive17.getAsBigInteger();
        java.lang.String str19 = gson10.toJson((java.lang.Object) bigInteger18);
        jsonArray5.add((java.lang.Number) bigInteger18);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj21 = objTypeAdapter4.fromJsonTree((com.google.gson.JsonElement) jsonArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(jsonElementItor9);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "100" + "'", str15, "100");
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "100" + "'", str19, "100");
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        jsonArray11.add((java.lang.Number) 10);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement22 = jsonArray11.get((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index -1 out of bounds for length 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        java.io.Reader reader7 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = charSequenceArrayTypeAdapter6.fromJson(reader7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter7 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter8 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter8.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter8.value(true);
        java.sql.Time time12 = null;
        timeTypeAdapter7.write(jsonWriter11, time12);
        java.sql.Time time14 = null;
        com.google.gson.JsonElement jsonElement15 = timeTypeAdapter7.toJsonTree(time14);
        java.lang.String str16 = gson0.toJson(jsonElement15);
        java.lang.Throwable throwable21 = null;
        com.google.gson.JsonIOException jsonIOException22 = new com.google.gson.JsonIOException("", throwable21);
        com.google.gson.stream.MalformedJsonException malformedJsonException23 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException22);
        com.google.gson.stream.MalformedJsonException malformedJsonException24 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException22);
        com.google.gson.JsonIOException jsonIOException25 = new com.google.gson.JsonIOException("hi!", (java.lang.Throwable) jsonIOException22);
        com.google.gson.JsonElement jsonElement26 = gson0.toJsonTree((java.lang.Object) "hi!");
        java.lang.Object obj27 = null;
        java.lang.String str28 = gson0.toJson(obj27);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonElement15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertNotNull(jsonElement26);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "null" + "'", str28, "null");
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger8 = jsonPrimitive7.getAsBigInteger();
        java.lang.String str9 = gson0.toJson((java.lang.Object) bigInteger8);
        java.lang.String str10 = gson0.toString();
        com.google.gson.Gson gson11 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter12 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass13 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter14 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson11, sqlDateTypeAdapterTypeAdapter12, sqlDateTypeAdapterClass13);
        com.google.gson.JsonNull jsonNull15 = new com.google.gson.JsonNull();
        java.lang.String str16 = gson11.toJson((com.google.gson.JsonElement) jsonNull15);
        java.lang.String str17 = gson0.toJson((com.google.gson.JsonElement) jsonNull15);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Number number18 = jsonNull15.getAsNumber();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: JsonNull");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "100" + "'", str9, "100");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "null" + "'", str17, "null");
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        java.io.Writer writer5 = null;
        com.google.gson.internal.LazilyParsedNumber lazilyParsedNumber7 = new com.google.gson.internal.LazilyParsedNumber("hi!");
        java.lang.String str8 = lazilyParsedNumber7.toString();
        java.lang.Object obj9 = null;
        boolean boolean10 = lazilyParsedNumber7.equals(obj9);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive((java.lang.Character) '#');
        boolean boolean13 = lazilyParsedNumber7.equals((java.lang.Object) jsonPrimitive12);
        java.lang.String str14 = jsonPrimitive12.getAsString();
        boolean boolean15 = jsonPrimitive12.isNumber();
        // The following exception was thrown during execution in test generation
        try {
            objTypeAdapter4.toJson(writer5, (java.lang.Object) jsonPrimitive12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "hi!" + "'", str8, "hi!");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "#" + "'", str14, "#");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray12 = jsonObject10.getAsJsonArray("com.google.gson.JsonIOException");
        java.lang.String str13 = gson0.toJson((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.JsonArray jsonArray14 = new com.google.gson.JsonArray();
        jsonArray14.add((java.lang.Number) 10);
        boolean boolean17 = jsonArray14.getAsBoolean();
        boolean boolean18 = jsonArray14.getAsBoolean();
        boolean boolean19 = jsonArray14.getAsBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive21 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str22 = jsonPrimitive21.getAsString();
        boolean boolean23 = jsonPrimitive21.isJsonArray();
        boolean boolean24 = jsonArray14.contains((com.google.gson.JsonElement) jsonPrimitive21);
        java.lang.String str25 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive21);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter26 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass27 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter28 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter26, typeAdapterFactoryClass27);
        com.google.gson.JsonObject jsonObject29 = new com.google.gson.JsonObject();
        boolean boolean31 = jsonObject29.has("");
        com.google.gson.JsonPrimitive jsonPrimitive33 = jsonObject29.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader34 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject29);
        jsonTreeReader34.close();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = typeAdapterFactoryArrayTypeAdapter28.read((com.google.gson.stream.JsonReader) jsonTreeReader34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JsonReader is closed");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(jsonArray12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "{}" + "'", str13, "{}");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "false" + "'", str22, "false");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "false" + "'", str25, "false");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(jsonPrimitive33);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonObject jsonObject4 = new com.google.gson.JsonObject();
        boolean boolean6 = jsonObject4.has("");
        com.google.gson.JsonPrimitive jsonPrimitive8 = jsonObject4.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader9 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject4);
        com.google.gson.stream.JsonToken jsonToken10 = jsonTreeReader9.peek();
        java.lang.String str11 = jsonTreeReader9.toString();
        com.google.gson.stream.JsonToken jsonToken12 = jsonTreeReader9.peek();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jsonPrimitive8);
        org.junit.Assert.assertTrue("'" + jsonToken10 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_OBJECT + "'", jsonToken10.equals(com.google.gson.stream.JsonToken.BEGIN_OBJECT));
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "JsonTreeReader" + "'", str11, "JsonTreeReader");
        org.junit.Assert.assertTrue("'" + jsonToken12 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_OBJECT + "'", jsonToken12.equals(com.google.gson.stream.JsonToken.BEGIN_OBJECT));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter0 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter2 = jsonTreeWriter0.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter4 = jsonTreeWriter0.value("com.google.gson.JsonIOException: ");
        com.google.gson.JsonElement jsonElement5 = jsonTreeWriter0.get();
        com.google.gson.JsonElement jsonElement6 = jsonTreeWriter0.get();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter0.value(true);
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter0.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter0.value((double) 100L);
        com.google.gson.JsonArray jsonArray12 = new com.google.gson.JsonArray();
        jsonArray12.add((java.lang.Number) 10);
        int int15 = jsonArray12.size();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor16 = jsonArray12.iterator();
        com.google.gson.Gson gson17 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter18 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass19 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter20 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson17, sqlDateTypeAdapterTypeAdapter18, sqlDateTypeAdapterClass19);
        java.lang.String str22 = gson17.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive24 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger25 = jsonPrimitive24.getAsBigInteger();
        java.lang.String str26 = gson17.toJson((java.lang.Object) bigInteger25);
        jsonArray12.add((java.lang.Number) bigInteger25);
        com.google.gson.stream.JsonWriter jsonWriter28 = jsonTreeWriter0.value((java.lang.Number) bigInteger25);
        short short29 = bigInteger25.shortValue();
        org.junit.Assert.assertNotNull(jsonWriter2);
        org.junit.Assert.assertNotNull(jsonWriter4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertNotNull(jsonElement6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(jsonElementItor16);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "100" + "'", str22, "100");
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "100" + "'", str26, "100");
        org.junit.Assert.assertNotNull(jsonWriter28);
        org.junit.Assert.assertTrue("'" + short29 + "' != '" + (short) 100 + "'", short29 == (short) 100);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        java.lang.Object obj7 = null;
        com.google.gson.JsonElement jsonElement8 = charSequenceArrayTypeAdapter6.toJsonTree(obj7);
        com.google.gson.TypeAdapterFactory typeAdapterFactory9 = com.google.gson.internal.bind.TypeAdapters.CALENDAR_FACTORY;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = charSequenceArrayTypeAdapter6.toJson((java.lang.Object) typeAdapterFactory9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(typeAdapterFactory9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.gson.Gson gson1 = new com.google.gson.Gson();
        java.lang.Throwable throwable3 = null;
        com.google.gson.JsonIOException jsonIOException4 = new com.google.gson.JsonIOException("", throwable3);
        java.lang.String str5 = gson1.toJson((java.lang.Object) jsonIOException4);
        com.google.gson.JsonIOException jsonIOException6 = new com.google.gson.JsonIOException("com.google.gson.JsonSyntaxException: hi!", (java.lang.Throwable) jsonIOException4);
        com.google.gson.stream.MalformedJsonException malformedJsonException7 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonIOException4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str5, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean20 = jsonTreeReader19.nextBoolean();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BOOLEAN but was BEGIN_ARRAY");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray12 = jsonObject10.getAsJsonArray("com.google.gson.JsonIOException");
        java.lang.String str13 = gson0.toJson((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.JsonArray jsonArray14 = new com.google.gson.JsonArray();
        jsonArray14.add((java.lang.Number) 10);
        boolean boolean17 = jsonArray14.getAsBoolean();
        boolean boolean18 = jsonArray14.getAsBoolean();
        boolean boolean19 = jsonArray14.getAsBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive21 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str22 = jsonPrimitive21.getAsString();
        boolean boolean23 = jsonPrimitive21.isJsonArray();
        boolean boolean24 = jsonArray14.contains((com.google.gson.JsonElement) jsonPrimitive21);
        java.lang.String str25 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive21);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter26 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass27 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter28 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter26, typeAdapterFactoryClass27);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = typeAdapterFactoryArrayTypeAdapter28.fromJson("com.google.gson.JsonSyntaxException: hi!");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(jsonArray12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "{}" + "'", str13, "{}");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "false" + "'", str22, "false");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "false" + "'", str25, "false");
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = objTypeAdapter4.nullSafe();
        java.io.Reader reader6 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = objTypeAdapter5.fromJson(reader6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory>(gson0, collectionTypeAdapterFactoryTypeAdapter1, collectionTypeAdapterFactoryClass2);
        java.lang.reflect.Type type5 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.AutoCloseable autoCloseable6 = gson0.fromJson("com.google.gson.JsonSyntaxException: com.google.gson.JsonParseException: ? extends ? super com.google.gson.JsonIOException", type5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterTypeAdapter19 = null;
        java.lang.Class<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter>(gson0, timeTypeAdapterTypeAdapter19, timeTypeAdapterClass20);
        java.io.Reader reader22 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = timeTypeAdapterArrayTypeAdapter21.fromJson(reader22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        java.lang.Object obj6 = null;
        com.google.gson.JsonElement jsonElement7 = objTypeAdapter5.toJsonTree(obj6);
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
        org.junit.Assert.assertNotNull(jsonElement7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.JsonPrimitive jsonPrimitive20 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        boolean boolean21 = jsonPrimitive20.isString();
        java.lang.Appendable appendable22 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive20, appendable22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonObject jsonObject5 = new com.google.gson.JsonObject();
        boolean boolean7 = jsonObject5.has("");
        com.google.gson.JsonPrimitive jsonPrimitive9 = jsonObject5.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader10 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject5);
        java.lang.String str11 = jsonTreeReader10.toString();
        java.lang.String str12 = jsonTreeReader10.getPath();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jsonPrimitive9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "JsonTreeReader" + "'", str11, "JsonTreeReader");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "$" + "'", str12, "$");
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter8 = charSequenceArrayTypeAdapter6.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = charSequenceArrayTypeAdapter6.fromJson("com.google.gson.JsonSyntaxException: hi!");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(objTypeAdapter8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        jsonArray0.add((java.lang.Number) 10);
        boolean boolean3 = jsonArray0.getAsBoolean();
        jsonArray0.add((java.lang.Boolean) true);
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor6 = jsonArray0.iterator();
        com.google.gson.JsonElement jsonElement8 = jsonArray0.get(1);
        com.google.gson.Gson gson9 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive11 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory12 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean13 = jsonPrimitive11.equals((java.lang.Object) typeAdapterFactory12);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter14 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter15 = jsonTreeWriter14.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter14.value(true);
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonWriter17.value(true);
        gson9.toJson((com.google.gson.JsonElement) jsonPrimitive11, jsonWriter17);
        boolean boolean21 = jsonArray0.remove((com.google.gson.JsonElement) jsonPrimitive11);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean22 = jsonArray0.getAsBoolean();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonElementItor6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(typeAdapterFactory12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jsonWriter15);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) 100);
        java.lang.String str8 = jsonPrimitive7.getAsString();
        boolean boolean9 = jsonPrimitive7.isString();
        long long10 = jsonPrimitive7.getAsLong();
        java.math.BigDecimal bigDecimal11 = jsonPrimitive7.getAsBigDecimal();
        char char12 = jsonPrimitive7.getAsCharacter();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = objTypeAdapter5.fromJsonTree((com.google.gson.JsonElement) jsonPrimitive7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was NUMBER");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "100" + "'", str8, "100");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(bigDecimal11);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + '1' + "'", char12 == '1');
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter8 = charSequenceArrayTypeAdapter6.nullSafe();
        java.io.Reader reader9 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = objTypeAdapter8.fromJson(reader9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(objTypeAdapter8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterTypeAdapter19 = null;
        java.lang.Class<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter>(gson0, timeTypeAdapterTypeAdapter19, timeTypeAdapterClass20);
        com.google.gson.internal.LazilyParsedNumber lazilyParsedNumber23 = new com.google.gson.internal.LazilyParsedNumber("hi!");
        java.lang.String str24 = lazilyParsedNumber23.toString();
        java.lang.Object obj25 = null;
        boolean boolean26 = lazilyParsedNumber23.equals(obj25);
        com.google.gson.JsonPrimitive jsonPrimitive28 = new com.google.gson.JsonPrimitive((java.lang.Character) '#');
        boolean boolean29 = lazilyParsedNumber23.equals((java.lang.Object) jsonPrimitive28);
        java.lang.String str30 = jsonPrimitive28.getAsString();
        java.lang.Appendable appendable31 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) str30, appendable31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "hi!" + "'", str24, "hi!");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "#" + "'", str30, "#");
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = objTypeAdapter4.fromJson("0");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.TypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeTypeAdapter19 = null;
        java.lang.Class<java.lang.reflect.ParameterizedType> parameterizedTypeClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType>(gson0, parameterizedTypeTypeAdapter19, parameterizedTypeClass20);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter22 = parameterizedTypeArrayTypeAdapter21.nullSafe();
        com.google.gson.JsonParseException jsonParseException26 = new com.google.gson.JsonParseException("hi!");
        java.lang.Throwable throwable29 = null;
        com.google.gson.JsonIOException jsonIOException30 = new com.google.gson.JsonIOException("", throwable29);
        com.google.gson.stream.MalformedJsonException malformedJsonException31 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException30);
        jsonParseException26.addSuppressed((java.lang.Throwable) jsonIOException30);
        com.google.gson.JsonIOException jsonIOException33 = new com.google.gson.JsonIOException("100", (java.lang.Throwable) jsonParseException26);
        com.google.gson.JsonParseException jsonParseException34 = new com.google.gson.JsonParseException("[10,true]", (java.lang.Throwable) jsonParseException26);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str35 = parameterizedTypeArrayTypeAdapter21.toJson((java.lang.Object) "[10,true]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter22);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        jsonTreeReader19.skipValue();
        // The following exception was thrown during execution in test generation
        try {
            jsonTreeReader19.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected END_OBJECT but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter4 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter4.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonTreeWriter4.beginArray();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) jsonWriter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: class com.google.gson.internal.bind.JsonTreeWriter declares multiple JSON fields named stack");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray12 = jsonObject10.getAsJsonArray("com.google.gson.JsonIOException");
        java.lang.String str13 = gson0.toJson((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.JsonArray jsonArray14 = new com.google.gson.JsonArray();
        jsonArray14.add((java.lang.Number) 10);
        boolean boolean17 = jsonArray14.getAsBoolean();
        boolean boolean18 = jsonArray14.getAsBoolean();
        boolean boolean19 = jsonArray14.getAsBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive21 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str22 = jsonPrimitive21.getAsString();
        boolean boolean23 = jsonPrimitive21.isJsonArray();
        boolean boolean24 = jsonArray14.contains((com.google.gson.JsonElement) jsonPrimitive21);
        java.lang.String str25 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive21);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter26 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass27 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter28 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter26, typeAdapterFactoryClass27);
        java.io.Writer writer29 = null;
        com.google.gson.JsonParseException jsonParseException32 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonSyntaxException jsonSyntaxException33 = new com.google.gson.JsonSyntaxException("? extends ? super com.google.gson.JsonIOException", (java.lang.Throwable) jsonParseException32);
        com.google.gson.JsonSyntaxException jsonSyntaxException34 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonParseException32);
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter28.toJson(writer29, (java.lang.Object) jsonParseException32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(jsonArray12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "{}" + "'", str13, "{}");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "false" + "'", str22, "false");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "false" + "'", str25, "false");
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter1 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter3 = jsonTreeWriter1.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter5 = jsonTreeWriter1.value("com.google.gson.JsonIOException: ");
        com.google.gson.JsonElement jsonElement6 = jsonTreeWriter1.get();
        jsonTreeWriter1.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonTreeWriter1.value((double) 1L);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonTreeWriter1.value(10L);
        java.lang.Appendable appendable13 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) jsonTreeWriter1, appendable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: class com.google.gson.internal.bind.JsonTreeWriter declares multiple JSON fields named stack");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter5);
        org.junit.Assert.assertNotNull(jsonElement6);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(jsonWriter12);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonParseException jsonParseException7 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException8 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException7);
        com.google.gson.JsonParseException jsonParseException10 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException11 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException10);
        jsonParseException8.addSuppressed((java.lang.Throwable) jsonParseException11);
        com.google.gson.JsonParseException jsonParseException13 = new com.google.gson.JsonParseException("? extends ? super com.google.gson.JsonIOException", (java.lang.Throwable) jsonParseException8);
        com.google.gson.JsonSyntaxException jsonSyntaxException14 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonParseException13);
        com.google.gson.JsonParseException jsonParseException17 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException18 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException17);
        com.google.gson.JsonParseException jsonParseException20 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException21 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException20);
        jsonParseException18.addSuppressed((java.lang.Throwable) jsonParseException21);
        com.google.gson.JsonParseException jsonParseException23 = new com.google.gson.JsonParseException("? extends ? super com.google.gson.JsonIOException", (java.lang.Throwable) jsonParseException18);
        com.google.gson.JsonSyntaxException jsonSyntaxException24 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonParseException23);
        jsonParseException13.addSuppressed((java.lang.Throwable) jsonSyntaxException24);
        java.lang.Throwable[] throwableArray26 = jsonParseException13.getSuppressed();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str27 = objTypeAdapter4.toJson((java.lang.Object) jsonParseException13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(throwableArray26);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.io.Writer writer5 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter6 = gson0.newJsonWriter(writer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonObject jsonObject6 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray8 = jsonObject6.getAsJsonArray("com.google.gson.JsonIOException");
        com.google.gson.JsonPrimitive jsonPrimitive10 = jsonObject6.getAsJsonPrimitive("\"false\"");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet11 = jsonObject6.entrySet();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader12 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = sqlDateTypeAdapterArrayTypeAdapter3.toJson((java.lang.Object) jsonTreeReader12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
        org.junit.Assert.assertNull(jsonArray8);
        org.junit.Assert.assertNull(jsonPrimitive10);
        org.junit.Assert.assertNotNull(strEntrySet11);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger8 = jsonPrimitive7.getAsBigInteger();
        java.lang.String str9 = gson0.toJson((java.lang.Object) bigInteger8);
        java.lang.String str10 = gson0.toString();
        com.google.gson.Gson gson11 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter12 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass13 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter14 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson11, sqlDateTypeAdapterTypeAdapter12, sqlDateTypeAdapterClass13);
        com.google.gson.JsonNull jsonNull15 = new com.google.gson.JsonNull();
        java.lang.String str16 = gson11.toJson((com.google.gson.JsonElement) jsonNull15);
        java.lang.String str17 = gson0.toJson((com.google.gson.JsonElement) jsonNull15);
        com.google.gson.JsonArray jsonArray18 = new com.google.gson.JsonArray();
        jsonArray18.add((java.lang.Boolean) false);
        com.google.gson.JsonArray jsonArray21 = new com.google.gson.JsonArray();
        jsonArray18.addAll(jsonArray21);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date24 = null;
        com.google.gson.JsonElement jsonElement25 = dateTypeAdapter23.toJsonTree(date24);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter26 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter26.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonWriter27.value((double) (byte) 1);
        java.util.Date date30 = null;
        dateTypeAdapter23.write(jsonWriter29, date30);
        jsonWriter29.setLenient(false);
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonWriter29.value("? extends ? super com.google.gson.JsonIOException");
        gson0.toJson((com.google.gson.JsonElement) jsonArray18, jsonWriter29);
        // The following exception was thrown during execution in test generation
        try {
            byte byte37 = jsonArray18.getAsByte();
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"false\"");
        } catch (java.lang.NumberFormatException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "100" + "'", str9, "100");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "null" + "'", str17, "null");
        org.junit.Assert.assertNotNull(jsonElement25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter35);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        jsonArray11.add((java.lang.Number) 10);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader21 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        jsonArray11.add((java.lang.Character) '0');
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter6 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter7 = sqlDateTypeAdapter6.nullSafe();
        java.sql.Date date8 = null;
        com.google.gson.JsonElement jsonElement9 = sqlDateTypeAdapter6.toJsonTree(date8);
        java.sql.Date date10 = sqlDateTypeAdapter5.fromJsonTree(jsonElement9);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter11 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonTreeWriter11.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter11.value(true);
        jsonWriter14.setSerializeNulls(false);
        java.sql.Date date17 = null;
        sqlDateTypeAdapter5.write(jsonWriter14, date17);
        jsonWriter14.setLenient(true);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter21 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter22 = dateTypeAdapter21.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter23 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter23.beginArray();
        jsonTreeWriter23.flush();
        java.util.Date date26 = null;
        dateTypeAdapter21.write((com.google.gson.stream.JsonWriter) jsonTreeWriter23, date26);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter28 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter28.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter28.endArray();
        jsonTreeWriter28.flush();
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter28.value((long) 100);
        java.util.Date date34 = null;
        dateTypeAdapter21.write((com.google.gson.stream.JsonWriter) jsonTreeWriter28, date34);
        com.google.gson.stream.JsonWriter jsonWriter36 = jsonTreeWriter28.nullValue();
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter3.write(jsonWriter14, (java.lang.Object) jsonWriter36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(dateTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(date10);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertNotNull(dateTypeAdapter22);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertNotNull(jsonWriter36);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean4 = jsonPrimitive2.equals((java.lang.Object) typeAdapterFactory3);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2, jsonWriter8);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        boolean boolean14 = jsonObject12.has("");
        java.lang.Object obj15 = null;
        boolean boolean16 = jsonObject12.equals(obj15);
        java.lang.Throwable throwable19 = null;
        com.google.gson.JsonIOException jsonIOException20 = new com.google.gson.JsonIOException("", throwable19);
        com.google.gson.stream.MalformedJsonException malformedJsonException21 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException20);
        java.lang.Throwable[] throwableArray22 = malformedJsonException21.getSuppressed();
        boolean boolean23 = jsonObject12.equals((java.lang.Object) throwableArray22);
        jsonObject12.addProperty("", (java.lang.Number) (short) 1);
        java.lang.Appendable appendable27 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonObject12, appendable27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertArrayEquals(throwableArray22, new java.lang.Throwable[] {});
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter7 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter8 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter8.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter8.value(true);
        java.sql.Time time12 = null;
        timeTypeAdapter7.write(jsonWriter11, time12);
        java.sql.Time time14 = null;
        com.google.gson.JsonElement jsonElement15 = timeTypeAdapter7.toJsonTree(time14);
        java.lang.String str16 = gson0.toJson(jsonElement15);
        java.lang.Throwable throwable21 = null;
        com.google.gson.JsonIOException jsonIOException22 = new com.google.gson.JsonIOException("", throwable21);
        com.google.gson.stream.MalformedJsonException malformedJsonException23 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException22);
        com.google.gson.stream.MalformedJsonException malformedJsonException24 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException22);
        com.google.gson.JsonIOException jsonIOException25 = new com.google.gson.JsonIOException("hi!", (java.lang.Throwable) jsonIOException22);
        com.google.gson.JsonElement jsonElement26 = gson0.toJsonTree((java.lang.Object) "hi!");
        // The following exception was thrown during execution in test generation
        try {
            short short27 = jsonElement26.getAsShort();
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonElement15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertNotNull(jsonElement26);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter8 = charSequenceArrayTypeAdapter6.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = charSequenceArrayTypeAdapter6.fromJson("{\"null\":false}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BEGIN_OBJECT at line 1 column 2 path $");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(objTypeAdapter8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.TypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeTypeAdapter19 = null;
        java.lang.Class<java.lang.reflect.ParameterizedType> parameterizedTypeClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType>(gson0, parameterizedTypeTypeAdapter19, parameterizedTypeClass20);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter22 = parameterizedTypeArrayTypeAdapter21.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = objTypeAdapter22.fromJson("100");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter22);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        com.google.gson.JsonArray jsonArray20 = new com.google.gson.JsonArray();
        jsonArray20.add("hi!");
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor23 = jsonArray20.iterator();
        int int24 = jsonArray20.size();
        java.lang.Number number25 = jsonArray20.getAsNumber();
        jsonArray11.add((com.google.gson.JsonElement) jsonArray20);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertNotNull(jsonElementItor23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(number25);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        jsonArray0.add((java.lang.Number) 10);
        boolean boolean3 = jsonArray0.getAsBoolean();
        jsonArray0.add((java.lang.Boolean) true);
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor6 = jsonArray0.iterator();
        com.google.gson.JsonElement jsonElement8 = jsonArray0.get(1);
        com.google.gson.Gson gson9 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive11 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory12 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean13 = jsonPrimitive11.equals((java.lang.Object) typeAdapterFactory12);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter14 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter15 = jsonTreeWriter14.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter14.value(true);
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonWriter17.value(true);
        gson9.toJson((com.google.gson.JsonElement) jsonPrimitive11, jsonWriter17);
        boolean boolean21 = jsonArray0.remove((com.google.gson.JsonElement) jsonPrimitive11);
        // The following exception was thrown during execution in test generation
        try {
            char char22 = jsonArray0.getAsCharacter();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonElementItor6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(typeAdapterFactory12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jsonWriter15);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonObject jsonObject5 = new com.google.gson.JsonObject();
        boolean boolean7 = jsonObject5.has("");
        com.google.gson.JsonPrimitive jsonPrimitive9 = jsonObject5.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader10 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject5);
        com.google.gson.stream.JsonToken jsonToken11 = jsonTreeReader10.peek();
        java.lang.String str12 = jsonTreeReader10.toString();
        jsonTreeReader10.skipValue();
        boolean boolean14 = jsonTreeReader10.hasNext();
        java.lang.String str15 = jsonTreeReader10.getPath();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jsonPrimitive9);
        org.junit.Assert.assertTrue("'" + jsonToken11 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_OBJECT + "'", jsonToken11.equals(com.google.gson.stream.JsonToken.BEGIN_OBJECT));
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "JsonTreeReader" + "'", str12, "JsonTreeReader");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "$" + "'", str15, "$");
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        jsonArray0.add((java.lang.Number) 10);
        int int3 = jsonArray0.size();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor4 = jsonArray0.iterator();
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter6 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson5, sqlDateTypeAdapterTypeAdapter6, sqlDateTypeAdapterClass7);
        java.lang.String str10 = gson5.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger13 = jsonPrimitive12.getAsBigInteger();
        java.lang.String str14 = gson5.toJson((java.lang.Object) bigInteger13);
        jsonArray0.add((java.lang.Number) bigInteger13);
        // The following exception was thrown during execution in test generation
        try {
            char char16 = jsonArray0.getAsCharacter();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(jsonElementItor4);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "100" + "'", str10, "100");
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "100" + "'", str14, "100");
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.TypeAdapter<java.lang.Cloneable> cloneableTypeAdapter7 = null;
        java.lang.Class<java.lang.Cloneable> cloneableClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable> cloneableArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable>(gson0, cloneableTypeAdapter7, cloneableClass8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = cloneableArrayTypeAdapter9.fromJson("com.google.gson.JsonObject");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        com.google.gson.stream.JsonToken jsonToken20 = jsonTreeReader19.peek();
        jsonTreeReader19.close();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertTrue("'" + jsonToken20 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_ARRAY + "'", jsonToken20.equals(com.google.gson.stream.JsonToken.BEGIN_ARRAY));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        boolean boolean2 = jsonObject0.has("");
        com.google.gson.JsonPrimitive jsonPrimitive4 = jsonObject0.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader5 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject0);
        com.google.gson.JsonElement jsonElement7 = jsonObject0.remove("null");
        com.google.gson.JsonObject jsonObject9 = jsonObject0.getAsJsonObject("com.google.gson.JsonIOException: ");
        com.google.gson.JsonArray jsonArray10 = new com.google.gson.JsonArray();
        jsonArray10.add((java.lang.Number) 10);
        int int13 = jsonArray10.size();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor14 = jsonArray10.iterator();
        com.google.gson.Gson gson15 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter16 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass17 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter18 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson15, sqlDateTypeAdapterTypeAdapter16, sqlDateTypeAdapterClass17);
        java.lang.String str20 = gson15.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive22 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger23 = jsonPrimitive22.getAsBigInteger();
        java.lang.String str24 = gson15.toJson((java.lang.Object) bigInteger23);
        jsonArray10.add((java.lang.Number) bigInteger23);
        boolean boolean26 = jsonObject0.equals((java.lang.Object) bigInteger23);
        boolean boolean28 = jsonObject0.has("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jsonPrimitive4);
        org.junit.Assert.assertNull(jsonElement7);
        org.junit.Assert.assertNull(jsonObject9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(jsonElementItor14);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "100" + "'", str20, "100");
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "100" + "'", str24, "100");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        boolean boolean20 = jsonTreeReader19.hasNext();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.Gson gson7 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter8 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass9 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter10 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson7, sqlDateTypeAdapterTypeAdapter8, sqlDateTypeAdapterClass9);
        com.google.gson.JsonNull jsonNull11 = new com.google.gson.JsonNull();
        java.lang.String str12 = gson7.toJson((com.google.gson.JsonElement) jsonNull11);
        com.google.gson.JsonArray jsonArray13 = new com.google.gson.JsonArray();
        jsonArray13.add((java.lang.Number) 10);
        boolean boolean16 = jsonArray13.getAsBoolean();
        boolean boolean17 = jsonArray13.getAsBoolean();
        com.google.gson.JsonArray jsonArray18 = new com.google.gson.JsonArray();
        jsonArray18.add((java.lang.Number) 10);
        boolean boolean21 = jsonArray18.getAsBoolean();
        jsonArray18.add((java.lang.Boolean) true);
        jsonArray13.addAll(jsonArray18);
        java.lang.String str25 = gson7.toJson((java.lang.Object) jsonArray18);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader26 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray18);
        java.lang.reflect.Type type27 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.reflect.Type type28 = gson0.fromJson((com.google.gson.stream.JsonReader) jsonTreeReader26, type27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "null" + "'", str12, "null");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "[10,true]" + "'", str25, "[10,true]");
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        java.lang.Object obj10 = null;
        java.lang.Appendable appendable11 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson(obj10, appendable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter8 = charSequenceArrayTypeAdapter6.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = objTypeAdapter8.fromJson("com.google.gson.JsonParseException: ? extends ? super com.google.gson.JsonIOException");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(objTypeAdapter8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonObject jsonObject4 = new com.google.gson.JsonObject();
        boolean boolean6 = jsonObject4.has("");
        com.google.gson.JsonPrimitive jsonPrimitive8 = jsonObject4.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader9 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject4);
        java.lang.String str10 = jsonTreeReader9.getPath();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj11 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jsonPrimitive8);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "$" + "'", str10, "$");
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement5 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy4);
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter6 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter7 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter7.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonTreeWriter7.value(true);
        java.sql.Time time11 = null;
        timeTypeAdapter6.write(jsonWriter10, time11);
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter13 = timeTypeAdapter6.nullSafe();
        java.sql.Time time14 = null;
        com.google.gson.JsonElement jsonElement15 = timeTypeAdapter13.toJsonTree(time14);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter16 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter17 = sqlDateTypeAdapter16.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter18 = dateTypeAdapter17.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter19 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter20 = sqlDateTypeAdapter19.nullSafe();
        com.google.gson.JsonNull jsonNull21 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date22 = dateTypeAdapter20.fromJsonTree((com.google.gson.JsonElement) jsonNull21);
        boolean boolean24 = jsonNull21.equals((java.lang.Object) 1L);
        java.sql.Date date25 = dateTypeAdapter17.fromJsonTree((com.google.gson.JsonElement) jsonNull21);
        java.lang.Class<?> wildcardClass26 = jsonNull21.getClass();
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken27 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass26);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter28 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date29 = null;
        com.google.gson.JsonElement jsonElement30 = dateTypeAdapter28.toJsonTree(date29);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter31 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter31.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonWriter32.value((double) (byte) 1);
        java.util.Date date35 = null;
        dateTypeAdapter28.write(jsonWriter34, date35);
        jsonWriter34.setLenient(false);
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonWriter34.value("? extends ? super com.google.gson.JsonIOException");
        boolean boolean41 = jsonWriter34.isLenient();
        gson0.toJson((java.lang.Object) jsonElement15, (java.lang.reflect.Type) wildcardClass26, jsonWriter34);
        com.google.gson.JsonArray jsonArray43 = new com.google.gson.JsonArray();
        jsonArray43.add((java.lang.Number) 10);
        boolean boolean46 = jsonArray43.getAsBoolean();
        boolean boolean47 = jsonArray43.getAsBoolean();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor48 = jsonArray43.iterator();
        com.google.gson.JsonNull jsonNull49 = new com.google.gson.JsonNull();
        java.lang.String str50 = jsonNull49.toString();
        boolean boolean51 = jsonArray43.remove((com.google.gson.JsonElement) jsonNull49);
        java.math.BigDecimal bigDecimal52 = jsonArray43.getAsBigDecimal();
        java.lang.Number number53 = jsonArray43.getAsNumber();
        java.lang.Appendable appendable54 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) jsonArray43, appendable54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(timeTypeAdapter13);
        org.junit.Assert.assertNotNull(jsonElement15);
        org.junit.Assert.assertNotNull(dateTypeAdapter17);
        org.junit.Assert.assertNotNull(dateTypeAdapter18);
        org.junit.Assert.assertNotNull(dateTypeAdapter20);
        org.junit.Assert.assertNotNull(jsonNull21);
        org.junit.Assert.assertNull(date22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardTypeToken27);
        org.junit.Assert.assertNotNull(jsonElement30);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(jsonElementItor48);
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "null" + "'", str50, "null");
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(bigDecimal52);
        org.junit.Assert.assertEquals("'" + number53 + "' != '" + 10 + "'", number53, 10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        jsonTreeReader19.skipValue();
        // The following exception was thrown during execution in test generation
        try {
            double double21 = jsonTreeReader19.nextDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NUMBER but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        jsonTreeReader19.skipValue();
        boolean boolean21 = jsonTreeReader19.hasNext();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.TypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeTypeAdapter19 = null;
        java.lang.Class<java.lang.reflect.ParameterizedType> parameterizedTypeClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType>(gson0, parameterizedTypeTypeAdapter19, parameterizedTypeClass20);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter22 = parameterizedTypeArrayTypeAdapter21.nullSafe();
        com.google.gson.stream.JsonToken jsonToken23 = com.google.gson.stream.JsonToken.NAME;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement24 = objTypeAdapter22.toJsonTree((java.lang.Object) jsonToken23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter22);
        org.junit.Assert.assertTrue("'" + jsonToken23 + "' != '" + com.google.gson.stream.JsonToken.NAME + "'", jsonToken23.equals(com.google.gson.stream.JsonToken.NAME));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter6 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter6, typeAdapterFactoryClass7);
        java.io.Writer writer9 = null;
        com.google.gson.internal.Excluder excluder10 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.internal.Excluder excluder11 = excluder10.disableInnerClassSerialization();
        com.google.gson.ExclusionStrategy exclusionStrategy12 = null;
        com.google.gson.internal.Excluder excluder15 = excluder11.withExclusionStrategy(exclusionStrategy12, true, true);
        com.google.gson.internal.Excluder excluder16 = excluder11.excludeFieldsWithoutExposeAnnotation();
        java.lang.Class<?> wildcardClass17 = excluder16.getClass();
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter8.toJson(writer9, (java.lang.Object) excluder16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(excluder10);
        org.junit.Assert.assertNotNull(excluder11);
        org.junit.Assert.assertNotNull(excluder15);
        org.junit.Assert.assertNotNull(excluder16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        boolean boolean2 = jsonObject0.has("");
        com.google.gson.JsonPrimitive jsonPrimitive4 = jsonObject0.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader5 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject0);
        com.google.gson.JsonElement jsonElement7 = jsonObject0.remove("null");
        com.google.gson.JsonObject jsonObject9 = jsonObject0.getAsJsonObject("com.google.gson.JsonIOException: ");
        com.google.gson.JsonArray jsonArray10 = new com.google.gson.JsonArray();
        jsonArray10.add((java.lang.Number) 10);
        int int13 = jsonArray10.size();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor14 = jsonArray10.iterator();
        com.google.gson.Gson gson15 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter16 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass17 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter18 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson15, sqlDateTypeAdapterTypeAdapter16, sqlDateTypeAdapterClass17);
        java.lang.String str20 = gson15.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive22 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger23 = jsonPrimitive22.getAsBigInteger();
        java.lang.String str24 = gson15.toJson((java.lang.Object) bigInteger23);
        jsonArray10.add((java.lang.Number) bigInteger23);
        boolean boolean26 = jsonObject0.equals((java.lang.Object) bigInteger23);
        byte byte27 = bigInteger23.byteValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jsonPrimitive4);
        org.junit.Assert.assertNull(jsonElement7);
        org.junit.Assert.assertNull(jsonObject9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(jsonElementItor14);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "100" + "'", str20, "100");
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "100" + "'", str24, "100");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + byte27 + "' != '" + (byte) 100 + "'", byte27 == (byte) 100);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter7 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter8 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter8.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter8.value(true);
        java.sql.Time time12 = null;
        timeTypeAdapter7.write(jsonWriter11, time12);
        java.sql.Time time14 = null;
        com.google.gson.JsonElement jsonElement15 = timeTypeAdapter7.toJsonTree(time14);
        java.lang.String str16 = gson0.toJson(jsonElement15);
        java.lang.Throwable throwable21 = null;
        com.google.gson.JsonIOException jsonIOException22 = new com.google.gson.JsonIOException("", throwable21);
        com.google.gson.stream.MalformedJsonException malformedJsonException23 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException22);
        com.google.gson.stream.MalformedJsonException malformedJsonException24 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException22);
        com.google.gson.JsonIOException jsonIOException25 = new com.google.gson.JsonIOException("hi!", (java.lang.Throwable) jsonIOException22);
        com.google.gson.JsonElement jsonElement26 = gson0.toJsonTree((java.lang.Object) "hi!");
        com.google.gson.JsonPrimitive jsonPrimitive28 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger29 = jsonPrimitive28.getAsBigInteger();
        short short30 = jsonPrimitive28.getAsShort();
        long long31 = jsonPrimitive28.getAsLong();
        byte byte32 = jsonPrimitive28.getAsByte();
        byte byte33 = jsonPrimitive28.getAsByte();
        java.math.BigDecimal bigDecimal34 = jsonPrimitive28.getAsBigDecimal();
        java.lang.Appendable appendable35 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive28, appendable35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonElement15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertNotNull(jsonElement26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 100 + "'", short30 == (short) 100);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertTrue("'" + byte32 + "' != '" + (byte) 100 + "'", byte32 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte33 + "' != '" + (byte) 100 + "'", byte33 == (byte) 100);
        org.junit.Assert.assertNotNull(bigDecimal34);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.TypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeTypeAdapter19 = null;
        java.lang.Class<java.lang.reflect.ParameterizedType> parameterizedTypeClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType>(gson0, parameterizedTypeTypeAdapter19, parameterizedTypeClass20);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter22 = parameterizedTypeArrayTypeAdapter21.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter23 = objTypeAdapter22.nullSafe();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter22);
        org.junit.Assert.assertNotNull(objTypeAdapter23);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.JsonArray jsonArray5 = new com.google.gson.JsonArray();
        jsonArray5.add((java.lang.Number) 10);
        int int8 = jsonArray5.size();
        com.google.gson.JsonArray jsonArray9 = new com.google.gson.JsonArray();
        jsonArray9.add((java.lang.Number) 10);
        boolean boolean12 = jsonArray9.getAsBoolean();
        jsonArray9.add((java.lang.Boolean) true);
        boolean boolean15 = jsonArray5.contains((com.google.gson.JsonElement) jsonArray9);
        com.google.gson.JsonArray jsonArray16 = new com.google.gson.JsonArray();
        jsonArray16.add((java.lang.Number) 10);
        int int19 = jsonArray16.getAsInt();
        com.google.gson.JsonArray jsonArray20 = new com.google.gson.JsonArray();
        jsonArray20.add((java.lang.Number) 10);
        boolean boolean23 = jsonArray20.getAsBoolean();
        boolean boolean24 = jsonArray20.getAsBoolean();
        boolean boolean25 = jsonArray20.getAsBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive27 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str28 = jsonPrimitive27.getAsString();
        boolean boolean29 = jsonPrimitive27.isJsonArray();
        boolean boolean30 = jsonArray20.contains((com.google.gson.JsonElement) jsonPrimitive27);
        jsonArray16.addAll(jsonArray20);
        boolean boolean32 = jsonArray5.remove((com.google.gson.JsonElement) jsonArray20);
        long long33 = jsonArray5.getAsLong();
        java.lang.Appendable appendable34 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonArray5, appendable34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "false" + "'", str28, "false");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.gson.JsonNull jsonNull0 = new com.google.gson.JsonNull();
        java.lang.String str1 = jsonNull0.toString();
        com.google.gson.JsonArray jsonArray2 = new com.google.gson.JsonArray();
        jsonArray2.add((java.lang.Number) 10);
        boolean boolean5 = jsonArray2.getAsBoolean();
        jsonArray2.add((java.lang.Boolean) true);
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor8 = jsonArray2.iterator();
        com.google.gson.JsonElement jsonElement10 = jsonArray2.get(1);
        com.google.gson.Gson gson11 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive13 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory14 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean15 = jsonPrimitive13.equals((java.lang.Object) typeAdapterFactory14);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter16 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter16.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter16.value(true);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonWriter19.value(true);
        gson11.toJson((com.google.gson.JsonElement) jsonPrimitive13, jsonWriter19);
        boolean boolean23 = jsonArray2.remove((com.google.gson.JsonElement) jsonPrimitive13);
        boolean boolean24 = jsonNull0.equals((java.lang.Object) boolean23);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "null" + "'", str1, "null");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jsonElementItor8);
        org.junit.Assert.assertNotNull(jsonElement10);
        org.junit.Assert.assertNotNull(typeAdapterFactory14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonParseException jsonParseException11 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonSyntaxException jsonSyntaxException12 = new com.google.gson.JsonSyntaxException("? extends ? super com.google.gson.JsonIOException", (java.lang.Throwable) jsonParseException11);
        com.google.gson.JsonSyntaxException jsonSyntaxException13 = new com.google.gson.JsonSyntaxException("10", (java.lang.Throwable) jsonSyntaxException12);
        com.google.gson.JsonParseException jsonParseException14 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonSyntaxException13);
        com.google.gson.stream.MalformedJsonException malformedJsonException15 = new com.google.gson.stream.MalformedJsonException("", (java.lang.Throwable) jsonParseException14);
        java.lang.Throwable[] throwableArray16 = jsonParseException14.getSuppressed();
        com.google.gson.JsonElement jsonElement17 = gson0.toJsonTree((java.lang.Object) throwableArray16);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertArrayEquals(throwableArray16, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(jsonElement17);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        java.lang.Object obj19 = null;
        boolean boolean20 = jsonArray11.equals(obj19);
        jsonArray11.add("{\"\":10,\"? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>\":\"\\\"false\\\"\"}");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonObject jsonObject20 = jsonArray11.getAsJsonObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Not a JSON Object: [10,true]");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        java.lang.Throwable throwable11 = null;
        com.google.gson.JsonIOException jsonIOException12 = new com.google.gson.JsonIOException("", throwable11);
        com.google.gson.stream.MalformedJsonException malformedJsonException13 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException12);
        com.google.gson.stream.MalformedJsonException malformedJsonException14 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException12);
        com.google.gson.JsonIOException jsonIOException15 = new com.google.gson.JsonIOException("hi!", (java.lang.Throwable) jsonIOException12);
        com.google.gson.JsonSyntaxException jsonSyntaxException16 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonIOException12);
        java.lang.String str17 = gson0.toJson((java.lang.Object) jsonSyntaxException16);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "{\"detailMessage\":\"com.google.gson.JsonIOException: \",\"cause\":{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]},\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str17, "{\"detailMessage\":\"com.google.gson.JsonIOException: \",\"cause\":{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]},\"stackTrace\":[],\"suppressedExceptions\":[]}");
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        jsonArray4.add((java.lang.Number) 10);
        boolean boolean7 = jsonArray4.getAsBoolean();
        boolean boolean8 = jsonArray4.getAsBoolean();
        com.google.gson.JsonArray jsonArray9 = new com.google.gson.JsonArray();
        jsonArray9.add((java.lang.Number) 10);
        boolean boolean12 = jsonArray9.getAsBoolean();
        jsonArray9.add((java.lang.Boolean) true);
        jsonArray4.addAll(jsonArray9);
        java.lang.Number number16 = null;
        jsonArray4.add(number16);
        com.google.gson.JsonObject jsonObject18 = new com.google.gson.JsonObject();
        boolean boolean20 = jsonObject18.has("");
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject18.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader23 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject18);
        jsonTreeReader23.skipValue();
        boolean boolean25 = jsonArray4.equals((java.lang.Object) jsonTreeReader23);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str26 = gson0.toJson((java.lang.Object) jsonTreeReader23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: class com.google.gson.internal.bind.JsonTreeReader declares multiple JSON fields named stack");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter6 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = objTypeAdapter6.fromJson("com.google.gson.JsonObject");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
        org.junit.Assert.assertNotNull(objTypeAdapter6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = sqlDateTypeAdapterArrayTypeAdapter3.fromJson("");
            org.junit.Assert.fail("Expected exception of type java.io.EOFException; message: End of input at line 1 column 1");
        } catch (java.io.EOFException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        jsonArray4.add((java.lang.Number) 10);
        int int7 = jsonArray4.size();
        com.google.gson.JsonArray jsonArray8 = new com.google.gson.JsonArray();
        jsonArray8.add((java.lang.Number) 10);
        boolean boolean11 = jsonArray8.getAsBoolean();
        jsonArray8.add((java.lang.Boolean) true);
        boolean boolean14 = jsonArray4.contains((com.google.gson.JsonElement) jsonArray8);
        com.google.gson.JsonArray jsonArray15 = new com.google.gson.JsonArray();
        jsonArray15.add((java.lang.Number) 10);
        int int18 = jsonArray15.getAsInt();
        com.google.gson.JsonArray jsonArray19 = new com.google.gson.JsonArray();
        jsonArray19.add((java.lang.Number) 10);
        boolean boolean22 = jsonArray19.getAsBoolean();
        boolean boolean23 = jsonArray19.getAsBoolean();
        boolean boolean24 = jsonArray19.getAsBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive26 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str27 = jsonPrimitive26.getAsString();
        boolean boolean28 = jsonPrimitive26.isJsonArray();
        boolean boolean29 = jsonArray19.contains((com.google.gson.JsonElement) jsonPrimitive26);
        jsonArray15.addAll(jsonArray19);
        boolean boolean31 = jsonArray4.remove((com.google.gson.JsonElement) jsonArray19);
        boolean boolean32 = jsonArray4.isJsonArray();
        long long33 = jsonArray4.getAsLong();
        java.lang.reflect.Type type34 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str35 = gson0.toJson((java.lang.Object) jsonArray4, type34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "false" + "'", str27, "false");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = objTypeAdapter4.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter6 = objTypeAdapter4.nullSafe();
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
        org.junit.Assert.assertNotNull(objTypeAdapter6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter19 = null;
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter20 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter21 = sqlDateTypeAdapter20.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter22 = dateTypeAdapter21.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter23 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter24 = sqlDateTypeAdapter23.nullSafe();
        com.google.gson.JsonNull jsonNull25 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date26 = dateTypeAdapter24.fromJsonTree((com.google.gson.JsonElement) jsonNull25);
        boolean boolean28 = jsonNull25.equals((java.lang.Object) 1L);
        java.sql.Date date29 = dateTypeAdapter21.fromJsonTree((com.google.gson.JsonElement) jsonNull25);
        java.lang.Class<?> wildcardClass30 = jsonNull25.getClass();
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken31 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass30);
        com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapterRuntimeTypeWrapper32 = new com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter19, (java.lang.reflect.Type) wildcardClass30);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(dateTypeAdapter21);
        org.junit.Assert.assertNotNull(dateTypeAdapter22);
        org.junit.Assert.assertNotNull(dateTypeAdapter24);
        org.junit.Assert.assertNotNull(jsonNull25);
        org.junit.Assert.assertNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(date29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(wildcardTypeToken31);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger8 = jsonPrimitive7.getAsBigInteger();
        java.lang.String str9 = gson0.toJson((java.lang.Object) bigInteger8);
        java.lang.String str10 = gson0.toString();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add("hi!");
        char char14 = jsonArray11.getAsCharacter();
        com.google.gson.JsonPrimitive jsonPrimitive17 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean18 = jsonPrimitive17.isBoolean();
        com.google.gson.JsonElement jsonElement19 = jsonArray11.set((int) (byte) 0, (com.google.gson.JsonElement) jsonPrimitive17);
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor20 = jsonArray11.iterator();
        com.google.gson.JsonElement jsonElement21 = gson0.toJsonTree((java.lang.Object) jsonElementItor20);
        // The following exception was thrown during execution in test generation
        try {
            java.math.BigDecimal bigDecimal22 = jsonElement21.getAsBigDecimal();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: JsonObject");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "100" + "'", str9, "100");
        org.junit.Assert.assertTrue("'" + char14 + "' != '" + 'h' + "'", char14 == 'h');
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(jsonElementItor20);
        org.junit.Assert.assertNotNull(jsonElement21);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory>(gson0, collectionTypeAdapterFactoryTypeAdapter1, collectionTypeAdapterFactoryClass2);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter4 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter5 = jsonTreeWriter4.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonTreeWriter4.value(true);
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter4.value(true);
        jsonTreeWriter4.flush();
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonTreeWriter4.value((java.lang.Number) (short) 100);
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter4.endArray();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter4.nullValue();
        boolean boolean15 = jsonTreeWriter4.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter4.value("100");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str18 = collectionTypeAdapterFactoryArrayTypeAdapter3.toJson((java.lang.Object) jsonTreeWriter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonWriter5);
        org.junit.Assert.assertNotNull(jsonWriter7);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jsonWriter17);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter6 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter7 = sqlDateTypeAdapter6.nullSafe();
        java.sql.Date date8 = null;
        com.google.gson.JsonElement jsonElement9 = sqlDateTypeAdapter6.toJsonTree(date8);
        java.sql.Date date10 = sqlDateTypeAdapter5.fromJsonTree(jsonElement9);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter11 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonTreeWriter11.beginArray();
        jsonWriter12.flush();
        java.sql.Date date14 = null;
        sqlDateTypeAdapter5.write(jsonWriter12, date14);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter16 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter16.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter16.value(true);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter16.value(true);
        jsonTreeWriter16.flush();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter16.value((java.lang.Number) (short) 100);
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter16.endArray();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter16.nullValue();
        boolean boolean27 = jsonTreeWriter16.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter16.value("100");
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter16.value((long) (short) 0);
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter3.write(jsonWriter12, (java.lang.Object) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(dateTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(date10);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter31);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Throwable throwable9 = null;
        com.google.gson.JsonIOException jsonIOException10 = new com.google.gson.JsonIOException("", throwable9);
        com.google.gson.stream.MalformedJsonException malformedJsonException11 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException10);
        com.google.gson.stream.MalformedJsonException malformedJsonException12 = new com.google.gson.stream.MalformedJsonException("hi!", (java.lang.Throwable) jsonIOException10);
        com.google.gson.stream.MalformedJsonException malformedJsonException13 = new com.google.gson.stream.MalformedJsonException("false", (java.lang.Throwable) malformedJsonException12);
        java.lang.Appendable appendable14 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) malformedJsonException13, appendable14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter6 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter6, typeAdapterFactoryClass7);
        java.io.Writer writer9 = null;
        com.google.gson.JsonArray jsonArray10 = new com.google.gson.JsonArray();
        jsonArray10.add((java.lang.Number) 10);
        com.google.gson.JsonArray jsonArray13 = new com.google.gson.JsonArray();
        jsonArray13.add((java.lang.Number) 10);
        boolean boolean16 = jsonArray13.getAsBoolean();
        java.math.BigInteger bigInteger17 = jsonArray13.getAsBigInteger();
        com.google.gson.JsonPrimitive jsonPrimitive19 = new com.google.gson.JsonPrimitive("null");
        boolean boolean20 = jsonArray13.contains((com.google.gson.JsonElement) jsonPrimitive19);
        boolean boolean21 = jsonArray13.isJsonPrimitive();
        long long22 = jsonArray13.getAsLong();
        boolean boolean23 = jsonArray10.contains((com.google.gson.JsonElement) jsonArray13);
        java.math.BigDecimal bigDecimal24 = jsonArray13.getAsBigDecimal();
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter8.toJson(writer9, (java.lang.Object) jsonArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(bigDecimal24);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.JsonPrimitive jsonPrimitive6 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 0);
        java.math.BigDecimal bigDecimal7 = jsonPrimitive6.getAsBigDecimal();
        char char8 = jsonPrimitive6.getAsCharacter();
        byte byte9 = jsonPrimitive6.getAsByte();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = objTypeAdapter4.toJson((java.lang.Object) byte9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(bigDecimal7);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '0' + "'", char8 == '0');
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonPrimitive jsonPrimitive11 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean12 = jsonPrimitive11.isBoolean();
        boolean boolean13 = jsonPrimitive11.isString();
        com.google.gson.JsonParseException jsonParseException16 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException17 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException16);
        com.google.gson.JsonParseException jsonParseException19 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException20 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException19);
        jsonParseException17.addSuppressed((java.lang.Throwable) jsonParseException20);
        com.google.gson.JsonParseException jsonParseException22 = new com.google.gson.JsonParseException("? extends ? super com.google.gson.JsonIOException", (java.lang.Throwable) jsonParseException17);
        com.google.gson.JsonSyntaxException jsonSyntaxException23 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonParseException22);
        boolean boolean24 = jsonPrimitive11.equals((java.lang.Object) jsonParseException22);
        boolean boolean25 = jsonPrimitive11.isNumber();
        float float26 = jsonPrimitive11.getAsFloat();
        boolean boolean27 = jsonPrimitive11.isBoolean();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter28 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter28.beginArray();
        jsonWriter29.flush();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonWriter29.beginArray();
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive11, jsonWriter31);
        java.lang.Object obj33 = null;
        boolean boolean34 = jsonPrimitive11.equals(obj33);
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 100.0f + "'", float26 == 100.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray12 = jsonObject10.getAsJsonArray("com.google.gson.JsonIOException");
        java.lang.String str13 = gson0.toJson((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.JsonArray jsonArray14 = new com.google.gson.JsonArray();
        jsonArray14.add((java.lang.Number) 10);
        boolean boolean17 = jsonArray14.getAsBoolean();
        boolean boolean18 = jsonArray14.getAsBoolean();
        boolean boolean19 = jsonArray14.getAsBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive21 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str22 = jsonPrimitive21.getAsString();
        boolean boolean23 = jsonPrimitive21.isJsonArray();
        boolean boolean24 = jsonArray14.contains((com.google.gson.JsonElement) jsonPrimitive21);
        java.lang.String str25 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive21);
        com.google.gson.JsonArray jsonArray26 = new com.google.gson.JsonArray();
        jsonArray26.add((java.lang.Number) 10);
        boolean boolean29 = jsonArray26.getAsBoolean();
        java.math.BigInteger bigInteger30 = jsonArray26.getAsBigInteger();
        com.google.gson.JsonPrimitive jsonPrimitive32 = new com.google.gson.JsonPrimitive("null");
        boolean boolean33 = jsonArray26.contains((com.google.gson.JsonElement) jsonPrimitive32);
        boolean boolean34 = jsonArray26.isJsonPrimitive();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor35 = jsonArray26.iterator();
        com.google.gson.JsonArray jsonArray36 = new com.google.gson.JsonArray();
        jsonArray36.add((java.lang.Boolean) false);
        com.google.gson.JsonArray jsonArray40 = new com.google.gson.JsonArray();
        jsonArray40.add((java.lang.Number) 10);
        boolean boolean43 = jsonArray40.getAsBoolean();
        boolean boolean44 = jsonArray40.getAsBoolean();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor45 = jsonArray40.iterator();
        com.google.gson.JsonNull jsonNull46 = new com.google.gson.JsonNull();
        java.lang.String str47 = jsonNull46.toString();
        boolean boolean48 = jsonArray40.remove((com.google.gson.JsonElement) jsonNull46);
        com.google.gson.JsonElement jsonElement49 = jsonArray36.set(0, (com.google.gson.JsonElement) jsonNull46);
        jsonArray26.add((com.google.gson.JsonElement) jsonArray36);
        com.google.gson.JsonElement jsonElement52 = jsonArray26.get((int) (short) 0);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter53 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter54 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter55 = sqlDateTypeAdapter54.nullSafe();
        java.sql.Date date56 = null;
        com.google.gson.JsonElement jsonElement57 = sqlDateTypeAdapter54.toJsonTree(date56);
        java.sql.Date date58 = sqlDateTypeAdapter53.fromJsonTree(jsonElement57);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter59 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter60 = jsonTreeWriter59.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter62 = jsonTreeWriter59.value(true);
        jsonWriter62.setSerializeNulls(false);
        java.sql.Date date65 = null;
        sqlDateTypeAdapter53.write(jsonWriter62, date65);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter67 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter68 = jsonTreeWriter67.beginArray();
        jsonTreeWriter67.flush();
        com.google.gson.stream.JsonWriter jsonWriter71 = jsonTreeWriter67.value("com.google.gson.JsonParseException: hi!");
        java.sql.Date date72 = null;
        sqlDateTypeAdapter53.write((com.google.gson.stream.JsonWriter) jsonTreeWriter67, date72);
        gson0.toJson(jsonElement52, (com.google.gson.stream.JsonWriter) jsonTreeWriter67);
        com.google.gson.stream.JsonWriter jsonWriter76 = jsonTreeWriter67.value((double) '4');
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(jsonArray12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "{}" + "'", str13, "{}");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "false" + "'", str22, "false");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "false" + "'", str25, "false");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(jsonElementItor35);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonElementItor45);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "null" + "'", str47, "null");
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(jsonElement49);
        org.junit.Assert.assertNotNull(jsonElement52);
        org.junit.Assert.assertNotNull(dateTypeAdapter55);
        org.junit.Assert.assertNotNull(jsonElement57);
        org.junit.Assert.assertNull(date58);
        org.junit.Assert.assertNotNull(jsonWriter60);
        org.junit.Assert.assertNotNull(jsonWriter62);
        org.junit.Assert.assertNotNull(jsonWriter68);
        org.junit.Assert.assertNotNull(jsonWriter71);
        org.junit.Assert.assertNotNull(jsonWriter76);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.JsonElement jsonElement7 = null;
        java.lang.String str8 = gson0.toJson(jsonElement7);
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive("10");
        double double11 = jsonPrimitive10.getAsDouble();
        boolean boolean12 = jsonPrimitive10.isNumber();
        double double13 = jsonPrimitive10.getAsDouble();
        com.google.gson.internal.Excluder excluder14 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.internal.Excluder excluder15 = excluder14.disableInnerClassSerialization();
        com.google.gson.ExclusionStrategy exclusionStrategy16 = null;
        com.google.gson.internal.Excluder excluder19 = excluder15.withExclusionStrategy(exclusionStrategy16, true, true);
        com.google.gson.internal.Excluder excluder20 = excluder15.excludeFieldsWithoutExposeAnnotation();
        java.lang.Class<?> wildcardClass21 = excluder20.getClass();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter22 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter22.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter22.value(true);
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter22.value(true);
        jsonTreeWriter22.flush();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter22.value((java.lang.Number) (short) 100);
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter22.endArray();
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter22.value(" ");
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) double13, (java.lang.reflect.Type) wildcardClass21, (com.google.gson.stream.JsonWriter) jsonTreeWriter22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Can not set double field com.google.gson.internal.Excluder.version to java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "null" + "'", str8, "null");
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(excluder14);
        org.junit.Assert.assertNotNull(excluder15);
        org.junit.Assert.assertNotNull(excluder19);
        org.junit.Assert.assertNotNull(excluder20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertNotNull(jsonWriter33);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonPrimitive jsonPrimitive11 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean12 = jsonPrimitive11.isBoolean();
        boolean boolean13 = jsonPrimitive11.isString();
        com.google.gson.JsonParseException jsonParseException16 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException17 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException16);
        com.google.gson.JsonParseException jsonParseException19 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException20 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException19);
        jsonParseException17.addSuppressed((java.lang.Throwable) jsonParseException20);
        com.google.gson.JsonParseException jsonParseException22 = new com.google.gson.JsonParseException("? extends ? super com.google.gson.JsonIOException", (java.lang.Throwable) jsonParseException17);
        com.google.gson.JsonSyntaxException jsonSyntaxException23 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonParseException22);
        boolean boolean24 = jsonPrimitive11.equals((java.lang.Object) jsonParseException22);
        boolean boolean25 = jsonPrimitive11.isNumber();
        float float26 = jsonPrimitive11.getAsFloat();
        boolean boolean27 = jsonPrimitive11.isBoolean();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter28 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter28.beginArray();
        jsonWriter29.flush();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonWriter29.beginArray();
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive11, jsonWriter31);
        boolean boolean33 = jsonWriter31.isLenient();
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 100.0f + "'", float26 == 100.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter8 = objTypeAdapter7.nullSafe();
        java.io.Writer writer9 = null;
        com.google.gson.stream.JsonToken jsonToken10 = com.google.gson.stream.JsonToken.END_DOCUMENT;
        // The following exception was thrown during execution in test generation
        try {
            objTypeAdapter7.toJson(writer9, (java.lang.Object) jsonToken10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(objTypeAdapter8);
        org.junit.Assert.assertTrue("'" + jsonToken10 + "' != '" + com.google.gson.stream.JsonToken.END_DOCUMENT + "'", jsonToken10.equals(com.google.gson.stream.JsonToken.END_DOCUMENT));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter6 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter6, typeAdapterFactoryClass7);
        com.google.gson.JsonObject jsonObject9 = new com.google.gson.JsonObject();
        boolean boolean11 = jsonObject9.has("");
        jsonObject9.addProperty("", (java.lang.Number) 100.0d);
        com.google.gson.JsonObject jsonObject16 = jsonObject9.getAsJsonObject("hi!");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter17 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter17.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter17.value("com.google.gson.JsonIOException: ");
        boolean boolean22 = jsonWriter21.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonWriter21.nullValue();
        boolean boolean24 = jsonObject9.equals((java.lang.Object) jsonWriter21);
        java.lang.Object obj25 = null;
        typeAdapterFactoryArrayTypeAdapter8.write(jsonWriter21, obj25);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter27 = typeAdapterFactoryArrayTypeAdapter8.nullSafe();
        java.lang.Object obj28 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str29 = objTypeAdapter27.toJson(obj28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JSON must start with an array or an object.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(jsonObject16);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(objTypeAdapter27);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        java.lang.String str4 = gson0.toString();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter5 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter6 = sqlDateTypeAdapter5.nullSafe();
        java.sql.Date date7 = null;
        com.google.gson.JsonElement jsonElement8 = sqlDateTypeAdapter5.toJsonTree(date7);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) jsonElement8);
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray12 = jsonObject10.getAsJsonArray("com.google.gson.JsonIOException");
        java.lang.String str13 = gson0.toJson((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.JsonArray jsonArray14 = new com.google.gson.JsonArray();
        jsonArray14.add((java.lang.Number) 10);
        boolean boolean17 = jsonArray14.getAsBoolean();
        boolean boolean18 = jsonArray14.getAsBoolean();
        boolean boolean19 = jsonArray14.getAsBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive21 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        java.lang.String str22 = jsonPrimitive21.getAsString();
        boolean boolean23 = jsonPrimitive21.isJsonArray();
        boolean boolean24 = jsonArray14.contains((com.google.gson.JsonElement) jsonPrimitive21);
        java.lang.String str25 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive21);
        boolean boolean26 = jsonPrimitive21.isJsonPrimitive();
        org.junit.Assert.assertNotNull(dateTypeAdapter6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNull(jsonArray12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "{}" + "'", str13, "{}");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "false" + "'", str22, "false");
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "false" + "'", str25, "false");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.TypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeTypeAdapter19 = null;
        java.lang.Class<java.lang.reflect.ParameterizedType> parameterizedTypeClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType>(gson0, parameterizedTypeTypeAdapter19, parameterizedTypeClass20);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter22 = parameterizedTypeArrayTypeAdapter21.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = parameterizedTypeArrayTypeAdapter21.fromJson("{\"\":10,\"? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>\":\"\\\"false\\\"\"}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BEGIN_OBJECT at line 1 column 2 path $");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter22);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter6 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter6, typeAdapterFactoryClass7);
        com.google.gson.JsonObject jsonObject9 = new com.google.gson.JsonObject();
        boolean boolean11 = jsonObject9.has("");
        jsonObject9.addProperty("", (java.lang.Number) 100.0d);
        com.google.gson.JsonObject jsonObject16 = jsonObject9.getAsJsonObject("hi!");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter17 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter17.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter17.value("com.google.gson.JsonIOException: ");
        boolean boolean22 = jsonWriter21.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonWriter21.nullValue();
        boolean boolean24 = jsonObject9.equals((java.lang.Object) jsonWriter21);
        java.lang.Object obj25 = null;
        typeAdapterFactoryArrayTypeAdapter8.write(jsonWriter21, obj25);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter27 = typeAdapterFactoryArrayTypeAdapter8.nullSafe();
        com.google.gson.JsonArray jsonArray28 = new com.google.gson.JsonArray();
        jsonArray28.add((java.lang.Number) 10);
        boolean boolean31 = jsonArray28.getAsBoolean();
        boolean boolean32 = jsonArray28.getAsBoolean();
        com.google.gson.JsonArray jsonArray33 = new com.google.gson.JsonArray();
        jsonArray33.add((java.lang.Number) 10);
        boolean boolean36 = jsonArray33.getAsBoolean();
        boolean boolean37 = jsonArray33.getAsBoolean();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor38 = jsonArray33.iterator();
        com.google.gson.JsonNull jsonNull39 = new com.google.gson.JsonNull();
        java.lang.String str40 = jsonNull39.toString();
        boolean boolean41 = jsonArray33.remove((com.google.gson.JsonElement) jsonNull39);
        jsonArray28.add((com.google.gson.JsonElement) jsonArray33);
        int int43 = jsonArray33.getAsInt();
        short short44 = jsonArray33.getAsShort();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj45 = typeAdapterFactoryArrayTypeAdapter8.fromJsonTree((com.google.gson.JsonElement) jsonArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(jsonObject16);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(objTypeAdapter27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(jsonElementItor38);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "null" + "'", str40, "null");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
        org.junit.Assert.assertTrue("'" + short44 + "' != '" + (short) 10 + "'", short44 == (short) 10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter6 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter6, typeAdapterFactoryClass7);
        com.google.gson.JsonObject jsonObject9 = new com.google.gson.JsonObject();
        boolean boolean11 = jsonObject9.has("");
        com.google.gson.JsonPrimitive jsonPrimitive13 = jsonObject9.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader14 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject9);
        jsonTreeReader14.skipValue();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj16 = typeAdapterFactoryArrayTypeAdapter8.read((com.google.gson.stream.JsonReader) jsonTreeReader14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(jsonPrimitive13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter6 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter6, typeAdapterFactoryClass7);
        com.google.gson.JsonObject jsonObject9 = new com.google.gson.JsonObject();
        boolean boolean11 = jsonObject9.has("");
        jsonObject9.addProperty("", (java.lang.Number) 100.0d);
        com.google.gson.JsonObject jsonObject16 = jsonObject9.getAsJsonObject("hi!");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter17 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter17.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter17.value("com.google.gson.JsonIOException: ");
        boolean boolean22 = jsonWriter21.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonWriter21.nullValue();
        boolean boolean24 = jsonObject9.equals((java.lang.Object) jsonWriter21);
        java.lang.Object obj25 = null;
        typeAdapterFactoryArrayTypeAdapter8.write(jsonWriter21, obj25);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter27 = typeAdapterFactoryArrayTypeAdapter8.nullSafe();
        com.google.gson.JsonObject jsonObject28 = new com.google.gson.JsonObject();
        boolean boolean30 = jsonObject28.has("");
        com.google.gson.JsonPrimitive jsonPrimitive32 = jsonObject28.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader33 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject28);
        java.lang.String str34 = jsonTreeReader33.toString();
        jsonTreeReader33.skipValue();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = typeAdapterFactoryArrayTypeAdapter8.read((com.google.gson.stream.JsonReader) jsonTreeReader33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(jsonObject16);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(objTypeAdapter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(jsonPrimitive32);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "JsonTreeReader" + "'", str34, "JsonTreeReader");
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter0 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter1 = jsonTreeWriter0.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter2 = jsonTreeWriter0.endArray();
        boolean boolean3 = jsonTreeWriter0.isHtmlSafe();
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        jsonArray4.add("hi!");
        char char7 = jsonArray4.getAsCharacter();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean11 = jsonPrimitive10.isBoolean();
        com.google.gson.JsonElement jsonElement12 = jsonArray4.set((int) (byte) 0, (com.google.gson.JsonElement) jsonPrimitive10);
        java.math.BigInteger bigInteger13 = jsonArray4.getAsBigInteger();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter0.value((java.lang.Number) bigInteger13);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter15 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter15.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter15.value("com.google.gson.JsonIOException: ");
        com.google.gson.JsonElement jsonElement20 = jsonTreeWriter15.get();
        com.google.gson.JsonElement jsonElement21 = jsonTreeWriter15.get();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter15.value(true);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter15.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter15.value((double) 100L);
        com.google.gson.JsonArray jsonArray27 = new com.google.gson.JsonArray();
        jsonArray27.add((java.lang.Number) 10);
        int int30 = jsonArray27.size();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor31 = jsonArray27.iterator();
        com.google.gson.Gson gson32 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter33 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass34 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter35 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson32, sqlDateTypeAdapterTypeAdapter33, sqlDateTypeAdapterClass34);
        java.lang.String str37 = gson32.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive39 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger40 = jsonPrimitive39.getAsBigInteger();
        java.lang.String str41 = gson32.toJson((java.lang.Object) bigInteger40);
        jsonArray27.add((java.lang.Number) bigInteger40);
        com.google.gson.stream.JsonWriter jsonWriter43 = jsonTreeWriter15.value((java.lang.Number) bigInteger40);
        com.google.gson.stream.JsonWriter jsonWriter44 = jsonTreeWriter0.value((java.lang.Number) bigInteger40);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter0.value((double) (-1L));
        org.junit.Assert.assertNotNull(jsonWriter1);
        org.junit.Assert.assertNotNull(jsonWriter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'h' + "'", char7 == 'h');
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jsonElement12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonElement20);
        org.junit.Assert.assertNotNull(jsonElement21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(jsonElementItor31);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "100" + "'", str37, "100");
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "100" + "'", str41, "100");
        org.junit.Assert.assertNotNull(jsonWriter43);
        org.junit.Assert.assertNotNull(jsonWriter44);
        org.junit.Assert.assertNotNull(jsonWriter46);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.TypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeTypeAdapter19 = null;
        java.lang.Class<java.lang.reflect.ParameterizedType> parameterizedTypeClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType>(gson0, parameterizedTypeTypeAdapter19, parameterizedTypeClass20);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter22 = parameterizedTypeArrayTypeAdapter21.nullSafe();
        com.google.gson.stream.MalformedJsonException malformedJsonException24 = new com.google.gson.stream.MalformedJsonException("null");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str25 = parameterizedTypeArrayTypeAdapter21.toJson((java.lang.Object) malformedJsonException24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter22);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        jsonTreeReader19.skipValue();
        // The following exception was thrown during execution in test generation
        try {
            jsonTreeReader19.beginObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_OBJECT but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        jsonArray11.add((java.lang.Number) 10);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader21 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        com.google.gson.JsonPrimitive jsonPrimitive23 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean24 = jsonPrimitive23.isBoolean();
        boolean boolean25 = jsonPrimitive23.isString();
        java.lang.Number number26 = jsonPrimitive23.getAsNumber();
        byte byte27 = jsonPrimitive23.getAsByte();
        jsonArray11.add((com.google.gson.JsonElement) jsonPrimitive23);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertEquals("'" + number26 + "' != '" + (short) 100 + "'", number26, (short) 100);
        org.junit.Assert.assertTrue("'" + byte27 + "' != '" + (byte) 100 + "'", byte27 == (byte) 100);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.TypeAdapter<java.lang.Cloneable> cloneableTypeAdapter7 = null;
        java.lang.Class<java.lang.Cloneable> cloneableClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable> cloneableArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable>(gson0, cloneableTypeAdapter7, cloneableClass8);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter10 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter11 = sqlDateTypeAdapter10.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter12 = sqlDateTypeAdapter10.nullSafe();
        java.sql.Date date13 = null;
        com.google.gson.JsonElement jsonElement14 = sqlDateTypeAdapter10.toJsonTree(date13);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter15 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter15.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter15.value("com.google.gson.JsonIOException: ");
        com.google.gson.JsonElement jsonElement20 = jsonTreeWriter15.get();
        com.google.gson.JsonElement jsonElement21 = jsonTreeWriter15.get();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter15.value(true);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter15.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter15.value((double) 100L);
        java.sql.Date date27 = null;
        sqlDateTypeAdapter10.write((com.google.gson.stream.JsonWriter) jsonTreeWriter15, date27);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str29 = gson0.toJson((java.lang.Object) jsonTreeWriter15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: class com.google.gson.internal.bind.JsonTreeWriter declares multiple JSON fields named stack");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(dateTypeAdapter11);
        org.junit.Assert.assertNotNull(dateTypeAdapter12);
        org.junit.Assert.assertNotNull(jsonElement14);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonElement20);
        org.junit.Assert.assertNotNull(jsonElement21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.DateTypeAdapter> dateTypeAdapterTypeAdapter7 = null;
        java.lang.Class<com.google.gson.internal.bind.DateTypeAdapter> dateTypeAdapterClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.DateTypeAdapter> dateTypeAdapterArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.DateTypeAdapter>(gson0, dateTypeAdapterTypeAdapter7, dateTypeAdapterClass8);
        com.google.gson.JsonArray jsonArray10 = new com.google.gson.JsonArray();
        jsonArray10.add((java.lang.Number) 10);
        int int13 = jsonArray10.getAsInt();
        boolean boolean14 = jsonArray10.getAsBoolean();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter15 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter16 = dateTypeAdapter15.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter17 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter18 = sqlDateTypeAdapter17.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter20 = jsonTreeWriter19.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.value(true);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonWriter22.value(true);
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonWriter22.value("");
        java.sql.Date date27 = null;
        sqlDateTypeAdapter17.write(jsonWriter22, date27);
        java.util.Date date29 = null;
        dateTypeAdapter15.write(jsonWriter22, date29);
        java.util.Date date31 = null;
        com.google.gson.JsonElement jsonElement32 = dateTypeAdapter15.toJsonTree(date31);
        java.util.Date date33 = null;
        com.google.gson.JsonElement jsonElement34 = dateTypeAdapter15.toJsonTree(date33);
        boolean boolean35 = jsonArray10.equals((java.lang.Object) dateTypeAdapter15);
        int int36 = jsonArray10.getAsInt();
        short short37 = jsonArray10.getAsShort();
        java.lang.String str38 = gson0.toJson((com.google.gson.JsonElement) jsonArray10);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTypeAdapter16);
        org.junit.Assert.assertNotNull(dateTypeAdapter18);
        org.junit.Assert.assertNotNull(jsonWriter20);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertNotNull(jsonElement32);
        org.junit.Assert.assertNotNull(jsonElement34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + short37 + "' != '" + (short) 10 + "'", short37 == (short) 10);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "[10]" + "'", str38, "[10]");
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.TypeAdapter<java.lang.Cloneable> cloneableTypeAdapter7 = null;
        java.lang.Class<java.lang.Cloneable> cloneableClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable> cloneableArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable>(gson0, cloneableTypeAdapter7, cloneableClass8);
        com.google.gson.TypeAdapter<com.google.gson.stream.JsonReader> jsonReaderTypeAdapter10 = null;
        java.lang.reflect.Type type11 = null;
        com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper<com.google.gson.stream.JsonReader> jsonReaderTypeAdapterRuntimeTypeWrapper12 = new com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper<com.google.gson.stream.JsonReader>(gson0, jsonReaderTypeAdapter10, type11);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = objTypeAdapter4.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter6 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonTreeWriter6.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter6.endArray();
        jsonTreeWriter6.flush();
        com.google.gson.JsonElement jsonElement10 = jsonTreeWriter6.get();
        boolean boolean11 = jsonElement10.isJsonObject();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj12 = objTypeAdapter4.fromJsonTree(jsonElement10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
        org.junit.Assert.assertNotNull(jsonWriter7);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonElement10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        com.google.gson.stream.JsonToken jsonToken20 = jsonTreeReader19.peek();
        com.google.gson.stream.JsonToken jsonToken21 = jsonTreeReader19.peek();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertTrue("'" + jsonToken20 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_ARRAY + "'", jsonToken20.equals(com.google.gson.stream.JsonToken.BEGIN_ARRAY));
        org.junit.Assert.assertTrue("'" + jsonToken21 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_ARRAY + "'", jsonToken21.equals(com.google.gson.stream.JsonToken.BEGIN_ARRAY));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.TypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeTypeAdapter19 = null;
        java.lang.Class<java.lang.reflect.ParameterizedType> parameterizedTypeClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType>(gson0, parameterizedTypeTypeAdapter19, parameterizedTypeClass20);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter22 = parameterizedTypeArrayTypeAdapter21.nullSafe();
        java.lang.Object obj23 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str24 = objTypeAdapter22.toJson(obj23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JSON must start with an array or an object.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter22);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean4 = jsonPrimitive2.equals((java.lang.Object) typeAdapterFactory3);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2, jsonWriter8);
        java.lang.reflect.Type type13 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory jsonAdapterAnnotationTypeAdapterFactory14 = gson0.fromJson("com.google.gson.JsonSyntaxException: ? extends ? super com.google.gson.JsonIOException", type13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = charSequenceArrayTypeAdapter6.nullSafe();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter8 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter9 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonTreeWriter9.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonTreeWriter9.value(true);
        java.sql.Time time13 = null;
        timeTypeAdapter8.write(jsonWriter12, time13);
        java.sql.Time time15 = null;
        com.google.gson.JsonElement jsonElement16 = timeTypeAdapter8.toJsonTree(time15);
        java.sql.Time time17 = null;
        com.google.gson.JsonElement jsonElement18 = timeTypeAdapter8.toJsonTree(time17);
        java.sql.Time time19 = null;
        com.google.gson.JsonElement jsonElement20 = timeTypeAdapter8.toJsonTree(time19);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter21 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter21.beginArray();
        jsonTreeWriter21.flush();
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter21.value("com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter21.value((double) 1);
        jsonWriter27.setLenient(true);
        java.sql.Time time30 = null;
        timeTypeAdapter8.write(jsonWriter27, time30);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str32 = charSequenceArrayTypeAdapter6.toJson((java.lang.Object) time30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JSON must start with an array or an object.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNotNull(jsonElement16);
        org.junit.Assert.assertNotNull(jsonElement18);
        org.junit.Assert.assertNotNull(jsonElement20);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter27);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter0 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter1 = jsonTreeWriter0.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter2 = jsonTreeWriter0.endArray();
        boolean boolean3 = jsonTreeWriter0.isHtmlSafe();
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        jsonArray4.add("hi!");
        char char7 = jsonArray4.getAsCharacter();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean11 = jsonPrimitive10.isBoolean();
        com.google.gson.JsonElement jsonElement12 = jsonArray4.set((int) (byte) 0, (com.google.gson.JsonElement) jsonPrimitive10);
        java.math.BigInteger bigInteger13 = jsonArray4.getAsBigInteger();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter0.value((java.lang.Number) bigInteger13);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter15 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter15.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter15.value("com.google.gson.JsonIOException: ");
        com.google.gson.JsonElement jsonElement20 = jsonTreeWriter15.get();
        com.google.gson.JsonElement jsonElement21 = jsonTreeWriter15.get();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter15.value(true);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter15.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter15.value((double) 100L);
        com.google.gson.JsonArray jsonArray27 = new com.google.gson.JsonArray();
        jsonArray27.add((java.lang.Number) 10);
        int int30 = jsonArray27.size();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor31 = jsonArray27.iterator();
        com.google.gson.Gson gson32 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter33 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass34 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter35 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson32, sqlDateTypeAdapterTypeAdapter33, sqlDateTypeAdapterClass34);
        java.lang.String str37 = gson32.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive39 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger40 = jsonPrimitive39.getAsBigInteger();
        java.lang.String str41 = gson32.toJson((java.lang.Object) bigInteger40);
        jsonArray27.add((java.lang.Number) bigInteger40);
        com.google.gson.stream.JsonWriter jsonWriter43 = jsonTreeWriter15.value((java.lang.Number) bigInteger40);
        com.google.gson.stream.JsonWriter jsonWriter44 = jsonTreeWriter0.value((java.lang.Number) bigInteger40);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter0.value(false);
        org.junit.Assert.assertNotNull(jsonWriter1);
        org.junit.Assert.assertNotNull(jsonWriter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'h' + "'", char7 == 'h');
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jsonElement12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonElement20);
        org.junit.Assert.assertNotNull(jsonElement21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(jsonElementItor31);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "100" + "'", str37, "100");
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "100" + "'", str41, "100");
        org.junit.Assert.assertNotNull(jsonWriter43);
        org.junit.Assert.assertNotNull(jsonWriter44);
        org.junit.Assert.assertNotNull(jsonWriter46);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.Object obj5 = null;
        java.lang.String str6 = gson0.toJson(obj5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("? extends ? super com.google.gson.JsonIOException<? extends ? super com.google.gson.JsonIOException>");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter9 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter10 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter10.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter10.value(true);
        java.sql.Time time14 = null;
        timeTypeAdapter9.write(jsonWriter13, time14);
        jsonWriter13.setLenient(false);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, jsonWriter13);
        com.google.gson.TypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeTypeAdapter19 = null;
        java.lang.Class<java.lang.reflect.ParameterizedType> parameterizedTypeClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType> parameterizedTypeArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.ParameterizedType>(gson0, parameterizedTypeTypeAdapter19, parameterizedTypeClass20);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter22 = parameterizedTypeArrayTypeAdapter21.nullSafe();
        java.io.Reader reader23 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = parameterizedTypeArrayTypeAdapter21.fromJson(reader23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "null" + "'", str6, "null");
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter22);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter0 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter2 = jsonTreeWriter0.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter4 = jsonTreeWriter0.value("com.google.gson.JsonIOException: ");
        com.google.gson.JsonElement jsonElement5 = jsonTreeWriter0.get();
        com.google.gson.JsonElement jsonElement6 = jsonTreeWriter0.get();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter0.value(true);
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter0.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter0.value((double) 100L);
        com.google.gson.JsonArray jsonArray12 = new com.google.gson.JsonArray();
        jsonArray12.add((java.lang.Number) 10);
        int int15 = jsonArray12.size();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor16 = jsonArray12.iterator();
        com.google.gson.Gson gson17 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter18 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass19 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter20 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson17, sqlDateTypeAdapterTypeAdapter18, sqlDateTypeAdapterClass19);
        java.lang.String str22 = gson17.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive24 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger25 = jsonPrimitive24.getAsBigInteger();
        java.lang.String str26 = gson17.toJson((java.lang.Object) bigInteger25);
        jsonArray12.add((java.lang.Number) bigInteger25);
        com.google.gson.stream.JsonWriter jsonWriter28 = jsonTreeWriter0.value((java.lang.Number) bigInteger25);
        jsonTreeWriter0.setSerializeNulls(false);
        org.junit.Assert.assertNotNull(jsonWriter2);
        org.junit.Assert.assertNotNull(jsonWriter4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertNotNull(jsonElement6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(jsonElementItor16);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "100" + "'", str22, "100");
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "100" + "'", str26, "100");
        org.junit.Assert.assertNotNull(jsonWriter28);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter20 = jsonTreeWriter19.beginArray();
        jsonTreeWriter19.flush();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter19.value("com.google.gson.JsonParseException: hi!");
        java.lang.reflect.Type type24 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement25 = gson0.toJsonTree((java.lang.Object) jsonTreeWriter19, type24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
        org.junit.Assert.assertNotNull(jsonWriter20);
        org.junit.Assert.assertNotNull(jsonWriter23);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter5 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter6 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonTreeWriter6.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter6.value(true);
        java.sql.Time time10 = null;
        timeTypeAdapter5.write(jsonWriter9, time10);
        java.sql.Time time12 = null;
        com.google.gson.JsonElement jsonElement13 = timeTypeAdapter5.toJsonTree(time12);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter14 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter15 = dateTypeAdapter14.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter16 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter16.beginArray();
        jsonTreeWriter16.flush();
        java.util.Date date19 = null;
        dateTypeAdapter14.write((com.google.gson.stream.JsonWriter) jsonTreeWriter16, date19);
        java.sql.Time time21 = null;
        timeTypeAdapter5.write((com.google.gson.stream.JsonWriter) jsonTreeWriter16, time21);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter16.value(false);
        java.lang.Object obj25 = null;
        typeAdapterFactoryArrayTypeAdapter3.write((com.google.gson.stream.JsonWriter) jsonTreeWriter16, obj25);
        com.google.gson.JsonObject jsonObject27 = new com.google.gson.JsonObject();
        boolean boolean29 = jsonObject27.has("");
        com.google.gson.JsonPrimitive jsonPrimitive31 = jsonObject27.getAsJsonPrimitive("{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader32 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject27);
        com.google.gson.stream.JsonToken jsonToken33 = jsonTreeReader32.peek();
        jsonTreeReader32.skipValue();
        jsonTreeReader32.setLenient(false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj37 = typeAdapterFactoryArrayTypeAdapter3.read((com.google.gson.stream.JsonReader) jsonTreeReader32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(jsonWriter7);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonElement13);
        org.junit.Assert.assertNotNull(dateTypeAdapter15);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(jsonPrimitive31);
        org.junit.Assert.assertTrue("'" + jsonToken33 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_OBJECT + "'", jsonToken33.equals(com.google.gson.stream.JsonToken.BEGIN_OBJECT));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        jsonArray11.add((java.lang.Number) 10);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader21 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str22 = jsonTreeReader21.nextName();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NAME but was BEGIN_ARRAY");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        java.lang.Throwable throwable4 = null;
        com.google.gson.JsonIOException jsonIOException5 = new com.google.gson.JsonIOException("", throwable4);
        java.lang.String str6 = gson2.toJson((java.lang.Object) jsonIOException5);
        com.google.gson.stream.MalformedJsonException malformedJsonException7 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonIOException5);
        com.google.gson.JsonIOException jsonIOException8 = new com.google.gson.JsonIOException("", (java.lang.Throwable) malformedJsonException7);
        com.google.gson.JsonSyntaxException jsonSyntaxException9 = new com.google.gson.JsonSyntaxException("? extends ? super com.google.gson.JsonIOException", (java.lang.Throwable) malformedJsonException7);
        com.google.gson.JsonSyntaxException jsonSyntaxException10 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) malformedJsonException7);
        com.google.gson.JsonParseException jsonParseException12 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException13 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException12);
        com.google.gson.JsonParseException jsonParseException15 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonParseException jsonParseException16 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException15);
        jsonParseException13.addSuppressed((java.lang.Throwable) jsonParseException16);
        com.google.gson.JsonSyntaxException jsonSyntaxException18 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonParseException16);
        com.google.gson.JsonSyntaxException jsonSyntaxException19 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonSyntaxException18);
        com.google.gson.JsonSyntaxException jsonSyntaxException21 = new com.google.gson.JsonSyntaxException("com.google.gson.JsonParseException: {\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
        jsonSyntaxException18.addSuppressed((java.lang.Throwable) jsonSyntaxException21);
        malformedJsonException7.addSuppressed((java.lang.Throwable) jsonSyntaxException18);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str6, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = sqlDateTypeAdapterArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = objTypeAdapter4.nullSafe();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Boolean) false);
        boolean boolean8 = jsonPrimitive7.isBoolean();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger11 = jsonPrimitive10.getAsBigInteger();
        short short12 = jsonPrimitive10.getAsShort();
        long long13 = jsonPrimitive10.getAsLong();
        byte byte14 = jsonPrimitive10.getAsByte();
        java.math.BigInteger bigInteger15 = jsonPrimitive10.getAsBigInteger();
        boolean boolean16 = jsonPrimitive7.equals((java.lang.Object) jsonPrimitive10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = objTypeAdapter5.fromJsonTree((com.google.gson.JsonElement) jsonPrimitive10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was NUMBER");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter6 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter6, typeAdapterFactoryClass7);
        com.google.gson.JsonObject jsonObject9 = new com.google.gson.JsonObject();
        boolean boolean11 = jsonObject9.has("");
        jsonObject9.addProperty("", (java.lang.Number) 100.0d);
        com.google.gson.JsonObject jsonObject16 = jsonObject9.getAsJsonObject("hi!");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter17 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter17.value("com.google.gson.JsonParseException: com.google.gson.JsonParseException: hi!");
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter17.value("com.google.gson.JsonIOException: ");
        boolean boolean22 = jsonWriter21.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonWriter21.nullValue();
        boolean boolean24 = jsonObject9.equals((java.lang.Object) jsonWriter21);
        java.lang.Object obj25 = null;
        typeAdapterFactoryArrayTypeAdapter8.write(jsonWriter21, obj25);
        java.io.Writer writer27 = null;
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter28 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter28.beginArray();
        java.lang.Number number30 = null;
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter28.value(number30);
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter28.endArray();
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter28.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter28.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter28.beginArray();
        java.lang.Number number36 = null;
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter28.value(number36);
        // The following exception was thrown during execution in test generation
        try {
            typeAdapterFactoryArrayTypeAdapter8.toJson(writer27, (java.lang.Object) jsonWriter37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(jsonObject16);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter37);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.JsonNull jsonNull4 = new com.google.gson.JsonNull();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        boolean boolean9 = jsonArray6.getAsBoolean();
        boolean boolean10 = jsonArray6.getAsBoolean();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        jsonArray11.add((java.lang.Number) 10);
        boolean boolean14 = jsonArray11.getAsBoolean();
        jsonArray11.add((java.lang.Boolean) true);
        jsonArray6.addAll(jsonArray11);
        java.lang.String str18 = gson0.toJson((java.lang.Object) jsonArray11);
        jsonArray11.add((java.lang.Number) 10);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader21 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonArray11);
        // The following exception was thrown during execution in test generation
        try {
            double double22 = jsonTreeReader21.nextDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NUMBER but was BEGIN_ARRAY");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[10,true]" + "'", str18, "[10,true]");
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter4 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter4, charSequenceClass5);
        java.lang.Object obj7 = null;
        java.lang.String str8 = gson0.toJson(obj7);
        java.io.Writer writer9 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter10 = gson0.newJsonWriter(writer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "null" + "'", str8, "null");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive("com.google.gson.JsonSyntaxException: hi!");
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter3 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass4 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter5 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson2, sqlDateTypeAdapterTypeAdapter3, sqlDateTypeAdapterClass4);
        java.lang.String str7 = gson2.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger10 = jsonPrimitive9.getAsBigInteger();
        java.lang.String str11 = gson2.toJson((java.lang.Object) bigInteger10);
        boolean boolean12 = jsonPrimitive1.equals((java.lang.Object) gson2);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "100" + "'", str7, "100");
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "100" + "'", str11, "100");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.TypeAdapter<java.lang.Cloneable> cloneableTypeAdapter7 = null;
        java.lang.Class<java.lang.Cloneable> cloneableClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable> cloneableArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Cloneable>(gson0, cloneableTypeAdapter7, cloneableClass8);
        java.lang.reflect.Type type11 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.reflect.Type type12 = gson0.fromJson("com.google.gson.JsonParseException: com.google.gson.JsonParseException: com.google.gson.JsonIOException: 100", type11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter1 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.JsonNull jsonNull2 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date3 = dateTypeAdapter1.fromJsonTree((com.google.gson.JsonElement) jsonNull2);
        boolean boolean5 = jsonNull2.equals((java.lang.Object) 1L);
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter7 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson6, sqlDateTypeAdapterTypeAdapter7, sqlDateTypeAdapterClass8);
        java.lang.String str11 = gson6.toJson((java.lang.Object) 100);
        java.lang.String str12 = gson6.toString();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.DateTypeAdapter> dateTypeAdapterTypeAdapter13 = null;
        java.lang.Class<com.google.gson.internal.bind.DateTypeAdapter> dateTypeAdapterClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.DateTypeAdapter> dateTypeAdapterArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.DateTypeAdapter>(gson6, dateTypeAdapterTypeAdapter13, dateTypeAdapterClass14);
        boolean boolean16 = jsonNull2.equals((java.lang.Object) dateTypeAdapterClass14);
        com.google.gson.JsonSyntaxException jsonSyntaxException18 = new com.google.gson.JsonSyntaxException("com.google.gson.JsonIOException: ");
        boolean boolean19 = jsonNull2.equals((java.lang.Object) "com.google.gson.JsonIOException: ");
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(jsonNull2);
        org.junit.Assert.assertNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "100" + "'", str11, "100");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive("false");
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.NUMBER_FACTORY;
        boolean boolean4 = jsonPrimitive2.equals((java.lang.Object) typeAdapterFactory3);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter5 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter5.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter5.value(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2, jsonWriter8);
        java.lang.String str12 = jsonPrimitive2.getAsString();
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "false" + "'", str12, "false");
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger8 = jsonPrimitive7.getAsBigInteger();
        java.lang.String str9 = gson0.toJson((java.lang.Object) bigInteger8);
        java.lang.String str10 = gson0.toString();
        com.google.gson.Gson gson11 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter12 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass13 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter14 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson11, sqlDateTypeAdapterTypeAdapter12, sqlDateTypeAdapterClass13);
        com.google.gson.JsonNull jsonNull15 = new com.google.gson.JsonNull();
        java.lang.String str16 = gson11.toJson((com.google.gson.JsonElement) jsonNull15);
        java.lang.String str17 = gson0.toJson((com.google.gson.JsonElement) jsonNull15);
        com.google.gson.JsonArray jsonArray18 = new com.google.gson.JsonArray();
        jsonArray18.add((java.lang.Boolean) false);
        com.google.gson.JsonArray jsonArray21 = new com.google.gson.JsonArray();
        jsonArray18.addAll(jsonArray21);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date24 = null;
        com.google.gson.JsonElement jsonElement25 = dateTypeAdapter23.toJsonTree(date24);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter26 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter26.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonWriter27.value((double) (byte) 1);
        java.util.Date date30 = null;
        dateTypeAdapter23.write(jsonWriter29, date30);
        jsonWriter29.setLenient(false);
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonWriter29.value("? extends ? super com.google.gson.JsonIOException");
        gson0.toJson((com.google.gson.JsonElement) jsonArray18, jsonWriter29);
        com.google.gson.TypeAdapter<com.google.gson.JsonSyntaxException> jsonSyntaxExceptionTypeAdapter37 = null;
        java.lang.Class<com.google.gson.JsonSyntaxException> jsonSyntaxExceptionClass38 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.JsonSyntaxException> jsonSyntaxExceptionArrayTypeAdapter39 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.JsonSyntaxException>(gson0, jsonSyntaxExceptionTypeAdapter37, jsonSyntaxExceptionClass38);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj41 = jsonSyntaxExceptionArrayTypeAdapter39.fromJson("");
            org.junit.Assert.fail("Expected exception of type java.io.EOFException; message: End of input at line 1 column 1");
        } catch (java.io.EOFException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "100" + "'", str9, "100");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "null" + "'", str17, "null");
        org.junit.Assert.assertNotNull(jsonElement25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter35);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory>(gson0, collectionTypeAdapterFactoryTypeAdapter1, collectionTypeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = collectionTypeAdapterFactoryArrayTypeAdapter3.nullSafe();
        java.io.Writer writer5 = null;
        com.google.gson.JsonParseException jsonParseException10 = new com.google.gson.JsonParseException("hi!");
        com.google.gson.JsonSyntaxException jsonSyntaxException11 = new com.google.gson.JsonSyntaxException("? extends ? super com.google.gson.JsonIOException", (java.lang.Throwable) jsonParseException10);
        com.google.gson.JsonSyntaxException jsonSyntaxException12 = new com.google.gson.JsonSyntaxException("10", (java.lang.Throwable) jsonSyntaxException11);
        com.google.gson.JsonParseException jsonParseException13 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonSyntaxException12);
        com.google.gson.stream.MalformedJsonException malformedJsonException14 = new com.google.gson.stream.MalformedJsonException("", (java.lang.Throwable) jsonParseException13);
        // The following exception was thrown during execution in test generation
        try {
            objTypeAdapter4.toJson(writer5, (java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objTypeAdapter4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray2 = jsonObject0.getAsJsonArray("com.google.gson.JsonIOException");
        com.google.gson.JsonPrimitive jsonPrimitive4 = jsonObject0.getAsJsonPrimitive("\"false\"");
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        jsonArray6.add((java.lang.Number) 10);
        int int9 = jsonArray6.size();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor10 = jsonArray6.iterator();
        com.google.gson.Gson gson11 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter12 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass13 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter14 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson11, sqlDateTypeAdapterTypeAdapter12, sqlDateTypeAdapterClass13);
        java.lang.String str16 = gson11.toJson((java.lang.Object) 100);
        com.google.gson.JsonPrimitive jsonPrimitive18 = new com.google.gson.JsonPrimitive((java.lang.Number) (byte) 100);
        java.math.BigInteger bigInteger19 = jsonPrimitive18.getAsBigInteger();
        java.lang.String str20 = gson11.toJson((java.lang.Object) bigInteger19);
        jsonArray6.add((java.lang.Number) bigInteger19);
        jsonObject0.add("com.google.gson.JsonSyntaxException: com.google.gson.JsonParseException: ? extends ? super com.google.gson.JsonIOException", (com.google.gson.JsonElement) jsonArray6);
        // The following exception was thrown during execution in test generation
        try {
            java.math.BigInteger bigInteger23 = jsonArray6.getAsBigInteger();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNull(jsonArray2);
        org.junit.Assert.assertNull(jsonPrimitive4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(jsonElementItor10);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "100" + "'", str16, "100");
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "100" + "'", str20, "100");
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter4 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter5 = dateTypeAdapter4.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter6 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonTreeWriter6.beginArray();
        jsonTreeWriter6.flush();
        java.util.Date date9 = null;
        dateTypeAdapter4.write((com.google.gson.stream.JsonWriter) jsonTreeWriter6, date9);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonTreeWriter6.value("com.google.gson.JsonSyntaxException: com.google.gson.JsonParseException: ? extends ? super com.google.gson.JsonIOException");
        boolean boolean13 = jsonTreeWriter6.isHtmlSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter14 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter15 = sqlDateTypeAdapter14.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter16 = dateTypeAdapter15.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter17 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter18 = sqlDateTypeAdapter17.nullSafe();
        com.google.gson.JsonNull jsonNull19 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date20 = dateTypeAdapter18.fromJsonTree((com.google.gson.JsonElement) jsonNull19);
        boolean boolean22 = jsonNull19.equals((java.lang.Object) 1L);
        java.sql.Date date23 = dateTypeAdapter15.fromJsonTree((com.google.gson.JsonElement) jsonNull19);
        java.sql.Date date24 = null;
        com.google.gson.JsonElement jsonElement25 = dateTypeAdapter15.toJsonTree(date24);
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter26 = dateTypeAdapter15.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter28 = jsonTreeWriter27.beginArray();
        java.lang.Number number29 = null;
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.value(number29);
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter27.endArray();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter27.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter27.nullValue();
        java.sql.Date date34 = null;
        dateTypeAdapter15.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date34);
        typeAdapterFactoryArrayTypeAdapter3.write((com.google.gson.stream.JsonWriter) jsonTreeWriter6, (java.lang.Object) date34);
        org.junit.Assert.assertNotNull(dateTypeAdapter5);
        org.junit.Assert.assertNotNull(jsonWriter7);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTypeAdapter15);
        org.junit.Assert.assertNotNull(dateTypeAdapter16);
        org.junit.Assert.assertNotNull(dateTypeAdapter18);
        org.junit.Assert.assertNotNull(jsonNull19);
        org.junit.Assert.assertNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(date23);
        org.junit.Assert.assertNotNull(jsonElement25);
        org.junit.Assert.assertNotNull(dateTypeAdapter26);
        org.junit.Assert.assertNotNull(jsonWriter28);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter33);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory>(gson0, collectionTypeAdapterFactoryTypeAdapter1, collectionTypeAdapterFactoryClass2);
        java.io.Reader reader4 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = collectionTypeAdapterFactoryArrayTypeAdapter3.fromJson(reader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.TypeAdapterFactory> typeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory> typeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.TypeAdapterFactory>(gson0, typeAdapterFactoryTypeAdapter1, typeAdapterFactoryClass2);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter4 = typeAdapterFactoryArrayTypeAdapter3.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter5 = objTypeAdapter4.nullSafe();
        org.junit.Assert.assertNotNull(objTypeAdapter4);
        org.junit.Assert.assertNotNull(objTypeAdapter5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement5 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy4);
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter6 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter7 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter7.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonTreeWriter7.value(true);
        java.sql.Time time11 = null;
        timeTypeAdapter6.write(jsonWriter10, time11);
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter13 = timeTypeAdapter6.nullSafe();
        java.sql.Time time14 = null;
        com.google.gson.JsonElement jsonElement15 = timeTypeAdapter13.toJsonTree(time14);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter16 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter17 = sqlDateTypeAdapter16.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter18 = dateTypeAdapter17.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter19 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter20 = sqlDateTypeAdapter19.nullSafe();
        com.google.gson.JsonNull jsonNull21 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date22 = dateTypeAdapter20.fromJsonTree((com.google.gson.JsonElement) jsonNull21);
        boolean boolean24 = jsonNull21.equals((java.lang.Object) 1L);
        java.sql.Date date25 = dateTypeAdapter17.fromJsonTree((com.google.gson.JsonElement) jsonNull21);
        java.lang.Class<?> wildcardClass26 = jsonNull21.getClass();
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken27 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass26);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter28 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date29 = null;
        com.google.gson.JsonElement jsonElement30 = dateTypeAdapter28.toJsonTree(date29);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter31 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter31.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonWriter32.value((double) (byte) 1);
        java.util.Date date35 = null;
        dateTypeAdapter28.write(jsonWriter34, date35);
        jsonWriter34.setLenient(false);
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonWriter34.value("? extends ? super com.google.gson.JsonIOException");
        boolean boolean41 = jsonWriter34.isLenient();
        gson0.toJson((java.lang.Object) jsonElement15, (java.lang.reflect.Type) wildcardClass26, jsonWriter34);
        com.google.gson.JsonObject jsonObject43 = new com.google.gson.JsonObject();
        boolean boolean45 = jsonObject43.has("");
        com.google.gson.JsonArray jsonArray47 = jsonObject43.getAsJsonArray("");
        jsonObject43.addProperty("null", (java.lang.Boolean) false);
        boolean boolean52 = jsonObject43.has("com.google.gson.JsonIOException: ");
        com.google.gson.JsonPrimitive jsonPrimitive54 = jsonObject43.getAsJsonPrimitive("com.google.gson.JsonIOException: ");
        java.lang.String str55 = gson0.toJson((com.google.gson.JsonElement) jsonObject43);
        com.google.gson.JsonArray jsonArray56 = new com.google.gson.JsonArray();
        jsonArray56.add("hi!");
        char char59 = jsonArray56.getAsCharacter();
        com.google.gson.JsonPrimitive jsonPrimitive62 = new com.google.gson.JsonPrimitive((java.lang.Number) (short) 100);
        boolean boolean63 = jsonPrimitive62.isBoolean();
        com.google.gson.JsonElement jsonElement64 = jsonArray56.set((int) (byte) 0, (com.google.gson.JsonElement) jsonPrimitive62);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter65 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter66 = sqlDateTypeAdapter65.nullSafe();
        java.sql.Date date67 = null;
        com.google.gson.JsonElement jsonElement68 = sqlDateTypeAdapter65.toJsonTree(date67);
        boolean boolean69 = jsonArray56.contains(jsonElement68);
        int int70 = jsonArray56.size();
        java.math.BigInteger bigInteger71 = jsonArray56.getAsBigInteger();
        java.math.BigDecimal bigDecimal72 = jsonArray56.getAsBigDecimal();
        java.lang.Appendable appendable73 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonArray56, appendable73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(timeTypeAdapter13);
        org.junit.Assert.assertNotNull(jsonElement15);
        org.junit.Assert.assertNotNull(dateTypeAdapter17);
        org.junit.Assert.assertNotNull(dateTypeAdapter18);
        org.junit.Assert.assertNotNull(dateTypeAdapter20);
        org.junit.Assert.assertNotNull(jsonNull21);
        org.junit.Assert.assertNull(date22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardTypeToken27);
        org.junit.Assert.assertNotNull(jsonElement30);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(jsonArray47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(jsonPrimitive54);
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "{\"null\":false}" + "'", str55, "{\"null\":false}");
        org.junit.Assert.assertTrue("'" + char59 + "' != '" + 'h' + "'", char59 == 'h');
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(jsonElement64);
        org.junit.Assert.assertNotNull(dateTypeAdapter66);
        org.junit.Assert.assertNotNull(jsonElement68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigDecimal72);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson0, sqlDateTypeAdapterTypeAdapter1, sqlDateTypeAdapterClass2);
        java.lang.String str5 = gson0.toJson((java.lang.Object) 100);
        java.lang.String str6 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.DateTypeAdapter> dateTypeAdapterTypeAdapter7 = null;
        java.lang.Class<com.google.gson.internal.bind.DateTypeAdapter> dateTypeAdapterClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.DateTypeAdapter> dateTypeAdapterArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.DateTypeAdapter>(gson0, dateTypeAdapterTypeAdapter7, dateTypeAdapterClass8);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str11 = dateTypeAdapterArrayTypeAdapter9.toJson((java.lang.Object) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "100" + "'", str5, "100");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        com.google.gson.stream.MalformedJsonException malformedJsonException5 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonIOException3);
        com.google.gson.JsonSyntaxException jsonSyntaxException6 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonIOException3);
        com.google.gson.JsonSyntaxException jsonSyntaxException7 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonIOException3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory>(gson0, collectionTypeAdapterFactoryTypeAdapter1, collectionTypeAdapterFactoryClass2);
        com.google.gson.Gson gson4 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterTypeAdapter5 = null;
        java.lang.Class<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterClass6 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter> sqlDateTypeAdapterArrayTypeAdapter7 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.SqlDateTypeAdapter>(gson4, sqlDateTypeAdapterTypeAdapter5, sqlDateTypeAdapterClass6);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter8 = sqlDateTypeAdapterArrayTypeAdapter7.nullSafe();
        java.lang.String str9 = gson0.toJson((java.lang.Object) sqlDateTypeAdapterArrayTypeAdapter7);
        org.junit.Assert.assertNotNull(objTypeAdapter8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "{\"componentTypeAdapter\":{}}" + "'", str9, "{\"componentTypeAdapter\":{}}");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Throwable throwable2 = null;
        com.google.gson.JsonIOException jsonIOException3 = new com.google.gson.JsonIOException("", throwable2);
        java.lang.String str4 = gson0.toJson((java.lang.Object) jsonIOException3);
        java.lang.String str5 = gson0.toString();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}" + "'", str4, "{\"detailMessage\":\"\",\"stackTrace\":[],\"suppressedExceptions\":[]}");
    }
}

