package org.jsoup.nodes;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test2501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2501");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parseBodyFragment(" #", "#declaration=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        org.jsoup.nodes.Evaluator.Tag tag4 = new org.jsoup.nodes.Evaluator.Tag("\n<body></body>");
        org.jsoup.nodes.Document document7 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str8 = document7.val();
        java.lang.String str10 = document7.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Node node13 = document7.attr("<html>\n <head></head>\n <body></body>\n</html>", "hi!");
        java.lang.String str14 = document7.className();
        org.jsoup.nodes.Element element17 = document7.attr("#document", "#root");
        org.jsoup.nodes.Document document20 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element22 = document20.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element25 = document20.attr("hi!", "");
        org.jsoup.nodes.Element element26 = element17.prependChild((org.jsoup.nodes.Node) element25);
        boolean boolean27 = tag4.matches(element17);
        document2.setParentNode((org.jsoup.nodes.Node) element17);
        java.lang.Integer int29 = document2.elementSiblingIndex();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(document7);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNotNull(element17);
        org.junit.Assert.assertNotNull(document20);
        org.junit.Assert.assertNotNull(element22);
        org.junit.Assert.assertNotNull(element25);
        org.junit.Assert.assertNotNull(element26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(int29);
    }

    @Test
    public void test2502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2502");
        org.jsoup.nodes.Evaluator.Tag tag1 = new org.jsoup.nodes.Evaluator.Tag("<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n\n<body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n hi! \n</body>");
        org.jsoup.nodes.Document document4 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element6 = document4.addClass("");
        org.jsoup.nodes.Element element8 = element6.prependElement("hi!");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str12 = document11.val();
        element6.setParentNode((org.jsoup.nodes.Node) document11);
        org.jsoup.nodes.Element element15 = document11.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element17 = element15.appendText("#declaration");
        java.util.Set<java.lang.String> strSet18 = element17.classNames();
        boolean boolean19 = tag1.matches(element17);
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(element17);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test2503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2503");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parse("hi!");
        java.lang.String str2 = document1.nodeName();
        org.jsoup.nodes.Document.OutputSettings outputSettings3 = document1.outputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings5 = outputSettings3.prettyPrint(true);
        java.nio.charset.CharsetEncoder charsetEncoder6 = outputSettings3.encoder();
        org.jsoup.nodes.Comment comment9 = new org.jsoup.nodes.Comment("#text", "");
        java.lang.StringBuilder stringBuilder10 = null;
        org.jsoup.nodes.Document document14 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element16 = document14.addClass("");
        org.jsoup.nodes.Element element18 = element16.prependElement("hi!");
        org.jsoup.nodes.Document document21 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str22 = document21.val();
        element16.setParentNode((org.jsoup.nodes.Node) document21);
        org.jsoup.nodes.Document.OutputSettings outputSettings24 = document21.new OutputSettings();
        boolean boolean25 = outputSettings24.prettyPrint();
        boolean boolean26 = outputSettings24.prettyPrint();
        comment9.outerHtmlTail(stringBuilder10, (int) (byte) 10, outputSettings24);
        java.nio.charset.Charset charset28 = outputSettings24.charset();
        org.jsoup.nodes.Document.OutputSettings outputSettings29 = outputSettings3.charset(charset28);
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "#document" + "'", str2, "#document");
        org.junit.Assert.assertNotNull(outputSettings3);
        org.junit.Assert.assertNotNull(outputSettings5);
        org.junit.Assert.assertNotNull(charsetEncoder6);
        org.junit.Assert.assertNotNull(document14);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(document21);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(charset28);
        org.junit.Assert.assertNotNull(outputSettings29);
    }

    @Test
    public void test2504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2504");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        org.jsoup.nodes.Element element13 = document9.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document14 = document9.ownerDocument();
        document14.setSiblingIndex(2);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertNotNull(document14);
    }

    @Test
    public void test2505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2505");
        org.jsoup.nodes.XmlDeclaration xmlDeclaration3 = new org.jsoup.nodes.XmlDeclaration("", "", true);
        java.lang.String str4 = xmlDeclaration3.nodeName();
        java.lang.String str5 = xmlDeclaration3.nodeName();
        java.lang.String str6 = xmlDeclaration3.nodeName();
        org.jsoup.nodes.Node node7 = xmlDeclaration3.parent();
        java.lang.StringBuilder stringBuilder8 = null;
        org.jsoup.nodes.XmlDeclaration xmlDeclaration13 = new org.jsoup.nodes.XmlDeclaration("", "", true);
        java.lang.StringBuilder stringBuilder14 = null;
        org.jsoup.nodes.Document document18 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element20 = document18.addClass("");
        org.jsoup.nodes.Element element22 = element20.prependElement("hi!");
        org.jsoup.nodes.Document document25 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str26 = document25.val();
        element20.setParentNode((org.jsoup.nodes.Node) document25);
        org.jsoup.nodes.Document.OutputSettings outputSettings28 = document25.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings30 = outputSettings28.prettyPrint(false);
        xmlDeclaration13.outerHtmlTail(stringBuilder14, (int) (short) -1, outputSettings28);
        org.jsoup.nodes.Entities.EscapeMode escapeMode32 = org.jsoup.nodes.Entities.EscapeMode.xhtml;
        org.jsoup.nodes.Document.OutputSettings outputSettings33 = outputSettings28.escapeMode(escapeMode32);
        org.jsoup.nodes.XmlDeclaration xmlDeclaration37 = new org.jsoup.nodes.XmlDeclaration("", "", true);
        java.lang.StringBuilder stringBuilder38 = null;
        org.jsoup.nodes.Document document42 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element44 = document42.addClass("");
        org.jsoup.nodes.Element element46 = element44.prependElement("hi!");
        org.jsoup.nodes.Document document49 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str50 = document49.val();
        element44.setParentNode((org.jsoup.nodes.Node) document49);
        org.jsoup.nodes.Document.OutputSettings outputSettings52 = document49.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings54 = outputSettings52.prettyPrint(false);
        xmlDeclaration37.outerHtmlTail(stringBuilder38, (int) (short) -1, outputSettings52);
        org.jsoup.nodes.Entities.EscapeMode escapeMode56 = org.jsoup.nodes.Entities.EscapeMode.xhtml;
        org.jsoup.nodes.Document.OutputSettings outputSettings57 = outputSettings52.escapeMode(escapeMode56);
        org.jsoup.nodes.Entities.EscapeMode escapeMode58 = outputSettings57.escapeMode();
        org.jsoup.nodes.Document.OutputSettings outputSettings59 = outputSettings28.escapeMode(escapeMode58);
        xmlDeclaration3.outerHtmlTail(stringBuilder8, (int) ' ', outputSettings28);
        java.lang.String str61 = xmlDeclaration3.getWholeDeclaration();
        java.lang.StringBuilder stringBuilder62 = null;
        org.jsoup.nodes.XmlDeclaration xmlDeclaration67 = new org.jsoup.nodes.XmlDeclaration("", "", true);
        java.lang.StringBuilder stringBuilder68 = null;
        org.jsoup.nodes.Document document72 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element74 = document72.addClass("");
        org.jsoup.nodes.Element element76 = element74.prependElement("hi!");
        org.jsoup.nodes.Document document79 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str80 = document79.val();
        element74.setParentNode((org.jsoup.nodes.Node) document79);
        org.jsoup.nodes.Document.OutputSettings outputSettings82 = document79.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings84 = outputSettings82.prettyPrint(false);
        xmlDeclaration67.outerHtmlTail(stringBuilder68, (int) (short) -1, outputSettings82);
        org.jsoup.nodes.Entities.EscapeMode escapeMode86 = org.jsoup.nodes.Entities.EscapeMode.xhtml;
        org.jsoup.nodes.Document.OutputSettings outputSettings87 = outputSettings82.escapeMode(escapeMode86);
        // The following exception was thrown during execution in test generation
        try {
            xmlDeclaration3.outerHtmlHead(stringBuilder62, (int) 'a', outputSettings82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "#declaration" + "'", str4, "#declaration");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "#declaration" + "'", str5, "#declaration");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "#declaration" + "'", str6, "#declaration");
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(element22);
        org.junit.Assert.assertNotNull(document25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertNotNull(outputSettings30);
        org.junit.Assert.assertTrue("'" + escapeMode32 + "' != '" + org.jsoup.nodes.Entities.EscapeMode.xhtml + "'", escapeMode32.equals(org.jsoup.nodes.Entities.EscapeMode.xhtml));
        org.junit.Assert.assertNotNull(outputSettings33);
        org.junit.Assert.assertNotNull(document42);
        org.junit.Assert.assertNotNull(element44);
        org.junit.Assert.assertNotNull(element46);
        org.junit.Assert.assertNotNull(document49);
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "" + "'", str50, "");
        org.junit.Assert.assertNotNull(outputSettings54);
        org.junit.Assert.assertTrue("'" + escapeMode56 + "' != '" + org.jsoup.nodes.Entities.EscapeMode.xhtml + "'", escapeMode56.equals(org.jsoup.nodes.Entities.EscapeMode.xhtml));
        org.junit.Assert.assertNotNull(outputSettings57);
        org.junit.Assert.assertTrue("'" + escapeMode58 + "' != '" + org.jsoup.nodes.Entities.EscapeMode.xhtml + "'", escapeMode58.equals(org.jsoup.nodes.Entities.EscapeMode.xhtml));
        org.junit.Assert.assertNotNull(outputSettings59);
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + "" + "'", str61, "");
        org.junit.Assert.assertNotNull(document72);
        org.junit.Assert.assertNotNull(element74);
        org.junit.Assert.assertNotNull(element76);
        org.junit.Assert.assertNotNull(document79);
        org.junit.Assert.assertEquals("'" + str80 + "' != '" + "" + "'", str80, "");
        org.junit.Assert.assertNotNull(outputSettings84);
        org.junit.Assert.assertTrue("'" + escapeMode86 + "' != '" + org.jsoup.nodes.Entities.EscapeMode.xhtml + "'", escapeMode86.equals(org.jsoup.nodes.Entities.EscapeMode.xhtml));
        org.junit.Assert.assertNotNull(outputSettings87);
    }

    @Test
    public void test2506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2506");
        org.jsoup.nodes.Evaluator.IndexLessThan indexLessThan1 = new org.jsoup.nodes.Evaluator.IndexLessThan((-1));
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList5 = document4.childNodes();
        org.jsoup.select.Elements elements6 = document4.getAllElements();
        org.jsoup.select.Elements elements7 = org.jsoup.select.Collector.collect((org.jsoup.nodes.Evaluator) indexLessThan1, (org.jsoup.nodes.Element) document4);
        org.jsoup.nodes.Element element9 = document4.append("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.jsoup.parser.Tag tag10 = document4.tag();
        org.jsoup.nodes.Element element11 = document4.body();
        document4.title("#data #data #data #data hi! #data #data #data hi! #data #data hi!");
        org.jsoup.nodes.Document.OutputSettings outputSettings14 = document4.new OutputSettings();
        boolean boolean15 = outputSettings14.prettyPrint();
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(nodeList5);
        org.junit.Assert.assertNotNull(elements6);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(element9);
        org.junit.Assert.assertNotNull(tag10);
        org.junit.Assert.assertNotNull(element11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test2507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2507");
        org.jsoup.nodes.Evaluator.AttributeWithValueContaining attributeWithValueContaining2 = new org.jsoup.nodes.Evaluator.AttributeWithValueContaining("#text", "hi!");
        org.jsoup.nodes.Document document5 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList6 = document5.childNodes();
        org.jsoup.select.Elements elements7 = document5.getAllElements();
        org.jsoup.nodes.Element element8 = document5.head();
        org.jsoup.nodes.Element element10 = element8.prepend("#document");
        boolean boolean11 = attributeWithValueContaining2.matches(element8);
        org.jsoup.nodes.Evaluator.Id id13 = new org.jsoup.nodes.Evaluator.Id("#document");
        org.jsoup.nodes.Evaluator.ContainsText containsText15 = new org.jsoup.nodes.Evaluator.ContainsText("hi!");
        org.jsoup.nodes.Document document18 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element20 = document18.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements22 = element20.getElementsByAttribute("hi!");
        org.jsoup.select.Elements elements24 = element20.getElementsMatchingText("<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean25 = containsText15.matches(element20);
        boolean boolean26 = id13.matches(element20);
        boolean boolean27 = attributeWithValueContaining2.matches(element20);
        org.jsoup.nodes.Document document30 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element32 = document30.addClass("");
        org.jsoup.nodes.Element element34 = element32.prependElement("hi!");
        org.jsoup.nodes.Document document37 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str38 = document37.val();
        element32.setParentNode((org.jsoup.nodes.Node) document37);
        org.jsoup.nodes.Element element41 = document37.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document42 = document37.ownerDocument();
        boolean boolean43 = attributeWithValueContaining2.matches((org.jsoup.nodes.Element) document42);
        attributeWithValueContaining2.value = " #document=\"<html>\n <head></head>\n <body></body>\n</html>\"";
        org.junit.Assert.assertNotNull(document5);
        org.junit.Assert.assertNotNull(nodeList6);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(elements22);
        org.junit.Assert.assertNotNull(elements24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(document30);
        org.junit.Assert.assertNotNull(element32);
        org.junit.Assert.assertNotNull(element34);
        org.junit.Assert.assertNotNull(document37);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
        org.junit.Assert.assertNotNull(element41);
        org.junit.Assert.assertNotNull(document42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test2508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2508");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        element4.baseUri = "<html>\n <head></head>\n <body></body>\n</html>";
        org.jsoup.select.Elements elements7 = element4.children();
        org.jsoup.select.Elements elements9 = elements7.eq(1);
        org.jsoup.select.Elements elements11 = elements9.removeAttr("<html>\n <head></head>\n <body>\n  hi!\n </body>\n</html>");
        org.jsoup.nodes.Evaluator.AttributeWithValueEnding attributeWithValueEnding14 = new org.jsoup.nodes.Evaluator.AttributeWithValueEnding("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#data");
        org.jsoup.nodes.Document document17 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str18 = document17.title();
        org.jsoup.nodes.Node node20 = document17.removeAttr("#document");
        boolean boolean21 = attributeWithValueEnding14.matches((org.jsoup.nodes.Element) document17);
        org.jsoup.nodes.Document document24 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element26 = document24.addClass("");
        org.jsoup.nodes.Element element28 = document24.val("hi!");
        java.lang.String str29 = document24.html();
        org.jsoup.nodes.Document document30 = document24.ownerDocument();
        org.jsoup.select.Elements elements33 = document24.getElementsByAttributeValueEnding("\n<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>", "#root");
        boolean boolean34 = attributeWithValueEnding14.matches((org.jsoup.nodes.Element) document24);
        org.jsoup.nodes.Document.OutputSettings outputSettings35 = document24.outputSettings();
        boolean boolean36 = elements9.add((org.jsoup.nodes.Element) document24);
        java.lang.String str37 = document24.title();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(elements9);
        org.junit.Assert.assertNotNull(elements11);
        org.junit.Assert.assertNotNull(document17);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(document24);
        org.junit.Assert.assertNotNull(element26);
        org.junit.Assert.assertNotNull(element28);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>" + "'", str29, "<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(document30);
        org.junit.Assert.assertNotNull(elements33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(outputSettings35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
    }

    @Test
    public void test2509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2509");
        org.jsoup.nodes.Evaluator.IndexGreaterThan indexGreaterThan1 = new org.jsoup.nodes.Evaluator.IndexGreaterThan((int) (byte) -1);
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList5 = document4.childNodes();
        org.jsoup.select.Elements elements6 = document4.getAllElements();
        org.jsoup.nodes.Element element7 = document4.head();
        org.jsoup.nodes.Element element9 = element7.prepend("#document");
        org.jsoup.nodes.Element element10 = element7.empty();
        boolean boolean11 = indexGreaterThan1.matches(element7);
        org.jsoup.nodes.Document document14 = org.jsoup.parser.Parser.parse("", "");
        boolean boolean16 = document14.hasAttr("hi!");
        org.jsoup.nodes.Document document19 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str20 = document19.val();
        java.lang.String str22 = document19.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements25 = document19.getElementsByAttributeValue("hi!", "hi!");
        java.lang.String str26 = elements25.text();
        org.jsoup.nodes.Document document29 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList30 = document29.childNodes();
        org.jsoup.nodes.TextNode textNode33 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        textNode33.text = "";
        org.jsoup.nodes.Element element36 = document29.prependChild((org.jsoup.nodes.Node) textNode33);
        boolean boolean37 = elements25.contains((java.lang.Object) textNode33);
        java.lang.String str38 = textNode33.text;
        boolean boolean39 = textNode33.isBlank();
        java.lang.String str40 = textNode33.toString();
        org.jsoup.nodes.Element element41 = document14.appendChild((org.jsoup.nodes.Node) textNode33);
        document14.baseUri = "<html>\n <head></head>\n <body>\n  #data\n </body>\n</html>";
        boolean boolean45 = document14.hasClass("#data");
        boolean boolean46 = indexGreaterThan1.matches((org.jsoup.nodes.Element) document14);
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(nodeList5);
        org.junit.Assert.assertNotNull(elements6);
        org.junit.Assert.assertNotNull(element7);
        org.junit.Assert.assertNotNull(element9);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(document14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(document19);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertNotNull(elements25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertNotNull(document29);
        org.junit.Assert.assertNotNull(nodeList30);
        org.junit.Assert.assertNotNull(textNode33);
        org.junit.Assert.assertNotNull(element36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "" + "'", str38, "");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "" + "'", str40, "");
        org.junit.Assert.assertNotNull(element41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test2510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2510");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        org.jsoup.nodes.Document.OutputSettings outputSettings12 = document9.new OutputSettings();
        org.jsoup.nodes.Element element14 = document9.text("\n<head class=\"hi!&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt; #document &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; data- &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>");
        java.lang.String str15 = document9.title();
        org.jsoup.nodes.Document document16 = document9.normalise();
        org.jsoup.nodes.Element element18 = document9.prependText(" text=\"hi!\" hi!=\"hi!\" data-=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\" #text=\"\"");
        org.jsoup.parser.Tag tag21 = org.jsoup.parser.Tag.valueOf("hi!");
        boolean boolean22 = tag21.preserveWhitespace();
        boolean boolean23 = tag21.isKnownTag();
        boolean boolean24 = tag21.preserveWhitespace();
        org.jsoup.nodes.Document document28 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element30 = document28.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element32 = document28.html("");
        org.jsoup.nodes.Attributes attributes33 = document28.attributes();
        java.util.Map<java.lang.String, java.lang.String> strMap34 = attributes33.dataset();
        org.jsoup.nodes.Element element35 = new org.jsoup.nodes.Element(tag21, "#declaration", attributes33);
        org.jsoup.nodes.Element element38 = element35.attr("#text", "hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.parser.Tag tag39 = element38.tag();
        org.jsoup.nodes.Node[] nodeArray40 = element38.childNodesAsArray();
        element18.addChildren(100, nodeArray40);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNotNull(document16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(tag21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(document28);
        org.junit.Assert.assertNotNull(element30);
        org.junit.Assert.assertNotNull(element32);
        org.junit.Assert.assertNotNull(attributes33);
        org.junit.Assert.assertNotNull(strMap34);
        org.junit.Assert.assertNotNull(element38);
        org.junit.Assert.assertNotNull(tag39);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertArrayEquals(nodeArray40, new org.jsoup.nodes.Node[] {});
    }

    @Test
    public void test2511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2511");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("<html>\n <head></head>\n <body></body>\n</html>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"", "<html>\n <head></head>\n <body>\n  &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;\n </body>\n</html>");
        org.junit.Assert.assertNotNull(document2);
    }

    @Test
    public void test2512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2512");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parseBodyFragment("#data", "\n<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.String str3 = document2.toString();
        org.jsoup.nodes.Element element5 = document2.removeClass("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.jsoup.nodes.Document document6 = document2.ownerDocument();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "<html>\n <head></head>\n <body>\n  #data\n </body>\n</html>" + "'", str3, "<html>\n <head></head>\n <body>\n  #data\n </body>\n</html>");
        org.junit.Assert.assertNotNull(element5);
        org.junit.Assert.assertNotNull(document6);
    }

    @Test
    public void test2513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2513");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parse("#document");
        java.util.Set<java.lang.String> strSet2 = document1.classNames();
        org.jsoup.nodes.Document.OutputSettings outputSettings3 = document1.outputSettings();
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(outputSettings3);
    }

    @Test
    public void test2514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2514");
        org.jsoup.nodes.Evaluator.AttributeWithValueEnding attributeWithValueEnding2 = new org.jsoup.nodes.Evaluator.AttributeWithValueEnding("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#data");
        org.jsoup.nodes.Evaluator.ContainsText containsText4 = new org.jsoup.nodes.Evaluator.ContainsText("hi!");
        org.jsoup.nodes.Document document7 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element9 = document7.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements11 = element9.getElementsByAttribute("hi!");
        org.jsoup.select.Elements elements13 = element9.getElementsMatchingText("<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean14 = containsText4.matches(element9);
        boolean boolean15 = element9.isBlock();
        java.util.Set<java.lang.String> strSet16 = element9.classNames();
        boolean boolean17 = attributeWithValueEnding2.matches(element9);
        org.jsoup.select.Elements elements19 = element9.getElementsByIndexLessThan(32);
        java.lang.String str20 = element9.toString();
        org.junit.Assert.assertNotNull(document7);
        org.junit.Assert.assertNotNull(element9);
        org.junit.Assert.assertNotNull(elements11);
        org.junit.Assert.assertNotNull(elements13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(elements19);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>" + "'", str20, "<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>");
    }

    @Test
    public void test2515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2515");
        org.jsoup.safety.Whitelist whitelist1 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = org.jsoup.Jsoup.clean("\n<body></body>", whitelist1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }

    @Test
    public void test2516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2516");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        boolean boolean13 = element4.hasAttr("                                                                                                 ");
        org.jsoup.nodes.Attributes attributes14 = element4.attributes();
        java.util.Spliterator<org.jsoup.nodes.Attribute> attributeSpliterator15 = attributes14.spliterator();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(attributes14);
        org.junit.Assert.assertNotNull(attributeSpliterator15);
    }

    @Test
    public void test2517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2517");
        org.jsoup.nodes.DataNode dataNode2 = org.jsoup.nodes.DataNode.createFromEncoded("", "#text");
        java.lang.String str3 = dataNode2.nodeName();
        org.jsoup.nodes.Document document6 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList7 = document6.childNodes();
        org.jsoup.select.Elements elements8 = document6.getAllElements();
        boolean boolean10 = elements8.hasClass("#document");
        org.jsoup.select.Elements elements12 = elements8.addClass("");
        boolean boolean13 = dataNode2.equals((java.lang.Object) elements12);
        org.jsoup.nodes.Evaluator.ContainsText containsText15 = new org.jsoup.nodes.Evaluator.ContainsText("hi!");
        org.jsoup.nodes.Document document18 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element20 = document18.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements22 = element20.getElementsByAttribute("hi!");
        org.jsoup.select.Elements elements24 = element20.getElementsMatchingText("<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean25 = containsText15.matches(element20);
        boolean boolean26 = element20.isBlock();
        dataNode2.setParentNode((org.jsoup.nodes.Node) element20);
        org.jsoup.select.Elements elements30 = element20.getElementsByAttributeValueStarting("#text<html>\n <head></head>\n <body></body>\n</html>", "<body></body>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        org.jsoup.nodes.Document document33 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element35 = document33.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element37 = document33.addClass("");
        org.jsoup.select.Elements elements39 = document33.getElementsContainingText("#document");
        org.jsoup.nodes.Document document42 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str43 = document42.val();
        java.lang.String str45 = document42.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements48 = document42.getElementsByAttributeValue("hi!", "hi!");
        int int49 = elements48.size();
        java.lang.String str51 = elements48.attr("hi!");
        boolean boolean52 = elements39.removeAll((java.util.Collection<org.jsoup.nodes.Element>) elements48);
        org.jsoup.select.Elements elements53 = elements39.empty();
        org.jsoup.select.Elements elements55 = elements53.removeClass("hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element56 = elements53.last();
        org.jsoup.select.Elements elements57 = elements53.empty();
        boolean boolean58 = elements30.retainAll((java.util.Collection<org.jsoup.nodes.Element>) elements53);
        org.jsoup.select.Elements elements60 = elements30.val("<html> \n <head></head> \n <body> \n </body>\n</html>\n<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Evaluator.AttributeWithValueNot attributeWithValueNot64 = new org.jsoup.nodes.Evaluator.AttributeWithValueNot("<html>\n <head></head>\n <body>\n  hi!\n </body>\n</html>", "hi! <html> <head></head> <body></body> </html>");
        org.jsoup.nodes.Document document67 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element69 = document67.addClass("");
        org.jsoup.nodes.Element element71 = document67.val("hi!");
        org.jsoup.nodes.Attributes attributes72 = element71.attributes;
        org.jsoup.nodes.Element element73 = element71.empty();
        org.jsoup.nodes.Element element75 = element73.addClass("hi!");
        org.jsoup.nodes.Element element77 = element75.append("hi!");
        org.jsoup.nodes.Document document79 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Document document82 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element84 = document82.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element86 = document82.addClass("");
        document79.setParentNode((org.jsoup.nodes.Node) document82);
        org.jsoup.nodes.Element element90 = document82.attr("hi!", "");
        org.jsoup.nodes.Element element91 = element77.prependChild((org.jsoup.nodes.Node) document82);
        org.jsoup.select.Elements elements93 = element77.getElementsContainingOwnText("#text");
        org.jsoup.select.Elements elements94 = org.jsoup.select.Collector.collect((org.jsoup.nodes.Evaluator) attributeWithValueNot64, element77);
        // The following exception was thrown during execution in test generation
        try {
            elements60.add(3, element77);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dataNode2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "#data" + "'", str3, "#data");
        org.junit.Assert.assertNotNull(document6);
        org.junit.Assert.assertNotNull(nodeList7);
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(elements22);
        org.junit.Assert.assertNotNull(elements24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(elements30);
        org.junit.Assert.assertNotNull(document33);
        org.junit.Assert.assertNotNull(element35);
        org.junit.Assert.assertNotNull(element37);
        org.junit.Assert.assertNotNull(elements39);
        org.junit.Assert.assertNotNull(document42);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "" + "'", str43, "");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "" + "'", str45, "");
        org.junit.Assert.assertNotNull(elements48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(elements53);
        org.junit.Assert.assertNotNull(elements55);
        org.junit.Assert.assertNull(element56);
        org.junit.Assert.assertNotNull(elements57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(elements60);
        org.junit.Assert.assertNotNull(document67);
        org.junit.Assert.assertNotNull(element69);
        org.junit.Assert.assertNotNull(element71);
        org.junit.Assert.assertNotNull(attributes72);
        org.junit.Assert.assertNotNull(element73);
        org.junit.Assert.assertNotNull(element75);
        org.junit.Assert.assertNotNull(element77);
        org.junit.Assert.assertNotNull(document79);
        org.junit.Assert.assertNotNull(document82);
        org.junit.Assert.assertNotNull(element84);
        org.junit.Assert.assertNotNull(element86);
        org.junit.Assert.assertNotNull(element90);
        org.junit.Assert.assertNotNull(element91);
        org.junit.Assert.assertNotNull(elements93);
        org.junit.Assert.assertNotNull(elements94);
    }

    @Test
    public void test2518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2518");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        java.lang.String str7 = document2.html();
        org.jsoup.nodes.Element element9 = document2.text("#text");
        org.jsoup.nodes.Element element11 = document2.toggleClass("<html>\n <head></head>\n <body></body>\n</html>#document");
        org.jsoup.select.Elements elements12 = element11.parents();
        java.lang.String str14 = element11.attr("\n &lt;head class=&quot;hi!&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; #document &amp;amp;lt;html&amp;amp;gt; &amp;amp;lt;head&amp;amp;gt;&amp;amp;lt;/head&amp;amp;gt; &amp;amp;lt;body&amp;amp;gt;&amp;amp;lt;/body&amp;amp;gt; &amp;amp;lt;/html&amp;amp;gt; data- &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;&quot;&gt;&lt;/head&gt;");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>" + "'", str7, "<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(element9);
        org.junit.Assert.assertNotNull(element11);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
    }

    @Test
    public void test2519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2519");
        org.jsoup.nodes.Evaluator.Class class1 = new org.jsoup.nodes.Evaluator.Class("#root");
        org.jsoup.nodes.Document document4 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element6 = document4.addClass("");
        org.jsoup.nodes.Element element8 = element6.prependElement("hi!");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str12 = document11.val();
        element6.setParentNode((org.jsoup.nodes.Node) document11);
        org.jsoup.nodes.Element element15 = document11.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document16 = document11.ownerDocument();
        org.jsoup.select.Elements elements18 = document11.getElementsByAttributeStarting("body");
        org.jsoup.nodes.Element element20 = document11.val("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        boolean boolean21 = class1.matches(element20);
        org.jsoup.nodes.Evaluator.Tag tag23 = new org.jsoup.nodes.Evaluator.Tag(" <html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document26 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element28 = document26.addClass("");
        org.jsoup.nodes.Element element30 = element28.prependElement("hi!");
        org.jsoup.nodes.Document document33 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str34 = document33.val();
        element28.setParentNode((org.jsoup.nodes.Node) document33);
        int int36 = document33.siblingIndex;
        org.jsoup.select.Elements elements38 = document33.getElementsMatchingText("hi!");
        java.lang.String str40 = document33.absUrl("<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean41 = document33.preserveWhitespace();
        org.jsoup.nodes.Element element43 = document33.appendText("hi!<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean44 = tag23.matches((org.jsoup.nodes.Element) document33);
        java.lang.String str45 = document33.nodeName();
        boolean boolean46 = class1.matches((org.jsoup.nodes.Element) document33);
        org.jsoup.nodes.Element element48 = document33.createElement("#data=\"\n&lt;hi!&gt;&lt;/hi!&gt;\n\n&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        java.util.List<org.jsoup.nodes.Node> nodeList49 = element48.childNodes;
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(document16);
        org.junit.Assert.assertNotNull(elements18);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(document26);
        org.junit.Assert.assertNotNull(element28);
        org.junit.Assert.assertNotNull(element30);
        org.junit.Assert.assertNotNull(document33);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(elements38);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "" + "'", str40, "");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(element43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "#document" + "'", str45, "#document");
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(element48);
        org.junit.Assert.assertNotNull(nodeList49);
    }

    @Test
    public void test2520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2520");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element6 = document2.html("");
        java.util.regex.Pattern pattern8 = null;
        org.jsoup.select.Elements elements9 = document2.getElementsByAttributeValueMatching("", pattern8);
        org.jsoup.select.Elements elements11 = elements9.after("");
        org.jsoup.select.Elements elements12 = new org.jsoup.select.Elements((java.util.List<org.jsoup.nodes.Element>) elements11);
        java.util.Spliterator<org.jsoup.nodes.Element> elementSpliterator13 = elements12.spliterator();
        org.jsoup.select.Elements elements15 = elements12.removeClass("                                                                                                 ");
        org.jsoup.select.Elements elements17 = elements12.append("<html>\n <head></head>\n <body>\n   &lt;head class=&quot;hi!&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; #document &amp;amp;lt;html&amp;amp;gt; &amp;amp;lt;head&amp;amp;gt;&amp;amp;lt;/head&amp;amp;gt; &amp;amp;lt;body&amp;amp;gt;&amp;amp;lt;/body&amp;amp;gt; &amp;amp;lt;/html&amp;amp;gt; data- &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;&quot;&gt;&lt;/head&gt;\n </body>\n</html>");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(elements9);
        org.junit.Assert.assertNotNull(elements11);
        org.junit.Assert.assertNotNull(elementSpliterator13);
        org.junit.Assert.assertNotNull(elements15);
        org.junit.Assert.assertNotNull(elements17);
    }

    @Test
    public void test2521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2521");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element6 = document2.addClass("");
        java.lang.String str7 = element6.id();
        org.jsoup.select.Elements elements10 = element6.getElementsByAttributeValueStarting("body", "body");
        java.lang.String str11 = element6.html();
        org.jsoup.nodes.Document document13 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Document document16 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element18 = document16.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element20 = document16.addClass("");
        document13.setParentNode((org.jsoup.nodes.Node) document16);
        org.jsoup.nodes.Element element24 = document16.attr("hi!", "");
        org.jsoup.nodes.Document document27 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element29 = document27.addClass("");
        org.jsoup.nodes.Element element31 = element29.prependElement("hi!");
        org.jsoup.nodes.Document document34 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str35 = document34.val();
        element29.setParentNode((org.jsoup.nodes.Node) document34);
        boolean boolean38 = document34.equals((java.lang.Object) 10L);
        org.jsoup.nodes.Document.OutputSettings outputSettings39 = document34.new OutputSettings();
        org.jsoup.nodes.Element element40 = element24.appendChild((org.jsoup.nodes.Node) document34);
        org.jsoup.select.Elements elements41 = document34.getAllElements();
        org.jsoup.select.Elements elements44 = document34.getElementsByAttributeValueStarting("<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>", " <html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements45 = document34.siblingElements();
        org.jsoup.nodes.Element element46 = element6.appendChild((org.jsoup.nodes.Node) document34);
        org.jsoup.nodes.Element element48 = document34.prependText("\n&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;=&quot;#data&quot;");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(elements10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>" + "'", str11, "<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>");
        org.junit.Assert.assertNotNull(document13);
        org.junit.Assert.assertNotNull(document16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(element24);
        org.junit.Assert.assertNotNull(document27);
        org.junit.Assert.assertNotNull(element29);
        org.junit.Assert.assertNotNull(element31);
        org.junit.Assert.assertNotNull(document34);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(element40);
        org.junit.Assert.assertNotNull(elements41);
        org.junit.Assert.assertNotNull(elements44);
        org.junit.Assert.assertNotNull(elements45);
        org.junit.Assert.assertNotNull(element46);
        org.junit.Assert.assertNotNull(element48);
    }

    @Test
    public void test2522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2522");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parse("hi!");
        java.lang.String str2 = document1.nodeName();
        org.jsoup.nodes.Document.OutputSettings outputSettings3 = document1.outputSettings();
        java.lang.String str4 = document1.baseUri;
        org.jsoup.nodes.Element element6 = document1.prependElement("<body></body>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;\n  hi! \n &lt;/body&gt;\n&lt;/html&gt;\"");
        org.jsoup.nodes.Document document9 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList10 = document9.childNodes();
        org.jsoup.select.Elements elements11 = document9.getAllElements();
        org.jsoup.nodes.Element element12 = document9.head();
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        org.jsoup.nodes.Element element23 = element12.classNames((java.util.Set<java.lang.String>) strSet21);
        org.jsoup.nodes.Element element25 = element12.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element26 = element12.parent();
        // The following exception was thrown during execution in test generation
        try {
            document1.removeChild((org.jsoup.nodes.Node) element26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must be true");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "#document" + "'", str2, "#document");
        org.junit.Assert.assertNotNull(outputSettings3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertNotNull(nodeList10);
        org.junit.Assert.assertNotNull(elements11);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertArrayEquals(strArray20, new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" });
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(element23);
        org.junit.Assert.assertNotNull(element25);
        org.junit.Assert.assertNotNull(element26);
    }

    @Test
    public void test2523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2523");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element6 = document2.addClass("");
        org.jsoup.select.Elements elements8 = document2.getElementsContainingText("#document");
        java.util.regex.Pattern pattern10 = null;
        org.jsoup.select.Elements elements11 = document2.getElementsByAttributeValueMatching("                                                                                                 ", pattern10);
        org.jsoup.select.Elements elements14 = document2.getElementsByAttributeValueNot("##document", "&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;");
        org.jsoup.nodes.Element element16 = document2.prependText("");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertNotNull(elements11);
        org.junit.Assert.assertNotNull(elements14);
        org.junit.Assert.assertNotNull(element16);
    }

    @Test
    public void test2524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2524");
        org.jsoup.nodes.Evaluator.AttributeWithValueEnding attributeWithValueEnding2 = new org.jsoup.nodes.Evaluator.AttributeWithValueEnding("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#data");
        java.lang.String str3 = attributeWithValueEnding2.key;
        attributeWithValueEnding2.value = "head=\"#comment\"";
        org.jsoup.nodes.Document document8 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str9 = document8.val();
        java.lang.String str11 = document8.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element12 = document8.head();
        org.jsoup.nodes.Element element14 = element12.prependElement("hi!<html>\n <head></head>\n <body></body>\n</html>");
        element14.remove();
        boolean boolean16 = attributeWithValueEnding2.matches(element14);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;" + "'", str3, "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.junit.Assert.assertNotNull(document8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test2525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2525");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("data-");
        document1.title("#declaration");
        org.jsoup.nodes.Document document5 = org.jsoup.nodes.Document.createShell("#document");
        org.jsoup.nodes.Element element7 = document5.text("hi!");
        java.lang.Integer int8 = element7.siblingIndex();
        org.jsoup.nodes.Element element9 = document1.prependChild((org.jsoup.nodes.Node) element7);
        java.util.regex.Pattern pattern10 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.select.Elements elements11 = element9.getElementsMatchingText(pattern10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertNotNull(document5);
        org.junit.Assert.assertNotNull(element7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(element9);
    }

    @Test
    public void test2526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2526");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        org.jsoup.nodes.Element element13 = document9.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean14 = document9.preserveWhitespace();
        org.jsoup.nodes.Node node15 = document9.nextSibling();
        java.lang.String str16 = document9.className();
        java.lang.String str17 = document9.tagName();
        org.jsoup.select.Elements elements19 = document9.getElementsMatchingOwnText("#data");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + " <html>\n <head></head>\n <body></body>\n</html>" + "'", str16, " <html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "#root" + "'", str17, "#root");
        org.junit.Assert.assertNotNull(elements19);
    }

    @Test
    public void test2527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2527");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("data-");
        document1.title("#declaration");
        org.jsoup.select.Elements elements5 = document1.getElementsByIndexLessThan(0);
        org.jsoup.select.Elements elements7 = elements5.removeAttr("<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n\n<body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n hi! \n</body>");
        org.jsoup.nodes.Document document10 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str11 = document10.val();
        java.lang.String str13 = document10.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Node node16 = document10.attr("<html>\n <head></head>\n <body></body>\n</html>", "hi!");
        java.lang.String str17 = document10.className();
        org.jsoup.nodes.Element element19 = document10.removeClass("");
        boolean boolean20 = elements5.contains((java.lang.Object) "");
        org.jsoup.select.Elements elements21 = elements5.parents();
        java.util.stream.Stream<org.jsoup.nodes.Element> elementStream22 = elements21.parallelStream();
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertNotNull(elements5);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(document10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(elements21);
        org.junit.Assert.assertNotNull(elementStream22);
    }

    @Test
    public void test2528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2528");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.title();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        document2.siblingIndex = (short) -1;
        org.jsoup.nodes.Document document7 = document2.normalise();
        java.util.List<org.jsoup.nodes.Node> nodeList8 = document2.childNodes();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertNotNull(document7);
        org.junit.Assert.assertNotNull(nodeList8);
    }

    @Test
    public void test2529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2529");
        org.jsoup.nodes.Evaluator.IndexEquals indexEquals1 = new org.jsoup.nodes.Evaluator.IndexEquals((int) 'a');
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList5 = document4.childNodes();
        org.jsoup.select.Elements elements6 = document4.getAllElements();
        boolean boolean7 = indexEquals1.matches((org.jsoup.nodes.Element) document4);
        org.jsoup.nodes.Element element8 = document4.head();
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(nodeList5);
        org.junit.Assert.assertNotNull(elements6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(element8);
    }

    @Test
    public void test2530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2530");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parseBodyFragmentRelaxed("#document", "<html>\n <head></head>\n <body></body>\n</html>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        java.lang.String str3 = document2.outerHtml();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "<html>\n <head></head>\n <body>\n  #document\n </body>\n</html>" + "'", str3, "<html>\n <head></head>\n <body>\n  #document\n </body>\n</html>");
    }

    @Test
    public void test2531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2531");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        org.jsoup.nodes.Element element5 = document2.head();
        org.jsoup.select.Elements elements7 = document2.getElementsByAttribute("data-");
        org.jsoup.nodes.Element element9 = document2.append("\n<head class=\"hi!&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt; #document &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; data- &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>");
        org.jsoup.nodes.Element element11 = element9.getElementById("<html>\n <head></head>\n <body></body>\n</html>=\"&lt;body&gt;&lt;/body&gt;\"");
        // The following exception was thrown during execution in test generation
        try {
            java.util.Set<java.lang.String> strSet12 = element11.classNames();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertNotNull(element5);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(element9);
        org.junit.Assert.assertNull(element11);
    }

    @Test
    public void test2532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2532");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        element4.baseUri = "<html>\n <head></head>\n <body></body>\n</html>";
        org.jsoup.select.Elements elements7 = element4.children();
        org.jsoup.select.Elements elements9 = elements7.eq(1);
        org.jsoup.select.Elements elements11 = elements9.removeAttr("<html>\n <head></head>\n <body>\n  hi!\n </body>\n</html>");
        org.jsoup.nodes.Evaluator.AttributeWithValueEnding attributeWithValueEnding14 = new org.jsoup.nodes.Evaluator.AttributeWithValueEnding("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#data");
        org.jsoup.nodes.Document document17 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str18 = document17.title();
        org.jsoup.nodes.Node node20 = document17.removeAttr("#document");
        boolean boolean21 = attributeWithValueEnding14.matches((org.jsoup.nodes.Element) document17);
        org.jsoup.nodes.Document document24 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element26 = document24.addClass("");
        org.jsoup.nodes.Element element28 = document24.val("hi!");
        java.lang.String str29 = document24.html();
        org.jsoup.nodes.Document document30 = document24.ownerDocument();
        org.jsoup.select.Elements elements33 = document24.getElementsByAttributeValueEnding("\n<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>", "#root");
        boolean boolean34 = attributeWithValueEnding14.matches((org.jsoup.nodes.Element) document24);
        org.jsoup.nodes.Document.OutputSettings outputSettings35 = document24.outputSettings();
        boolean boolean36 = elements9.add((org.jsoup.nodes.Element) document24);
        java.lang.StringBuilder stringBuilder37 = null;
        org.jsoup.nodes.Document.OutputSettings outputSettings39 = null;
        // The following exception was thrown during execution in test generation
        try {
            document24.outerHtmlHead(stringBuilder37, 0, outputSettings39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(elements9);
        org.junit.Assert.assertNotNull(elements11);
        org.junit.Assert.assertNotNull(document17);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(document24);
        org.junit.Assert.assertNotNull(element26);
        org.junit.Assert.assertNotNull(element28);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>" + "'", str29, "<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(document30);
        org.junit.Assert.assertNotNull(elements33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(outputSettings35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test2533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2533");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.nodes.Element element8 = element6.val("#data");
        org.jsoup.nodes.Element element11 = element6.attr("<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n\n<body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n hi! \n</body>", "\n<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements12 = element6.children();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element14 = element6.appendElement("                                                                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: String must not be empty");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element11);
        org.junit.Assert.assertNotNull(elements12);
    }

    @Test
    public void test2534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2534");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("#root");
        boolean boolean3 = document1.hasAttr("#text");
        java.util.Map<java.lang.String, java.lang.String> strMap4 = document1.dataset();
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strMap4);
    }

    @Test
    public void test2535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2535");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.nodes.Attributes attributes7 = element6.attributes;
        org.jsoup.nodes.Element element8 = element6.empty();
        org.jsoup.nodes.Element element10 = element8.addClass("hi!");
        org.jsoup.parser.Tag tag11 = element10.tag();
        boolean boolean12 = tag11.isEmpty();
        java.lang.String str13 = tag11.getName();
        boolean boolean14 = tag11.isEmpty();
        org.jsoup.nodes.Element element16 = new org.jsoup.nodes.Element(tag11, "#data #data #data #data hi! #data #data #data hi! #data #data hi!");
        org.jsoup.nodes.TextNode textNode19 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        org.jsoup.nodes.Node node22 = textNode19.attr("hi!", "hi!");
        textNode19.text = "";
        org.jsoup.nodes.Attributes attributes25 = textNode19.attributes();
        boolean boolean26 = tag11.equals((java.lang.Object) attributes25);
        org.jsoup.parser.TokenQueue tokenQueue28 = new org.jsoup.parser.TokenQueue("#document");
        java.lang.String str29 = tokenQueue28.consumeAttributeKey();
        boolean boolean30 = tokenQueue28.isEmpty();
        boolean boolean31 = tokenQueue28.matchesStartTag();
        boolean boolean32 = attributes25.equals((java.lang.Object) boolean31);
        attributes25.put("<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html><html>\n <head></head>\n <body></body>\n</html>", "body");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(attributes7);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(tag11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "#root" + "'", str13, "#root");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textNode19);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(attributes25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "" + "'", str29, "");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test2536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2536");
        org.jsoup.nodes.Evaluator.AttributeWithValueNot attributeWithValueNot2 = new org.jsoup.nodes.Evaluator.AttributeWithValueNot("<html>\n <head></head>\n <body>\n   &lt;head class=&quot;hi!&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; #document &amp;amp;lt;html&amp;amp;gt; &amp;amp;lt;head&amp;amp;gt;&amp;amp;lt;/head&amp;amp;gt; &amp;amp;lt;body&amp;amp;gt;&amp;amp;lt;/body&amp;amp;gt; &amp;amp;lt;/html&amp;amp;gt; data- &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;&quot;&gt;&lt;/head&gt;\n </body>\n</html>", "head");
        org.jsoup.nodes.Document document5 = org.jsoup.Jsoup.parseBodyFragment("data-", "");
        document5.setBaseUri("<html> <head></head> <body></body> </html>");
        org.jsoup.helper.Validate.notNull((java.lang.Object) document5, " text&equals;&quot;hi&excl;&quot; hi&excl;&equals;&quot;hi&excl;&quot; data-&equals;&quot;&amp;lt&semi;html&amp;gt&semi;&NewLine; &amp;lt&semi;head&amp;gt&semi;&amp;lt&semi;&sol;head&amp;gt&semi;&NewLine; &amp;lt&semi;body&amp;gt&semi;&amp;lt&semi;&sol;body&amp;gt&semi;&NewLine;&amp;lt&semi;&sol;html&amp;gt&semi;&quot;&lt;html&gt;&NewLine; &lt;head&gt;&lt;&sol;head&gt;&NewLine; &lt;body&gt;&lt;&sol;body&gt;&NewLine;&lt;&sol;html&gt;");
        boolean boolean10 = attributeWithValueNot2.matches((org.jsoup.nodes.Element) document5);
        org.junit.Assert.assertNotNull(document5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test2537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2537");
        org.jsoup.nodes.Evaluator.AttributeStarting attributeStarting1 = new org.jsoup.nodes.Evaluator.AttributeStarting("");
        org.jsoup.nodes.Document document4 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str5 = document4.val();
        java.lang.String str7 = document4.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Node node10 = document4.attr("<html>\n <head></head>\n <body></body>\n</html>", "hi!");
        java.lang.String str11 = document4.className();
        org.jsoup.nodes.Element element13 = document4.removeClass("");
        boolean boolean14 = attributeStarting1.matches((org.jsoup.nodes.Element) document4);
        java.util.regex.Pattern pattern16 = null;
        org.jsoup.nodes.Evaluator.AttributeWithValueMatching attributeWithValueMatching17 = new org.jsoup.nodes.Evaluator.AttributeWithValueMatching(" <html>\n <head></head>\n <body></body>\n</html>#document", pattern16);
        boolean boolean18 = document4.equals((java.lang.Object) attributeWithValueMatching17);
        org.jsoup.nodes.Element element20 = document4.addClass("<html>\n <head></head>\n <body>\n  <html>  \n  </html> #data  \n </body>\n</html>");
        org.jsoup.nodes.Element element23 = element20.attr("<html> <head></head> <body> hi! </body> </html>", "\n<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.String str24 = element20.nodeName();
        java.lang.String str25 = element20.nodeName();
        org.jsoup.nodes.Element element27 = element20.text("");
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(element23);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "#document" + "'", str24, "#document");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "#document" + "'", str25, "#document");
        org.junit.Assert.assertNotNull(element27);
    }

    @Test
    public void test2538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2538");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        boolean boolean6 = elements4.hasClass("#document");
        org.jsoup.nodes.Evaluator.Class class8 = new org.jsoup.nodes.Evaluator.Class("#root");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element13 = document11.addClass("");
        org.jsoup.nodes.Element element15 = element13.prependElement("hi!");
        org.jsoup.nodes.Document document18 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str19 = document18.val();
        element13.setParentNode((org.jsoup.nodes.Node) document18);
        org.jsoup.nodes.Element element22 = document18.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document23 = document18.ownerDocument();
        org.jsoup.select.Elements elements25 = document18.getElementsByAttributeStarting("body");
        org.jsoup.nodes.Element element27 = document18.val("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        boolean boolean28 = class8.matches(element27);
        org.jsoup.nodes.Evaluator.Tag tag30 = new org.jsoup.nodes.Evaluator.Tag(" <html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document33 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element35 = document33.addClass("");
        org.jsoup.nodes.Element element37 = element35.prependElement("hi!");
        org.jsoup.nodes.Document document40 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str41 = document40.val();
        element35.setParentNode((org.jsoup.nodes.Node) document40);
        int int43 = document40.siblingIndex;
        org.jsoup.select.Elements elements45 = document40.getElementsMatchingText("hi!");
        java.lang.String str47 = document40.absUrl("<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean48 = document40.preserveWhitespace();
        org.jsoup.nodes.Element element50 = document40.appendText("hi!<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean51 = tag30.matches((org.jsoup.nodes.Element) document40);
        java.lang.String str52 = document40.nodeName();
        boolean boolean53 = class8.matches((org.jsoup.nodes.Element) document40);
        org.jsoup.nodes.Document document56 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element58 = document56.addClass("");
        org.jsoup.nodes.Element element60 = document56.val("hi!");
        org.jsoup.nodes.Attributes attributes61 = element60.attributes;
        org.jsoup.nodes.Element element62 = element60.empty();
        org.jsoup.nodes.Element element64 = element62.addClass("hi!");
        org.jsoup.nodes.Element element66 = element64.append("hi!");
        org.jsoup.nodes.Document document68 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Document document71 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element73 = document71.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element75 = document71.addClass("");
        document68.setParentNode((org.jsoup.nodes.Node) document71);
        org.jsoup.nodes.Element element79 = document71.attr("hi!", "");
        org.jsoup.nodes.Element element80 = element66.prependChild((org.jsoup.nodes.Node) document71);
        org.jsoup.select.Elements elements82 = element66.getElementsContainingOwnText("#text");
        org.jsoup.nodes.Node node83 = element66.parent();
        boolean boolean84 = class8.matches(element66);
        int int85 = elements4.indexOf((java.lang.Object) boolean84);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertNotNull(element22);
        org.junit.Assert.assertNotNull(document23);
        org.junit.Assert.assertNotNull(elements25);
        org.junit.Assert.assertNotNull(element27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(document33);
        org.junit.Assert.assertNotNull(element35);
        org.junit.Assert.assertNotNull(element37);
        org.junit.Assert.assertNotNull(document40);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "" + "'", str41, "");
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(elements45);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "" + "'", str47, "");
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(element50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertEquals("'" + str52 + "' != '" + "#document" + "'", str52, "#document");
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(document56);
        org.junit.Assert.assertNotNull(element58);
        org.junit.Assert.assertNotNull(element60);
        org.junit.Assert.assertNotNull(attributes61);
        org.junit.Assert.assertNotNull(element62);
        org.junit.Assert.assertNotNull(element64);
        org.junit.Assert.assertNotNull(element66);
        org.junit.Assert.assertNotNull(document68);
        org.junit.Assert.assertNotNull(document71);
        org.junit.Assert.assertNotNull(element73);
        org.junit.Assert.assertNotNull(element75);
        org.junit.Assert.assertNotNull(element79);
        org.junit.Assert.assertNotNull(element80);
        org.junit.Assert.assertNotNull(elements82);
        org.junit.Assert.assertNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
    }

    @Test
    public void test2539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2539");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        org.jsoup.nodes.Element element5 = document2.head();
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        org.jsoup.nodes.Element element16 = element5.classNames((java.util.Set<java.lang.String>) strSet14);
        org.jsoup.nodes.Element element18 = element5.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document21 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str22 = document21.title();
        org.jsoup.select.Elements elements23 = document21.getAllElements();
        document21.siblingIndex = (short) -1;
        java.util.List<org.jsoup.nodes.Node> nodeList26 = document21.childNodes;
        element18.childNodes = nodeList26;
        boolean boolean28 = element18.isBlock();
        org.jsoup.parser.Tag tag30 = org.jsoup.parser.Tag.valueOf("hi!");
        boolean boolean31 = tag30.isBlock();
        java.lang.String str32 = tag30.getName();
        boolean boolean33 = tag30.isData();
        boolean boolean34 = tag30.isKnownTag();
        java.lang.String str35 = tag30.getName();
        org.jsoup.nodes.TextNode textNode39 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        org.jsoup.nodes.Node node42 = textNode39.attr("hi!", "hi!");
        org.jsoup.nodes.Node node45 = textNode39.attr("data-", "<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Attributes attributes46 = textNode39.attributes();
        java.util.Map<java.lang.String, java.lang.String> strMap47 = attributes46.dataset();
        org.jsoup.nodes.Element element48 = new org.jsoup.nodes.Element(tag30, "#document", attributes46);
        element18.attributes = attributes46;
        java.lang.String str50 = element18.text();
        java.lang.String str51 = element18.className();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertNotNull(element5);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertArrayEquals(strArray13, new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" });
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(document21);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertNotNull(elements23);
        org.junit.Assert.assertNotNull(nodeList26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(tag30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "hi!" + "'", str32, "hi!");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "hi!" + "'", str35, "hi!");
        org.junit.Assert.assertNotNull(textNode39);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(attributes46);
        org.junit.Assert.assertNotNull(strMap47);
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "" + "'", str50, "");
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
    }

    @Test
    public void test2540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2540");
        org.jsoup.nodes.Document document1 = new org.jsoup.nodes.Document("hi!");
        org.jsoup.nodes.Element element3 = document1.createElement("head=\"#comment\"");
        org.junit.Assert.assertNotNull(element3);
    }

    @Test
    public void test2541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2541");
        org.jsoup.nodes.Attribute attribute2 = new org.jsoup.nodes.Attribute("<html>\n <head></head>\n <body></body>\n</html>#document", " #document=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        attribute2.setKey(" <html>\n <head></head>\n <body></body>\n</html>#document");
        java.lang.String str5 = attribute2.toString();
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>#document=\" #document=&quot;&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;&quot;\"" + "'", str5, "<html>\n <head></head>\n <body></body>\n</html>#document=\" #document=&quot;&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;&quot;\"");
    }

    @Test
    public void test2542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2542");
        org.jsoup.nodes.Evaluator.ContainsOwnText containsOwnText1 = new org.jsoup.nodes.Evaluator.ContainsOwnText("");
        org.jsoup.nodes.Document document4 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element6 = document4.addClass("");
        org.jsoup.nodes.Element element8 = element6.prependElement("hi!");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str12 = document11.val();
        element6.setParentNode((org.jsoup.nodes.Node) document11);
        org.jsoup.nodes.Element element15 = document11.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document16 = document11.ownerDocument();
        org.jsoup.select.Elements elements18 = document11.getElementsByAttributeStarting("body");
        boolean boolean19 = containsOwnText1.matches((org.jsoup.nodes.Element) document11);
        org.jsoup.nodes.Document document22 = org.jsoup.parser.Parser.parseBodyFragmentRelaxed("#data", "<html>\n <head></head>\n <body>\n  <html>  \n  </html> #data  \n </body>\n</html>");
        boolean boolean23 = containsOwnText1.matches((org.jsoup.nodes.Element) document22);
        org.jsoup.select.Elements elements25 = document22.getElementsByIndexEquals(0);
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(document16);
        org.junit.Assert.assertNotNull(elements18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(document22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(elements25);
    }

    @Test
    public void test2543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2543");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.nodes.Attributes attributes7 = element6.attributes;
        org.jsoup.nodes.Element element8 = element6.empty();
        org.jsoup.nodes.Element element10 = element8.addClass("hi!");
        int int11 = element8.siblingIndex;
        org.jsoup.nodes.Element element14 = element8.attr("hi!", "hi!<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.String str15 = element8.id();
        org.jsoup.nodes.Node[] nodeArray16 = null;
        // The following exception was thrown during execution in test generation
        try {
            element8.addChildren(nodeArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(attributes7);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
    }

    @Test
    public void test2544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2544");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;\n  hi! \n &lt;/body&gt;\n&lt;/html&gt;\"", "hi!<html> <head></head> <body></body> </html>");
        org.junit.Assert.assertNotNull(document2);
    }

    @Test
    public void test2545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2545");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        java.lang.String str7 = document2.text();
        org.jsoup.nodes.Node node8 = document2.parent();
        org.jsoup.nodes.Element element10 = document2.text("#document");
        org.jsoup.nodes.Element element12 = document2.text(" text=\"hi!\" hi!=\"hi!\" data-=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        org.jsoup.select.Elements elements14 = document2.getElementsByTag("\n<body></body>");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(elements14);
    }

    @Test
    public void test2546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2546");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.val();
        java.lang.String str5 = document2.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements8 = document2.getElementsByAttributeValue("hi!", "hi!");
        org.jsoup.select.Elements elements9 = elements8.parents();
        org.jsoup.select.Elements elements10 = elements8.remove();
        org.jsoup.select.Elements elements11 = elements8.remove();
        org.jsoup.select.Elements elements12 = elements8.empty();
        int int13 = elements12.size();
        org.jsoup.select.Elements elements16 = elements12.attr("<html>\n <head></head>\n <body></body>\n</html>", "hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements18 = elements12.prepend("<html>\n <head></head>\n <body></body>\n</html>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        org.jsoup.select.Elements elements20 = elements12.removeClass("<html>\n <head></head>\n <body>\n  hi! \n </body>\n</html>");
        org.jsoup.nodes.Document document23 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element25 = document23.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element27 = document23.addClass("");
        org.jsoup.select.Elements elements29 = document23.getElementsContainingText("#document");
        org.jsoup.nodes.Document document32 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str33 = document32.val();
        java.lang.String str35 = document32.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements38 = document32.getElementsByAttributeValue("hi!", "hi!");
        int int39 = elements38.size();
        java.lang.String str41 = elements38.attr("hi!");
        boolean boolean42 = elements29.removeAll((java.util.Collection<org.jsoup.nodes.Element>) elements38);
        org.jsoup.select.Elements elements43 = elements29.empty();
        org.jsoup.select.Elements elements45 = elements43.removeClass("hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements48 = elements43.attr("hi!<html>\n <head></head>\n <body></body>\n</html>", "hi!");
        boolean boolean49 = elements20.addAll((java.util.Collection<org.jsoup.nodes.Element>) elements48);
        org.jsoup.select.Elements elements51 = elements20.removeAttr(" <html>\n <head></head>\n <body></body>\n</html>#document");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertNotNull(elements9);
        org.junit.Assert.assertNotNull(elements10);
        org.junit.Assert.assertNotNull(elements11);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(elements16);
        org.junit.Assert.assertNotNull(elements18);
        org.junit.Assert.assertNotNull(elements20);
        org.junit.Assert.assertNotNull(document23);
        org.junit.Assert.assertNotNull(element25);
        org.junit.Assert.assertNotNull(element27);
        org.junit.Assert.assertNotNull(elements29);
        org.junit.Assert.assertNotNull(document32);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertNotNull(elements38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "" + "'", str41, "");
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(elements43);
        org.junit.Assert.assertNotNull(elements45);
        org.junit.Assert.assertNotNull(elements48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(elements51);
    }

    @Test
    public void test2547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2547");
        org.jsoup.nodes.Evaluator.Id id1 = new org.jsoup.nodes.Evaluator.Id("#document");
        org.jsoup.nodes.Evaluator.AttributeWithValueEnding attributeWithValueEnding4 = new org.jsoup.nodes.Evaluator.AttributeWithValueEnding(" <html>\n <head></head>\n <body></body>\n</html>", "hi!<html> <head></head> <body></body> </html>");
        org.jsoup.nodes.Evaluator.IndexLessThan indexLessThan6 = new org.jsoup.nodes.Evaluator.IndexLessThan((int) (byte) 1);
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        boolean boolean10 = indexLessThan6.matches((org.jsoup.nodes.Element) document9);
        org.jsoup.nodes.Document document13 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element15 = document13.addClass("");
        org.jsoup.nodes.Element element17 = document13.val("hi!");
        java.lang.Integer int18 = document13.elementSiblingIndex();
        org.jsoup.select.Elements elements20 = document13.getElementsByAttribute("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements22 = document13.getElementsByIndexEquals((int) (short) -1);
        boolean boolean23 = indexLessThan6.matches((org.jsoup.nodes.Element) document13);
        boolean boolean24 = attributeWithValueEnding4.matches((org.jsoup.nodes.Element) document13);
        org.jsoup.select.Elements elements26 = document13.getElementsByIndexGreaterThan((int) '4');
        boolean boolean27 = id1.matches((org.jsoup.nodes.Element) document13);
        org.jsoup.nodes.Document document30 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element32 = document30.addClass("");
        org.jsoup.nodes.Element element34 = document30.val("hi!");
        org.jsoup.nodes.Node[] nodeArray35 = document30.childNodesAsArray();
        java.lang.String str36 = document30.id();
        org.jsoup.nodes.Document document39 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element41 = document39.addClass("");
        org.jsoup.nodes.Element element43 = element41.prependElement("hi!");
        org.jsoup.nodes.Node node44 = element41.nextSibling();
        org.jsoup.select.Elements elements45 = element41.children();
        boolean boolean46 = document30.equals((java.lang.Object) elements45);
        org.jsoup.nodes.Element element47 = document30.body();
        org.jsoup.nodes.Element element49 = element47.wrap("hi!<html> <head></head> <body></body> </html>");
        element47.setSiblingIndex(32);
        boolean boolean52 = id1.matches(element47);
        org.jsoup.select.Elements elements54 = element47.getElementsByClass(" &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt; &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; &lt;/body&gt; &lt;/html&gt;");
        boolean boolean55 = elements54.hasText();
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(document13);
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(element17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(elements20);
        org.junit.Assert.assertNotNull(elements22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(elements26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(document30);
        org.junit.Assert.assertNotNull(element32);
        org.junit.Assert.assertNotNull(element34);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
        org.junit.Assert.assertNotNull(document39);
        org.junit.Assert.assertNotNull(element41);
        org.junit.Assert.assertNotNull(element43);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNotNull(elements45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(element47);
        org.junit.Assert.assertNotNull(element49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(elements54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test2548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2548");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        org.jsoup.nodes.Element element13 = document9.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document.OutputSettings outputSettings14 = document9.new OutputSettings();
        java.lang.String str15 = document9.nodeName();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "#document" + "'", str15, "#document");
    }

    @Test
    public void test2549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2549");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element6 = document4.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element8 = document4.addClass("");
        document1.setParentNode((org.jsoup.nodes.Node) document4);
        org.jsoup.nodes.Element element12 = document4.attr("hi!", "");
        org.jsoup.nodes.Document document15 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element17 = document15.addClass("");
        org.jsoup.nodes.Element element19 = element17.prependElement("hi!");
        org.jsoup.nodes.Document document22 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str23 = document22.val();
        element17.setParentNode((org.jsoup.nodes.Node) document22);
        boolean boolean26 = document22.equals((java.lang.Object) 10L);
        org.jsoup.nodes.Document.OutputSettings outputSettings27 = document22.new OutputSettings();
        org.jsoup.nodes.Element element28 = element12.appendChild((org.jsoup.nodes.Node) document22);
        org.jsoup.select.Elements elements29 = document22.getAllElements();
        org.jsoup.select.Elements elements32 = document22.getElementsByAttributeValueStarting("<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>", " <html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element34 = document22.appendElement("<html>\n <head></head>\n <body>\n  hi! \n </body>\n</html>");
        java.lang.String str35 = document22.nodeName();
        org.jsoup.nodes.Element element37 = document22.getElementById(" text=\"\"");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element38 = element37.firstElementSibling();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(document15);
        org.junit.Assert.assertNotNull(element17);
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertNotNull(document22);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(element28);
        org.junit.Assert.assertNotNull(elements29);
        org.junit.Assert.assertNotNull(elements32);
        org.junit.Assert.assertNotNull(element34);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "#document" + "'", str35, "#document");
        org.junit.Assert.assertNull(element37);
    }

    @Test
    public void test2550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2550");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        org.jsoup.nodes.Element element13 = document9.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element15 = element13.appendText("#declaration");
        java.lang.StringBuilder stringBuilder16 = null;
        // The following exception was thrown during execution in test generation
        try {
            element13.outerHtml(stringBuilder16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertNotNull(element15);
    }

    @Test
    public void test2551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2551");
        org.jsoup.nodes.Evaluator.AttributeWithValueContaining attributeWithValueContaining2 = new org.jsoup.nodes.Evaluator.AttributeWithValueContaining("#text", "hi!");
        org.jsoup.nodes.Document document5 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList6 = document5.childNodes();
        org.jsoup.select.Elements elements7 = document5.getAllElements();
        org.jsoup.nodes.Element element8 = document5.head();
        org.jsoup.nodes.Element element10 = element8.prepend("#document");
        boolean boolean11 = attributeWithValueContaining2.matches(element8);
        attributeWithValueContaining2.key = "a";
        org.jsoup.nodes.Document document16 = org.jsoup.parser.Parser.parse("", "");
        boolean boolean18 = document16.hasAttr("hi!");
        org.jsoup.nodes.Document document21 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str22 = document21.val();
        java.lang.String str24 = document21.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements27 = document21.getElementsByAttributeValue("hi!", "hi!");
        java.lang.String str28 = elements27.text();
        org.jsoup.nodes.Document document31 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList32 = document31.childNodes();
        org.jsoup.nodes.TextNode textNode35 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        textNode35.text = "";
        org.jsoup.nodes.Element element38 = document31.prependChild((org.jsoup.nodes.Node) textNode35);
        boolean boolean39 = elements27.contains((java.lang.Object) textNode35);
        java.lang.String str40 = textNode35.text;
        boolean boolean41 = textNode35.isBlank();
        java.lang.String str42 = textNode35.toString();
        org.jsoup.nodes.Element element43 = document16.appendChild((org.jsoup.nodes.Node) textNode35);
        document16.baseUri = "<html>\n <head></head>\n <body>\n  #data\n </body>\n</html>";
        org.jsoup.nodes.Element element47 = document16.createElement("#");
        boolean boolean48 = attributeWithValueContaining2.matches(element47);
        org.junit.Assert.assertNotNull(document5);
        org.junit.Assert.assertNotNull(nodeList6);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(document16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(document21);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertNotNull(elements27);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertNotNull(document31);
        org.junit.Assert.assertNotNull(nodeList32);
        org.junit.Assert.assertNotNull(textNode35);
        org.junit.Assert.assertNotNull(element38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "" + "'", str40, "");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "" + "'", str42, "");
        org.junit.Assert.assertNotNull(element43);
        org.junit.Assert.assertNotNull(element47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test2552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2552");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.val();
        java.lang.String str5 = document2.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements8 = document2.getElementsByAttributeValue("hi!", "hi!");
        org.jsoup.select.Elements elements9 = new org.jsoup.select.Elements((java.util.List<org.jsoup.nodes.Element>) elements8);
        org.jsoup.select.Elements elements10 = elements9.parents();
        org.jsoup.select.Elements elements12 = elements10.addClass("&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;");
        org.jsoup.select.Elements elements14 = elements12.toggleClass(" #document=\"<html>\n <head></head>\n <body></body>\n</html>\"");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertNotNull(elements10);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertNotNull(elements14);
    }

    @Test
    public void test2553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2553");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.val();
        java.lang.String str5 = document2.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements8 = document2.getElementsByAttributeValue("hi!", "hi!");
        java.lang.String str9 = elements8.text();
        org.jsoup.nodes.Document document12 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList13 = document12.childNodes();
        org.jsoup.nodes.TextNode textNode16 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        textNode16.text = "";
        org.jsoup.nodes.Element element19 = document12.prependChild((org.jsoup.nodes.Node) textNode16);
        boolean boolean20 = elements8.contains((java.lang.Object) textNode16);
        java.lang.String str21 = textNode16.text;
        boolean boolean22 = textNode16.isBlank();
        org.jsoup.nodes.TextNode textNode24 = textNode16.text("#text");
        java.lang.String str25 = textNode24.baseUri();
        boolean boolean27 = textNode24.hasAttr("hi");
        org.jsoup.nodes.Node node28 = textNode24.parent();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertNotNull(document12);
        org.junit.Assert.assertNotNull(nodeList13);
        org.junit.Assert.assertNotNull(textNode16);
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(textNode24);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "hi!" + "'", str25, "hi!");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test2554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2554");
        org.jsoup.nodes.Evaluator.Id id1 = new org.jsoup.nodes.Evaluator.Id("#document");
        org.jsoup.nodes.Document document3 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Document document6 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element8 = document6.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element10 = document6.addClass("");
        document3.setParentNode((org.jsoup.nodes.Node) document6);
        org.jsoup.nodes.Element element14 = document6.attr("hi!", "");
        boolean boolean15 = id1.matches((org.jsoup.nodes.Element) document6);
        org.jsoup.nodes.Element element17 = document6.appendText("");
        org.jsoup.nodes.Element element19 = document6.createElement("#root");
        org.jsoup.nodes.Attributes attributes20 = element19.attributes();
        org.junit.Assert.assertNotNull(document3);
        org.junit.Assert.assertNotNull(document6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(element17);
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertNotNull(attributes20);
    }

    @Test
    public void test2555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2555");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        org.jsoup.nodes.Element element5 = document2.head();
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        org.jsoup.nodes.Element element16 = element5.classNames((java.util.Set<java.lang.String>) strSet14);
        org.jsoup.nodes.Element element18 = element5.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element21 = element5.attr("#text", "hi!");
        org.jsoup.select.Elements elements23 = element5.getElementsByAttributeStarting("hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Node node24 = element5.nextSibling();
        boolean boolean26 = element5.hasClass("\n<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertNotNull(element5);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertArrayEquals(strArray13, new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" });
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(element21);
        org.junit.Assert.assertNotNull(elements23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test2556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2556");
        org.jsoup.nodes.Evaluator.Tag tag1 = new org.jsoup.nodes.Evaluator.Tag("<#root class=\"\" hi!=\"\">\n <html>\n  <head></head>\n  <body>\n   &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n  </body>\n </html>\n</#root>hi!");
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList5 = document4.childNodes();
        org.jsoup.select.Elements elements6 = document4.getAllElements();
        org.jsoup.nodes.Element element7 = document4.head();
        org.jsoup.nodes.Element element9 = element7.prepend("#document");
        org.jsoup.select.Elements elements12 = element9.getElementsByAttributeValueMatching("<html>\n <head></head>\n <body>\n  <html>  \n  </html> #data  \n </body>\n</html>", "<html>\n <head></head>\n <body></body>\n</html>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        org.jsoup.nodes.Document document15 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str16 = document15.val();
        java.lang.String str18 = document15.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements21 = document15.getElementsByAttributeValue("hi!", "hi!");
        org.jsoup.select.Elements elements22 = elements21.parents();
        org.jsoup.nodes.Document document25 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str26 = document25.val();
        java.lang.String str28 = document25.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements31 = document25.getElementsByAttributeValue("hi!", "hi!");
        int int32 = elements31.size();
        java.lang.String str34 = elements31.attr("hi!");
        boolean boolean35 = elements21.retainAll((java.util.Collection<org.jsoup.nodes.Element>) elements31);
        java.lang.String str36 = elements21.outerHtml();
        boolean boolean37 = element9.equals((java.lang.Object) elements21);
        org.jsoup.nodes.Element element38 = element9.empty();
        org.jsoup.nodes.Element element40 = element9.appendText("<html>\n <head></head>\n <body>\n   &lt;head class=&quot;hi!&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; #document &amp;amp;lt;html&amp;amp;gt; &amp;amp;lt;head&amp;amp;gt;&amp;amp;lt;/head&amp;amp;gt; &amp;amp;lt;body&amp;amp;gt;&amp;amp;lt;/body&amp;amp;gt; &amp;amp;lt;/html&amp;amp;gt; data- &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;&quot;&gt;&lt;/head&gt;\n </body>\n</html>");
        boolean boolean41 = tag1.matches(element40);
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(nodeList5);
        org.junit.Assert.assertNotNull(elements6);
        org.junit.Assert.assertNotNull(element7);
        org.junit.Assert.assertNotNull(element9);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertNotNull(document15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNotNull(elements21);
        org.junit.Assert.assertNotNull(elements22);
        org.junit.Assert.assertNotNull(document25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertNotNull(elements31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "" + "'", str36, "");
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(element38);
        org.junit.Assert.assertNotNull(element40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test2557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2557");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        int int12 = document9.siblingIndex;
        org.jsoup.select.Elements elements14 = document9.getElementsMatchingText("hi!");
        java.lang.String str16 = document9.absUrl("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element17 = document9.head();
        element17.remove();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(elements14);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertNotNull(element17);
    }

    @Test
    public void test2558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2558");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt; #text &lt;/body&gt; &lt;/html&gt;", "<body></body>");
        org.junit.Assert.assertNotNull(document2);
    }

    @Test
    public void test2559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2559");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.val();
        java.lang.String str5 = document2.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements8 = document2.getElementsByAttributeValue("hi!", "hi!");
        org.jsoup.select.Elements elements10 = elements8.after("#text");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element12 = elements8.get((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index -1 out of bounds for length 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertNotNull(elements10);
    }

    @Test
    public void test2560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2560");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        org.jsoup.nodes.Element element5 = document2.head();
        org.jsoup.nodes.Element element7 = element5.prepend("#document");
        org.jsoup.select.Elements elements10 = element7.getElementsByAttributeValueMatching("<html>\n <head></head>\n <body>\n  <html>  \n  </html> #data  \n </body>\n</html>", "<html>\n <head></head>\n <body></body>\n</html>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        org.jsoup.nodes.Document document13 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str14 = document13.val();
        java.lang.String str16 = document13.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements19 = document13.getElementsByAttributeValue("hi!", "hi!");
        org.jsoup.select.Elements elements20 = elements19.parents();
        org.jsoup.nodes.Document document23 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str24 = document23.val();
        java.lang.String str26 = document23.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements29 = document23.getElementsByAttributeValue("hi!", "hi!");
        int int30 = elements29.size();
        java.lang.String str32 = elements29.attr("hi!");
        boolean boolean33 = elements19.retainAll((java.util.Collection<org.jsoup.nodes.Element>) elements29);
        java.lang.String str34 = elements19.outerHtml();
        boolean boolean35 = element7.equals((java.lang.Object) elements19);
        org.jsoup.nodes.Document document38 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList39 = document38.childNodes();
        org.jsoup.select.Elements elements40 = document38.getAllElements();
        org.jsoup.nodes.Element element41 = document38.head();
        java.lang.String[] strArray49 = new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" };
        java.util.LinkedHashSet<java.lang.String> strSet50 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet50, strArray49);
        org.jsoup.nodes.Element element52 = element41.classNames((java.util.Set<java.lang.String>) strSet50);
        org.jsoup.nodes.Element element54 = element41.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.String str55 = element41.toString();
        org.jsoup.nodes.Element element57 = element41.prepend("hi!");
        org.jsoup.nodes.Element element59 = element41.removeClass("body");
        org.jsoup.select.Elements elements62 = element59.getElementsByAttributeValueMatching("hi!<html>\n <head></head>\n <body></body>\n</html>", "<html>\n <head></head>\n <body>\n  hi! \n </body>\n</html>");
        org.jsoup.nodes.Element element63 = element7.prependChild((org.jsoup.nodes.Node) element59);
        org.jsoup.nodes.Element element65 = element7.prependElement(" <html> <head></head> <body></body> </html>");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertNotNull(element5);
        org.junit.Assert.assertNotNull(element7);
        org.junit.Assert.assertNotNull(elements10);
        org.junit.Assert.assertNotNull(document13);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "" + "'", str16, "");
        org.junit.Assert.assertNotNull(elements19);
        org.junit.Assert.assertNotNull(elements20);
        org.junit.Assert.assertNotNull(document23);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "" + "'", str24, "");
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertNotNull(elements29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "" + "'", str34, "");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(document38);
        org.junit.Assert.assertNotNull(nodeList39);
        org.junit.Assert.assertNotNull(elements40);
        org.junit.Assert.assertNotNull(element41);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertArrayEquals(strArray49, new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" });
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(element52);
        org.junit.Assert.assertNotNull(element54);
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "\n<head class=\"hi!&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt; #document &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; data- &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>" + "'", str55, "\n<head class=\"hi!&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt; #document &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; data- &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>");
        org.junit.Assert.assertNotNull(element57);
        org.junit.Assert.assertNotNull(element59);
        org.junit.Assert.assertNotNull(elements62);
        org.junit.Assert.assertNotNull(element63);
        org.junit.Assert.assertNotNull(element65);
    }

    @Test
    public void test2561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2561");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        int int12 = document9.siblingIndex;
        org.jsoup.select.Elements elements14 = document9.getElementsMatchingText("hi!");
        org.jsoup.select.Elements elements17 = document9.getElementsByAttributeValueEnding("hi!<html> <head></head> <body></body> </html>", "<html>\n <head></head>\n <body>\n  <html>  \n  </html> #data  \n </body>\n</html>");
        boolean boolean19 = elements17.hasAttr("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(elements14);
        org.junit.Assert.assertNotNull(elements17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test2562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2562");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        java.lang.String str7 = element6.ownText();
        org.jsoup.select.Elements elements9 = element6.getElementsByIndexLessThan(0);
        org.jsoup.parser.Tag tag10 = element6.tag();
        org.jsoup.nodes.Element element12 = new org.jsoup.nodes.Element(tag10, "<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n\n<body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n hi! \n</body>");
        boolean boolean13 = tag10.preserveWhitespace();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(elements9);
        org.junit.Assert.assertNotNull(tag10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test2563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2563");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("<html>\n <head></head>\n <body>\n  <html>  \n  </html> \n </body>\n</html>", "");
        java.util.Set<java.lang.String> strSet3 = document2.classNames();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test2564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2564");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        boolean boolean13 = element4.hasAttr("                                                                                                 ");
        org.jsoup.nodes.Attributes attributes14 = element4.attributes();
        element4.baseUri = " <html>\n <head></head>\n <body></body>\n</html>=\"#data\"";
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(attributes14);
    }

    @Test
    public void test2565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2565");
        org.jsoup.nodes.TextNode textNode2 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        org.jsoup.nodes.Node node5 = textNode2.attr("hi!", "hi!");
        textNode2.text = "";
        org.jsoup.nodes.Node node10 = textNode2.attr("hi!<html>\n <head></head>\n <body></body>\n</html>", "");
        java.lang.String str11 = textNode2.nodeName();
        boolean boolean13 = textNode2.hasAttr("&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;");
        java.lang.StringBuilder stringBuilder14 = null;
        org.jsoup.nodes.Document document18 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList19 = document18.childNodes();
        org.jsoup.nodes.Document.OutputSettings outputSettings20 = document18.outputSettings();
        textNode2.outerHtmlTail(stringBuilder14, (int) ' ', outputSettings20);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str23 = textNode2.absUrl("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: String must not be empty");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(textNode2);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "#text" + "'", str11, "#text");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertNotNull(nodeList19);
        org.junit.Assert.assertNotNull(outputSettings20);
    }

    @Test
    public void test2566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2566");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        org.jsoup.nodes.Element element5 = document2.head();
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        org.jsoup.nodes.Element element16 = element5.classNames((java.util.Set<java.lang.String>) strSet14);
        org.jsoup.nodes.Element element18 = element5.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document21 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str22 = document21.title();
        org.jsoup.select.Elements elements23 = document21.getAllElements();
        document21.siblingIndex = (short) -1;
        java.util.List<org.jsoup.nodes.Node> nodeList26 = document21.childNodes;
        element18.childNodes = nodeList26;
        org.jsoup.nodes.Element element29 = element18.val("#root");
        org.jsoup.select.Elements elements30 = element29.children();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertNotNull(element5);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertArrayEquals(strArray13, new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" });
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(document21);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "" + "'", str22, "");
        org.junit.Assert.assertNotNull(elements23);
        org.junit.Assert.assertNotNull(nodeList26);
        org.junit.Assert.assertNotNull(element29);
        org.junit.Assert.assertNotNull(elements30);
    }

    @Test
    public void test2567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2567");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        int int12 = document9.siblingIndex;
        org.jsoup.select.Elements elements15 = document9.getElementsByAttributeValueMatching("\n<body></body>", "&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;");
        org.jsoup.nodes.Document document18 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element20 = document18.addClass("");
        org.jsoup.nodes.Element element22 = element20.prependElement("hi!");
        org.jsoup.nodes.Document document25 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str26 = document25.val();
        element20.setParentNode((org.jsoup.nodes.Node) document25);
        org.jsoup.nodes.Element element29 = document25.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document30 = document25.ownerDocument();
        org.jsoup.select.Elements elements32 = document25.getElementsByAttributeStarting("body");
        org.jsoup.nodes.Element element34 = document25.val("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        java.util.List<org.jsoup.nodes.Node> nodeList35 = element34.childNodes();
        org.jsoup.nodes.Document document38 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str39 = document38.title();
        org.jsoup.nodes.Node node41 = document38.removeAttr("#document");
        org.jsoup.nodes.Element element42 = document38.body();
        boolean boolean43 = element42.preserveWhitespace();
        java.lang.String str44 = element42.html();
        java.util.List<org.jsoup.nodes.Node> nodeList45 = element42.siblingNodes();
        org.jsoup.nodes.Element element47 = element42.appendElement("body");
        boolean boolean48 = element42.isBlock();
        org.jsoup.nodes.Element element50 = element42.prependElement("<html>\n <head></head>\n <body>\n  hi! \n </body>\n</html>");
        // The following exception was thrown during execution in test generation
        try {
            document9.replaceChild((org.jsoup.nodes.Node) element34, (org.jsoup.nodes.Node) element42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must be true");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(elements15);
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(element22);
        org.junit.Assert.assertNotNull(document25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertNotNull(element29);
        org.junit.Assert.assertNotNull(document30);
        org.junit.Assert.assertNotNull(elements32);
        org.junit.Assert.assertNotNull(element34);
        org.junit.Assert.assertNotNull(nodeList35);
        org.junit.Assert.assertNotNull(document38);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "" + "'", str39, "");
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(element42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
        org.junit.Assert.assertNotNull(nodeList45);
        org.junit.Assert.assertNotNull(element47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(element50);
    }

    @Test
    public void test2568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2568");
        org.jsoup.nodes.DataNode dataNode2 = org.jsoup.nodes.DataNode.createFromEncoded("", "#text");
        java.lang.String str3 = dataNode2.nodeName();
        org.jsoup.nodes.Document document6 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList7 = document6.childNodes();
        org.jsoup.select.Elements elements8 = document6.getAllElements();
        boolean boolean10 = elements8.hasClass("#document");
        org.jsoup.select.Elements elements12 = elements8.addClass("");
        boolean boolean13 = dataNode2.equals((java.lang.Object) elements12);
        org.jsoup.nodes.Evaluator.ContainsText containsText15 = new org.jsoup.nodes.Evaluator.ContainsText("hi!");
        org.jsoup.nodes.Document document18 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element20 = document18.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements22 = element20.getElementsByAttribute("hi!");
        org.jsoup.select.Elements elements24 = element20.getElementsMatchingText("<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean25 = containsText15.matches(element20);
        boolean boolean26 = element20.isBlock();
        dataNode2.setParentNode((org.jsoup.nodes.Node) element20);
        java.util.List<org.jsoup.nodes.Node> nodeList28 = dataNode2.siblingNodes();
        org.jsoup.nodes.Attributes attributes29 = null;
        dataNode2.attributes = attributes29;
        java.lang.StringBuilder stringBuilder31 = null;
        org.jsoup.nodes.Document.OutputSettings outputSettings33 = null;
        dataNode2.outerHtmlTail(stringBuilder31, (int) (byte) 0, outputSettings33);
        org.junit.Assert.assertNotNull(dataNode2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "#data" + "'", str3, "#data");
        org.junit.Assert.assertNotNull(document6);
        org.junit.Assert.assertNotNull(nodeList7);
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(elements22);
        org.junit.Assert.assertNotNull(elements24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeList28);
    }

    @Test
    public void test2569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2569");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("<html>\n <head></head>\n <body>\n  #data\n </body>\n</html>", "#text");
        org.jsoup.select.Elements elements4 = document2.getElementsByIndexEquals(10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str6 = document2.absUrl("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: String must not be empty");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(elements4);
    }

    @Test
    public void test2570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2570");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        org.jsoup.nodes.Element element5 = document2.head();
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        org.jsoup.nodes.Element element16 = element5.classNames((java.util.Set<java.lang.String>) strSet14);
        org.jsoup.nodes.Element element18 = element5.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.String str19 = element5.toString();
        org.jsoup.nodes.Element element21 = element5.prepend("hi!");
        org.jsoup.nodes.Element element23 = element5.removeClass("body");
        org.jsoup.nodes.Element element25 = element23.text("\n<head class=\"hi!&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt; #document &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; data- &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>");
        org.jsoup.nodes.Element element27 = element23.addClass(" #document=\"<body></body>\"");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertNotNull(element5);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertArrayEquals(strArray13, new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" });
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "\n<head class=\"hi!&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt; #document &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; data- &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>" + "'", str19, "\n<head class=\"hi!&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt; #document &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; data- &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>");
        org.junit.Assert.assertNotNull(element21);
        org.junit.Assert.assertNotNull(element23);
        org.junit.Assert.assertNotNull(element25);
        org.junit.Assert.assertNotNull(element27);
    }

    @Test
    public void test2571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2571");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element6 = document2.html("");
        boolean boolean7 = document2.preserveWhitespace();
        boolean boolean8 = document2.hasText();
        org.jsoup.nodes.Element element9 = document2.head();
        java.lang.String str10 = document2.toString();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(element9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
    }

    @Test
    public void test2572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2572");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parse("hi!");
        java.lang.String str2 = document1.nodeName();
        org.jsoup.nodes.Document.OutputSettings outputSettings3 = document1.outputSettings();
        org.jsoup.nodes.Attributes attributes4 = document1.attributes();
        java.lang.String str6 = document1.attr("<html>\n <head></head>\n <body>\n  <html>  \n  </html> &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;  \n </body>\n</html>");
        org.jsoup.nodes.Node node7 = null;
        // The following exception was thrown during execution in test generation
        try {
            document1.replaceWith(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "#document" + "'", str2, "#document");
        org.junit.Assert.assertNotNull(outputSettings3);
        org.junit.Assert.assertNotNull(attributes4);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
    }

    @Test
    public void test2573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2573");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element6 = document4.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element8 = document4.addClass("");
        document1.setParentNode((org.jsoup.nodes.Node) document4);
        org.jsoup.nodes.Element element12 = document4.attr("hi!", "");
        org.jsoup.nodes.Element element14 = element12.appendText("<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>");
        org.jsoup.select.Elements elements15 = element12.parents();
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertNotNull(elements15);
    }

    @Test
    public void test2574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2574");
        org.jsoup.nodes.Evaluator.AttributeWithValueStarting attributeWithValueStarting2 = new org.jsoup.nodes.Evaluator.AttributeWithValueStarting("&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;", "<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document5 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList6 = document5.childNodes();
        org.jsoup.select.Elements elements7 = document5.getAllElements();
        org.jsoup.nodes.Element element8 = document5.head();
        org.jsoup.nodes.Node node9 = document5.parent();
        org.jsoup.nodes.Element element11 = document5.toggleClass("#root");
        org.jsoup.select.Elements elements12 = element11.parents();
        org.jsoup.nodes.Node node13 = null;
        element11.setParentNode(node13);
        boolean boolean15 = attributeWithValueStarting2.matches(element11);
        org.jsoup.nodes.Document document19 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element21 = document19.addClass("");
        org.jsoup.nodes.Element element23 = document19.val("hi!");
        org.jsoup.nodes.Node[] nodeArray24 = document19.childNodesAsArray();
        // The following exception was thrown during execution in test generation
        try {
            element11.addChildren(100, nodeArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document5);
        org.junit.Assert.assertNotNull(nodeList6);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNotNull(element11);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(document19);
        org.junit.Assert.assertNotNull(element21);
        org.junit.Assert.assertNotNull(element23);
        org.junit.Assert.assertNotNull(nodeArray24);
    }

    @Test
    public void test2575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2575");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Node node6 = document2.removeAttr("#text");
        org.jsoup.nodes.Document.OutputSettings outputSettings7 = document2.outputSettings();
        boolean boolean9 = document2.hasClass("#data #data #data #data hi! #data #data #data hi! #data #data hi!");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(outputSettings7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test2576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2576");
        org.jsoup.nodes.Evaluator.AttributeStarting attributeStarting1 = new org.jsoup.nodes.Evaluator.AttributeStarting("\n<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document3 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Document document6 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element8 = document6.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element10 = document6.addClass("");
        document3.setParentNode((org.jsoup.nodes.Node) document6);
        org.jsoup.nodes.Element element14 = document6.attr("hi!", "");
        org.jsoup.nodes.Document document17 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element19 = document17.addClass("");
        org.jsoup.nodes.Element element21 = element19.prependElement("hi!");
        org.jsoup.nodes.Document document24 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str25 = document24.val();
        element19.setParentNode((org.jsoup.nodes.Node) document24);
        boolean boolean28 = document24.equals((java.lang.Object) 10L);
        org.jsoup.nodes.Document.OutputSettings outputSettings29 = document24.new OutputSettings();
        org.jsoup.nodes.Element element30 = element14.appendChild((org.jsoup.nodes.Node) document24);
        org.jsoup.select.Elements elements31 = document24.getAllElements();
        org.jsoup.select.Elements elements34 = document24.getElementsByAttributeValueStarting("<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>", " <html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements35 = document24.siblingElements();
        boolean boolean36 = attributeStarting1.matches((org.jsoup.nodes.Element) document24);
        org.jsoup.nodes.Element element38 = document24.after("\n<html>\n <head class=\"hi!&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;  #document &amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt; data-\"></head>\n <body>\n  hi! \n </body>\n <html>  \n </html> \n <html>  #data  \n </html>&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n</html>");
        org.junit.Assert.assertNotNull(document3);
        org.junit.Assert.assertNotNull(document6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertNotNull(document17);
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertNotNull(element21);
        org.junit.Assert.assertNotNull(document24);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(element30);
        org.junit.Assert.assertNotNull(elements31);
        org.junit.Assert.assertNotNull(elements34);
        org.junit.Assert.assertNotNull(elements35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(element38);
    }

    @Test
    public void test2577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2577");
        org.jsoup.nodes.Attributes attributes0 = new org.jsoup.nodes.Attributes();
        java.util.Iterator<org.jsoup.nodes.Attribute> attributeItor1 = attributes0.iterator();
        java.lang.StringBuilder stringBuilder2 = null;
        org.jsoup.nodes.Document document6 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element8 = document6.addClass("");
        org.jsoup.nodes.Element element10 = element8.prependElement("hi!");
        org.jsoup.nodes.Document document13 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str14 = document13.val();
        element8.setParentNode((org.jsoup.nodes.Node) document13);
        org.jsoup.nodes.Document.OutputSettings outputSettings16 = document13.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings18 = outputSettings16.prettyPrint(false);
        org.jsoup.nodes.Document.OutputSettings outputSettings20 = outputSettings16.indentAmount((int) (short) 10);
        java.lang.String str21 = org.jsoup.nodes.Entities.escape("<html>\n <head></head>\n <body></body>\n</html>", outputSettings20);
        attributes0.html(stringBuilder2, outputSettings20);
        org.jsoup.nodes.Document document25 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str26 = document25.val();
        java.lang.String str28 = document25.attr("<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.String str30 = document25.attr("#document");
        boolean boolean31 = attributes0.equals((java.lang.Object) document25);
        java.lang.StringBuilder stringBuilder32 = null;
        org.jsoup.nodes.Attributes attributes33 = new org.jsoup.nodes.Attributes();
        java.util.Iterator<org.jsoup.nodes.Attribute> attributeItor34 = attributes33.iterator();
        java.lang.StringBuilder stringBuilder35 = null;
        org.jsoup.nodes.Document document39 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element41 = document39.addClass("");
        org.jsoup.nodes.Element element43 = element41.prependElement("hi!");
        org.jsoup.nodes.Document document46 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str47 = document46.val();
        element41.setParentNode((org.jsoup.nodes.Node) document46);
        org.jsoup.nodes.Document.OutputSettings outputSettings49 = document46.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings51 = outputSettings49.prettyPrint(false);
        org.jsoup.nodes.Document.OutputSettings outputSettings53 = outputSettings49.indentAmount((int) (short) 10);
        java.lang.String str54 = org.jsoup.nodes.Entities.escape("<html>\n <head></head>\n <body></body>\n</html>", outputSettings53);
        attributes33.html(stringBuilder35, outputSettings53);
        attributes0.html(stringBuilder32, outputSettings53);
        java.util.Spliterator<org.jsoup.nodes.Attribute> attributeSpliterator57 = attributes0.spliterator();
        boolean boolean59 = attributes0.hasKey("");
        java.lang.String str61 = attributes0.get(" text=\"hi!\" hi!=\"hi!\" data-=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(attributeItor1);
        org.junit.Assert.assertNotNull(document6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(document13);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNotNull(outputSettings18);
        org.junit.Assert.assertNotNull(outputSettings20);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;" + "'", str21, "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.junit.Assert.assertNotNull(document25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "" + "'", str28, "");
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "" + "'", str30, "");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(attributeItor34);
        org.junit.Assert.assertNotNull(document39);
        org.junit.Assert.assertNotNull(element41);
        org.junit.Assert.assertNotNull(element43);
        org.junit.Assert.assertNotNull(document46);
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "" + "'", str47, "");
        org.junit.Assert.assertNotNull(outputSettings51);
        org.junit.Assert.assertNotNull(outputSettings53);
        org.junit.Assert.assertEquals("'" + str54 + "' != '" + "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;" + "'", str54, "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.junit.Assert.assertNotNull(attributeSpliterator57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + "" + "'", str61, "");
    }

    @Test
    public void test2578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2578");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.nodes.Attributes attributes7 = element6.attributes;
        org.jsoup.nodes.Element element8 = element6.empty();
        org.jsoup.nodes.Element element10 = element8.addClass("hi!");
        org.jsoup.parser.Tag tag11 = element10.tag();
        org.jsoup.nodes.Document document14 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element16 = document14.addClass("");
        org.jsoup.nodes.Element element18 = document14.val("hi!");
        org.jsoup.nodes.Attributes attributes19 = element18.attributes;
        org.jsoup.nodes.Element element20 = element18.empty();
        org.jsoup.nodes.Element element22 = element20.addClass("hi!");
        org.jsoup.parser.Tag tag23 = element22.tag();
        java.util.List<org.jsoup.nodes.Node> nodeList24 = element22.childNodes();
        boolean boolean25 = tag11.equals((java.lang.Object) nodeList24);
        java.lang.String str26 = tag11.toString();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(attributes7);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(tag11);
        org.junit.Assert.assertNotNull(document14);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(attributes19);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(element22);
        org.junit.Assert.assertNotNull(tag23);
        org.junit.Assert.assertNotNull(nodeList24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "#root" + "'", str26, "#root");
    }

    @Test
    public void test2579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2579");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.val();
        java.lang.String str5 = document2.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements8 = document2.getElementsByAttributeValue("hi!", "hi!");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element13 = document11.addClass("");
        org.jsoup.nodes.Element element15 = element13.prependElement("hi!");
        org.jsoup.nodes.Document document18 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str19 = document18.val();
        element13.setParentNode((org.jsoup.nodes.Node) document18);
        int int21 = document18.siblingIndex;
        org.jsoup.select.Elements elements23 = document18.getElementsMatchingText("hi!");
        boolean boolean25 = elements23.hasAttr("#declaration");
        java.lang.Object obj26 = null;
        boolean boolean27 = elements23.contains(obj26);
        boolean boolean28 = elements8.removeAll((java.util.Collection<org.jsoup.nodes.Element>) elements23);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(elements23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test2580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2580");
        org.jsoup.nodes.TextNode textNode2 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        org.jsoup.nodes.Node node5 = textNode2.attr("hi!", "hi!");
        boolean boolean6 = textNode2.isBlank();
        java.lang.String str7 = textNode2.text();
        java.lang.StringBuilder stringBuilder8 = null;
        org.jsoup.nodes.DataNode dataNode12 = new org.jsoup.nodes.DataNode("hi!<html>\n <head></head>\n <body></body>\n</html>", "\n<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.StringBuilder stringBuilder13 = null;
        org.jsoup.nodes.Document document18 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element20 = document18.addClass("");
        org.jsoup.nodes.Element element22 = element20.prependElement("hi!");
        org.jsoup.nodes.Document document25 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str26 = document25.val();
        element20.setParentNode((org.jsoup.nodes.Node) document25);
        org.jsoup.nodes.Document.OutputSettings outputSettings28 = document25.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings30 = outputSettings28.prettyPrint(false);
        java.lang.String str31 = org.jsoup.nodes.Entities.escape("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", outputSettings28);
        dataNode12.outerHtmlTail(stringBuilder13, (int) (byte) -1, outputSettings28);
        textNode2.outerHtmlTail(stringBuilder8, 2, outputSettings28);
        org.jsoup.nodes.Entities.EscapeMode escapeMode34 = org.jsoup.nodes.Entities.EscapeMode.base;
        java.util.Map<java.lang.Character, java.lang.String> charMap35 = escapeMode34.getMap();
        org.jsoup.nodes.Document.OutputSettings outputSettings36 = outputSettings28.escapeMode(escapeMode34);
        org.jsoup.nodes.Document.OutputSettings outputSettings38 = outputSettings28.indentAmount((int) '#');
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Document.OutputSettings outputSettings40 = outputSettings28.charset("<html>\n <head></head>\n <body></body>\n</html>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
            org.junit.Assert.fail("Expected exception of type java.nio.charset.IllegalCharsetNameException; message: <html>? <head></head>? <body></body>?</html>=\"&lt;html&gt;? &lt;head&gt;&lt;/head&gt;? &lt;body&gt;&lt;/body&gt;?&lt;/html&gt;\"");
        } catch (java.nio.charset.IllegalCharsetNameException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(textNode2);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "hi!" + "'", str7, "hi!");
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(element22);
        org.junit.Assert.assertNotNull(document25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertNotNull(outputSettings30);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;" + "'", str31, "&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;");
        org.junit.Assert.assertTrue("'" + escapeMode34 + "' != '" + org.jsoup.nodes.Entities.EscapeMode.base + "'", escapeMode34.equals(org.jsoup.nodes.Entities.EscapeMode.base));
        org.junit.Assert.assertNotNull(charMap35);
        org.junit.Assert.assertNotNull(outputSettings36);
        org.junit.Assert.assertNotNull(outputSettings38);
    }

    @Test
    public void test2581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2581");
        org.jsoup.nodes.Evaluator.ContainsOwnText containsOwnText1 = new org.jsoup.nodes.Evaluator.ContainsOwnText("<html>\n <head></head>\n <body>\n  #text\n </body>\n</html>");
        org.jsoup.nodes.Document document4 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element6 = document4.addClass("");
        org.jsoup.nodes.Element element8 = element6.prependElement("hi!");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str12 = document11.val();
        element6.setParentNode((org.jsoup.nodes.Node) document11);
        org.jsoup.nodes.Element element15 = document11.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element16 = document11.body();
        boolean boolean17 = containsOwnText1.matches(element16);
        org.jsoup.nodes.Document document20 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str21 = document20.val();
        java.lang.String str23 = document20.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements26 = document20.getElementsByAttributeValue("hi!", "hi!");
        org.jsoup.select.Elements elements27 = elements26.parents();
        org.jsoup.select.Elements elements28 = elements26.remove();
        org.jsoup.select.Elements elements29 = elements26.remove();
        org.jsoup.select.Elements elements30 = elements26.empty();
        org.jsoup.select.Elements elements33 = elements30.attr("\n<body></body>", "\n<body></body>");
        org.jsoup.nodes.Document document36 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str37 = document36.title();
        org.jsoup.nodes.Element[] elementArray38 = new org.jsoup.nodes.Element[] { document36 };
        java.util.ArrayList<org.jsoup.nodes.Element> elementList39 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList39, elementArray38);
        java.util.stream.Stream<org.jsoup.nodes.Element> elementStream41 = elementList39.stream();
        boolean boolean42 = elements30.containsAll((java.util.Collection<org.jsoup.nodes.Element>) elementList39);
        org.jsoup.nodes.Document document45 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element47 = document45.addClass("");
        int int48 = elements30.indexOf((java.lang.Object) document45);
        java.lang.String str49 = document45.outerHtml();
        java.lang.String str50 = document45.tagName();
        boolean boolean51 = containsOwnText1.matches((org.jsoup.nodes.Element) document45);
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(document20);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertNotNull(elements26);
        org.junit.Assert.assertNotNull(elements27);
        org.junit.Assert.assertNotNull(elements28);
        org.junit.Assert.assertNotNull(elements29);
        org.junit.Assert.assertNotNull(elements30);
        org.junit.Assert.assertNotNull(elements33);
        org.junit.Assert.assertNotNull(document36);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
        org.junit.Assert.assertNotNull(elementArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(elementStream41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(document45);
        org.junit.Assert.assertNotNull(element47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>" + "'", str49, "<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "#root" + "'", str50, "#root");
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test2582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2582");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        java.lang.String str4 = document2.className();
        java.lang.String str5 = document2.title();
        org.jsoup.nodes.Node[] nodeArray6 = document2.childNodesAsArray();
        org.jsoup.helper.Validate.noNullElements((java.lang.Object[]) nodeArray6);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNotNull(nodeArray6);
    }

    @Test
    public void test2583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2583");
        org.jsoup.nodes.Evaluator.Attribute attribute1 = new org.jsoup.nodes.Evaluator.Attribute("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList5 = document4.childNodes();
        org.jsoup.select.Elements elements6 = document4.getAllElements();
        org.jsoup.nodes.Element element7 = document4.head();
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        org.jsoup.nodes.Element element18 = element7.classNames((java.util.Set<java.lang.String>) strSet16);
        org.jsoup.nodes.Element element19 = element7.parent();
        java.lang.String str20 = element19.val();
        boolean boolean21 = attribute1.matches(element19);
        java.lang.Integer int22 = element19.siblingIndex();
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(nodeList5);
        org.junit.Assert.assertNotNull(elements6);
        org.junit.Assert.assertNotNull(element7);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertArrayEquals(strArray15, new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" });
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test2584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2584");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        org.jsoup.nodes.Element element13 = document9.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document14 = document9.ownerDocument();
        org.jsoup.select.Elements elements16 = document9.getElementsByAttributeStarting("body");
        org.jsoup.nodes.Element element18 = document9.val("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        java.util.List<org.jsoup.nodes.Node> nodeList19 = element18.childNodes();
        org.jsoup.select.Elements elements21 = element18.getElementsByTag("hi!");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertNotNull(document14);
        org.junit.Assert.assertNotNull(elements16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(nodeList19);
        org.junit.Assert.assertNotNull(elements21);
    }

    @Test
    public void test2585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2585");
        org.jsoup.parser.Tag tag1 = org.jsoup.parser.Tag.valueOf("hi!");
        boolean boolean2 = tag1.preserveWhitespace();
        boolean boolean3 = tag1.isKnownTag();
        boolean boolean4 = tag1.preserveWhitespace();
        org.jsoup.nodes.Document document8 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element10 = document8.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element12 = document8.html("");
        org.jsoup.nodes.Attributes attributes13 = document8.attributes();
        java.util.Map<java.lang.String, java.lang.String> strMap14 = attributes13.dataset();
        org.jsoup.nodes.Element element15 = new org.jsoup.nodes.Element(tag1, "#declaration", attributes13);
        org.jsoup.nodes.Element element18 = element15.attr("#text", "hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.parser.Tag tag19 = element18.tag();
        org.jsoup.nodes.Element element21 = element18.appendElement("<html> <head></head> <body></body> </html>");
        org.jsoup.select.Elements elements23 = element21.getElementsContainingOwnText("<body></body>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        org.jsoup.select.Elements elements25 = elements23.toggleClass(" <html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>");
        org.junit.Assert.assertNotNull(tag1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(document8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(attributes13);
        org.junit.Assert.assertNotNull(strMap14);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(tag19);
        org.junit.Assert.assertNotNull(element21);
        org.junit.Assert.assertNotNull(elements23);
        org.junit.Assert.assertNotNull(elements25);
    }

    @Test
    public void test2586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2586");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        org.jsoup.nodes.Element element5 = document2.head();
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        org.jsoup.nodes.Element element16 = element5.classNames((java.util.Set<java.lang.String>) strSet14);
        org.jsoup.nodes.Element element18 = element5.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element21 = element5.attr("#text", "hi!");
        org.jsoup.select.Elements elements23 = element5.getElementsByIndexGreaterThan((int) (byte) 0);
        org.jsoup.select.Elements elements25 = element5.getElementsContainingText(" <html> <head></head> <body></body> </html>");
        org.jsoup.select.Elements elements28 = elements25.attr("<html> <head></head> <body> hi! </body> </html>", " text=\"hi!\" hi!=\"hi!\" hi!<html>\n <head></head>\n <body></body>\n</html>=\"\"");
        org.jsoup.nodes.Document document30 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.select.Elements elements32 = document30.getElementsByAttribute("hi!");
        java.lang.Object[] objArray33 = elements32.toArray();
        boolean boolean34 = elements28.equals((java.lang.Object) elements32);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertNotNull(element5);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertArrayEquals(strArray13, new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" });
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(element21);
        org.junit.Assert.assertNotNull(elements23);
        org.junit.Assert.assertNotNull(elements25);
        org.junit.Assert.assertNotNull(elements28);
        org.junit.Assert.assertNotNull(document30);
        org.junit.Assert.assertNotNull(elements32);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertArrayEquals(objArray33, new java.lang.Object[] {});
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test2587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2587");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("<html>\n <head></head>\n <body>\n  <html>  \n  </html> \n </body>\n</html>", "hi!\n<html>  \n</html> \n<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(document2);
    }

    @Test
    public void test2588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2588");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element6 = document2.html("");
        org.jsoup.select.Elements elements8 = document2.getElementsByIndexEquals(2);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(elements8);
    }

    @Test
    public void test2589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2589");
        org.jsoup.nodes.Attribute attribute2 = new org.jsoup.nodes.Attribute("<html>\n <head></head>\n <body></body>\n</html>", "#data");
        java.lang.String str3 = attribute2.toString();
        boolean boolean4 = attribute2.isDataAttribute();
        boolean boolean5 = attribute2.isDataAttribute();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>=\"#data\"" + "'", str3, "<html>\n <head></head>\n <body></body>\n</html>=\"#data\"");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test2590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2590");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        boolean boolean13 = document9.equals((java.lang.Object) 10L);
        org.jsoup.nodes.Document.OutputSettings outputSettings14 = document9.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings16 = outputSettings14.indentAmount((int) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Document.OutputSettings outputSettings18 = outputSettings14.charset("<html> <head></head> <body> hi! </body> </html>");
            org.junit.Assert.fail("Expected exception of type java.nio.charset.IllegalCharsetNameException; message: <html> <head></head> <body> hi! </body> </html>");
        } catch (java.nio.charset.IllegalCharsetNameException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(outputSettings16);
    }

    @Test
    public void test2591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2591");
        org.jsoup.nodes.Evaluator.ContainsOwnText containsOwnText1 = new org.jsoup.nodes.Evaluator.ContainsOwnText("");
        org.jsoup.nodes.Document document4 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element6 = document4.addClass("");
        org.jsoup.nodes.Element element8 = element6.prependElement("hi!");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str12 = document11.val();
        element6.setParentNode((org.jsoup.nodes.Node) document11);
        org.jsoup.nodes.Element element15 = document11.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document16 = document11.ownerDocument();
        org.jsoup.select.Elements elements18 = document11.getElementsByAttributeStarting("body");
        boolean boolean19 = containsOwnText1.matches((org.jsoup.nodes.Element) document11);
        org.jsoup.nodes.Document document22 = org.jsoup.parser.Parser.parseBodyFragmentRelaxed("#data", "<html>\n <head></head>\n <body>\n  <html>  \n  </html> #data  \n </body>\n</html>");
        boolean boolean23 = containsOwnText1.matches((org.jsoup.nodes.Element) document22);
        org.jsoup.nodes.Element element24 = document22.head();
        java.lang.String str26 = element24.absUrl(" <html> <head></head> <body></body> </html>#document");
        java.util.regex.Pattern pattern27 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.select.Elements elements28 = element24.getElementsMatchingText(pattern27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(document16);
        org.junit.Assert.assertNotNull(elements18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(document22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(element24);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
    }

    @Test
    public void test2592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2592");
        org.jsoup.nodes.TextNode textNode2 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        textNode2.text = "";
        java.lang.String str5 = textNode2.nodeName();
        org.jsoup.nodes.Attributes attributes6 = textNode2.attributes();
        textNode2.text = "#text";
        java.lang.StringBuilder stringBuilder9 = null;
        org.jsoup.nodes.Document document13 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList14 = document13.childNodes();
        org.jsoup.nodes.TextNode textNode17 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        textNode17.text = "";
        org.jsoup.nodes.Element element20 = document13.prependChild((org.jsoup.nodes.Node) textNode17);
        org.jsoup.nodes.Attributes attributes21 = textNode17.attributes;
        java.lang.StringBuilder stringBuilder22 = null;
        org.jsoup.nodes.TextNode textNode26 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        textNode26.text = "";
        java.lang.String str29 = textNode26.nodeName();
        org.jsoup.nodes.Attributes attributes30 = textNode26.attributes();
        java.lang.StringBuilder stringBuilder31 = null;
        org.jsoup.nodes.Comment comment35 = new org.jsoup.nodes.Comment("#text", "");
        java.lang.StringBuilder stringBuilder36 = null;
        org.jsoup.nodes.Document document40 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element42 = document40.addClass("");
        org.jsoup.nodes.Element element44 = element42.prependElement("hi!");
        org.jsoup.nodes.Document document47 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str48 = document47.val();
        element42.setParentNode((org.jsoup.nodes.Node) document47);
        org.jsoup.nodes.Document.OutputSettings outputSettings50 = document47.new OutputSettings();
        boolean boolean51 = outputSettings50.prettyPrint();
        boolean boolean52 = outputSettings50.prettyPrint();
        comment35.outerHtmlTail(stringBuilder36, (int) (byte) 10, outputSettings50);
        textNode26.outerHtmlTail(stringBuilder31, (int) (byte) 0, outputSettings50);
        org.jsoup.nodes.Entities.EscapeMode escapeMode55 = org.jsoup.nodes.Entities.EscapeMode.xhtml;
        org.jsoup.nodes.Document.OutputSettings outputSettings56 = outputSettings50.escapeMode(escapeMode55);
        org.jsoup.nodes.Entities.EscapeMode escapeMode57 = outputSettings56.escapeMode();
        boolean boolean58 = outputSettings56.prettyPrint();
        textNode17.outerHtmlTail(stringBuilder22, 1, outputSettings56);
        java.nio.charset.Charset charset60 = outputSettings56.charset();
        textNode2.outerHtmlTail(stringBuilder9, (-1), outputSettings56);
        org.jsoup.nodes.Document document62 = textNode2.ownerDocument();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str63 = textNode2.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(textNode2);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "#text" + "'", str5, "#text");
        org.junit.Assert.assertNotNull(attributes6);
        org.junit.Assert.assertNotNull(document13);
        org.junit.Assert.assertNotNull(nodeList14);
        org.junit.Assert.assertNotNull(textNode17);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNull(attributes21);
        org.junit.Assert.assertNotNull(textNode26);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "#text" + "'", str29, "#text");
        org.junit.Assert.assertNotNull(attributes30);
        org.junit.Assert.assertNotNull(document40);
        org.junit.Assert.assertNotNull(element42);
        org.junit.Assert.assertNotNull(element44);
        org.junit.Assert.assertNotNull(document47);
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "" + "'", str48, "");
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + escapeMode55 + "' != '" + org.jsoup.nodes.Entities.EscapeMode.xhtml + "'", escapeMode55.equals(org.jsoup.nodes.Entities.EscapeMode.xhtml));
        org.junit.Assert.assertNotNull(outputSettings56);
        org.junit.Assert.assertTrue("'" + escapeMode57 + "' != '" + org.jsoup.nodes.Entities.EscapeMode.xhtml + "'", escapeMode57.equals(org.jsoup.nodes.Entities.EscapeMode.xhtml));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(charset60);
        org.junit.Assert.assertNull(document62);
    }

    @Test
    public void test2593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2593");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.title();
        org.jsoup.select.Elements elements4 = document2.getAllElements();
        document2.siblingIndex = (short) -1;
        org.jsoup.nodes.Element element8 = document2.prependText("<html> <head></head> <body></body> </html>=\"#data\"");
        org.jsoup.nodes.Document document11 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element13 = document11.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element15 = document11.html("");
        java.util.regex.Pattern pattern17 = null;
        org.jsoup.select.Elements elements18 = document11.getElementsByAttributeValueMatching("", pattern17);
        org.jsoup.nodes.Attributes attributes19 = document11.attributes;
        org.jsoup.nodes.Attribute attribute22 = new org.jsoup.nodes.Attribute("head=\"#comment\"", "<html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>");
        attributes19.put(attribute22);
        boolean boolean24 = document2.equals((java.lang.Object) attribute22);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(elements18);
        org.junit.Assert.assertNotNull(attributes19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test2594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2594");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        boolean boolean13 = document9.equals((java.lang.Object) 10L);
        java.util.List<org.jsoup.nodes.Node> nodeList14 = document9.childNodes;
        java.lang.String str15 = document9.html();
        java.lang.Integer int16 = document9.siblingIndex();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeList14);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>" + "'", str15, "<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test2595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2595");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("data-");
        document1.title("#declaration");
        org.jsoup.select.Elements elements5 = document1.getElementsByIndexLessThan(0);
        org.jsoup.select.Elements elements7 = elements5.removeAttr("<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n\n<body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n hi! \n</body>");
        org.jsoup.nodes.Document document10 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str11 = document10.val();
        java.lang.String str13 = document10.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Node node16 = document10.attr("<html>\n <head></head>\n <body></body>\n</html>", "hi!");
        java.lang.String str17 = document10.className();
        org.jsoup.nodes.Element element19 = document10.removeClass("");
        boolean boolean20 = elements5.contains((java.lang.Object) "");
        org.jsoup.select.Elements elements21 = elements5.parents();
        // The following exception was thrown during execution in test generation
        try {
            java.util.List<org.jsoup.nodes.Element> elementList24 = elements21.subList(10, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertNotNull(elements5);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(document10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(elements21);
    }

    @Test
    public void test2596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2596");
        org.jsoup.nodes.DataNode dataNode2 = org.jsoup.nodes.DataNode.createFromEncoded("", "#text");
        java.lang.StringBuilder stringBuilder3 = null;
        org.jsoup.nodes.Document document7 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element9 = document7.addClass("");
        org.jsoup.nodes.Element element11 = element9.prependElement("hi!");
        org.jsoup.nodes.Document document14 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str15 = document14.val();
        element9.setParentNode((org.jsoup.nodes.Node) document14);
        org.jsoup.nodes.Document.OutputSettings outputSettings17 = document14.new OutputSettings();
        dataNode2.outerHtmlTail(stringBuilder3, 100, outputSettings17);
        org.jsoup.nodes.DataNode dataNode20 = dataNode2.setWholeData("\n<hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.DataNode dataNode22 = dataNode20.setWholeData("hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Document document23 = dataNode20.ownerDocument();
        org.junit.Assert.assertNotNull(dataNode2);
        org.junit.Assert.assertNotNull(document7);
        org.junit.Assert.assertNotNull(element9);
        org.junit.Assert.assertNotNull(element11);
        org.junit.Assert.assertNotNull(document14);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNotNull(dataNode20);
        org.junit.Assert.assertNotNull(dataNode22);
        org.junit.Assert.assertNull(document23);
    }

    @Test
    public void test2597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2597");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("data-", "");
        org.jsoup.nodes.Element element4 = document2.prependElement("<html>\n <head></head>\n <body>\n  body\n </body>\n</html>");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
    }

    @Test
    public void test2598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2598");
        org.jsoup.nodes.Evaluator.AllElements allElements0 = new org.jsoup.nodes.Evaluator.AllElements();
        org.jsoup.nodes.Document document3 = org.jsoup.Jsoup.parseBodyFragment("data-", "");
        document3.baseUri = "#root";
        boolean boolean6 = allElements0.matches((org.jsoup.nodes.Element) document3);
        java.lang.Integer int7 = document3.elementSiblingIndex();
        org.jsoup.select.Elements elements9 = document3.getElementsContainingText("<body></body>");
        org.jsoup.nodes.Evaluator.IndexEquals indexEquals11 = new org.jsoup.nodes.Evaluator.IndexEquals(0);
        org.jsoup.nodes.Document document14 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList15 = document14.childNodes();
        org.jsoup.select.Elements elements16 = document14.getAllElements();
        org.jsoup.nodes.Element element17 = document14.head();
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" };
        java.util.LinkedHashSet<java.lang.String> strSet26 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet26, strArray25);
        org.jsoup.nodes.Element element28 = element17.classNames((java.util.Set<java.lang.String>) strSet26);
        org.jsoup.nodes.Element element29 = element17.parent();
        boolean boolean30 = indexEquals11.matches(element29);
        element29.baseUri = "#data";
        org.jsoup.nodes.Element element34 = element29.append("<html>\n <head></head>\n <body>\n  <html>  \n  </html> #data  \n </body>\n</html>");
        org.jsoup.nodes.Element element36 = element29.appendText("<html> <head></head> <body></body> </html>");
        org.jsoup.nodes.Element element38 = element29.before("<html> <head></head> <body></body> </html>");
        document3.parentNode = element29;
        org.jsoup.nodes.Document.OutputSettings outputSettings40 = document3.new OutputSettings();
        org.jsoup.nodes.Element element42 = document3.append("<html> <head></head> <body></body> </html>");
        org.junit.Assert.assertNotNull(document3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(elements9);
        org.junit.Assert.assertNotNull(document14);
        org.junit.Assert.assertNotNull(nodeList15);
        org.junit.Assert.assertNotNull(elements16);
        org.junit.Assert.assertNotNull(element17);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertArrayEquals(strArray25, new java.lang.String[] { "hi!<html>\n <head></head>\n <body></body>\n</html>", "", "#document", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "#document", "data-" });
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(element28);
        org.junit.Assert.assertNotNull(element29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(element34);
        org.junit.Assert.assertNotNull(element36);
        org.junit.Assert.assertNotNull(element38);
        org.junit.Assert.assertNotNull(element42);
    }

    @Test
    public void test2599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2599");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.val();
        java.lang.String str5 = document2.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements8 = document2.getElementsByAttributeValue("hi!", "hi!");
        java.lang.String str9 = elements8.text();
        org.jsoup.nodes.Document document12 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList13 = document12.childNodes();
        org.jsoup.nodes.TextNode textNode16 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        textNode16.text = "";
        org.jsoup.nodes.Element element19 = document12.prependChild((org.jsoup.nodes.Node) textNode16);
        boolean boolean20 = elements8.contains((java.lang.Object) textNode16);
        java.lang.String str21 = textNode16.text;
        boolean boolean22 = textNode16.isBlank();
        org.jsoup.nodes.TextNode textNode24 = textNode16.text("#text");
        org.jsoup.nodes.Attributes attributes25 = textNode16.attributes();
        int int26 = attributes25.size();
        java.util.Spliterator<org.jsoup.nodes.Attribute> attributeSpliterator27 = attributes25.spliterator();
        java.lang.String str28 = attributes25.html();
        int int29 = attributes25.size();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "" + "'", str9, "");
        org.junit.Assert.assertNotNull(document12);
        org.junit.Assert.assertNotNull(nodeList13);
        org.junit.Assert.assertNotNull(textNode16);
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(textNode24);
        org.junit.Assert.assertNotNull(attributes25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(attributeSpliterator27);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + " text=\"#text\"" + "'", str28, " text=\"#text\"");
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test2600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2600");
        org.jsoup.nodes.XmlDeclaration xmlDeclaration3 = new org.jsoup.nodes.XmlDeclaration("", "", true);
        java.lang.StringBuilder stringBuilder4 = null;
        org.jsoup.nodes.Document document8 = org.jsoup.Jsoup.parseBodyFragment("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.jsoup.nodes.Document.OutputSettings outputSettings9 = document8.outputSettings();
        // The following exception was thrown during execution in test generation
        try {
            xmlDeclaration3.outerHtmlHead(stringBuilder4, (-1), outputSettings9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document8);
        org.junit.Assert.assertNotNull(outputSettings9);
    }

    @Test
    public void test2601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2601");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parseBodyFragment("<html>\n <head></head>\n <body>\n  #text\n </body>\n</html>", "<html>\n <head></head>\n <body></body>\n</html>\n<head></head>\n<body></body>\n\n");
        org.jsoup.nodes.Node node3 = document2.parent();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test2602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2602");
        org.jsoup.nodes.TextNode textNode2 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        java.lang.String str4 = textNode2.attr("#document");
        java.lang.String str6 = textNode2.attr("#declaration");
        java.lang.String str7 = textNode2.text();
        java.lang.String str8 = textNode2.getWholeText();
        java.lang.StringBuilder stringBuilder9 = null;
        org.jsoup.nodes.Document document13 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element15 = document13.addClass("");
        org.jsoup.nodes.Element element17 = element15.prependElement("hi!");
        org.jsoup.nodes.Document document20 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str21 = document20.val();
        element15.setParentNode((org.jsoup.nodes.Node) document20);
        org.jsoup.nodes.Document.OutputSettings outputSettings23 = document20.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings25 = outputSettings23.prettyPrint(false);
        org.jsoup.nodes.Document.OutputSettings outputSettings27 = outputSettings23.indentAmount((int) (short) 10);
        textNode2.outerHtmlTail(stringBuilder9, 0, outputSettings27);
        java.lang.String str29 = textNode2.nodeName();
        org.junit.Assert.assertNotNull(textNode2);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "hi!" + "'", str7, "hi!");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "hi!" + "'", str8, "hi!");
        org.junit.Assert.assertNotNull(document13);
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(element17);
        org.junit.Assert.assertNotNull(document20);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "" + "'", str21, "");
        org.junit.Assert.assertNotNull(outputSettings25);
        org.junit.Assert.assertNotNull(outputSettings27);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "#text" + "'", str29, "#text");
    }

    @Test
    public void test2603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2603");
        org.jsoup.nodes.Evaluator.AttributeWithValueNot attributeWithValueNot2 = new org.jsoup.nodes.Evaluator.AttributeWithValueNot("#document", "#root");
        java.lang.String str3 = attributeWithValueNot2.value;
        attributeWithValueNot2.value = "";
        java.lang.String str6 = attributeWithValueNot2.key;
        org.jsoup.nodes.Document document8 = new org.jsoup.nodes.Document("data-");
        boolean boolean9 = document8.isBlock();
        org.jsoup.nodes.Document document12 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList13 = document12.childNodes();
        org.jsoup.select.Elements elements14 = document12.getAllElements();
        org.jsoup.nodes.Element element15 = document12.head();
        java.util.Set<java.lang.String> strSet16 = document12.classNames();
        java.lang.String str18 = org.jsoup.helper.StringUtil.join((java.util.Collection<java.lang.String>) strSet16, "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.jsoup.nodes.Element element19 = document8.classNames(strSet16);
        boolean boolean20 = attributeWithValueNot2.matches(element19);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "#root" + "'", str3, "#root");
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "#document" + "'", str6, "#document");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(document12);
        org.junit.Assert.assertNotNull(nodeList13);
        org.junit.Assert.assertNotNull(elements14);
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test2604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2604");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element6 = document2.html("");
        boolean boolean7 = document2.preserveWhitespace();
        org.jsoup.nodes.Element element9 = document2.appendElement("<html> <head></head> <body></body> </html>");
        java.lang.Integer int10 = document2.siblingIndex();
        boolean boolean11 = document2.isBlock();
        boolean boolean12 = document2.preserveWhitespace();
        java.util.regex.Pattern pattern14 = null;
        org.jsoup.select.Elements elements15 = document2.getElementsByAttributeValueMatching("hi!<html>&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;<head></head>&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;<body></body>&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;</html>&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;#document&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;&lt;html&gt;&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;&lt;head&gt;&lt;/head&gt;&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;&lt;body&gt;&lt;/body&gt;&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;&lt;/html&gt;&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;data-&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;<html>\n <head></head>\n <body></body>\n</html>", pattern14);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(element9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(elements15);
    }

    @Test
    public void test2605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2605");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element6 = document2.addClass("");
        org.jsoup.select.Elements elements8 = document2.getElementsContainingText("#document");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str12 = document11.val();
        java.lang.String str14 = document11.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements17 = document11.getElementsByAttributeValue("hi!", "hi!");
        int int18 = elements17.size();
        java.lang.String str20 = elements17.attr("hi!");
        boolean boolean21 = elements8.removeAll((java.util.Collection<org.jsoup.nodes.Element>) elements17);
        org.jsoup.select.Elements elements22 = elements8.empty();
        org.jsoup.nodes.Document document25 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList26 = document25.childNodes();
        org.jsoup.select.Elements elements27 = document25.getAllElements();
        boolean boolean29 = elements27.hasClass("#document");
        boolean boolean30 = elements8.addAll((java.util.Collection<org.jsoup.nodes.Element>) elements27);
        org.jsoup.select.Elements elements31 = elements27.parents();
        org.jsoup.select.Elements elements33 = elements31.before("");
        java.lang.String str34 = elements33.toString();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNotNull(elements17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(elements22);
        org.junit.Assert.assertNotNull(document25);
        org.junit.Assert.assertNotNull(nodeList26);
        org.junit.Assert.assertNotNull(elements27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(elements31);
        org.junit.Assert.assertNotNull(elements33);
        org.junit.Assert.assertEquals("'" + str34 + "' != '" + "\n<html>\n <head></head>\n <body>\n  hi! \n </body>\n</html>" + "'", str34, "\n<html>\n <head></head>\n <body>\n  hi! \n </body>\n</html>");
    }

    @Test
    public void test2606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2606");
        org.jsoup.safety.Whitelist whitelist1 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean2 = org.jsoup.Jsoup.isValid("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;", whitelist1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }

    @Test
    public void test2607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2607");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.val();
        org.jsoup.nodes.Node node5 = document2.removeAttr("hi!");
        org.jsoup.select.Elements elements8 = document2.getElementsByAttributeValueStarting("head", " #declaration=\"&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;\"");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(elements8);
    }

    @Test
    public void test2608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2608");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.select.Elements elements8 = element6.getElementsMatchingOwnText("&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;");
        org.jsoup.select.Elements elements10 = element6.getElementsMatchingText("hi!<html> <head></head> <body></body> </html>");
        org.jsoup.select.Elements elements12 = element6.getElementsByIndexEquals((int) '\n');
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertNotNull(elements10);
        org.junit.Assert.assertNotNull(elements12);
    }

    @Test
    public void test2609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2609");
        org.jsoup.parser.Tag tag1 = org.jsoup.parser.Tag.valueOf("hi!");
        boolean boolean2 = tag1.preserveWhitespace();
        boolean boolean3 = tag1.isKnownTag();
        boolean boolean4 = tag1.preserveWhitespace();
        org.jsoup.nodes.Document document8 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element10 = document8.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element12 = document8.html("");
        org.jsoup.nodes.Attributes attributes13 = document8.attributes();
        java.util.Map<java.lang.String, java.lang.String> strMap14 = attributes13.dataset();
        org.jsoup.nodes.Element element15 = new org.jsoup.nodes.Element(tag1, "#declaration", attributes13);
        java.lang.String str16 = tag1.toString();
        boolean boolean17 = tag1.isEmpty();
        org.junit.Assert.assertNotNull(tag1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(document8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(attributes13);
        org.junit.Assert.assertNotNull(strMap14);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "hi!" + "'", str16, "hi!");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test2610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2610");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.nodes.Attributes attributes7 = element6.attributes;
        org.jsoup.nodes.Element element8 = element6.empty();
        org.jsoup.nodes.Element element10 = element8.addClass("hi!");
        java.lang.String str11 = element10.nodeName();
        org.jsoup.select.Elements elements13 = element10.getElementsByIndexEquals((int) (byte) 10);
        org.jsoup.nodes.Document document16 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element18 = document16.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element21 = document16.attr("hi!", "");
        java.util.Set<java.lang.String> strSet22 = element21.classNames();
        org.jsoup.nodes.Element element23 = element10.classNames(strSet22);
        boolean boolean25 = element10.hasAttr("<html> <head></head> <body></body> </html>");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(attributes7);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "#document" + "'", str11, "#document");
        org.junit.Assert.assertNotNull(elements13);
        org.junit.Assert.assertNotNull(document16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertNotNull(element21);
        org.junit.Assert.assertNotNull(strSet22);
        org.junit.Assert.assertNotNull(element23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test2611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2611");
        org.jsoup.nodes.Evaluator.AttributeWithValueNot attributeWithValueNot2 = new org.jsoup.nodes.Evaluator.AttributeWithValueNot("#document", "#root");
        java.lang.String str3 = attributeWithValueNot2.value;
        attributeWithValueNot2.key = "hi!<html>\n <head></head>\n <body></body>\n</html>";
        org.jsoup.nodes.Document document8 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element10 = document8.addClass("");
        org.jsoup.nodes.Element element12 = document8.val("hi!");
        org.jsoup.nodes.Attributes attributes13 = element12.attributes;
        org.jsoup.nodes.Element element14 = element12.empty();
        org.jsoup.nodes.Element element16 = element14.addClass("hi!");
        org.jsoup.nodes.Element element18 = element16.append("hi!");
        boolean boolean19 = attributeWithValueNot2.matches(element18);
        org.jsoup.nodes.Evaluator.Class class21 = new org.jsoup.nodes.Evaluator.Class("#root");
        org.jsoup.nodes.Document document24 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element26 = document24.addClass("");
        org.jsoup.nodes.Element element28 = document24.val("hi!");
        org.jsoup.nodes.Attributes attributes29 = element28.attributes;
        org.jsoup.nodes.Element element30 = element28.empty();
        org.jsoup.nodes.Element element32 = element30.addClass("hi!");
        int int33 = element30.siblingIndex;
        org.jsoup.nodes.Element element36 = element30.attr("hi!", "hi!<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean37 = class21.matches(element36);
        org.jsoup.nodes.Document document40 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element42 = document40.addClass("");
        org.jsoup.nodes.Element element44 = element42.prependElement("hi!");
        org.jsoup.nodes.Node node45 = element42.nextSibling();
        org.jsoup.select.Elements elements46 = element42.children();
        boolean boolean47 = class21.matches(element42);
        boolean boolean48 = attributeWithValueNot2.matches(element42);
        java.lang.String str50 = element42.attr("<html>\n <head></head>\n <body>\n  hi! \n </body>\n</html>");
        java.lang.Integer int51 = element42.elementSiblingIndex();
        org.jsoup.select.Elements elements53 = element42.getElementsByAttribute("<html>\n <head></head>\n <body>\n  #data\n </body>\n</html>");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "#root" + "'", str3, "#root");
        org.junit.Assert.assertNotNull(document8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(attributes13);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(element18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(document24);
        org.junit.Assert.assertNotNull(element26);
        org.junit.Assert.assertNotNull(element28);
        org.junit.Assert.assertNotNull(attributes29);
        org.junit.Assert.assertNotNull(element30);
        org.junit.Assert.assertNotNull(element32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(element36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(document40);
        org.junit.Assert.assertNotNull(element42);
        org.junit.Assert.assertNotNull(element44);
        org.junit.Assert.assertNull(node45);
        org.junit.Assert.assertNotNull(elements46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertEquals("'" + str50 + "' != '" + "" + "'", str50, "");
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(elements53);
    }

    @Test
    public void test2612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2612");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.nodes.Node[] nodeArray7 = document2.childNodesAsArray();
        java.lang.String str8 = document2.id();
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element13 = document11.addClass("");
        org.jsoup.nodes.Element element15 = element13.prependElement("hi!");
        org.jsoup.nodes.Node node16 = element13.nextSibling();
        org.jsoup.select.Elements elements17 = element13.children();
        boolean boolean18 = document2.equals((java.lang.Object) elements17);
        java.lang.String str19 = document2.baseUri;
        java.lang.String str20 = document2.toString();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(nodeArray7);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(elements17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>" + "'", str20, "<html>\n <head></head>\n <body></body>\n</html>");
    }

    @Test
    public void test2613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2613");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.nodes.Attributes attributes7 = element6.attributes;
        org.jsoup.nodes.Element element8 = element6.empty();
        org.jsoup.nodes.Element element10 = element8.addClass("hi!");
        int int11 = element8.siblingIndex;
        org.jsoup.nodes.Element element14 = element8.attr("hi!", "hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element16 = element8.val("#declaration");
        java.util.List<org.jsoup.nodes.Node> nodeList17 = element16.childNodes();
        org.jsoup.nodes.Element element19 = element16.prependElement("\n<head class=\"hi!&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt; #document &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; data- &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>");
        org.jsoup.nodes.Element element21 = element19.append("                                                                                                    ");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(attributes7);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(nodeList17);
        org.junit.Assert.assertNotNull(element19);
        org.junit.Assert.assertNotNull(element21);
    }

    @Test
    public void test2614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2614");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("#root");
        boolean boolean3 = document1.hasAttr("#text");
        java.lang.String str4 = document1.nodeName();
        java.lang.String str5 = document1.tagName();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element7 = document1.createElement(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: String must not be empty");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "#document" + "'", str4, "#document");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "#root" + "'", str5, "#root");
    }

    @Test
    public void test2615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2615");
        org.jsoup.nodes.Evaluator.IndexLessThan indexLessThan1 = new org.jsoup.nodes.Evaluator.IndexLessThan((-1));
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList5 = document4.childNodes();
        org.jsoup.select.Elements elements6 = document4.getAllElements();
        org.jsoup.select.Elements elements7 = org.jsoup.select.Collector.collect((org.jsoup.nodes.Evaluator) indexLessThan1, (org.jsoup.nodes.Element) document4);
        org.jsoup.nodes.Document document10 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element12 = document10.addClass("");
        org.jsoup.nodes.Element element14 = element12.prependElement("hi!");
        org.jsoup.nodes.Document document17 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str18 = document17.val();
        element12.setParentNode((org.jsoup.nodes.Node) document17);
        org.jsoup.nodes.Document.OutputSettings outputSettings20 = document17.new OutputSettings();
        org.jsoup.nodes.Element element22 = document17.text("\n<head class=\"hi!&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt; #document &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt; data- &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>");
        org.jsoup.select.Elements elements23 = document17.parents();
        org.jsoup.select.Elements elements24 = org.jsoup.select.Collector.collect((org.jsoup.nodes.Evaluator) indexLessThan1, (org.jsoup.nodes.Element) document17);
        org.jsoup.select.Elements elements26 = elements24.wrap("<html>\n <head></head>\n <body>\n  ");
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(nodeList5);
        org.junit.Assert.assertNotNull(elements6);
        org.junit.Assert.assertNotNull(elements7);
        org.junit.Assert.assertNotNull(document10);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertNotNull(document17);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNotNull(element22);
        org.junit.Assert.assertNotNull(elements23);
        org.junit.Assert.assertNotNull(elements24);
        org.junit.Assert.assertNotNull(elements26);
    }

    @Test
    public void test2616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2616");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.title();
        org.jsoup.nodes.Node node5 = document2.removeAttr("#document");
        org.jsoup.nodes.Document document6 = document2.normalise();
        org.jsoup.nodes.Node node7 = document6.parentNode;
        org.jsoup.nodes.Element element9 = document6.append("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        boolean boolean11 = document6.hasAttr("document");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(document6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(element9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test2617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2617");
        org.jsoup.parser.Tag tag1 = org.jsoup.parser.Tag.valueOf("hi!");
        boolean boolean2 = tag1.preserveWhitespace();
        boolean boolean3 = tag1.isKnownTag();
        boolean boolean4 = tag1.preserveWhitespace();
        org.jsoup.nodes.Document document8 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element10 = document8.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element12 = document8.html("");
        org.jsoup.nodes.Attributes attributes13 = document8.attributes();
        java.util.Map<java.lang.String, java.lang.String> strMap14 = attributes13.dataset();
        org.jsoup.nodes.Element element15 = new org.jsoup.nodes.Element(tag1, "#declaration", attributes13);
        java.lang.StringBuilder stringBuilder16 = null;
        org.jsoup.nodes.Document document19 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element21 = document19.addClass("");
        org.jsoup.nodes.Element element23 = element21.prependElement("hi!");
        org.jsoup.nodes.Document document26 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str27 = document26.val();
        element21.setParentNode((org.jsoup.nodes.Node) document26);
        org.jsoup.nodes.Document.OutputSettings outputSettings29 = document26.new OutputSettings();
        boolean boolean30 = outputSettings29.prettyPrint();
        attributes13.html(stringBuilder16, outputSettings29);
        java.util.List<org.jsoup.nodes.Attribute> attributeList32 = attributes13.asList();
        java.util.Map<java.lang.String, java.lang.String> strMap33 = attributes13.dataset();
        org.junit.Assert.assertNotNull(tag1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(document8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(attributes13);
        org.junit.Assert.assertNotNull(strMap14);
        org.junit.Assert.assertNotNull(document19);
        org.junit.Assert.assertNotNull(element21);
        org.junit.Assert.assertNotNull(element23);
        org.junit.Assert.assertNotNull(document26);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "" + "'", str27, "");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(attributeList32);
        org.junit.Assert.assertNotNull(strMap33);
    }

    @Test
    public void test2618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2618");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("\n<body></body>", "<html>\n <head></head>\n <body>\n  #data\n </body>\n</html>");
        java.util.List<org.jsoup.nodes.Node> nodeList3 = document2.childNodes();
        org.jsoup.nodes.TextNode textNode6 = org.jsoup.nodes.TextNode.createFromEncoded("hi!", "hi!");
        org.jsoup.nodes.Node node9 = textNode6.attr("hi!", "hi!");
        org.jsoup.nodes.Node node12 = textNode6.attr("data-", "<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Attributes attributes13 = textNode6.attributes();
        textNode6.text = "hi!";
        java.lang.String str17 = textNode6.attr("<html> <head></head> <body></body> </html>");
        org.jsoup.nodes.Attributes attributes18 = textNode6.attributes();
        document2.attributes = attributes18;
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(nodeList3);
        org.junit.Assert.assertNotNull(textNode6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(attributes13);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertNotNull(attributes18);
    }

    @Test
    public void test2619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2619");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.val();
        java.lang.String str5 = document2.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements8 = document2.getElementsByAttributeValue("hi!", "hi!");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str12 = document11.val();
        java.lang.String str14 = document11.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements17 = document11.getElementsByAttributeValue("hi!", "hi!");
        int int18 = elements17.size();
        java.lang.String str20 = elements17.attr("hi!");
        boolean boolean21 = elements8.contains((java.lang.Object) elements17);
        boolean boolean23 = elements8.hasClass(" text=&quot;hi!&quot; hi!=&quot;hi!&quot; hi!&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;=&quot;&quot;");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNotNull(elements17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test2620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2620");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.nodes.Element element8 = element6.val("#data");
        org.jsoup.nodes.Element element10 = element6.appendElement("&amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
    }

    @Test
    public void test2621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2621");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        java.lang.String str7 = element6.ownText();
        org.jsoup.select.Elements elements9 = element6.getElementsByIndexLessThan(0);
        org.jsoup.parser.Tag tag10 = element6.tag();
        org.jsoup.select.Elements elements12 = element6.getElementsByClass("hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements14 = element6.getElementsByTag("<html>\n <head></head>\n <body></body>\n</html>=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        org.jsoup.nodes.Element element16 = element6.html("hi!\n<html>  \n</html> \n<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(elements9);
        org.junit.Assert.assertNotNull(tag10);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertNotNull(elements14);
        org.junit.Assert.assertNotNull(element16);
    }

    @Test
    public void test2622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2622");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element6 = document2.addClass("");
        java.lang.String str7 = element6.id();
        org.jsoup.select.Elements elements10 = element6.getElementsByAttributeValueStarting("body", "body");
        org.jsoup.nodes.Document document13 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element15 = document13.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element17 = document13.addClass("");
        org.jsoup.select.Elements elements19 = document13.getElementsContainingText("#document");
        org.jsoup.nodes.Document document22 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str23 = document22.val();
        java.lang.String str25 = document22.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements28 = document22.getElementsByAttributeValue("hi!", "hi!");
        int int29 = elements28.size();
        java.lang.String str31 = elements28.attr("hi!");
        boolean boolean32 = elements19.removeAll((java.util.Collection<org.jsoup.nodes.Element>) elements28);
        org.jsoup.select.Elements elements33 = elements19.empty();
        org.jsoup.nodes.Document document36 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList37 = document36.childNodes();
        org.jsoup.select.Elements elements38 = document36.getAllElements();
        boolean boolean40 = elements38.hasClass("#document");
        boolean boolean41 = elements19.addAll((java.util.Collection<org.jsoup.nodes.Element>) elements38);
        boolean boolean42 = elements10.removeAll((java.util.Collection<org.jsoup.nodes.Element>) elements19);
        boolean boolean43 = elements19.isEmpty();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(elements10);
        org.junit.Assert.assertNotNull(document13);
        org.junit.Assert.assertNotNull(element15);
        org.junit.Assert.assertNotNull(element17);
        org.junit.Assert.assertNotNull(elements19);
        org.junit.Assert.assertNotNull(document22);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "" + "'", str25, "");
        org.junit.Assert.assertNotNull(elements28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "" + "'", str31, "");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(elements33);
        org.junit.Assert.assertNotNull(document36);
        org.junit.Assert.assertNotNull(nodeList37);
        org.junit.Assert.assertNotNull(elements38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test2623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2623");
        org.jsoup.safety.Whitelist whitelist1 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = org.jsoup.Jsoup.clean(" <html>\n <head></head>\n <body>\n  &lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n </body>\n</html>", whitelist1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }

    @Test
    public void test2624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2624");
        java.util.regex.Pattern pattern0 = null;
        org.jsoup.nodes.Evaluator.MatchesOwn matchesOwn1 = new org.jsoup.nodes.Evaluator.MatchesOwn(pattern0);
        org.jsoup.nodes.Document document4 = org.jsoup.parser.Parser.parseBodyFragmentRelaxed(" <html>\n <head></head>\n <body></body>\n</html>#document", "head=\"#comment\"");
        org.jsoup.select.Elements elements7 = document4.getElementsByAttributeValueEnding("&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;", "<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n\n<body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n hi! \n</body>");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean8 = matchesOwn1.matches((org.jsoup.nodes.Element) document4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(document4);
        org.junit.Assert.assertNotNull(elements7);
    }

    @Test
    public void test2625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2625");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        org.jsoup.nodes.Element element8 = element6.val("#data");
        org.jsoup.select.Elements elements10 = element6.getElementsByIndexEquals(3);
        org.jsoup.select.Elements elements13 = elements10.attr("", " text=\"hi!\" hi!=\"hi!\" data-=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(elements10);
        org.junit.Assert.assertNotNull(elements13);
    }

    @Test
    public void test2626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2626");
        java.util.regex.Pattern pattern1 = null;
        org.jsoup.nodes.Evaluator.AttributeWithValueMatching attributeWithValueMatching2 = new org.jsoup.nodes.Evaluator.AttributeWithValueMatching("#root", pattern1);
        java.util.regex.Pattern pattern3 = null;
        attributeWithValueMatching2.pattern = pattern3;
        attributeWithValueMatching2.key = " <html>\n <head></head>\n <body></body>\n</html>";
        java.util.regex.Pattern pattern7 = null;
        attributeWithValueMatching2.pattern = pattern7;
        org.jsoup.nodes.Document document11 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element13 = document11.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element16 = document11.attr("hi!", "");
        boolean boolean17 = attributeWithValueMatching2.matches((org.jsoup.nodes.Element) document11);
        org.jsoup.nodes.Document document20 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element22 = document20.addClass("");
        org.jsoup.nodes.Element element24 = document20.val("hi!");
        java.lang.String str25 = document20.html();
        org.jsoup.nodes.Document document26 = document20.ownerDocument();
        org.jsoup.nodes.Element element27 = document26.body();
        org.jsoup.select.Elements elements29 = document26.getElementsMatchingText(" &lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;\n  &amp;lt;html&amp;gt; &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt; &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt; &amp;lt;/html&amp;gt;\n &lt;/body&gt;\n&lt;/html&gt;");
        org.jsoup.select.Elements elements31 = elements29.html("<html>\n <head></head>\n <body>\n  #text\n </body>\n</html>");
        org.jsoup.nodes.Document document34 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str35 = document34.title();
        org.jsoup.nodes.Node node37 = document34.removeAttr("#document");
        org.jsoup.nodes.Document document38 = document34.normalise();
        org.jsoup.nodes.Node node39 = document38.parentNode;
        org.jsoup.nodes.Element element41 = document38.append("&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.jsoup.nodes.Element element43 = document38.text("<html>\n <head></head>\n <body>\n  #data\n </body>\n</html>");
        boolean boolean44 = elements29.contains((java.lang.Object) element43);
        boolean boolean45 = attributeWithValueMatching2.matches(element43);
        java.lang.String str46 = attributeWithValueMatching2.key;
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(document20);
        org.junit.Assert.assertNotNull(element22);
        org.junit.Assert.assertNotNull(element24);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>" + "'", str25, "<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(document26);
        org.junit.Assert.assertNotNull(element27);
        org.junit.Assert.assertNotNull(elements29);
        org.junit.Assert.assertNotNull(elements31);
        org.junit.Assert.assertNotNull(document34);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "" + "'", str35, "");
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(document38);
        org.junit.Assert.assertNull(node39);
        org.junit.Assert.assertNotNull(element41);
        org.junit.Assert.assertNotNull(element43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + " <html>\n <head></head>\n <body></body>\n</html>" + "'", str46, " <html>\n <head></head>\n <body></body>\n</html>");
    }

    @Test
    public void test2627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2627");
        org.jsoup.parser.Tag tag1 = org.jsoup.parser.Tag.valueOf("hi!");
        boolean boolean2 = tag1.preserveWhitespace();
        boolean boolean3 = tag1.isKnownTag();
        boolean boolean4 = tag1.preserveWhitespace();
        org.jsoup.nodes.Document document8 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element10 = document8.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element12 = document8.html("");
        org.jsoup.nodes.Attributes attributes13 = document8.attributes();
        java.util.Map<java.lang.String, java.lang.String> strMap14 = attributes13.dataset();
        org.jsoup.nodes.Element element15 = new org.jsoup.nodes.Element(tag1, "#declaration", attributes13);
        java.lang.String str16 = element15.nodeName();
        org.jsoup.nodes.Element element18 = element15.text(" #");
        org.junit.Assert.assertNotNull(tag1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(document8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(attributes13);
        org.junit.Assert.assertNotNull(strMap14);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "hi!" + "'", str16, "hi!");
        org.junit.Assert.assertNotNull(element18);
    }

    @Test
    public void test2628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2628");
        org.jsoup.nodes.DataNode dataNode2 = org.jsoup.nodes.DataNode.createFromEncoded("", "#text");
        java.lang.String str3 = dataNode2.nodeName();
        org.jsoup.nodes.Document document6 = org.jsoup.Jsoup.parse("hi!", "");
        java.util.List<org.jsoup.nodes.Node> nodeList7 = document6.childNodes();
        org.jsoup.select.Elements elements8 = document6.getAllElements();
        boolean boolean10 = elements8.hasClass("#document");
        org.jsoup.select.Elements elements12 = elements8.addClass("");
        boolean boolean13 = dataNode2.equals((java.lang.Object) elements12);
        org.jsoup.nodes.Evaluator.ContainsText containsText15 = new org.jsoup.nodes.Evaluator.ContainsText("hi!");
        org.jsoup.nodes.Document document18 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element20 = document18.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements22 = element20.getElementsByAttribute("hi!");
        org.jsoup.select.Elements elements24 = element20.getElementsMatchingText("<html>\n <head></head>\n <body></body>\n</html>");
        boolean boolean25 = containsText15.matches(element20);
        boolean boolean26 = element20.isBlock();
        dataNode2.setParentNode((org.jsoup.nodes.Node) element20);
        java.util.List<org.jsoup.nodes.Node> nodeList28 = dataNode2.siblingNodes();
        java.lang.String str29 = dataNode2.nodeName();
        int int30 = dataNode2.siblingIndex;
        org.junit.Assert.assertNotNull(dataNode2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "#data" + "'", str3, "#data");
        org.junit.Assert.assertNotNull(document6);
        org.junit.Assert.assertNotNull(nodeList7);
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(document18);
        org.junit.Assert.assertNotNull(element20);
        org.junit.Assert.assertNotNull(elements22);
        org.junit.Assert.assertNotNull(elements24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeList28);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "#data" + "'", str29, "#data");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test2629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2629");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str3 = document2.title();
        org.jsoup.nodes.Node node5 = document2.removeAttr("#document");
        org.jsoup.nodes.Document document6 = document2.normalise();
        org.jsoup.nodes.Node node7 = document6.parentNode;
        java.lang.String str8 = document6.nodeName();
        org.jsoup.select.Elements elements10 = document6.getElementsByClass("<body></body>");
        org.jsoup.select.Elements elements12 = elements10.addClass("data-");
        java.util.ListIterator<org.jsoup.nodes.Element> elementItor14 = elements12.listIterator((int) (short) 0);
        java.lang.String str15 = elements12.outerHtml();
        org.jsoup.nodes.Document document19 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element21 = document19.addClass("");
        org.jsoup.nodes.Element element23 = document19.val("hi!");
        org.jsoup.nodes.Attributes attributes24 = element23.attributes;
        org.jsoup.nodes.Element element25 = element23.empty();
        org.jsoup.nodes.Element element27 = element25.addClass("hi!");
        int int28 = element25.siblingIndex;
        org.jsoup.nodes.Element element31 = element25.attr("hi!", "hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element33 = element25.val("#declaration");
        org.jsoup.nodes.Attributes attributes34 = new org.jsoup.nodes.Attributes();
        java.util.Iterator<org.jsoup.nodes.Attribute> attributeItor35 = attributes34.iterator();
        java.lang.StringBuilder stringBuilder36 = null;
        org.jsoup.nodes.Document document40 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element42 = document40.addClass("");
        org.jsoup.nodes.Element element44 = element42.prependElement("hi!");
        org.jsoup.nodes.Document document47 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str48 = document47.val();
        element42.setParentNode((org.jsoup.nodes.Node) document47);
        org.jsoup.nodes.Document.OutputSettings outputSettings50 = document47.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings52 = outputSettings50.prettyPrint(false);
        org.jsoup.nodes.Document.OutputSettings outputSettings54 = outputSettings50.indentAmount((int) (short) 10);
        java.lang.String str55 = org.jsoup.nodes.Entities.escape("<html>\n <head></head>\n <body></body>\n</html>", outputSettings54);
        attributes34.html(stringBuilder36, outputSettings54);
        org.jsoup.nodes.Document document59 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str60 = document59.val();
        java.lang.String str62 = document59.attr("<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.String str64 = document59.attr("#document");
        boolean boolean65 = attributes34.equals((java.lang.Object) document59);
        boolean boolean66 = element25.equals((java.lang.Object) document59);
        boolean boolean67 = document59.isBlock();
        org.jsoup.nodes.Attributes attributes68 = null;
        document59.attributes = attributes68;
        org.jsoup.nodes.Element element70 = document59.head();
        org.jsoup.nodes.Element element72 = element70.appendElement("<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n\n<body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n hi! \n</body>");
        elements12.add(0, element70);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(document6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "#document" + "'", str8, "#document");
        org.junit.Assert.assertNotNull(elements10);
        org.junit.Assert.assertNotNull(elements12);
        org.junit.Assert.assertNotNull(elementItor14);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "" + "'", str15, "");
        org.junit.Assert.assertNotNull(document19);
        org.junit.Assert.assertNotNull(element21);
        org.junit.Assert.assertNotNull(element23);
        org.junit.Assert.assertNotNull(attributes24);
        org.junit.Assert.assertNotNull(element25);
        org.junit.Assert.assertNotNull(element27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(element31);
        org.junit.Assert.assertNotNull(element33);
        org.junit.Assert.assertNotNull(attributeItor35);
        org.junit.Assert.assertNotNull(document40);
        org.junit.Assert.assertNotNull(element42);
        org.junit.Assert.assertNotNull(element44);
        org.junit.Assert.assertNotNull(document47);
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "" + "'", str48, "");
        org.junit.Assert.assertNotNull(outputSettings52);
        org.junit.Assert.assertNotNull(outputSettings54);
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;" + "'", str55, "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.junit.Assert.assertNotNull(document59);
        org.junit.Assert.assertEquals("'" + str60 + "' != '" + "" + "'", str60, "");
        org.junit.Assert.assertEquals("'" + str62 + "' != '" + "" + "'", str62, "");
        org.junit.Assert.assertEquals("'" + str64 + "' != '" + "" + "'", str64, "");
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(element70);
        org.junit.Assert.assertNotNull(element72);
    }

    @Test
    public void test2630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2630");
        org.jsoup.nodes.Document document1 = new org.jsoup.nodes.Document("hi!");
        java.lang.String str2 = document1.data();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
    }

    @Test
    public void test2631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2631");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements4 = document1.getElementsByAttributeValueContaining("#document", "#document");
        document1.setBaseUri("                                                                                                    ");
        java.lang.String str7 = document1.ownText();
        org.junit.Assert.assertNotNull(document1);
        org.junit.Assert.assertNotNull(elements4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
    }

    @Test
    public void test2632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2632");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        java.lang.Integer int7 = document2.elementSiblingIndex();
        org.jsoup.select.Elements elements9 = document2.getElementsByAttribute("<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.String str11 = elements9.attr("#document");
        java.util.Iterator<org.jsoup.nodes.Element> elementItor12 = elements9.iterator();
        org.jsoup.nodes.Evaluator.AttributeWithValueContaining attributeWithValueContaining15 = new org.jsoup.nodes.Evaluator.AttributeWithValueContaining("<html>\n <head></head>\n <body></body>\n</html>=\"#data\"", "                                                                                                    ");
        org.jsoup.nodes.Evaluator.AttributeWithValueContaining attributeWithValueContaining18 = new org.jsoup.nodes.Evaluator.AttributeWithValueContaining("#text", "hi!");
        org.jsoup.nodes.Document document21 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element23 = document21.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element25 = document21.addClass("");
        org.jsoup.select.Elements elements27 = element25.getElementsMatchingOwnText("#data");
        boolean boolean28 = attributeWithValueContaining18.matches(element25);
        org.jsoup.nodes.Evaluator.AttributeWithValueContaining[] attributeWithValueContainingArray29 = new org.jsoup.nodes.Evaluator.AttributeWithValueContaining[] { attributeWithValueContaining15, attributeWithValueContaining18 };
        org.jsoup.nodes.Evaluator.AttributeWithValueContaining[] attributeWithValueContainingArray30 = elements9.toArray(attributeWithValueContainingArray29);
        org.jsoup.nodes.Document document33 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element35 = document33.addClass("");
        org.jsoup.nodes.Element element37 = document33.val("hi!");
        java.lang.String str38 = document33.html();
        org.jsoup.nodes.Document document39 = document33.ownerDocument();
        boolean boolean41 = document39.equals((java.lang.Object) '\n');
        java.lang.String str42 = document39.nodeName();
        org.jsoup.nodes.Element[] elementArray43 = new org.jsoup.nodes.Element[] { document39 };
        org.jsoup.nodes.Element[] elementArray44 = elements9.toArray(elementArray43);
        org.jsoup.select.Elements elements46 = elements9.removeClass("<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<html <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n <head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n <body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n  hi! \n </body>\n</html>\n\n<head <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\"></head>\n\n<body <hi!></hi!>\n\n<html>\n <head></head>\n <body></body>\n</html>=\"#text&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\">\n hi! \n</body>");
        org.jsoup.select.Elements elements48 = elements9.removeClass("<html>\n <head></head>\n <body></body>\n</html>&lt;html&gt; &lt;head&gt;&lt;/head&gt; &lt;body&gt;&lt;/body&gt; &lt;/html&gt;\n<head></head>\n<body></body>\n\n");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(elements9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "" + "'", str11, "");
        org.junit.Assert.assertNotNull(elementItor12);
        org.junit.Assert.assertNotNull(document21);
        org.junit.Assert.assertNotNull(element23);
        org.junit.Assert.assertNotNull(element25);
        org.junit.Assert.assertNotNull(elements27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(attributeWithValueContainingArray29);
        org.junit.Assert.assertNotNull(attributeWithValueContainingArray30);
        org.junit.Assert.assertNotNull(document33);
        org.junit.Assert.assertNotNull(element35);
        org.junit.Assert.assertNotNull(element37);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>" + "'", str38, "<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(document39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "#document" + "'", str42, "#document");
        org.junit.Assert.assertNotNull(elementArray43);
        org.junit.Assert.assertArrayEquals(elementArray43, new org.jsoup.nodes.Element[] { null });
        org.junit.Assert.assertNotNull(elementArray44);
        org.junit.Assert.assertArrayEquals(elementArray44, new org.jsoup.nodes.Element[] { null });
        org.junit.Assert.assertNotNull(elements46);
        org.junit.Assert.assertNotNull(elements48);
    }

    @Test
    public void test2633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2633");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = document2.val("hi!");
        java.lang.String str7 = element6.ownText();
        org.jsoup.select.Elements elements9 = element6.getElementsByIndexLessThan(0);
        org.jsoup.parser.Tag tag10 = element6.tag();
        org.jsoup.nodes.Element element12 = element6.prependText("hi!<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements14 = element6.getElementsByAttribute(" text=\"hi!\" hi!=\"hi!\" data-=\"&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;\" #text=\"\"");
        org.jsoup.select.Elements elements16 = elements14.append("hi<html>\n <head></head>\n <body></body>\n</html>");
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "" + "'", str7, "");
        org.junit.Assert.assertNotNull(elements9);
        org.junit.Assert.assertNotNull(tag10);
        org.junit.Assert.assertNotNull(element12);
        org.junit.Assert.assertNotNull(elements14);
        org.junit.Assert.assertNotNull(elements16);
    }

    @Test
    public void test2634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2634");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element4 = document2.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element6 = document2.addClass("");
        org.jsoup.select.Elements elements8 = document2.getElementsContainingText("#document");
        org.jsoup.nodes.Document document11 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str12 = document11.val();
        java.lang.String str14 = document11.attr("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements17 = document11.getElementsByAttributeValue("hi!", "hi!");
        int int18 = elements17.size();
        java.lang.String str20 = elements17.attr("hi!");
        boolean boolean21 = elements8.removeAll((java.util.Collection<org.jsoup.nodes.Element>) elements17);
        org.jsoup.nodes.Document document24 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element26 = document24.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element28 = document24.html("");
        java.util.regex.Pattern pattern30 = null;
        org.jsoup.select.Elements elements31 = document24.getElementsByAttributeValueMatching("", pattern30);
        org.jsoup.select.Elements elements33 = elements31.after("");
        org.jsoup.select.Elements elements34 = new org.jsoup.select.Elements((java.util.List<org.jsoup.nodes.Element>) elements33);
        boolean boolean35 = elements17.containsAll((java.util.Collection<org.jsoup.nodes.Element>) elements33);
        org.jsoup.select.Elements elements36 = new org.jsoup.select.Elements((java.util.Collection<org.jsoup.nodes.Element>) elements33);
        java.lang.String str37 = elements33.val();
        boolean boolean38 = elements33.hasText();
        java.util.ListIterator<org.jsoup.nodes.Element> elementItor40 = elements33.listIterator(0);
        org.jsoup.select.Elements elements41 = new org.jsoup.select.Elements((java.util.Collection<org.jsoup.nodes.Element>) elements33);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(elements8);
        org.junit.Assert.assertNotNull(document11);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "" + "'", str14, "");
        org.junit.Assert.assertNotNull(elements17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(document24);
        org.junit.Assert.assertNotNull(element26);
        org.junit.Assert.assertNotNull(element28);
        org.junit.Assert.assertNotNull(elements31);
        org.junit.Assert.assertNotNull(elements33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(elementItor40);
    }

    @Test
    public void test2635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2635");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        org.jsoup.nodes.Document.OutputSettings outputSettings12 = document9.outputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings14 = outputSettings12.indentAmount((int) '4');
        boolean boolean15 = outputSettings12.prettyPrint();
        org.jsoup.nodes.Entities.EscapeMode escapeMode16 = outputSettings12.escapeMode();
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(outputSettings12);
        org.junit.Assert.assertNotNull(outputSettings14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + escapeMode16 + "' != '" + org.jsoup.nodes.Entities.EscapeMode.base + "'", escapeMode16.equals(org.jsoup.nodes.Entities.EscapeMode.base));
    }

    @Test
    public void test2636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2636");
        org.jsoup.nodes.Evaluator.Id id1 = new org.jsoup.nodes.Evaluator.Id("#document");
        org.jsoup.nodes.Document document3 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Document document6 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element8 = document6.text("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element10 = document6.addClass("");
        document3.setParentNode((org.jsoup.nodes.Node) document6);
        org.jsoup.nodes.Element element14 = document6.attr("hi!", "");
        boolean boolean15 = id1.matches((org.jsoup.nodes.Element) document6);
        org.jsoup.nodes.Element element17 = document6.appendText("");
        org.jsoup.nodes.Attributes attributes18 = new org.jsoup.nodes.Attributes();
        java.util.Iterator<org.jsoup.nodes.Attribute> attributeItor19 = attributes18.iterator();
        java.lang.StringBuilder stringBuilder20 = null;
        org.jsoup.nodes.Document document24 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element26 = document24.addClass("");
        org.jsoup.nodes.Element element28 = element26.prependElement("hi!");
        org.jsoup.nodes.Document document31 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str32 = document31.val();
        element26.setParentNode((org.jsoup.nodes.Node) document31);
        org.jsoup.nodes.Document.OutputSettings outputSettings34 = document31.new OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings36 = outputSettings34.prettyPrint(false);
        org.jsoup.nodes.Document.OutputSettings outputSettings38 = outputSettings34.indentAmount((int) (short) 10);
        java.lang.String str39 = org.jsoup.nodes.Entities.escape("<html>\n <head></head>\n <body></body>\n</html>", outputSettings38);
        attributes18.html(stringBuilder20, outputSettings38);
        org.jsoup.nodes.Document document43 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str44 = document43.val();
        java.lang.String str46 = document43.attr("<html>\n <head></head>\n <body></body>\n</html>");
        java.lang.String str48 = document43.attr("#document");
        boolean boolean49 = attributes18.equals((java.lang.Object) document43);
        element17.attributes = attributes18;
        int int51 = attributes18.size();
        org.junit.Assert.assertNotNull(document3);
        org.junit.Assert.assertNotNull(document6);
        org.junit.Assert.assertNotNull(element8);
        org.junit.Assert.assertNotNull(element10);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(element17);
        org.junit.Assert.assertNotNull(attributeItor19);
        org.junit.Assert.assertNotNull(document24);
        org.junit.Assert.assertNotNull(element26);
        org.junit.Assert.assertNotNull(element28);
        org.junit.Assert.assertNotNull(document31);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "" + "'", str32, "");
        org.junit.Assert.assertNotNull(outputSettings36);
        org.junit.Assert.assertNotNull(outputSettings38);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;" + "'", str39, "&lt;html&gt;\n &lt;head&gt;&lt;/head&gt;\n &lt;body&gt;&lt;/body&gt;\n&lt;/html&gt;");
        org.junit.Assert.assertNotNull(document43);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "" + "'", str46, "");
        org.junit.Assert.assertEquals("'" + str48 + "' != '" + "" + "'", str48, "");
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test2637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test2637");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("", "");
        org.jsoup.nodes.Element element4 = document2.addClass("");
        org.jsoup.nodes.Element element6 = element4.prependElement("hi!");
        org.jsoup.nodes.Document document9 = org.jsoup.parser.Parser.parse("", "");
        java.lang.String str10 = document9.val();
        element4.setParentNode((org.jsoup.nodes.Node) document9);
        org.jsoup.nodes.Element element13 = document9.toggleClass("<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.nodes.Element element14 = document9.body();
        org.jsoup.nodes.Element element16 = element14.after("");
        org.jsoup.select.Elements elements19 = element14.getElementsByAttributeValue("<html>\n <head></head>\n <body></body>\n</html>", "<html>\n <head></head>\n <body></body>\n</html>");
        org.jsoup.select.Elements elements21 = elements19.toggleClass("");
        java.lang.Object[] objArray22 = elements19.toArray();
        boolean boolean24 = elements19.hasClass("&amp;lt;html&amp;gt;\n &amp;lt;head&amp;gt;&amp;lt;/head&amp;gt;\n &amp;lt;body&amp;gt;&amp;lt;/body&amp;gt;\n&amp;lt;/html&amp;gt;");
        org.jsoup.select.Elements elements25 = new org.jsoup.select.Elements((java.util.List<org.jsoup.nodes.Element>) elements19);
        org.junit.Assert.assertNotNull(document2);
        org.junit.Assert.assertNotNull(element4);
        org.junit.Assert.assertNotNull(element6);
        org.junit.Assert.assertNotNull(document9);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "" + "'", str10, "");
        org.junit.Assert.assertNotNull(element13);
        org.junit.Assert.assertNotNull(element14);
        org.junit.Assert.assertNotNull(element16);
        org.junit.Assert.assertNotNull(elements19);
        org.junit.Assert.assertNotNull(elements21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertArrayEquals(objArray22, new java.lang.Object[] {});
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }
}

