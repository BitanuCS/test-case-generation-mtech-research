package org.apache.commons.lang3.text;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test1501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1501");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] stringMatcherArray2 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] stringMatcherArray3 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][][] stringMatcherArray4 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][][] { stringMatcherArray2, stringMatcherArray3 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][][] stringMatcherArray5 = org.apache.commons.lang3.Validate.noNullElements(stringMatcherArray4);
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] stringMatcherArray6 = org.apache.commons.lang3.ObjectUtils.firstNonNull(stringMatcherArray4);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.lang3.Validate.isTrue(false, "", (java.lang.Object[]) stringMatcherArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(stringMatcherArray2);
        org.junit.Assert.assertNotNull(stringMatcherArray3);
        org.junit.Assert.assertNotNull(stringMatcherArray4);
        org.junit.Assert.assertNotNull(stringMatcherArray5);
        org.junit.Assert.assertNotNull(stringMatcherArray6);
    }

    @Test
    public void test1502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1502");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException5 = new org.apache.commons.lang3.exception.CloneFailedException("hi!");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException6 = new org.apache.commons.lang3.exception.CloneFailedException("10", (java.lang.Throwable) cloneFailedException5);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException7 = new org.apache.commons.lang3.exception.CloneFailedException("", (java.lang.Throwable) cloneFailedException6);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException10 = new org.apache.commons.lang3.exception.CloneFailedException("hi!");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException11 = new org.apache.commons.lang3.exception.CloneFailedException("10", (java.lang.Throwable) cloneFailedException10);
        java.util.Locale locale13 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat14 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale13);
        java.text.Format format15 = org.apache.commons.lang3.ObjectUtils.clone((java.text.Format) extendedMessageFormat14);
        boolean boolean16 = org.apache.commons.lang3.ObjectUtils.notEqual((java.lang.Object) cloneFailedException10, (java.lang.Object) format15);
        cloneFailedException7.addSuppressed((java.lang.Throwable) cloneFailedException10);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException18 = new org.apache.commons.lang3.exception.CloneFailedException("55", (java.lang.Throwable) cloneFailedException7);
        java.lang.Throwable throwable19 = org.apache.commons.lang3.ObjectUtils.cloneIfPossible((java.lang.Throwable) cloneFailedException7);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException20 = new org.apache.commons.lang3.exception.CloneFailedException((java.lang.Throwable) cloneFailedException7);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException21 = new org.apache.commons.lang3.exception.CloneFailedException("", (java.lang.Throwable) cloneFailedException20);
        java.lang.Throwable[] throwableArray22 = cloneFailedException21.getSuppressed();
        org.junit.Assert.assertNotNull(format15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(throwable19);
        org.junit.Assert.assertEquals(throwable19.getLocalizedMessage(), "");
        org.junit.Assert.assertEquals(throwable19.getMessage(), "");
        org.junit.Assert.assertEquals(throwable19.toString(), "org.apache.commons.lang3.exception.CloneFailedException: ");
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertArrayEquals(throwableArray22, new java.lang.Throwable[] {});
    }

    @Test
    public void test1503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1503");
        org.apache.commons.lang3.Validate.inclusiveBetween("", "org.apache.commons.lang3.exception.CloneFailedException: ", (java.lang.Comparable<java.lang.String>) "1");
    }

    @Test
    public void test1504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1504");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale1);
        extendedMessageFormat2.applyPattern("10");
        java.util.Locale locale7 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat8 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale7);
        java.text.Format[] formatArray9 = extendedMessageFormat8.getFormats();
        extendedMessageFormat8.applyPattern("class [[Ljava.lang.String;");
        java.lang.String str12 = extendedMessageFormat8.toPattern();
        java.text.Format[] formatArray13 = extendedMessageFormat8.getFormats();
        java.lang.String str14 = java.text.MessageFormat.format("org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: ", (java.lang.Object[]) formatArray13);
        // The following exception was thrown during execution in test generation
        try {
            extendedMessageFormat2.setFormats(formatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(formatArray9);
        org.junit.Assert.assertArrayEquals(formatArray9, new java.text.Format[] {});
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "class [[Ljava.lang.String;" + "'", str12, "class [[Ljava.lang.String;");
        org.junit.Assert.assertNotNull(formatArray13);
        org.junit.Assert.assertArrayEquals(formatArray13, new java.text.Format[] {});
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: " + "'", str14, "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: ");
    }

    @Test
    public void test1505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1505");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException1 = new org.apache.commons.lang3.exception.CloneFailedException("org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException2 = new org.apache.commons.lang3.exception.CloneFailedException((java.lang.Throwable) cloneFailedException1);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException3 = new org.apache.commons.lang3.exception.CloneFailedException((java.lang.Throwable) cloneFailedException2);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException4 = new org.apache.commons.lang3.exception.CloneFailedException((java.lang.Throwable) cloneFailedException3);
        java.util.Locale locale8 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat9 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale8);
        java.lang.Object[] objArray11 = extendedMessageFormat9.parse("hi!");
        extendedMessageFormat9.applyPattern("10");
        extendedMessageFormat9.applyPattern("55");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat17 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale18 = extendedMessageFormat17.getLocale();
        extendedMessageFormat9.setLocale(locale18);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat20 = new org.apache.commons.lang3.text.ExtendedMessageFormat("-46", locale18);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat21 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale18);
        boolean boolean22 = org.apache.commons.lang3.ObjectUtils.equals((java.lang.Object) cloneFailedException4, (java.lang.Object) extendedMessageFormat21);
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray26 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray27 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray28 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray29 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray30 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray31 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray26, stringMatcherArray27, stringMatcherArray28, stringMatcherArray29, stringMatcherArray30 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray32 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray31);
        java.lang.String str33 = org.apache.commons.lang3.Validate.notEmpty("class [[Ljava.lang.String;", "hi!", (java.lang.Object[]) stringMatcherArray31);
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray36 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray37 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray38 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray39 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray40 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray41 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray36, stringMatcherArray37, stringMatcherArray38, stringMatcherArray39, stringMatcherArray40 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray42 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray41);
        java.lang.String str43 = org.apache.commons.lang3.Validate.notEmpty("class [[Ljava.lang.String;", "hi!", (java.lang.Object[]) stringMatcherArray41);
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray44 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(stringMatcherArray31, stringMatcherArray41);
        java.lang.String str45 = java.text.MessageFormat.format("", (java.lang.Object[]) stringMatcherArray44);
        java.lang.Object[] objArray47 = null;
        java.io.Serializable serializable48 = org.apache.commons.lang3.Validate.notNull((java.io.Serializable) stringMatcherArray44, "0", objArray47);
        boolean boolean49 = extendedMessageFormat21.equals((java.lang.Object) "0");
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertArrayEquals(objArray11, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertEquals(locale18.toString(), "en_US");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stringMatcherArray26);
        org.junit.Assert.assertArrayEquals(stringMatcherArray26, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray27);
        org.junit.Assert.assertArrayEquals(stringMatcherArray27, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray28);
        org.junit.Assert.assertArrayEquals(stringMatcherArray28, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray29);
        org.junit.Assert.assertArrayEquals(stringMatcherArray29, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray30);
        org.junit.Assert.assertArrayEquals(stringMatcherArray30, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray31);
        org.junit.Assert.assertNotNull(stringMatcherArray32);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "class [[Ljava.lang.String;" + "'", str33, "class [[Ljava.lang.String;");
        org.junit.Assert.assertNotNull(stringMatcherArray36);
        org.junit.Assert.assertArrayEquals(stringMatcherArray36, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray37);
        org.junit.Assert.assertArrayEquals(stringMatcherArray37, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray38);
        org.junit.Assert.assertArrayEquals(stringMatcherArray38, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray39);
        org.junit.Assert.assertArrayEquals(stringMatcherArray39, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray40);
        org.junit.Assert.assertArrayEquals(stringMatcherArray40, new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray41);
        org.junit.Assert.assertNotNull(stringMatcherArray42);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "class [[Ljava.lang.String;" + "'", str43, "class [[Ljava.lang.String;");
        org.junit.Assert.assertNotNull(stringMatcherArray44);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "" + "'", str45, "");
        org.junit.Assert.assertNotNull(serializable48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test1506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1506");
        java.lang.CharSequence charSequence1 = org.apache.commons.lang3.Validate.notBlank((java.lang.CharSequence) "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException");
        org.junit.Assert.assertEquals("'" + charSequence1 + "' != '" + "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException" + "'", charSequence1, "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException");
    }

    @Test
    public void test1507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1507");
        java.util.Locale locale2 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat3 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale2);
        extendedMessageFormat3.applyPattern("10");
        java.lang.String str6 = extendedMessageFormat3.toPattern();
        java.util.Locale locale8 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat9 = new org.apache.commons.lang3.text.ExtendedMessageFormat("10", locale8);
        java.util.Locale locale11 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat12 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale11);
        java.lang.String str13 = extendedMessageFormat12.toPattern();
        java.util.Locale locale15 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat16 = new org.apache.commons.lang3.text.ExtendedMessageFormat("10", locale15);
        org.apache.commons.lang3.text.ExtendedMessageFormat[] extendedMessageFormatArray17 = new org.apache.commons.lang3.text.ExtendedMessageFormat[] { extendedMessageFormat3, extendedMessageFormat9, extendedMessageFormat12, extendedMessageFormat16 };
        org.apache.commons.lang3.text.StrMatcher.NoMatcher noMatcher19 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher20 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher21 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher22 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher20, strMatcher21);
        char[] charArray25 = new char[] { '4', 'a' };
        int int29 = strMatcher20.isMatch(charArray25, 0, (int) (byte) 0, (int) (short) 1);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher charSetMatcher30 = new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher(charArray25);
        int int34 = noMatcher19.isMatch(charArray25, 5, (int) '4', (int) (byte) 100);
        org.apache.commons.lang3.text.StrMatcher.NoMatcher[] noMatcherArray35 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher[] { noMatcher19 };
        org.apache.commons.lang3.text.StrMatcher.NoMatcher[] noMatcherArray36 = org.apache.commons.lang3.Validate.noNullElements(noMatcherArray35);
        org.apache.commons.lang3.text.ExtendedMessageFormat[] extendedMessageFormatArray37 = org.apache.commons.lang3.Validate.noNullElements(extendedMessageFormatArray17, "55", (java.lang.Object[]) noMatcherArray35);
        java.text.MessageFormat[] messageFormatArray38 = org.apache.commons.lang3.Validate.notNull((java.text.MessageFormat[]) extendedMessageFormatArray37);
        java.text.Format[] formatArray39 = org.apache.commons.lang3.ObjectUtils.cloneIfPossible((java.text.Format[]) extendedMessageFormatArray37);
        java.lang.String str40 = java.text.MessageFormat.format("hi!", (java.lang.Object[]) extendedMessageFormatArray37);
        java.lang.String[] strArray50 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" };
        java.lang.String str51 = org.apache.commons.lang3.ObjectUtils.min(strArray50);
        java.lang.String str52 = org.apache.commons.lang3.Validate.notBlank("class [[Ljava.lang.String;", "55", (java.lang.Object[]) strArray50);
        org.apache.commons.lang3.text.ExtendedMessageFormat[] extendedMessageFormatArray53 = org.apache.commons.lang3.Validate.notNull(extendedMessageFormatArray37, "class [[Ljava.lang.String;", (java.lang.Object[]) strArray50);
        java.util.Locale locale56 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat57 = new org.apache.commons.lang3.text.ExtendedMessageFormat("10", locale56);
        java.util.Locale locale58 = extendedMessageFormat57.getLocale();
        java.text.Format[] formatArray59 = extendedMessageFormat57.getFormatsByArgumentIndex();
        java.text.MessageFormat[] messageFormatArray60 = org.apache.commons.lang3.Validate.notEmpty((java.text.MessageFormat[]) extendedMessageFormatArray53, "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: ", (java.lang.Object[]) formatArray59);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "10" + "'", str6, "10");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "" + "'", str13, "");
        org.junit.Assert.assertNotNull(extendedMessageFormatArray17);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strMatcher22);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertArrayEquals(charArray25, new char[] { '4', 'a' });
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(noMatcherArray35);
        org.junit.Assert.assertNotNull(noMatcherArray36);
        org.junit.Assert.assertNotNull(extendedMessageFormatArray37);
        org.junit.Assert.assertNotNull(messageFormatArray38);
        org.junit.Assert.assertNotNull(formatArray39);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "hi!" + "'", str40, "hi!");
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertArrayEquals(strArray50, new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" });
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
        org.junit.Assert.assertEquals("'" + str52 + "' != '" + "class [[Ljava.lang.String;" + "'", str52, "class [[Ljava.lang.String;");
        org.junit.Assert.assertNotNull(extendedMessageFormatArray53);
        org.junit.Assert.assertNull(locale58);
        org.junit.Assert.assertNotNull(formatArray59);
        org.junit.Assert.assertArrayEquals(formatArray59, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(messageFormatArray60);
    }

    @Test
    public void test1508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1508");
        java.lang.reflect.Type[][] typeArray0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.reflect.Type[][] typeArray1 = org.apache.commons.lang3.Validate.notEmpty(typeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: The validated array is empty");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test1509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1509");
        java.util.Locale locale2 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat3 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale2);
        java.lang.Object[] objArray5 = extendedMessageFormat3.parse("hi!");
        extendedMessageFormat3.applyPattern("10");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher9 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher11 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher13 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher15 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher17 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray18 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher9, stringMatcher11, stringMatcher13, stringMatcher15, stringMatcher17 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray19 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray18);
        boolean boolean20 = extendedMessageFormat3.equals((java.lang.Object) stringMatcherArray18);
        java.text.Format[] formatArray21 = extendedMessageFormat3.getFormats();
        java.text.Format[] formatArray22 = extendedMessageFormat3.getFormats();
        java.util.Locale locale24 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat25 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale24);
        java.lang.String str26 = extendedMessageFormat25.toPattern();
        java.text.Format[] formatArray27 = extendedMessageFormat25.getFormatsByArgumentIndex();
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat29 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale30 = extendedMessageFormat29.getLocale();
        extendedMessageFormat25.setLocale(locale30);
        extendedMessageFormat3.setLocale(locale30);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat33 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!", locale30);
        java.text.ParsePosition parsePosition35 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj36 = extendedMessageFormat33.parseObject("en_US", parsePosition35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertArrayEquals(objArray5, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray18);
        org.junit.Assert.assertNotNull(stringMatcherArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(formatArray21);
        org.junit.Assert.assertArrayEquals(formatArray21, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(formatArray22);
        org.junit.Assert.assertArrayEquals(formatArray22, new java.text.Format[] {});
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "" + "'", str26, "");
        org.junit.Assert.assertNotNull(formatArray27);
        org.junit.Assert.assertArrayEquals(formatArray27, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertEquals(locale30.toString(), "en_US");
    }

    @Test
    public void test1510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1510");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("10", locale1);
        java.util.Locale locale4 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat5 = new org.apache.commons.lang3.text.ExtendedMessageFormat("55", locale4);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat6 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(extendedMessageFormat2, extendedMessageFormat5);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat7 = org.apache.commons.lang3.ObjectUtils.cloneIfPossible(extendedMessageFormat6);
        java.text.Format[] formatArray8 = extendedMessageFormat6.getFormats();
        org.junit.Assert.assertNotNull(extendedMessageFormat6);
        org.junit.Assert.assertNotNull(extendedMessageFormat7);
        org.junit.Assert.assertNotNull(formatArray8);
        org.junit.Assert.assertArrayEquals(formatArray8, new java.text.Format[] {});
    }

    @Test
    public void test1511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1511");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] stringMatcherArray0 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] stringMatcherArray1 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] {};
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][][] stringMatcherArray2 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][][] { stringMatcherArray0, stringMatcherArray1 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][][] stringMatcherArray3 = org.apache.commons.lang3.Validate.noNullElements(stringMatcherArray2);
        java.lang.String str5 = org.apache.commons.lang3.ObjectUtils.toString((java.lang.Object) stringMatcherArray3, "class [Ljava.lang.Object;");
        org.junit.Assert.assertNotNull(stringMatcherArray0);
        org.junit.Assert.assertNotNull(stringMatcherArray1);
        org.junit.Assert.assertNotNull(stringMatcherArray2);
        org.junit.Assert.assertNotNull(stringMatcherArray3);
    }

    @Test
    public void test1512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1512");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException3 = new org.apache.commons.lang3.exception.CloneFailedException("hi!");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException4 = new org.apache.commons.lang3.exception.CloneFailedException("10", (java.lang.Throwable) cloneFailedException3);
        java.util.Locale locale6 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat7 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale6);
        java.text.Format format8 = org.apache.commons.lang3.ObjectUtils.clone((java.text.Format) extendedMessageFormat7);
        boolean boolean9 = org.apache.commons.lang3.ObjectUtils.notEqual((java.lang.Object) cloneFailedException3, (java.lang.Object) format8);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException10 = new org.apache.commons.lang3.exception.CloneFailedException((java.lang.Throwable) cloneFailedException3);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException11 = new org.apache.commons.lang3.exception.CloneFailedException("hi!", (java.lang.Throwable) cloneFailedException3);
        org.apache.commons.lang3.text.StrMatcher strMatcher13 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher14 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher15 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher13, strMatcher14);
        java.lang.Class<?> wildcardClass16 = strMatcher15.getClass();
        org.apache.commons.lang3.text.StrMatcher.NoMatcher noMatcher20 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher();
        java.lang.Object obj21 = new java.lang.Object();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 100.0d, 100.0d, noMatcher20, obj21, (-1.0f), (short) 1 };
        java.lang.String str25 = java.text.MessageFormat.format("hi!", objArray24);
        java.lang.Class<?> wildcardClass26 = objArray24.getClass();
        org.apache.commons.lang3.text.StrMatcher strMatcher27 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher28 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher29 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher27, strMatcher28);
        java.lang.Class<?> wildcardClass30 = strMatcher29.getClass();
        org.apache.commons.lang3.text.StrMatcher strMatcher31 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher32 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher33 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher31, strMatcher32);
        java.lang.Class<?> wildcardClass34 = strMatcher33.getClass();
        java.lang.String[] strArray40 = new java.lang.String[] { "", "hi!", "10", "10", "10" };
        java.lang.String[] strArray46 = new java.lang.String[] { "", "hi!", "10", "10", "10" };
        java.lang.String[] strArray52 = new java.lang.String[] { "", "hi!", "10", "10", "10" };
        java.lang.String[][] strArray53 = new java.lang.String[][] { strArray40, strArray46, strArray52 };
        java.lang.String[] strArray61 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" };
        java.lang.String str62 = org.apache.commons.lang3.ObjectUtils.min(strArray61);
        java.lang.String[][] strArray63 = org.apache.commons.lang3.Validate.notEmpty(strArray53, "", (java.lang.Object[]) strArray61);
        java.lang.Class<?> wildcardClass64 = strArray53.getClass();
        java.lang.Class<?> wildcardClass65 = org.apache.commons.lang3.ObjectUtils.clone(wildcardClass64);
        org.apache.commons.lang3.text.StrMatcher.NoMatcher noMatcher69 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher();
        java.lang.Object obj70 = new java.lang.Object();
        java.lang.Object[] objArray73 = new java.lang.Object[] { 100.0d, 100.0d, noMatcher69, obj70, (-1.0f), (short) 1 };
        java.lang.String str74 = java.text.MessageFormat.format("hi!", objArray73);
        java.lang.Class<?> wildcardClass75 = objArray73.getClass();
        java.lang.Class[] classArray77 = new java.lang.Class[6];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray78 = (java.lang.Class<?>[]) classArray77;
        wildcardClassArray78[0] = wildcardClass16;
        wildcardClassArray78[1] = wildcardClass26;
        wildcardClassArray78[2] = wildcardClass30;
        wildcardClassArray78[3] = wildcardClass34;
        wildcardClassArray78[4] = wildcardClass65;
        wildcardClassArray78[5] = wildcardClass75;
        java.lang.Class<?> wildcardClass91 = org.apache.commons.lang3.ObjectUtils.firstNonNull(wildcardClassArray78);
        java.lang.Object obj92 = org.apache.commons.lang3.Validate.notNull((java.lang.Object) "hi!", "org.apache.commons.lang3.exception.CloneFailedException: 55", (java.lang.Object[]) wildcardClassArray78);
        org.junit.Assert.assertNotNull(format8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(strMatcher13);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "hi!" + "'", str25, "hi!");
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(strMatcher27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertNotNull(strMatcher32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertArrayEquals(strArray40, new java.lang.String[] { "", "hi!", "10", "10", "10" });
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertArrayEquals(strArray46, new java.lang.String[] { "", "hi!", "10", "10", "10" });
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertArrayEquals(strArray52, new java.lang.String[] { "", "hi!", "10", "10", "10" });
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertArrayEquals(strArray61, new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" });
        org.junit.Assert.assertEquals("'" + str62 + "' != '" + "" + "'", str62, "");
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNull(wildcardClass65);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertEquals("'" + str74 + "' != '" + "hi!" + "'", str74, "hi!");
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(classArray77);
        org.junit.Assert.assertArrayEquals(classArray77, new java.lang.Class[] { org.apache.commons.lang3.text.StrMatcher.TrimMatcher.class, java.lang.Object[].class, org.apache.commons.lang3.text.StrMatcher.TrimMatcher.class, org.apache.commons.lang3.text.StrMatcher.TrimMatcher.class, null, java.lang.Object[].class });
        org.junit.Assert.assertNotNull(wildcardClassArray78);
        org.junit.Assert.assertArrayEquals(wildcardClassArray78, new java.lang.Class[] { org.apache.commons.lang3.text.StrMatcher.TrimMatcher.class, java.lang.Object[].class, org.apache.commons.lang3.text.StrMatcher.TrimMatcher.class, org.apache.commons.lang3.text.StrMatcher.TrimMatcher.class, null, java.lang.Object[].class });
        org.junit.Assert.assertNotNull(wildcardClass91);
        org.junit.Assert.assertEquals("'" + obj92 + "' != '" + "hi!" + "'", obj92, "hi!");
    }

    @Test
    public void test1513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1513");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException2 = new org.apache.commons.lang3.exception.CloneFailedException("hi!", throwable1);
        java.lang.String[] strArray11 = new java.lang.String[] { "", "hi!", "10", "10", "10" };
        java.lang.String[] strArray17 = new java.lang.String[] { "", "hi!", "10", "10", "10" };
        java.lang.String[] strArray23 = new java.lang.String[] { "", "hi!", "10", "10", "10" };
        java.lang.String[][] strArray24 = new java.lang.String[][] { strArray11, strArray17, strArray23 };
        java.lang.String[] strArray32 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" };
        java.lang.String str33 = org.apache.commons.lang3.ObjectUtils.min(strArray32);
        java.lang.String[][] strArray34 = org.apache.commons.lang3.Validate.notEmpty(strArray24, "", (java.lang.Object[]) strArray32);
        org.apache.commons.lang3.Validate.validState(true, "", (java.lang.Object[]) strArray32);
        java.lang.RuntimeException runtimeException36 = org.apache.commons.lang3.Validate.notNull((java.lang.RuntimeException) cloneFailedException2, "org.apache.commons.lang3.exception.CloneFailedException: hi!", (java.lang.Object[]) strArray32);
        java.lang.RuntimeException runtimeException37 = null;
        java.lang.RuntimeException runtimeException38 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(runtimeException36, runtimeException37);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException39 = new org.apache.commons.lang3.exception.CloneFailedException((java.lang.Throwable) runtimeException38);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException45 = new org.apache.commons.lang3.exception.CloneFailedException("hi!");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException46 = new org.apache.commons.lang3.exception.CloneFailedException("10", (java.lang.Throwable) cloneFailedException45);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException47 = new org.apache.commons.lang3.exception.CloneFailedException("", (java.lang.Throwable) cloneFailedException46);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException50 = new org.apache.commons.lang3.exception.CloneFailedException("hi!");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException51 = new org.apache.commons.lang3.exception.CloneFailedException("10", (java.lang.Throwable) cloneFailedException50);
        java.util.Locale locale53 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat54 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale53);
        java.text.Format format55 = org.apache.commons.lang3.ObjectUtils.clone((java.text.Format) extendedMessageFormat54);
        boolean boolean56 = org.apache.commons.lang3.ObjectUtils.notEqual((java.lang.Object) cloneFailedException50, (java.lang.Object) format55);
        cloneFailedException47.addSuppressed((java.lang.Throwable) cloneFailedException50);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException58 = new org.apache.commons.lang3.exception.CloneFailedException("55", (java.lang.Throwable) cloneFailedException47);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException61 = new org.apache.commons.lang3.exception.CloneFailedException("hi!");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException62 = new org.apache.commons.lang3.exception.CloneFailedException("10", (java.lang.Throwable) cloneFailedException61);
        java.util.Locale locale64 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat65 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale64);
        java.text.Format format66 = org.apache.commons.lang3.ObjectUtils.clone((java.text.Format) extendedMessageFormat65);
        boolean boolean67 = org.apache.commons.lang3.ObjectUtils.notEqual((java.lang.Object) cloneFailedException61, (java.lang.Object) format66);
        java.lang.Throwable throwable70 = null;
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException71 = new org.apache.commons.lang3.exception.CloneFailedException("", throwable70);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException72 = new org.apache.commons.lang3.exception.CloneFailedException("hi!", (java.lang.Throwable) cloneFailedException71);
        cloneFailedException61.addSuppressed((java.lang.Throwable) cloneFailedException71);
        cloneFailedException58.addSuppressed((java.lang.Throwable) cloneFailedException71);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException75 = new org.apache.commons.lang3.exception.CloneFailedException("org.apache.commons.lang3.exception.CloneFailedException: ", (java.lang.Throwable) cloneFailedException58);
        cloneFailedException39.addSuppressed((java.lang.Throwable) cloneFailedException58);
        java.lang.Throwable[] throwableArray77 = cloneFailedException58.getSuppressed();
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertArrayEquals(strArray11, new java.lang.String[] { "", "hi!", "10", "10", "10" });
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertArrayEquals(strArray17, new java.lang.String[] { "", "hi!", "10", "10", "10" });
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertArrayEquals(strArray23, new java.lang.String[] { "", "hi!", "10", "10", "10" });
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertArrayEquals(strArray32, new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" });
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(runtimeException36);
        org.junit.Assert.assertNotNull(runtimeException38);
        org.junit.Assert.assertNotNull(format55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(format66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(throwableArray77);
    }

    @Test
    public void test1514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1514");
        java.lang.Throwable[] throwableArray0 = null;
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException5 = new org.apache.commons.lang3.exception.CloneFailedException("hi!");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException6 = new org.apache.commons.lang3.exception.CloneFailedException("10", (java.lang.Throwable) cloneFailedException5);
        java.util.Locale locale8 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat9 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale8);
        java.text.Format format10 = org.apache.commons.lang3.ObjectUtils.clone((java.text.Format) extendedMessageFormat9);
        boolean boolean11 = org.apache.commons.lang3.ObjectUtils.notEqual((java.lang.Object) cloneFailedException5, (java.lang.Object) format10);
        java.lang.Throwable throwable14 = null;
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException15 = new org.apache.commons.lang3.exception.CloneFailedException("", throwable14);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException16 = new org.apache.commons.lang3.exception.CloneFailedException("hi!", (java.lang.Throwable) cloneFailedException15);
        cloneFailedException5.addSuppressed((java.lang.Throwable) cloneFailedException15);
        java.lang.Throwable throwable19 = null;
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException20 = new org.apache.commons.lang3.exception.CloneFailedException("hi!", throwable19);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException21 = new org.apache.commons.lang3.exception.CloneFailedException((java.lang.Throwable) cloneFailedException20);
        boolean boolean22 = org.apache.commons.lang3.ObjectUtils.equals((java.lang.Object) cloneFailedException15, (java.lang.Object) cloneFailedException21);
        org.apache.commons.lang3.exception.CloneFailedException[] cloneFailedExceptionArray23 = new org.apache.commons.lang3.exception.CloneFailedException[] { cloneFailedException21 };
        org.apache.commons.lang3.exception.CloneFailedException[] cloneFailedExceptionArray24 = org.apache.commons.lang3.ObjectUtils.cloneIfPossible(cloneFailedExceptionArray23);
        org.apache.commons.lang3.exception.CloneFailedException[] cloneFailedExceptionArray25 = org.apache.commons.lang3.Validate.noNullElements(cloneFailedExceptionArray24);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Throwable[] throwableArray26 = org.apache.commons.lang3.Validate.validIndex(throwableArray0, (int) (short) 100, "", (java.lang.Object[]) cloneFailedExceptionArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: The validated object is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(format10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(cloneFailedExceptionArray23);
        org.junit.Assert.assertNotNull(cloneFailedExceptionArray24);
        org.junit.Assert.assertNotNull(cloneFailedExceptionArray25);
    }

    @Test
    public void test1515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1515");
        org.apache.commons.lang3.text.StrMatcher strMatcher0 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher1 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher2 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher0, strMatcher1);
        char[] charArray5 = new char[] { '4', 'a' };
        int int9 = strMatcher0.isMatch(charArray5, 0, (int) (byte) 0, (int) (short) 1);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher charSetMatcher10 = new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher(charArray5);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher charSetMatcher11 = new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher(charArray5);
        org.apache.commons.lang3.text.StrMatcher.CharMatcher charMatcher13 = new org.apache.commons.lang3.text.StrMatcher.CharMatcher(' ');
        org.apache.commons.lang3.text.StrMatcher.NoMatcher noMatcher14 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher15 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher16 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher17 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher15, strMatcher16);
        char[] charArray20 = new char[] { '4', 'a' };
        int int24 = strMatcher15.isMatch(charArray20, 0, (int) (byte) 0, (int) (short) 1);
        int int28 = noMatcher14.isMatch(charArray20, 0, 0, 3);
        org.apache.commons.lang3.text.StrMatcher strMatcher29 = org.apache.commons.lang3.text.StrMatcher.charSetMatcher(charArray20);
        java.util.Locale locale31 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat32 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale31);
        java.text.Format[] formatArray33 = extendedMessageFormat32.getFormats();
        boolean boolean34 = org.apache.commons.lang3.ObjectUtils.notEqual((java.lang.Object) charArray20, (java.lang.Object) extendedMessageFormat32);
        int int38 = charMatcher13.isMatch(charArray20, 0, 79, 2);
        org.apache.commons.lang3.text.StrMatcher strMatcher39 = org.apache.commons.lang3.text.StrMatcher.charSetMatcher(charArray20);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher charSetMatcher40 = new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher(charArray20);
        // The following exception was thrown during execution in test generation
        try {
            int int44 = charSetMatcher11.isMatch(charArray20, 55, 0, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 55 out of bounds for length 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(strMatcher0);
        org.junit.Assert.assertNotNull(strMatcher1);
        org.junit.Assert.assertNotNull(strMatcher2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertArrayEquals(charArray5, new char[] { '4', 'a' });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertArrayEquals(charArray20, new char[] { '4', 'a' });
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(formatArray33);
        org.junit.Assert.assertArrayEquals(formatArray33, new java.text.Format[] {});
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(strMatcher39);
    }

    @Test
    public void test1516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1516");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale1);
        java.text.Format[] formatArray3 = extendedMessageFormat2.getFormats();
        java.lang.String str4 = extendedMessageFormat2.toPattern();
        java.util.Locale locale5 = extendedMessageFormat2.getLocale();
        java.text.Format[] formatArray6 = null;
        // The following exception was thrown during execution in test generation
        try {
            extendedMessageFormat2.setFormatsByArgumentIndex(formatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(formatArray3);
        org.junit.Assert.assertArrayEquals(formatArray3, new java.text.Format[] {});
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "hi!" + "'", str4, "hi!");
        org.junit.Assert.assertNull(locale5);
    }

    @Test
    public void test1517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1517");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale1);
        extendedMessageFormat2.applyPattern("10");
        java.lang.String str5 = extendedMessageFormat2.toPattern();
        java.util.Locale locale7 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat8 = new org.apache.commons.lang3.text.ExtendedMessageFormat("10", locale7);
        java.util.Locale locale10 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat11 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale10);
        java.lang.String str12 = extendedMessageFormat11.toPattern();
        java.util.Locale locale14 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat15 = new org.apache.commons.lang3.text.ExtendedMessageFormat("10", locale14);
        org.apache.commons.lang3.text.ExtendedMessageFormat[] extendedMessageFormatArray16 = new org.apache.commons.lang3.text.ExtendedMessageFormat[] { extendedMessageFormat2, extendedMessageFormat8, extendedMessageFormat11, extendedMessageFormat15 };
        org.apache.commons.lang3.text.StrMatcher.NoMatcher noMatcher18 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher19 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher20 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher21 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher19, strMatcher20);
        char[] charArray24 = new char[] { '4', 'a' };
        int int28 = strMatcher19.isMatch(charArray24, 0, (int) (byte) 0, (int) (short) 1);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher charSetMatcher29 = new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher(charArray24);
        int int33 = noMatcher18.isMatch(charArray24, 5, (int) '4', (int) (byte) 100);
        org.apache.commons.lang3.text.StrMatcher.NoMatcher[] noMatcherArray34 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher[] { noMatcher18 };
        org.apache.commons.lang3.text.StrMatcher.NoMatcher[] noMatcherArray35 = org.apache.commons.lang3.Validate.noNullElements(noMatcherArray34);
        org.apache.commons.lang3.text.ExtendedMessageFormat[] extendedMessageFormatArray36 = org.apache.commons.lang3.Validate.noNullElements(extendedMessageFormatArray16, "55", (java.lang.Object[]) noMatcherArray34);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat37 = org.apache.commons.lang3.ObjectUtils.firstNonNull(extendedMessageFormatArray36);
        extendedMessageFormat37.applyPattern("org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat40 = org.apache.commons.lang3.ObjectUtils.cloneIfPossible(extendedMessageFormat37);
        java.text.Format[] formatArray41 = extendedMessageFormat40.getFormats();
        java.text.MessageFormat[] messageFormatArray43 = new java.text.MessageFormat[] {};
        java.text.MessageFormat[][] messageFormatArray44 = new java.text.MessageFormat[][] { messageFormatArray43 };
        java.text.MessageFormat[][] messageFormatArray45 = org.apache.commons.lang3.ObjectUtils.cloneIfPossible(messageFormatArray44);
        java.text.MessageFormat[] messageFormatArray46 = org.apache.commons.lang3.ObjectUtils.firstNonNull(messageFormatArray44);
        java.lang.String str47 = java.text.MessageFormat.format("org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!", (java.lang.Object[]) messageFormatArray46);
        java.text.MessageFormat[] messageFormatArray48 = org.apache.commons.lang3.ObjectUtils.cloneIfPossible(messageFormatArray46);
        java.lang.StringBuffer stringBuffer49 = null;
        java.text.FieldPosition fieldPosition50 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.StringBuffer stringBuffer51 = extendedMessageFormat40.format((java.lang.Object) messageFormatArray46, stringBuffer49, fieldPosition50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "10" + "'", str5, "10");
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNotNull(extendedMessageFormatArray16);
        org.junit.Assert.assertNotNull(strMatcher19);
        org.junit.Assert.assertNotNull(strMatcher20);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertArrayEquals(charArray24, new char[] { '4', 'a' });
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(noMatcherArray34);
        org.junit.Assert.assertNotNull(noMatcherArray35);
        org.junit.Assert.assertNotNull(extendedMessageFormatArray36);
        org.junit.Assert.assertNotNull(extendedMessageFormat37);
        org.junit.Assert.assertNotNull(extendedMessageFormat40);
        org.junit.Assert.assertNotNull(formatArray41);
        org.junit.Assert.assertArrayEquals(formatArray41, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(messageFormatArray43);
        org.junit.Assert.assertArrayEquals(messageFormatArray43, new java.text.MessageFormat[] {});
        org.junit.Assert.assertNotNull(messageFormatArray44);
        org.junit.Assert.assertNotNull(messageFormatArray45);
        org.junit.Assert.assertNotNull(messageFormatArray46);
        org.junit.Assert.assertArrayEquals(messageFormatArray46, new java.text.MessageFormat[] {});
        org.junit.Assert.assertEquals("'" + str47 + "' != '" + "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!" + "'", str47, "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!");
        org.junit.Assert.assertNotNull(messageFormatArray48);
        org.junit.Assert.assertArrayEquals(messageFormatArray48, new java.text.MessageFormat[] {});
    }

    @Test
    public void test1518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1518");
        java.util.Locale locale2 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat3 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale2);
        java.lang.Object[] objArray5 = extendedMessageFormat3.parse("hi!");
        extendedMessageFormat3.applyPattern("10");
        extendedMessageFormat3.applyPattern("55");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat11 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale12 = extendedMessageFormat11.getLocale();
        extendedMessageFormat3.setLocale(locale12);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat14 = new org.apache.commons.lang3.text.ExtendedMessageFormat("-46", locale12);
        java.text.Format[] formatArray15 = extendedMessageFormat14.getFormats();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertArrayEquals(objArray5, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertEquals(locale12.toString(), "en_US");
        org.junit.Assert.assertNotNull(formatArray15);
        org.junit.Assert.assertArrayEquals(formatArray15, new java.text.Format[] {});
    }

    @Test
    public void test1519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1519");
        int int3 = org.apache.commons.lang3.ObjectUtils.compare("", "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: ", false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-228) + "'", int3 == (-228));
    }

    @Test
    public void test1520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1520");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale1);
        java.text.Format[] formatArray3 = extendedMessageFormat2.getFormats();
        java.util.Locale locale4 = null;
        extendedMessageFormat2.setLocale(locale4);
        java.lang.String str6 = extendedMessageFormat2.toPattern();
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat8 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        extendedMessageFormat8.applyPattern("org.apache.commons.lang3.exception.CloneFailedException");
        java.text.Format[] formatArray11 = extendedMessageFormat8.getFormats();
        java.lang.Object[] objArray13 = extendedMessageFormat8.parse("org.apache.commons.lang3.exception.CloneFailedException: 55");
        java.text.Format[] formatArray14 = extendedMessageFormat8.getFormats();
        // The following exception was thrown during execution in test generation
        try {
            extendedMessageFormat2.setFormats(formatArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(formatArray3);
        org.junit.Assert.assertArrayEquals(formatArray3, new java.text.Format[] {});
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertNotNull(formatArray11);
        org.junit.Assert.assertArrayEquals(formatArray11, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertArrayEquals(objArray13, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(formatArray14);
        org.junit.Assert.assertArrayEquals(formatArray14, new java.text.Format[] {});
    }

    @Test
    public void test1521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1521");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException: 55", locale1);
        java.util.Locale locale3 = extendedMessageFormat2.getLocale();
        java.util.Locale locale4 = extendedMessageFormat2.getLocale();
        java.util.Locale locale5 = extendedMessageFormat2.getLocale();
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(locale4);
        org.junit.Assert.assertNull(locale5);
    }

    @Test
    public void test1522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1522");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher3 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("class [[Ljava.lang.String;");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray4 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher3 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray5 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray4 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher7 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("class [[Ljava.lang.String;");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray8 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher7 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray9 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray8 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] stringMatcherArray10 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] { stringMatcherArray5, stringMatcherArray9 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher12 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("class [[Ljava.lang.String;");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray13 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher12 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray14 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray13 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher16 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("class [[Ljava.lang.String;");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray17 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher16 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray18 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray17 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] stringMatcherArray19 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] { stringMatcherArray14, stringMatcherArray18 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher21 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("class [[Ljava.lang.String;");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray22 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher21 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray23 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray22 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher25 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("class [[Ljava.lang.String;");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray26 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher25 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray27 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray26 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] stringMatcherArray28 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] { stringMatcherArray23, stringMatcherArray27 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher30 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("class [[Ljava.lang.String;");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray31 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher30 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray32 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray31 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher34 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("class [[Ljava.lang.String;");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray35 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher34 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] stringMatcherArray36 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][] { stringMatcherArray35 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] stringMatcherArray37 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][] { stringMatcherArray32, stringMatcherArray36 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][][] stringMatcherArray38 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][][] { stringMatcherArray10, stringMatcherArray19, stringMatcherArray28, stringMatcherArray37 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[][][][] stringMatcherArray39 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray38);
        java.lang.String str40 = org.apache.commons.lang3.Validate.notBlank("org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!", "10", (java.lang.Object[]) stringMatcherArray39);
        org.junit.Assert.assertNotNull(stringMatcherArray4);
        org.junit.Assert.assertNotNull(stringMatcherArray5);
        org.junit.Assert.assertNotNull(stringMatcherArray8);
        org.junit.Assert.assertNotNull(stringMatcherArray9);
        org.junit.Assert.assertNotNull(stringMatcherArray10);
        org.junit.Assert.assertNotNull(stringMatcherArray13);
        org.junit.Assert.assertNotNull(stringMatcherArray14);
        org.junit.Assert.assertNotNull(stringMatcherArray17);
        org.junit.Assert.assertNotNull(stringMatcherArray18);
        org.junit.Assert.assertNotNull(stringMatcherArray19);
        org.junit.Assert.assertNotNull(stringMatcherArray22);
        org.junit.Assert.assertNotNull(stringMatcherArray23);
        org.junit.Assert.assertNotNull(stringMatcherArray26);
        org.junit.Assert.assertNotNull(stringMatcherArray27);
        org.junit.Assert.assertNotNull(stringMatcherArray28);
        org.junit.Assert.assertNotNull(stringMatcherArray31);
        org.junit.Assert.assertNotNull(stringMatcherArray32);
        org.junit.Assert.assertNotNull(stringMatcherArray35);
        org.junit.Assert.assertNotNull(stringMatcherArray36);
        org.junit.Assert.assertNotNull(stringMatcherArray37);
        org.junit.Assert.assertNotNull(stringMatcherArray38);
        org.junit.Assert.assertNotNull(stringMatcherArray39);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!" + "'", str40, "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!");
    }

    @Test
    public void test1523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1523");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale1);
        java.lang.Object[] objArray4 = extendedMessageFormat2.parse("hi!");
        extendedMessageFormat2.applyPattern("10");
        java.text.Format format7 = org.apache.commons.lang3.ObjectUtils.clone((java.text.Format) extendedMessageFormat2);
        java.util.Locale locale8 = null;
        extendedMessageFormat2.setLocale(locale8);
        org.apache.commons.lang3.text.StrMatcher.NoMatcher noMatcher10 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher11 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher12 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher13 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher11, strMatcher12);
        char[] charArray16 = new char[] { '4', 'a' };
        int int20 = strMatcher11.isMatch(charArray16, 0, (int) (byte) 0, (int) (short) 1);
        int int24 = noMatcher10.isMatch(charArray16, 0, 0, 3);
        org.apache.commons.lang3.text.StrMatcher strMatcher25 = org.apache.commons.lang3.text.StrMatcher.charSetMatcher(charArray16);
        java.util.Locale locale27 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat28 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale27);
        java.text.Format[] formatArray29 = extendedMessageFormat28.getFormats();
        boolean boolean30 = org.apache.commons.lang3.ObjectUtils.notEqual((java.lang.Object) strMatcher25, (java.lang.Object) formatArray29);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str31 = extendedMessageFormat2.format((java.lang.Object) boolean30);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: class java.lang.Boolean cannot be cast to class [Ljava.lang.Object; (java.lang.Boolean and [Ljava.lang.Object; are in module java.base of loader 'bootstrap')");
        } catch (java.lang.ClassCastException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertArrayEquals(objArray4, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertNotNull(strMatcher11);
        org.junit.Assert.assertNotNull(strMatcher12);
        org.junit.Assert.assertNotNull(strMatcher13);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertArrayEquals(charArray16, new char[] { '4', 'a' });
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertNotNull(formatArray29);
        org.junit.Assert.assertArrayEquals(formatArray29, new java.text.Format[] {});
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test1524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1524");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat1 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!");
        java.lang.Object obj2 = null;
        boolean boolean3 = extendedMessageFormat1.equals(obj2);
        java.lang.String str4 = extendedMessageFormat1.toPattern();
        java.text.ParsePosition parsePosition6 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj7 = extendedMessageFormat1.parseObject("", parsePosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "hi!" + "'", str4, "hi!");
    }

    @Test
    public void test1525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1525");
        java.util.Locale locale2 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat3 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale2);
        java.text.Format[] formatArray4 = extendedMessageFormat3.getFormats();
        java.lang.String str5 = extendedMessageFormat3.toPattern();
        java.lang.Throwable throwable8 = null;
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException9 = new org.apache.commons.lang3.exception.CloneFailedException("", throwable8);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException10 = new org.apache.commons.lang3.exception.CloneFailedException("hi!", (java.lang.Throwable) cloneFailedException9);
        boolean boolean11 = extendedMessageFormat3.equals((java.lang.Object) "hi!");
        java.lang.String str12 = extendedMessageFormat3.toPattern();
        java.util.Locale locale17 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat18 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale17);
        java.lang.Object[] objArray20 = extendedMessageFormat18.parse("hi!");
        extendedMessageFormat18.applyPattern("10");
        extendedMessageFormat18.applyPattern("55");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat26 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale27 = extendedMessageFormat26.getLocale();
        extendedMessageFormat18.setLocale(locale27);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat29 = new org.apache.commons.lang3.text.ExtendedMessageFormat("-46", locale27);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat30 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale27);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat31 = new org.apache.commons.lang3.text.ExtendedMessageFormat("-46", locale27);
        boolean boolean32 = org.apache.commons.lang3.ObjectUtils.equals((java.lang.Object) extendedMessageFormat3, (java.lang.Object) locale27);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat33 = new org.apache.commons.lang3.text.ExtendedMessageFormat(" ", locale27);
        char[] charArray37 = new char[] { ' ', ' ', ' ' };
        char[] charArray41 = new char[] { ' ', ' ', ' ' };
        char[][] charArray42 = new char[][] { charArray37, charArray41 };
        char[] charArray46 = new char[] { ' ', ' ', ' ' };
        char[] charArray50 = new char[] { ' ', ' ', ' ' };
        char[][] charArray51 = new char[][] { charArray46, charArray50 };
        char[] charArray55 = new char[] { ' ', ' ', ' ' };
        char[] charArray59 = new char[] { ' ', ' ', ' ' };
        char[][] charArray60 = new char[][] { charArray55, charArray59 };
        char[] charArray64 = new char[] { ' ', ' ', ' ' };
        char[] charArray68 = new char[] { ' ', ' ', ' ' };
        char[][] charArray69 = new char[][] { charArray64, charArray68 };
        char[] charArray73 = new char[] { ' ', ' ', ' ' };
        char[] charArray77 = new char[] { ' ', ' ', ' ' };
        char[][] charArray78 = new char[][] { charArray73, charArray77 };
        char[][][] charArray79 = new char[][][] { charArray42, charArray51, charArray60, charArray69, charArray78 };
        char[][][] charArray80 = org.apache.commons.lang3.Validate.notEmpty(charArray79);
        java.lang.String[] strArray82 = new java.lang.String[] {};
        java.lang.String str83 = org.apache.commons.lang3.ObjectUtils.min(strArray82);
        java.lang.String str84 = org.apache.commons.lang3.ObjectUtils.min(strArray82);
        char[][][] charArray85 = org.apache.commons.lang3.Validate.notNull(charArray79, "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!", (java.lang.Object[]) strArray82);
        java.lang.StringBuffer stringBuffer86 = null;
        java.text.FieldPosition fieldPosition87 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.StringBuffer stringBuffer88 = extendedMessageFormat33.format((java.lang.Object[]) strArray82, stringBuffer86, fieldPosition87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(formatArray4);
        org.junit.Assert.assertArrayEquals(formatArray4, new java.text.Format[] {});
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertArrayEquals(objArray20, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_US");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertArrayEquals(charArray37, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertArrayEquals(charArray41, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertArrayEquals(charArray46, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertArrayEquals(charArray50, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertArrayEquals(charArray55, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertArrayEquals(charArray59, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray60);
        org.junit.Assert.assertNotNull(charArray64);
        org.junit.Assert.assertArrayEquals(charArray64, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray68);
        org.junit.Assert.assertArrayEquals(charArray68, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray69);
        org.junit.Assert.assertNotNull(charArray73);
        org.junit.Assert.assertArrayEquals(charArray73, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray77);
        org.junit.Assert.assertArrayEquals(charArray77, new char[] { ' ', ' ', ' ' });
        org.junit.Assert.assertNotNull(charArray78);
        org.junit.Assert.assertNotNull(charArray79);
        org.junit.Assert.assertNotNull(charArray80);
        org.junit.Assert.assertNotNull(strArray82);
        org.junit.Assert.assertArrayEquals(strArray82, new java.lang.String[] {});
        org.junit.Assert.assertNull(str83);
        org.junit.Assert.assertNull(str84);
        org.junit.Assert.assertNotNull(charArray85);
    }

    @Test
    public void test1526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1526");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale1);
        java.lang.Object[] objArray4 = extendedMessageFormat2.parse("hi!");
        extendedMessageFormat2.applyPattern("10");
        java.text.Format format7 = org.apache.commons.lang3.ObjectUtils.clone((java.text.Format) extendedMessageFormat2);
        java.util.Locale locale8 = extendedMessageFormat2.getLocale();
        java.util.Locale locale10 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat11 = new org.apache.commons.lang3.text.ExtendedMessageFormat("10", locale10);
        java.util.Locale locale13 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat14 = new org.apache.commons.lang3.text.ExtendedMessageFormat("55", locale13);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat15 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(extendedMessageFormat11, extendedMessageFormat14);
        extendedMessageFormat14.applyPattern("7");
        java.text.Format[] formatArray18 = extendedMessageFormat14.getFormatsByArgumentIndex();
        // The following exception was thrown during execution in test generation
        try {
            extendedMessageFormat2.setFormatsByArgumentIndex(formatArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertArrayEquals(objArray4, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(format7);
        org.junit.Assert.assertNull(locale8);
        org.junit.Assert.assertNotNull(extendedMessageFormat15);
        org.junit.Assert.assertNotNull(formatArray18);
        org.junit.Assert.assertArrayEquals(formatArray18, new java.text.Format[] {});
    }

    @Test
    public void test1527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1527");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat1 = new org.apache.commons.lang3.text.ExtendedMessageFormat("-46");
        java.util.Locale locale3 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat4 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale3);
        java.text.Format[] formatArray5 = extendedMessageFormat4.getFormats();
        java.util.Locale locale6 = null;
        extendedMessageFormat4.setLocale(locale6);
        java.util.Locale locale8 = extendedMessageFormat4.getLocale();
        java.util.Locale locale10 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat11 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale10);
        java.lang.String str12 = extendedMessageFormat11.toPattern();
        java.text.Format[] formatArray13 = extendedMessageFormat11.getFormatsByArgumentIndex();
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat15 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale16 = extendedMessageFormat15.getLocale();
        extendedMessageFormat11.setLocale(locale16);
        extendedMessageFormat4.setLocale(locale16);
        boolean boolean19 = extendedMessageFormat1.equals((java.lang.Object) extendedMessageFormat4);
        java.lang.String str20 = extendedMessageFormat1.toPattern();
        java.lang.Object obj21 = null;
        java.lang.StringBuffer stringBuffer22 = null;
        java.text.FieldPosition fieldPosition23 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.StringBuffer stringBuffer24 = extendedMessageFormat1.format(obj21, stringBuffer22, fieldPosition23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(formatArray5);
        org.junit.Assert.assertArrayEquals(formatArray5, new java.text.Format[] {});
        org.junit.Assert.assertNull(locale8);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "" + "'", str12, "");
        org.junit.Assert.assertNotNull(formatArray13);
        org.junit.Assert.assertArrayEquals(formatArray13, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertEquals(locale16.toString(), "en_US");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "-46" + "'", str20, "-46");
    }

    @Test
    public void test1528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1528");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher1 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher3 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher5 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher7 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher9 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray10 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher1, stringMatcher3, stringMatcher5, stringMatcher7, stringMatcher9 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray11 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray10);
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher12 = org.apache.commons.lang3.ObjectUtils.firstNonNull(stringMatcherArray10);
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher13 = org.apache.commons.lang3.Validate.notNull(stringMatcher12);
        org.apache.commons.lang3.text.StrMatcher.NoMatcher noMatcher14 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher15 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher16 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher17 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher15, strMatcher16);
        char[] charArray20 = new char[] { '4', 'a' };
        int int24 = strMatcher15.isMatch(charArray20, 0, (int) (byte) 0, (int) (short) 1);
        int int28 = noMatcher14.isMatch(charArray20, 0, 0, 3);
        org.apache.commons.lang3.text.StrMatcher strMatcher29 = org.apache.commons.lang3.text.StrMatcher.charSetMatcher(charArray20);
        org.apache.commons.lang3.text.StrMatcher.NoMatcher noMatcher30 = new org.apache.commons.lang3.text.StrMatcher.NoMatcher();
        java.lang.String str31 = org.apache.commons.lang3.ObjectUtils.toString((java.lang.Object) noMatcher30);
        char[] charArray33 = new char[] { 'a' };
        int int37 = noMatcher30.isMatch(charArray33, (int) (byte) -1, (int) (byte) 10, (-7));
        int int39 = strMatcher29.isMatch(charArray33, 0);
        int int43 = stringMatcher13.isMatch(charArray33, (int) '4', (int) (short) 10, 46);
        org.apache.commons.lang3.text.StrMatcher strMatcher44 = org.apache.commons.lang3.text.StrMatcher.charSetMatcher(charArray33);
        org.junit.Assert.assertNotNull(stringMatcherArray10);
        org.junit.Assert.assertNotNull(stringMatcherArray11);
        org.junit.Assert.assertNotNull(stringMatcher12);
        org.junit.Assert.assertNotNull(stringMatcher13);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertArrayEquals(charArray20, new char[] { '4', 'a' });
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertArrayEquals(charArray33, new char[] { 'a' });
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(strMatcher44);
    }

    @Test
    public void test1529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1529");
        java.util.Locale locale2 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat3 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale2);
        java.lang.Object[] objArray5 = extendedMessageFormat3.parse("hi!");
        extendedMessageFormat3.applyPattern("10");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher9 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher11 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher13 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher15 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher17 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray18 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher9, stringMatcher11, stringMatcher13, stringMatcher15, stringMatcher17 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray19 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray18);
        boolean boolean20 = extendedMessageFormat3.equals((java.lang.Object) stringMatcherArray18);
        java.lang.String[] strArray29 = new java.lang.String[] { "", "hi!", "10", "10", "10" };
        java.lang.String[] strArray35 = new java.lang.String[] { "", "hi!", "10", "10", "10" };
        java.lang.String[] strArray41 = new java.lang.String[] { "", "hi!", "10", "10", "10" };
        java.lang.String[][] strArray42 = new java.lang.String[][] { strArray29, strArray35, strArray41 };
        java.lang.String[] strArray50 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" };
        java.lang.String str51 = org.apache.commons.lang3.ObjectUtils.min(strArray50);
        java.lang.String[][] strArray52 = org.apache.commons.lang3.Validate.notEmpty(strArray42, "", (java.lang.Object[]) strArray50);
        org.apache.commons.lang3.Validate.validState(true, "", (java.lang.Object[]) strArray50);
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray54 = org.apache.commons.lang3.Validate.notNull(stringMatcherArray18, "", (java.lang.Object[]) strArray50);
        java.lang.String str55 = org.apache.commons.lang3.ObjectUtils.min(strArray50);
        java.lang.String str56 = org.apache.commons.lang3.ObjectUtils.min(strArray50);
        java.lang.String str57 = java.text.MessageFormat.format("", (java.lang.Object[]) strArray50);
        java.lang.String str58 = org.apache.commons.lang3.ObjectUtils.min(strArray50);
        java.lang.String str59 = org.apache.commons.lang3.ObjectUtils.max(strArray50);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertArrayEquals(objArray5, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray18);
        org.junit.Assert.assertNotNull(stringMatcherArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertArrayEquals(strArray29, new java.lang.String[] { "", "hi!", "10", "10", "10" });
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertArrayEquals(strArray35, new java.lang.String[] { "", "hi!", "10", "10", "10" });
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertArrayEquals(strArray41, new java.lang.String[] { "", "hi!", "10", "10", "10" });
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertArrayEquals(strArray50, new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" });
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "" + "'", str51, "");
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(stringMatcherArray54);
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "" + "'", str55, "");
        org.junit.Assert.assertEquals("'" + str56 + "' != '" + "" + "'", str56, "");
        org.junit.Assert.assertEquals("'" + str57 + "' != '" + "" + "'", str57, "");
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "" + "'", str58, "");
        org.junit.Assert.assertEquals("'" + str59 + "' != '" + "hi!" + "'", str59, "hi!");
    }

    @Test
    public void test1530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1530");
        java.util.Locale locale5 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat6 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale5);
        java.lang.Object[] objArray8 = extendedMessageFormat6.parse("hi!");
        extendedMessageFormat6.applyPattern("10");
        java.util.Locale locale12 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat13 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale12);
        extendedMessageFormat13.applyPattern("10");
        java.util.Locale locale17 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat18 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale17);
        java.util.Locale locale20 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat21 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale20);
        java.util.Locale locale23 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat24 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale23);
        java.lang.Object[] objArray26 = extendedMessageFormat24.parse("hi!");
        extendedMessageFormat24.applyPattern("10");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher30 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher32 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher34 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher36 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher38 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray39 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher30, stringMatcher32, stringMatcher34, stringMatcher36, stringMatcher38 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray40 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray39);
        boolean boolean41 = extendedMessageFormat24.equals((java.lang.Object) stringMatcherArray39);
        java.text.MessageFormat[] messageFormatArray42 = new java.text.MessageFormat[] { extendedMessageFormat6, extendedMessageFormat13, extendedMessageFormat18, extendedMessageFormat21, extendedMessageFormat24 };
        java.text.MessageFormat messageFormat43 = org.apache.commons.lang3.ObjectUtils.firstNonNull(messageFormatArray42);
        java.text.Format[] formatArray44 = messageFormat43.getFormatsByArgumentIndex();
        org.apache.commons.lang3.Validate.exclusiveBetween("class [Ljava.lang.Object;", "org.apache.commons.lang3.exception.CloneFailedException: hi!", (java.lang.Comparable<java.lang.String>) "org.apache.commons.lang3.exception.CloneFailedException: -46", "org.apache.commons.lang3.exception.CloneFailedException: 55", (java.lang.Object[]) formatArray44);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertArrayEquals(objArray8, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertArrayEquals(objArray26, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray39);
        org.junit.Assert.assertNotNull(stringMatcherArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(messageFormatArray42);
        org.junit.Assert.assertNotNull(messageFormat43);
        org.junit.Assert.assertNotNull(formatArray44);
        org.junit.Assert.assertArrayEquals(formatArray44, new java.text.Format[] {});
    }

    @Test
    public void test1531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1531");
        org.apache.commons.lang3.text.StrMatcher strMatcher0 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher1 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher2 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher0, strMatcher1);
        char[] charArray5 = new char[] { '4', 'a' };
        int int9 = strMatcher0.isMatch(charArray5, 0, (int) (byte) 0, (int) (short) 1);
        char[] charArray10 = org.apache.commons.lang3.ObjectUtils.cloneIfPossible(charArray5);
        org.apache.commons.lang3.text.StrMatcher strMatcher11 = org.apache.commons.lang3.text.StrMatcher.charSetMatcher(charArray5);
        java.lang.String str12 = org.apache.commons.lang3.ObjectUtils.toString((java.lang.Object) strMatcher11);
        org.junit.Assert.assertNotNull(strMatcher0);
        org.junit.Assert.assertNotNull(strMatcher1);
        org.junit.Assert.assertNotNull(strMatcher2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertArrayEquals(charArray5, new char[] { '4', 'a' });
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertArrayEquals(charArray10, new char[] { '4', 'a' });
        org.junit.Assert.assertNotNull(strMatcher11);
    }

    @Test
    public void test1532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1532");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale1);
        java.lang.Object[] objArray4 = extendedMessageFormat2.parse("hi!");
        extendedMessageFormat2.applyPattern("10");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher8 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher10 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher12 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher14 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher16 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray17 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher8, stringMatcher10, stringMatcher12, stringMatcher14, stringMatcher16 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray18 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray17);
        boolean boolean19 = extendedMessageFormat2.equals((java.lang.Object) stringMatcherArray17);
        java.text.Format[] formatArray20 = extendedMessageFormat2.getFormats();
        java.text.Format[] formatArray21 = extendedMessageFormat2.getFormats();
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat23 = new org.apache.commons.lang3.text.ExtendedMessageFormat("class [[Ljava.lang.String;");
        java.text.Format[] formatArray24 = extendedMessageFormat23.getFormatsByArgumentIndex();
        // The following exception was thrown during execution in test generation
        try {
            extendedMessageFormat2.setFormatsByArgumentIndex(formatArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertArrayEquals(objArray4, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray17);
        org.junit.Assert.assertNotNull(stringMatcherArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(formatArray20);
        org.junit.Assert.assertArrayEquals(formatArray20, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(formatArray21);
        org.junit.Assert.assertArrayEquals(formatArray21, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(formatArray24);
        org.junit.Assert.assertArrayEquals(formatArray24, new java.text.Format[] {});
    }

    @Test
    public void test1533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1533");
        java.util.Locale locale4 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat5 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale4);
        org.apache.commons.lang3.ObjectUtils objectUtils6 = new org.apache.commons.lang3.ObjectUtils();
        boolean boolean7 = extendedMessageFormat5.equals((java.lang.Object) objectUtils6);
        java.text.Format[] formatArray8 = extendedMessageFormat5.getFormatsByArgumentIndex();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = org.apache.commons.lang3.Validate.validIndex("org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: ", (-12), "-20", (java.lang.Object[]) formatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: -20");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(formatArray8);
        org.junit.Assert.assertArrayEquals(formatArray8, new java.text.Format[] {});
    }

    @Test
    public void test1534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1534");
        org.apache.commons.lang3.Validate validate0 = new org.apache.commons.lang3.Validate();
        org.apache.commons.lang3.Validate[] validateArray1 = new org.apache.commons.lang3.Validate[] { validate0 };
        org.apache.commons.lang3.Validate[] validateArray2 = org.apache.commons.lang3.Validate.noNullElements(validateArray1);
        org.apache.commons.lang3.Validate[] validateArray3 = org.apache.commons.lang3.Validate.noNullElements(validateArray2);
        org.apache.commons.lang3.Validate validate4 = org.apache.commons.lang3.ObjectUtils.firstNonNull(validateArray3);
        org.junit.Assert.assertNotNull(validateArray1);
        org.junit.Assert.assertNotNull(validateArray2);
        org.junit.Assert.assertNotNull(validateArray3);
        org.junit.Assert.assertNotNull(validate4);
    }

    @Test
    public void test1535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1535");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat3 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale4 = null;
        extendedMessageFormat3.setLocale(locale4);
        java.text.Format[] formatArray6 = extendedMessageFormat3.getFormatsByArgumentIndex();
        java.text.Format[] formatArray7 = extendedMessageFormat3.getFormats();
        java.lang.CharSequence charSequence8 = org.apache.commons.lang3.Validate.notEmpty((java.lang.CharSequence) "org.apache.commons.lang3.exception.CloneFailedException: hi!", "en_US", (java.lang.Object[]) formatArray7);
        org.junit.Assert.assertNotNull(formatArray6);
        org.junit.Assert.assertArrayEquals(formatArray6, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(formatArray7);
        org.junit.Assert.assertArrayEquals(formatArray7, new java.text.Format[] {});
        org.junit.Assert.assertEquals("'" + charSequence8 + "' != '" + "org.apache.commons.lang3.exception.CloneFailedException: hi!" + "'", charSequence8, "org.apache.commons.lang3.exception.CloneFailedException: hi!");
    }

    @Test
    public void test1536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1536");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale1);
        java.text.Format[] formatArray3 = extendedMessageFormat2.getFormats();
        extendedMessageFormat2.applyPattern("class [[Ljava.lang.String;");
        java.lang.String str6 = extendedMessageFormat2.toPattern();
        java.text.Format[] formatArray7 = extendedMessageFormat2.getFormats();
        java.lang.String str8 = org.apache.commons.lang3.ObjectUtils.identityToString((java.lang.Object) formatArray7);
        org.junit.Assert.assertNotNull(formatArray3);
        org.junit.Assert.assertArrayEquals(formatArray3, new java.text.Format[] {});
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "class [[Ljava.lang.String;" + "'", str6, "class [[Ljava.lang.String;");
        org.junit.Assert.assertNotNull(formatArray7);
        org.junit.Assert.assertArrayEquals(formatArray7, new java.text.Format[] {});
    }

    @Test
    public void test1537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1537");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale1);
        extendedMessageFormat2.applyPattern("10");
        boolean boolean6 = extendedMessageFormat2.equals((java.lang.Object) '#');
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat8 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale9 = extendedMessageFormat8.getLocale();
        extendedMessageFormat2.setLocale(locale9);
        java.util.Locale locale12 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat13 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale12);
        extendedMessageFormat13.applyPattern("10");
        java.lang.String str16 = extendedMessageFormat13.toPattern();
        java.text.Format format17 = org.apache.commons.lang3.ObjectUtils.defaultIfNull((java.text.Format) extendedMessageFormat2, (java.text.Format) extendedMessageFormat13);
        java.lang.String str18 = org.apache.commons.lang3.ObjectUtils.toString((java.lang.Object) extendedMessageFormat2);
        java.text.Format[] formatArray19 = extendedMessageFormat2.getFormatsByArgumentIndex();
        java.util.Locale locale21 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat22 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale21);
        java.lang.String str23 = extendedMessageFormat22.toPattern();
        java.text.Format[] formatArray24 = extendedMessageFormat22.getFormatsByArgumentIndex();
        java.lang.Object obj25 = null;
        boolean boolean26 = extendedMessageFormat22.equals(obj25);
        java.text.Format[] formatArray27 = extendedMessageFormat22.getFormatsByArgumentIndex();
        // The following exception was thrown during execution in test generation
        try {
            extendedMessageFormat2.setFormatsByArgumentIndex(formatArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertEquals(locale9.toString(), "en_US");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "10" + "'", str16, "10");
        org.junit.Assert.assertNotNull(format17);
        org.junit.Assert.assertNotNull(formatArray19);
        org.junit.Assert.assertArrayEquals(formatArray19, new java.text.Format[] {});
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "" + "'", str23, "");
        org.junit.Assert.assertNotNull(formatArray24);
        org.junit.Assert.assertArrayEquals(formatArray24, new java.text.Format[] {});
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(formatArray27);
        org.junit.Assert.assertArrayEquals(formatArray27, new java.text.Format[] {});
    }

    @Test
    public void test1538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1538");
        java.util.Locale locale6 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat7 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale6);
        java.lang.String str8 = extendedMessageFormat7.toPattern();
        java.text.Format[] formatArray9 = extendedMessageFormat7.getFormatsByArgumentIndex();
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat11 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale12 = extendedMessageFormat11.getLocale();
        extendedMessageFormat7.setLocale(locale12);
        java.util.Locale locale15 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat16 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException: hi!", locale15);
        extendedMessageFormat16.applyPattern("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale20 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat21 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale20);
        java.lang.Object[] objArray23 = extendedMessageFormat21.parse("hi!");
        extendedMessageFormat21.applyPattern("10");
        extendedMessageFormat21.applyPattern("55");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat29 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale30 = extendedMessageFormat29.getLocale();
        extendedMessageFormat21.setLocale(locale30);
        extendedMessageFormat16.setLocale(locale30);
        extendedMessageFormat7.setLocale(locale30);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat34 = new org.apache.commons.lang3.text.ExtendedMessageFormat("7", locale30);
        java.util.Locale locale38 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat39 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale38);
        java.lang.Object[] objArray41 = extendedMessageFormat39.parse("hi!");
        extendedMessageFormat39.applyPattern("10");
        extendedMessageFormat39.applyPattern("55");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat47 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale48 = extendedMessageFormat47.getLocale();
        extendedMessageFormat39.setLocale(locale48);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat50 = new org.apache.commons.lang3.text.ExtendedMessageFormat("-46", locale48);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat51 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale48);
        java.util.Locale[] localeArray52 = new java.util.Locale[] { locale30, locale48 };
        java.util.Locale[] localeArray53 = org.apache.commons.lang3.Validate.noNullElements(localeArray52);
        java.lang.Comparable<java.lang.String> strComparable54 = org.apache.commons.lang3.Validate.notNull((java.lang.Comparable<java.lang.String>) "0", "", (java.lang.Object[]) localeArray52);
        java.lang.String[] strArray62 = new java.lang.String[] { "10", "class [[Ljava.lang.String;", "org.apache.commons.lang3.exception.CloneFailedException: hi!", "10", "hi!", "hi!" };
        java.lang.String str63 = org.apache.commons.lang3.ObjectUtils.max(strArray62);
        java.lang.String str64 = org.apache.commons.lang3.ObjectUtils.min(strArray62);
        java.util.Locale[] localeArray65 = org.apache.commons.lang3.Validate.notNull(localeArray52, "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!", (java.lang.Object[]) strArray62);
        java.lang.CharSequence charSequence66 = org.apache.commons.lang3.Validate.notBlank((java.lang.CharSequence) "7", "org.apache.commons.lang3.exception.CloneFailedException: 55", (java.lang.Object[]) localeArray65);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNotNull(formatArray9);
        org.junit.Assert.assertArrayEquals(formatArray9, new java.text.Format[] {});
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertEquals(locale12.toString(), "en_US");
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertArrayEquals(objArray23, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertEquals(locale30.toString(), "en_US");
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertArrayEquals(objArray41, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(locale48);
        org.junit.Assert.assertEquals(locale48.toString(), "en_US");
        org.junit.Assert.assertNotNull(localeArray52);
        org.junit.Assert.assertNotNull(localeArray53);
        org.junit.Assert.assertEquals("'" + strComparable54 + "' != '" + "0" + "'", strComparable54, "0");
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertArrayEquals(strArray62, new java.lang.String[] { "10", "class [[Ljava.lang.String;", "org.apache.commons.lang3.exception.CloneFailedException: hi!", "10", "hi!", "hi!" });
        org.junit.Assert.assertEquals("'" + str63 + "' != '" + "org.apache.commons.lang3.exception.CloneFailedException: hi!" + "'", str63, "org.apache.commons.lang3.exception.CloneFailedException: hi!");
        org.junit.Assert.assertEquals("'" + str64 + "' != '" + "10" + "'", str64, "10");
        org.junit.Assert.assertNotNull(localeArray65);
        org.junit.Assert.assertEquals("'" + charSequence66 + "' != '" + "7" + "'", charSequence66, "7");
    }

    @Test
    public void test1539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1539");
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] charSetMatcherArray3 = new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher charSetMatcher4 = org.apache.commons.lang3.ObjectUtils.firstNonNull(charSetMatcherArray3);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] charSetMatcherArray5 = new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] {};
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher charSetMatcher6 = org.apache.commons.lang3.ObjectUtils.firstNonNull(charSetMatcherArray5);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] charSetMatcherArray7 = org.apache.commons.lang3.ObjectUtils.clone(charSetMatcherArray5);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] charSetMatcherArray8 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(charSetMatcherArray3, charSetMatcherArray5);
        java.lang.String[] strArray16 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" };
        java.lang.String str17 = org.apache.commons.lang3.ObjectUtils.min(strArray16);
        java.lang.String str18 = org.apache.commons.lang3.ObjectUtils.min(strArray16);
        java.lang.String str19 = org.apache.commons.lang3.ObjectUtils.min(strArray16);
        java.lang.String str20 = org.apache.commons.lang3.ObjectUtils.min(strArray16);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] charSetMatcherArray21 = org.apache.commons.lang3.Validate.notNull(charSetMatcherArray8, "class [[Ljava.lang.String;", (java.lang.Object[]) strArray16);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.lang3.Validate.matchesPattern((java.lang.CharSequence) "org.apache.commons.lang3.exception.CloneFailedException", "10", "org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!", (java.lang.Object[]) charSetMatcherArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(charSetMatcherArray3);
        org.junit.Assert.assertArrayEquals(charSetMatcherArray3, new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] {});
        org.junit.Assert.assertNull(charSetMatcher4);
        org.junit.Assert.assertNotNull(charSetMatcherArray5);
        org.junit.Assert.assertArrayEquals(charSetMatcherArray5, new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] {});
        org.junit.Assert.assertNull(charSetMatcher6);
        org.junit.Assert.assertNotNull(charSetMatcherArray7);
        org.junit.Assert.assertArrayEquals(charSetMatcherArray7, new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] {});
        org.junit.Assert.assertNotNull(charSetMatcherArray8);
        org.junit.Assert.assertArrayEquals(charSetMatcherArray8, new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] {});
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertArrayEquals(strArray16, new java.lang.String[] { "", "hi!", "hi!", "", "hi!", "" });
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "" + "'", str17, "");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "" + "'", str19, "");
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "" + "'", str20, "");
        org.junit.Assert.assertNotNull(charSetMatcherArray21);
        org.junit.Assert.assertArrayEquals(charSetMatcherArray21, new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher[] {});
    }

    @Test
    public void test1540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1540");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale1);
        java.lang.Object[] objArray4 = extendedMessageFormat2.parse("hi!");
        java.lang.String str6 = org.apache.commons.lang3.ObjectUtils.toString((java.lang.Object) extendedMessageFormat2, "10");
        java.text.Format[] formatArray7 = null;
        // The following exception was thrown during execution in test generation
        try {
            extendedMessageFormat2.setFormats(formatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertArrayEquals(objArray4, new java.lang.Object[] {});
    }

    @Test
    public void test1541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1541");
        org.apache.commons.lang3.text.StrMatcher strMatcher1 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher2 = org.apache.commons.lang3.text.StrMatcher.trimMatcher();
        org.apache.commons.lang3.text.StrMatcher strMatcher3 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(strMatcher1, strMatcher2);
        char[] charArray6 = new char[] { '4', 'a' };
        int int10 = strMatcher1.isMatch(charArray6, 0, (int) (byte) 0, (int) (short) 1);
        org.apache.commons.lang3.text.StrMatcher.CharSetMatcher charSetMatcher11 = new org.apache.commons.lang3.text.StrMatcher.CharSetMatcher(charArray6);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat13 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        extendedMessageFormat13.applyPattern("org.apache.commons.lang3.exception.CloneFailedException");
        java.lang.String str16 = extendedMessageFormat13.toPattern();
        boolean boolean17 = org.apache.commons.lang3.ObjectUtils.equals((java.lang.Object) charSetMatcher11, (java.lang.Object) extendedMessageFormat13);
        java.util.Locale locale20 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat21 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException: hi!", locale20);
        extendedMessageFormat21.applyPattern("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale25 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat26 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale25);
        java.lang.Object[] objArray28 = extendedMessageFormat26.parse("hi!");
        extendedMessageFormat26.applyPattern("10");
        extendedMessageFormat26.applyPattern("55");
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat34 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException");
        java.util.Locale locale35 = extendedMessageFormat34.getLocale();
        extendedMessageFormat26.setLocale(locale35);
        extendedMessageFormat21.setLocale(locale35);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat38 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException: 55", locale35);
        extendedMessageFormat13.setLocale(locale35);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat40 = new org.apache.commons.lang3.text.ExtendedMessageFormat("55", locale35);
        java.util.Locale locale42 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat43 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale42);
        org.apache.commons.lang3.ObjectUtils objectUtils44 = new org.apache.commons.lang3.ObjectUtils();
        boolean boolean45 = extendedMessageFormat43.equals((java.lang.Object) objectUtils44);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException49 = new org.apache.commons.lang3.exception.CloneFailedException("hi!");
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException50 = new org.apache.commons.lang3.exception.CloneFailedException("10", (java.lang.Throwable) cloneFailedException49);
        org.apache.commons.lang3.exception.CloneFailedException cloneFailedException51 = new org.apache.commons.lang3.exception.CloneFailedException("", (java.lang.Throwable) cloneFailedException50);
        java.util.Locale locale53 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat54 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale53);
        java.lang.Object[] objArray56 = extendedMessageFormat54.parse("hi!");
        extendedMessageFormat54.applyPattern("10");
        java.util.Locale locale60 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat61 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale60);
        extendedMessageFormat61.applyPattern("10");
        java.util.Locale locale65 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat66 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale65);
        java.util.Locale locale68 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat69 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale68);
        java.util.Locale locale71 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat72 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale71);
        java.lang.Object[] objArray74 = extendedMessageFormat72.parse("hi!");
        extendedMessageFormat72.applyPattern("10");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher78 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher80 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher82 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher84 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher86 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray87 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher78, stringMatcher80, stringMatcher82, stringMatcher84, stringMatcher86 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray88 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray87);
        boolean boolean89 = extendedMessageFormat72.equals((java.lang.Object) stringMatcherArray87);
        java.text.MessageFormat[] messageFormatArray90 = new java.text.MessageFormat[] { extendedMessageFormat54, extendedMessageFormat61, extendedMessageFormat66, extendedMessageFormat69, extendedMessageFormat72 };
        java.text.MessageFormat messageFormat91 = org.apache.commons.lang3.ObjectUtils.firstNonNull(messageFormatArray90);
        java.text.Format[] formatArray92 = messageFormat91.getFormatsByArgumentIndex();
        boolean boolean93 = org.apache.commons.lang3.ObjectUtils.notEqual((java.lang.Object) cloneFailedException51, (java.lang.Object) formatArray92);
        boolean boolean94 = org.apache.commons.lang3.ObjectUtils.equals((java.lang.Object) extendedMessageFormat43, (java.lang.Object) formatArray92);
        java.text.Format[] formatArray95 = extendedMessageFormat43.getFormatsByArgumentIndex();
        // The following exception was thrown during execution in test generation
        try {
            extendedMessageFormat40.setFormatsByArgumentIndex(formatArray95);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(strMatcher1);
        org.junit.Assert.assertNotNull(strMatcher2);
        org.junit.Assert.assertNotNull(strMatcher3);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertArrayEquals(charArray6, new char[] { '4', 'a' });
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "org.apache.commons.lang3.exception.CloneFailedException" + "'", str16, "org.apache.commons.lang3.exception.CloneFailedException");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertArrayEquals(objArray28, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(locale35);
        org.junit.Assert.assertEquals(locale35.toString(), "en_US");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertArrayEquals(objArray56, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertArrayEquals(objArray74, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray87);
        org.junit.Assert.assertNotNull(stringMatcherArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(messageFormatArray90);
        org.junit.Assert.assertNotNull(messageFormat91);
        org.junit.Assert.assertNotNull(formatArray92);
        org.junit.Assert.assertArrayEquals(formatArray92, new java.text.Format[] {});
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(formatArray95);
        org.junit.Assert.assertArrayEquals(formatArray95, new java.text.Format[] {});
    }

    @Test
    public void test1542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1542");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("10", locale1);
        java.util.Locale locale4 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat5 = new org.apache.commons.lang3.text.ExtendedMessageFormat("55", locale4);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat6 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(extendedMessageFormat2, extendedMessageFormat5);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat7 = org.apache.commons.lang3.ObjectUtils.cloneIfPossible(extendedMessageFormat6);
        extendedMessageFormat6.applyPattern("org.apache.commons.lang3.exception.CloneFailedException: hi!");
        java.text.Format[] formatArray10 = extendedMessageFormat6.getFormatsByArgumentIndex();
        org.junit.Assert.assertNotNull(extendedMessageFormat6);
        org.junit.Assert.assertNotNull(extendedMessageFormat7);
        org.junit.Assert.assertNotNull(formatArray10);
        org.junit.Assert.assertArrayEquals(formatArray10, new java.text.Format[] {});
    }

    @Test
    public void test1543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1543");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("10", locale1);
        java.util.Locale locale4 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat5 = new org.apache.commons.lang3.text.ExtendedMessageFormat("55", locale4);
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat6 = org.apache.commons.lang3.ObjectUtils.defaultIfNull(extendedMessageFormat2, extendedMessageFormat5);
        java.text.Format[] formatArray7 = extendedMessageFormat5.getFormats();
        java.text.ParsePosition parsePosition9 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = extendedMessageFormat5.parseObject("7", parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(extendedMessageFormat6);
        org.junit.Assert.assertNotNull(formatArray7);
        org.junit.Assert.assertArrayEquals(formatArray7, new java.text.Format[] {});
    }

    @Test
    public void test1544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1544");
        java.util.Locale locale3 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat4 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale3);
        java.lang.Object[] objArray6 = extendedMessageFormat4.parse("hi!");
        extendedMessageFormat4.applyPattern("10");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher10 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher12 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher14 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher16 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher18 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray19 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher10, stringMatcher12, stringMatcher14, stringMatcher16, stringMatcher18 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray20 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray19);
        boolean boolean21 = extendedMessageFormat4.equals((java.lang.Object) stringMatcherArray19);
        java.text.Format[] formatArray22 = extendedMessageFormat4.getFormatsByArgumentIndex();
        org.apache.commons.lang3.Validate.validState(true, "org.apache.commons.lang3.exception.CloneFailedException: hi!", (java.lang.Object[]) formatArray22);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertArrayEquals(objArray6, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray19);
        org.junit.Assert.assertNotNull(stringMatcherArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(formatArray22);
        org.junit.Assert.assertArrayEquals(formatArray22, new java.text.Format[] {});
    }

    @Test
    public void test1545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test1545");
        java.util.Locale locale1 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat2 = new org.apache.commons.lang3.text.ExtendedMessageFormat("org.apache.commons.lang3.exception.CloneFailedException: hi!", locale1);
        java.lang.String str3 = org.apache.commons.lang3.ObjectUtils.identityToString((java.lang.Object) extendedMessageFormat2);
        java.util.Locale locale5 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat6 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale5);
        java.lang.Object[] objArray8 = extendedMessageFormat6.parse("hi!");
        extendedMessageFormat6.applyPattern("10");
        java.util.Locale locale12 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat13 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale12);
        extendedMessageFormat13.applyPattern("10");
        java.util.Locale locale17 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat18 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale17);
        java.util.Locale locale20 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat21 = new org.apache.commons.lang3.text.ExtendedMessageFormat("", locale20);
        java.util.Locale locale23 = null;
        org.apache.commons.lang3.text.ExtendedMessageFormat extendedMessageFormat24 = new org.apache.commons.lang3.text.ExtendedMessageFormat("hi!", locale23);
        java.lang.Object[] objArray26 = extendedMessageFormat24.parse("hi!");
        extendedMessageFormat24.applyPattern("10");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher30 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher32 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher34 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher36 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher stringMatcher38 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher("hi!");
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray39 = new org.apache.commons.lang3.text.StrMatcher.StringMatcher[] { stringMatcher30, stringMatcher32, stringMatcher34, stringMatcher36, stringMatcher38 };
        org.apache.commons.lang3.text.StrMatcher.StringMatcher[] stringMatcherArray40 = org.apache.commons.lang3.Validate.notEmpty(stringMatcherArray39);
        boolean boolean41 = extendedMessageFormat24.equals((java.lang.Object) stringMatcherArray39);
        java.text.MessageFormat[] messageFormatArray42 = new java.text.MessageFormat[] { extendedMessageFormat6, extendedMessageFormat13, extendedMessageFormat18, extendedMessageFormat21, extendedMessageFormat24 };
        java.text.MessageFormat messageFormat43 = org.apache.commons.lang3.ObjectUtils.firstNonNull(messageFormatArray42);
        java.text.Format[] formatArray44 = messageFormat43.getFormatsByArgumentIndex();
        boolean boolean45 = extendedMessageFormat2.equals((java.lang.Object) messageFormat43);
        java.text.Format[] formatArray46 = extendedMessageFormat2.getFormatsByArgumentIndex();
        java.util.Locale locale47 = extendedMessageFormat2.getLocale();
        boolean boolean49 = org.apache.commons.lang3.ObjectUtils.notEqual((java.lang.Object) extendedMessageFormat2, (java.lang.Object) (-3));
        java.text.Format[] formatArray50 = extendedMessageFormat2.getFormatsByArgumentIndex();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj52 = extendedMessageFormat2.parseObject("org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: org.apache.commons.lang3.exception.CloneFailedException: hi!");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertArrayEquals(objArray8, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertArrayEquals(objArray26, new java.lang.Object[] {});
        org.junit.Assert.assertNotNull(stringMatcherArray39);
        org.junit.Assert.assertNotNull(stringMatcherArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(messageFormatArray42);
        org.junit.Assert.assertNotNull(messageFormat43);
        org.junit.Assert.assertNotNull(formatArray44);
        org.junit.Assert.assertArrayEquals(formatArray44, new java.text.Format[] {});
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(formatArray46);
        org.junit.Assert.assertArrayEquals(formatArray46, new java.text.Format[] {});
        org.junit.Assert.assertNull(locale47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(formatArray50);
        org.junit.Assert.assertArrayEquals(formatArray50, new java.text.Format[] {});
    }
}

