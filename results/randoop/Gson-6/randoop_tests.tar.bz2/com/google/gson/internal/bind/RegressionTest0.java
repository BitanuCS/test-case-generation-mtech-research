package com.google.gson.internal.bind;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    public void assertBooleanArrayEquals(boolean[] expectedArray, boolean[] actualArray) {
        if (expectedArray.length != actualArray.length) {
            throw new AssertionError("Array lengths differ: " + expectedArray.length + " != " + actualArray.length);
        }
        for (int i = 0; i < expectedArray.length; i++) {
            if (expectedArray[i] != actualArray[i]) {
                throw new AssertionError("Arrays differ at index " + i + ": " + expectedArray[i] + " != " + actualArray[i]);
            }
        }
    }

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable2 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) (-1.0d), appendable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonElement jsonElement1 = null;
        com.google.gson.stream.JsonWriter jsonWriter2 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson(jsonElement1, jsonWriter2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter4 = jsonWriter3.beginArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter1 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement2 = null;
        com.google.gson.JsonElement jsonElement3 = jsonElementTypeAdapter1.toJsonTree(jsonElement2);
        com.google.gson.JsonNull jsonNull4 = jsonElement3.getAsJsonNull();
        java.lang.String str5 = jsonElement3.toString();
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        java.lang.Appendable appendable7 = null;
        java.io.Writer writer8 = com.google.gson.internal.Streams.writerForAppendable(appendable7);
        com.google.gson.stream.JsonWriter jsonWriter9 = gson6.newJsonWriter(writer8);
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson(jsonElement3, (java.lang.Appendable) writer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter1);
        org.junit.Assert.assertNotNull(jsonElement3);
        org.junit.Assert.assertNotNull(jsonNull4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertNotNull(writer8);
        org.junit.Assert.assertNotNull(jsonWriter9);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        java.lang.reflect.Type type5 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str6 = gson0.toJson((java.lang.Object) '#', type5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter5 = jsonWriter3.jsonValue("");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter4 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement5 = null;
        com.google.gson.JsonElement jsonElement6 = jsonElementTypeAdapter4.toJsonTree(jsonElement5);
        com.google.gson.JsonNull jsonNull7 = jsonElement6.getAsJsonNull();
        boolean boolean8 = jsonNull7.isJsonPrimitive();
        java.lang.Appendable appendable9 = null;
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonNull7, appendable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter4);
        org.junit.Assert.assertNotNull(jsonElement6);
        org.junit.Assert.assertNotNull(jsonNull7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter5 = jsonWriter3.value(100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.value((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.io.Reader reader1 = null;
        com.google.gson.LongSerializationPolicy longSerializationPolicy2 = com.google.gson.LongSerializationPolicy.STRING;
        java.lang.Class<?> wildcardClass3 = longSerializationPolicy2.getClass();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonIOException jsonIOException4 = gson0.fromJson(reader1, (java.lang.reflect.Type) wildcardClass3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(longSerializationPolicy2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter0 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.Gson gson1 = new com.google.gson.Gson();
        java.lang.Appendable appendable2 = null;
        java.io.Writer writer3 = com.google.gson.internal.Streams.writerForAppendable(appendable2);
        com.google.gson.stream.JsonWriter jsonWriter4 = gson1.newJsonWriter(writer3);
        java.sql.Time time5 = null;
        // The following exception was thrown during execution in test generation
        try {
            timeTypeAdapter0.write(jsonWriter4, time5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer3);
        org.junit.Assert.assertNotNull(jsonWriter4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        java.lang.Appendable appendable3 = null;
        java.io.Writer writer4 = com.google.gson.internal.Streams.writerForAppendable(appendable3);
        com.google.gson.stream.JsonWriter jsonWriter5 = gson2.newJsonWriter(writer4);
        jsonWriter5.setHtmlSafe(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonPrimitive1, jsonWriter5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer4);
        org.junit.Assert.assertNotNull(jsonWriter5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter0 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.Gson gson1 = new com.google.gson.Gson();
        java.lang.Appendable appendable2 = null;
        java.io.Writer writer3 = com.google.gson.internal.Streams.writerForAppendable(appendable2);
        com.google.gson.stream.JsonWriter jsonWriter4 = gson1.newJsonWriter(writer3);
        jsonWriter4.setHtmlSafe(true);
        jsonWriter4.setHtmlSafe(true);
        jsonWriter4.setLenient(true);
        java.sql.Time time11 = null;
        // The following exception was thrown during execution in test generation
        try {
            timeTypeAdapter0.write(jsonWriter4, time11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer3);
        org.junit.Assert.assertNotNull(jsonWriter4);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter8 = jsonWriter3.beginObject();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setLenient(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter13 = jsonWriter3.jsonValue(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy4 = com.google.gson.LongSerializationPolicy.STRING;
        java.lang.Class<?> wildcardClass5 = longSerializationPolicy4.getClass();
        com.google.gson.LongSerializationPolicy longSerializationPolicy6 = com.google.gson.LongSerializationPolicy.STRING;
        java.lang.Class<?> wildcardClass7 = longSerializationPolicy6.getClass();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) wildcardClass5, (java.lang.reflect.Type) wildcardClass7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: class java.lang.Class cannot be cast to class java.lang.Enum (java.lang.Class and java.lang.Enum are in module java.base of loader 'bootstrap')");
        } catch (java.lang.ClassCastException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(longSerializationPolicy4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(longSerializationPolicy6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setLenient(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter3.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter4 = jsonWriter3.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter4 = jsonWriter3.beginObject();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setLenient(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter3.beginObject();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setSerializeNulls(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter15 = jsonWriter3.value(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.gson.internal.ConstructorConstructor constructorConstructor0 = null;
        com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory jsonAdapterAnnotationTypeAdapterFactory1 = new com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory(constructorConstructor0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        java.lang.Appendable appendable9 = null;
        java.io.Writer writer10 = com.google.gson.internal.Streams.writerForAppendable(appendable9);
        com.google.gson.stream.JsonWriter jsonWriter11 = gson8.newJsonWriter(writer10);
        jsonWriter11.setHtmlSafe(true);
        jsonWriter11.setHtmlSafe(true);
        jsonWriter11.setSerializeNulls(true);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter18 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date19 = null;
        com.google.gson.JsonElement jsonElement20 = sqlDateTypeAdapter18.toJsonTree(date19);
        // The following exception was thrown during execution in test generation
        try {
            fieldNamingPolicyArrayTypeAdapter6.write(jsonWriter11, (java.lang.Object) date19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(writer10);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonElement20);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.value((java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter5 = jsonWriter3.value(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setSerializeNulls(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter11 = jsonWriter3.value(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        java.lang.Appendable appendable3 = null;
        java.io.Writer writer4 = com.google.gson.internal.Streams.writerForAppendable(appendable3);
        com.google.gson.stream.JsonWriter jsonWriter5 = gson2.newJsonWriter(writer4);
        jsonWriter5.setHtmlSafe(true);
        java.util.Date date8 = null;
        // The following exception was thrown during execution in test generation
        try {
            dateTypeAdapter0.write(jsonWriter5, date8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(writer4);
        org.junit.Assert.assertNotNull(jsonWriter5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        // The following exception was thrown during execution in test generation
        try {
            long long9 = jsonElement8.getAsLong();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: JsonNull");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setIndent(" ");
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter6 = jsonWriter3.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter7 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson3, fieldNamingPolicyTypeAdapter7, fieldNamingPolicyClass8);
        com.google.gson.TypeAdapterFactory typeAdapterFactory10 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement11 = gson3.toJsonTree((java.lang.Object) typeAdapterFactory10);
        java.util.Date date12 = dateTypeAdapter2.fromJsonTree(jsonElement11);
        com.google.gson.Gson gson13 = new com.google.gson.Gson();
        java.lang.Appendable appendable14 = null;
        java.io.Writer writer15 = com.google.gson.internal.Streams.writerForAppendable(appendable14);
        com.google.gson.stream.JsonWriter jsonWriter16 = gson13.newJsonWriter(writer15);
        java.util.Date date17 = null;
        // The following exception was thrown during execution in test generation
        try {
            dateTypeAdapter2.toJson(writer15, date17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(typeAdapterFactory10);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNull(date12);
        org.junit.Assert.assertNotNull(writer15);
        org.junit.Assert.assertNotNull(jsonWriter16);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        java.util.Date date2 = null;
        java.lang.String str3 = dateTypeAdapter0.toJson(date2);
        com.google.gson.Gson gson4 = new com.google.gson.Gson();
        java.lang.Appendable appendable5 = null;
        java.io.Writer writer6 = com.google.gson.internal.Streams.writerForAppendable(appendable5);
        com.google.gson.stream.JsonWriter jsonWriter7 = gson4.newJsonWriter(writer6);
        jsonWriter7.setHtmlSafe(true);
        jsonWriter7.setHtmlSafe(true);
        jsonWriter7.setLenient(true);
        java.util.Date date14 = null;
        // The following exception was thrown during execution in test generation
        try {
            dateTypeAdapter0.write(jsonWriter7, date14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "null" + "'", str3, "null");
        org.junit.Assert.assertNotNull(writer6);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.name("");
        // The following exception was thrown during execution in test generation
        try {
            jsonWriter3.close();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Incomplete document");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        java.lang.Appendable appendable9 = null;
        java.io.Writer writer10 = com.google.gson.internal.Streams.writerForAppendable(appendable9);
        com.google.gson.stream.JsonWriter jsonWriter11 = gson8.newJsonWriter(writer10);
        jsonWriter11.setHtmlSafe(true);
        jsonWriter11.setHtmlSafe(true);
        jsonWriter11.setLenient(true);
        com.google.gson.JsonArray jsonArray18 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor19 = jsonArray18.iterator();
        // The following exception was thrown during execution in test generation
        try {
            fieldNamingPolicyArrayTypeAdapter6.write(jsonWriter11, (java.lang.Object) jsonArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(writer10);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonElementItor19);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.name("");
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter8 = jsonWriter7.beginObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter7 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson3, fieldNamingPolicyTypeAdapter7, fieldNamingPolicyClass8);
        com.google.gson.TypeAdapterFactory typeAdapterFactory10 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement11 = gson3.toJsonTree((java.lang.Object) typeAdapterFactory10);
        java.util.Date date12 = dateTypeAdapter2.fromJsonTree(jsonElement11);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Class<?> wildcardClass13 = date12.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(typeAdapterFactory10);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNull(date12);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0d));
        java.lang.Number number11 = jsonPrimitive10.getAsNumber();
        java.lang.String str12 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive10);
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertEquals("'" + number11 + "' != '" + (-1.0d) + "'", number11, (-1.0d));
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "-1.0" + "'", str12, "-1.0");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = sqlDateTypeAdapter0.toJsonTree(date1);
        com.google.gson.JsonNull jsonNull3 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date4 = sqlDateTypeAdapter0.fromJsonTree((com.google.gson.JsonElement) jsonNull3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        java.lang.Appendable appendable6 = null;
        java.io.Writer writer7 = com.google.gson.internal.Streams.writerForAppendable(appendable6);
        com.google.gson.stream.JsonWriter jsonWriter8 = gson5.newJsonWriter(writer7);
        jsonWriter8.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter8.name("");
        java.sql.Date date13 = null;
        sqlDateTypeAdapter0.write(jsonWriter12, date13);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter15 = jsonWriter12.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonNull3);
        org.junit.Assert.assertNull(date4);
        org.junit.Assert.assertNotNull(writer7);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter12);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setIndent(" ");
        // The following exception was thrown during execution in test generation
        try {
            jsonWriter3.close();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Incomplete document");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        boolean boolean6 = jsonWriter3.isHtmlSafe();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter8 = jsonWriter3.value(10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setIndent(" ");
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.jsonValue("com.google.gson.JsonSyntaxException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.io.Reader reader1 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonReader jsonReader2 = gson0.newJsonReader(reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.Gson gson1 = new com.google.gson.Gson();
        java.lang.Appendable appendable2 = null;
        java.io.Writer writer3 = com.google.gson.internal.Streams.writerForAppendable(appendable2);
        com.google.gson.stream.JsonWriter jsonWriter4 = gson1.newJsonWriter(writer3);
        jsonWriter4.setIndent(" ");
        java.util.Date date7 = null;
        // The following exception was thrown during execution in test generation
        try {
            dateTypeAdapter0.write(jsonWriter4, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer3);
        org.junit.Assert.assertNotNull(jsonWriter4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setSerializeNulls(true);
        // The following exception was thrown during execution in test generation
        try {
            jsonWriter3.close();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Incomplete document");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setLenient(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter3.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.name("");
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter8 = jsonWriter7.beginArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter6 = jsonWriter3.beginArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter0 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.Gson gson1 = new com.google.gson.Gson();
        java.lang.Appendable appendable2 = null;
        java.io.Writer writer3 = com.google.gson.internal.Streams.writerForAppendable(appendable2);
        com.google.gson.stream.JsonWriter jsonWriter4 = gson1.newJsonWriter(writer3);
        jsonWriter4.setIndent(" ");
        java.sql.Time time7 = null;
        // The following exception was thrown during execution in test generation
        try {
            timeTypeAdapter0.write(jsonWriter4, time7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer3);
        org.junit.Assert.assertNotNull(jsonWriter4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.Gson gson1 = new com.google.gson.Gson();
        java.lang.Appendable appendable2 = null;
        java.io.Writer writer3 = com.google.gson.internal.Streams.writerForAppendable(appendable2);
        com.google.gson.stream.JsonWriter jsonWriter4 = gson1.newJsonWriter(writer3);
        jsonWriter4.setHtmlSafe(true);
        boolean boolean7 = jsonWriter4.isLenient();
        boolean boolean8 = jsonWriter4.isHtmlSafe();
        java.util.Date date9 = null;
        // The following exception was thrown during execution in test generation
        try {
            dateTypeAdapter0.write(jsonWriter4, date9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer3);
        org.junit.Assert.assertNotNull(jsonWriter4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.gson.internal.ObjectConstructor<java.lang.AutoCloseable> autoCloseableObjectConstructor0 = null;
        java.util.Map<java.lang.String, com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.BoundField> strMap1 = null;
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable> autoCloseableAdapter2 = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable>(autoCloseableObjectConstructor0, strMap1);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter3 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter4 = jsonTreeWriter3.nullValue();
        boolean boolean5 = jsonTreeWriter3.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter3.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter3.value((long) (byte) -1);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        com.google.gson.Gson gson11 = new com.google.gson.Gson();
        java.lang.Appendable appendable12 = null;
        java.io.Writer writer13 = com.google.gson.internal.Streams.writerForAppendable(appendable12);
        com.google.gson.stream.JsonWriter jsonWriter14 = gson11.newJsonWriter(writer13);
        jsonWriter14.setHtmlSafe(true);
        // The following exception was thrown during execution in test generation
        try {
            autoCloseableAdapter2.write(jsonWriter8, (java.lang.AutoCloseable) jsonWriter14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonWriter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(writer13);
        org.junit.Assert.assertNotNull(jsonWriter14);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        jsonWriter6.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter6.name("");
        jsonWriter10.setSerializeNulls(true);
        java.util.Date date13 = null;
        // The following exception was thrown during execution in test generation
        try {
            dateTypeAdapter0.write(jsonWriter10, date13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.gson.internal.ObjectConstructor<java.lang.AutoCloseable> autoCloseableObjectConstructor0 = null;
        java.util.Map<java.lang.String, com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.BoundField> strMap1 = null;
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable> autoCloseableAdapter2 = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable>(autoCloseableObjectConstructor0, strMap1);
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        jsonWriter6.setHtmlSafe(true);
        jsonWriter6.setHtmlSafe(true);
        jsonWriter6.setLenient(true);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter13 = new com.google.gson.internal.bind.JsonTreeWriter();
        // The following exception was thrown during execution in test generation
        try {
            autoCloseableAdapter2.write(jsonWriter6, (java.lang.AutoCloseable) jsonTreeWriter13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.name("");
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter9 = jsonWriter7.value((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement9 = null;
        com.google.gson.JsonElement jsonElement10 = jsonElementTypeAdapter8.toJsonTree(jsonElement9);
        com.google.gson.JsonNull jsonNull11 = jsonElement10.getAsJsonNull();
        boolean boolean12 = jsonNull11.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader13 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull11);
        com.google.gson.stream.JsonToken jsonToken14 = jsonTreeReader13.peek();
        java.lang.Object obj15 = fieldNamingPolicyArrayTypeAdapter6.read((com.google.gson.stream.JsonReader) jsonTreeReader13);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement16 = com.google.gson.internal.Streams.parse((com.google.gson.stream.JsonReader) jsonTreeReader13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter8);
        org.junit.Assert.assertNotNull(jsonElement10);
        org.junit.Assert.assertNotNull(jsonNull11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jsonToken14 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken14.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter0 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter1 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement2 = null;
        com.google.gson.JsonElement jsonElement3 = jsonElementTypeAdapter1.toJsonTree(jsonElement2);
        com.google.gson.JsonNull jsonNull4 = jsonElement3.getAsJsonNull();
        java.lang.String str5 = jsonElement3.toString();
        java.sql.Time time6 = timeTypeAdapter0.fromJsonTree(jsonElement3);
        java.sql.Time time7 = null;
        com.google.gson.JsonElement jsonElement8 = timeTypeAdapter0.toJsonTree(time7);
        com.google.gson.Gson gson9 = new com.google.gson.Gson();
        java.lang.Appendable appendable10 = null;
        java.io.Writer writer11 = com.google.gson.internal.Streams.writerForAppendable(appendable10);
        com.google.gson.stream.JsonWriter jsonWriter12 = gson9.newJsonWriter(writer11);
        jsonWriter12.setHtmlSafe(true);
        jsonWriter12.setHtmlSafe(true);
        java.sql.Time time17 = null;
        // The following exception was thrown during execution in test generation
        try {
            timeTypeAdapter0.write(jsonWriter12, time17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter1);
        org.junit.Assert.assertNotNull(jsonElement3);
        org.junit.Assert.assertNotNull(jsonNull4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertNull(time6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(writer11);
        org.junit.Assert.assertNotNull(jsonWriter12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = fieldNamingPolicyArrayTypeAdapter12.fromJson("JsonTreeReader");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        boolean boolean6 = jsonWriter3.isLenient();
        jsonWriter3.flush();
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        com.google.gson.stream.JsonWriter jsonWriter7 = new com.google.gson.stream.JsonWriter(writer5);
        java.util.Date date8 = null;
        // The following exception was thrown during execution in test generation
        try {
            dateTypeAdapter2.toJson(writer5, date8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter8 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date9 = null;
        com.google.gson.JsonElement jsonElement10 = sqlDateTypeAdapter8.toJsonTree(date9);
        java.sql.Date date11 = null;
        com.google.gson.JsonElement jsonElement12 = sqlDateTypeAdapter8.toJsonTree(date11);
        java.sql.Date date13 = null;
        java.lang.String str14 = sqlDateTypeAdapter8.toJson(date13);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter15 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement16 = null;
        com.google.gson.JsonElement jsonElement17 = jsonElementTypeAdapter15.toJsonTree(jsonElement16);
        com.google.gson.JsonNull jsonNull18 = jsonElement17.getAsJsonNull();
        boolean boolean19 = jsonNull18.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader20 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull18);
        com.google.gson.stream.JsonToken jsonToken21 = jsonTreeReader20.peek();
        java.sql.Date date22 = sqlDateTypeAdapter8.read((com.google.gson.stream.JsonReader) jsonTreeReader20);
        jsonTreeReader20.close();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj24 = fieldNamingPolicyArrayTypeAdapter6.read((com.google.gson.stream.JsonReader) jsonTreeReader20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JsonReader is closed");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonElement10);
        org.junit.Assert.assertNotNull(jsonElement12);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "null" + "'", str14, "null");
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter15);
        org.junit.Assert.assertNotNull(jsonElement17);
        org.junit.Assert.assertNotNull(jsonNull18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + jsonToken21 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken21.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertNull(date22);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter0 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter1 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement2 = null;
        com.google.gson.JsonElement jsonElement3 = jsonElementTypeAdapter1.toJsonTree(jsonElement2);
        com.google.gson.JsonNull jsonNull4 = jsonElement3.getAsJsonNull();
        java.lang.String str5 = jsonElement3.toString();
        java.sql.Time time6 = timeTypeAdapter0.fromJsonTree(jsonElement3);
        com.google.gson.Gson gson7 = new com.google.gson.Gson();
        java.lang.Appendable appendable8 = null;
        java.io.Writer writer9 = com.google.gson.internal.Streams.writerForAppendable(appendable8);
        com.google.gson.stream.JsonWriter jsonWriter10 = gson7.newJsonWriter(writer9);
        java.sql.Time time11 = null;
        // The following exception was thrown during execution in test generation
        try {
            timeTypeAdapter0.write(jsonWriter10, time11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter1);
        org.junit.Assert.assertNotNull(jsonElement3);
        org.junit.Assert.assertNotNull(jsonNull4);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "null" + "'", str5, "null");
        org.junit.Assert.assertNull(time6);
        org.junit.Assert.assertNotNull(writer9);
        org.junit.Assert.assertNotNull(jsonWriter10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.name("");
        jsonWriter7.setSerializeNulls(true);
        // The following exception was thrown during execution in test generation
        try {
            jsonWriter7.close();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Incomplete document");
        } catch (java.io.IOException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.gson.JsonNull jsonNull0 = com.google.gson.JsonNull.INSTANCE;
        com.google.gson.Gson gson1 = new com.google.gson.Gson();
        java.lang.Appendable appendable2 = null;
        java.io.Writer writer3 = com.google.gson.internal.Streams.writerForAppendable(appendable2);
        com.google.gson.stream.JsonWriter jsonWriter4 = gson1.newJsonWriter(writer3);
        jsonWriter4.setHtmlSafe(true);
        jsonWriter4.setHtmlSafe(true);
        jsonWriter4.setLenient(true);
        jsonWriter4.setLenient(true);
        jsonWriter4.setSerializeNulls(true);
        boolean boolean15 = jsonWriter4.getSerializeNulls();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonNull0, jsonWriter4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonNull0);
        org.junit.Assert.assertNotNull(writer3);
        org.junit.Assert.assertNotNull(jsonWriter4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.JsonNull jsonNull8 = com.google.gson.JsonNull.INSTANCE;
        java.lang.Object obj9 = null;
        boolean boolean10 = jsonNull8.equals(obj9);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement11 = objTypeAdapter7.toJsonTree((java.lang.Object) boolean10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonNull8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.stream.JsonReader jsonReader7 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = fieldNamingPolicyArrayTypeAdapter6.read(jsonReader7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement8 = fieldNamingPolicyArrayTypeAdapter6.toJsonTree((java.lang.Object) "com.google.gson.JsonParseException: com.google.gson.JsonSyntaxException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter9 = jsonWriter3.value("com.google.gson.JsonSyntaxException: com.google.gson.JsonSyntaxException: hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.stream.JsonWriter jsonWriter4 = new com.google.gson.stream.JsonWriter(writer2);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter6 = jsonWriter4.value("com.google.gson.JsonIOException: true");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        java.lang.Appendable appendable9 = null;
        java.io.Writer writer10 = com.google.gson.internal.Streams.writerForAppendable(appendable9);
        com.google.gson.stream.JsonWriter jsonWriter11 = gson8.newJsonWriter(writer10);
        jsonWriter11.setHtmlSafe(true);
        jsonWriter11.setHtmlSafe(true);
        jsonWriter11.setLenient(true);
        com.google.gson.JsonObject jsonObject18 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray20 = jsonObject18.getAsJsonArray("");
        com.google.gson.JsonElement jsonElement22 = jsonObject18.remove("4");
        // The following exception was thrown during execution in test generation
        try {
            fieldNamingPolicyArrayTypeAdapter6.write(jsonWriter11, (java.lang.Object) jsonElement22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(writer10);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNull(jsonArray20);
        org.junit.Assert.assertNull(jsonElement22);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.JsonElement jsonElement7 = null;
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader8 = new com.google.gson.internal.bind.JsonTreeReader(jsonElement7);
        jsonTreeReader8.close();
        boolean boolean10 = jsonTreeReader8.isLenient();
        jsonTreeReader8.close();
        java.lang.String str12 = jsonTreeReader8.toString();
        java.lang.String str13 = jsonTreeReader8.getPath();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = fieldNamingPolicyArrayTypeAdapter6.read((com.google.gson.stream.JsonReader) jsonTreeReader8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JsonReader is closed");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "JsonTreeReader" + "'", str12, "JsonTreeReader");
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "$" + "'", str13, "$");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.name("");
        jsonWriter7.setSerializeNulls(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter7.nullValue();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement9 = null;
        com.google.gson.JsonElement jsonElement10 = jsonElementTypeAdapter8.toJsonTree(jsonElement9);
        com.google.gson.JsonNull jsonNull11 = jsonElement10.getAsJsonNull();
        boolean boolean12 = jsonNull11.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader13 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull11);
        com.google.gson.stream.JsonToken jsonToken14 = jsonTreeReader13.peek();
        java.lang.Object obj15 = fieldNamingPolicyArrayTypeAdapter6.read((com.google.gson.stream.JsonReader) jsonTreeReader13);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str16 = jsonTreeReader13.nextName();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NAME but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter8);
        org.junit.Assert.assertNotNull(jsonElement10);
        org.junit.Assert.assertNotNull(jsonNull11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jsonToken14 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken14.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        java.io.Writer writer13 = null;
        com.google.gson.Gson gson14 = new com.google.gson.Gson();
        java.lang.Appendable appendable15 = null;
        java.io.Writer writer16 = com.google.gson.internal.Streams.writerForAppendable(appendable15);
        com.google.gson.stream.JsonWriter jsonWriter17 = gson14.newJsonWriter(writer16);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter18 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass19 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter20 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson14, fieldNamingPolicyTypeAdapter18, fieldNamingPolicyClass19);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter21 = fieldNamingPolicyArrayTypeAdapter20.nullSafe();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter22 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement23 = null;
        com.google.gson.JsonElement jsonElement24 = jsonElementTypeAdapter22.toJsonTree(jsonElement23);
        com.google.gson.JsonNull jsonNull25 = jsonElement24.getAsJsonNull();
        boolean boolean26 = jsonNull25.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader27 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull25);
        com.google.gson.stream.JsonToken jsonToken28 = jsonTreeReader27.peek();
        java.lang.Object obj29 = fieldNamingPolicyArrayTypeAdapter20.read((com.google.gson.stream.JsonReader) jsonTreeReader27);
        // The following exception was thrown during execution in test generation
        try {
            fieldNamingPolicyArrayTypeAdapter12.toJson(writer13, (java.lang.Object) fieldNamingPolicyArrayTypeAdapter20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(writer16);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(objTypeAdapter21);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter22);
        org.junit.Assert.assertNotNull(jsonElement24);
        org.junit.Assert.assertNotNull(jsonNull25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + jsonToken28 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken28.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertNull(obj29);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = sqlDateTypeAdapter0.toJsonTree(date1);
        com.google.gson.JsonNull jsonNull3 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date4 = sqlDateTypeAdapter0.fromJsonTree((com.google.gson.JsonElement) jsonNull3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        java.lang.Appendable appendable6 = null;
        java.io.Writer writer7 = com.google.gson.internal.Streams.writerForAppendable(appendable6);
        com.google.gson.stream.JsonWriter jsonWriter8 = gson5.newJsonWriter(writer7);
        jsonWriter8.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter8.name("");
        java.sql.Date date13 = null;
        sqlDateTypeAdapter0.write(jsonWriter12, date13);
        com.google.gson.JsonObject jsonObject15 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray17 = jsonObject15.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter18.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject15, (com.google.gson.stream.JsonWriter) jsonTreeWriter18);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter18.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter18.endArray();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter18.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter18.endObject();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter18.value((long) 10);
        jsonTreeWriter18.setSerializeNulls(true);
        java.sql.Date date29 = null;
        sqlDateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter18, date29);
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter18.value((java.lang.Number) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter33 = jsonWriter32.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonNull3);
        org.junit.Assert.assertNull(date4);
        org.junit.Assert.assertNotNull(writer7);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNull(jsonArray17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertNotNull(jsonWriter32);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setLenient(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter3.nullValue();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement9 = null;
        com.google.gson.JsonElement jsonElement10 = jsonElementTypeAdapter8.toJsonTree(jsonElement9);
        com.google.gson.JsonNull jsonNull11 = jsonElement10.getAsJsonNull();
        boolean boolean12 = jsonNull11.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader13 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull11);
        com.google.gson.stream.JsonToken jsonToken14 = jsonTreeReader13.peek();
        java.lang.Object obj15 = fieldNamingPolicyArrayTypeAdapter6.read((com.google.gson.stream.JsonReader) jsonTreeReader13);
        java.lang.String str16 = jsonTreeReader13.toString();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement17 = com.google.gson.internal.Streams.parse((com.google.gson.stream.JsonReader) jsonTreeReader13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter8);
        org.junit.Assert.assertNotNull(jsonElement10);
        org.junit.Assert.assertNotNull(jsonNull11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jsonToken14 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken14.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "JsonTreeReader" + "'", str16, "JsonTreeReader");
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter7 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson3, fieldNamingPolicyTypeAdapter7, fieldNamingPolicyClass8);
        com.google.gson.TypeAdapterFactory typeAdapterFactory10 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement11 = gson3.toJsonTree((java.lang.Object) typeAdapterFactory10);
        java.util.Date date12 = dateTypeAdapter2.fromJsonTree(jsonElement11);
        java.util.Date date13 = null;
        java.lang.String str14 = dateTypeAdapter2.toJson(date13);
        java.util.Date date15 = null;
        java.lang.String str16 = dateTypeAdapter2.toJson(date15);
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter17 = dateTypeAdapter2.nullSafe();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter19 = dateTypeAdapter18.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter20 = dateTypeAdapter18.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter21 = dateTypeAdapter20.nullSafe();
        java.util.Date date22 = null;
        com.google.gson.JsonElement jsonElement23 = dateTypeAdapter20.toJsonTree(date22);
        java.util.Date date24 = dateTypeAdapter2.fromJsonTree(jsonElement23);
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(typeAdapterFactory10);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNull(date12);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "null" + "'", str14, "null");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertNotNull(dateTypeAdapter17);
        org.junit.Assert.assertNotNull(dateTypeAdapter19);
        org.junit.Assert.assertNotNull(dateTypeAdapter20);
        org.junit.Assert.assertNotNull(dateTypeAdapter21);
        org.junit.Assert.assertNotNull(jsonElement23);
        org.junit.Assert.assertNull(date24);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.math.BigInteger bigInteger9 = jsonPrimitive8.getAsBigInteger();
        boolean boolean11 = jsonPrimitive8.equals((java.lang.Object) (byte) -1);
        java.lang.Appendable appendable12 = null;
        java.io.Writer writer13 = com.google.gson.internal.Streams.writerForAppendable(appendable12);
        java.io.Writer writer14 = com.google.gson.internal.Streams.writerForAppendable((java.lang.Appendable) writer13);
        java.io.Writer writer15 = com.google.gson.internal.Streams.writerForAppendable((java.lang.Appendable) writer14);
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive8, (java.lang.Appendable) writer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(writer13);
        org.junit.Assert.assertNotNull(writer14);
        org.junit.Assert.assertNotNull(writer15);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.gson.Gson gson0 = null;
        com.google.gson.internal.bind.ObjectTypeAdapter objectTypeAdapter1 = new com.google.gson.internal.bind.ObjectTypeAdapter(gson0);
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        java.lang.Appendable appendable3 = null;
        java.io.Writer writer4 = com.google.gson.internal.Streams.writerForAppendable(appendable3);
        com.google.gson.stream.JsonWriter jsonWriter5 = gson2.newJsonWriter(writer4);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter6 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson2, fieldNamingPolicyTypeAdapter6, fieldNamingPolicyClass7);
        com.google.gson.TypeAdapterFactory typeAdapterFactory9 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement10 = gson2.toJsonTree((java.lang.Object) typeAdapterFactory9);
        java.lang.String str11 = gson2.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter12 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass13 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter14 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson2, fieldNamingPolicyTypeAdapter12, fieldNamingPolicyClass13);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter15 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass16 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter17 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson2, fieldNamingPolicyTypeAdapter15, fieldNamingPolicyClass16);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement18 = objectTypeAdapter1.toJsonTree((java.lang.Object) gson2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer4);
        org.junit.Assert.assertNotNull(jsonWriter5);
        org.junit.Assert.assertNotNull(typeAdapterFactory9);
        org.junit.Assert.assertNotNull(jsonElement10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.JsonElement jsonElement8 = null;
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader9 = new com.google.gson.internal.bind.JsonTreeReader(jsonElement8);
        jsonTreeReader9.close();
        boolean boolean11 = jsonTreeReader9.isLenient();
        jsonTreeReader9.close();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = fieldNamingPolicyArrayTypeAdapter6.read((com.google.gson.stream.JsonReader) jsonTreeReader9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JsonReader is closed");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter16 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement17 = null;
        com.google.gson.JsonElement jsonElement18 = jsonElementTypeAdapter16.toJsonTree(jsonElement17);
        com.google.gson.JsonPrimitive jsonPrimitive20 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        java.lang.String str21 = jsonElementTypeAdapter16.toJson((com.google.gson.JsonElement) jsonPrimitive20);
        boolean boolean22 = jsonPrimitive20.isJsonObject();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = fieldNamingPolicyArrayTypeAdapter15.fromJsonTree((com.google.gson.JsonElement) jsonPrimitive20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BOOLEAN");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter16);
        org.junit.Assert.assertNotNull(jsonElement18);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "true" + "'", str21, "true");
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.name("");
        jsonWriter7.setHtmlSafe(false);
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.gson.internal.ObjectConstructor<java.lang.AutoCloseable> autoCloseableObjectConstructor0 = null;
        java.util.Map<java.lang.String, com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.BoundField> strMap1 = null;
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable> autoCloseableAdapter2 = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable>(autoCloseableObjectConstructor0, strMap1);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter3 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter4 = jsonTreeWriter3.nullValue();
        boolean boolean5 = jsonTreeWriter3.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter3.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter3.value((long) (byte) -1);
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter8.value(true);
        java.lang.AutoCloseable autoCloseable11 = null;
        autoCloseableAdapter2.write(jsonWriter8, autoCloseable11);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter13 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter13.nullValue();
        boolean boolean15 = jsonTreeWriter13.isHtmlSafe();
        com.google.gson.Gson gson16 = new com.google.gson.Gson();
        java.lang.Appendable appendable17 = null;
        java.io.Writer writer18 = com.google.gson.internal.Streams.writerForAppendable(appendable17);
        com.google.gson.stream.JsonWriter jsonWriter19 = gson16.newJsonWriter(writer18);
        jsonWriter19.setHtmlSafe(true);
        boolean boolean22 = jsonWriter19.isLenient();
        // The following exception was thrown during execution in test generation
        try {
            autoCloseableAdapter2.write((com.google.gson.stream.JsonWriter) jsonTreeWriter13, (java.lang.AutoCloseable) jsonWriter19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonWriter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter10);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(writer18);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.gson.internal.ObjectConstructor<java.lang.AutoCloseable> autoCloseableObjectConstructor0 = null;
        java.util.Map<java.lang.String, com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.BoundField> strMap1 = null;
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable> autoCloseableAdapter2 = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable>(autoCloseableObjectConstructor0, strMap1);
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        jsonWriter6.setHtmlSafe(true);
        jsonWriter6.setHtmlSafe(true);
        jsonWriter6.setLenient(true);
        com.google.gson.JsonObject jsonObject13 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray15 = jsonObject13.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter16 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter16.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject13, (com.google.gson.stream.JsonWriter) jsonTreeWriter16);
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter16.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter20 = jsonTreeWriter16.endArray();
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter16.beginObject();
        // The following exception was thrown during execution in test generation
        try {
            autoCloseableAdapter2.write(jsonWriter6, (java.lang.AutoCloseable) jsonWriter21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNull(jsonArray15);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter20);
        org.junit.Assert.assertNotNull(jsonWriter21);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter7 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson3, fieldNamingPolicyTypeAdapter7, fieldNamingPolicyClass8);
        com.google.gson.TypeAdapterFactory typeAdapterFactory10 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement11 = gson3.toJsonTree((java.lang.Object) typeAdapterFactory10);
        java.util.Date date12 = dateTypeAdapter2.fromJsonTree(jsonElement11);
        java.util.Date date13 = null;
        java.lang.String str14 = dateTypeAdapter2.toJson(date13);
        java.util.Date date15 = null;
        java.lang.String str16 = dateTypeAdapter2.toJson(date15);
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter17 = dateTypeAdapter2.nullSafe();
        java.util.Date date19 = dateTypeAdapter2.fromJson("null");
        // The following exception was thrown during execution in test generation
        try {
            java.util.Date date21 = dateTypeAdapter2.fromJson("com.google.gson.JsonSyntaxException: []");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(typeAdapterFactory10);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNull(date12);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "null" + "'", str14, "null");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertNotNull(dateTypeAdapter17);
        org.junit.Assert.assertNull(date19);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        com.google.gson.stream.JsonReader jsonReader16 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = fieldNamingPolicyArrayTypeAdapter15.read(jsonReader16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter0 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean3 = jsonPrimitive2.isJsonNull();
        com.google.gson.JsonElement jsonElement4 = jsonElementTypeAdapter0.toJsonTree((com.google.gson.JsonElement) jsonPrimitive2);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        java.lang.Appendable appendable6 = null;
        java.io.Writer writer7 = com.google.gson.internal.Streams.writerForAppendable(appendable6);
        com.google.gson.stream.JsonWriter jsonWriter8 = gson5.newJsonWriter(writer7);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter9 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson5, fieldNamingPolicyTypeAdapter9, fieldNamingPolicyClass10);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter12 = fieldNamingPolicyArrayTypeAdapter11.nullSafe();
        java.lang.Throwable throwable15 = null;
        com.google.gson.JsonSyntaxException jsonSyntaxException16 = new com.google.gson.JsonSyntaxException("", throwable15);
        java.lang.Throwable[] throwableArray17 = jsonSyntaxException16.getSuppressed();
        com.google.gson.stream.MalformedJsonException malformedJsonException18 = new com.google.gson.stream.MalformedJsonException("{\"com.google.gson.JsonParseException: \":\"a\"}", (java.lang.Throwable) jsonSyntaxException16);
        java.lang.Throwable[] throwableArray19 = malformedJsonException18.getSuppressed();
        com.google.gson.JsonElement jsonElement20 = objTypeAdapter12.toJsonTree((java.lang.Object) throwableArray19);
        java.lang.String str21 = jsonElementTypeAdapter0.toJson(jsonElement20);
        java.lang.String str22 = jsonElement20.toString();
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(writer7);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(objTypeAdapter12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertArrayEquals(throwableArray17, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertArrayEquals(throwableArray19, new java.lang.Throwable[] {});
        org.junit.Assert.assertNotNull(jsonElement20);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "[]" + "'", str21, "[]");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "[]" + "'", str22, "[]");
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.math.BigInteger bigInteger2 = jsonPrimitive1.getAsBigInteger();
        java.lang.Number number3 = jsonPrimitive1.getAsNumber();
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        com.google.gson.internal.Excluder excluder5 = new com.google.gson.internal.Excluder();
        boolean boolean6 = jsonArray4.equals((java.lang.Object) excluder5);
        boolean boolean7 = jsonPrimitive1.equals((java.lang.Object) jsonArray4);
        com.google.gson.JsonPrimitive jsonPrimitive8 = jsonPrimitive1.getAsJsonPrimitive();
        double double9 = jsonPrimitive8.getAsDouble();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter10 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date11 = null;
        com.google.gson.JsonElement jsonElement12 = sqlDateTypeAdapter10.toJsonTree(date11);
        com.google.gson.JsonNull jsonNull13 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date14 = sqlDateTypeAdapter10.fromJsonTree((com.google.gson.JsonElement) jsonNull13);
        com.google.gson.Gson gson15 = new com.google.gson.Gson();
        java.lang.Appendable appendable16 = null;
        java.io.Writer writer17 = com.google.gson.internal.Streams.writerForAppendable(appendable16);
        com.google.gson.stream.JsonWriter jsonWriter18 = gson15.newJsonWriter(writer17);
        jsonWriter18.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonWriter18.name("");
        java.sql.Date date23 = null;
        sqlDateTypeAdapter10.write(jsonWriter22, date23);
        boolean boolean25 = jsonPrimitive8.equals((java.lang.Object) sqlDateTypeAdapter10);
        // The following exception was thrown during execution in test generation
        try {
            java.sql.Date date27 = sqlDateTypeAdapter10.fromJson("? extends com.google.gson.LongSerializationPolicy$2");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(number3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jsonPrimitive8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(jsonElement12);
        org.junit.Assert.assertNotNull(jsonNull13);
        org.junit.Assert.assertNull(date14);
        org.junit.Assert.assertNotNull(writer17);
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.lang.String str3 = jsonPrimitive2.getAsString();
        double double4 = jsonPrimitive2.getAsDouble();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy6 = com.google.gson.LongSerializationPolicy.DEFAULT;
        com.google.gson.JsonElement jsonElement8 = longSerializationPolicy6.serialize((java.lang.Long) 1L);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy6);
        // The following exception was thrown during execution in test generation
        try {
            java.math.BigDecimal bigDecimal10 = jsonElement9.getAsBigDecimal();
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Character D is neither a decimal digit number, decimal point, nor \"e\" notation exponential mark.");
        } catch (java.lang.NumberFormatException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "4" + "'", str3, "4");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "\"4\"" + "'", str5, "\"4\"");
        org.junit.Assert.assertNotNull(longSerializationPolicy6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setSerializeNulls(true);
        boolean boolean10 = jsonWriter3.isHtmlSafe();
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        java.lang.Object obj16 = null;
        com.google.gson.JsonElement jsonElement17 = fieldNamingPolicyArrayTypeAdapter15.toJsonTree(obj16);
        java.io.Reader reader18 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = fieldNamingPolicyArrayTypeAdapter15.fromJson(reader18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement17);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter7 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson3, fieldNamingPolicyTypeAdapter7, fieldNamingPolicyClass8);
        com.google.gson.TypeAdapterFactory typeAdapterFactory10 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement11 = gson3.toJsonTree((java.lang.Object) typeAdapterFactory10);
        java.util.Date date12 = dateTypeAdapter2.fromJsonTree(jsonElement11);
        java.util.Date date13 = null;
        java.lang.String str14 = dateTypeAdapter2.toJson(date13);
        java.util.Date date15 = null;
        java.lang.String str16 = dateTypeAdapter2.toJson(date15);
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter17 = dateTypeAdapter2.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter18 = dateTypeAdapter2.nullSafe();
        java.util.Date date19 = null;
        com.google.gson.JsonElement jsonElement20 = dateTypeAdapter2.toJsonTree(date19);
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(typeAdapterFactory10);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNull(date12);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "null" + "'", str14, "null");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertNotNull(dateTypeAdapter17);
        org.junit.Assert.assertNotNull(dateTypeAdapter18);
        org.junit.Assert.assertNotNull(jsonElement20);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray18 = jsonObject16.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter20 = jsonTreeWriter19.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject16, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter19.endArray();
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter19.value(false);
        com.google.gson.stream.JsonToken jsonToken26 = com.google.gson.stream.JsonToken.BEGIN_ARRAY;
        // The following exception was thrown during execution in test generation
        try {
            fieldNamingPolicyArrayTypeAdapter15.write(jsonWriter25, (java.lang.Object) jsonToken26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNull(jsonArray18);
        org.junit.Assert.assertNotNull(jsonWriter20);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertTrue("'" + jsonToken26 + "' != '" + com.google.gson.stream.JsonToken.BEGIN_ARRAY + "'", jsonToken26.equals(com.google.gson.stream.JsonToken.BEGIN_ARRAY));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        java.lang.Object obj16 = null;
        com.google.gson.JsonElement jsonElement17 = fieldNamingPolicyArrayTypeAdapter15.toJsonTree(obj16);
        com.google.gson.JsonElement jsonElement18 = null;
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader(jsonElement18);
        jsonTreeReader19.close();
        java.lang.String str21 = jsonTreeReader19.toString();
        java.lang.String str22 = jsonTreeReader19.toString();
        jsonTreeReader19.close();
        boolean boolean24 = jsonTreeReader19.isLenient();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj25 = fieldNamingPolicyArrayTypeAdapter15.read((com.google.gson.stream.JsonReader) jsonTreeReader19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JsonReader is closed");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement17);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "JsonTreeReader" + "'", str21, "JsonTreeReader");
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "JsonTreeReader" + "'", str22, "JsonTreeReader");
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        com.google.gson.JsonObject jsonObject9 = new com.google.gson.JsonObject();
        com.google.gson.JsonElement jsonElement11 = jsonObject9.get("hi!");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet12 = jsonObject9.entrySet();
        java.lang.String str13 = gson0.toJson((java.lang.Object) strEntrySet12);
        java.io.Reader reader14 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonReader jsonReader15 = gson0.newJsonReader(reader14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNull(jsonElement11);
        org.junit.Assert.assertNotNull(strEntrySet12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.JsonObject jsonObject13 = new com.google.gson.JsonObject();
        jsonObject13.addProperty("{\"com.google.gson.JsonParseException: \":\"a\"}", (java.lang.Character) '4');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = fieldNamingPolicyArrayTypeAdapter12.toJson((java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter13 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter13.nullValue();
        boolean boolean15 = jsonTreeWriter13.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter13.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter13.value((long) (byte) -1);
        jsonTreeWriter13.flush();
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter13.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter13.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter13.value("null");
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter13.value(0L);
        java.lang.Object obj28 = null;
        fieldNamingPolicyArrayTypeAdapter12.write((com.google.gson.stream.JsonWriter) jsonTreeWriter13, obj28);
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter13.value(0L);
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter31);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.name("");
        jsonWriter7.setSerializeNulls(true);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter11 = jsonWriter7.value((long) (short) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Nesting problem.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter8 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter8.nullValue();
        boolean boolean10 = jsonTreeWriter8.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter8.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter8.value((long) (byte) -1);
        jsonTreeWriter8.flush();
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter8.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter8.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter20 = jsonTreeWriter8.value("null");
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter8.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter8.value("null");
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter8.nullValue();
        com.google.gson.JsonObject jsonObject25 = new com.google.gson.JsonObject();
        com.google.gson.JsonElement jsonElement27 = jsonObject25.get("hi!");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet28 = jsonObject25.entrySet();
        // The following exception was thrown during execution in test generation
        try {
            fieldNamingPolicyArrayTypeAdapter6.write(jsonWriter24, (java.lang.Object) jsonObject25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter20);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNull(jsonElement27);
        org.junit.Assert.assertNotNull(strEntrySet28);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.gson.internal.ObjectConstructor<java.lang.AutoCloseable> autoCloseableObjectConstructor0 = null;
        java.util.Map<java.lang.String, com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.BoundField> strMap1 = null;
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable> autoCloseableAdapter2 = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.Adapter<java.lang.AutoCloseable>(autoCloseableObjectConstructor0, strMap1);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive5 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean6 = jsonPrimitive5.isJsonNull();
        com.google.gson.JsonElement jsonElement7 = jsonElementTypeAdapter3.toJsonTree((com.google.gson.JsonElement) jsonPrimitive5);
        com.google.gson.JsonObject jsonObject8 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray10 = jsonObject8.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter11 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonTreeWriter11.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject8, (com.google.gson.stream.JsonWriter) jsonTreeWriter11);
        com.google.gson.stream.JsonWriter jsonWriter15 = jsonTreeWriter11.value((java.lang.Number) (byte) -1);
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter11.value((double) 1);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter18 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement19 = null;
        com.google.gson.JsonElement jsonElement20 = jsonElementTypeAdapter18.toJsonTree(jsonElement19);
        com.google.gson.JsonNull jsonNull21 = jsonElement20.getAsJsonNull();
        boolean boolean22 = jsonNull21.isJsonPrimitive();
        boolean boolean23 = jsonNull21.isJsonArray();
        boolean boolean24 = jsonNull21.isJsonNull();
        com.google.gson.TypeAdapterFactory typeAdapterFactory25 = com.google.gson.internal.bind.TypeAdapters.ATOMIC_INTEGER_ARRAY_FACTORY;
        boolean boolean26 = jsonNull21.equals((java.lang.Object) typeAdapterFactory25);
        jsonElementTypeAdapter3.write((com.google.gson.stream.JsonWriter) jsonTreeWriter11, (com.google.gson.JsonElement) jsonNull21);
        com.google.gson.JsonElement jsonElement28 = jsonTreeWriter11.get();
        java.lang.AutoCloseable autoCloseable29 = null;
        autoCloseableAdapter2.write((com.google.gson.stream.JsonWriter) jsonTreeWriter11, autoCloseable29);
        com.google.gson.JsonObject jsonObject31 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray33 = jsonObject31.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter34 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter34.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject31, (com.google.gson.stream.JsonWriter) jsonTreeWriter34);
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter34.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter38 = jsonTreeWriter34.endArray();
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter34.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonTreeWriter34.endObject();
        com.google.gson.Gson gson41 = new com.google.gson.Gson();
        java.lang.Appendable appendable42 = null;
        java.io.Writer writer43 = com.google.gson.internal.Streams.writerForAppendable(appendable42);
        com.google.gson.stream.JsonWriter jsonWriter44 = gson41.newJsonWriter(writer43);
        jsonWriter44.setHtmlSafe(true);
        jsonWriter44.setHtmlSafe(true);
        // The following exception was thrown during execution in test generation
        try {
            autoCloseableAdapter2.write(jsonWriter40, (java.lang.AutoCloseable) jsonWriter44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(jsonElement7);
        org.junit.Assert.assertNull(jsonArray10);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNotNull(jsonWriter15);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter18);
        org.junit.Assert.assertNotNull(jsonElement20);
        org.junit.Assert.assertNotNull(jsonNull21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(typeAdapterFactory25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertNull(jsonArray33);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter37);
        org.junit.Assert.assertNotNull(jsonWriter38);
        org.junit.Assert.assertNotNull(jsonWriter39);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertNotNull(writer43);
        org.junit.Assert.assertNotNull(jsonWriter44);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        java.lang.Appendable appendable3 = null;
        java.io.Writer writer4 = com.google.gson.internal.Streams.writerForAppendable(appendable3);
        com.google.gson.stream.JsonWriter jsonWriter5 = gson2.newJsonWriter(writer4);
        jsonWriter5.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonWriter5.name("");
        com.google.gson.stream.JsonWriter jsonWriter10 = jsonWriter5.nullValue();
        java.util.Date date11 = null;
        // The following exception was thrown during execution in test generation
        try {
            dateTypeAdapter0.write(jsonWriter5, date11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(writer4);
        org.junit.Assert.assertNotNull(jsonWriter5);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonWriter10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor1 = jsonArray0.iterator();
        com.google.gson.JsonArray jsonArray2 = jsonArray0.getAsJsonArray();
        jsonArray2.add((java.lang.Boolean) true);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        com.google.gson.JsonElement jsonElement8 = jsonArray2.set(0, (com.google.gson.JsonElement) jsonPrimitive7);
        java.lang.String str9 = jsonArray2.getAsString();
        boolean boolean10 = jsonArray2.isJsonNull();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor11 = jsonArray2.iterator();
        com.google.gson.Gson gson13 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.lang.String str16 = jsonPrimitive15.getAsString();
        double double17 = jsonPrimitive15.getAsDouble();
        java.lang.String str18 = gson13.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        boolean boolean19 = jsonPrimitive15.isJsonNull();
        java.lang.String str20 = jsonPrimitive15.getAsString();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonElement jsonElement21 = jsonArray2.set((int) (byte) -1, (com.google.gson.JsonElement) jsonPrimitive15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index -1 out of bounds for length 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElementItor1);
        org.junit.Assert.assertNotNull(jsonArray2);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "hi!" + "'", str9, "hi!");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jsonElementItor11);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "4" + "'", str16, "4");
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "\"4\"" + "'", str18, "\"4\"");
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "4" + "'", str20, "4");
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter7 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson3, fieldNamingPolicyTypeAdapter7, fieldNamingPolicyClass8);
        com.google.gson.TypeAdapterFactory typeAdapterFactory10 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement11 = gson3.toJsonTree((java.lang.Object) typeAdapterFactory10);
        java.util.Date date12 = dateTypeAdapter2.fromJsonTree(jsonElement11);
        java.util.Date date13 = null;
        java.lang.String str14 = dateTypeAdapter2.toJson(date13);
        java.util.Date date15 = null;
        java.lang.String str16 = dateTypeAdapter2.toJson(date15);
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter17 = dateTypeAdapter2.nullSafe();
        java.util.Date date19 = dateTypeAdapter2.fromJson("null");
        // The following exception was thrown during execution in test generation
        try {
            java.util.Date date21 = dateTypeAdapter2.fromJson("{}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected a string but was BEGIN_OBJECT at line 1 column 2 path $");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(typeAdapterFactory10);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNull(date12);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "null" + "'", str14, "null");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertNotNull(dateTypeAdapter17);
        org.junit.Assert.assertNull(date19);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter7 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson3, fieldNamingPolicyTypeAdapter7, fieldNamingPolicyClass8);
        com.google.gson.TypeAdapterFactory typeAdapterFactory10 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement11 = gson3.toJsonTree((java.lang.Object) typeAdapterFactory10);
        java.util.Date date12 = dateTypeAdapter2.fromJsonTree(jsonElement11);
        java.util.Date date13 = null;
        java.lang.String str14 = dateTypeAdapter2.toJson(date13);
        java.util.Date date15 = null;
        java.lang.String str16 = dateTypeAdapter2.toJson(date15);
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter17 = dateTypeAdapter2.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter18 = dateTypeAdapter2.nullSafe();
        java.io.Reader reader19 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.Date date20 = dateTypeAdapter2.fromJson(reader19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(typeAdapterFactory10);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNull(date12);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "null" + "'", str14, "null");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertNotNull(dateTypeAdapter17);
        org.junit.Assert.assertNotNull(dateTypeAdapter18);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter13 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter13.nullValue();
        boolean boolean15 = jsonTreeWriter13.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter13.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter13.value((long) (byte) -1);
        jsonTreeWriter13.flush();
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter13.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter13.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter13.value("null");
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter13.value(0L);
        java.lang.Object obj28 = null;
        fieldNamingPolicyArrayTypeAdapter12.write((com.google.gson.stream.JsonWriter) jsonTreeWriter13, obj28);
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter13.value((java.lang.Number) 2);
        boolean boolean32 = jsonWriter31.isHtmlSafe();
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter13 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter13.nullValue();
        boolean boolean15 = jsonTreeWriter13.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter13.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter13.value((long) (byte) -1);
        jsonTreeWriter13.flush();
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter13.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter13.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter13.value("null");
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter13.value(0L);
        java.lang.Object obj28 = null;
        fieldNamingPolicyArrayTypeAdapter12.write((com.google.gson.stream.JsonWriter) jsonTreeWriter13, obj28);
        java.lang.Object obj30 = null;
        java.lang.String str31 = fieldNamingPolicyArrayTypeAdapter12.toJson(obj30);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj33 = fieldNamingPolicyArrayTypeAdapter12.fromJson("com.google.gson.stream.MalformedJsonException");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "null" + "'", str31, "null");
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        com.google.gson.JsonObject jsonObject9 = new com.google.gson.JsonObject();
        com.google.gson.JsonElement jsonElement11 = jsonObject9.get("hi!");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet12 = jsonObject9.entrySet();
        java.lang.String str13 = gson0.toJson((java.lang.Object) strEntrySet12);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter14 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive16 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean17 = jsonPrimitive16.isJsonNull();
        com.google.gson.JsonElement jsonElement18 = jsonElementTypeAdapter14.toJsonTree((com.google.gson.JsonElement) jsonPrimitive16);
        boolean boolean19 = jsonPrimitive16.isString();
        boolean boolean20 = jsonPrimitive16.isNumber();
        boolean boolean21 = jsonPrimitive16.isString();
        java.lang.String str22 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive16);
        com.google.gson.JsonPrimitive jsonPrimitive24 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        double double25 = jsonPrimitive24.getAsDouble();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter26 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter26.nullValue();
        boolean boolean28 = jsonTreeWriter26.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter26.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter26.beginArray();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonPrimitive24, (com.google.gson.stream.JsonWriter) jsonTreeWriter26);
        com.google.gson.Gson gson32 = new com.google.gson.Gson();
        java.lang.Appendable appendable33 = null;
        java.io.Writer writer34 = com.google.gson.internal.Streams.writerForAppendable(appendable33);
        com.google.gson.stream.JsonWriter jsonWriter35 = gson32.newJsonWriter(writer34);
        com.google.gson.stream.JsonWriter jsonWriter36 = new com.google.gson.stream.JsonWriter(writer34);
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) jsonTreeWriter26, (java.lang.Appendable) writer34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: class com.google.gson.internal.bind.JsonTreeWriter declares multiple JSON fields named stack");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNull(jsonElement11);
        org.junit.Assert.assertNotNull(strEntrySet12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonElement18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "true" + "'", str22, "true");
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(writer34);
        org.junit.Assert.assertNotNull(jsonWriter35);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        com.google.gson.JsonPrimitive jsonPrimitive17 = new com.google.gson.JsonPrimitive("com.google.gson.JsonParseException: ");
        boolean boolean18 = jsonPrimitive17.isString();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader19 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonPrimitive17);
        java.lang.String str20 = jsonTreeReader19.getPath();
        java.lang.String str21 = jsonTreeReader19.toString();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj22 = fieldNamingPolicyArrayTypeAdapter15.read((com.google.gson.stream.JsonReader) jsonTreeReader19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was STRING");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "$" + "'", str20, "$");
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "JsonTreeReader" + "'", str21, "JsonTreeReader");
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = fieldNamingPolicyArrayTypeAdapter6.fromJson("\"true\"");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was STRING at line 1 column 2 path $");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = sqlDateTypeAdapter0.toJsonTree(date1);
        com.google.gson.JsonNull jsonNull3 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date4 = sqlDateTypeAdapter0.fromJsonTree((com.google.gson.JsonElement) jsonNull3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        java.lang.Appendable appendable6 = null;
        java.io.Writer writer7 = com.google.gson.internal.Streams.writerForAppendable(appendable6);
        com.google.gson.stream.JsonWriter jsonWriter8 = gson5.newJsonWriter(writer7);
        jsonWriter8.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter8.name("");
        java.sql.Date date13 = null;
        sqlDateTypeAdapter0.write(jsonWriter12, date13);
        com.google.gson.JsonObject jsonObject15 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray17 = jsonObject15.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter18.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject15, (com.google.gson.stream.JsonWriter) jsonTreeWriter18);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter18.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter18.endArray();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter18.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter18.endObject();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter18.value((long) 10);
        jsonTreeWriter18.setSerializeNulls(true);
        java.sql.Date date29 = null;
        sqlDateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter18, date29);
        com.google.gson.JsonObject jsonObject31 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray33 = jsonObject31.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter34 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter34.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject31, (com.google.gson.stream.JsonWriter) jsonTreeWriter34);
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter34.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter38 = jsonTreeWriter34.endArray();
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonTreeWriter34.value(false);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter34.value(4L);
        java.sql.Date date43 = null;
        sqlDateTypeAdapter0.write(jsonWriter42, date43);
        com.google.gson.JsonElement jsonElement45 = null;
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader46 = new com.google.gson.internal.bind.JsonTreeReader(jsonElement45);
        jsonTreeReader46.close();
        boolean boolean48 = jsonTreeReader46.isLenient();
        java.lang.String str49 = jsonTreeReader46.toString();
        // The following exception was thrown during execution in test generation
        try {
            java.sql.Date date50 = sqlDateTypeAdapter0.read((com.google.gson.stream.JsonReader) jsonTreeReader46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JsonReader is closed");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonNull3);
        org.junit.Assert.assertNull(date4);
        org.junit.Assert.assertNotNull(writer7);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNull(jsonArray17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertNull(jsonArray33);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter37);
        org.junit.Assert.assertNotNull(jsonWriter38);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "JsonTreeReader" + "'", str49, "JsonTreeReader");
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.lang.String str10 = jsonPrimitive9.getAsString();
        double double11 = jsonPrimitive9.getAsDouble();
        long long12 = jsonPrimitive9.getAsLong();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = objTypeAdapter7.fromJsonTree((com.google.gson.JsonElement) jsonPrimitive9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was STRING");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "4" + "'", str10, "4");
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4L + "'", long12 == 4L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        java.io.Reader reader8 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = objTypeAdapter7.fromJson(reader8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.lang.String str3 = jsonPrimitive2.getAsString();
        double double4 = jsonPrimitive2.getAsDouble();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2);
        boolean boolean6 = jsonPrimitive2.isNumber();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "4" + "'", str3, "4");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "\"4\"" + "'", str5, "\"4\"");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter0 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter1 = jsonElementTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter2 = jsonElementTypeAdapter1.nullSafe();
        com.google.gson.JsonArray jsonArray3 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor4 = jsonArray3.iterator();
        com.google.gson.JsonArray jsonArray5 = jsonArray3.getAsJsonArray();
        jsonArray5.add((java.lang.Boolean) true);
        char char8 = jsonArray5.getAsCharacter();
        com.google.gson.JsonArray jsonArray9 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor10 = jsonArray9.iterator();
        com.google.gson.JsonArray jsonArray11 = jsonArray9.getAsJsonArray();
        jsonArray5.addAll(jsonArray11);
        com.google.gson.LongSerializationPolicy longSerializationPolicy13 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement15 = longSerializationPolicy13.serialize((java.lang.Long) 10L);
        boolean boolean16 = jsonArray11.contains(jsonElement15);
        com.google.gson.JsonElement jsonElement17 = jsonElementTypeAdapter1.fromJsonTree(jsonElement15);
        com.google.gson.JsonElement jsonElement18 = null;
        com.google.gson.JsonElement jsonElement19 = jsonElementTypeAdapter1.toJsonTree(jsonElement18);
        com.google.gson.Gson gson20 = new com.google.gson.Gson();
        java.lang.Appendable appendable21 = null;
        java.io.Writer writer22 = com.google.gson.internal.Streams.writerForAppendable(appendable21);
        com.google.gson.stream.JsonWriter jsonWriter23 = gson20.newJsonWriter(writer22);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter24 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass25 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter26 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson20, fieldNamingPolicyTypeAdapter24, fieldNamingPolicyClass25);
        com.google.gson.TypeAdapterFactory typeAdapterFactory27 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement28 = gson20.toJsonTree((java.lang.Object) typeAdapterFactory27);
        java.lang.String str29 = gson20.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter30 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass31 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter32 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson20, fieldNamingPolicyTypeAdapter30, fieldNamingPolicyClass31);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter33 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter33.nullValue();
        boolean boolean35 = jsonTreeWriter33.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter36 = jsonTreeWriter33.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter38 = jsonTreeWriter33.value((long) (byte) -1);
        jsonTreeWriter33.flush();
        com.google.gson.stream.JsonWriter jsonWriter41 = jsonTreeWriter33.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter43 = jsonTreeWriter33.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter45 = jsonTreeWriter33.value("null");
        com.google.gson.stream.JsonWriter jsonWriter47 = jsonTreeWriter33.value(0L);
        java.lang.Object obj48 = null;
        fieldNamingPolicyArrayTypeAdapter32.write((com.google.gson.stream.JsonWriter) jsonTreeWriter33, obj48);
        com.google.gson.JsonArray jsonArray50 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor51 = jsonArray50.iterator();
        com.google.gson.JsonArray jsonArray52 = jsonArray50.getAsJsonArray();
        java.util.Spliterator<com.google.gson.JsonElement> jsonElementSpliterator53 = jsonArray50.spliterator();
        com.google.gson.JsonArray jsonArray54 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor55 = jsonArray54.iterator();
        com.google.gson.JsonArray jsonArray56 = jsonArray54.getAsJsonArray();
        jsonArray56.add((java.lang.Boolean) true);
        jsonArray56.add((java.lang.Number) (byte) -1);
        jsonArray50.addAll(jsonArray56);
        jsonElementTypeAdapter1.write((com.google.gson.stream.JsonWriter) jsonTreeWriter33, (com.google.gson.JsonElement) jsonArray56);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter0);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter1);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter2);
        org.junit.Assert.assertNotNull(jsonElementItor4);
        org.junit.Assert.assertNotNull(jsonArray5);
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + 't' + "'", char8 == 't');
        org.junit.Assert.assertNotNull(jsonElementItor10);
        org.junit.Assert.assertNotNull(jsonArray11);
        org.junit.Assert.assertNotNull(longSerializationPolicy13);
        org.junit.Assert.assertNotNull(jsonElement15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jsonElement17);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(writer22);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(typeAdapterFactory27);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(jsonWriter36);
        org.junit.Assert.assertNotNull(jsonWriter38);
        org.junit.Assert.assertNotNull(jsonWriter41);
        org.junit.Assert.assertNotNull(jsonWriter43);
        org.junit.Assert.assertNotNull(jsonWriter45);
        org.junit.Assert.assertNotNull(jsonWriter47);
        org.junit.Assert.assertNotNull(jsonElementItor51);
        org.junit.Assert.assertNotNull(jsonArray52);
        org.junit.Assert.assertNotNull(jsonElementSpliterator53);
        org.junit.Assert.assertNotNull(jsonElementItor55);
        org.junit.Assert.assertNotNull(jsonArray56);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter9 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter9, charSequenceClass10);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter12 = charSequenceArrayTypeAdapter11.nullSafe();
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(objTypeAdapter12);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter0 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time1 = null;
        com.google.gson.JsonElement jsonElement2 = timeTypeAdapter0.toJsonTree(time1);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter3 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter4 = jsonTreeWriter3.nullValue();
        boolean boolean5 = jsonTreeWriter3.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter6 = jsonTreeWriter3.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonTreeWriter3.value((long) (byte) -1);
        jsonTreeWriter3.flush();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter3.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter3.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter15 = jsonTreeWriter3.value("null");
        java.sql.Time time16 = null;
        timeTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter3, time16);
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter18 = timeTypeAdapter0.nullSafe();
        com.google.gson.Gson gson19 = new com.google.gson.Gson();
        java.lang.Appendable appendable20 = null;
        java.io.Writer writer21 = com.google.gson.internal.Streams.writerForAppendable(appendable20);
        com.google.gson.stream.JsonWriter jsonWriter22 = gson19.newJsonWriter(writer21);
        com.google.gson.stream.JsonWriter jsonWriter23 = new com.google.gson.stream.JsonWriter(writer21);
        java.sql.Time time24 = null;
        // The following exception was thrown during execution in test generation
        try {
            timeTypeAdapter18.toJson(writer21, time24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonWriter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(jsonWriter15);
        org.junit.Assert.assertNotNull(timeTypeAdapter18);
        org.junit.Assert.assertNotNull(writer21);
        org.junit.Assert.assertNotNull(jsonWriter22);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter0 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Character) ' ');
        boolean boolean3 = jsonPrimitive2.getAsBoolean();
        com.google.gson.JsonElement jsonElement4 = jsonElementTypeAdapter0.toJsonTree((com.google.gson.JsonElement) jsonPrimitive2);
        com.google.gson.JsonArray jsonArray5 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor6 = jsonArray5.iterator();
        com.google.gson.JsonArray jsonArray7 = jsonArray5.getAsJsonArray();
        jsonArray7.add((java.lang.Boolean) true);
        char char10 = jsonArray7.getAsCharacter();
        com.google.gson.JsonArray jsonArray11 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor12 = jsonArray11.iterator();
        com.google.gson.JsonArray jsonArray13 = jsonArray11.getAsJsonArray();
        jsonArray7.addAll(jsonArray13);
        com.google.gson.LongSerializationPolicy longSerializationPolicy15 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement17 = longSerializationPolicy15.serialize((java.lang.Long) 10L);
        boolean boolean18 = jsonArray13.contains(jsonElement17);
        jsonArray13.add((java.lang.Number) 1.0f);
        java.lang.String str21 = jsonArray13.getAsString();
        long long22 = jsonArray13.getAsLong();
        com.google.gson.JsonElement jsonElement23 = jsonElementTypeAdapter0.fromJsonTree((com.google.gson.JsonElement) jsonArray13);
        com.google.gson.Gson gson24 = new com.google.gson.Gson();
        java.lang.Appendable appendable25 = null;
        java.io.Writer writer26 = com.google.gson.internal.Streams.writerForAppendable(appendable25);
        com.google.gson.stream.JsonWriter jsonWriter27 = gson24.newJsonWriter(writer26);
        com.google.gson.stream.JsonWriter jsonWriter28 = new com.google.gson.stream.JsonWriter(writer26);
        java.io.Writer writer29 = com.google.gson.internal.Streams.writerForAppendable((java.lang.Appendable) writer26);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter30 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement31 = null;
        com.google.gson.JsonElement jsonElement32 = jsonElementTypeAdapter30.toJsonTree(jsonElement31);
        com.google.gson.JsonObject jsonObject33 = new com.google.gson.JsonObject();
        com.google.gson.JsonObject jsonObject35 = jsonObject33.getAsJsonObject("");
        jsonObject33.addProperty("com.google.gson.JsonParseException: ", (java.lang.Character) 'a');
        java.lang.String str39 = jsonElementTypeAdapter30.toJson((com.google.gson.JsonElement) jsonObject33);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter40 = jsonElementTypeAdapter30.nullSafe();
        com.google.gson.JsonPrimitive jsonPrimitive42 = new com.google.gson.JsonPrimitive("hi!");
        boolean boolean43 = jsonPrimitive42.getAsBoolean();
        java.lang.String str44 = jsonElementTypeAdapter30.toJson((com.google.gson.JsonElement) jsonPrimitive42);
        java.lang.String str45 = jsonPrimitive42.getAsString();
        // The following exception was thrown during execution in test generation
        try {
            jsonElementTypeAdapter0.toJson(writer26, (com.google.gson.JsonElement) jsonPrimitive42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(jsonElementItor6);
        org.junit.Assert.assertNotNull(jsonArray7);
        org.junit.Assert.assertTrue("'" + char10 + "' != '" + 't' + "'", char10 == 't');
        org.junit.Assert.assertNotNull(jsonElementItor12);
        org.junit.Assert.assertNotNull(jsonArray13);
        org.junit.Assert.assertNotNull(longSerializationPolicy15);
        org.junit.Assert.assertNotNull(jsonElement17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "1.0" + "'", str21, "1.0");
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(jsonElement23);
        org.junit.Assert.assertNotNull(writer26);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(writer29);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter30);
        org.junit.Assert.assertNotNull(jsonElement32);
        org.junit.Assert.assertNull(jsonObject35);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "{\"com.google.gson.JsonParseException: \":\"a\"}" + "'", str39, "{\"com.google.gson.JsonParseException: \":\"a\"}");
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "\"hi!\"" + "'", str44, "\"hi!\"");
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "hi!" + "'", str45, "hi!");
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.JsonElement jsonElement13 = null;
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader14 = new com.google.gson.internal.bind.JsonTreeReader(jsonElement13);
        jsonTreeReader14.close();
        boolean boolean16 = jsonTreeReader14.isLenient();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = fieldNamingPolicyArrayTypeAdapter12.toJson((java.lang.Object) boolean16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.gson.internal.LazilyParsedNumber lazilyParsedNumber1 = new com.google.gson.internal.LazilyParsedNumber("com.google.gson.JsonSyntaxException: com.google.gson.JsonSyntaxException: hi!");
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive4 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.lang.String str5 = jsonPrimitive4.getAsString();
        double double6 = jsonPrimitive4.getAsDouble();
        java.lang.String str7 = gson2.toJson((com.google.gson.JsonElement) jsonPrimitive4);
        com.google.gson.internal.bind.ObjectTypeAdapter objectTypeAdapter8 = new com.google.gson.internal.bind.ObjectTypeAdapter(gson2);
        boolean boolean9 = lazilyParsedNumber1.equals((java.lang.Object) objectTypeAdapter8);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = lazilyParsedNumber1.intValue();
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Character array is missing \"e\" notation exponential mark.");
        } catch (java.lang.NumberFormatException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "4" + "'", str5, "4");
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "\"4\"" + "'", str7, "\"4\"");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement9 = null;
        com.google.gson.JsonElement jsonElement10 = jsonElementTypeAdapter8.toJsonTree(jsonElement9);
        com.google.gson.JsonNull jsonNull11 = jsonElement10.getAsJsonNull();
        boolean boolean12 = jsonNull11.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader13 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull11);
        com.google.gson.stream.JsonToken jsonToken14 = jsonTreeReader13.peek();
        java.lang.Object obj15 = fieldNamingPolicyArrayTypeAdapter6.read((com.google.gson.stream.JsonReader) jsonTreeReader13);
        java.lang.String str16 = jsonTreeReader13.toString();
        // The following exception was thrown during execution in test generation
        try {
            int int17 = jsonTreeReader13.nextInt();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NUMBER but was END_DOCUMENT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter8);
        org.junit.Assert.assertNotNull(jsonElement10);
        org.junit.Assert.assertNotNull(jsonNull11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jsonToken14 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken14.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "JsonTreeReader" + "'", str16, "JsonTreeReader");
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        boolean boolean6 = jsonWriter3.isLenient();
        boolean boolean7 = jsonWriter3.isHtmlSafe();
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.stream.JsonWriter jsonWriter9 = jsonWriter3.jsonValue("com.google.gson.stream.MalformedJsonException");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter8 = objTypeAdapter7.nullSafe();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj10 = objTypeAdapter8.fromJson("");
            org.junit.Assert.fail("Expected exception of type java.io.EOFException; message: End of input at line 1 column 1");
        } catch (java.io.EOFException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(objTypeAdapter8);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor1 = jsonArray0.iterator();
        com.google.gson.JsonArray jsonArray2 = jsonArray0.getAsJsonArray();
        java.util.Spliterator<com.google.gson.JsonElement> jsonElementSpliterator3 = jsonArray0.spliterator();
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor5 = jsonArray4.iterator();
        com.google.gson.JsonArray jsonArray6 = jsonArray4.getAsJsonArray();
        jsonArray6.add((java.lang.Boolean) true);
        jsonArray6.add((java.lang.Number) (byte) -1);
        jsonArray0.addAll(jsonArray6);
        java.lang.String str12 = jsonArray0.toString();
        com.google.gson.Gson gson13 = new com.google.gson.Gson();
        java.lang.Appendable appendable14 = null;
        java.io.Writer writer15 = com.google.gson.internal.Streams.writerForAppendable(appendable14);
        com.google.gson.stream.JsonWriter jsonWriter16 = gson13.newJsonWriter(writer15);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter17 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson13, fieldNamingPolicyTypeAdapter17, fieldNamingPolicyClass18);
        com.google.gson.TypeAdapterFactory typeAdapterFactory20 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement21 = gson13.toJsonTree((java.lang.Object) typeAdapterFactory20);
        com.google.gson.JsonObject jsonObject22 = new com.google.gson.JsonObject();
        com.google.gson.JsonElement jsonElement24 = jsonObject22.get("hi!");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet25 = jsonObject22.entrySet();
        java.lang.String str26 = gson13.toJson((java.lang.Object) strEntrySet25);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter27 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive29 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean30 = jsonPrimitive29.isJsonNull();
        com.google.gson.JsonElement jsonElement31 = jsonElementTypeAdapter27.toJsonTree((com.google.gson.JsonElement) jsonPrimitive29);
        boolean boolean32 = jsonPrimitive29.isString();
        boolean boolean33 = jsonPrimitive29.isNumber();
        boolean boolean34 = jsonPrimitive29.isString();
        java.lang.String str35 = gson13.toJson((com.google.gson.JsonElement) jsonPrimitive29);
        boolean boolean36 = jsonArray0.remove((com.google.gson.JsonElement) jsonPrimitive29);
        int int37 = jsonArray0.size();
        com.google.gson.JsonObject jsonObject38 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray40 = jsonObject38.getAsJsonArray("");
        com.google.gson.JsonArray jsonArray42 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor43 = jsonArray42.iterator();
        com.google.gson.JsonArray jsonArray44 = jsonArray42.getAsJsonArray();
        java.util.Spliterator<com.google.gson.JsonElement> jsonElementSpliterator45 = jsonArray42.spliterator();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter46 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement47 = null;
        com.google.gson.JsonElement jsonElement48 = jsonElementTypeAdapter46.toJsonTree(jsonElement47);
        com.google.gson.JsonNull jsonNull49 = jsonElement48.getAsJsonNull();
        boolean boolean50 = jsonNull49.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader51 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull49);
        boolean boolean52 = jsonArray42.contains((com.google.gson.JsonElement) jsonNull49);
        jsonObject38.add("\"hi!\"", (com.google.gson.JsonElement) jsonNull49);
        jsonObject38.addProperty("JsonTreeReader", " ");
        com.google.gson.JsonElement jsonElement58 = jsonObject38.get("true");
        jsonArray0.add(jsonElement58);
        org.junit.Assert.assertNotNull(jsonElementItor1);
        org.junit.Assert.assertNotNull(jsonArray2);
        org.junit.Assert.assertNotNull(jsonElementSpliterator3);
        org.junit.Assert.assertNotNull(jsonElementItor5);
        org.junit.Assert.assertNotNull(jsonArray6);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[true,-1]" + "'", str12, "[true,-1]");
        org.junit.Assert.assertNotNull(writer15);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(typeAdapterFactory20);
        org.junit.Assert.assertNotNull(jsonElement21);
        org.junit.Assert.assertNull(jsonElement24);
        org.junit.Assert.assertNotNull(strEntrySet25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "[]" + "'", str26, "[]");
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jsonElement31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "true" + "'", str35, "true");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNull(jsonArray40);
        org.junit.Assert.assertNotNull(jsonElementItor43);
        org.junit.Assert.assertNotNull(jsonArray44);
        org.junit.Assert.assertNotNull(jsonElementSpliterator45);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter46);
        org.junit.Assert.assertNotNull(jsonElement48);
        org.junit.Assert.assertNotNull(jsonNull49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(jsonElement58);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter13 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter13.nullValue();
        boolean boolean15 = jsonTreeWriter13.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter13.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter13.value((long) (byte) -1);
        jsonTreeWriter13.flush();
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter13.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter13.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter13.value("null");
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter13.value(0L);
        java.lang.Object obj28 = null;
        fieldNamingPolicyArrayTypeAdapter12.write((com.google.gson.stream.JsonWriter) jsonTreeWriter13, obj28);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter30 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive32 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean33 = jsonPrimitive32.isJsonNull();
        com.google.gson.JsonElement jsonElement34 = jsonElementTypeAdapter30.toJsonTree((com.google.gson.JsonElement) jsonPrimitive32);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter35 = jsonElementTypeAdapter30.nullSafe();
        com.google.gson.JsonArray jsonArray36 = new com.google.gson.JsonArray();
        com.google.gson.internal.Excluder excluder37 = new com.google.gson.internal.Excluder();
        boolean boolean38 = jsonArray36.equals((java.lang.Object) excluder37);
        com.google.gson.JsonArray jsonArray39 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor40 = jsonArray39.iterator();
        com.google.gson.JsonArray jsonArray41 = jsonArray39.getAsJsonArray();
        jsonArray41.add((java.lang.Boolean) true);
        jsonArray36.addAll(jsonArray41);
        int int45 = jsonArray41.size();
        com.google.gson.JsonElement jsonElement46 = jsonElementTypeAdapter30.toJsonTree((com.google.gson.JsonElement) jsonArray41);
        com.google.gson.JsonElement jsonElement47 = null;
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader48 = new com.google.gson.internal.bind.JsonTreeReader(jsonElement47);
        jsonTreeReader48.close();
        boolean boolean50 = jsonTreeReader48.isLenient();
        boolean boolean51 = jsonTreeReader48.isLenient();
        boolean boolean52 = jsonArray41.equals((java.lang.Object) jsonTreeReader48);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj53 = fieldNamingPolicyArrayTypeAdapter12.fromJsonTree((com.google.gson.JsonElement) jsonArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jsonElement34);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jsonElementItor40);
        org.junit.Assert.assertNotNull(jsonArray41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(jsonElement46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson3 = new com.google.gson.Gson();
        java.lang.Appendable appendable4 = null;
        java.io.Writer writer5 = com.google.gson.internal.Streams.writerForAppendable(appendable4);
        com.google.gson.stream.JsonWriter jsonWriter6 = gson3.newJsonWriter(writer5);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter7 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass8 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter9 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson3, fieldNamingPolicyTypeAdapter7, fieldNamingPolicyClass8);
        com.google.gson.TypeAdapterFactory typeAdapterFactory10 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement11 = gson3.toJsonTree((java.lang.Object) typeAdapterFactory10);
        java.util.Date date12 = dateTypeAdapter2.fromJsonTree(jsonElement11);
        java.util.Date date13 = null;
        java.lang.String str14 = dateTypeAdapter2.toJson(date13);
        java.util.Date date15 = null;
        java.lang.String str16 = dateTypeAdapter2.toJson(date15);
        java.util.Date date17 = null;
        java.lang.String str18 = dateTypeAdapter2.toJson(date17);
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter19 = dateTypeAdapter2.nullSafe();
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(writer5);
        org.junit.Assert.assertNotNull(jsonWriter6);
        org.junit.Assert.assertNotNull(typeAdapterFactory10);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNull(date12);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "null" + "'", str14, "null");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "null" + "'", str16, "null");
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "null" + "'", str18, "null");
        org.junit.Assert.assertNotNull(dateTypeAdapter19);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.lang.String str3 = jsonPrimitive2.getAsString();
        double double4 = jsonPrimitive2.getAsDouble();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2);
        boolean boolean6 = jsonPrimitive2.isJsonNull();
        float float7 = jsonPrimitive2.getAsFloat();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "4" + "'", str3, "4");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "\"4\"" + "'", str5, "\"4\"");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 4.0f + "'", float7 == 4.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor1 = jsonArray0.iterator();
        com.google.gson.JsonArray jsonArray2 = jsonArray0.getAsJsonArray();
        java.util.Spliterator<com.google.gson.JsonElement> jsonElementSpliterator3 = jsonArray0.spliterator();
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor5 = jsonArray4.iterator();
        com.google.gson.JsonArray jsonArray6 = jsonArray4.getAsJsonArray();
        jsonArray6.add((java.lang.Boolean) true);
        jsonArray6.add((java.lang.Number) (byte) -1);
        jsonArray0.addAll(jsonArray6);
        java.lang.String str12 = jsonArray0.toString();
        com.google.gson.Gson gson13 = new com.google.gson.Gson();
        java.lang.Appendable appendable14 = null;
        java.io.Writer writer15 = com.google.gson.internal.Streams.writerForAppendable(appendable14);
        com.google.gson.stream.JsonWriter jsonWriter16 = gson13.newJsonWriter(writer15);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter17 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson13, fieldNamingPolicyTypeAdapter17, fieldNamingPolicyClass18);
        com.google.gson.TypeAdapterFactory typeAdapterFactory20 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement21 = gson13.toJsonTree((java.lang.Object) typeAdapterFactory20);
        com.google.gson.JsonObject jsonObject22 = new com.google.gson.JsonObject();
        com.google.gson.JsonElement jsonElement24 = jsonObject22.get("hi!");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet25 = jsonObject22.entrySet();
        java.lang.String str26 = gson13.toJson((java.lang.Object) strEntrySet25);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter27 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive29 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean30 = jsonPrimitive29.isJsonNull();
        com.google.gson.JsonElement jsonElement31 = jsonElementTypeAdapter27.toJsonTree((com.google.gson.JsonElement) jsonPrimitive29);
        boolean boolean32 = jsonPrimitive29.isString();
        boolean boolean33 = jsonPrimitive29.isNumber();
        boolean boolean34 = jsonPrimitive29.isString();
        java.lang.String str35 = gson13.toJson((com.google.gson.JsonElement) jsonPrimitive29);
        boolean boolean36 = jsonArray0.remove((com.google.gson.JsonElement) jsonPrimitive29);
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.JsonNull jsonNull37 = jsonArray0.getAsJsonNull();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: This is not a JSON Null.");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElementItor1);
        org.junit.Assert.assertNotNull(jsonArray2);
        org.junit.Assert.assertNotNull(jsonElementSpliterator3);
        org.junit.Assert.assertNotNull(jsonElementItor5);
        org.junit.Assert.assertNotNull(jsonArray6);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[true,-1]" + "'", str12, "[true,-1]");
        org.junit.Assert.assertNotNull(writer15);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(typeAdapterFactory20);
        org.junit.Assert.assertNotNull(jsonElement21);
        org.junit.Assert.assertNull(jsonElement24);
        org.junit.Assert.assertNotNull(strEntrySet25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "[]" + "'", str26, "[]");
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jsonElement31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "true" + "'", str35, "true");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter18 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive20 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean21 = jsonPrimitive20.isJsonNull();
        com.google.gson.JsonElement jsonElement22 = jsonElementTypeAdapter18.toJsonTree((com.google.gson.JsonElement) jsonPrimitive20);
        java.lang.Throwable throwable25 = null;
        com.google.gson.JsonSyntaxException jsonSyntaxException26 = new com.google.gson.JsonSyntaxException("", throwable25);
        com.google.gson.JsonSyntaxException jsonSyntaxException27 = new com.google.gson.JsonSyntaxException("", throwable25);
        java.lang.Throwable throwable29 = null;
        com.google.gson.JsonSyntaxException jsonSyntaxException30 = new com.google.gson.JsonSyntaxException("", throwable29);
        jsonSyntaxException27.addSuppressed((java.lang.Throwable) jsonSyntaxException30);
        com.google.gson.stream.MalformedJsonException malformedJsonException32 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonSyntaxException27);
        boolean boolean33 = jsonPrimitive20.equals((java.lang.Object) malformedJsonException32);
        jsonObject16.add("true", (com.google.gson.JsonElement) jsonPrimitive20);
        com.google.gson.Gson gson35 = null;
        com.google.gson.internal.bind.ObjectTypeAdapter objectTypeAdapter36 = new com.google.gson.internal.bind.ObjectTypeAdapter(gson35);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter37 = objectTypeAdapter36.nullSafe();
        boolean boolean38 = jsonObject16.equals((java.lang.Object) objectTypeAdapter36);
        com.google.gson.JsonPrimitive jsonPrimitive40 = jsonObject16.getAsJsonPrimitive("true");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj41 = fieldNamingPolicyArrayTypeAdapter15.fromJsonTree((com.google.gson.JsonElement) jsonPrimitive40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BOOLEAN");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonElement22);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(objTypeAdapter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jsonPrimitive40);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        com.google.gson.TypeAdapter<java.lang.CharSequence> charSequenceTypeAdapter9 = null;
        java.lang.Class<java.lang.CharSequence> charSequenceClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence> charSequenceArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.CharSequence>(gson0, charSequenceTypeAdapter9, charSequenceClass10);
        java.io.Reader reader12 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj13 = charSequenceArrayTypeAdapter11.fromJson(reader12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = sqlDateTypeAdapter0.toJsonTree(date1);
        com.google.gson.JsonNull jsonNull3 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date4 = sqlDateTypeAdapter0.fromJsonTree((com.google.gson.JsonElement) jsonNull3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        java.lang.Appendable appendable6 = null;
        java.io.Writer writer7 = com.google.gson.internal.Streams.writerForAppendable(appendable6);
        com.google.gson.stream.JsonWriter jsonWriter8 = gson5.newJsonWriter(writer7);
        jsonWriter8.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter8.name("");
        java.sql.Date date13 = null;
        sqlDateTypeAdapter0.write(jsonWriter12, date13);
        com.google.gson.JsonObject jsonObject15 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray17 = jsonObject15.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter18.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject15, (com.google.gson.stream.JsonWriter) jsonTreeWriter18);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter18.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter18.endArray();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter18.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter18.endObject();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter18.value((long) 10);
        jsonTreeWriter18.setSerializeNulls(true);
        java.sql.Date date29 = null;
        sqlDateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter18, date29);
        com.google.gson.JsonObject jsonObject31 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray33 = jsonObject31.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter34 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter34.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject31, (com.google.gson.stream.JsonWriter) jsonTreeWriter34);
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter34.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter38 = jsonTreeWriter34.endArray();
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonTreeWriter34.value(false);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter34.value(4L);
        java.sql.Date date43 = null;
        sqlDateTypeAdapter0.write(jsonWriter42, date43);
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter45 = sqlDateTypeAdapter0.nullSafe();
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonNull3);
        org.junit.Assert.assertNull(date4);
        org.junit.Assert.assertNotNull(writer7);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNull(jsonArray17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertNull(jsonArray33);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter37);
        org.junit.Assert.assertNotNull(jsonWriter38);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertNotNull(dateTypeAdapter45);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.gson.JsonElement jsonElement0 = null;
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter1 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date2 = null;
        com.google.gson.JsonElement jsonElement3 = sqlDateTypeAdapter1.toJsonTree(date2);
        com.google.gson.JsonNull jsonNull4 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date5 = sqlDateTypeAdapter1.fromJsonTree((com.google.gson.JsonElement) jsonNull4);
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        java.lang.Appendable appendable7 = null;
        java.io.Writer writer8 = com.google.gson.internal.Streams.writerForAppendable(appendable7);
        com.google.gson.stream.JsonWriter jsonWriter9 = gson6.newJsonWriter(writer8);
        jsonWriter9.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonWriter9.name("");
        java.sql.Date date14 = null;
        sqlDateTypeAdapter1.write(jsonWriter13, date14);
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray18 = jsonObject16.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter20 = jsonTreeWriter19.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject16, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter19.endArray();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter19.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter19.endObject();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.value((long) 10);
        jsonTreeWriter19.setSerializeNulls(true);
        java.sql.Date date30 = null;
        sqlDateTypeAdapter1.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date30);
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter19.value((java.lang.Number) (short) 10);
        com.google.gson.internal.Streams.write(jsonElement0, jsonWriter33);
        org.junit.Assert.assertNotNull(jsonElement3);
        org.junit.Assert.assertNotNull(jsonNull4);
        org.junit.Assert.assertNull(date5);
        org.junit.Assert.assertNotNull(writer8);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNull(jsonArray18);
        org.junit.Assert.assertNotNull(jsonWriter20);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter33);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.math.BigInteger bigInteger2 = jsonPrimitive1.getAsBigInteger();
        java.lang.Number number3 = jsonPrimitive1.getAsNumber();
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        com.google.gson.internal.Excluder excluder5 = new com.google.gson.internal.Excluder();
        boolean boolean6 = jsonArray4.equals((java.lang.Object) excluder5);
        boolean boolean7 = jsonPrimitive1.equals((java.lang.Object) jsonArray4);
        com.google.gson.JsonPrimitive jsonPrimitive8 = jsonPrimitive1.getAsJsonPrimitive();
        java.math.BigInteger bigInteger9 = jsonPrimitive8.getAsBigInteger();
        com.google.gson.Gson gson10 = new com.google.gson.Gson();
        java.lang.Appendable appendable11 = null;
        java.io.Writer writer12 = com.google.gson.internal.Streams.writerForAppendable(appendable11);
        com.google.gson.stream.JsonWriter jsonWriter13 = gson10.newJsonWriter(writer12);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter14 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson10, fieldNamingPolicyTypeAdapter14, fieldNamingPolicyClass15);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter17 = fieldNamingPolicyArrayTypeAdapter16.nullSafe();
        boolean boolean18 = jsonPrimitive8.equals((java.lang.Object) fieldNamingPolicyArrayTypeAdapter16);
        com.google.gson.JsonElement jsonElement19 = null;
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader20 = new com.google.gson.internal.bind.JsonTreeReader(jsonElement19);
        jsonTreeReader20.close();
        boolean boolean22 = jsonTreeReader20.isLenient();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj23 = fieldNamingPolicyArrayTypeAdapter16.read((com.google.gson.stream.JsonReader) jsonTreeReader20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JsonReader is closed");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(number3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jsonPrimitive8);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor1 = jsonArray0.iterator();
        com.google.gson.JsonArray jsonArray2 = jsonArray0.getAsJsonArray();
        java.util.Spliterator<com.google.gson.JsonElement> jsonElementSpliterator3 = jsonArray0.spliterator();
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor5 = jsonArray4.iterator();
        com.google.gson.JsonArray jsonArray6 = jsonArray4.getAsJsonArray();
        jsonArray6.add((java.lang.Boolean) true);
        jsonArray6.add((java.lang.Number) (byte) -1);
        jsonArray0.addAll(jsonArray6);
        java.lang.String str12 = jsonArray0.toString();
        com.google.gson.Gson gson13 = new com.google.gson.Gson();
        java.lang.Appendable appendable14 = null;
        java.io.Writer writer15 = com.google.gson.internal.Streams.writerForAppendable(appendable14);
        com.google.gson.stream.JsonWriter jsonWriter16 = gson13.newJsonWriter(writer15);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter17 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson13, fieldNamingPolicyTypeAdapter17, fieldNamingPolicyClass18);
        com.google.gson.TypeAdapterFactory typeAdapterFactory20 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement21 = gson13.toJsonTree((java.lang.Object) typeAdapterFactory20);
        com.google.gson.JsonObject jsonObject22 = new com.google.gson.JsonObject();
        com.google.gson.JsonElement jsonElement24 = jsonObject22.get("hi!");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet25 = jsonObject22.entrySet();
        java.lang.String str26 = gson13.toJson((java.lang.Object) strEntrySet25);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter27 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive29 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean30 = jsonPrimitive29.isJsonNull();
        com.google.gson.JsonElement jsonElement31 = jsonElementTypeAdapter27.toJsonTree((com.google.gson.JsonElement) jsonPrimitive29);
        boolean boolean32 = jsonPrimitive29.isString();
        boolean boolean33 = jsonPrimitive29.isNumber();
        boolean boolean34 = jsonPrimitive29.isString();
        java.lang.String str35 = gson13.toJson((com.google.gson.JsonElement) jsonPrimitive29);
        boolean boolean36 = jsonArray0.remove((com.google.gson.JsonElement) jsonPrimitive29);
        // The following exception was thrown during execution in test generation
        try {
            float float37 = jsonPrimitive29.getAsFloat();
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"true\"");
        } catch (java.lang.NumberFormatException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElementItor1);
        org.junit.Assert.assertNotNull(jsonArray2);
        org.junit.Assert.assertNotNull(jsonElementSpliterator3);
        org.junit.Assert.assertNotNull(jsonElementItor5);
        org.junit.Assert.assertNotNull(jsonArray6);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[true,-1]" + "'", str12, "[true,-1]");
        org.junit.Assert.assertNotNull(writer15);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(typeAdapterFactory20);
        org.junit.Assert.assertNotNull(jsonElement21);
        org.junit.Assert.assertNull(jsonElement24);
        org.junit.Assert.assertNotNull(strEntrySet25);
        org.junit.Assert.assertEquals("'" + str26 + "' != '" + "[]" + "'", str26, "[]");
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jsonElement31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "true" + "'", str35, "true");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        com.google.gson.JsonElement jsonElement12 = jsonObject10.get("hi!");
        boolean boolean13 = jsonObject10.isJsonNull();
        jsonObject10.addProperty("-1.0", (java.lang.Character) 'a');
        com.google.gson.JsonPrimitive jsonPrimitive18 = jsonObject10.getAsJsonPrimitive("4");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet19 = jsonObject10.entrySet();
        jsonObject10.addProperty("", "com.google.gson.JsonSyntaxException: com.google.gson.JsonSyntaxException: hi!");
        jsonObject10.addProperty("", (java.lang.Boolean) false);
        java.lang.reflect.Type type26 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.google.gson.internal.bind.TypeAdapterRuntimeTypeWrapper<java.lang.Cloneable> cloneableTypeAdapterRuntimeTypeWrapper27 = gson0.fromJson((com.google.gson.JsonElement) jsonObject10, type26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNull(jsonElement12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(jsonPrimitive18);
        org.junit.Assert.assertNotNull(strEntrySet19);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        java.lang.String str10 = gson0.toString();
        com.google.gson.JsonIOException jsonIOException12 = new com.google.gson.JsonIOException("true");
        com.google.gson.stream.MalformedJsonException malformedJsonException13 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonIOException12);
        java.lang.Appendable appendable14 = null;
        java.io.Writer writer15 = com.google.gson.internal.Streams.writerForAppendable(appendable14);
        java.io.Writer writer16 = com.google.gson.internal.Streams.writerForAppendable((java.lang.Appendable) writer15);
        // The following exception was thrown during execution in test generation
        try {
            gson0.toJson((java.lang.Object) malformedJsonException13, (java.lang.Appendable) writer16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(writer15);
        org.junit.Assert.assertNotNull(writer16);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter8 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter8.nullValue();
        boolean boolean10 = jsonTreeWriter8.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter8.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonTreeWriter8.value((long) (byte) -1);
        jsonTreeWriter8.flush();
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter8.value((double) 1L);
        boolean boolean17 = jsonTreeWriter8.isLenient();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter8.value("false");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter20 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time21 = null;
        com.google.gson.JsonElement jsonElement22 = timeTypeAdapter20.toJsonTree(time21);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter23 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter23.nullValue();
        boolean boolean25 = jsonTreeWriter23.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter23.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter28 = jsonTreeWriter23.value((long) (byte) -1);
        jsonTreeWriter23.flush();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter23.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter23.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter23.value("null");
        java.sql.Time time36 = null;
        timeTypeAdapter20.write((com.google.gson.stream.JsonWriter) jsonTreeWriter23, time36);
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter23.value(true);
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonWriter39.endArray();
        com.google.gson.stream.JsonWriter jsonWriter41 = jsonWriter39.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonWriter41.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter43 = jsonWriter42.beginObject();
        // The following exception was thrown during execution in test generation
        try {
            fieldNamingPolicyArrayTypeAdapter6.write(jsonWriter19, (java.lang.Object) jsonWriter42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonElement22);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertNotNull(jsonWriter28);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter39);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertNotNull(jsonWriter41);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertNotNull(jsonWriter43);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        java.lang.String str10 = gson0.toString();
        java.lang.String str12 = gson0.toJson((java.lang.Object) "$");
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "\"$\"" + "'", str12, "\"$\"");
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter2 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive4 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean5 = jsonPrimitive4.isJsonNull();
        com.google.gson.JsonElement jsonElement6 = jsonElementTypeAdapter2.toJsonTree((com.google.gson.JsonElement) jsonPrimitive4);
        java.lang.Throwable throwable9 = null;
        com.google.gson.JsonSyntaxException jsonSyntaxException10 = new com.google.gson.JsonSyntaxException("", throwable9);
        com.google.gson.JsonSyntaxException jsonSyntaxException11 = new com.google.gson.JsonSyntaxException("", throwable9);
        java.lang.Throwable throwable13 = null;
        com.google.gson.JsonSyntaxException jsonSyntaxException14 = new com.google.gson.JsonSyntaxException("", throwable13);
        jsonSyntaxException11.addSuppressed((java.lang.Throwable) jsonSyntaxException14);
        com.google.gson.stream.MalformedJsonException malformedJsonException16 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonSyntaxException11);
        boolean boolean17 = jsonPrimitive4.equals((java.lang.Object) malformedJsonException16);
        jsonObject0.add("true", (com.google.gson.JsonElement) jsonPrimitive4);
        com.google.gson.Gson gson19 = null;
        com.google.gson.internal.bind.ObjectTypeAdapter objectTypeAdapter20 = new com.google.gson.internal.bind.ObjectTypeAdapter(gson19);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter21 = objectTypeAdapter20.nullSafe();
        boolean boolean22 = jsonObject0.equals((java.lang.Object) objectTypeAdapter20);
        com.google.gson.JsonPrimitive jsonPrimitive24 = jsonObject0.getAsJsonPrimitive("true");
        com.google.gson.JsonElement jsonElement26 = jsonObject0.get("");
        com.google.gson.JsonPrimitive jsonPrimitive29 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.math.BigInteger bigInteger30 = jsonPrimitive29.getAsBigInteger();
        java.lang.Number number31 = jsonPrimitive29.getAsNumber();
        com.google.gson.JsonArray jsonArray32 = new com.google.gson.JsonArray();
        com.google.gson.internal.Excluder excluder33 = new com.google.gson.internal.Excluder();
        boolean boolean34 = jsonArray32.equals((java.lang.Object) excluder33);
        boolean boolean35 = jsonPrimitive29.equals((java.lang.Object) jsonArray32);
        com.google.gson.JsonPrimitive jsonPrimitive36 = jsonPrimitive29.getAsJsonPrimitive();
        double double37 = jsonPrimitive36.getAsDouble();
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter38 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date39 = null;
        com.google.gson.JsonElement jsonElement40 = sqlDateTypeAdapter38.toJsonTree(date39);
        com.google.gson.JsonNull jsonNull41 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date42 = sqlDateTypeAdapter38.fromJsonTree((com.google.gson.JsonElement) jsonNull41);
        com.google.gson.Gson gson43 = new com.google.gson.Gson();
        java.lang.Appendable appendable44 = null;
        java.io.Writer writer45 = com.google.gson.internal.Streams.writerForAppendable(appendable44);
        com.google.gson.stream.JsonWriter jsonWriter46 = gson43.newJsonWriter(writer45);
        jsonWriter46.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter50 = jsonWriter46.name("");
        java.sql.Date date51 = null;
        sqlDateTypeAdapter38.write(jsonWriter50, date51);
        boolean boolean53 = jsonPrimitive36.equals((java.lang.Object) sqlDateTypeAdapter38);
        jsonObject0.add("", (com.google.gson.JsonElement) jsonPrimitive36);
        com.google.gson.JsonElement jsonElement56 = jsonObject0.get("");
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jsonElement6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(objTypeAdapter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(jsonPrimitive24);
        org.junit.Assert.assertNull(jsonElement26);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(number31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(jsonPrimitive36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(jsonElement40);
        org.junit.Assert.assertNotNull(jsonNull41);
        org.junit.Assert.assertNull(date42);
        org.junit.Assert.assertNotNull(writer45);
        org.junit.Assert.assertNotNull(jsonWriter46);
        org.junit.Assert.assertNotNull(jsonWriter50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(jsonElement56);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = sqlDateTypeAdapter0.toJsonTree(date1);
        com.google.gson.JsonNull jsonNull3 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date4 = sqlDateTypeAdapter0.fromJsonTree((com.google.gson.JsonElement) jsonNull3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        java.lang.Appendable appendable6 = null;
        java.io.Writer writer7 = com.google.gson.internal.Streams.writerForAppendable(appendable6);
        com.google.gson.stream.JsonWriter jsonWriter8 = gson5.newJsonWriter(writer7);
        jsonWriter8.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter8.name("");
        java.sql.Date date13 = null;
        sqlDateTypeAdapter0.write(jsonWriter12, date13);
        com.google.gson.JsonObject jsonObject15 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray17 = jsonObject15.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter18.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject15, (com.google.gson.stream.JsonWriter) jsonTreeWriter18);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter18.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter18.endArray();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter18.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter18.endObject();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter18.value((long) 10);
        jsonTreeWriter18.setSerializeNulls(true);
        java.sql.Date date29 = null;
        sqlDateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter18, date29);
        java.lang.Number number31 = null;
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter18.value(number31);
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonNull3);
        org.junit.Assert.assertNull(date4);
        org.junit.Assert.assertNotNull(writer7);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNull(jsonArray17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertNotNull(jsonWriter32);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = sqlDateTypeAdapter0.toJsonTree(date1);
        com.google.gson.JsonNull jsonNull3 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date4 = sqlDateTypeAdapter0.fromJsonTree((com.google.gson.JsonElement) jsonNull3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        java.lang.Appendable appendable6 = null;
        java.io.Writer writer7 = com.google.gson.internal.Streams.writerForAppendable(appendable6);
        com.google.gson.stream.JsonWriter jsonWriter8 = gson5.newJsonWriter(writer7);
        jsonWriter8.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter8.name("");
        java.sql.Date date13 = null;
        sqlDateTypeAdapter0.write(jsonWriter12, date13);
        com.google.gson.JsonObject jsonObject15 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray17 = jsonObject15.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter18.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject15, (com.google.gson.stream.JsonWriter) jsonTreeWriter18);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter18.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter18.endArray();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter18.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter18.endObject();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter18.value((long) 10);
        jsonTreeWriter18.setSerializeNulls(true);
        java.sql.Date date29 = null;
        sqlDateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter18, date29);
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter18.value((java.lang.Number) (short) 10);
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonWriter32.value(false);
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonNull3);
        org.junit.Assert.assertNull(date4);
        org.junit.Assert.assertNotNull(writer7);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNull(jsonArray17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter34);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.lang.String str3 = jsonPrimitive2.getAsString();
        double double4 = jsonPrimitive2.getAsDouble();
        java.lang.String str5 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive2);
        com.google.gson.LongSerializationPolicy longSerializationPolicy6 = com.google.gson.LongSerializationPolicy.DEFAULT;
        com.google.gson.JsonElement jsonElement8 = longSerializationPolicy6.serialize((java.lang.Long) 1L);
        com.google.gson.JsonElement jsonElement9 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy6);
        com.google.gson.JsonElement jsonElement11 = longSerializationPolicy6.serialize((java.lang.Long) 0L);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "4" + "'", str3, "4");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "\"4\"" + "'", str5, "\"4\"");
        org.junit.Assert.assertNotNull(longSerializationPolicy6);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement9);
        org.junit.Assert.assertNotNull(jsonElement11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter1 = dateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter2 = dateTypeAdapter0.nullSafe();
        java.util.Date date3 = null;
        java.lang.String str4 = dateTypeAdapter0.toJson(date3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        java.lang.Appendable appendable6 = null;
        java.io.Writer writer7 = com.google.gson.internal.Streams.writerForAppendable(appendable6);
        com.google.gson.stream.JsonWriter jsonWriter8 = gson5.newJsonWriter(writer7);
        java.util.Date date9 = null;
        // The following exception was thrown during execution in test generation
        try {
            dateTypeAdapter0.toJson(writer7, date9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "null" + "'", str4, "null");
        org.junit.Assert.assertNotNull(writer7);
        org.junit.Assert.assertNotNull(jsonWriter8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor1 = jsonArray0.iterator();
        com.google.gson.JsonArray jsonArray2 = jsonArray0.getAsJsonArray();
        jsonArray2.add((java.lang.Boolean) true);
        char char5 = jsonArray2.getAsCharacter();
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor7 = jsonArray6.iterator();
        com.google.gson.JsonArray jsonArray8 = jsonArray6.getAsJsonArray();
        jsonArray2.addAll(jsonArray8);
        com.google.gson.LongSerializationPolicy longSerializationPolicy10 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement12 = longSerializationPolicy10.serialize((java.lang.Long) 10L);
        boolean boolean13 = jsonArray8.contains(jsonElement12);
        jsonArray8.add((java.lang.Number) 1.0f);
        jsonArray8.add("$");
        com.google.gson.Gson gson18 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive20 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.lang.String str21 = jsonPrimitive20.getAsString();
        double double22 = jsonPrimitive20.getAsDouble();
        java.lang.String str23 = gson18.toJson((com.google.gson.JsonElement) jsonPrimitive20);
        com.google.gson.LongSerializationPolicy longSerializationPolicy24 = com.google.gson.LongSerializationPolicy.DEFAULT;
        com.google.gson.JsonElement jsonElement26 = longSerializationPolicy24.serialize((java.lang.Long) 1L);
        com.google.gson.JsonElement jsonElement27 = gson18.toJsonTree((java.lang.Object) longSerializationPolicy24);
        boolean boolean28 = jsonArray8.contains(jsonElement27);
        com.google.gson.JsonObject jsonObject29 = new com.google.gson.JsonObject();
        com.google.gson.JsonObject jsonObject31 = jsonObject29.getAsJsonObject("");
        jsonObject29.addProperty("com.google.gson.JsonParseException: ", (java.lang.Character) 'a');
        jsonObject29.addProperty("com.google.gson.JsonParseException: ", " ");
        boolean boolean38 = jsonArray8.contains((com.google.gson.JsonElement) jsonObject29);
        org.junit.Assert.assertNotNull(jsonElementItor1);
        org.junit.Assert.assertNotNull(jsonArray2);
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + 't' + "'", char5 == 't');
        org.junit.Assert.assertNotNull(jsonElementItor7);
        org.junit.Assert.assertNotNull(jsonArray8);
        org.junit.Assert.assertNotNull(longSerializationPolicy10);
        org.junit.Assert.assertNotNull(jsonElement12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "4" + "'", str21, "4");
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertEquals("'" + str23 + "' != '" + "\"4\"" + "'", str23, "\"4\"");
        org.junit.Assert.assertNotNull(longSerializationPolicy24);
        org.junit.Assert.assertNotNull(jsonElement26);
        org.junit.Assert.assertNotNull(jsonElement27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(jsonObject31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray2 = jsonObject0.getAsJsonArray("");
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor5 = jsonArray4.iterator();
        com.google.gson.JsonArray jsonArray6 = jsonArray4.getAsJsonArray();
        java.util.Spliterator<com.google.gson.JsonElement> jsonElementSpliterator7 = jsonArray4.spliterator();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement9 = null;
        com.google.gson.JsonElement jsonElement10 = jsonElementTypeAdapter8.toJsonTree(jsonElement9);
        com.google.gson.JsonNull jsonNull11 = jsonElement10.getAsJsonNull();
        boolean boolean12 = jsonNull11.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader13 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull11);
        boolean boolean14 = jsonArray4.contains((com.google.gson.JsonElement) jsonNull11);
        jsonObject0.add("\"hi!\"", (com.google.gson.JsonElement) jsonNull11);
        com.google.gson.Gson gson16 = new com.google.gson.Gson();
        java.lang.Appendable appendable17 = null;
        java.io.Writer writer18 = com.google.gson.internal.Streams.writerForAppendable(appendable17);
        com.google.gson.stream.JsonWriter jsonWriter19 = gson16.newJsonWriter(writer18);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter20 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass21 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter22 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson16, fieldNamingPolicyTypeAdapter20, fieldNamingPolicyClass21);
        com.google.gson.TypeAdapterFactory typeAdapterFactory23 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement24 = gson16.toJsonTree((java.lang.Object) typeAdapterFactory23);
        java.lang.String str25 = gson16.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter26 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass27 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter28 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson16, fieldNamingPolicyTypeAdapter26, fieldNamingPolicyClass27);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter29 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter29.nullValue();
        boolean boolean31 = jsonTreeWriter29.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter29.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter29.value((long) (byte) -1);
        jsonTreeWriter29.flush();
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter29.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter29.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter41 = jsonTreeWriter29.value("null");
        com.google.gson.stream.JsonWriter jsonWriter43 = jsonTreeWriter29.value(0L);
        java.lang.Object obj44 = null;
        fieldNamingPolicyArrayTypeAdapter28.write((com.google.gson.stream.JsonWriter) jsonTreeWriter29, obj44);
        com.google.gson.stream.JsonWriter jsonWriter47 = jsonTreeWriter29.value((java.lang.Number) 2);
        com.google.gson.stream.JsonWriter jsonWriter48 = jsonTreeWriter29.beginArray();
        boolean boolean49 = jsonNull11.equals((java.lang.Object) jsonWriter48);
        org.junit.Assert.assertNull(jsonArray2);
        org.junit.Assert.assertNotNull(jsonElementItor5);
        org.junit.Assert.assertNotNull(jsonArray6);
        org.junit.Assert.assertNotNull(jsonElementSpliterator7);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter8);
        org.junit.Assert.assertNotNull(jsonElement10);
        org.junit.Assert.assertNotNull(jsonNull11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(writer18);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(typeAdapterFactory23);
        org.junit.Assert.assertNotNull(jsonElement24);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(jsonWriter37);
        org.junit.Assert.assertNotNull(jsonWriter39);
        org.junit.Assert.assertNotNull(jsonWriter41);
        org.junit.Assert.assertNotNull(jsonWriter43);
        org.junit.Assert.assertNotNull(jsonWriter47);
        org.junit.Assert.assertNotNull(jsonWriter48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        com.google.gson.JsonObject jsonObject9 = new com.google.gson.JsonObject();
        com.google.gson.JsonElement jsonElement11 = jsonObject9.get("hi!");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet12 = jsonObject9.entrySet();
        java.lang.String str13 = gson0.toJson((java.lang.Object) strEntrySet12);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter14 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive16 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean17 = jsonPrimitive16.isJsonNull();
        com.google.gson.JsonElement jsonElement18 = jsonElementTypeAdapter14.toJsonTree((com.google.gson.JsonElement) jsonPrimitive16);
        boolean boolean19 = jsonPrimitive16.isString();
        boolean boolean20 = jsonPrimitive16.isNumber();
        boolean boolean21 = jsonPrimitive16.isString();
        java.lang.String str22 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive16);
        // The following exception was thrown during execution in test generation
        try {
            long long23 = jsonPrimitive16.getAsLong();
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"true\"");
        } catch (java.lang.NumberFormatException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNull(jsonElement11);
        org.junit.Assert.assertNotNull(strEntrySet12);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonElement18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "true" + "'", str22, "true");
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        java.lang.Object obj16 = null;
        com.google.gson.JsonElement jsonElement17 = fieldNamingPolicyArrayTypeAdapter15.toJsonTree(obj16);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = fieldNamingPolicyArrayTypeAdapter15.fromJson("true");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BOOLEAN at line 1 column 5 path $");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement17);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter13 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter13.nullValue();
        boolean boolean15 = jsonTreeWriter13.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter13.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter13.value((long) (byte) -1);
        jsonTreeWriter13.flush();
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter13.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter13.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter13.value("null");
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter13.value(0L);
        java.lang.Object obj28 = null;
        fieldNamingPolicyArrayTypeAdapter12.write((com.google.gson.stream.JsonWriter) jsonTreeWriter13, obj28);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter30 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement31 = null;
        com.google.gson.JsonElement jsonElement32 = jsonElementTypeAdapter30.toJsonTree(jsonElement31);
        com.google.gson.JsonNull jsonNull33 = jsonElement32.getAsJsonNull();
        boolean boolean34 = jsonNull33.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader35 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull33);
        com.google.gson.stream.JsonToken jsonToken36 = jsonTreeReader35.peek();
        java.lang.String str37 = jsonTreeReader35.toString();
        java.lang.Object obj38 = fieldNamingPolicyArrayTypeAdapter12.read((com.google.gson.stream.JsonReader) jsonTreeReader35);
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter30);
        org.junit.Assert.assertNotNull(jsonElement32);
        org.junit.Assert.assertNotNull(jsonNull33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + jsonToken36 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken36.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "JsonTreeReader" + "'", str37, "JsonTreeReader");
        org.junit.Assert.assertNull(obj38);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Character) '4');
        java.math.BigInteger bigInteger2 = jsonPrimitive1.getAsBigInteger();
        java.lang.Number number3 = jsonPrimitive1.getAsNumber();
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        com.google.gson.internal.Excluder excluder5 = new com.google.gson.internal.Excluder();
        boolean boolean6 = jsonArray4.equals((java.lang.Object) excluder5);
        boolean boolean7 = jsonPrimitive1.equals((java.lang.Object) jsonArray4);
        com.google.gson.JsonPrimitive jsonPrimitive8 = jsonPrimitive1.getAsJsonPrimitive();
        java.math.BigInteger bigInteger9 = jsonPrimitive8.getAsBigInteger();
        com.google.gson.Gson gson10 = new com.google.gson.Gson();
        java.lang.Appendable appendable11 = null;
        java.io.Writer writer12 = com.google.gson.internal.Streams.writerForAppendable(appendable11);
        com.google.gson.stream.JsonWriter jsonWriter13 = gson10.newJsonWriter(writer12);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter14 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson10, fieldNamingPolicyTypeAdapter14, fieldNamingPolicyClass15);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter17 = fieldNamingPolicyArrayTypeAdapter16.nullSafe();
        boolean boolean18 = jsonPrimitive8.equals((java.lang.Object) fieldNamingPolicyArrayTypeAdapter16);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter19 = fieldNamingPolicyArrayTypeAdapter16.nullSafe();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter20 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement21 = null;
        com.google.gson.JsonElement jsonElement22 = jsonElementTypeAdapter20.toJsonTree(jsonElement21);
        com.google.gson.JsonNull jsonNull23 = jsonElement22.getAsJsonNull();
        boolean boolean24 = jsonNull23.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader25 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull23);
        com.google.gson.stream.JsonToken jsonToken26 = jsonTreeReader25.peek();
        boolean boolean27 = jsonTreeReader25.hasNext();
        java.lang.String str28 = jsonTreeReader25.getPath();
        java.lang.Object obj29 = fieldNamingPolicyArrayTypeAdapter16.read((com.google.gson.stream.JsonReader) jsonTreeReader25);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(number3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jsonPrimitive8);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(writer12);
        org.junit.Assert.assertNotNull(jsonWriter13);
        org.junit.Assert.assertNotNull(objTypeAdapter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objTypeAdapter19);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter20);
        org.junit.Assert.assertNotNull(jsonElement22);
        org.junit.Assert.assertNotNull(jsonNull23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + jsonToken26 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken26.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "$" + "'", str28, "$");
        org.junit.Assert.assertNull(obj29);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = sqlDateTypeAdapter0.toJsonTree(date1);
        java.sql.Date date3 = null;
        com.google.gson.JsonElement jsonElement4 = sqlDateTypeAdapter0.toJsonTree(date3);
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter5 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter6 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonTreeWriter6.nullValue();
        boolean boolean8 = jsonTreeWriter6.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter9 = jsonTreeWriter6.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter11 = jsonTreeWriter6.value((long) (byte) -1);
        jsonTreeWriter6.flush();
        com.google.gson.stream.JsonWriter jsonWriter14 = jsonTreeWriter6.value(0L);
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter6.value((long) 'a');
        com.google.gson.stream.JsonWriter jsonWriter17 = jsonTreeWriter6.endArray();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonWriter17.value((java.lang.Number) 1.0d);
        java.sql.Date date20 = null;
        sqlDateTypeAdapter0.write(jsonWriter19, date20);
        com.google.gson.Gson gson22 = new com.google.gson.Gson();
        java.lang.Appendable appendable23 = null;
        java.io.Writer writer24 = com.google.gson.internal.Streams.writerForAppendable(appendable23);
        com.google.gson.stream.JsonWriter jsonWriter25 = gson22.newJsonWriter(writer24);
        java.sql.Date date26 = null;
        // The following exception was thrown during execution in test generation
        try {
            sqlDateTypeAdapter0.toJson(writer24, date26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(dateTypeAdapter5);
        org.junit.Assert.assertNotNull(jsonWriter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(jsonWriter11);
        org.junit.Assert.assertNotNull(jsonWriter14);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertNotNull(jsonWriter17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(writer24);
        org.junit.Assert.assertNotNull(jsonWriter25);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter7 = jsonWriter3.name("");
        com.google.gson.stream.JsonWriter jsonWriter8 = jsonWriter7.nullValue();
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter7);
        org.junit.Assert.assertNotNull(jsonWriter8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapterFactory typeAdapterFactory7 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement8 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter13 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter13, fieldNamingPolicyClass14);
        java.lang.Object obj16 = null;
        com.google.gson.JsonElement jsonElement17 = fieldNamingPolicyArrayTypeAdapter15.toJsonTree(obj16);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter18 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement19 = null;
        com.google.gson.JsonElement jsonElement20 = jsonElementTypeAdapter18.toJsonTree(jsonElement19);
        com.google.gson.JsonNull jsonNull21 = jsonElement20.getAsJsonNull();
        boolean boolean22 = jsonNull21.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader23 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull21);
        com.google.gson.stream.JsonToken jsonToken24 = jsonTreeReader23.peek();
        java.lang.String str25 = jsonTreeReader23.toString();
        jsonTreeReader23.setLenient(false);
        java.lang.Object obj28 = fieldNamingPolicyArrayTypeAdapter15.read((com.google.gson.stream.JsonReader) jsonTreeReader23);
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(typeAdapterFactory7);
        org.junit.Assert.assertNotNull(jsonElement8);
        org.junit.Assert.assertNotNull(jsonElement17);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter18);
        org.junit.Assert.assertNotNull(jsonElement20);
        org.junit.Assert.assertNotNull(jsonNull21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + jsonToken24 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken24.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "JsonTreeReader" + "'", str25, "JsonTreeReader");
        org.junit.Assert.assertNull(obj28);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter4 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass5 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter6 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson0, fieldNamingPolicyTypeAdapter4, fieldNamingPolicyClass5);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter7 = fieldNamingPolicyArrayTypeAdapter6.nullSafe();
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonElement jsonElement9 = null;
        com.google.gson.JsonElement jsonElement10 = jsonElementTypeAdapter8.toJsonTree(jsonElement9);
        com.google.gson.JsonNull jsonNull11 = jsonElement10.getAsJsonNull();
        boolean boolean12 = jsonNull11.isJsonPrimitive();
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader13 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonNull11);
        com.google.gson.stream.JsonToken jsonToken14 = jsonTreeReader13.peek();
        java.lang.Object obj15 = fieldNamingPolicyArrayTypeAdapter6.read((com.google.gson.stream.JsonReader) jsonTreeReader13);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter16 = com.google.gson.internal.bind.TypeAdapters.JSON_ELEMENT;
        com.google.gson.JsonPrimitive jsonPrimitive18 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean19 = jsonPrimitive18.isJsonNull();
        com.google.gson.JsonElement jsonElement20 = jsonElementTypeAdapter16.toJsonTree((com.google.gson.JsonElement) jsonPrimitive18);
        com.google.gson.TypeAdapter<com.google.gson.JsonElement> jsonElementTypeAdapter21 = jsonElementTypeAdapter16.nullSafe();
        com.google.gson.JsonArray jsonArray22 = new com.google.gson.JsonArray();
        com.google.gson.internal.Excluder excluder23 = new com.google.gson.internal.Excluder();
        boolean boolean24 = jsonArray22.equals((java.lang.Object) excluder23);
        com.google.gson.JsonArray jsonArray25 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor26 = jsonArray25.iterator();
        com.google.gson.JsonArray jsonArray27 = jsonArray25.getAsJsonArray();
        jsonArray27.add((java.lang.Boolean) true);
        jsonArray22.addAll(jsonArray27);
        int int31 = jsonArray27.size();
        com.google.gson.JsonElement jsonElement32 = jsonElementTypeAdapter16.toJsonTree((com.google.gson.JsonElement) jsonArray27);
        com.google.gson.JsonObject jsonObject33 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray35 = jsonObject33.getAsJsonArray("");
        com.google.gson.JsonElement jsonElement37 = jsonObject33.remove("4");
        java.lang.String str38 = jsonElementTypeAdapter16.toJson((com.google.gson.JsonElement) jsonObject33);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj39 = fieldNamingPolicyArrayTypeAdapter6.fromJsonTree((com.google.gson.JsonElement) jsonObject33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(objTypeAdapter7);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter8);
        org.junit.Assert.assertNotNull(jsonElement10);
        org.junit.Assert.assertNotNull(jsonNull11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + jsonToken14 + "' != '" + com.google.gson.stream.JsonToken.NULL + "'", jsonToken14.equals(com.google.gson.stream.JsonToken.NULL));
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jsonElement20);
        org.junit.Assert.assertNotNull(jsonElementTypeAdapter21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jsonElementItor26);
        org.junit.Assert.assertNotNull(jsonArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(jsonElement32);
        org.junit.Assert.assertNull(jsonArray35);
        org.junit.Assert.assertNull(jsonElement37);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "{}" + "'", str38, "{}");
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Appendable appendable1 = null;
        java.io.Writer writer2 = com.google.gson.internal.Streams.writerForAppendable(appendable1);
        com.google.gson.stream.JsonWriter jsonWriter3 = gson0.newJsonWriter(writer2);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setHtmlSafe(true);
        jsonWriter3.setLenient(true);
        jsonWriter3.setLenient(true);
        com.google.gson.stream.JsonWriter jsonWriter13 = jsonWriter3.name("JsonTreeReader");
        org.junit.Assert.assertNotNull(writer2);
        org.junit.Assert.assertNotNull(jsonWriter3);
        org.junit.Assert.assertNotNull(jsonWriter13);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor1 = jsonArray0.iterator();
        com.google.gson.JsonArray jsonArray2 = jsonArray0.getAsJsonArray();
        jsonArray2.add((java.lang.Boolean) true);
        boolean boolean5 = jsonArray2.getAsBoolean();
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        java.lang.Appendable appendable7 = null;
        java.io.Writer writer8 = com.google.gson.internal.Streams.writerForAppendable(appendable7);
        com.google.gson.stream.JsonWriter jsonWriter9 = gson6.newJsonWriter(writer8);
        com.google.gson.TypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyTypeAdapter10 = null;
        java.lang.Class<com.google.gson.FieldNamingPolicy> fieldNamingPolicyClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy> fieldNamingPolicyArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.FieldNamingPolicy>(gson6, fieldNamingPolicyTypeAdapter10, fieldNamingPolicyClass11);
        com.google.gson.TypeAdapterFactory typeAdapterFactory13 = com.google.gson.internal.bind.TypeAdapters.BIT_SET_FACTORY;
        com.google.gson.JsonElement jsonElement14 = gson6.toJsonTree((java.lang.Object) typeAdapterFactory13);
        boolean boolean15 = jsonArray2.equals((java.lang.Object) typeAdapterFactory13);
        org.junit.Assert.assertNotNull(jsonElementItor1);
        org.junit.Assert.assertNotNull(jsonArray2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(writer8);
        org.junit.Assert.assertNotNull(jsonWriter9);
        org.junit.Assert.assertNotNull(typeAdapterFactory13);
        org.junit.Assert.assertNotNull(jsonElement14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = sqlDateTypeAdapter0.toJsonTree(date1);
        com.google.gson.JsonNull jsonNull3 = com.google.gson.JsonNull.INSTANCE;
        java.sql.Date date4 = sqlDateTypeAdapter0.fromJsonTree((com.google.gson.JsonElement) jsonNull3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        java.lang.Appendable appendable6 = null;
        java.io.Writer writer7 = com.google.gson.internal.Streams.writerForAppendable(appendable6);
        com.google.gson.stream.JsonWriter jsonWriter8 = gson5.newJsonWriter(writer7);
        jsonWriter8.setHtmlSafe(true);
        com.google.gson.stream.JsonWriter jsonWriter12 = jsonWriter8.name("");
        java.sql.Date date13 = null;
        sqlDateTypeAdapter0.write(jsonWriter12, date13);
        com.google.gson.JsonObject jsonObject15 = new com.google.gson.JsonObject();
        com.google.gson.JsonArray jsonArray17 = jsonObject15.getAsJsonArray("");
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter18.nullValue();
        com.google.gson.internal.Streams.write((com.google.gson.JsonElement) jsonObject15, (com.google.gson.stream.JsonWriter) jsonTreeWriter18);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter18.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter18.endArray();
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter18.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter18.endObject();
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter18.value((long) 10);
        jsonTreeWriter18.setSerializeNulls(true);
        java.sql.Date date29 = null;
        sqlDateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter18, date29);
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter18.value((java.lang.Number) (short) 10);
        boolean boolean33 = jsonTreeWriter18.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter18.nullValue();
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonNull3);
        org.junit.Assert.assertNull(date4);
        org.junit.Assert.assertNotNull(writer7);
        org.junit.Assert.assertNotNull(jsonWriter8);
        org.junit.Assert.assertNotNull(jsonWriter12);
        org.junit.Assert.assertNull(jsonArray17);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jsonWriter34);
    }
}

