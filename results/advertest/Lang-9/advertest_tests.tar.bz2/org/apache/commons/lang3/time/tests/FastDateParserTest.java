package gentest.org.apache.commons.lang3.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.lang3.time.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.SortedMap;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
public class FastDateParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                           public void testInit_ValidPattern_TypicalValues() throws Exception {
                                                                                                                                                                                               java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                                                                               constructor.setAccessible(true);
                                                                                                                                                                                               FastDateParser parser = constructor.newInstance("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
                                                                                                                                                                                               
                                                                                                                                                                                               java.lang.reflect.Method getParsePatternMethod = FastDateParser.class.getDeclaredMethod("getParsePattern");
                                                                                                                                                                                               getParsePatternMethod.setAccessible(true);
                                                                                                                                                                                               assertNotNull(getParsePatternMethod.invoke(parser));
                                                                                                                                                                                               
                                                                                                                                                                                               assertEquals("yyyy-MM-dd", parser.getPattern());
                                                                                                                                                                                               assertEquals(TimeZone.getTimeZone("UTC"), parser.getTimeZone());
                                                                                                                                                                                               assertEquals(Locale.US, parser.getLocale());
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                           public void testInit_InvalidPattern_ThrowsIllegalArgumentException() {
                                                                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                               thrown.expectMessage("Invalid pattern");
                                                                                                                                                                                               
                                                                                                                                                                                               // Passing a pattern format that doesn't match the formatPattern matcher using an anonymous subclass to access the protected constructor
                                                                                                                                                                                               new FastDateParser("", TimeZone.getDefault(), Locale.US) {};
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                           public void testInit_UnmatchedSuffix_ThrowsIllegalArgumentException() {
                                                                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                               // The parser will successfully match the beginning ('yyyy') but fail to parse/consume the remaining invalid syntax.
                                                                                                                                                                                               thrown.expectMessage("Failed to parse");
                                                                                                                                                                                       
                                                                                                                                                                                               new FastDateParser("yyyy***", TimeZone.getDefault(), Locale.US) {};
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                      public void testInitMutantDetectYearVsMonth() throws Exception {
                                                                                                                                                                                          // Using a 2-digit year pattern ("yy") which relies on `thisYear` for century interpretation.
                                                                                                                                                                                          // For example, if current year is 2023, "23" should resolve to 2023.
                                                                                                                                                                                          // If mutated to Calendar.MONTH (0-11), `thisYear` becomes a small number (e.g., 0 for January),
                                                                                                                                                                                          // causing two-digit year parsing calculations to fail or yield incorrect centuries (e.g., 1923 instead of 2023).
                                                                                                                                                                                          
                                                                                                                                                                                          java.lang.reflect.Constructor<org.apache.commons.lang3.time.FastDateParser> constructor = 
                                                                                                                                                                                              org.apache.commons.lang3.time.FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                                                                          constructor.setAccessible(true);
                                                                                                                                                                                          org.apache.commons.lang3.time.FastDateParser parser = constructor.newInstance("yy", TimeZone.getDefault(), Locale.getDefault());
                                                                                                                                                                                          
                                                                                                                                                                                          Date parsedDate = parser.parse("23");
                                                                                                                                                                                          
                                                                                                                                                                                          Calendar calendar = Calendar.getInstance();
                                                                                                                                                                                          calendar.setTime(parsedDate);
                                                                                                                                                                                          
                                                                                                                                                                                          int parsedYear = calendar.get(Calendar.YEAR);
                                                                                                                                                                                          int currentActualYear = Calendar.getInstance().get(Calendar.YEAR);
                                                                                                                                                                                          
                                                                                                                                                                                          // The parsed year for "23" should match the current century's year (e.g., 2023), 
                                                                                                                                                                                          // not a corrupted year resulting from `thisYear` being set to a month value (0-11).
                                                                                                                                                                                          assertEquals(currentActualYear, parsedYear);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                     public void testInitInitializesNameValues() throws Exception {
                                                                                                                                                                                         // Use reflection to instantiate FastDateParser since the constructor is protected
                                                                                                                                                                                         Class<?> parserClass = FastDateParser.class;
                                                                                                                                                                                         java.lang.reflect.Constructor<?> ctor = parserClass.getDeclaredConstructor(String.class, TimeZone.class, Locale.ENGLISH.getClass());
                                                                                                                                                                                         ctor.setAccessible(true);
                                                                                                                                                                                         Object parser = ctor.newInstance("MMMM", TimeZone.getDefault(), Locale.ENGLISH);
                                                                                                                                                                                         
                                                                                                                                                                                         // Invoke the private init() method using reflection
                                                                                                                                                                                         java.lang.reflect.Method initMethod = parserClass.getDeclaredMethod("init");
                                                                                                                                                                                         initMethod.setAccessible(true);
                                                                                                                                                                                         initMethod.invoke(parser);
                                                                                                                                                                                         
                                                                                                                                                                                         // Access the private `nameValues` field using reflection to verify it is initialized
                                                                                                                                                                                         java.lang.reflect.Field nameValuesField = parserClass.getDeclaredField("nameValues");
                                                                                                                                                                                         nameValuesField.setAccessible(true);
                                                                                                                                                                                         Object nameValues = nameValuesField.get(parser);
                                                                                                                                                                                         
                                                                                                                                                                                         // Assert that nameValues was properly initialized and is not null
                                                                                                                                                                                         assertNotNull("nameValues should not be null after init()", nameValues);
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                            public void testMutantNextStrategyIsNullOnPatternBreak() throws Exception {
                                                                                                                                                                                // Use reflection to invoke the protected constructor of FastDateParser
                                                                                                                                                                                java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                                FastDateParser parser = constructor.newInstance("yyyy ZZZZZ", TimeZone.getDefault(), Locale.getDefault());
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to access the private field 'nextStrategy'
                                                                                                                                                                                java.lang.reflect.Field nextStrategyField = FastDateParser.class.getDeclaredField("nextStrategy");
                                                                                                                                                                                nextStrategyField.setAccessible(true);
                                                                                                                                                                                Object nextStrategyValue = nextStrategyField.get(parser);
                                                                                                                                                                                
                                                                                                                                                                                // In the original code, when the loop breaks because lookingAt() fails, nextStrategy is set to null.
                                                                                                                                                                                // The mutant sets nextStrategy = currentStrategy, which would leave it non-null.
                                                                                                                                                                                org.junit.Assert.assertNull("nextStrategy should be null after breaking out of the pattern matching loop", nextStrategyValue);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                       public void testInitMutantDetection() throws Exception {
                                                                                                                                                                           // Using a pattern where the single/final strategy's addRegex returns true.
                                                                                                                                                                           // Under the mutant, the condition !addRegex(...) would evaluate to false,
                                                                                                                                                                           // causing the strategy to be skipped and not added to the collector.
                                                                                                                                                                           String pattern = "yyyy";
                                                                                                                                                                           TimeZone tz = TimeZone.getTimeZone("UTC");
                                                                                                                                                                           Locale locale = Locale.US;
                                                                                                                                                                           
                                                                                                                                                                           java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                                                           constructor.setAccessible(true);
                                                                                                                                                                           FastDateParser parser = constructor.newInstance(pattern, tz, locale);
                                                                                                                                                                           
                                                                                                                                                                           // If the mutant is present, the strategy array will not contain the strategy for "yyyy",
                                                                                                                                                                           // causing parse() to fail or return a Date where the year is not parsed correctly.
                                                                                                                                                                           java.util.Date date = parser.parse("2023");
                                                                                                                                                                           
                                                                                                                                                                           java.util.Calendar cal = java.util.Calendar.getInstance(tz, locale);
                                                                                                                                                                           cal.setTime(date);
                                                                                                                                                                           
                                                                                                                                                                           org.junit.Assert.assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                                                                                                                                                       }

    @Test
                                                                                                                                                                  public void testParserInitializationAndParsing() throws Exception {
                                                                                                                                                                      String pattern = "yyyy-MM-dd";
                                                                                                                                                                      TimeZone timeZone = TimeZone.getTimeZone("UTC");
                                                                                                                                                                      Locale locale = Locale.US;
                                                                                                                                                              
                                                                                                                                                                      java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                                                      constructor.setAccessible(true);
                                                                                                                                                                      FastDateParser parser = constructor.newInstance(pattern, timeZone, locale);
                                                                                                                                                                      
                                                                                                                                                                      String source = "2023-10-05";
                                                                                                                                                                      Date parsedDate = parser.parse(source);
                                                                                                                                                                      
                                                                                                                                                                      assertNotNull("Parsed date should not be null if strategies were correctly added", parsedDate);
                                                                                                                                                                      
                                                                                                                                                                      Calendar calendar = Calendar.getInstance(timeZone, locale);
                                                                                                                                                                      calendar.setTime(parsedDate);
                                                                                                                                                                      
                                                                                                                                                                      assertEquals(2023, calendar.get(Calendar.YEAR));
                                                                                                                                                                      assertEquals(Calendar.OCTOBER, calendar.get(Calendar.MONTH));
                                                                                                                                                                      assertEquals(5, calendar.get(Calendar.DAY_OF_MONTH));
                                                                                                                                                                  }

    @Test
                                                                                                                                                             public void testInitMutantCurrentFormatFieldNotNull() throws Exception {
                                                                                                                                                                 // A pattern with multiple format fields ensures the loop runs more than once,
                                                                                                                                                                 // exercising the assignment: currentFormatField = nextFormatField;
                                                                                                                                                                 // The mutant sets currentFormatField = null, which breaks subsequent strategy lookups in the loop.
                                                                                                                                                                 java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                                                 FastDateParser parser = constructor.newInstance("yyyy-MM", TimeZone.getDefault(), Locale.getDefault());
                                                                                                                                                                 
                                                                                                                                                                 // Verify that the parser was successfully initialized and can parse a valid date string matching the pattern.
                                                                                                                                                                 // Under the mutant, the strategies and parse pattern would be incorrectly constructed, 
                                                                                                                                                                 // causing a ParseException or failure to correctly parse the date.
                                                                                                                                                                 java.util.Date date = parser.parse("2023-10");
                                                                                                                                                                 assertNotNull("Parser should successfully parse a valid date string with multiple fields", date);
                                                                                                                                                                 
                                                                                                                                                                 java.util.Calendar calendar = java.util.Calendar.getInstance();
                                                                                                                                                                 calendar.setTime(date);
                                                                                                                                                                 assertEquals(2023, calendar.get(java.util.Calendar.YEAR));
                                                                                                                                                                 assertEquals(java.util.Calendar.OCTOBER, calendar.get(java.util.Calendar.MONTH));
                                                                                                                                                             }

    @Test
                                                                                                                                                        public void testInitThrowsIllegalArgumentExceptionOnIncompleteParse() throws Exception {
                                                                                                                                                            TimeZone tz = TimeZone.getDefault();
                                                                                                                                                            Locale locale = Locale.US;
                                                                                                                                                            
                                                                                                                                                            java.lang.reflect.Constructor<org.apache.commons.lang3.time.FastDateParser> constructor = 
                                                                                                                                                                org.apache.commons.lang3.time.FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            try {
                                                                                                                                                                constructor.newInstance("yyyy-MM-dd ZZZZ ExtraTokens", tz, locale);
                                                                                                                                                                org.junit.Assert.fail("Expected IllegalArgumentException for incomplete parse pattern");
                                                                                                                                                            } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                                                                org.junit.Assert.assertTrue(e.getTargetException() instanceof IllegalArgumentException);
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                                   public void testInitMutantDetection1() throws Exception {
                                                                                                                                                       // Instantiate FastDateParser with a simple pattern "yyyy" using reflection due to protected constructor access.
                                                                                                                                                       Class<?> clazz = Class.forName("org.apache.commons.lang3.time.FastDateParser");
                                                                                                                                                       java.lang.reflect.Constructor<?> constructor = clazz.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                                       constructor.setAccessible(true);
                                                                                                                                                       
                                                                                                                                                       Object parserObj = constructor.newInstance("yyyy", TimeZone.getDefault(), Locale.getDefault());
                                                                                                                                                       
                                                                                                                                                       // Attempt to parse a valid date string using the parser via reflection or public parse method if accessible.
                                                                                                                                                       java.lang.reflect.Method parseMethod = clazz.getMethod("parse", String.class);
                                                                                                                                                       java.util.Date date = (java.util.Date) parseMethod.invoke(parserObj, "2023");
                                                                                                                                                       
                                                                                                                                                       assertNotNull("Parsed date should not be null if strategy was correctly added", date);
                                                                                                                                                       
                                                                                                                                                       java.util.Calendar calendar = java.util.Calendar.getInstance();
                                                                                                                                                       calendar.setTime(date);
                                                                                                                                                       assertEquals("The parsed year should match", 2023, calendar.get(java.util.Calendar.YEAR));
                                                                                                                                                   }

    @Test
                                                                                                                                              public void testInitMutantCollectorClear() {
                                                                                                                                                  String pattern = "yyyy-MM-dd";
                                                                                                                                                  TimeZone timeZone = TimeZone.getTimeZone("UTC");
                                                                                                                                                  Locale locale = Locale.US;
                                                                                                                                          
                                                                                                                                                  FastDateParser parser;
                                                                                                                                                  try {
                                                                                                                                                      java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                                      constructor.setAccessible(true);
                                                                                                                                                      parser = constructor.newInstance(pattern, timeZone, locale);
                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                      throw new RuntimeException(e);
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  String source = "2023-10-05";
                                                                                                                                                  Date parsedDate;
                                                                                                                                                  try {
                                                                                                                                                      parsedDate = parser.parse(source);
                                                                                                                                                  } catch (java.text.ParseException e) {
                                                                                                                                                      throw new RuntimeException(e);
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  assertNotNull("Parsed date should not be null", parsedDate);
                                                                                                                                                  
                                                                                                                                                  Calendar calendar = Calendar.getInstance(timeZone, locale);
                                                                                                                                                  calendar.setTime(parsedDate);
                                                                                                                                                  
                                                                                                                                                  assertEquals(2023, calendar.get(Calendar.YEAR));
                                                                                                                                                  assertEquals(Calendar.OCTOBER, calendar.get(Calendar.MONTH));
                                                                                                                                                  assertEquals(5, calendar.get(Calendar.DAY_OF_MONTH));
                                                                                                                                              }

    @Test
                                                                                                                                     public void testInitResetsCurrentFormatFieldToNull() throws Exception {
                                                                                                                                         java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                         constructor.setAccessible(true);
                                                                                                                                         FastDateParser parser = constructor.newInstance("yyyy-MM-dd", TimeZone.getDefault(), Locale.getDefault());
                                                                                                                                         
                                                                                                                                         java.lang.reflect.Field field = FastDateParser.class.getDeclaredField("currentFormatField");
                                                                                                                                         field.setAccessible(true);
                                                                                                                                         Object currentFormatFieldVal = field.get(parser);
                                                                                                                                         
                                                                                                                                         org.junit.Assert.assertNull("currentFormatField should be reset to null after initialization", currentFormatFieldVal);
                                                                                                                                     }

    @Test
                                                                                                                                public void testInitStrategiesNotNull() throws Exception {
                                                                                                                                    String pattern = "yyyy-MM-dd";
                                                                                                                                    TimeZone timeZone = TimeZone.getTimeZone("UTC");
                                                                                                                                    Locale locale = Locale.US;
                                                                                                                            
                                                                                                                                    java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                    FastDateParser parser = constructor.newInstance(pattern, timeZone, locale);
                                                                                                                            
                                                                                                                                    // Attempting to parse a date string will invoke the strategies array. 
                                                                                                                                    // If the mutant survived (strategies = null), a NullPointerException will be thrown.
                                                                                                                                    Date parsedDate = parser.parse("2023-10-05");
                                                                                                                                    
                                                                                                                                    assertNotNull("Parsed date should not be null if strategies are correctly initialized", parsedDate);
                                                                                                                                }

    @Test
                                                                                                                            public void testGetParsePatternVisibilityMutant() throws Exception {
                                                                                                                                Class<?> parserClass = FastDateParser.class;
                                                                                                                                java.lang.reflect.Method method = parserClass.getDeclaredMethod("getParsePattern");
                                                                                                                                
                                                                                                                                // The original method has package-private visibility (neither public, private, nor protected).
                                                                                                                                // The mutant changes it to public. We assert that it should NOT be public.
                                                                                                                                int modifiers = method.getModifiers();
                                                                                                                                boolean isPublic = java.lang.reflect.Modifier.isPublic(modifiers);
                                                                                                                                
                                                                                                                                org.junit.Assert.assertFalse(
                                                                                                                                    "Mutant detected: getParsePattern() should have package-private visibility, but it is public.",
                                                                                                                                    isPublic
                                                                                                                                );
                                                                                                                            }

    @Test
                                                                                                                          public void testInitRespectsTimeZoneAndLocale() throws Exception {
                                                                                                                              // Choose a timezone that might have a different year at certain times, 
                                                                                                                              // or simply ensure a non-default timezone and locale are correctly used.
                                                                                                                              TimeZone tz = TimeZone.getTimeZone("GMT+14:00");
                                                                                                                              Locale loc = Locale.US;
                                                                                                                              
                                                                                                                              // FastDateParser constructor is protected, so instantiate via an anonymous subclass
                                                                                                                              FastDateParser parser = new FastDateParser("yy", tz, loc) {};
                                                                                                                              
                                                                                                                              // Use reflection to inspect the private 'thisYear' field initialized by init()
                                                                                                                              java.lang.reflect.Field field = FastDateParser.class.getDeclaredField("thisYear");
                                                                                                                              field.setAccessible(true);
                                                                                                                              int parserThisYear = (Integer) field.get(parser);
                                                                                                                              
                                                                                                                              // Calculate what the year *should* be using the specific timeZone and locale
                                                                                                                              Calendar cal = Calendar.getInstance(tz, loc);
                                                                                                                              int expectedYear = cal.get(Calendar.YEAR);
                                                                                                                              
                                                                                                                              org.junit.Assert.assertEquals(
                                                                                                                                  "FastDateParser.init() should initialize thisYear using the provided TimeZone and Locale",
                                                                                                                                  expectedYear,
                                                                                                                                  parserThisYear
                                                                                                                              );
                                                                                                                          }

    @Test
                                                                                                                     public void testInitLoopBehaviorAndMutantDetection() {
                                                                                                                         // Test a pattern with multiple format fields to fully exercise the for(;;) loop iterations using a subclass to access protected constructor
                                                                                                                         FastDateParser parserMulti = new FastDateParser("yyyy-MM-dd HH:mm:ss", TimeZone.getDefault(), Locale.getDefault()) {};
                                                                                                                         assertEquals("yyyy-MM-dd HH:mm:ss", parserMulti.getPattern());
                                                                                                                 
                                                                                                                         // Test a pattern with a single format field
                                                                                                                         FastDateParser parserSingle = new FastDateParser("yyyy", TimeZone.getDefault(), Locale.getDefault()) {};
                                                                                                                         assertEquals("yyyy", parserSingle.getPattern());
                                                                                                                 
                                                                                                                         // Test an invalid pattern that triggers exceptions during or after the loop execution
                                                                                                                         try {
                                                                                                                             new FastDateParser("", TimeZone.getDefault(), Locale.getDefault()) {};
                                                                                                                             fail("Expected IllegalArgumentException for empty pattern");
                                                                                                                         } catch (IllegalArgumentException e) {
                                                                                                                             assertTrue(e.getMessage().contains("Invalid pattern"));
                                                                                                                         }
                                                                                                                     }

    @Test
                                                                                                                public void testInitThrowsExceptionOnUnconsumedPattern() {
                                                                                                                    // A pattern with a valid start ("yyyy-MM-dd") followed by unparsable trailing characters (" INVALID")
                                                                                                                    // This ensures regionStart() != regionEnd() after the strategy extraction loop.
                                                                                                                    try {
                                                                                                                        new FastDateParser("yyyy-MM-dd INVALID", TimeZone.getDefault(), Locale.getDefault()) {};
                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                        // expected
                                                                                                                        return;
                                                                                                                    }
                                                                                                                    org.junit.Assert.fail("Expected IllegalArgumentException for unconsumed pattern");
                                                                                                                }

    @Test
                                                                                                       public void testInitMutantDetection2() {
                                                                                                           // Create a FastDateParser with a pattern that requires multiple strategies (year, month, day)
                                                                                                           String pattern = "yyyy-MM-dd";
                                                                                                           TimeZone timeZone = TimeZone.getDefault();
                                                                                                           Locale locale = Locale.getDefault();
                                                                                                   
                                                                                                           FastDateParser parser = null;
                                                                                                           try {
                                                                                                               java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                               constructor.setAccessible(true);
                                                                                                               parser = constructor.newInstance(pattern, timeZone, locale);
                                                                                                           } catch (Exception e) {
                                                                                                               org.junit.Assert.fail("Failed to instantiate FastDateParser via reflection: " + e.getMessage());
                                                                                                           }
                                                                                                   
                                                                                                           // Attempt to parse a valid date string using the parser.
                                                                                                           // The original code correctly populates strategies and parses the date successfully.
                                                                                                           // The mutant sets strategies = new Strategy[0], causing parsing to fail or return incorrect results.
                                                                                                           java.util.Date date = null;
                                                                                                           try {
                                                                                                               date = parser.parse("2023-10-05");
                                                                                                           } catch (java.text.ParseException e) {
                                                                                                               org.junit.Assert.fail("Failed to parse date: " + e.getMessage());
                                                                                                           }
                                                                                                           
                                                                                                           assertNotNull("The parse result should not be null if strategies are correctly initialized", date);
                                                                                                           
                                                                                                           // We can also verify via reflection that strategies array is not empty
                                                                                                           try {
                                                                                                               java.lang.reflect.Field strategiesField = FastDateParser.class.getDeclaredField("strategies");
                                                                                                               strategiesField.setAccessible(true);
                                                                                                               Object[] strategies = (Object[]) strategiesField.get(parser);
                                                                                                               
                                                                                                               // A pattern like "yyyy-MM-dd" should produce multiple strategies (at least 3: year, month, day separators/strategies)
                                                                                                               assertTrue("Strategies array should contain parsed strategies, not be empty", strategies.length > 0);
                                                                                                           } catch (Exception e) {
                                                                                                               org.junit.Assert.fail("Reflection failed: " + e.getMessage());
                                                                                                           }
                                                                                                       }

    @Test
                                                                                                  public void testParsePatternMutation() {
                                                                                                      String pattern = "yyyy-MM-dd";
                                                                                                      TimeZone timeZone = TimeZone.getTimeZone("UTC");
                                                                                                      Locale locale = Locale.US;
                                                                                                      
                                                                                                      FastDateParser parser = null;
                                                                                                      try {
                                                                                                          java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                          constructor.setAccessible(true);
                                                                                                          parser = constructor.newInstance(pattern, timeZone, locale);
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to instantiate FastDateParser via reflection: " + e.getMessage());
                                                                                                      }
                                                                                                      
                                                                                                      // Verify that the parsePattern is compiled from the actual regex and not an empty string.
                                                                                                      // An empty pattern regex would not match a formatted date string like "2023-10-05".
                                                                                                      String source = "2023-10-05";
                                                                                                      java.util.Date date = null;
                                                                                                      try {
                                                                                                          date = parser.parse(source);
                                                                                                      } catch (java.text.ParseException e) {
                                                                                                          fail("ParseException thrown while parsing valid date: " + e.getMessage());
                                                                                                      }
                                                                                                      
                                                                                                      assertNotNull("The parse method should successfully parse a valid date matching the pattern, " +
                                                                                                                    "detecting if parsePattern was incorrectly compiled as an empty string.", date);
                                                                                                  }

    @Test
                                                                                         public void testInitThrowsDetailedIllegalArgumentExceptionOnPartialParse() {
                                                                                             TimeZone tz = TimeZone.getDefault();
                                                                                             Locale locale = Locale.US;
                                                                                             // A pattern that parses valid tokens ("yyyy-MM-dd") but leaves trailing unconsumed characters (" invalid")
                                                                                             String invalidPattern = "yyyy-MM-dd invalid";
                                                                                             
                                                                                             try {
                                                                                                 java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                                 constructor.setAccessible(true);
                                                                                                 constructor.newInstance(invalidPattern, tz, locale);
                                                                                                 org.junit.Assert.fail("Expected IllegalArgumentException to be thrown");
                                                                                             } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                 Throwable cause = e.getCause();
                                                                                                 org.junit.Assert.assertTrue("Expected IllegalArgumentException", cause instanceof IllegalArgumentException);
                                                                                                 String message = cause.getMessage();
                                                                                                 org.junit.Assert.assertNotNull("Exception message should not be null", message);
                                                                                                 org.junit.Assert.assertTrue(
                                                                                                     "Exception message should contain the failure details, but was: " + message,
                                                                                                     message.contains("Failed to parse") && message.contains("gave up at index")
                                                                                                 );
                                                                                             } catch (Exception e) {
                                                                                                 org.junit.Assert.fail("Unexpected exception: " + e.getMessage());
                                                                                             }
                                                                                         }

    @Test
                                                                                    public void testInitThisYearMutation() throws Exception {
                                                                                        // Parse a 2-digit year pattern, which relies heavily on 'thisYear' for century pivoting.
                                                                                        java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                        constructor.setAccessible(true);
                                                                                        FastDateParser parser = constructor.newInstance("yy", TimeZone.getDefault(), Locale.getDefault());
                                                                                        
                                                                                        // Get the current year dynamically to keep the test robust across years
                                                                                        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
                                                                                        String twoDigitYearStr = String.format("%02d", currentYear % 100);
                                                                                        
                                                                                        Date parsedDate = parser.parse(twoDigitYearStr);
                                                                                        Calendar calendar = Calendar.getInstance();
                                                                                        calendar.setTime(parsedDate);
                                                                                        
                                                                                        // If the mutant is active (thisYear = 0), the parsed year will be incorrect (e.g., century pivot around 0).
                                                                                        // The correct behavior should map it to the current century's corresponding year.
                                                                                        assertEquals(currentYear, calendar.get(Calendar.YEAR));
                                                                                    }

    @Test
                                                                               public void testInitMultiFieldPatternCapturesMutant() throws Exception {
                                                                                   // Creating a FastDateParser with a multi-field pattern requires 
                                                                                   // the matcher region to correctly advance past the first field.
                                                                                   // The mutant resets the region to (0, 0), which breaks multi-field pattern parsing.
                                                                                   Class<?> clazz = org.apache.commons.lang3.time.FastDateParser.class;
                                                                                   java.lang.reflect.Constructor<?> constructor = clazz.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                                   constructor.setAccessible(true);
                                                                                   Object parser = constructor.newInstance("yyyy-MM-dd", TimeZone.getDefault(), Locale.getDefault());
                                                                                   
                                                                                   java.lang.reflect.Method method = clazz.getDeclaredMethod("getParsePattern");
                                                                                   method.setAccessible(true);
                                                                                   Object pattern = method.invoke(parser);
                                                                                   assertNotNull(pattern);
                                                                               }

    @Test
                                                                          public void testParserInitializationWithMultipleFields() throws Exception {
                                                                              // Using a multi-field pattern to ensure the loop progresses and updates currentFormatField.
                                                                              // If currentFormatField = nextFormatField is mutated to currentFormatField = currentFormatField,
                                                                              // the parser will only process the first field ("HH") repeatedly or fail to build correct strategies.
                                                                              java.lang.reflect.Constructor<org.apache.commons.lang3.time.FastDateParser> constructor = 
                                                                                  org.apache.commons.lang3.time.FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                              constructor.setAccessible(true);
                                                                              org.apache.commons.lang3.time.FastDateParser parser = constructor.newInstance("HH:mm", TimeZone.getDefault(), Locale.getDefault());
                                                                              
                                                                              // Parsing a valid date/time string matching the multi-field pattern
                                                                              java.util.Date date = parser.parse("14:30");
                                                                              
                                                                              // If the mutant survives, the second field ("mm") is never processed correctly as nextFormatField,
                                                                              // resulting in incorrect parsing behavior or mismatching strategy array size.
                                                                              assertNotNull("Parsed date should not be null", date);
                                                                              
                                                                              java.util.Calendar calendar = java.util.Calendar.getInstance();
                                                                              calendar.setTime(date);
                                                                              
                                                                              // Verify that both hours and minutes are correctly parsed, which requires successful advancement of format fields.
                                                                              assertEquals("Hour should be parsed correctly", 14, calendar.get(java.util.Calendar.HOUR_OF_DAY));
                                                                              assertEquals("Minute should be parsed correctly", 30, calendar.get(java.util.Calendar.MINUTE));
                                                                          }

    @Test
                                                                        public void testStrategiesArrayInitialization() throws Exception {
                                                                            java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                            constructor.setAccessible(true);
                                                                            FastDateParser parser = constructor.newInstance("yyyy-MM-dd HH:mm:ss", TimeZone.getDefault(), Locale.US);
                                                                            
                                                                            java.lang.reflect.Field strategiesField = FastDateParser.class.getDeclaredField("strategies");
                                                                            strategiesField.setAccessible(true);
                                                                            Object[] parsedStrategies = (Object[]) strategiesField.get(parser);
                                                                            
                                                                            assertNotNull("Strategies array should not be null", parsedStrategies);
                                                                            assertTrue("Strategies array length should be greater than 0", parsedStrategies.length > 0);
                                                                            
                                                                            // Verify parsing works correctly with the populated strategies
                                                                            java.util.Date date = parser.parse("2023-10-05 14:30:00");
                                                                            assertNotNull("Parsed date should not be null", date);
                                                                        }

    @Test
                                                               public void testInitCompilesRegexNotRawPattern() throws Exception {
                                                                   String pattern = "yyyy-MM-dd";
                                                                   TimeZone timeZone = TimeZone.getDefault();
                                                                   Locale locale = Locale.US;
                                                                   
                                                                   java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                                   constructor.setAccessible(true);
                                                                   FastDateParser parser = constructor.newInstance(pattern, timeZone, locale);
                                                                   
                                                                   java.lang.reflect.Method getParsePatternMethod = FastDateParser.class.getDeclaredMethod("getParsePattern");
                                                                   getParsePatternMethod.setAccessible(true);
                                                                   Pattern parsePattern = (Pattern) getParsePatternMethod.invoke(parser);
                                                                   
                                                                   // The original code compiles regex.toString() which translates format tokens 
                                                                   // into regular expression patterns (e.g., \\p{IsNd}{4} for yyyy).
                                                                   // The mutant compiles the raw 'pattern' string directly (i.e., "yyyy-MM-dd").
                                                                   // Therefore, the compiled pattern's regex string should not equal the raw pattern string.
                                                                   org.junit.Assert.assertNotEquals(
                                                                       "The parsePattern should be compiled from the translated regex, not the raw format pattern",
                                                                       pattern,
                                                                       parsePattern.pattern()
                                                                   );
                                                               }

    @Test
                                                          public void testInitMutantCapture() throws Exception {
                                                              // Using reflection to invoke the protected constructor of FastDateParser
                                                              java.lang.reflect.Constructor<org.apache.commons.lang3.time.FastDateParser> constructor = 
                                                                  org.apache.commons.lang3.time.FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                              constructor.setAccessible(true);
                                                              FastDateParser parser = constructor.newInstance("yyyy-MM", TimeZone.getDefault(), Locale.getDefault());
                                                              
                                                              // If the mutant (currentFormatField = null) is active, the second field (MM) will not be 
                                                              // correctly processed or a failure/exception will occur during parsing/initialization.
                                                              // We verify that the parser successfully parses a date string matching the multi-field pattern.
                                                              assertNotNull("Parser should be successfully initialized", parser);
                                                              
                                                              java.util.Date date = parser.parse("2023-05");
                                                              assertNotNull("Parser should successfully parse a valid date string with multiple fields", date);
                                                              
                                                              java.util.Calendar cal = java.util.Calendar.getInstance();
                                                              cal.setTime(date);
                                                              org.junit.Assert.assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                                              org.junit.Assert.assertEquals(java.util.Calendar.MAY, cal.get(java.util.Calendar.MONTH));
                                                          }

    @Test
                                                     public void testInitRespectsTimeZoneAndLocaleForThisYear() throws Exception {
                                                         TimeZone tz = TimeZone.getTimeZone("GMT+12:00");
                                                         Locale loc = Locale.US;
                                                         String pattern = "y";
                                                 
                                                         java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                         constructor.setAccessible(true);
                                                         FastDateParser parser = constructor.newInstance(pattern, tz, loc);
                                                 
                                                         java.lang.reflect.Field yearField = FastDateParser.class.getDeclaredField("thisYear");
                                                         yearField.setAccessible(true);
                                                         int parsedThisYear = yearField.getInt(parser);
                                                 
                                                         Calendar expectedCal = Calendar.getInstance(tz, loc);
                                                         int expectedYear = expectedCal.get(Calendar.YEAR);
                                                 
                                                         assertEquals("The initialized year must match the year in the specified TimeZone and Locale", expectedYear, parsedThisYear);
                                                     }

    @Test
                                                public void testInitLoopMutantDetection() throws Exception {
                                                    // Instantiate FastDateParser with a multi-field pattern using reflection to bypass protected access
                                                    java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                                    constructor.setAccessible(true);
                                                    FastDateParser parser = constructor.newInstance("yyyy-MM-dd HH:mm:ss", TimeZone.getDefault(), Locale.getDefault());
                                                    
                                                    // Verify that the parser successfully initializes and parses a valid date string matching the pattern
                                                    String sourceDate = "2023-10-05 15:30:45";
                                                    java.util.Date date = parser.parse(sourceDate);
                                                    
                                                    assertNotNull("The parsed date should not be null", date);
                                                    
                                                    java.util.Calendar calendar = java.util.Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault());
                                                    calendar.setTime(date);
                                                    
                                                    org.junit.Assert.assertEquals(2023, calendar.get(java.util.Calendar.YEAR));
                                                    org.junit.Assert.assertEquals(java.util.Calendar.OCTOBER, calendar.get(java.util.Calendar.MONTH));
                                                    org.junit.Assert.assertEquals(5, calendar.get(java.util.Calendar.DAY_OF_MONTH));
                                                    org.junit.Assert.assertEquals(15, calendar.get(java.util.Calendar.HOUR_OF_DAY));
                                                    org.junit.Assert.assertEquals(30, calendar.get(java.util.Calendar.MINUTE));
                                                    org.junit.Assert.assertEquals(45, calendar.get(java.util.Calendar.SECOND));
                                                }

    @Test
                                           public void testMutantCaughtByMultipleFieldsPattern() throws Exception {
                                               // Using reflection to instantiate FastDateParser since the constructor has protected access
                                               java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                               constructor.setAccessible(true);
                                               FastDateParser parser = constructor.newInstance("yyyy-MM", TimeZone.getDefault(), Locale.getDefault());
                                               
                                               // Parsing a valid date matching "yyyy-MM" format
                                               java.util.Date date = parser.parse("2023-05");
                                               
                                               // In the original code, "2023-05" parses correctly with year 2023 and month May (4 in 0-indexed calendars).
                                               // Under the mutation, since currentFormatField is not updated to "MM", the second strategy 
                                               // will incorrectly correspond to "yyyy" instead of "MM", failing to parse the month correctly 
                                               // or resulting in a mismatched strategy array / regex.
                                               java.util.Calendar cal = java.util.Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault());
                                               cal.setTime(date);
                                               
                                               org.junit.Assert.assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                               org.junit.Assert.assertEquals(java.util.Calendar.MAY, cal.get(java.util.Calendar.MONTH));
                                           }

    @Test
                                      public void testStrategiesArrayInitializationMutant() throws Exception {
                                          // Use reflection to access the protected constructor of FastDateParser
                                          java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                          constructor.setAccessible(true);
                                          FastDateParser parser = constructor.newInstance("yyyy-MM-dd HH:mm:ss", TimeZone.getDefault(), Locale.getDefault());
                                  
                                          // Use reflection to access the private 'strategies' field
                                          java.lang.reflect.Field strategiesField = FastDateParser.class.getDeclaredField("strategies");
                                          strategiesField.setAccessible(true);
                                          Object strategiesObj = strategiesField.get(parser);
                                  
                                          // Verify that the strategies array is correctly initialized and contains the expected number of strategies (6 components)
                                          assertNotNull("Strategies array should not be null", strategiesObj);
                                          assertTrue("Strategies array should be an array", strategiesObj.getClass().isArray());
                                          assertEquals("Strategies array length should match the number of format fields", 6, java.lang.reflect.Array.getLength(strategiesObj));
                                      }

    @Test
                                 public void testInitThrowsExceptionOnTrailingCharacters() throws Exception {
                                     // A pattern with valid components followed by unparseable trailing characters
                                     // will leave regionStart() != regionEnd(), triggering the IllegalArgumentException.
                                     java.lang.reflect.Constructor<org.apache.commons.lang3.time.FastDateParser> constructor = 
                                         org.apache.commons.lang3.time.FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                     constructor.setAccessible(true);
                                     try {
                                         constructor.newInstance("yyyy-MM-dd extra-invalid-chars", TimeZone.getDefault(), Locale.getDefault());
                                         org.junit.Assert.fail("Expected IllegalArgumentException");
                                     } catch (java.lang.reflect.InvocationTargetException e) {
                                         if (e.getCause() instanceof IllegalArgumentException) {
                                             // Expected exception
                                         } else {
                                             throw e;
                                         }
                                     }
                                 }

    @Test
                            public void testMutantCurrentFormatFieldAssignment() throws Exception {
                                // Constructing a FastDateParser with a multi-token pattern ensures 
                                // that the loop executes multiple times and updates currentFormatField.
                                // The mutant affects how currentFormatField is updated when transitioning or exiting.
                                TimeZone tz = TimeZone.getTimeZone("UTC");
                                Locale locale = Locale.US;
                                
                                java.lang.reflect.Constructor<FastDateParser> constructor = FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                                constructor.setAccessible(true);
                                FastDateParser parser = constructor.newInstance("MM/dd/yyyy", tz, locale);
                                
                                assertNotNull("Parser should be successfully created", parser);
                                assertEquals("MM/dd/yyyy", parser.getPattern());
                                
                                // Verify that parsing works correctly, ensuring all strategies were correctly assigned
                                // and currentFormatField didn't get stuck due to the ternary mutation.
                                java.util.Date date = parser.parse("01/15/2023");
                                assertNotNull("Parsed date should not be null", date);
                                
                                java.util.Calendar cal = java.util.Calendar.getInstance(tz, locale);
                                cal.setTime(date);
                                assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                assertEquals(java.util.Calendar.JANUARY, cal.get(java.util.Calendar.MONTH));
                                assertEquals(15, cal.get(java.util.Calendar.DAY_OF_MONTH));
                            }

    @Test
                       public void testInitLoopAndPatternParsing() throws Exception {
                           String pattern = "yyyy-MM-dd HH:mm:ss Z";
                           TimeZone tz = TimeZone.getTimeZone("GMT");
                           Locale locale = Locale.US;
                           
                           java.lang.reflect.Constructor<org.apache.commons.lang3.time.FastDateParser> constructor = 
                               org.apache.commons.lang3.time.FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                           constructor.setAccessible(true);
                           
                           org.apache.commons.lang3.time.FastDateParser parser = constructor.newInstance(pattern, tz, locale);
                           
                           java.lang.reflect.Method getParsePatternMethod = org.apache.commons.lang3.time.FastDateParser.class.getDeclaredMethod("getParsePattern");
                           getParsePatternMethod.setAccessible(true);
                           
                           assertNotNull("Parse pattern should not be null", getParsePatternMethod.invoke(parser));
                           assertEquals("TimeZone should match", tz, parser.getTimeZone());
                           assertEquals("Locale should match", locale, parser.getLocale());
                           
                           org.apache.commons.lang3.time.FastDateParser parserWithLiterals = constructor.newInstance("yyyy年MM月dd日 HH:mm:ss", tz, locale);
                           assertNotNull("Parse pattern with literals should not be null", getParsePatternMethod.invoke(parserWithLiterals));
                       }

    @Test
                  public void testInitMutantStrategiesArraySize() throws Exception {
                      // Given a pattern with multiple distinct strategy tokens (e.g., Year and Month)
                      String pattern = "yyyy-MM";
                      TimeZone timeZone = TimeZone.getDefault();
                      Locale locale = Locale.US;
              
                      // When the FastDateParser is instantiated, it calls init()
                      // Using an anonymous subclass to access the protected constructor
                      FastDateParser parser = new FastDateParser(pattern, timeZone, locale) {};
              
                      // Using reflection to access the private 'strategies' field to verify its length
                      java.lang.reflect.Field strategiesField = FastDateParser.class.getDeclaredField("strategies");
                      strategiesField.setAccessible(true);
                      Object[] strategies = (Object[]) strategiesField.get(parser);
              
                      // Assert that the strategies array length matches the expected number of format components (2 tokens).
                      // The mutant (collector.size() - 1) would produce an array of size 1 instead of 2.
                      assertNotNull("Strategies array should not be null", strategies);
                      assertEquals("Strategies array length should match the number of parsed pattern components", 2, strategies.length);
                  }

    @Test
             public void testInitMultipleFormatFieldsMutation() throws Exception {
                 // Initialize FastDateParser with a pattern containing multiple format fields ("yyyy", "MM", "dd")
                 // This ensures the loop in init() runs multiple times, executing the assignment:
                 // currentFormatField = nextFormatField; vs currentFormatField = (nextFormatField == null) ? null : nextFormatField;
                 java.lang.reflect.Constructor<org.apache.commons.lang3.time.FastDateParser> constructor = 
                     org.apache.commons.lang3.time.FastDateParser.class.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
                 constructor.setAccessible(true);
                 FastDateParser parser = constructor.newInstance("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
                 
                 // Verify that the parser correctly parses a date string matching the multi-field pattern,
                 // which proves that currentFormatField and strategies were correctly initialized and transitioned.
                 Date date = parser.parse("2023-10-05");
                 assertNotNull("Parsed date should not be null", date);
                 
                 Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
                 calendar.setTime(date);
                 assertEquals(2023, calendar.get(Calendar.YEAR));
                 assertEquals(Calendar.OCTOBER, calendar.get(Calendar.MONTH));
                 assertEquals(5, calendar.get(Calendar.DAY_OF_MONTH));
             }

    @Test
        public void testInitMutantStrategiesArraySize1() throws Exception {
            // Use reflection to create an instance of FastDateParser since the constructor is protected
            Class<?> parserClass = FastDateParser.class;
            java.lang.reflect.Constructor<?> constructor = parserClass.getDeclaredConstructor(String.class, TimeZone.class, Locale.class);
            constructor.setAccessible(true);
            Object parser = constructor.newInstance("yyyy-MM-dd", TimeZone.getDefault(), Locale.getDefault());
            
            // Use reflection to access the private 'strategies' field
            java.lang.reflect.Field strategiesField = parserClass.getDeclaredField("strategies");
            strategiesField.setAccessible(true);
            
            Object strategiesArrayObj = strategiesField.get(parser);
            
            org.junit.Assert.assertNotNull("Strategies array should not be null", strategiesArrayObj);
            int length = java.lang.reflect.Array.getLength(strategiesArrayObj);
            org.junit.Assert.assertEquals("Strategies array length should match the number of pattern components", 3, length);
        }


}
