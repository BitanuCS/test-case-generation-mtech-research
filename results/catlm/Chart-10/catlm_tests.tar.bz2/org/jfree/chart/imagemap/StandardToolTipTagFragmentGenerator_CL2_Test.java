package org.jfree.chart.imagemap;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class StandardToolTipTagFragmentGenerator_CL2_Test {

    @Test
    public void testImageMapToolTipFragment() throws Exception {
        StandardToolTipTagFragmentGenerator g 
                = new StandardToolTipTagFragmentGenerator();
        assertThat(g.generateToolTipFragment(null), is(""));
        assertThat(g.generateToolTipFragment("abc"), is("abc"));
        assertThat(g.generateToolTipFragment("abc\ndef"), is("abc \ndef"));
        assertThat(g.generateToolTipFragment("abc\n\rdef"), is("abc \n\rdef"));
    }
}
