package org.jfree.chart.imagemap;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class StandardToolTipTagFragmentGenerator_CL0_Test {

    @Test
    public void test() throws Exception {
        StandardToolTipTagFragmentGenerator g 
                = new StandardToolTipTagFragmentGenerator();
        assertThat(g.generateToolTipFragment(null), is(nullValue()));
        assertThat(g.generateToolTipFragment("abc"), is("abc"));
    }
}
