package org.jfree.chart.imagemap;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class StandardToolTipTagFragmentGenerator_CL1_Test {

    @Test
    public void testImageMapToolTipFragment() {}
// Defects4J: flaky method
//     @Test
//     public void testImageMapToolTipFragment() throws Exception {
//         StandardToolTipTagFragmentGenerator g 
//                 = new StandardToolTipTagFragmentGenerator();
//         assertThat(g.generateToolTipFragment(null), 
//                 is(nullValue()));
//         assertThat(g.generateToolTipFragment("abc"), 
//                 is(" title=\"abc\" alt=\"\""));
//     }
}
