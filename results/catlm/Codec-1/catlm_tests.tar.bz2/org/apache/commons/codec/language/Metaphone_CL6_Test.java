package org.apache.commons.codec.language;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.StringEncoder;

public class Metaphone_CL6_Test {

    @Test
    public void testMetaphone() throws Exception {
        StringEncoder encoder = new Metaphone();
        String input = "Hello World!";
        String expectedOutput = "Kello Worl Worl";
        String output = encoder.encode(input);
        assertEquals(expectedOutput, output);
    }
}
