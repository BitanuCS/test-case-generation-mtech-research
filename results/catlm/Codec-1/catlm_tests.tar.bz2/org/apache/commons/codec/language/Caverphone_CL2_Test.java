package org.apache.commons.codec.language;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.StringEncoder;

public class Caverphone_CL2_Test {

    @Test
    public void testCaverphone() throws Exception {
        StringEncoder encoder = new Caverphone();
        String caverphone = encoder.encode("hello");
        assertThat(caverphone, is("1111111111"));
    }
}
