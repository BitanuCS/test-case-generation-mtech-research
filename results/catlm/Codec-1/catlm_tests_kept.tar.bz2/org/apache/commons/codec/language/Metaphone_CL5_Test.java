package org.apache.commons.codec.language;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.StringEncoder;

public class Metaphone_CL5_Test {

    @Test
    public void testMetaphone() {}
// Defects4J: flaky method
//     @Test
//     public void testMetaphone() throws EncoderException {
//         String str = "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z";
//         StringEncoder encoder = new Metaphone();
//         String metaphone = encoder.encode(str);
//         assertThat(metaphone, is("A B C D E F G H I J K L M N O P Q R S T U V W X Y Z"));
//     }
}
