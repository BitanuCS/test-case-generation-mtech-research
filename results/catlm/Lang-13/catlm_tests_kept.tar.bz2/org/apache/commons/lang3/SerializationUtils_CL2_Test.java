package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class SerializationUtils_CL2_Test {

    @Test
    public void testClone() {}
// Defects4J: flaky method
//     @Test
//     public void testClone() throws Exception {
//         final Map<String, String> map = new HashMap<String, String>();
//         map.put("key1", "value1");
//         map.put("key2", "value2");
//         final Serializable obj = new Serializable() {
//             private static final long serialVersionUID = 1L;
// 
//             @Override
//             public String toString() {
//                 return "obj";
//             }
//         };
//         final Serializable clone = SerializationUtils.clone(obj);
//         assertThat(clone, is(instanceOf(Serializable.class)));
//         assertThat(clone, is(not(sameInstance(obj))));
//         assertThat(clone, is(map));
//     }
}
