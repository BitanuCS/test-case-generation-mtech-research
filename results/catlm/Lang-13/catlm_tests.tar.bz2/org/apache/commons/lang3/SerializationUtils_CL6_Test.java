package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class SerializationUtils_CL6_Test {

    @Test
    public void testClone() throws Exception {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("key", "value");
        final Serializable obj = new Serializable() {
            private static final long serialVersionUID = 1L;

            @Override
            public String toString() {
                return "test";
            }
        };
        final Serializable clone = SerializationUtils.clone(obj);
        assertThat(clone, is(instanceOf(Serializable.class)));
        assertThat(clone.toString(), is("test"));
        assertThat(map.size(), is(1));
        assertThat(map.get("key"), is("value"));
    }
}
