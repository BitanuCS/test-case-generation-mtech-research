package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import org.joda.time.base.AbstractPartial;
import org.joda.time.field.AbstractPartialFieldProperty;
import org.joda.time.field.FieldUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

public class Partial_CL5_Test {

    @Test
    public void test_equality() throws Exception {
        Partial partial1 = new Partial(DateTimeFieldType.year(), 2005);
        Partial partial2 = new Partial(DateTimeFieldType.year(), 2005);
        assertEquals(partial1, partial2);
        assertEquals(partial2, partial1);
        Partial partial3 = new Partial(DateTimeFieldType.year(), 2006);
        assertNotEquals(partial1, partial3);
        assertNotEquals(partial3, partial1);
    }
}
