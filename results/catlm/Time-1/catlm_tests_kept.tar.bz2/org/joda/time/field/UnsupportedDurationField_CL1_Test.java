package org.joda.time.field;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.Serializable;
import java.util.HashMap;
import org.joda.time.DurationField;
import org.joda.time.DurationFieldType;

public class UnsupportedDurationField_CL1_Test {

    @Test
    public void test_getDifference() {}
// Defects4J: flaky method
//     @Test
//     public void test_getDifference() throws Exception {
//         UnsupportedDurationField testField = UnsupportedDurationField.getInstance(DurationFieldType.minutes());
//         assertThat(testField.getDifference(0L, 1L), is(1));
//         assertThat(testField.getDifference(1L, 1L), is(-1));
//         assertThat(testField.getDifference(1L, 0L), is(-1));
//         assertThat(testField.getDifference(0L, 0L), is(0));
//         assertThat(testField.getDifference(0L, 1L), is(0));
//         assertThat(testField.getDifference(1L, 1L), is(0));
//     }
}
