package org.joda.time.field;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.Serializable;
import java.util.HashMap;
import org.joda.time.DurationField;
import org.joda.time.DurationFieldType;

public class UnsupportedDurationField_CL0_Test {

    @Test
    public void test_getName() throws Exception {
        assertThat(UnsupportedDurationField.getInstance(DurationFieldType.weeks()).getName(), is("weeks"));
        assertThat(UnsupportedDurationField.getInstance(DurationFieldType.days()).getName(), is("days"));
        assertThat(UnsupportedDurationField.getInstance(DurationFieldType.hours()).getName(), is("hours"));
        assertThat(UnsupportedDurationField.getInstance(DurationFieldType.minutes()).getName(), is("minutes"));
        assertThat(UnsupportedDurationField.getInstance(DurationFieldType.seconds()).getName(), is("seconds"));
        assertThat(UnsupportedDurationField.getInstance(DurationFieldType.millis()).getName(), is("millis"));
    }
}
