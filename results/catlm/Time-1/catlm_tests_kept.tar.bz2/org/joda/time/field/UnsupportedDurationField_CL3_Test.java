package org.joda.time.field;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.Serializable;
import java.util.HashMap;
import org.joda.time.DurationField;
import org.joda.time.DurationFieldType;

public class UnsupportedDurationField_CL3_Test {

    @Test
    public void testUnsupported() {}
// Defects4J: flaky method
//     @Test
//     public void testUnsupported() throws Exception {
//         UnsupportedDurationField field = UnsupportedDurationField.getInstance(DurationFieldType.minutes());
//         assertThat(field.isSupported(), is(false));
//         assertThat(field.getValue(123L), is(0L));
//         assertThat(field.getValueAsLong(123L), is(0L));
//         assertThat(field.getMillis(123L), is(0L));
//         assertThat(field.getUnitMillis(), is(0L));
//         assertThat(field.getName(), is("minutes"));
//         assertThat(field.toString(), is("UnsupportedDurationField[minutes]"));
//     }
}
