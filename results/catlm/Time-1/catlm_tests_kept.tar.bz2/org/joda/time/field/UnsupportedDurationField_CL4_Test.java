package org.joda.time.field;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.Serializable;
import java.util.HashMap;
import org.joda.time.DurationField;
import org.joda.time.DurationFieldType;

public class UnsupportedDurationField_CL4_Test {

    @Test
    public void test_getName() throws Exception {
        DurationField f = UnsupportedDurationField.getInstance(DurationFieldType.weeks());
        assertThat(f.getName(), is("weeks"));
    }
}
