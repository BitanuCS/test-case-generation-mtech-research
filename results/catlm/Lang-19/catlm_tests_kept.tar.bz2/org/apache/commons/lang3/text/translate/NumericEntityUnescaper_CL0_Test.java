package org.apache.commons.lang3.text.translate;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.IOException;
import java.io.Writer;

public class NumericEntityUnescaper_CL0_Test {

    @Test
    public void testUnescape() {}
// Defects4J: flaky method
//     @Test
//     public void testUnescape() throws IOException {
//         NumericEntityUnescaper unesc = new NumericEntityUnescaper();
//         assertThat(unesc.translate("&#123;"), is((int)123));
//         assertThat(unesc.translate("&amp;"), is('&'));
//         assertThat(unesc.translate("&#x123;"), is((int)123));
//         assertThat(unesc.translate("&amp;#123;"), is((int)123));
//         assertThat(unesc.translate("&#x123;#123;"), is((int)123));
//         assertThat(unesc.translate("&amp;#x123;"), is((int)123));
//         assertThat(unesc.translate("&#x123;#x123;"), is((int)123));
//         assertThat(unesc.translate("&amp;#123;#x123;"), is((int)123));
//     }
}
