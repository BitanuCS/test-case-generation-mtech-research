package org.mockito.internal.stubbing.answers;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.Serializable;
import java.lang.reflect.Modifier;
import org.mockito.internal.stubbing.defaultanswers.GloballyConfiguredAnswer;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

public class CallsRealMethods_CL1_Test {

    @Test
    public void testAnswerIsSerializable() throws Exception {
        Answer<Object> answer = new CallsRealMethods();
        assertThat(answer, is(not(instanceOf(Serializable.class))));
    }
}
