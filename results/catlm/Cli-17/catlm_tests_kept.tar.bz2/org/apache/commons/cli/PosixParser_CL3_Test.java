package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class PosixParser_CL3_Test {

    @Test
    public void testFlatten() throws Exception {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption(OptionBuilder.hasArg().isRequired().create('i'));
        options.addOption(OptionBuilder.hasArgs().create('a'));
        options.addOption(OptionBuilder.hasOptionalArg().create('b'));
        options.addOption(OptionBuilder.hasArgs().create('c'));
        options.addOption(OptionBuilder.hasOptionalArg().create('d'));
        String[] args = new String[] { "-i", "1", "-a", "2", "-b", "3", "-c", "4", "-d", "5" };
        String[] expected = new String[] { "-i", "1", "-a", "2", "-b", "3", "-c", "4", "-d", "5" };
        List tokens = Arrays.asList(args);
        String[] actual = parser.flatten(options, args, false);
        assertThat(tokens, is(equalTo(expected)));
        assertThat(actual, is(equalTo(expected)));
    }
}
