package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class PosixParser_CL1_Test {

    @Test
    public void testFlatten() throws Exception {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption(OptionBuilder.hasArg().isRequired().create('a'));
        options.addOption(OptionBuilder.hasArgs().create('b'));
        String[] args = new String[]{"-a", "foo", "-b", "bar"};
        String[] tokens = parser.flatten(options, args, false);
        assertThat(tokens, is(new String[]{"-a", "foo", "-b", "bar"}));
    }
}
