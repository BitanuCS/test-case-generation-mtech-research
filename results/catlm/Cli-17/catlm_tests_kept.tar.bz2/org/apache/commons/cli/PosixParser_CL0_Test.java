package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class PosixParser_CL0_Test {

    @Test
    public void testFlatten() throws Exception {
        PosixParser parser = new PosixParser();
        Options options = new Options();

        options.addOption("c", "C", false, "C");
        options.addOption("x", "X", false, "X");
        options.addOption("y", "Y", false, "Y");
        options.addOption("z", "Z", false, "Z");

        String[] args = new String[]{"-c", "-x", "-y", "-z"};
        String[] actual = parser.flatten(options, args, false);
        String[] expected = {"-c", "-x", "-y", "-z"};

        assertThat(actual, is(expected));
    }
}
