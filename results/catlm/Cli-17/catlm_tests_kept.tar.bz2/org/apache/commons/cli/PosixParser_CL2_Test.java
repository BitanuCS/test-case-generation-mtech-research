package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class PosixParser_CL2_Test {

    @Test
    public void testFlatten() throws Exception {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption(OptionBuilder.hasArg().isRequired().create('v'));
        options.addOption(OptionBuilder.hasArgs().create('a'));
        String[] args = new String[] { "-v", "-a", "foo" };
        String[] tokens = parser.flatten(options, args, false);
        assertThat(tokens, is(new String[] { "-v", "foo" }));
    }
}
