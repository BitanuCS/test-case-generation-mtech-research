package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.math.BigInteger;
import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;

public class Base64_CL3_Test {

    @Test
    public void testBase64() throws Exception {
        String testString = "Hello World";
        byte[] testBytes = testString.getBytes("US-ASCII");
        byte[] encoded = Base64.encodeBase64(testBytes);
        byte[] decoded = Base64.decodeBase64(encoded);
        assertThat(decoded, is(testBytes));
    }
}
