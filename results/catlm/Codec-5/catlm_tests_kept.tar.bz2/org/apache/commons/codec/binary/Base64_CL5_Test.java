package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.math.BigInteger;
import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;

public class Base64_CL5_Test {

    @Test
    public void testBase64() {}
// Defects4J: flaky method
//     @Test
//     public void testBase64() throws DecoderException, EncoderException {
//         String input = "This is a test string";
//         byte[] encodedBytes = Base64.encodeBase64(input.getBytes());
//         assertThat(encodedBytes, is(equalTo(input)));
//         byte[] decodedBytes = Base64.decodeBase64(encodedBytes);
//         assertThat(decodedBytes, is(equalTo(input.getBytes())));
//     }
}
