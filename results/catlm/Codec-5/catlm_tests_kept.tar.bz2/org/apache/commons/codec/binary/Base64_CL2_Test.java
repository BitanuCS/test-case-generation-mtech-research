package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.math.BigInteger;
import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;

public class Base64_CL2_Test {

    @Test
    public void testBase64() throws DecoderException {
        String testString = "This is a test string";
        byte[] testBytes = testString.getBytes();
        byte[] encoded = Base64.encodeBase64(testBytes);
        byte[] decoded = Base64.decodeBase64(encoded);
        assertThat(decoded, is(equalTo(testBytes)));
    }
}
