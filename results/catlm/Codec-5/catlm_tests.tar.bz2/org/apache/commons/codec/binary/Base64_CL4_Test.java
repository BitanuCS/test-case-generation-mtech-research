package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.math.BigInteger;
import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;

public class Base64_CL4_Test {

    @Test
    public void testBase64() throws Exception {
        String input = "This is a test string";
        byte[] output = Base64.encodeBase64(input.getBytes("UTF-8"));
        assertThat(output, is(input));
    }
}
