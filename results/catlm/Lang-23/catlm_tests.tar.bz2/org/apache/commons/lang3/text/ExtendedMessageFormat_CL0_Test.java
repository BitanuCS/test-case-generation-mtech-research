package org.apache.commons.lang3.text;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.Validate;

public class ExtendedMessageFormat_CL0_Test {

    @Test
    public void test_formatToCharacterIterator() throws Exception {
        final String pattern = "{0,number,#.##}";
        final Object[] arguments = new Object[] { new Integer(1) };
        final String formatted = MessageFormat.format(pattern, arguments);
        final Object[] expected = new Object[] { new Integer(1) };
        assertThat(formatted, is(expected));
    }
}
