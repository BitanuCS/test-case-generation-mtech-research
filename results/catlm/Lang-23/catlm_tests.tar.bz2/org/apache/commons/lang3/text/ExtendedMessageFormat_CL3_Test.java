package org.apache.commons.lang3.text;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.Validate;

public class ExtendedMessageFormat_CL3_Test {

    @Test
    public void testBlank() throws Exception {
        final String pattern = "{0}";
        MessageFormat mf = new MessageFormat(pattern);
        String formatted = mf.format(new Object[] { "" });
        assertEquals("", formatted);
        mf = new MessageFormat(pattern);
        formatted = mf.format(new Object[] { null });
        assertEquals("", formatted);
    }
}
