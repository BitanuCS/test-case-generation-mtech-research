package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.Serializable;
import org.joda.convert.FromString;
import org.joda.time.base.BasePeriod;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.field.FieldUtils;
import org.joda.time.format.ISOPeriodFormat;
import org.joda.time.format.PeriodFormatter;

public class Period_CL4_Test {

    @Test
    public void test_immutable() throws Exception {
        Period test = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        assertThat(test.getYears(), is(1));
        assertThat(test.getMonths(), is(2));
        assertThat(test.getWeeks(), is(3));
        assertThat(test.getDays(), is(4));
        assertThat(test.getHours(), is(5));
        assertThat(test.getMinutes(), is(6));
        assertThat(test.getSeconds(), is(7));
        assertThat(test.getMillis(), is(8));
    }
}
