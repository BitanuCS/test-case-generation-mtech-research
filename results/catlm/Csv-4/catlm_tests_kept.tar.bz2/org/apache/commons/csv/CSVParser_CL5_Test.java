package org.apache.commons.csv;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import static org.apache.commons.csv.Token.Type.TOKEN;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

public class CSVParser_CL5_Test {

    @Test
    public void testCSVParser() {}
// Defects4J: flaky method
//     @Test
//     public void testCSVParser() throws Exception {
//         CSVParser parser = CSVParser.parse("a;b\nc;d", CSVFormat.RFC4180);
//         List<CSVRecord> records = parser.getRecords();
//         assertThat(records.size(), is(3));
//         assertThat(records.get(0).get(0), is("a"));
//         assertThat(records.get(1).get(0), is("b"));
//         assertThat(records.get(2).get(0), is("c"));
//         assertThat(records.get(0).get(1), is("d"));
//     }
}
