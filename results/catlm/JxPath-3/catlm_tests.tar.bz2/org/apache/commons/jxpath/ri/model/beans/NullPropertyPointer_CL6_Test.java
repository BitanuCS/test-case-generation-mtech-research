package org.apache.commons.jxpath.ri.model.beans;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathInvalidAccessException;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.NodePointer;

public class NullPropertyPointer_CL6_Test {

    @Test
    public void testSetValue() throws Exception {
        NullPropertyPointer pointer = new NullPropertyPointer(null);
        pointer.setValue("foo");
        assertThat(pointer.getValue(), is("foo"));
    }
}
