package org.mockito.internal.util;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.mockito.exceptions.Reporter;

public class Timer_CL0_Test {

    @Test
    public void testTimerIsCounting() {}
// Defects4J: flaky method
//     @Test
//     public void testTimerIsCounting() throws Exception {
//         Timer timer = new Timer(100);
//         assertThat(timer.isCounting(), is(true));
//     }
}
