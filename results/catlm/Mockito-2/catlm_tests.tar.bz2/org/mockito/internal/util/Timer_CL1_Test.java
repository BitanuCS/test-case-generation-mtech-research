package org.mockito.internal.util;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.mockito.exceptions.Reporter;

public class Timer_CL1_Test {

    @Test
    public void testTimerStartsAtZero() throws Exception {
        Timer timer = new Timer(100);
        assertThat(timer.isCounting(), is(false));
        assertThat(timer.isCounting(), is(false));
        assertThat(timer.isCounting(), is(false));
    }
}
