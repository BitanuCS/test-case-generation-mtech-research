package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.utils.ArchiveUtils;

public class TarArchiveInputStream_CL0_Test {

    @Test
    public void testMatches() throws Exception {
        byte[] sig = ArchiveUtils.toAsciiBytes("ustar\u0001\r\n");
        assertTrue(TarArchiveInputStream.matches(sig, sig.length));
        assertFalse(TarArchiveInputStream.matches(sig, sig.length+1));
    }
}
