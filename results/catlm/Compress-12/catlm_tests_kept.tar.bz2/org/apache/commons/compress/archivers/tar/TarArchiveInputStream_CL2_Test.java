package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.utils.ArchiveUtils;

public class TarArchiveInputStream_CL2_Test {

    @Test
    public void testMatches() {}
// Defects4J: flaky method
//     @Test
//     public void testMatches() throws Exception {
//         byte[] sig = new byte[] { 0x50, 0x4b, 0x03, 0x04 };
//         assertTrue(TarArchiveInputStream.matches(sig, sig.length));
//         assertFalse(TarArchiveInputStream.matches(sig, sig.length + 1));
//     }
}
