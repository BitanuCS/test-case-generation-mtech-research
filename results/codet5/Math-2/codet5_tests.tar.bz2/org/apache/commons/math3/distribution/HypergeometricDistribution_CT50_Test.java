package org.apache.commons.math3.distribution;

import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class HypergeometricDistribution_CT50_Test {

@Test public void testGetNumericalMean() throws Exception { HypergeometricDistribution distribution = new HypergeometricDistribution(1, 2, 3); assertEquals(0.5, distribution.getNumericalMean(), 0.001); }
}
