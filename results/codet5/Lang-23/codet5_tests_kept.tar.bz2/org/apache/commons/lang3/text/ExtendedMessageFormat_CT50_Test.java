package org.apache.commons.lang3.text;

import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.Validate;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class ExtendedMessageFormat_CT50_Test {

@Test public void testEquals() throws Exception { ExtendedMessageFormat format1 = new ExtendedMessageFormat("pattern", Locale.ENGLISH); ExtendedMessageFormat format2 = new ExtendedMessageFormat("pattern", Locale.ENGLISH); assertEquals(format1, format2); }
}
