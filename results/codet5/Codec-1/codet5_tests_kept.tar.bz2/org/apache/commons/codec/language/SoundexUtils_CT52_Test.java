package org.apache.commons.codec.language;

import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.StringEncoder;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class SoundexUtils_CT52_Test {

@Test public void testClean() {}
// Defects4J: flaky method
// @Test public void testClean() throws EncoderException { String str = "abc"; String result = SoundexUtils.clean(str); assertEquals("abc", result); }
}
