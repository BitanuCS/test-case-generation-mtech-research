package org.apache.commons.cli2.builder;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.validation.ClassValidator;
import org.apache.commons.cli2.validation.DateValidator;
import org.apache.commons.cli2.validation.FileValidator;
import org.apache.commons.cli2.validation.NumberValidator;
import org.apache.commons.cli2.validation.UrlValidator;
import org.apache.commons.cli2.validation.Validator;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class PatternBuilder_CT52_Test {

@Test public void testCreateOption() throws Exception { final PatternBuilder builder = new PatternBuilder(); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar"); builder.withPattern("/foo/bar/bar"); }
}
